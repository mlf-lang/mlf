(***********************************************************************)
(*                                                                     *)
(*                           Objective Caml                            *)
(*                                                                     *)
(*            Xavier Leroy, projet Cristal, INRIA Rocquencourt         *)
(*                                                                     *)
(*  Copyright 1996 Institut National de Recherche en Informatique et   *)
(*  en Automatique.  All rights reserved.  This file is distributed    *)
(*  under the terms of the Q Public License version 1.0.               *)
(*                                                                     *)
(***********************************************************************)

module Lexer = ELexer
module Parser = EParser
(* Adapted from Ocaml/toplevel/toploop.ml for MLF by Boris Yakobowski *)

let first_line = ref true
let got_eof = ref false;;

let read_input_default prompt buffer len =
  output_string stdout prompt; flush stdout;
  let i = ref 0 in
  try
    while true do
      if !i >= len then raise Exit;
      let c = input_char stdin in
      Bytes.set buffer !i c;
      incr i;
      if c = '\n' then raise Exit;
    done;
    (!i, false)
  with
  | End_of_file ->
      (!i, true)
  | Exit ->
      (!i, false)

let read_interactive_input = ref read_input_default

let refill_lexbuf buffer len =
  if !got_eof then (got_eof := false; 0) else begin
    let prompt =
(*      if !Clflags.noprompt then "" *)
      if !first_line then "# "
      else if !Lexer.in_comment then "* "
      else "  "
    in
    first_line := false;
    let (len, eof) = !read_interactive_input prompt buffer len in
    if eof then begin
      Highlight.echo_eof ();
      if len > 0 then got_eof := true;
      len
    end else
      len
  end

let _ =
  Sys.interactive := true;;

open SyntaxErrors

let rec skip_phrase lexbuf =
  try
    match Lexer.token lexbuf with
      Parser.SEMISEMI | Parser.EOF -> ()
    | _ -> skip_phrase lexbuf
  with
    | LexingError (UnterminatedComment _) -> ()
    | LexingError (InvalidChar _) -> skip_phrase lexbuf
;;

(* Maybe introduced a bug. TODO *)
let maybe_skip_phrase lexbuf =
  if Lexing.lexeme lexbuf = ";;" || lexbuf.Lexing.lex_eof_reached
  then ()
  else skip_phrase lexbuf

let wrap_parser parsing_fun lexbuf =
  try
    let ast = parsing_fun Lexer.token lexbuf in
    Parsing.clear_parser();
    ast
  with
  | LexingError (UnterminatedComment _) as exn -> raise exn
  | LexingError (InvalidChar _) as exn ->
      if !Highlight.input_name = "" then skip_phrase lexbuf;
      raise exn
  | (ParsingError _ | Parser.Error) as exn ->
      if !Highlight.input_name = "" then maybe_skip_phrase lexbuf;
      raise exn
;;

exception PPerror

let loop ppf
    ~init_env
    ~init_msg
    ~parse_phrase
    ~eval_phrase
    ~report_error
    =
  Format.fprintf ppf "        MLFω version 0.3@.@.";
  Format.fprintf ppf "%s\n%!" init_msg;
  let lb = Lexing.from_function refill_lexbuf in
  Highlight.input_name := "";
  Highlight.input_lexbuf := Some lb;
  Sys.catch_break true;
  let env = ref init_env in
  while true do
    try
      Lexing.flush_input lb;
      Highlight.reset();
      first_line := true;
      let phr =
        try wrap_parser parse_phrase lb
        with Exit -> raise PPerror in
      env := eval_phrase !env phr
    with
    | PPerror -> ()
    | End_of_file -> exit 0
    | Sys.Break -> Format.fprintf ppf "Interrupted.@."
    | Parser.Error ->
      let loc = Locations.curr_loc lb in
      if !Highlight.input_name = "";
      then maybe_skip_phrase lb;
      Highlight.print_loc ppf loc;
      Format.fprintf ppf "Syntax error.@."
    | exn -> report_error ppf exn
  done
