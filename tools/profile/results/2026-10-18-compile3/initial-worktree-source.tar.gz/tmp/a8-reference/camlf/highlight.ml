(***********************************************************************)
(*                                                                     *)
(*                           Objective Caml                            *)
(*                                                                     *)
(*            Xavier Leroy, projet Cristal, INRIA Rocquencourt         *)
(*                                                                     *)
(*  Copyright 1996 Institut National de Recherche en Informatique et   *)
(*  en Automatique.  All rights reserved.  This file is distributed    *)
(*  under the terms of the Q Public License version 1.0.               *)
(*                                                                     *)
(***********************************************************************)

(* Adapted from OCaml/utils/terminfo.ml and OCaml/parsing/location.ml
   for MLF by Boris Yakobowski *)

module Terminfo = struct

type status =
  | Uninitialised
  | Bad_term
  | Good_term of int  (* number of lines of the terminal *)
;;
let setup (_ : out_channel) = Bad_term;;
let backup (_ : int) = ();;
let standout (_ : bool) = ();;
let resume (_ : int) = ();;

end


open Lexing
open Locations
open Format


let input_name = ref ""
let input_lexbuf = ref (None : lexbuf option)

(* Terminal info *)

let status = ref Terminfo.Uninitialised

let num_loc_lines = ref 0 (* number of lines already printed after input *)

(* Highlight the location using standout mode. *)
(* It is crucial that the pervasives printing functions are the one used,
   for highlighting to work *)

let highlight_terminfo num_lines loc1 ?(loc2=dummy_loc) lb =
  (* Char 0 is at offset -lb.lex_abs_pos in lb.lex_buffer. *)
  let pos0 = -lb.lex_abs_pos in
  (* Do nothing if the buffer does not contain the whole phrase. *)
  if pos0 < 0 then raise Exit;
  (* Count number of lines in phrase *)
  let lines = ref !num_loc_lines in
  for i = pos0 to lb.lex_buffer_len - 1 do
    if (Bytes.unsafe_to_string lb.lex_buffer).[i] = '\n' then incr lines
  done;
  (* If too many lines, give up *)
  if !lines >= num_lines - 2 then raise Exit;
  (* Move cursor up that number of lines *)
  flush stdout; Terminfo.backup !lines;
  (* Print the input, switching to standout for the location *)
  let bol = ref false in
  Stdlib.print_string "# ";
  for pos = 0 to lb.lex_buffer_len - pos0 - 1 do
    if !bol then (Stdlib.print_string "  "; bol := false);
    if pos = loc1.loc_start.pos_cnum || pos = loc2.loc_start.pos_cnum then
      Terminfo.standout true;
    if pos = loc1.loc_end.pos_cnum || pos = loc2.loc_end.pos_cnum then
      Terminfo.standout false;
    let c = (Bytes.unsafe_to_string lb.lex_buffer).[pos + pos0] in
    Stdlib.print_char c;
    bol := (c = '\n')
  done;
  (* Make sure standout mode is over *)
  Terminfo.standout false;
  (* Position cursor back to original location *)
  Terminfo.resume !num_loc_lines;
  flush stdout

(* Highlight the location by printing it again. *)

let highlight_dumb ppf lb loc =
  (* Char 0 is at offset -lb.lex_abs_pos in lb.lex_buffer. *)
  let pos0 = -lb.lex_abs_pos in
  (* Do nothing if the buffer does not contain the whole phrase. *)
  if pos0 < 0 then raise Exit;
  let end_pos = lb.lex_buffer_len - pos0 - 1 in
  (* Determine line numbers for the start and end points *)
  let line_start = ref 0 and line_end = ref 0 in
  for pos = 0 to end_pos do
    if (Bytes.unsafe_to_string lb.lex_buffer).[pos + pos0] = '\n' then begin
      if loc.loc_start.pos_cnum > pos then incr line_start;
      if loc.loc_end.pos_cnum   > pos then incr line_end;
    end
  done;
  (* Print character location (useful for Emacs) *)
  fprintf ppf "Characters %i-%i:@."
                 loc.loc_start.pos_cnum loc.loc_end.pos_cnum;
  (* Print the input, underlining the location *)
  pp_print_string ppf "  ";
  let line = ref 0 in
  let pos_at_bol = ref 0 in
  for pos = 0 to end_pos do
    let c = (Bytes.unsafe_to_string lb.lex_buffer).[pos + pos0] in
    if c <> '\n' then begin
      if !line = !line_start && !line = !line_end then
        (* loc is on one line: print whole line *)
        pp_print_char ppf c
      else if !line = !line_start then
        (* first line of multiline loc: print ... before loc_start *)
        if pos < loc.loc_start.pos_cnum
        then pp_print_char ppf '.'
        else pp_print_char ppf c
      else if !line = !line_end then
        (* last line of multiline loc: print ... after loc_end *)
        if pos < loc.loc_end.pos_cnum
        then pp_print_char ppf c
        else pp_print_char ppf '.'
      else if !line > !line_start && !line < !line_end then
        (* intermediate line of multiline loc: print whole line *)
        pp_print_char ppf c
    end else begin
      if !line = !line_start && !line = !line_end then begin
        (* loc is on one line: underline location *)
        pp_print_string ppf "\n  ";
        for i = !pos_at_bol to loc.loc_start.pos_cnum - 1 do
          pp_print_char ppf ' '
        done;
        for i = loc.loc_start.pos_cnum to loc.loc_end.pos_cnum - 1 do
          pp_print_char ppf '^'
        done
      end;
      if !line >= !line_start && !line <= !line_end then begin
        fprintf ppf "@.";
        if pos < loc.loc_end.pos_cnum then pp_print_string ppf "  "
      end;
      incr line;
      pos_at_bol := pos + 1;
    end
  done

(* Highlight the location using one of the supported modes. *)

let rec highlight_locations loc1 ?loc2 ppf =
  match !status with
  | Terminfo.Uninitialised ->
      status := Terminfo.setup stdout; highlight_locations loc1 ?loc2 ppf
  | Terminfo.Bad_term ->
      begin match !input_lexbuf with
      | None -> false
      | Some lb ->
          let norepeat =
            try Sys.getenv "TERM" = "norepeat" with Not_found -> false in
          if norepeat then false else
            try
              highlight_dumb ppf lb loc1;
              (match loc2 with
                | Some loc2 -> highlight_dumb ppf lb loc2
                | None -> ());
              true
            with Exit -> false
      end
  | Terminfo.Good_term num_lines ->
      begin match !input_lexbuf with
      | None -> false
      | Some lb ->
          try highlight_terminfo num_lines loc1 ?loc2 lb; true
          with Exit -> false
      end


(* Print the location in some way or another *)
let reset () =
  num_loc_lines := 0

let (msg_file, msg_line, msg_chars, msg_to, msg_colon, msg_head) =
  ("File \"", "\", line ", ", characters ", "-", ":", "")

(* return file, line, char from the given position *)
let get_pos_info pos =
  let (filename, linenum, linebeg) =
    if pos.pos_fname = "" && !input_name = "" then
      ("", -1, 0)
    else if pos.pos_fname = "" then
      (!input_name, pos.pos_lnum, pos.pos_bol)
(*      Linenum.for_position !input_name pos.pos_cnum *)
    else
      (pos.pos_fname, pos.pos_lnum, pos.pos_bol)
  in
  (filename, linenum, pos.pos_cnum - linebeg)
;;

let print_loc ppf loc =
  let (file, line, startchar) = get_pos_info loc.loc_start in
  let endchar = loc.loc_end.pos_cnum - loc.loc_start.pos_cnum + startchar in
(*  let (startchar, endchar) =
    if startchar < 0 then (0, 1) else (startchar, endchar)
  in *)
  if file = "" then begin
    if highlight_locations loc ppf then () else
      fprintf ppf "Characters %i-%i:@."
              loc.loc_start.pos_cnum loc.loc_end.pos_cnum
  end else begin
    fprintf ppf "%s%s%s%i" msg_file file msg_line line;
    fprintf ppf "%s%i" msg_chars startchar;
    fprintf ppf "%s%i%s@.%s" msg_to endchar msg_colon msg_head;
  end

let print_locs ppf loc1 loc2 =
  let (file1, line1, startchar1) = get_pos_info loc1.loc_start
  and (file2, line2, startchar2) = get_pos_info loc2.loc_start in
  let endchar1 = loc1.loc_end.pos_cnum - loc1.loc_start.pos_cnum + startchar1
  and endchar2 = loc2.loc_end.pos_cnum - loc2.loc_start.pos_cnum + startchar2 in
  assert (file1 = file2);
  if file1 = "" then (
    if highlight_locations loc1 ~loc2 ppf = false then (
      fprintf ppf "Characters %i-%i:@."
        loc1.loc_start.pos_cnum loc1.loc_end.pos_cnum;
      fprintf ppf "Characters %i-%i:@."
        loc2.loc_start.pos_cnum loc2.loc_end.pos_cnum;
    )
  ) else (
    fprintf ppf "%s%s%s%i" msg_file file1 msg_line line1;
    fprintf ppf "%s%i" msg_chars startchar1;
    fprintf ppf "%s%i%s@.%s" msg_to endchar1 msg_colon msg_head;

    fprintf ppf "%s%s%s%i" msg_file file2 msg_line line2;
    fprintf ppf "%s%i" msg_chars startchar2;
    fprintf ppf "%s%i%s@.%s" msg_to endchar2 msg_colon msg_head;
  )


let echo_eof () =
  print_newline ();
  incr num_loc_lines
