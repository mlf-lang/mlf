# Native C/MLF benchmark comparison

The runner is written in MLF and builds with the native package manager. It
compares a candidate compiler, a baseline compiler and C on all nine pinned
Benchmarks Game workloads. It does not run the Haskell or Rust baselines.

```sh
export MLF_GC_PREFIX=/path/to/bdwgc-install
./mlfpkg --manifest tools/bench/mlf-package.json \
  --compiler /path/to/native/emlf --runtime "$PWD/runtime/mlf_runtime.c" \
  --build-dir "$PWD/.mlf-build/native-bench-driver" --timeout 21600 build
.mlf-build/native-bench-driver/bin/bench \
  /path/to/candidate/emlf /path/to/baseline/emlf \
  "$PWD/.mlf-build/native-bench-results" 7 /absolute/path/to/clang
```

Run from the repository root with a fresh output directory and no other builds
or measured jobs running. An odd sample count of at least three is required.
Each measured compilation uses a new directory and runtime object. MLF source
compilation overlaps runtime compilation, followed by LLVM optimization and
linking, matching the existing benchmark pipeline. C uses the manifest's flags.
Process creation, IO, collection and exit remain in runtime measurements.
Each freshly linked executable receives one untimed, output-checked invocation
at the measured input before its timed fresh process. This keeps the operating
system's one-time executable verification out of steady-state runtime ratios.

Dedicated correctness executables for all three compilers are checked against
the independent MLF oracle at all manifest check sizes. The pinned fixtures are
also checked against those oracles. Each measured executable's warm-up and timed
run use the unchanged manifest default size and compare output
against the validated C implementation. Floating-point comparisons use the
existing 1e-8 tolerance; textual integer results compare tokens; byte workloads
compare complete file hashes. DNA inputs come from the pinned C FASTA program,
which is independently checked in the FASTA workload before they are used.

`results.json` starts with a non-success status and is only completed after all
correctness, source-integrity and performance checks. Each sample retains wall
and CPU time, RSS, process status, commands and build stages, alongside the
executables and output. The report records input and tool/source hashes. Sample
order alternates to reduce ordering bias. The required limits remain **5x C
compilation and 2x C runtime**; a failed limit exits nonzero.

The existing native C process and binary-file transports under `test/` supply
clocks, process isolation and raw bytes. Assertions and orchestration run in
MLF. GHC, Python and Cabal are not used.
