# Native self-compilation profiling

This diagnostic driver uses the production parser, module linker, class
translation, solver, elaborator, independent xMLF checker and LLVM backend.
`Force.emlf` traverses the complete result of each phase before recording its
end. The following `*-forced-again` checkpoint reports a traversal of the
already evaluated result. No serialization or additional graph validation is
used to force values. The final LLVM must match the ordinary compiler's output.

The diagnostic runtime intercepts only `MLF_PHASE` stderr markers. It records
monotonic wall time, cumulative BDWGC allocations and collection time, heap
size, collection count and process peak RSS. The production runtime is unchanged.
`max_rss` uses the host's `getrusage` units (bytes on macOS, KiB on Linux).

```sh
export MLF_GC_PREFIX="$PWD/dist-newstyle/bootstrap-deps/bdwgc-8.2.12-install"
tools/profile/build.sh /path/to/native/emlf "$PWD" "$PWD/.mlf-build/profile"
/usr/bin/time -l .mlf-build/profile/profile \
  "$PWD/bootstrap/Main.emlf" "$PWD/bootstrap" \
  > .mlf-build/profile/self.ll 2> .mlf-build/profile/phases.jsonl
/path/to/native/emlf -i bootstrap --emit-llvm-gc bootstrap/Main.emlf \
  > .mlf-build/profile/ordinary.ll
cmp .mlf-build/profile/self.ll .mlf-build/profile/ordinary.ll
```

Build the driver from both revisions, then profile the **same frozen input
source tree** to compare solver implementations. Run measured processes alone.
The driver has an explicit extra `recheck` phase to quantify the cost of checking
an already evaluated term. Its raw LLVM API also checks input, so diagnostic
wall time is not ordinary compiler wall time. Full forcing and longer-lived
intermediate results can change collection and evaluation order; compare fresh
ordinary compiler processes separately for the end-to-end result. A repeated
forcing checkpoint can trigger an IO-boundary collection; its time includes
that collection rather than representing traversal alone.

No GHC, Python, Cabal, or package download is used. The shell script only builds
and links the diagnostic executable using a supplied native MLF compiler,
Clang, GMP and BDWGC.

For native stack attribution, run `build-names.sh` with the same three arguments
after `build.sh`. It generates a diagnostic copy of the optimizer that retains
source display hints while allocating the same numeric identities. `Workers.emlf`
maps those identities to source names. `name-workers.awk` annotates worker symbols
in the original LLVM and retains internal function symbols for native sampling.
The source tree and driver must match the earlier profile build. Run from the
repository root. On macOS, `sample PID 60 10 -file solver.sample` captures stacks
for sixty seconds at ten-millisecond intervals. Start it at the
`unify-forced-again` checkpoint to inspect instantiation. Use this binary for
attribution only; use the ordinary compiler for performance measurements.
