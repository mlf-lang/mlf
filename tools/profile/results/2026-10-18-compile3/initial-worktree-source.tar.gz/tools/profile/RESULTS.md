# Native self-compilation profiling milestone — 2026-10-16

The compiler changes reuse a successful independent xMLF check and reduce
allocation while reconstructing solver graphs. The production runtime and
graph validation rules are unchanged. Measurements use an Apple M1 Max (32 GiB), macOS 26.6.2 ARM64,
Clang 23.1.3, GMP 6.3.0 and BDWGC 8.2.12. No GHC, Cabal, Python or subagents
were used. Node was used for file editing and report aggregation; the compiler,
test orchestration and benchmark runner execute as native MLF.

The measured solver allocation reduction is **2.9%**. Ordinary self-compilation
did **not** improve: its three-run median was **3.7% slower**. All native test
groups and all nine C-relative benchmark gates passed. This milestone establishes
safe check reuse and lower solver allocation, not an end-to-end speedup.

## Checked emission

`Bootstrap.X.Checked` exports an opaque `CheckedTerm`. Its private constructor
can only be reached through the independent xMLF checker. `Compilation` is
also opaque and stores that witness. Source compilation still verifies the
inferred type and source erasure; source and separate-module LLVM entry points
then reuse the witness. Raw/deserialized xMLF still goes through the checker,
and IO entry points still require an IO type. Separate-module object boundary
and graft checks remain in place.

Four new regression entries compare checked/raw LLVM in both layouts, reject
malformed external terms, enforce IO entry types and verify constructor privacy
through the real module loader.

## Solver allocation

`strictNode`, `strictGraph` and `strictScopes` force the same required fields
and return their existing immutable records. Previously they constructed new
wrappers for already existing records. `buildNodeTree` now forces each finished
map subtree before returning it, avoiding a deferred construction spine.

Three new regression entries compare graph construction against independent
insertion, check lazy unused fields and arbitrary-precision identities, and
compare graph expansion against an independent implementation.

A first split/join-map-union and batched-expansion experiment did not provide
convincing improvement and was reverted. The retained
[sample summary](results/2026-10-16/sample-summary.json) and
[compressed native stacks](results/2026-10-16/solver-named.sample.gz) come from
that experimental snapshot, whose
[patch](results/2026-10-16/reverted-union-experiment.patch) is retained for
provenance. They guided the subsequent allocation changes; they are not a
post-change performance measurement. Among 4,509 samples, the nearest graph
function was `solverUnify` in 17.2% and `buildNodeTree` in 14.5%; nearest source
functions included `IntMap.lookupTree` (10.8%) and `Map.balance` (9.5%).
These are sampled stack attributions, not exclusive function timings.

## Measurement boundaries

Both revisions compile the same frozen original compiler source from commit
`ff8362d6cd5678b062e68b105ba23890ef847e33`. The expected LLVM SHA-256 is
`b5866443a271d7d7a7463bdc65958aa9b0c28541be7600e1209051cd40f9eabc`.
The original native compiler SHA-256 is
`6f658807be3a2fb1955ee42284b4ba34a736f7927ac9964da9c3cd234cb41bc0`;
the final compiler is
`6a04cdf5fbd6e1f304fb3b2847e081e58b659594f8d722712b977758007fd0ce`.

The diagnostic driver forces each phase's complete result and explicitly
measures an extra recheck. Its raw LLVM API checks again. Its total therefore
must not be treated as ordinary compiler time. Full forcing and longer-lived
intermediates alter collection/evaluation order; repeated-force checkpoints
can include IO-boundary collection. Allocation totals count managed BDWGC
allocation, not every operating-system allocation. See the
[profiling instructions](README.md) and
[toolchain fingerprint](results/2026-10-16/toolchain-fingerprint.json).

Ordinary measurements use fresh compiler processes, alternate original/final
order and include complete source-to-LLVM emission. They exclude Clang
optimization and native linking. The full Benchmarks Game compilation gate
includes those later stages and uses the unchanged workload inputs.

## Diagnostic results

The final profiler emitted exactly the same LLVM as the original profiler.
The [phase archive](results/2026-10-16/phases.json) contains every checkpoint
and the frozen input hashes; raw
[original](results/2026-10-16/baseline-phases.jsonl) and
[final](results/2026-10-16/final-phases.jsonl) logs are retained.

| Diagnostic measurement | Original | Final |
| --- | ---: | ---: |
| Instantiation wall time | 67.850 s | 59.150 s |
| Instantiation managed allocation | 91.016 GB | 88.393 GB |
| Instantiation GC time | 33.206 s | 29.687 s |
| Final normalization wall time | 19.245 s | 17.647 s |
| LLVM phase wall time | 136.503 s | 106.468 s |
| Total managed allocation | 365.347 GB | 362.140 GB |
| Peak resident memory | 8.851 GB | 8.930 GB |

GB means decimal billions of bytes. Instantiation allocated **2.62 GB less
(2.9%)**, with **12.8% lower observed phase wall time**. These are single
diagnostic runs; wall-time differences also include GC and operating-system
variation. The ordinary paired runs are the basis for the end-to-end timing
comparison. Peak live/resident memory did not fall with cumulative allocation.

The deliberately retained repeat-check phase in the final profiler took
**1.605 s** and allocated **5.017 GB** on the already evaluated target. The
ordinary source and linked-module LLVM paths now reuse the successful check.
LLVM emission remains the largest diagnostic phase at **106.468 s**; it
includes optimization, code generation, output construction and the raw API's
independent target check.

## Ordinary self-compilation

The [ordinary-run archive](results/2026-10-16/ordinary.json) preserves all six
measurements, CPU time, peak RSS, commands and binary hashes. Each fresh process
compiled the same frozen original source, and every emitted LLVM file matched
the reference byte for byte. Runs were sequential, with no concurrent build or
test jobs; normal desktop background services were not disabled.

| Pair | Execution order | Original wall time | Final wall time |
| --- | --- | ---: | ---: |
| 1 | Original, final | 259.858 s | 264.285 s |
| 2 | Final, original | 270.033 s | 302.320 s |
| 3 | Original, final | 284.509 s | 279.942 s |
| Median | | **270.033 s** | **279.942 s** |

The final median is **9.908 s (3.7%) slower**. The paired changes vary from
1.6% faster to 12.0% slower; three pairs do not establish how much of the
difference comes from the changes versus GC and host variation. The single
diagnostic run's lower phase times cannot override this ordinary result.
Resident memory also did not consistently improve: original runs peaked at
9.679–11.181 GB and final runs at 9.799–10.887 GB.

Further speed work should first profile allocation and retained memory during
ordinary LLVM emission, the largest phase in the diagnostic run. Within the
solver, the sampled unification, graph-map construction and lookup paths remain
the next targets. Any further change needs the same frozen-input comparison;
less cumulative allocation alone is not enough to claim faster compilation.

## Benchmarks

All 18 limits pass across nine workloads, with seven samples per language.
Maximum compilation is n-body at **4.947x C**; maximum runtime is k-nucleotide
at **1.673x C**. N-body has only about 1% compilation margin. All 63 final
benchmark LLVM outputs match the original compiler byte for byte. The
[benchmark table](../../benchmarks/RESULTS.md) and
[raw report](../bench/results/2026-10-16-native-macos-arm64.json) preserve the
measurements, commands, tool/source hashes and correctness checks.

## Native validation

The full native package-manager test command passed all six groups. Every
group records the final compiler hash above and unchanged source hashes. The
[validation archive](results/2026-10-16/native-validation.json) retains those
reports and the package-manager build/test report.

- Unit: **643 checks**, including the seven new regression entries; an
  independent oracle over **6,712 closed terms**; **43 Figure 12** expectations
  and **36 supplementary checks**; **53 native harness tests**.
- Packages: **18 resolver tests** and **19 integration cases**.
- Self-host: a fresh next-stage build reproduced both LLVM and the native
  compiler executable byte for byte, without reusing the candidate build.
  The current-source LLVM fixed-point hash is
  `e6f08662f59e2b4468373bf3c75cb82585f5323a2531fd7fa3ee10639b1adff9`.
  This differs from the frozen-original-source hash used for timing above.
- Parity: **7,086 cases**, with **3,202 accepted**, **3,884 rejected**, and
  **80 runtime cases executed on both backends**.
- Backends: **546 rows × 2 backends in each of two layouts**, standard and
  compact GC; **494 shared fixtures per layout**, with no failures or missing
  executions.
- Compiler port: **26 rows × 2 backends in each layout**, including independent
  graph/inference references, solver validation reuse, state typing and
  primitive metadata; no failures or missing executions.

The test command used the native `mlfpkg` executable via `MLF_PACKAGE_MANAGER`:

```sh
export MLF_PACKAGE_MANAGER="$PWD/.mlf-build/self-profile/candidate/bin/mlfpkg"
export MLF_GC_PREFIX="$PWD/dist-newstyle/bootstrap-deps/bdwgc-8.2.12-install"
export PATH="$PWD/.mlf-build/self-profile/blocked:$PATH"
./mlfpkg --locked \
  --compiler "$PWD/.mlf-build/self-profile/candidate-v2/bin/emlf" \
  --build-dir "$PWD/.mlf-build/self-profile/candidate-v3" \
  --timeout 21600 test
```

The seed supplied to package building was the preceding native compiler;
every test group used the final compiler in `candidate-v3/bin/emlf`. Failing
PATH wrappers guarded GHC, Cabal and Python commands; their invocation log
remained absent. The port group includes long interpreted compiler and graph
fixtures, which account for most of the verification time.
