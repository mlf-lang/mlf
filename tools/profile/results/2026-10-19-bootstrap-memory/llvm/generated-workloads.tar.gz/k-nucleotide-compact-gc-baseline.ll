; Generated from independently checked xMLF.
source_filename = "emlf"

declare ptr @mlf_thunk_new(ptr, i64)
declare ptr @mlf_execute_st_lazy(ptr)
declare ptr @mlf_st_new_array(ptr, ptr)
declare ptr @mlf_st_read_array(ptr, ptr)
declare ptr @mlf_st_write_array(ptr, ptr, ptr)
declare ptr @mlf_st_length_array(ptr)
declare void @mlf_set_args(i32, ptr)
declare ptr @mlf_env_new(i64)
declare void @mlf_env_set(ptr, i64, ptr)
declare ptr @mlf_env_get(ptr, i64)
declare ptr @mlf_thunk(ptr, ptr)
declare ptr @mlf_closure(ptr, ptr)
declare ptr @mlf_application(ptr, ptr)
declare ptr @mlf_hole()
declare void @mlf_fill(ptr, ptr)
declare ptr @mlf_integer(ptr)
declare ptr @mlf_string(ptr, i64)
declare ptr @mlf_double(double)
declare double @llvm.sqrt.f64(double)
declare double @mlf_int_to_double(ptr)
declare ptr @mlf_read_int_table(ptr, ptr)
declare ptr @mlf_write_int_table(ptr, ptr, ptr)
declare ptr @mlf_add_int_table(ptr, ptr, ptr)
declare void @mlf_roots_enter(ptr, i64, ptr)
declare void @mlf_roots_leave(ptr)
declare void @mlf_gc_check(i64, ptr)
declare ptr @mlf_get_byte_line()
declare ptr @mlf_new_array(i64, ptr, ptr)
declare ptr @mlf_bytes_from_string(ptr)
declare ptr @mlf_put_bytes(ptr, ptr, ptr)
declare ptr @mlf_new_int_table()
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare i8 @mlf_byte(ptr)
declare ptr @mlf_peek(ptr)
declare ptr @mlf_native_io(ptr, ptr)
declare void @mlf_bounds_failure() noreturn
declare ptr @mlf_primitive(i64)
declare ptr @mlf_prim1(i64, ptr)
declare ptr @mlf_prim2(i64, ptr, ptr)
declare i64 @mlf_truth(ptr)
declare ptr @mlf_prim3(i64, ptr, ptr, ptr)
declare ptr @mlf_force(ptr)
declare ptr @mlf_add_int(ptr, ptr)
declare ptr @mlf_sub_int(ptr, ptr)
declare ptr @mlf_eq_int(ptr, ptr)
declare ptr @mlf_lt_int(ptr, ptr)
declare ptr @mlf_constructor(i64, i64)
declare ptr @mlf_constructor1(i64, ptr)
declare ptr @mlf_constructor2(i64, ptr, ptr)
declare ptr @mlf_constructor_fields(i64, ptr)
declare ptr @mlf_constructor_new(i64, i64)
declare ptr @mlf_field(ptr, i64)
declare void @mlf_match_failure() noreturn
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare i32 @mlf_run(ptr, i64)

@mlf_constructor_pending = external global [33 x ptr]
declare ptr @mlf_constructor_allocate(i64, i64)
define private ptr @mlf.allocate.constructor(i64 %identity, i64 %count, i64 %size) alwaysinline {
entry:
  %small = icmp ule i64 %size, 256
  br i1 %small, label %batch, label %slow
batch:
  %index = lshr i64 %size, 3
  %slot = getelementptr [33 x ptr], ptr @mlf_constructor_pending, i64 0, i64 %index
  %value = load ptr, ptr %slot, align 8
  %empty = icmp eq ptr %value, null
  br i1 %empty, label %slow, label %ready
ready:
  %next = load ptr, ptr %value, align 8
  store ptr %next, ptr %slot, align 8
  store i64 0, ptr %value, align 8
  ret ptr %value
slow:
  %allocated = call ptr @mlf_constructor_allocate(i64 %identity, i64 %count)
  ret ptr %allocated
}
define private ptr @mlf.construct.1(i64 %identity, ptr %a) alwaysinline {
entry:
  %value = call ptr @mlf.allocate.constructor(i64 %identity, i64 1, i64 24)
  store i32 12, ptr %value, align 4
  %id = getelementptr i8, ptr %value, i64 8
  store i64 %identity, ptr %id, align 8
  %first = getelementptr i8, ptr %value, i64 16
  store ptr %a, ptr %first, align 8
  ret ptr %value
}
define private ptr @mlf.construct.2(i64 %identity, ptr %a, ptr %b) alwaysinline {
entry:
  %value = call ptr @mlf.allocate.constructor(i64 %identity, i64 2, i64 32)
  store i32 13, ptr %value, align 4
  %id = getelementptr i8, ptr %value, i64 8
  store i64 %identity, ptr %id, align 8
  %first = getelementptr i8, ptr %value, i64 16
  store ptr %a, ptr %first, align 8
  %second = getelementptr i8, ptr %value, i64 24
  store ptr %b, ptr %second, align 8
  ret ptr %value
}
define private ptr @mlf.construct.wide(i64 %identity, i64 %count) alwaysinline {
entry:
  %fields = mul i64 %count, 8
  %size = add i64 %fields, 24
  %value = call ptr @mlf.allocate.constructor(i64 %identity, i64 %count, i64 %size)
  store i32 28, ptr %value, align 4
  %id = getelementptr i8, ptr %value, i64 8
  store i64 %identity, ptr %id, align 8
  %arity = getelementptr i8, ptr %value, i64 16
  store i64 %count, ptr %arity, align 8
  ret ptr %value
}
@mlf_compact_pending = external global [17 x ptr]
define private ptr @mlf.allocate.thunk(ptr %code, i64 %count) alwaysinline {
entry:
  %words = add i64 %count, 4
  %index = lshr i64 %words, 1
  %slot = getelementptr [17 x ptr], ptr @mlf_compact_pending, i64 0, i64 %index
  %value = load ptr, ptr %slot, align 8
  %empty = icmp eq ptr %value, null
  br i1 %empty, label %slow, label %ready
ready:
  %next = load ptr, ptr %value, align 8
  store ptr %next, ptr %slot, align 8
  store i64 3, ptr %value, align 8
  %function = getelementptr i8, ptr %value, i64 8
  store ptr %code, ptr %function, align 8
  %environment = getelementptr i8, ptr %value, i64 24
  %capture = getelementptr i8, ptr %value, i64 16
  store ptr %environment, ptr %capture, align 8
  store i64 %count, ptr %environment, align 8
  ret ptr %value
slow:
  %allocated = call ptr @mlf_thunk_new(ptr %code, i64 %count)
  ret ptr %allocated
}
define private ptr @mlf.force(ptr %value) alwaysinline {
entry:
  %null = icmp eq ptr %value, null
  br i1 %null, label %slow, label %test
test:
  %bits = ptrtoint ptr %value to i64
  %kind = and i64 %bits, 7
  %immediate = icmp ne i64 %kind, 0
  br i1 %immediate, label %done, label %tagged
tagged:
  %tag = load i32, ptr %value, align 4
  %ready = icmp uge i32 %tag, 5
  br i1 %ready, label %done, label %deferred
deferred:
  %isthunk = icmp eq i32 %tag, 3
  br i1 %isthunk, label %enter, label %indirect
indirect:
  %forwarded = icmp eq i32 %tag, 2
  br i1 %forwarded, label %next, label %slow
next:
  %slot = getelementptr i8, ptr %value, i64 8
  %p = load ptr, ptr %slot, align 8
  %missing = icmp eq ptr %p, null
  br i1 %missing, label %slow, label %nexttest
nexttest:
  %pbits = ptrtoint ptr %p to i64
  %pkind = and i64 %pbits, 7
  %pimm = icmp ne i64 %pkind, 0
  br i1 %pimm, label %forward, label %ptagged
ptagged:
  %ptag = load i32, ptr %p, align 4
  %pready = icmp uge i32 %ptag, 5
  br i1 %pready, label %forward, label %slow
forward:
  ret ptr %p
done:
  ret ptr %value
enter:
  %code.slot = getelementptr i8, ptr %value, i64 8
  %env.slot = getelementptr i8, ptr %value, i64 16
  %code = load ptr, ptr %code.slot, align 8
  %env = load ptr, ptr %env.slot, align 8
  store i32 1, ptr %value, align 4
  store ptr null, ptr %code.slot, align 8
  store ptr null, ptr %env.slot, align 8
  %returned = call ptr %code(ptr %env, ptr null)
  %canonical = call ptr @mlf_force(ptr %returned)
  store i32 2, ptr %value, align 4
  store ptr %canonical, ptr %code.slot, align 8
  ret ptr %canonical
slow:
  %result = tail call ptr @mlf_force(ptr %value)
  ret ptr %result
}
!0 = !{!"MLF storage"}
!1 = !{!"managed object", !0}
!2 = !{!"array cells", !0}
!3 = !{!1, !1, i64 0}
!4 = !{!2, !2, i64 0}
@mlf.bytes.3059 = private unnamed_addr constant [1 x i8] c"\00", align 1
@mlf.bytes.3059.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 0, ptr @mlf.bytes.3059, ptr null }, align 8
@mlf.bytes.3310 = private unnamed_addr constant [1 x i8] c"\00", align 1
@mlf.bytes.3310.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 0, ptr @mlf.bytes.3310, ptr null }, align 8
@mlf.bytes.3439 = private unnamed_addr constant [2 x i8] c"\41\00", align 1
@mlf.bytes.3439.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 1, ptr @mlf.bytes.3439, ptr null }, align 8
@mlf.bytes.3456 = private unnamed_addr constant [2 x i8] c"\43\00", align 1
@mlf.bytes.3456.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 1, ptr @mlf.bytes.3456, ptr null }, align 8
@mlf.bytes.3473 = private unnamed_addr constant [2 x i8] c"\47\00", align 1
@mlf.bytes.3473.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 1, ptr @mlf.bytes.3473, ptr null }, align 8
@mlf.bytes.3474 = private unnamed_addr constant [2 x i8] c"\54\00", align 1
@mlf.bytes.3474.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 1, ptr @mlf.bytes.3474, ptr null }, align 8
@mlf.bytes.3539 = private unnamed_addr constant [2 x i8] c"\20\00", align 1
@mlf.bytes.3539.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 1, ptr @mlf.bytes.3539, ptr null }, align 8
@mlf.bytes.4175 = private unnamed_addr constant [2 x i8] c"\09\00", align 1
@mlf.bytes.4175.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 1, ptr @mlf.bytes.4175, ptr null }, align 8
@mlf.bytes.4214 = private unnamed_addr constant [4 x i8] c"\47\47\54\00", align 1
@mlf.bytes.4214.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 3, ptr @mlf.bytes.4214, ptr null }, align 8
@mlf.bytes.4233 = private unnamed_addr constant [5 x i8] c"\47\47\54\41\00", align 1
@mlf.bytes.4233.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 4, ptr @mlf.bytes.4233, ptr null }, align 8
@mlf.bytes.4252 = private unnamed_addr constant [7 x i8] c"\47\47\54\41\54\54\00", align 1
@mlf.bytes.4252.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 6, ptr @mlf.bytes.4252, ptr null }, align 8
@mlf.bytes.4271 = private unnamed_addr constant [13 x i8] c"\47\47\54\41\54\54\54\54\41\41\54\54\00", align 1
@mlf.bytes.4271.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 12, ptr @mlf.bytes.4271, ptr null }, align 8
@mlf.bytes.4283 = private unnamed_addr constant [19 x i8] c"\47\47\54\41\54\54\54\54\41\41\54\54\54\41\54\41\47\54\00", align 1
@mlf.bytes.4283.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 18, ptr @mlf.bytes.4283, ptr null }, align 8
define private ptr @mlf.numeric.25(ptr %a0) {
entry:
  %v11 = alloca [1 x ptr], align 8
  %v12 = getelementptr ptr, ptr %v11, i64 0
  store ptr %a0, ptr %v12, align 8
  call void @mlf_gc_check(i64 1, ptr %v11)
  %v13 = call ptr @mlf_get_byte_line()
  %v14 = getelementptr i8, ptr %v13, i64 8
  %v15 = load i64, ptr %v14, align 8, !tbaa !3
  %v16 = getelementptr i8, ptr %v13, i64 16
  %v17 = load ptr, ptr %v16, align 8, !tbaa !3
  %v18 = shl i64 %v15, 1
  %v19 = or i64 %v18, 1
  %v20 = inttoptr i64 %v19 to ptr
  %v21 = ptrtoint ptr %v20 to i64
  %v22 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v23 = and i64 %v21, %v22
  %v24 = and i64 %v23, 1
  %v25 = icmp ne i64 %v24, 0
  br i1 %v25, label %yes.26, label %no.27
yes.26:
  %v29 = icmp eq i64 %v21, %v22
  %v30 = select i1 %v29, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.28
no.27:
  %v31 = call ptr @mlf_eq_int(ptr %v20, ptr inttoptr (i64 1 to ptr))
  br label %join.28
join.28:
  %v32 = phi ptr [ %v30, %yes.26 ], [ %v31, %no.27 ]
  %v33 = icmp eq ptr %v32, inttoptr (i64 6 to ptr)
  br i1 %v33, label %tail.yes.34, label %tail.no.35
tail.yes.34:
  ret ptr inttoptr (i64 4 to ptr)
tail.no.35:
  %v36 = ptrtoint ptr %v20 to i64
  %v37 = ptrtoint ptr inttoptr (i64 13 to ptr) to i64
  %v38 = and i64 %v36, %v37
  %v39 = and i64 %v38, 1
  %v40 = icmp ne i64 %v39, 0
  br i1 %v40, label %yes.41, label %no.42
yes.41:
  %v44 = icmp slt i64 %v36, %v37
  %v45 = select i1 %v44, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.43
no.42:
  %v46 = call ptr @mlf_lt_int(ptr %v20, ptr inttoptr (i64 13 to ptr))
  br label %join.43
join.43:
  %v47 = phi ptr [ %v45, %yes.41 ], [ %v46, %no.42 ]
  %v48 = icmp eq ptr %v47, inttoptr (i64 6 to ptr)
  br i1 %v48, label %yes.49, label %no.50
yes.49:
  br label %join.51
no.50:
  %v52 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v53 = ashr i64 %v52, 1
  %v54 = and i64 %v52, 1
  %v55 = icmp ne i64 %v54, 0
  %v56 = icmp ult i64 %v53, %v15
  %v57 = and i1 %v55, %v56
  br i1 %v57, label %array.valid.58, label %array.invalid.59
array.invalid.59:
  call void @mlf_bounds_failure()
  unreachable
array.valid.58:
  %v60 = getelementptr i8, ptr %v17, i64 %v53
  %v61 = load i8, ptr %v60, align 1, !tbaa !4
  %v62 = zext i8 %v61 to i64
  %v63 = shl i64 %v62, 1
  %v64 = or i64 %v63, 1
  %v65 = inttoptr i64 %v64 to ptr
  %v66 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v67 = ashr i64 %v66, 1
  %v68 = and i64 %v66, 1
  %v69 = icmp ne i64 %v68, 0
  %v70 = icmp ult i64 %v67, %v15
  %v71 = and i1 %v69, %v70
  br i1 %v71, label %array.valid.72, label %array.invalid.73
array.invalid.73:
  call void @mlf_bounds_failure()
  unreachable
array.valid.72:
  %v74 = getelementptr i8, ptr %v17, i64 %v67
  %v75 = load i8, ptr %v74, align 1, !tbaa !4
  %v76 = zext i8 %v75 to i64
  %v77 = shl i64 %v76, 1
  %v78 = or i64 %v77, 1
  %v79 = inttoptr i64 %v78 to ptr
  %v80 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v81 = ashr i64 %v80, 1
  %v82 = and i64 %v80, 1
  %v83 = icmp ne i64 %v82, 0
  %v84 = icmp ult i64 %v81, %v15
  %v85 = and i1 %v83, %v84
  br i1 %v85, label %array.valid.86, label %array.invalid.87
array.invalid.87:
  call void @mlf_bounds_failure()
  unreachable
array.valid.86:
  %v88 = getelementptr i8, ptr %v17, i64 %v81
  %v89 = load i8, ptr %v88, align 1, !tbaa !4
  %v90 = zext i8 %v89 to i64
  %v91 = shl i64 %v90, 1
  %v92 = or i64 %v91, 1
  %v93 = inttoptr i64 %v92 to ptr
  %v94 = ptrtoint ptr inttoptr (i64 7 to ptr) to i64
  %v95 = ashr i64 %v94, 1
  %v96 = and i64 %v94, 1
  %v97 = icmp ne i64 %v96, 0
  %v98 = icmp ult i64 %v95, %v15
  %v99 = and i1 %v97, %v98
  br i1 %v99, label %array.valid.100, label %array.invalid.101
array.invalid.101:
  call void @mlf_bounds_failure()
  unreachable
array.valid.100:
  %v102 = getelementptr i8, ptr %v17, i64 %v95
  %v103 = load i8, ptr %v102, align 1, !tbaa !4
  %v104 = zext i8 %v103 to i64
  %v105 = shl i64 %v104, 1
  %v106 = or i64 %v105, 1
  %v107 = inttoptr i64 %v106 to ptr
  %v108 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v109 = ashr i64 %v108, 1
  %v110 = and i64 %v108, 1
  %v111 = icmp ne i64 %v110, 0
  %v112 = icmp ult i64 %v109, %v15
  %v113 = and i1 %v111, %v112
  br i1 %v113, label %array.valid.114, label %array.invalid.115
array.invalid.115:
  call void @mlf_bounds_failure()
  unreachable
array.valid.114:
  %v116 = getelementptr i8, ptr %v17, i64 %v109
  %v117 = load i8, ptr %v116, align 1, !tbaa !4
  %v118 = zext i8 %v117 to i64
  %v119 = shl i64 %v118, 1
  %v120 = or i64 %v119, 1
  %v121 = inttoptr i64 %v120 to ptr
  %v122 = ptrtoint ptr inttoptr (i64 11 to ptr) to i64
  %v123 = ashr i64 %v122, 1
  %v124 = and i64 %v122, 1
  %v125 = icmp ne i64 %v124, 0
  %v126 = icmp ult i64 %v123, %v15
  %v127 = and i1 %v125, %v126
  br i1 %v127, label %array.valid.128, label %array.invalid.129
array.invalid.129:
  call void @mlf_bounds_failure()
  unreachable
array.valid.128:
  %v130 = getelementptr i8, ptr %v17, i64 %v123
  %v131 = load i8, ptr %v130, align 1, !tbaa !4
  %v132 = zext i8 %v131 to i64
  %v133 = shl i64 %v132, 1
  %v134 = or i64 %v133, 1
  %v135 = inttoptr i64 %v134 to ptr
  %v136 = ptrtoint ptr %v65 to i64
  %v137 = ptrtoint ptr inttoptr (i64 125 to ptr) to i64
  %v138 = icmp eq i64 %v136, %v137
  %v139 = select i1 %v138, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v140 = icmp eq ptr %v139, inttoptr (i64 6 to ptr)
  br i1 %v140, label %yes.141, label %no.142
yes.141:
  %v144 = ptrtoint ptr %v79 to i64
  %v145 = ptrtoint ptr inttoptr (i64 169 to ptr) to i64
  %v146 = icmp eq i64 %v144, %v145
  %v147 = select i1 %v146, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v148 = icmp eq ptr %v147, inttoptr (i64 6 to ptr)
  br i1 %v148, label %yes.149, label %no.150
yes.149:
  %v152 = ptrtoint ptr %v93 to i64
  %v153 = ptrtoint ptr inttoptr (i64 145 to ptr) to i64
  %v154 = icmp eq i64 %v152, %v153
  %v155 = select i1 %v154, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v156 = icmp eq ptr %v155, inttoptr (i64 6 to ptr)
  br i1 %v156, label %yes.157, label %no.158
yes.157:
  %v160 = ptrtoint ptr %v107 to i64
  %v161 = ptrtoint ptr inttoptr (i64 165 to ptr) to i64
  %v162 = icmp eq i64 %v160, %v161
  %v163 = select i1 %v162, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v164 = icmp eq ptr %v163, inttoptr (i64 6 to ptr)
  br i1 %v164, label %yes.165, label %no.166
yes.165:
  %v168 = ptrtoint ptr %v121 to i64
  %v169 = ptrtoint ptr inttoptr (i64 139 to ptr) to i64
  %v170 = icmp eq i64 %v168, %v169
  %v171 = select i1 %v170, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v172 = icmp eq ptr %v171, inttoptr (i64 6 to ptr)
  br i1 %v172, label %yes.173, label %no.174
yes.173:
  %v176 = ptrtoint ptr %v135 to i64
  %v177 = ptrtoint ptr inttoptr (i64 139 to ptr) to i64
  %v178 = icmp eq i64 %v176, %v177
  %v179 = select i1 %v178, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.175
no.174:
  br label %join.175
join.175:
  %v180 = phi ptr [ %v179, %yes.173 ], [ inttoptr (i64 2 to ptr), %no.174 ]
  br label %join.167
no.166:
  br label %join.167
join.167:
  %v181 = phi ptr [ %v180, %join.175 ], [ inttoptr (i64 2 to ptr), %no.166 ]
  br label %join.159
no.158:
  br label %join.159
join.159:
  %v182 = phi ptr [ %v181, %join.167 ], [ inttoptr (i64 2 to ptr), %no.158 ]
  br label %join.151
no.150:
  br label %join.151
join.151:
  %v183 = phi ptr [ %v182, %join.159 ], [ inttoptr (i64 2 to ptr), %no.150 ]
  br label %join.143
no.142:
  br label %join.143
join.143:
  %v184 = phi ptr [ %v183, %join.151 ], [ inttoptr (i64 2 to ptr), %no.142 ]
  %v185 = icmp eq ptr %v184, inttoptr (i64 6 to ptr)
  br i1 %v185, label %yes.186, label %no.187
yes.186:
  %v189 = ptrtoint ptr %v20 to i64
  %v190 = ptrtoint ptr inttoptr (i64 13 to ptr) to i64
  %v191 = and i64 %v189, %v190
  %v192 = and i64 %v191, 1
  %v193 = icmp ne i64 %v192, 0
  br i1 %v193, label %yes.194, label %no.195
yes.194:
  %v197 = icmp eq i64 %v189, %v190
  %v198 = select i1 %v197, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.196
no.195:
  %v199 = call ptr @mlf_eq_int(ptr %v20, ptr inttoptr (i64 13 to ptr))
  br label %join.196
join.196:
  %v200 = phi ptr [ %v198, %yes.194 ], [ %v199, %no.195 ]
  %v201 = icmp eq ptr %v200, inttoptr (i64 6 to ptr)
  br i1 %v201, label %yes.202, label %no.203
yes.202:
  br label %join.204
no.203:
  %v205 = ptrtoint ptr inttoptr (i64 13 to ptr) to i64
  %v206 = ashr i64 %v205, 1
  %v207 = and i64 %v205, 1
  %v208 = icmp ne i64 %v207, 0
  %v209 = icmp ult i64 %v206, %v15
  %v210 = and i1 %v208, %v209
  br i1 %v210, label %array.valid.211, label %array.invalid.212
array.invalid.212:
  call void @mlf_bounds_failure()
  unreachable
array.valid.211:
  %v213 = getelementptr i8, ptr %v17, i64 %v206
  %v214 = load i8, ptr %v213, align 1, !tbaa !4
  %v215 = zext i8 %v214 to i64
  %v216 = shl i64 %v215, 1
  %v217 = or i64 %v216, 1
  %v218 = inttoptr i64 %v217 to ptr
  %v219 = ptrtoint ptr %v218 to i64
  %v220 = ptrtoint ptr inttoptr (i64 65 to ptr) to i64
  %v221 = icmp eq i64 %v219, %v220
  %v222 = select i1 %v221, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v223 = icmp eq ptr %v222, inttoptr (i64 6 to ptr)
  br i1 %v223, label %yes.224, label %no.225
yes.224:
  br label %join.226
no.225:
  %v227 = ptrtoint ptr %v218 to i64
  %v228 = ptrtoint ptr inttoptr (i64 19 to ptr) to i64
  %v229 = icmp eq i64 %v227, %v228
  %v230 = select i1 %v229, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v231 = icmp eq ptr %v230, inttoptr (i64 6 to ptr)
  br i1 %v231, label %yes.232, label %no.233
yes.232:
  br label %join.234
no.233:
  %v235 = ptrtoint ptr %v218 to i64
  %v236 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v237 = icmp eq i64 %v235, %v236
  %v238 = select i1 %v237, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v239 = icmp eq ptr %v238, inttoptr (i64 6 to ptr)
  br i1 %v239, label %yes.240, label %no.241
yes.240:
  br label %join.242
no.241:
  %v243 = ptrtoint ptr %v218 to i64
  %v244 = ptrtoint ptr inttoptr (i64 27 to ptr) to i64
  %v245 = icmp eq i64 %v243, %v244
  %v246 = select i1 %v245, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.242
join.242:
  %v247 = phi ptr [ inttoptr (i64 6 to ptr), %yes.240 ], [ %v246, %no.241 ]
  br label %join.234
join.234:
  %v248 = phi ptr [ inttoptr (i64 6 to ptr), %yes.232 ], [ %v247, %join.242 ]
  br label %join.226
join.226:
  %v249 = phi ptr [ inttoptr (i64 6 to ptr), %yes.224 ], [ %v248, %join.234 ]
  br label %join.204
join.204:
  %v250 = phi ptr [ inttoptr (i64 6 to ptr), %yes.202 ], [ %v249, %join.226 ]
  br label %join.188
no.187:
  br label %join.188
join.188:
  %v251 = phi ptr [ %v250, %join.204 ], [ inttoptr (i64 2 to ptr), %no.187 ]
  br label %join.51
join.51:
  %v252 = phi ptr [ inttoptr (i64 2 to ptr), %yes.49 ], [ %v251, %join.188 ]
  %v253 = icmp eq ptr %v252, inttoptr (i64 6 to ptr)
  br i1 %v253, label %tail.yes.254, label %tail.no.255
tail.yes.254:
  ret ptr inttoptr (i64 4 to ptr)
tail.no.255:
  %v256 = musttail call ptr @mlf.numeric.25(ptr inttoptr (i64 4 to ptr))
  ret ptr %v256
}

define private ptr @mlf.code.261(ptr %env, ptr %arg) {
entry:
  %v262 = getelementptr i8, ptr %env, i64 8
  %v263 = load ptr, ptr %v262, align 8, !tbaa !3
  %v264 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v264, align 8, !tbaa !3
  %v265 = call ptr @mlf_prim1(i64 38, ptr %v263)
  ret ptr %v265
}

define private ptr @mlf.code.294(ptr %env, ptr %arg) {
entry:
  %v295 = getelementptr i8, ptr %env, i64 8
  %v296 = load ptr, ptr %v295, align 8, !tbaa !3
  %v297 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v297, align 8, !tbaa !3
  %v298 = call ptr @mlf_prim2(i64 36, ptr %v296, ptr inttoptr (i64 1 to ptr))
  ret ptr %v298
}

define private ptr @mlf.code.308(ptr %env, ptr %arg) {
entry:
  %v309 = getelementptr i8, ptr %env, i64 8
  %v310 = load ptr, ptr %v309, align 8, !tbaa !3
  %v311 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v311, align 8, !tbaa !3
  %v312 = call ptr @mlf_prim2(i64 36, ptr %v310, ptr inttoptr (i64 3 to ptr))
  ret ptr %v312
}

define private ptr @mlf.code.324(ptr %env, ptr %arg) {
entry:
  %v325 = getelementptr i8, ptr %env, i64 8
  %v326 = load ptr, ptr %v325, align 8, !tbaa !3
  %v327 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v327, align 8, !tbaa !3
  %v328 = call ptr @mlf_prim2(i64 36, ptr %v326, ptr inttoptr (i64 5 to ptr))
  ret ptr %v328
}

define private ptr @mlf.code.342(ptr %env, ptr %arg) {
entry:
  %v343 = getelementptr i8, ptr %env, i64 8
  %v344 = load ptr, ptr %v343, align 8, !tbaa !3
  %v345 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v345, align 8, !tbaa !3
  %v346 = call ptr @mlf_prim2(i64 36, ptr %v344, ptr inttoptr (i64 7 to ptr))
  ret ptr %v346
}

define private ptr @mlf.code.362(ptr %env, ptr %arg) {
entry:
  %v363 = getelementptr i8, ptr %env, i64 8
  %v364 = load ptr, ptr %v363, align 8, !tbaa !3
  %v365 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v365, align 8, !tbaa !3
  %v366 = call ptr @mlf_prim2(i64 36, ptr %v364, ptr inttoptr (i64 9 to ptr))
  ret ptr %v366
}

define private ptr @mlf.code.384(ptr %env, ptr %arg) {
entry:
  %v385 = getelementptr i8, ptr %env, i64 8
  %v386 = load ptr, ptr %v385, align 8, !tbaa !3
  %v387 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v387, align 8, !tbaa !3
  %v388 = call ptr @mlf_prim2(i64 36, ptr %v386, ptr inttoptr (i64 11 to ptr))
  ret ptr %v388
}

define private ptr @mlf.code.456(ptr %env, ptr %arg) {
entry:
  %v457 = getelementptr i8, ptr %env, i64 8
  %v458 = load ptr, ptr %v457, align 8, !tbaa !3
  %v459 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v459, align 8, !tbaa !3
  %v460 = call ptr @mlf_prim2(i64 36, ptr %v458, ptr inttoptr (i64 13 to ptr))
  ret ptr %v460
}

define private ptr @mlf.code.466(ptr %env, ptr %arg) {
entry:
  %v467 = getelementptr i8, ptr %env, i64 8
  %v468 = load ptr, ptr %v467, align 8, !tbaa !3
  %v469 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v469, align 8, !tbaa !3
  %v470 = call ptr @mlf.force(ptr %v468)
  %v471 = call ptr @mlf_prim2(i64 10, ptr %v470, ptr inttoptr (i64 65 to ptr))
  %v472 = icmp eq ptr %v471, inttoptr (i64 6 to ptr)
  br i1 %v472, label %yes.473, label %no.474
yes.473:
  br label %join.475
no.474:
  %v476 = call ptr @mlf_prim2(i64 10, ptr %v470, ptr inttoptr (i64 19 to ptr))
  %v477 = icmp eq ptr %v476, inttoptr (i64 6 to ptr)
  br i1 %v477, label %yes.478, label %no.479
yes.478:
  br label %join.480
no.479:
  %v481 = call ptr @mlf_prim2(i64 10, ptr %v470, ptr inttoptr (i64 21 to ptr))
  %v482 = icmp eq ptr %v481, inttoptr (i64 6 to ptr)
  br i1 %v482, label %yes.483, label %no.484
yes.483:
  br label %join.485
no.484:
  %v486 = call ptr @mlf_prim2(i64 10, ptr %v470, ptr inttoptr (i64 27 to ptr))
  br label %join.485
join.485:
  %v487 = phi ptr [ inttoptr (i64 6 to ptr), %yes.483 ], [ %v486, %no.484 ]
  br label %join.480
join.480:
  %v488 = phi ptr [ inttoptr (i64 6 to ptr), %yes.478 ], [ %v487, %join.485 ]
  br label %join.475
join.475:
  %v489 = phi ptr [ inttoptr (i64 6 to ptr), %yes.473 ], [ %v488, %join.480 ]
  ret ptr %v489
}

define private ptr @mlf.code.465(ptr %env, ptr %arg) {
entry:
  %v490 = call ptr @mlf.allocate.thunk(ptr @mlf.code.466, i64 1)
  %v491 = getelementptr i8, ptr %v490, i64 16
  %v492 = load ptr, ptr %v491, align 8, !tbaa !3
  %v493 = getelementptr i8, ptr %v492, i64 8
  store ptr %arg, ptr %v493, align 8, !tbaa !3
  %v494 = call ptr @mlf_prim1(i64 0, ptr %v490)
  ret ptr %v494
}

define private ptr @mlf.code.393(ptr %env, ptr %arg) {
entry:
  %v394 = getelementptr i8, ptr %env, i64 8
  %v395 = load ptr, ptr %v394, align 8, !tbaa !3
  %v396 = getelementptr i8, ptr %env, i64 16
  %v397 = load ptr, ptr %v396, align 8, !tbaa !3
  %v398 = getelementptr i8, ptr %env, i64 24
  %v399 = load ptr, ptr %v398, align 8, !tbaa !3
  %v400 = getelementptr i8, ptr %env, i64 32
  %v401 = load ptr, ptr %v400, align 8, !tbaa !3
  %v402 = getelementptr i8, ptr %env, i64 40
  %v403 = load ptr, ptr %v402, align 8, !tbaa !3
  %v404 = getelementptr i8, ptr %env, i64 48
  %v405 = load ptr, ptr %v404, align 8, !tbaa !3
  %v406 = getelementptr i8, ptr %env, i64 56
  %v407 = load ptr, ptr %v406, align 8, !tbaa !3
  %v408 = call ptr @mlf.force(ptr %v399)
  %v409 = call ptr @mlf_prim2(i64 10, ptr %v408, ptr inttoptr (i64 125 to ptr))
  %v410 = icmp eq ptr %v409, inttoptr (i64 6 to ptr)
  br i1 %v410, label %yes.411, label %no.412
yes.411:
  %v414 = call ptr @mlf.force(ptr %v401)
  %v415 = call ptr @mlf_prim2(i64 10, ptr %v414, ptr inttoptr (i64 169 to ptr))
  %v416 = icmp eq ptr %v415, inttoptr (i64 6 to ptr)
  br i1 %v416, label %yes.417, label %no.418
yes.417:
  %v420 = call ptr @mlf.force(ptr %v403)
  %v421 = call ptr @mlf_prim2(i64 10, ptr %v420, ptr inttoptr (i64 145 to ptr))
  %v422 = icmp eq ptr %v421, inttoptr (i64 6 to ptr)
  br i1 %v422, label %yes.423, label %no.424
yes.423:
  %v426 = call ptr @mlf.force(ptr %v405)
  %v427 = call ptr @mlf_prim2(i64 10, ptr %v426, ptr inttoptr (i64 165 to ptr))
  %v428 = icmp eq ptr %v427, inttoptr (i64 6 to ptr)
  br i1 %v428, label %yes.429, label %no.430
yes.429:
  %v432 = call ptr @mlf.force(ptr %v407)
  %v433 = call ptr @mlf_prim2(i64 10, ptr %v432, ptr inttoptr (i64 139 to ptr))
  %v434 = icmp eq ptr %v433, inttoptr (i64 6 to ptr)
  br i1 %v434, label %yes.435, label %no.436
yes.435:
  %v438 = call ptr @mlf.force(ptr %arg)
  %v439 = call ptr @mlf_prim2(i64 10, ptr %v438, ptr inttoptr (i64 139 to ptr))
  br label %join.437
no.436:
  br label %join.437
join.437:
  %v440 = phi ptr [ %v439, %yes.435 ], [ inttoptr (i64 2 to ptr), %no.436 ]
  br label %join.431
no.430:
  br label %join.431
join.431:
  %v441 = phi ptr [ %v440, %join.437 ], [ inttoptr (i64 2 to ptr), %no.430 ]
  br label %join.425
no.424:
  br label %join.425
join.425:
  %v442 = phi ptr [ %v441, %join.431 ], [ inttoptr (i64 2 to ptr), %no.424 ]
  br label %join.419
no.418:
  br label %join.419
join.419:
  %v443 = phi ptr [ %v442, %join.425 ], [ inttoptr (i64 2 to ptr), %no.418 ]
  br label %join.413
no.412:
  br label %join.413
join.413:
  %v444 = phi ptr [ %v443, %join.419 ], [ inttoptr (i64 2 to ptr), %no.412 ]
  %v445 = icmp eq ptr %v444, inttoptr (i64 6 to ptr)
  br i1 %v445, label %yes.446, label %no.447
yes.446:
  %v449 = call ptr @mlf.force(ptr %v397)
  %v450 = call ptr @mlf_prim2(i64 10, ptr %v449, ptr inttoptr (i64 13 to ptr))
  %v451 = icmp eq ptr %v450, inttoptr (i64 6 to ptr)
  br i1 %v451, label %yes.452, label %no.453
yes.452:
  %v455 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 6 to ptr))
  br label %join.454
no.453:
  %v461 = call ptr @mlf.allocate.thunk(ptr @mlf.code.456, i64 1)
  %v462 = getelementptr i8, ptr %v461, i64 16
  %v463 = load ptr, ptr %v462, align 8, !tbaa !3
  %v464 = getelementptr i8, ptr %v463, i64 8
  store ptr %v395, ptr %v464, align 8, !tbaa !3
  %v495 = call ptr @mlf_closure(ptr @mlf.code.465, ptr null)
  %v496 = call ptr @mlf_prim2(i64 1, ptr %v461, ptr %v495)
  br label %join.454
join.454:
  %v497 = phi ptr [ %v455, %yes.452 ], [ %v496, %no.453 ]
  br label %join.448
no.447:
  %v498 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 2 to ptr))
  br label %join.448
join.448:
  %v499 = phi ptr [ %v497, %join.454 ], [ %v498, %no.447 ]
  ret ptr %v499
}

define private ptr @mlf.code.371(ptr %env, ptr %arg) {
entry:
  %v372 = getelementptr i8, ptr %env, i64 8
  %v373 = load ptr, ptr %v372, align 8, !tbaa !3
  %v374 = getelementptr i8, ptr %env, i64 16
  %v375 = load ptr, ptr %v374, align 8, !tbaa !3
  %v376 = getelementptr i8, ptr %env, i64 24
  %v377 = load ptr, ptr %v376, align 8, !tbaa !3
  %v378 = getelementptr i8, ptr %env, i64 32
  %v379 = load ptr, ptr %v378, align 8, !tbaa !3
  %v380 = getelementptr i8, ptr %env, i64 40
  %v381 = load ptr, ptr %v380, align 8, !tbaa !3
  %v382 = getelementptr i8, ptr %env, i64 48
  %v383 = load ptr, ptr %v382, align 8, !tbaa !3
  %v389 = call ptr @mlf.allocate.thunk(ptr @mlf.code.384, i64 1)
  %v390 = getelementptr i8, ptr %v389, i64 16
  %v391 = load ptr, ptr %v390, align 8, !tbaa !3
  %v392 = getelementptr i8, ptr %v391, i64 8
  store ptr %v373, ptr %v392, align 8, !tbaa !3
  %v500 = call ptr @mlf_env_new(i64 7)
  %v501 = getelementptr i8, ptr %v500, i64 8
  store ptr %v373, ptr %v501, align 8, !tbaa !3
  %v502 = getelementptr i8, ptr %v500, i64 16
  store ptr %v375, ptr %v502, align 8, !tbaa !3
  %v503 = getelementptr i8, ptr %v500, i64 24
  store ptr %v377, ptr %v503, align 8, !tbaa !3
  %v504 = getelementptr i8, ptr %v500, i64 32
  store ptr %v379, ptr %v504, align 8, !tbaa !3
  %v505 = getelementptr i8, ptr %v500, i64 40
  store ptr %v381, ptr %v505, align 8, !tbaa !3
  %v506 = getelementptr i8, ptr %v500, i64 48
  store ptr %v383, ptr %v506, align 8, !tbaa !3
  %v507 = getelementptr i8, ptr %v500, i64 56
  store ptr %arg, ptr %v507, align 8, !tbaa !3
  %v508 = call ptr @mlf_closure(ptr @mlf.code.393, ptr %v500)
  %v509 = call ptr @mlf_prim2(i64 1, ptr %v389, ptr %v508)
  ret ptr %v509
}

define private ptr @mlf.code.351(ptr %env, ptr %arg) {
entry:
  %v352 = getelementptr i8, ptr %env, i64 8
  %v353 = load ptr, ptr %v352, align 8, !tbaa !3
  %v354 = getelementptr i8, ptr %env, i64 16
  %v355 = load ptr, ptr %v354, align 8, !tbaa !3
  %v356 = getelementptr i8, ptr %env, i64 24
  %v357 = load ptr, ptr %v356, align 8, !tbaa !3
  %v358 = getelementptr i8, ptr %env, i64 32
  %v359 = load ptr, ptr %v358, align 8, !tbaa !3
  %v360 = getelementptr i8, ptr %env, i64 40
  %v361 = load ptr, ptr %v360, align 8, !tbaa !3
  %v367 = call ptr @mlf.allocate.thunk(ptr @mlf.code.362, i64 1)
  %v368 = getelementptr i8, ptr %v367, i64 16
  %v369 = load ptr, ptr %v368, align 8, !tbaa !3
  %v370 = getelementptr i8, ptr %v369, i64 8
  store ptr %v353, ptr %v370, align 8, !tbaa !3
  %v510 = call ptr @mlf_env_new(i64 6)
  %v511 = getelementptr i8, ptr %v510, i64 8
  store ptr %v353, ptr %v511, align 8, !tbaa !3
  %v512 = getelementptr i8, ptr %v510, i64 16
  store ptr %v355, ptr %v512, align 8, !tbaa !3
  %v513 = getelementptr i8, ptr %v510, i64 24
  store ptr %v357, ptr %v513, align 8, !tbaa !3
  %v514 = getelementptr i8, ptr %v510, i64 32
  store ptr %v359, ptr %v514, align 8, !tbaa !3
  %v515 = getelementptr i8, ptr %v510, i64 40
  store ptr %v361, ptr %v515, align 8, !tbaa !3
  %v516 = getelementptr i8, ptr %v510, i64 48
  store ptr %arg, ptr %v516, align 8, !tbaa !3
  %v517 = call ptr @mlf_closure(ptr @mlf.code.371, ptr %v510)
  %v518 = call ptr @mlf_prim2(i64 1, ptr %v367, ptr %v517)
  ret ptr %v518
}

define private ptr @mlf.code.333(ptr %env, ptr %arg) {
entry:
  %v334 = getelementptr i8, ptr %env, i64 8
  %v335 = load ptr, ptr %v334, align 8, !tbaa !3
  %v336 = getelementptr i8, ptr %env, i64 16
  %v337 = load ptr, ptr %v336, align 8, !tbaa !3
  %v338 = getelementptr i8, ptr %env, i64 24
  %v339 = load ptr, ptr %v338, align 8, !tbaa !3
  %v340 = getelementptr i8, ptr %env, i64 32
  %v341 = load ptr, ptr %v340, align 8, !tbaa !3
  %v347 = call ptr @mlf.allocate.thunk(ptr @mlf.code.342, i64 1)
  %v348 = getelementptr i8, ptr %v347, i64 16
  %v349 = load ptr, ptr %v348, align 8, !tbaa !3
  %v350 = getelementptr i8, ptr %v349, i64 8
  store ptr %v335, ptr %v350, align 8, !tbaa !3
  %v519 = call ptr @mlf_env_new(i64 5)
  %v520 = getelementptr i8, ptr %v519, i64 8
  store ptr %v335, ptr %v520, align 8, !tbaa !3
  %v521 = getelementptr i8, ptr %v519, i64 16
  store ptr %v337, ptr %v521, align 8, !tbaa !3
  %v522 = getelementptr i8, ptr %v519, i64 24
  store ptr %v339, ptr %v522, align 8, !tbaa !3
  %v523 = getelementptr i8, ptr %v519, i64 32
  store ptr %v341, ptr %v523, align 8, !tbaa !3
  %v524 = getelementptr i8, ptr %v519, i64 40
  store ptr %arg, ptr %v524, align 8, !tbaa !3
  %v525 = call ptr @mlf_closure(ptr @mlf.code.351, ptr %v519)
  %v526 = call ptr @mlf_prim2(i64 1, ptr %v347, ptr %v525)
  ret ptr %v526
}

define private ptr @mlf.code.317(ptr %env, ptr %arg) {
entry:
  %v318 = getelementptr i8, ptr %env, i64 8
  %v319 = load ptr, ptr %v318, align 8, !tbaa !3
  %v320 = getelementptr i8, ptr %env, i64 16
  %v321 = load ptr, ptr %v320, align 8, !tbaa !3
  %v322 = getelementptr i8, ptr %env, i64 24
  %v323 = load ptr, ptr %v322, align 8, !tbaa !3
  %v329 = call ptr @mlf.allocate.thunk(ptr @mlf.code.324, i64 1)
  %v330 = getelementptr i8, ptr %v329, i64 16
  %v331 = load ptr, ptr %v330, align 8, !tbaa !3
  %v332 = getelementptr i8, ptr %v331, i64 8
  store ptr %v319, ptr %v332, align 8, !tbaa !3
  %v527 = call ptr @mlf_env_new(i64 4)
  %v528 = getelementptr i8, ptr %v527, i64 8
  store ptr %v319, ptr %v528, align 8, !tbaa !3
  %v529 = getelementptr i8, ptr %v527, i64 16
  store ptr %v321, ptr %v529, align 8, !tbaa !3
  %v530 = getelementptr i8, ptr %v527, i64 24
  store ptr %v323, ptr %v530, align 8, !tbaa !3
  %v531 = getelementptr i8, ptr %v527, i64 32
  store ptr %arg, ptr %v531, align 8, !tbaa !3
  %v532 = call ptr @mlf_closure(ptr @mlf.code.333, ptr %v527)
  %v533 = call ptr @mlf_prim2(i64 1, ptr %v329, ptr %v532)
  ret ptr %v533
}

define private ptr @mlf.code.303(ptr %env, ptr %arg) {
entry:
  %v304 = getelementptr i8, ptr %env, i64 8
  %v305 = load ptr, ptr %v304, align 8, !tbaa !3
  %v306 = getelementptr i8, ptr %env, i64 16
  %v307 = load ptr, ptr %v306, align 8, !tbaa !3
  %v313 = call ptr @mlf.allocate.thunk(ptr @mlf.code.308, i64 1)
  %v314 = getelementptr i8, ptr %v313, i64 16
  %v315 = load ptr, ptr %v314, align 8, !tbaa !3
  %v316 = getelementptr i8, ptr %v315, i64 8
  store ptr %v305, ptr %v316, align 8, !tbaa !3
  %v534 = call ptr @mlf_env_new(i64 3)
  %v535 = getelementptr i8, ptr %v534, i64 8
  store ptr %v305, ptr %v535, align 8, !tbaa !3
  %v536 = getelementptr i8, ptr %v534, i64 16
  store ptr %v307, ptr %v536, align 8, !tbaa !3
  %v537 = getelementptr i8, ptr %v534, i64 24
  store ptr %arg, ptr %v537, align 8, !tbaa !3
  %v538 = call ptr @mlf_closure(ptr @mlf.code.317, ptr %v534)
  %v539 = call ptr @mlf_prim2(i64 1, ptr %v313, ptr %v538)
  ret ptr %v539
}

define private ptr @mlf.code.280(ptr %env, ptr %arg) {
entry:
  %v281 = getelementptr i8, ptr %env, i64 8
  %v282 = load ptr, ptr %v281, align 8, !tbaa !3
  %v283 = getelementptr i8, ptr %env, i64 16
  %v284 = load ptr, ptr %v283, align 8, !tbaa !3
  %v285 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v285, align 8, !tbaa !3
  %v286 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v286, align 8, !tbaa !3
  %v287 = call ptr @mlf.force(ptr %v284)
  %v288 = call ptr @mlf_prim2(i64 11, ptr %v287, ptr inttoptr (i64 13 to ptr))
  %v289 = icmp eq ptr %v288, inttoptr (i64 6 to ptr)
  br i1 %v289, label %yes.290, label %no.291
yes.290:
  %v293 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 2 to ptr))
  br label %join.292
no.291:
  %v299 = call ptr @mlf.allocate.thunk(ptr @mlf.code.294, i64 1)
  %v300 = getelementptr i8, ptr %v299, i64 16
  %v301 = load ptr, ptr %v300, align 8, !tbaa !3
  %v302 = getelementptr i8, ptr %v301, i64 8
  store ptr %v282, ptr %v302, align 8, !tbaa !3
  %v540 = call ptr @mlf_env_new(i64 2)
  %v541 = getelementptr i8, ptr %v540, i64 8
  store ptr %v282, ptr %v541, align 8, !tbaa !3
  %v542 = getelementptr i8, ptr %v540, i64 16
  store ptr %v287, ptr %v542, align 8, !tbaa !3
  %v543 = call ptr @mlf_closure(ptr @mlf.code.303, ptr %v540)
  %v544 = call ptr @mlf_prim2(i64 1, ptr %v299, ptr %v543)
  br label %join.292
join.292:
  %v545 = phi ptr [ %v293, %yes.290 ], [ %v544, %no.291 ]
  ret ptr %v545
}

define private ptr @mlf.code.551(ptr %env, ptr %arg) {
entry:
  %v552 = call ptr @mlf.force(ptr %arg)
  %v553 = icmp eq ptr %v552, inttoptr (i64 6 to ptr)
  br i1 %v553, label %yes.554, label %no.555
yes.554:
  %v557 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.556
no.555:
  %v558 = call ptr @mlf_env_new(i64 1)
  %v559 = getelementptr i8, ptr %v558, i64 8
  store ptr inttoptr (i64 4 to ptr), ptr %v559, align 8, !tbaa !3
  %v560 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2, ptr %v558)
  br label %join.556
join.556:
  %v561 = phi ptr [ %v557, %yes.554 ], [ %v560, %no.555 ]
  ret ptr %v561
}

define private ptr @mlf.code.270(ptr %env, ptr %arg) {
entry:
  %v271 = getelementptr i8, ptr %env, i64 8
  %v272 = load ptr, ptr %v271, align 8, !tbaa !3
  %v273 = call ptr @mlf.force(ptr %arg)
  %v274 = call ptr @mlf_prim2(i64 10, ptr %v273, ptr inttoptr (i64 1 to ptr))
  %v275 = icmp eq ptr %v274, inttoptr (i64 6 to ptr)
  br i1 %v275, label %yes.276, label %no.277
yes.276:
  %v279 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.278
no.277:
  %v546 = call ptr @mlf.allocate.thunk(ptr @mlf.code.280, i64 2)
  %v547 = getelementptr i8, ptr %v546, i64 16
  %v548 = load ptr, ptr %v547, align 8, !tbaa !3
  %v549 = getelementptr i8, ptr %v548, i64 8
  store ptr %v272, ptr %v549, align 8, !tbaa !3
  %v550 = getelementptr i8, ptr %v548, i64 16
  store ptr %v273, ptr %v550, align 8, !tbaa !3
  %v562 = call ptr @mlf_closure(ptr @mlf.code.551, ptr null)
  %v563 = call ptr @mlf_prim2(i64 1, ptr %v546, ptr %v562)
  br label %join.278
join.278:
  %v564 = phi ptr [ %v279, %yes.276 ], [ %v563, %no.277 ]
  ret ptr %v564
}

define private ptr @mlf.code.260(ptr %env, ptr %arg) {
entry:
  %v266 = call ptr @mlf.allocate.thunk(ptr @mlf.code.261, i64 1)
  %v267 = getelementptr i8, ptr %v266, i64 16
  %v268 = load ptr, ptr %v267, align 8, !tbaa !3
  %v269 = getelementptr i8, ptr %v268, i64 8
  store ptr %arg, ptr %v269, align 8, !tbaa !3
  %v565 = call ptr @mlf_env_new(i64 1)
  %v566 = getelementptr i8, ptr %v565, i64 8
  store ptr %arg, ptr %v566, align 8, !tbaa !3
  %v567 = call ptr @mlf_closure(ptr @mlf.code.270, ptr %v565)
  %v568 = call ptr @mlf_prim2(i64 1, ptr %v266, ptr %v567)
  ret ptr %v568
}

define private ptr @mlf.worker.25(ptr %a0) {
entry:
  %v259 = call ptr @mlf_primitive(i64 41)
  %v569 = call ptr @mlf_closure(ptr @mlf.code.260, ptr null)
  %v570 = call ptr @mlf_prim2(i64 1, ptr %v259, ptr %v569)
  ret ptr %v570
}

define private ptr @mlf.numeric.entry.2(ptr %env, ptr %arg) {
entry:
  %v3 = getelementptr i8, ptr %env, i64 8
  %v4 = load ptr, ptr %v3, align 8, !tbaa !3
  %v5 = call ptr @mlf_peek(ptr %v4)
  %v6 = icmp ne ptr %v5, null
  %v7 = and i1 true, %v6
  br i1 %v7, label %yes.8, label %no.9
yes.8:
  %v257 = call ptr @mlf.numeric.25(ptr %v5)
  %v258 = call ptr @mlf_prim1(i64 0, ptr %v257)
  br label %join.10
no.9:
  %v571 = call ptr @mlf.worker.25(ptr %v4)
  br label %join.10
join.10:
  %v572 = phi ptr [ %v258, %yes.8 ], [ %v571, %no.9 ]
  ret ptr %v572
}

define private ptr @mlf.code.1(ptr %env, ptr %arg) {
entry:
  %v573 = call ptr @mlf_env_new(i64 1)
  %v574 = getelementptr i8, ptr %v573, i64 8
  store ptr inttoptr (i64 4 to ptr), ptr %v574, align 8, !tbaa !3
  %v575 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2, ptr %v573)
  ret ptr %v575
}

define private ptr @mlf.code.578(ptr %env, ptr %arg) {
entry:
  %v579 = call ptr @mlf_prim2(i64 35, ptr inttoptr (i64 2049 to ptr), ptr inttoptr (i64 1 to ptr))
  ret ptr %v579
}

define private ptr @mlf.numeric.11.pi(ptr %a0, ptr %a1) alwaysinline {
entry:
  %v669 = ptrtoint ptr %a1 to i64
  %v670 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v671 = icmp eq i64 %v669, %v670
  %v672 = select i1 %v671, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v673 = icmp eq ptr %v672, inttoptr (i64 6 to ptr)
  br i1 %v673, label %tail.yes.674, label %tail.no.675
tail.yes.674:
  ret ptr inttoptr (i64 1 to ptr)
tail.no.675:
  %v676 = ptrtoint ptr %a1 to i64
  %v677 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v678 = sub i64 %v677, 1
  %v679 = sub nsw i64 %v676, %v678
  %v680 = inttoptr i64 %v679 to ptr
  %v681 = getelementptr i8, ptr %a0, i64 8
  %v682 = load i64, ptr %v681, align 8, !tbaa !3
  %v683 = getelementptr i8, ptr %a0, i64 16
  %v684 = load ptr, ptr %v683, align 8, !tbaa !3
  %v685 = ptrtoint ptr %v680 to i64
  %v686 = ashr i64 %v685, 1
  %v687 = and i64 %v685, 1
  %v688 = icmp ne i64 %v687, 0
  %v689 = icmp ult i64 %v686, %v682
  %v690 = and i1 %v688, %v689
  br i1 %v690, label %array.valid.691, label %array.invalid.692
array.invalid.692:
  call void @mlf_bounds_failure()
  unreachable
array.valid.691:
  %v693 = getelementptr i8, ptr %v684, i64 %v686
  %v694 = load i8, ptr %v693, align 1, !tbaa !4
  %v695 = zext i8 %v694 to i64
  %v696 = shl i64 %v695, 1
  %v697 = or i64 %v696, 1
  %v698 = inttoptr i64 %v697 to ptr
  %v699 = ptrtoint ptr %v698 to i64
  %v700 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v701 = icmp eq i64 %v699, %v700
  %v702 = select i1 %v701, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v703 = icmp eq ptr %v702, inttoptr (i64 6 to ptr)
  br i1 %v703, label %tail.yes.704, label %tail.no.705
tail.yes.704:
  %v706 = ptrtoint ptr %a1 to i64
  %v707 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v708 = sub i64 %v707, 1
  %v709 = sub nsw i64 %v706, %v708
  %v710 = inttoptr i64 %v709 to ptr
  %v711 = musttail call ptr @mlf.numeric.11.pi(ptr %a0, ptr %v710)
  ret ptr %v711
tail.no.705:
  %v712 = ptrtoint ptr %v698 to i64
  %v713 = ptrtoint ptr inttoptr (i64 27 to ptr) to i64
  %v714 = icmp eq i64 %v712, %v713
  %v715 = select i1 %v714, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v716 = icmp eq ptr %v715, inttoptr (i64 6 to ptr)
  br i1 %v716, label %tail.yes.717, label %tail.no.718
tail.yes.717:
  %v719 = ptrtoint ptr %a1 to i64
  %v720 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v721 = sub i64 %v720, 1
  %v722 = sub nsw i64 %v719, %v721
  %v723 = inttoptr i64 %v722 to ptr
  %v724 = musttail call ptr @mlf.numeric.11.pi(ptr %a0, ptr %v723)
  ret ptr %v724
tail.no.718:
  ret ptr %a1
}

define private ptr @mlf.numeric.11(ptr %a0, ptr %a1) alwaysinline {
entry:
  %v661 = ptrtoint ptr %a1 to i64
  %v662 = and i64 %v661, 1
  %v663 = icmp ne i64 %v662, 0
  %v664 = icmp ult i64 %v661, 4294967296
  %v665 = and i1 %v663, %v664
  %v666 = and i1 true, %v665
  br i1 %v666, label %range.fast.667, label %range.general.668
range.fast.667:
  %v725 = musttail call ptr @mlf.numeric.11.pi(ptr %a0, ptr %a1)
  ret ptr %v725
range.general.668:
  %v726 = ptrtoint ptr %a1 to i64
  %v727 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v728 = and i64 %v726, %v727
  %v729 = and i64 %v728, 1
  %v730 = icmp ne i64 %v729, 0
  br i1 %v730, label %yes.731, label %no.732
yes.731:
  %v734 = icmp eq i64 %v726, %v727
  %v735 = select i1 %v734, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.733
no.732:
  %v736 = call ptr @mlf_eq_int(ptr %a1, ptr inttoptr (i64 1 to ptr))
  br label %join.733
join.733:
  %v737 = phi ptr [ %v735, %yes.731 ], [ %v736, %no.732 ]
  %v738 = icmp eq ptr %v737, inttoptr (i64 6 to ptr)
  br i1 %v738, label %tail.yes.739, label %tail.no.740
tail.yes.739:
  ret ptr inttoptr (i64 1 to ptr)
tail.no.740:
  %v741 = ptrtoint ptr %a1 to i64
  %v742 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v743 = and i64 %v741, %v742
  %v744 = and i64 %v743, 1
  %v745 = icmp ne i64 %v744, 0
  br i1 %v745, label %yes.746, label %no.747
yes.746:
  %v749 = sub i64 %v742, 1
  %v750 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v741, i64 %v749)
  %v751 = extractvalue { i64, i1 } %v750, 0
  %v752 = extractvalue { i64, i1 } %v750, 1
  br i1 %v752, label %yes.753, label %no.754
yes.753:
  %v756 = call ptr @mlf_sub_int(ptr %a1, ptr inttoptr (i64 3 to ptr))
  br label %join.755
no.754:
  %v757 = inttoptr i64 %v751 to ptr
  br label %join.755
join.755:
  %v758 = phi ptr [ %v756, %yes.753 ], [ %v757, %no.754 ]
  br label %join.748
no.747:
  %v759 = call ptr @mlf_sub_int(ptr %a1, ptr inttoptr (i64 3 to ptr))
  br label %join.748
join.748:
  %v760 = phi ptr [ %v758, %join.755 ], [ %v759, %no.747 ]
  %v761 = getelementptr i8, ptr %a0, i64 8
  %v762 = load i64, ptr %v761, align 8, !tbaa !3
  %v763 = getelementptr i8, ptr %a0, i64 16
  %v764 = load ptr, ptr %v763, align 8, !tbaa !3
  %v765 = ptrtoint ptr %v760 to i64
  %v766 = ashr i64 %v765, 1
  %v767 = and i64 %v765, 1
  %v768 = icmp ne i64 %v767, 0
  %v769 = icmp ult i64 %v766, %v762
  %v770 = and i1 %v768, %v769
  br i1 %v770, label %array.valid.771, label %array.invalid.772
array.invalid.772:
  call void @mlf_bounds_failure()
  unreachable
array.valid.771:
  %v773 = getelementptr i8, ptr %v764, i64 %v766
  %v774 = load i8, ptr %v773, align 1, !tbaa !4
  %v775 = zext i8 %v774 to i64
  %v776 = shl i64 %v775, 1
  %v777 = or i64 %v776, 1
  %v778 = inttoptr i64 %v777 to ptr
  %v779 = ptrtoint ptr %v778 to i64
  %v780 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v781 = icmp eq i64 %v779, %v780
  %v782 = select i1 %v781, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v783 = icmp eq ptr %v782, inttoptr (i64 6 to ptr)
  br i1 %v783, label %tail.yes.784, label %tail.no.785
tail.yes.784:
  %v786 = ptrtoint ptr %a1 to i64
  %v787 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v788 = and i64 %v786, %v787
  %v789 = and i64 %v788, 1
  %v790 = icmp ne i64 %v789, 0
  br i1 %v790, label %yes.791, label %no.792
yes.791:
  %v794 = sub i64 %v787, 1
  %v795 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v786, i64 %v794)
  %v796 = extractvalue { i64, i1 } %v795, 0
  %v797 = extractvalue { i64, i1 } %v795, 1
  br i1 %v797, label %yes.798, label %no.799
yes.798:
  %v801 = call ptr @mlf_sub_int(ptr %a1, ptr inttoptr (i64 3 to ptr))
  br label %join.800
no.799:
  %v802 = inttoptr i64 %v796 to ptr
  br label %join.800
join.800:
  %v803 = phi ptr [ %v801, %yes.798 ], [ %v802, %no.799 ]
  br label %join.793
no.792:
  %v804 = call ptr @mlf_sub_int(ptr %a1, ptr inttoptr (i64 3 to ptr))
  br label %join.793
join.793:
  %v805 = phi ptr [ %v803, %join.800 ], [ %v804, %no.792 ]
  %v806 = musttail call ptr @mlf.numeric.11(ptr %a0, ptr %v805)
  ret ptr %v806
tail.no.785:
  %v807 = ptrtoint ptr %v778 to i64
  %v808 = ptrtoint ptr inttoptr (i64 27 to ptr) to i64
  %v809 = icmp eq i64 %v807, %v808
  %v810 = select i1 %v809, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v811 = icmp eq ptr %v810, inttoptr (i64 6 to ptr)
  br i1 %v811, label %tail.yes.812, label %tail.no.813
tail.yes.812:
  %v814 = ptrtoint ptr %a1 to i64
  %v815 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v816 = and i64 %v814, %v815
  %v817 = and i64 %v816, 1
  %v818 = icmp ne i64 %v817, 0
  br i1 %v818, label %yes.819, label %no.820
yes.819:
  %v822 = sub i64 %v815, 1
  %v823 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v814, i64 %v822)
  %v824 = extractvalue { i64, i1 } %v823, 0
  %v825 = extractvalue { i64, i1 } %v823, 1
  br i1 %v825, label %yes.826, label %no.827
yes.826:
  %v829 = call ptr @mlf_sub_int(ptr %a1, ptr inttoptr (i64 3 to ptr))
  br label %join.828
no.827:
  %v830 = inttoptr i64 %v824 to ptr
  br label %join.828
join.828:
  %v831 = phi ptr [ %v829, %yes.826 ], [ %v830, %no.827 ]
  br label %join.821
no.820:
  %v832 = call ptr @mlf_sub_int(ptr %a1, ptr inttoptr (i64 3 to ptr))
  br label %join.821
join.821:
  %v833 = phi ptr [ %v831, %join.828 ], [ %v832, %no.820 ]
  %v834 = musttail call ptr @mlf.numeric.11(ptr %a0, ptr %v833)
  ret ptr %v834
tail.no.813:
  ret ptr %a1
}

define private ptr @mlf.numeric.8(ptr %a0, ptr %a1) alwaysinline {
entry:
  %v871 = ptrtoint ptr %a0 to i64
  %v872 = ptrtoint ptr %a1 to i64
  %v873 = and i64 %v871, %v872
  %v874 = and i64 %v873, 1
  %v875 = icmp ne i64 %v874, 0
  br i1 %v875, label %yes.876, label %no.877
yes.876:
  %v879 = icmp slt i64 %v871, %v872
  %v880 = select i1 %v879, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.878
no.877:
  %v881 = call ptr @mlf_lt_int(ptr %a0, ptr %a1)
  br label %join.878
join.878:
  %v882 = phi ptr [ %v880, %yes.876 ], [ %v881, %no.877 ]
  %v883 = icmp eq ptr %v882, inttoptr (i64 6 to ptr)
  br i1 %v883, label %tail.yes.884, label %tail.no.885
tail.yes.884:
  %v886 = ptrtoint ptr %a0 to i64
  %v887 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v888 = and i64 %v886, %v887
  %v889 = and i64 %v888, 1
  %v890 = icmp ne i64 %v889, 0
  br i1 %v890, label %yes.891, label %no.892
yes.891:
  %v894 = ashr i64 %v886, 1
  %v895 = ashr i64 %v887, 1
  %v896 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v894, i64 %v895)
  %v897 = extractvalue { i64, i1 } %v896, 0
  %v898 = extractvalue { i64, i1 } %v896, 1
  %v899 = xor i1 %v898, true
  %v900 = icmp sge i64 %v897, -4611686018427387904
  %v901 = icmp sle i64 %v897, 4611686018427387903
  %v902 = and i1 %v900, %v901
  %v903 = and i1 %v902, %v899
  br i1 %v903, label %yes.904, label %no.905
yes.904:
  %v907 = shl i64 %v897, 1
  %v908 = or i64 %v907, 1
  %v909 = inttoptr i64 %v908 to ptr
  br label %join.906
no.905:
  %v910 = call ptr @mlf_prim2(i64 14, ptr %a0, ptr inttoptr (i64 5 to ptr))
  br label %join.906
join.906:
  %v911 = phi ptr [ %v909, %yes.904 ], [ %v910, %no.905 ]
  br label %join.893
no.892:
  %v912 = call ptr @mlf_prim2(i64 14, ptr %a0, ptr inttoptr (i64 5 to ptr))
  br label %join.893
join.893:
  %v913 = phi ptr [ %v911, %join.906 ], [ %v912, %no.892 ]
  %v914 = musttail call ptr @mlf.numeric.8(ptr %v913, ptr %a1)
  ret ptr %v914
tail.no.885:
  ret ptr %a0
}

define private ptr @mlf.numeric.0(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) alwaysinline {
entry:
  %v917 = getelementptr i8, ptr %a0, i64 8
  %v918 = load i64, ptr %v917, align 8, !tbaa !3
  %v919 = getelementptr i8, ptr %a0, i64 16
  %v920 = load ptr, ptr %v919, align 8, !tbaa !3
  %v921 = getelementptr i8, ptr %a1, i64 8
  %v922 = load i64, ptr %v921, align 8, !tbaa !3
  %v923 = getelementptr i8, ptr %a1, i64 16
  %v924 = load ptr, ptr %v923, align 8, !tbaa !3
  %v925 = ptrtoint ptr %a2 to i64
  %v926 = ptrtoint ptr %a3 to i64
  %v927 = ptrtoint ptr %a4 to i64
  %v928 = and i64 %v925, 1
  %v929 = icmp ne i64 %v928, 0
  %v930 = and i64 %v926, 1
  %v931 = icmp ne i64 %v930, 0
  %v932 = and i64 %v927, 1
  %v933 = icmp ne i64 %v932, 0
  %v934 = ashr i64 %v925, 1
  %v935 = ashr i64 %v926, 1
  %v936 = ashr i64 %v927, 1
  %v937 = icmp sge i64 %v936, 0
  %v938 = icmp sge i64 %v934, %v936
  %v939 = icmp ule i64 %v934, %v918
  %v940 = icmp ule i64 %v935, %v922
  %v941 = sub i64 %v922, %v935
  %v942 = icmp ule i64 %v934, %v941
  %v943 = sub i64 %v934, %v936
  %v944 = icmp ne ptr %v920, %v924
  %v945 = icmp eq i64 %v935, 0
  %v946 = icmp uge i64 %v935, %v943
  %v947 = or i1 %v944, %v945
  %v948 = or i1 %v947, %v946
  %v949 = and i1 true, %v929
  %v950 = and i1 %v949, %v931
  %v951 = and i1 %v950, %v933
  %v952 = and i1 %v951, %v937
  %v953 = and i1 %v952, %v938
  %v954 = and i1 %v953, %v939
  %v955 = and i1 %v954, %v940
  %v956 = and i1 %v955, %v942
  %v957 = and i1 %v956, %v948
  br i1 %v957, label %copy.bulk.958, label %copy.scalar.959
copy.bulk.958:
  %v960 = getelementptr i8, ptr %v920, i64 %v936
  %v961 = add i64 %v935, %v936
  %v962 = getelementptr i8, ptr %v924, i64 %v961
  call void @llvm.memmove.p0.p0.i64(ptr %v962, ptr %v960, i64 %v943, i1 false)
  ret ptr inttoptr (i64 4 to ptr)
copy.scalar.959:
  %v963 = ptrtoint ptr %a4 to i64
  %v964 = ptrtoint ptr %a2 to i64
  %v965 = and i64 %v963, %v964
  %v966 = and i64 %v965, 1
  %v967 = icmp ne i64 %v966, 0
  br i1 %v967, label %yes.968, label %no.969
yes.968:
  %v971 = icmp slt i64 %v963, %v964
  %v972 = select i1 %v971, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.970
no.969:
  %v973 = call ptr @mlf_lt_int(ptr %a4, ptr %a2)
  br label %join.970
join.970:
  %v974 = phi ptr [ %v972, %yes.968 ], [ %v973, %no.969 ]
  %v975 = icmp eq ptr %v974, inttoptr (i64 6 to ptr)
  br i1 %v975, label %tail.yes.976, label %tail.no.977
tail.yes.976:
  %v978 = ptrtoint ptr %a4 to i64
  %v979 = ashr i64 %v978, 1
  %v980 = and i64 %v978, 1
  %v981 = icmp ne i64 %v980, 0
  %v982 = icmp ult i64 %v979, %v918
  %v983 = and i1 %v981, %v982
  br i1 %v983, label %array.valid.984, label %array.invalid.985
array.invalid.985:
  call void @mlf_bounds_failure()
  unreachable
array.valid.984:
  %v986 = getelementptr i8, ptr %v920, i64 %v979
  %v987 = load i8, ptr %v986, align 1, !tbaa !4
  %v988 = zext i8 %v987 to i64
  %v989 = shl i64 %v988, 1
  %v990 = or i64 %v989, 1
  %v991 = inttoptr i64 %v990 to ptr
  %v992 = ptrtoint ptr %a3 to i64
  %v993 = ptrtoint ptr %a4 to i64
  %v994 = and i64 %v992, %v993
  %v995 = and i64 %v994, 1
  %v996 = icmp ne i64 %v995, 0
  br i1 %v996, label %yes.997, label %no.998
yes.997:
  %v1000 = sub i64 %v993, 1
  %v1001 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v992, i64 %v1000)
  %v1002 = extractvalue { i64, i1 } %v1001, 0
  %v1003 = extractvalue { i64, i1 } %v1001, 1
  br i1 %v1003, label %yes.1004, label %no.1005
yes.1004:
  %v1007 = call ptr @mlf_add_int(ptr %a3, ptr %a4)
  br label %join.1006
no.1005:
  %v1008 = inttoptr i64 %v1002 to ptr
  br label %join.1006
join.1006:
  %v1009 = phi ptr [ %v1007, %yes.1004 ], [ %v1008, %no.1005 ]
  br label %join.999
no.998:
  %v1010 = call ptr @mlf_add_int(ptr %a3, ptr %a4)
  br label %join.999
join.999:
  %v1011 = phi ptr [ %v1009, %join.1006 ], [ %v1010, %no.998 ]
  %v1012 = ptrtoint ptr %v1011 to i64
  %v1013 = ashr i64 %v1012, 1
  %v1014 = and i64 %v1012, 1
  %v1015 = icmp ne i64 %v1014, 0
  %v1016 = icmp ult i64 %v1013, %v922
  %v1017 = and i1 %v1015, %v1016
  br i1 %v1017, label %array.valid.1018, label %array.invalid.1019
array.invalid.1019:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1018:
  %v1020 = getelementptr i8, ptr %v924, i64 %v1013
  %v1021 = ptrtoint ptr %v991 to i64
  %v1022 = ashr i64 %v1021, 1
  %v1023 = trunc i64 %v1022 to i8
  store i8 %v1023, ptr %v1020, align 1, !tbaa !4
  %v1024 = ptrtoint ptr %a4 to i64
  %v1025 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1026 = sub i64 %v1025, 1
  %v1027 = add nsw i64 %v1024, %v1026
  %v1028 = inttoptr i64 %v1027 to ptr
  %v1029 = musttail call ptr @mlf.numeric.0(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %v1028)
  ret ptr %v1029
tail.no.977:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.numeric.17.ppiii(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) alwaysinline {
entry:
  %v1051 = ptrtoint ptr %a4 to i64
  %v1052 = ptrtoint ptr %a2 to i64
  %v1053 = icmp slt i64 %v1051, %v1052
  %v1054 = select i1 %v1053, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1055 = icmp eq ptr %v1054, inttoptr (i64 6 to ptr)
  br i1 %v1055, label %tail.yes.1056, label %tail.no.1057
tail.yes.1056:
  %v1058 = getelementptr i8, ptr %a0, i64 8
  %v1059 = load i64, ptr %v1058, align 8, !tbaa !3
  %v1060 = getelementptr i8, ptr %a0, i64 16
  %v1061 = load ptr, ptr %v1060, align 8, !tbaa !3
  %v1062 = ptrtoint ptr %a4 to i64
  %v1063 = ashr i64 %v1062, 1
  %v1064 = and i64 %v1062, 1
  %v1065 = icmp ne i64 %v1064, 0
  %v1066 = icmp ult i64 %v1063, %v1059
  %v1067 = and i1 %v1065, %v1066
  br i1 %v1067, label %array.valid.1068, label %array.invalid.1069
array.invalid.1069:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1068:
  %v1070 = getelementptr i8, ptr %v1061, i64 %v1063
  %v1071 = load i8, ptr %v1070, align 1, !tbaa !4
  %v1072 = zext i8 %v1071 to i64
  %v1073 = shl i64 %v1072, 1
  %v1074 = or i64 %v1073, 1
  %v1075 = inttoptr i64 %v1074 to ptr
  %v1076 = ptrtoint ptr %a3 to i64
  %v1077 = ptrtoint ptr %a4 to i64
  %v1078 = sub i64 %v1077, 1
  %v1079 = add nsw i64 %v1076, %v1078
  %v1080 = inttoptr i64 %v1079 to ptr
  %v1081 = ptrtoint ptr %v1075 to i64
  %v1082 = ptrtoint ptr inttoptr (i64 131 to ptr) to i64
  %v1083 = icmp eq i64 %v1081, %v1082
  %v1084 = select i1 %v1083, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1085 = icmp eq ptr %v1084, inttoptr (i64 6 to ptr)
  br i1 %v1085, label %yes.1086, label %no.1087
yes.1086:
  br label %join.1088
no.1087:
  %v1089 = ptrtoint ptr %v1075 to i64
  %v1090 = ptrtoint ptr inttoptr (i64 195 to ptr) to i64
  %v1091 = icmp eq i64 %v1089, %v1090
  %v1092 = select i1 %v1091, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1093 = icmp eq ptr %v1092, inttoptr (i64 6 to ptr)
  br i1 %v1093, label %yes.1094, label %no.1095
yes.1094:
  br label %join.1096
no.1095:
  %v1097 = ptrtoint ptr %v1075 to i64
  %v1098 = ptrtoint ptr inttoptr (i64 135 to ptr) to i64
  %v1099 = icmp eq i64 %v1097, %v1098
  %v1100 = select i1 %v1099, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1101 = icmp eq ptr %v1100, inttoptr (i64 6 to ptr)
  br i1 %v1101, label %yes.1102, label %no.1103
yes.1102:
  br label %join.1104
no.1103:
  %v1105 = ptrtoint ptr %v1075 to i64
  %v1106 = ptrtoint ptr inttoptr (i64 199 to ptr) to i64
  %v1107 = icmp eq i64 %v1105, %v1106
  %v1108 = select i1 %v1107, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1109 = icmp eq ptr %v1108, inttoptr (i64 6 to ptr)
  br i1 %v1109, label %yes.1110, label %no.1111
yes.1110:
  br label %join.1112
no.1111:
  %v1113 = ptrtoint ptr %v1075 to i64
  %v1114 = ptrtoint ptr inttoptr (i64 143 to ptr) to i64
  %v1115 = icmp eq i64 %v1113, %v1114
  %v1116 = select i1 %v1115, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1117 = icmp eq ptr %v1116, inttoptr (i64 6 to ptr)
  br i1 %v1117, label %yes.1118, label %no.1119
yes.1118:
  br label %join.1120
no.1119:
  %v1121 = ptrtoint ptr %v1075 to i64
  %v1122 = ptrtoint ptr inttoptr (i64 207 to ptr) to i64
  %v1123 = icmp eq i64 %v1121, %v1122
  %v1124 = select i1 %v1123, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1125 = icmp eq ptr %v1124, inttoptr (i64 6 to ptr)
  br i1 %v1125, label %yes.1126, label %no.1127
yes.1126:
  br label %join.1128
no.1127:
  br label %join.1128
join.1128:
  %v1129 = phi ptr [ inttoptr (i64 5 to ptr), %yes.1126 ], [ inttoptr (i64 7 to ptr), %no.1127 ]
  br label %join.1120
join.1120:
  %v1130 = phi ptr [ inttoptr (i64 5 to ptr), %yes.1118 ], [ %v1129, %join.1128 ]
  br label %join.1112
join.1112:
  %v1131 = phi ptr [ inttoptr (i64 3 to ptr), %yes.1110 ], [ %v1130, %join.1120 ]
  br label %join.1104
join.1104:
  %v1132 = phi ptr [ inttoptr (i64 3 to ptr), %yes.1102 ], [ %v1131, %join.1112 ]
  br label %join.1096
join.1096:
  %v1133 = phi ptr [ inttoptr (i64 1 to ptr), %yes.1094 ], [ %v1132, %join.1104 ]
  br label %join.1088
join.1088:
  %v1134 = phi ptr [ inttoptr (i64 1 to ptr), %yes.1086 ], [ %v1133, %join.1096 ]
  %v1135 = getelementptr i8, ptr %a1, i64 8
  %v1136 = load i64, ptr %v1135, align 8, !tbaa !3
  %v1137 = getelementptr i8, ptr %a1, i64 16
  %v1138 = load ptr, ptr %v1137, align 8, !tbaa !3
  %v1139 = ptrtoint ptr %v1080 to i64
  %v1140 = ashr i64 %v1139, 1
  %v1141 = and i64 %v1139, 1
  %v1142 = icmp ne i64 %v1141, 0
  %v1143 = icmp ult i64 %v1140, %v1136
  %v1144 = and i1 %v1142, %v1143
  br i1 %v1144, label %array.valid.1145, label %array.invalid.1146
array.invalid.1146:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1145:
  %v1147 = getelementptr i8, ptr %v1138, i64 %v1140
  %v1148 = ptrtoint ptr %v1134 to i64
  %v1149 = ashr i64 %v1148, 1
  %v1150 = trunc i64 %v1149 to i8
  store i8 %v1150, ptr %v1147, align 1, !tbaa !4
  %v1151 = ptrtoint ptr %a4 to i64
  %v1152 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1153 = sub i64 %v1152, 1
  %v1154 = add nsw i64 %v1151, %v1153
  %v1155 = inttoptr i64 %v1154 to ptr
  %v1156 = musttail call ptr @mlf.numeric.17.ppiii(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %v1155)
  ret ptr %v1156
tail.no.1057:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.numeric.17(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) alwaysinline {
entry:
  %v1031 = ptrtoint ptr %a2 to i64
  %v1032 = and i64 %v1031, 1
  %v1033 = icmp ne i64 %v1032, 0
  %v1034 = icmp ult i64 %v1031, 4294967296
  %v1035 = and i1 %v1033, %v1034
  %v1036 = ptrtoint ptr %a3 to i64
  %v1037 = and i64 %v1036, 1
  %v1038 = icmp ne i64 %v1037, 0
  %v1039 = icmp ult i64 %v1036, 4294967296
  %v1040 = and i1 %v1038, %v1039
  %v1041 = ptrtoint ptr %a4 to i64
  %v1042 = and i64 %v1041, 1
  %v1043 = icmp ne i64 %v1042, 0
  %v1044 = icmp ult i64 %v1041, 4294967296
  %v1045 = and i1 %v1043, %v1044
  %v1046 = and i1 true, %v1035
  %v1047 = and i1 %v1046, %v1040
  %v1048 = and i1 %v1047, %v1045
  br i1 %v1048, label %range.fast.1049, label %range.general.1050
range.fast.1049:
  %v1157 = musttail call ptr @mlf.numeric.17.ppiii(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4)
  ret ptr %v1157
range.general.1050:
  %v1158 = ptrtoint ptr %a4 to i64
  %v1159 = ptrtoint ptr %a2 to i64
  %v1160 = and i64 %v1158, %v1159
  %v1161 = and i64 %v1160, 1
  %v1162 = icmp ne i64 %v1161, 0
  br i1 %v1162, label %yes.1163, label %no.1164
yes.1163:
  %v1166 = icmp slt i64 %v1158, %v1159
  %v1167 = select i1 %v1166, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1165
no.1164:
  %v1168 = call ptr @mlf_lt_int(ptr %a4, ptr %a2)
  br label %join.1165
join.1165:
  %v1169 = phi ptr [ %v1167, %yes.1163 ], [ %v1168, %no.1164 ]
  %v1170 = icmp eq ptr %v1169, inttoptr (i64 6 to ptr)
  br i1 %v1170, label %tail.yes.1171, label %tail.no.1172
tail.yes.1171:
  %v1173 = getelementptr i8, ptr %a0, i64 8
  %v1174 = load i64, ptr %v1173, align 8, !tbaa !3
  %v1175 = getelementptr i8, ptr %a0, i64 16
  %v1176 = load ptr, ptr %v1175, align 8, !tbaa !3
  %v1177 = ptrtoint ptr %a4 to i64
  %v1178 = ashr i64 %v1177, 1
  %v1179 = and i64 %v1177, 1
  %v1180 = icmp ne i64 %v1179, 0
  %v1181 = icmp ult i64 %v1178, %v1174
  %v1182 = and i1 %v1180, %v1181
  br i1 %v1182, label %array.valid.1183, label %array.invalid.1184
array.invalid.1184:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1183:
  %v1185 = getelementptr i8, ptr %v1176, i64 %v1178
  %v1186 = load i8, ptr %v1185, align 1, !tbaa !4
  %v1187 = zext i8 %v1186 to i64
  %v1188 = shl i64 %v1187, 1
  %v1189 = or i64 %v1188, 1
  %v1190 = inttoptr i64 %v1189 to ptr
  %v1191 = ptrtoint ptr %a3 to i64
  %v1192 = ptrtoint ptr %a4 to i64
  %v1193 = and i64 %v1191, %v1192
  %v1194 = and i64 %v1193, 1
  %v1195 = icmp ne i64 %v1194, 0
  br i1 %v1195, label %yes.1196, label %no.1197
yes.1196:
  %v1199 = sub i64 %v1192, 1
  %v1200 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1191, i64 %v1199)
  %v1201 = extractvalue { i64, i1 } %v1200, 0
  %v1202 = extractvalue { i64, i1 } %v1200, 1
  br i1 %v1202, label %yes.1203, label %no.1204
yes.1203:
  %v1206 = call ptr @mlf_add_int(ptr %a3, ptr %a4)
  br label %join.1205
no.1204:
  %v1207 = inttoptr i64 %v1201 to ptr
  br label %join.1205
join.1205:
  %v1208 = phi ptr [ %v1206, %yes.1203 ], [ %v1207, %no.1204 ]
  br label %join.1198
no.1197:
  %v1209 = call ptr @mlf_add_int(ptr %a3, ptr %a4)
  br label %join.1198
join.1198:
  %v1210 = phi ptr [ %v1208, %join.1205 ], [ %v1209, %no.1197 ]
  %v1211 = ptrtoint ptr %v1190 to i64
  %v1212 = ptrtoint ptr inttoptr (i64 131 to ptr) to i64
  %v1213 = icmp eq i64 %v1211, %v1212
  %v1214 = select i1 %v1213, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1215 = icmp eq ptr %v1214, inttoptr (i64 6 to ptr)
  br i1 %v1215, label %yes.1216, label %no.1217
yes.1216:
  br label %join.1218
no.1217:
  %v1219 = ptrtoint ptr %v1190 to i64
  %v1220 = ptrtoint ptr inttoptr (i64 195 to ptr) to i64
  %v1221 = icmp eq i64 %v1219, %v1220
  %v1222 = select i1 %v1221, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1223 = icmp eq ptr %v1222, inttoptr (i64 6 to ptr)
  br i1 %v1223, label %yes.1224, label %no.1225
yes.1224:
  br label %join.1226
no.1225:
  %v1227 = ptrtoint ptr %v1190 to i64
  %v1228 = ptrtoint ptr inttoptr (i64 135 to ptr) to i64
  %v1229 = icmp eq i64 %v1227, %v1228
  %v1230 = select i1 %v1229, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1231 = icmp eq ptr %v1230, inttoptr (i64 6 to ptr)
  br i1 %v1231, label %yes.1232, label %no.1233
yes.1232:
  br label %join.1234
no.1233:
  %v1235 = ptrtoint ptr %v1190 to i64
  %v1236 = ptrtoint ptr inttoptr (i64 199 to ptr) to i64
  %v1237 = icmp eq i64 %v1235, %v1236
  %v1238 = select i1 %v1237, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1239 = icmp eq ptr %v1238, inttoptr (i64 6 to ptr)
  br i1 %v1239, label %yes.1240, label %no.1241
yes.1240:
  br label %join.1242
no.1241:
  %v1243 = ptrtoint ptr %v1190 to i64
  %v1244 = ptrtoint ptr inttoptr (i64 143 to ptr) to i64
  %v1245 = icmp eq i64 %v1243, %v1244
  %v1246 = select i1 %v1245, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1247 = icmp eq ptr %v1246, inttoptr (i64 6 to ptr)
  br i1 %v1247, label %yes.1248, label %no.1249
yes.1248:
  br label %join.1250
no.1249:
  %v1251 = ptrtoint ptr %v1190 to i64
  %v1252 = ptrtoint ptr inttoptr (i64 207 to ptr) to i64
  %v1253 = icmp eq i64 %v1251, %v1252
  %v1254 = select i1 %v1253, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1255 = icmp eq ptr %v1254, inttoptr (i64 6 to ptr)
  br i1 %v1255, label %yes.1256, label %no.1257
yes.1256:
  br label %join.1258
no.1257:
  br label %join.1258
join.1258:
  %v1259 = phi ptr [ inttoptr (i64 5 to ptr), %yes.1256 ], [ inttoptr (i64 7 to ptr), %no.1257 ]
  br label %join.1250
join.1250:
  %v1260 = phi ptr [ inttoptr (i64 5 to ptr), %yes.1248 ], [ %v1259, %join.1258 ]
  br label %join.1242
join.1242:
  %v1261 = phi ptr [ inttoptr (i64 3 to ptr), %yes.1240 ], [ %v1260, %join.1250 ]
  br label %join.1234
join.1234:
  %v1262 = phi ptr [ inttoptr (i64 3 to ptr), %yes.1232 ], [ %v1261, %join.1242 ]
  br label %join.1226
join.1226:
  %v1263 = phi ptr [ inttoptr (i64 1 to ptr), %yes.1224 ], [ %v1262, %join.1234 ]
  br label %join.1218
join.1218:
  %v1264 = phi ptr [ inttoptr (i64 1 to ptr), %yes.1216 ], [ %v1263, %join.1226 ]
  %v1265 = getelementptr i8, ptr %a1, i64 8
  %v1266 = load i64, ptr %v1265, align 8, !tbaa !3
  %v1267 = getelementptr i8, ptr %a1, i64 16
  %v1268 = load ptr, ptr %v1267, align 8, !tbaa !3
  %v1269 = ptrtoint ptr %v1210 to i64
  %v1270 = ashr i64 %v1269, 1
  %v1271 = and i64 %v1269, 1
  %v1272 = icmp ne i64 %v1271, 0
  %v1273 = icmp ult i64 %v1270, %v1266
  %v1274 = and i1 %v1272, %v1273
  br i1 %v1274, label %array.valid.1275, label %array.invalid.1276
array.invalid.1276:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1275:
  %v1277 = getelementptr i8, ptr %v1268, i64 %v1270
  %v1278 = ptrtoint ptr %v1264 to i64
  %v1279 = ashr i64 %v1278, 1
  %v1280 = trunc i64 %v1279 to i8
  store i8 %v1280, ptr %v1277, align 1, !tbaa !4
  %v1281 = ptrtoint ptr %a4 to i64
  %v1282 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1283 = sub i64 %v1282, 1
  %v1284 = add nsw i64 %v1281, %v1283
  %v1285 = inttoptr i64 %v1284 to ptr
  %v1286 = musttail call ptr @mlf.numeric.17(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %v1285)
  ret ptr %v1286
tail.no.1172:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.numeric.38(ptr %a0, ptr %a1, ptr %a2) {
entry:
  %v605 = alloca [3 x ptr], align 8
  %v606 = getelementptr ptr, ptr %v605, i64 0
  store ptr %a0, ptr %v606, align 8
  %v607 = getelementptr ptr, ptr %v605, i64 1
  store ptr %a1, ptr %v607, align 8
  %v608 = getelementptr ptr, ptr %v605, i64 2
  store ptr %a2, ptr %v608, align 8
  call void @mlf_gc_check(i64 3, ptr %v605)
  %v609 = call ptr @mlf_get_byte_line()
  %v610 = getelementptr i8, ptr %v609, i64 8
  %v611 = load i64, ptr %v610, align 8, !tbaa !3
  %v612 = getelementptr i8, ptr %v609, i64 16
  %v613 = load ptr, ptr %v612, align 8, !tbaa !3
  %v614 = shl i64 %v611, 1
  %v615 = or i64 %v614, 1
  %v616 = inttoptr i64 %v615 to ptr
  %v617 = ptrtoint ptr %v616 to i64
  %v618 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v619 = and i64 %v617, %v618
  %v620 = and i64 %v619, 1
  %v621 = icmp ne i64 %v620, 0
  br i1 %v621, label %yes.622, label %no.623
yes.622:
  %v625 = icmp eq i64 %v617, %v618
  %v626 = select i1 %v625, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.624
no.623:
  %v627 = call ptr @mlf_eq_int(ptr %v616, ptr inttoptr (i64 1 to ptr))
  br label %join.624
join.624:
  %v628 = phi ptr [ %v626, %yes.622 ], [ %v627, %no.623 ]
  %v629 = icmp eq ptr %v628, inttoptr (i64 6 to ptr)
  br i1 %v629, label %tail.yes.630, label %tail.no.631
tail.yes.630:
  %v632 = call ptr @mlf.construct.wide(i64 1, i64 3)
  %v633 = getelementptr i8, ptr %v632, i64 24
  store ptr %a0, ptr %v633, align 8, !tbaa !3
  %v634 = getelementptr i8, ptr %v632, i64 32
  store ptr %a1, ptr %v634, align 8, !tbaa !3
  %v635 = getelementptr i8, ptr %v632, i64 40
  store ptr %a2, ptr %v635, align 8, !tbaa !3
  ret ptr %v632
tail.no.631:
  %v636 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v637 = ashr i64 %v636, 1
  %v638 = and i64 %v636, 1
  %v639 = icmp ne i64 %v638, 0
  %v640 = icmp ult i64 %v637, %v611
  %v641 = and i1 %v639, %v640
  br i1 %v641, label %array.valid.642, label %array.invalid.643
array.invalid.643:
  call void @mlf_bounds_failure()
  unreachable
array.valid.642:
  %v644 = getelementptr i8, ptr %v613, i64 %v637
  %v645 = load i8, ptr %v644, align 1, !tbaa !4
  %v646 = zext i8 %v645 to i64
  %v647 = shl i64 %v646, 1
  %v648 = or i64 %v647, 1
  %v649 = inttoptr i64 %v648 to ptr
  %v650 = ptrtoint ptr %v649 to i64
  %v651 = ptrtoint ptr inttoptr (i64 125 to ptr) to i64
  %v652 = icmp eq i64 %v650, %v651
  %v653 = select i1 %v652, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v654 = icmp eq ptr %v653, inttoptr (i64 6 to ptr)
  br i1 %v654, label %tail.yes.655, label %tail.no.656
tail.yes.655:
  %v657 = call ptr @mlf.construct.wide(i64 1, i64 3)
  %v658 = getelementptr i8, ptr %v657, i64 24
  store ptr %a0, ptr %v658, align 8, !tbaa !3
  %v659 = getelementptr i8, ptr %v657, i64 32
  store ptr %a1, ptr %v659, align 8, !tbaa !3
  %v660 = getelementptr i8, ptr %v657, i64 40
  store ptr %a2, ptr %v660, align 8, !tbaa !3
  ret ptr %v657
tail.no.656:
  %v835 = call ptr @mlf.numeric.11(ptr %v609, ptr %v616)
  %v836 = ptrtoint ptr %a1 to i64
  %v837 = ptrtoint ptr %v835 to i64
  %v838 = and i64 %v836, %v837
  %v839 = and i64 %v838, 1
  %v840 = icmp ne i64 %v839, 0
  br i1 %v840, label %yes.841, label %no.842
yes.841:
  %v844 = sub i64 %v837, 1
  %v845 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v836, i64 %v844)
  %v846 = extractvalue { i64, i1 } %v845, 0
  %v847 = extractvalue { i64, i1 } %v845, 1
  br i1 %v847, label %yes.848, label %no.849
yes.848:
  %v851 = call ptr @mlf_add_int(ptr %a1, ptr %v835)
  br label %join.850
no.849:
  %v852 = inttoptr i64 %v846 to ptr
  br label %join.850
join.850:
  %v853 = phi ptr [ %v851, %yes.848 ], [ %v852, %no.849 ]
  br label %join.843
no.842:
  %v854 = call ptr @mlf_add_int(ptr %a1, ptr %v835)
  br label %join.843
join.843:
  %v855 = phi ptr [ %v853, %join.850 ], [ %v854, %no.842 ]
  %v856 = ptrtoint ptr %a2 to i64
  %v857 = ptrtoint ptr %v855 to i64
  %v858 = and i64 %v856, %v857
  %v859 = and i64 %v858, 1
  %v860 = icmp ne i64 %v859, 0
  br i1 %v860, label %yes.861, label %no.862
yes.861:
  %v864 = icmp slt i64 %v856, %v857
  %v865 = select i1 %v864, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.863
no.862:
  %v866 = call ptr @mlf_lt_int(ptr %a2, ptr %v855)
  br label %join.863
join.863:
  %v867 = phi ptr [ %v865, %yes.861 ], [ %v866, %no.862 ]
  %v868 = icmp eq ptr %v867, inttoptr (i64 6 to ptr)
  br i1 %v868, label %tail.yes.869, label %tail.no.870
tail.yes.869:
  %v915 = call ptr @mlf.numeric.8(ptr %a2, ptr %v855)
  %v916 = call ptr @mlf_new_array(i64 35, ptr %v915, ptr inttoptr (i64 1 to ptr))
  %v1030 = call ptr @mlf.numeric.0(ptr %a0, ptr %v916, ptr %a1, ptr inttoptr (i64 1 to ptr), ptr inttoptr (i64 1 to ptr))
  %v1287 = call ptr @mlf.numeric.17(ptr %v609, ptr %v916, ptr %v835, ptr %a1, ptr inttoptr (i64 1 to ptr))
  %v1288 = musttail call ptr @mlf.numeric.38(ptr %v916, ptr %v855, ptr %v915)
  ret ptr %v1288
tail.no.870:
  %v1289 = call ptr @mlf.numeric.17(ptr %v609, ptr %a0, ptr %v835, ptr %a1, ptr inttoptr (i64 1 to ptr))
  %v1290 = musttail call ptr @mlf.numeric.38(ptr %a0, ptr %v855, ptr %a2)
  ret ptr %v1290
}

define private ptr @mlf.code.1301(ptr %env, ptr %arg) {
entry:
  %v1302 = getelementptr i8, ptr %env, i64 8
  %v1303 = load ptr, ptr %v1302, align 8, !tbaa !3
  %v1304 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1304, align 8, !tbaa !3
  %v1305 = call ptr @mlf_prim1(i64 38, ptr %v1303)
  ret ptr %v1305
}

define private ptr @mlf.code.1330(ptr %env, ptr %arg) {
entry:
  %v1331 = getelementptr i8, ptr %env, i64 8
  %v1332 = load ptr, ptr %v1331, align 8, !tbaa !3
  %v1333 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1333, align 8, !tbaa !3
  %v1334 = call ptr @mlf_prim2(i64 36, ptr %v1332, ptr inttoptr (i64 1 to ptr))
  ret ptr %v1334
}

define private ptr @mlf.code.1397(ptr %env, ptr %arg) {
entry:
  %v1398 = getelementptr i8, ptr %env, i64 8
  %v1399 = load ptr, ptr %v1398, align 8, !tbaa !3
  %v1400 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1400, align 8, !tbaa !3
  %v1401 = call ptr @mlf.force(ptr %v1399)
  %v1402 = call ptr @mlf_prim2(i64 9, ptr %v1401, ptr inttoptr (i64 3 to ptr))
  ret ptr %v1402
}

define private ptr @mlf.code.1390(ptr %env, ptr %arg) {
entry:
  %v1391 = getelementptr i8, ptr %env, i64 8
  %v1392 = load ptr, ptr %v1391, align 8, !tbaa !3
  %v1393 = getelementptr i8, ptr %env, i64 16
  %v1394 = load ptr, ptr %v1393, align 8, !tbaa !3
  %v1395 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1395, align 8, !tbaa !3
  %v1396 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1396, align 8, !tbaa !3
  %v1403 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1397, i64 1)
  %v1404 = getelementptr i8, ptr %v1403, i64 16
  %v1405 = load ptr, ptr %v1404, align 8, !tbaa !3
  %v1406 = getelementptr i8, ptr %v1405, i64 8
  store ptr %v1394, ptr %v1406, align 8, !tbaa !3
  %v1407 = call ptr @mlf_prim2(i64 36, ptr %v1392, ptr %v1403)
  ret ptr %v1407
}

define private ptr @mlf.code.1413(ptr %env, ptr %arg) {
entry:
  %v1414 = getelementptr i8, ptr %env, i64 8
  %v1415 = load ptr, ptr %v1414, align 8, !tbaa !3
  %v1416 = getelementptr i8, ptr %env, i64 16
  %v1417 = load ptr, ptr %v1416, align 8, !tbaa !3
  %v1418 = call ptr @mlf.force(ptr %arg)
  %v1419 = call ptr @mlf_prim2(i64 10, ptr %v1418, ptr inttoptr (i64 21 to ptr))
  %v1420 = icmp eq ptr %v1419, inttoptr (i64 6 to ptr)
  br i1 %v1420, label %yes.1421, label %no.1422
yes.1421:
  %v1424 = call ptr @mlf.force(ptr %v1417)
  %v1425 = call ptr @mlf_prim2(i64 9, ptr %v1424, ptr inttoptr (i64 3 to ptr))
  %v1426 = call ptr @mlf_env_new(i64 2)
  %v1427 = getelementptr i8, ptr %v1426, i64 8
  store ptr %v1415, ptr %v1427, align 8, !tbaa !3
  %v1428 = getelementptr i8, ptr %v1426, i64 16
  store ptr %v1425, ptr %v1428, align 8, !tbaa !3
  %v1429 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1368, ptr %v1426)
  br label %join.1423
no.1422:
  %v1430 = call ptr @mlf_prim2(i64 10, ptr %v1418, ptr inttoptr (i64 27 to ptr))
  %v1431 = icmp eq ptr %v1430, inttoptr (i64 6 to ptr)
  br i1 %v1431, label %yes.1432, label %no.1433
yes.1432:
  %v1435 = call ptr @mlf.force(ptr %v1417)
  %v1436 = call ptr @mlf_prim2(i64 9, ptr %v1435, ptr inttoptr (i64 3 to ptr))
  %v1437 = call ptr @mlf_env_new(i64 2)
  %v1438 = getelementptr i8, ptr %v1437, i64 8
  store ptr %v1415, ptr %v1438, align 8, !tbaa !3
  %v1439 = getelementptr i8, ptr %v1437, i64 16
  store ptr %v1436, ptr %v1439, align 8, !tbaa !3
  %v1440 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1368, ptr %v1437)
  br label %join.1434
no.1433:
  %v1441 = call ptr @mlf_prim1(i64 0, ptr %v1417)
  br label %join.1434
join.1434:
  %v1442 = phi ptr [ %v1440, %yes.1432 ], [ %v1441, %no.1433 ]
  br label %join.1423
join.1423:
  %v1443 = phi ptr [ %v1429, %yes.1421 ], [ %v1442, %join.1434 ]
  ret ptr %v1443
}

define private ptr @mlf.worker.11(ptr %a0, ptr %a1) {
entry:
  %v1384 = call ptr @mlf_prim2(i64 10, ptr %a1, ptr inttoptr (i64 1 to ptr))
  %v1385 = icmp eq ptr %v1384, inttoptr (i64 6 to ptr)
  br i1 %v1385, label %yes.1386, label %no.1387
yes.1386:
  %v1389 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 1 to ptr))
  br label %join.1388
no.1387:
  %v1408 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1390, i64 2)
  %v1409 = getelementptr i8, ptr %v1408, i64 16
  %v1410 = load ptr, ptr %v1409, align 8, !tbaa !3
  %v1411 = getelementptr i8, ptr %v1410, i64 8
  store ptr %a0, ptr %v1411, align 8, !tbaa !3
  %v1412 = getelementptr i8, ptr %v1410, i64 16
  store ptr %a1, ptr %v1412, align 8, !tbaa !3
  %v1444 = call ptr @mlf_env_new(i64 2)
  %v1445 = getelementptr i8, ptr %v1444, i64 8
  store ptr %a0, ptr %v1445, align 8, !tbaa !3
  %v1446 = getelementptr i8, ptr %v1444, i64 16
  store ptr %a1, ptr %v1446, align 8, !tbaa !3
  %v1447 = call ptr @mlf_closure(ptr @mlf.code.1413, ptr %v1444)
  %v1448 = call ptr @mlf_prim2(i64 1, ptr %v1408, ptr %v1447)
  br label %join.1388
join.1388:
  %v1449 = phi ptr [ %v1389, %yes.1386 ], [ %v1448, %no.1387 ]
  ret ptr %v1449
}

define private ptr @mlf.numeric.entry.1368(ptr %env, ptr %arg) {
entry:
  %v1369 = getelementptr i8, ptr %env, i64 8
  %v1370 = load ptr, ptr %v1369, align 8, !tbaa !3
  %v1371 = getelementptr i8, ptr %env, i64 16
  %v1372 = load ptr, ptr %v1371, align 8, !tbaa !3
  %v1373 = call ptr @mlf_peek(ptr %v1370)
  %v1374 = call ptr @mlf_peek(ptr %v1372)
  %v1375 = icmp ne ptr %v1373, null
  %v1376 = icmp ne ptr %v1374, null
  %v1377 = and i1 true, %v1375
  %v1378 = and i1 %v1377, %v1376
  br i1 %v1378, label %yes.1379, label %no.1380
yes.1379:
  %v1382 = call ptr @mlf.numeric.11(ptr %v1373, ptr %v1374)
  %v1383 = call ptr @mlf_prim1(i64 0, ptr %v1382)
  br label %join.1381
no.1380:
  %v1450 = call ptr @mlf.force(ptr %v1372)
  %v1451 = call ptr @mlf.worker.11(ptr %v1370, ptr %v1450)
  br label %join.1381
join.1381:
  %v1452 = phi ptr [ %v1383, %yes.1379 ], [ %v1451, %no.1380 ]
  ret ptr %v1452
}

define private ptr @mlf.code.1361(ptr %env, ptr %arg) {
entry:
  %v1362 = getelementptr i8, ptr %env, i64 8
  %v1363 = load ptr, ptr %v1362, align 8, !tbaa !3
  %v1364 = getelementptr i8, ptr %env, i64 16
  %v1365 = load ptr, ptr %v1364, align 8, !tbaa !3
  %v1366 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1366, align 8, !tbaa !3
  %v1367 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1367, align 8, !tbaa !3
  %v1453 = call ptr @mlf.force(ptr %v1365)
  %v1454 = call ptr @mlf_env_new(i64 2)
  %v1455 = getelementptr i8, ptr %v1454, i64 8
  store ptr %v1363, ptr %v1455, align 8, !tbaa !3
  %v1456 = getelementptr i8, ptr %v1454, i64 16
  store ptr %v1453, ptr %v1456, align 8, !tbaa !3
  %v1457 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1368, ptr %v1454)
  ret ptr %v1457
}

define private ptr @mlf.worker.8(ptr %a0, ptr %a1) {
entry:
  %v1504 = call ptr @mlf_prim2(i64 11, ptr %a0, ptr %a1)
  %v1505 = icmp eq ptr %v1504, inttoptr (i64 6 to ptr)
  br i1 %v1505, label %yes.1506, label %no.1507
yes.1506:
  %v1509 = call ptr @mlf_prim2(i64 14, ptr %a0, ptr inttoptr (i64 5 to ptr))
  %v1510 = call ptr @mlf_env_new(i64 2)
  %v1511 = getelementptr i8, ptr %v1510, i64 8
  store ptr %v1509, ptr %v1511, align 8, !tbaa !3
  %v1512 = getelementptr i8, ptr %v1510, i64 16
  store ptr %a1, ptr %v1512, align 8, !tbaa !3
  %v1513 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1488, ptr %v1510)
  br label %join.1508
no.1507:
  %v1514 = call ptr @mlf_prim1(i64 0, ptr %a0)
  br label %join.1508
join.1508:
  %v1515 = phi ptr [ %v1513, %yes.1506 ], [ %v1514, %no.1507 ]
  ret ptr %v1515
}

define private ptr @mlf.numeric.entry.1488(ptr %env, ptr %arg) {
entry:
  %v1489 = getelementptr i8, ptr %env, i64 8
  %v1490 = load ptr, ptr %v1489, align 8, !tbaa !3
  %v1491 = getelementptr i8, ptr %env, i64 16
  %v1492 = load ptr, ptr %v1491, align 8, !tbaa !3
  %v1493 = call ptr @mlf_peek(ptr %v1490)
  %v1494 = call ptr @mlf_peek(ptr %v1492)
  %v1495 = icmp ne ptr %v1493, null
  %v1496 = icmp ne ptr %v1494, null
  %v1497 = and i1 true, %v1495
  %v1498 = and i1 %v1497, %v1496
  br i1 %v1498, label %yes.1499, label %no.1500
yes.1499:
  %v1502 = call ptr @mlf.numeric.8(ptr %v1493, ptr %v1494)
  %v1503 = call ptr @mlf_prim1(i64 0, ptr %v1502)
  br label %join.1501
no.1500:
  %v1516 = call ptr @mlf.force(ptr %v1490)
  %v1517 = call ptr @mlf.force(ptr %v1492)
  %v1518 = call ptr @mlf.worker.8(ptr %v1516, ptr %v1517)
  br label %join.1501
join.1501:
  %v1519 = phi ptr [ %v1503, %yes.1499 ], [ %v1518, %no.1500 ]
  ret ptr %v1519
}

define private ptr @mlf.code.1481(ptr %env, ptr %arg) {
entry:
  %v1482 = getelementptr i8, ptr %env, i64 8
  %v1483 = load ptr, ptr %v1482, align 8, !tbaa !3
  %v1484 = getelementptr i8, ptr %env, i64 16
  %v1485 = load ptr, ptr %v1484, align 8, !tbaa !3
  %v1486 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1486, align 8, !tbaa !3
  %v1487 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1487, align 8, !tbaa !3
  %v1520 = call ptr @mlf.force(ptr %v1483)
  %v1521 = call ptr @mlf.force(ptr %v1485)
  %v1522 = call ptr @mlf_env_new(i64 2)
  %v1523 = getelementptr i8, ptr %v1522, i64 8
  store ptr %v1520, ptr %v1523, align 8, !tbaa !3
  %v1524 = getelementptr i8, ptr %v1522, i64 16
  store ptr %v1521, ptr %v1524, align 8, !tbaa !3
  %v1525 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1488, ptr %v1522)
  ret ptr %v1525
}

define private ptr @mlf.code.1542(ptr %env, ptr %arg) {
entry:
  %v1543 = getelementptr i8, ptr %env, i64 8
  %v1544 = load ptr, ptr %v1543, align 8, !tbaa !3
  %v1545 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1545, align 8, !tbaa !3
  %v1546 = call ptr @mlf_prim2(i64 35, ptr %v1544, ptr inttoptr (i64 1 to ptr))
  ret ptr %v1546
}

define private ptr @mlf.code.1610(ptr %env, ptr %arg) {
entry:
  %v1611 = getelementptr i8, ptr %env, i64 8
  %v1612 = load ptr, ptr %v1611, align 8, !tbaa !3
  %v1613 = getelementptr i8, ptr %env, i64 16
  %v1614 = load ptr, ptr %v1613, align 8, !tbaa !3
  %v1615 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1615, align 8, !tbaa !3
  %v1616 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1616, align 8, !tbaa !3
  %v1617 = call ptr @mlf_prim2(i64 36, ptr %v1612, ptr %v1614)
  ret ptr %v1617
}

define private ptr @mlf.code.1647(ptr %env, ptr %arg) {
entry:
  %v1648 = getelementptr i8, ptr %env, i64 8
  %v1649 = load ptr, ptr %v1648, align 8, !tbaa !3
  %v1650 = getelementptr i8, ptr %env, i64 16
  %v1651 = load ptr, ptr %v1650, align 8, !tbaa !3
  %v1652 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1652, align 8, !tbaa !3
  %v1653 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1653, align 8, !tbaa !3
  %v1654 = call ptr @mlf.force(ptr %v1649)
  %v1655 = call ptr @mlf.force(ptr %v1651)
  %v1656 = call ptr @mlf_prim2(i64 8, ptr %v1654, ptr %v1655)
  ret ptr %v1656
}

define private ptr @mlf.code.1634(ptr %env, ptr %arg) {
entry:
  %v1635 = getelementptr i8, ptr %env, i64 8
  %v1636 = load ptr, ptr %v1635, align 8, !tbaa !3
  %v1637 = getelementptr i8, ptr %env, i64 16
  %v1638 = load ptr, ptr %v1637, align 8, !tbaa !3
  %v1639 = getelementptr i8, ptr %env, i64 24
  %v1640 = load ptr, ptr %v1639, align 8, !tbaa !3
  %v1641 = getelementptr i8, ptr %env, i64 32
  %v1642 = load ptr, ptr %v1641, align 8, !tbaa !3
  %v1643 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1643, align 8, !tbaa !3
  %v1644 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1644, align 8, !tbaa !3
  %v1645 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v1645, align 8, !tbaa !3
  %v1646 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v1646, align 8, !tbaa !3
  %v1657 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1647, i64 2)
  %v1658 = getelementptr i8, ptr %v1657, i64 16
  %v1659 = load ptr, ptr %v1658, align 8, !tbaa !3
  %v1660 = getelementptr i8, ptr %v1659, i64 8
  store ptr %v1638, ptr %v1660, align 8, !tbaa !3
  %v1661 = getelementptr i8, ptr %v1659, i64 16
  store ptr %v1640, ptr %v1661, align 8, !tbaa !3
  %v1662 = call ptr @mlf_prim3(i64 37, ptr %v1636, ptr %v1657, ptr %v1642)
  ret ptr %v1662
}

define private ptr @mlf.code.1670(ptr %env, ptr %arg) {
entry:
  %v1671 = getelementptr i8, ptr %env, i64 8
  %v1672 = load ptr, ptr %v1671, align 8, !tbaa !3
  %v1673 = getelementptr i8, ptr %env, i64 16
  %v1674 = load ptr, ptr %v1673, align 8, !tbaa !3
  %v1675 = getelementptr i8, ptr %env, i64 24
  %v1676 = load ptr, ptr %v1675, align 8, !tbaa !3
  %v1677 = getelementptr i8, ptr %env, i64 32
  %v1678 = load ptr, ptr %v1677, align 8, !tbaa !3
  %v1679 = getelementptr i8, ptr %env, i64 40
  %v1680 = load ptr, ptr %v1679, align 8, !tbaa !3
  %v1681 = call ptr @mlf.force(ptr %v1676)
  %v1682 = call ptr @mlf.force(ptr %v1680)
  %v1683 = call ptr @mlf_prim2(i64 8, ptr %v1682, ptr inttoptr (i64 3 to ptr))
  %v1684 = call ptr @mlf_env_new(i64 5)
  %v1685 = getelementptr i8, ptr %v1684, i64 8
  store ptr %v1672, ptr %v1685, align 8, !tbaa !3
  %v1686 = getelementptr i8, ptr %v1684, i64 16
  store ptr %v1674, ptr %v1686, align 8, !tbaa !3
  %v1687 = getelementptr i8, ptr %v1684, i64 24
  store ptr %v1681, ptr %v1687, align 8, !tbaa !3
  %v1688 = getelementptr i8, ptr %v1684, i64 32
  store ptr %v1678, ptr %v1688, align 8, !tbaa !3
  %v1689 = getelementptr i8, ptr %v1684, i64 40
  store ptr %v1683, ptr %v1689, align 8, !tbaa !3
  %v1690 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1574, ptr %v1684)
  ret ptr %v1690
}

define private ptr @mlf.code.1623(ptr %env, ptr %arg) {
entry:
  %v1624 = getelementptr i8, ptr %env, i64 8
  %v1625 = load ptr, ptr %v1624, align 8, !tbaa !3
  %v1626 = getelementptr i8, ptr %env, i64 16
  %v1627 = load ptr, ptr %v1626, align 8, !tbaa !3
  %v1628 = getelementptr i8, ptr %env, i64 24
  %v1629 = load ptr, ptr %v1628, align 8, !tbaa !3
  %v1630 = getelementptr i8, ptr %env, i64 32
  %v1631 = load ptr, ptr %v1630, align 8, !tbaa !3
  %v1632 = getelementptr i8, ptr %env, i64 40
  %v1633 = load ptr, ptr %v1632, align 8, !tbaa !3
  %v1663 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1634, i64 4)
  %v1664 = getelementptr i8, ptr %v1663, i64 16
  %v1665 = load ptr, ptr %v1664, align 8, !tbaa !3
  %v1666 = getelementptr i8, ptr %v1665, i64 8
  store ptr %v1627, ptr %v1666, align 8, !tbaa !3
  %v1667 = getelementptr i8, ptr %v1665, i64 16
  store ptr %v1631, ptr %v1667, align 8, !tbaa !3
  %v1668 = getelementptr i8, ptr %v1665, i64 24
  store ptr %v1633, ptr %v1668, align 8, !tbaa !3
  %v1669 = getelementptr i8, ptr %v1665, i64 32
  store ptr %arg, ptr %v1669, align 8, !tbaa !3
  %v1691 = call ptr @mlf_env_new(i64 5)
  %v1692 = getelementptr i8, ptr %v1691, i64 8
  store ptr %v1625, ptr %v1692, align 8, !tbaa !3
  %v1693 = getelementptr i8, ptr %v1691, i64 16
  store ptr %v1627, ptr %v1693, align 8, !tbaa !3
  %v1694 = getelementptr i8, ptr %v1691, i64 24
  store ptr %v1629, ptr %v1694, align 8, !tbaa !3
  %v1695 = getelementptr i8, ptr %v1691, i64 32
  store ptr %v1631, ptr %v1695, align 8, !tbaa !3
  %v1696 = getelementptr i8, ptr %v1691, i64 40
  store ptr %v1633, ptr %v1696, align 8, !tbaa !3
  %v1697 = call ptr @mlf_closure(ptr @mlf.code.1670, ptr %v1691)
  %v1698 = call ptr @mlf_prim2(i64 1, ptr %v1663, ptr %v1697)
  ret ptr %v1698
}

define private ptr @mlf.worker.0(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) {
entry:
  %v1605 = call ptr @mlf_prim2(i64 11, ptr %a4, ptr %a2)
  %v1606 = icmp eq ptr %v1605, inttoptr (i64 6 to ptr)
  br i1 %v1606, label %yes.1607, label %no.1608
yes.1607:
  %v1618 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1610, i64 2)
  %v1619 = getelementptr i8, ptr %v1618, i64 16
  %v1620 = load ptr, ptr %v1619, align 8, !tbaa !3
  %v1621 = getelementptr i8, ptr %v1620, i64 8
  store ptr %a0, ptr %v1621, align 8, !tbaa !3
  %v1622 = getelementptr i8, ptr %v1620, i64 16
  store ptr %a4, ptr %v1622, align 8, !tbaa !3
  %v1699 = call ptr @mlf_env_new(i64 5)
  %v1700 = getelementptr i8, ptr %v1699, i64 8
  store ptr %a0, ptr %v1700, align 8, !tbaa !3
  %v1701 = getelementptr i8, ptr %v1699, i64 16
  store ptr %a1, ptr %v1701, align 8, !tbaa !3
  %v1702 = getelementptr i8, ptr %v1699, i64 24
  store ptr %a2, ptr %v1702, align 8, !tbaa !3
  %v1703 = getelementptr i8, ptr %v1699, i64 32
  store ptr %a3, ptr %v1703, align 8, !tbaa !3
  %v1704 = getelementptr i8, ptr %v1699, i64 40
  store ptr %a4, ptr %v1704, align 8, !tbaa !3
  %v1705 = call ptr @mlf_closure(ptr @mlf.code.1623, ptr %v1699)
  %v1706 = call ptr @mlf_prim2(i64 1, ptr %v1618, ptr %v1705)
  br label %join.1609
no.1608:
  %v1707 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.1609
join.1609:
  %v1708 = phi ptr [ %v1706, %yes.1607 ], [ %v1707, %no.1608 ]
  ret ptr %v1708
}

define private ptr @mlf.numeric.entry.1574(ptr %env, ptr %arg) {
entry:
  %v1575 = getelementptr i8, ptr %env, i64 8
  %v1576 = load ptr, ptr %v1575, align 8, !tbaa !3
  %v1577 = getelementptr i8, ptr %env, i64 16
  %v1578 = load ptr, ptr %v1577, align 8, !tbaa !3
  %v1579 = getelementptr i8, ptr %env, i64 24
  %v1580 = load ptr, ptr %v1579, align 8, !tbaa !3
  %v1581 = getelementptr i8, ptr %env, i64 32
  %v1582 = load ptr, ptr %v1581, align 8, !tbaa !3
  %v1583 = getelementptr i8, ptr %env, i64 40
  %v1584 = load ptr, ptr %v1583, align 8, !tbaa !3
  %v1585 = call ptr @mlf_peek(ptr %v1576)
  %v1586 = call ptr @mlf_peek(ptr %v1578)
  %v1587 = call ptr @mlf_peek(ptr %v1580)
  %v1588 = call ptr @mlf_peek(ptr %v1582)
  %v1589 = call ptr @mlf_peek(ptr %v1584)
  %v1590 = icmp ne ptr %v1585, null
  %v1591 = icmp ne ptr %v1586, null
  %v1592 = icmp ne ptr %v1587, null
  %v1593 = icmp ne ptr %v1588, null
  %v1594 = icmp ne ptr %v1589, null
  %v1595 = and i1 true, %v1590
  %v1596 = and i1 %v1595, %v1591
  %v1597 = and i1 %v1596, %v1592
  %v1598 = and i1 %v1597, %v1593
  %v1599 = and i1 %v1598, %v1594
  br i1 %v1599, label %yes.1600, label %no.1601
yes.1600:
  %v1603 = call ptr @mlf.numeric.0(ptr %v1585, ptr %v1586, ptr %v1587, ptr %v1588, ptr %v1589)
  %v1604 = call ptr @mlf_prim1(i64 0, ptr %v1603)
  br label %join.1602
no.1601:
  %v1709 = call ptr @mlf.force(ptr %v1580)
  %v1710 = call ptr @mlf.force(ptr %v1584)
  %v1711 = call ptr @mlf.worker.0(ptr %v1576, ptr %v1578, ptr %v1709, ptr %v1582, ptr %v1710)
  br label %join.1602
join.1602:
  %v1712 = phi ptr [ %v1604, %yes.1600 ], [ %v1711, %no.1601 ]
  ret ptr %v1712
}

define private ptr @mlf.code.1564(ptr %env, ptr %arg) {
entry:
  %v1565 = getelementptr i8, ptr %env, i64 8
  %v1566 = load ptr, ptr %v1565, align 8, !tbaa !3
  %v1567 = getelementptr i8, ptr %env, i64 16
  %v1568 = load ptr, ptr %v1567, align 8, !tbaa !3
  %v1569 = getelementptr i8, ptr %env, i64 24
  %v1570 = load ptr, ptr %v1569, align 8, !tbaa !3
  %v1571 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1571, align 8, !tbaa !3
  %v1572 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1572, align 8, !tbaa !3
  %v1573 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v1573, align 8, !tbaa !3
  %v1713 = call ptr @mlf.force(ptr %v1568)
  %v1714 = call ptr @mlf_env_new(i64 5)
  %v1715 = getelementptr i8, ptr %v1714, i64 8
  store ptr %v1566, ptr %v1715, align 8, !tbaa !3
  %v1716 = getelementptr i8, ptr %v1714, i64 16
  store ptr %v1570, ptr %v1716, align 8, !tbaa !3
  %v1717 = getelementptr i8, ptr %v1714, i64 24
  store ptr %v1713, ptr %v1717, align 8, !tbaa !3
  %v1718 = getelementptr i8, ptr %v1714, i64 32
  store ptr inttoptr (i64 1 to ptr), ptr %v1718, align 8, !tbaa !3
  %v1719 = getelementptr i8, ptr %v1714, i64 40
  store ptr inttoptr (i64 1 to ptr), ptr %v1719, align 8, !tbaa !3
  %v1720 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1574, ptr %v1714)
  ret ptr %v1720
}

define private ptr @mlf.code.1789(ptr %env, ptr %arg) {
entry:
  %v1790 = getelementptr i8, ptr %env, i64 8
  %v1791 = load ptr, ptr %v1790, align 8, !tbaa !3
  %v1792 = getelementptr i8, ptr %env, i64 16
  %v1793 = load ptr, ptr %v1792, align 8, !tbaa !3
  %v1794 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1794, align 8, !tbaa !3
  %v1795 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1795, align 8, !tbaa !3
  %v1796 = call ptr @mlf_prim2(i64 36, ptr %v1791, ptr %v1793)
  ret ptr %v1796
}

define private ptr @mlf.code.1826(ptr %env, ptr %arg) {
entry:
  %v1827 = getelementptr i8, ptr %env, i64 8
  %v1828 = load ptr, ptr %v1827, align 8, !tbaa !3
  %v1829 = getelementptr i8, ptr %env, i64 16
  %v1830 = load ptr, ptr %v1829, align 8, !tbaa !3
  %v1831 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1831, align 8, !tbaa !3
  %v1832 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1832, align 8, !tbaa !3
  %v1833 = call ptr @mlf.force(ptr %v1828)
  %v1834 = call ptr @mlf.force(ptr %v1830)
  %v1835 = call ptr @mlf_prim2(i64 8, ptr %v1833, ptr %v1834)
  ret ptr %v1835
}

define private ptr @mlf.worker.15(ptr %a0) {
entry:
  %v1845 = call ptr @mlf_prim2(i64 10, ptr %a0, ptr inttoptr (i64 131 to ptr))
  %v1846 = icmp eq ptr %v1845, inttoptr (i64 6 to ptr)
  br i1 %v1846, label %yes.1847, label %no.1848
yes.1847:
  br label %join.1849
no.1848:
  %v1850 = call ptr @mlf_prim2(i64 10, ptr %a0, ptr inttoptr (i64 195 to ptr))
  %v1851 = icmp eq ptr %v1850, inttoptr (i64 6 to ptr)
  br i1 %v1851, label %yes.1852, label %no.1853
yes.1852:
  br label %join.1854
no.1853:
  %v1855 = call ptr @mlf_prim2(i64 10, ptr %a0, ptr inttoptr (i64 135 to ptr))
  %v1856 = icmp eq ptr %v1855, inttoptr (i64 6 to ptr)
  br i1 %v1856, label %yes.1857, label %no.1858
yes.1857:
  br label %join.1859
no.1858:
  %v1860 = call ptr @mlf_prim2(i64 10, ptr %a0, ptr inttoptr (i64 199 to ptr))
  %v1861 = icmp eq ptr %v1860, inttoptr (i64 6 to ptr)
  br i1 %v1861, label %yes.1862, label %no.1863
yes.1862:
  br label %join.1864
no.1863:
  %v1865 = call ptr @mlf_prim2(i64 10, ptr %a0, ptr inttoptr (i64 143 to ptr))
  %v1866 = icmp eq ptr %v1865, inttoptr (i64 6 to ptr)
  br i1 %v1866, label %yes.1867, label %no.1868
yes.1867:
  br label %join.1869
no.1868:
  %v1870 = call ptr @mlf_prim2(i64 10, ptr %a0, ptr inttoptr (i64 207 to ptr))
  %v1871 = icmp eq ptr %v1870, inttoptr (i64 6 to ptr)
  br i1 %v1871, label %yes.1872, label %no.1873
yes.1872:
  br label %join.1874
no.1873:
  br label %join.1874
join.1874:
  %v1875 = phi ptr [ inttoptr (i64 5 to ptr), %yes.1872 ], [ inttoptr (i64 7 to ptr), %no.1873 ]
  br label %join.1869
join.1869:
  %v1876 = phi ptr [ inttoptr (i64 5 to ptr), %yes.1867 ], [ %v1875, %join.1874 ]
  br label %join.1864
join.1864:
  %v1877 = phi ptr [ inttoptr (i64 3 to ptr), %yes.1862 ], [ %v1876, %join.1869 ]
  br label %join.1859
join.1859:
  %v1878 = phi ptr [ inttoptr (i64 3 to ptr), %yes.1857 ], [ %v1877, %join.1864 ]
  br label %join.1854
join.1854:
  %v1879 = phi ptr [ inttoptr (i64 1 to ptr), %yes.1852 ], [ %v1878, %join.1859 ]
  br label %join.1849
join.1849:
  %v1880 = phi ptr [ inttoptr (i64 1 to ptr), %yes.1847 ], [ %v1879, %join.1854 ]
  ret ptr %v1880
}

define private ptr @mlf.code.1841(ptr %env, ptr %arg) {
entry:
  %v1842 = getelementptr i8, ptr %env, i64 8
  %v1843 = load ptr, ptr %v1842, align 8, !tbaa !3
  %v1844 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1844, align 8, !tbaa !3
  %v1881 = call ptr @mlf.force(ptr %v1843)
  %v1882 = call ptr @mlf.worker.15(ptr %v1881)
  ret ptr %v1882
}

define private ptr @mlf.code.1813(ptr %env, ptr %arg) {
entry:
  %v1814 = getelementptr i8, ptr %env, i64 8
  %v1815 = load ptr, ptr %v1814, align 8, !tbaa !3
  %v1816 = getelementptr i8, ptr %env, i64 16
  %v1817 = load ptr, ptr %v1816, align 8, !tbaa !3
  %v1818 = getelementptr i8, ptr %env, i64 24
  %v1819 = load ptr, ptr %v1818, align 8, !tbaa !3
  %v1820 = getelementptr i8, ptr %env, i64 32
  %v1821 = load ptr, ptr %v1820, align 8, !tbaa !3
  %v1822 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1822, align 8, !tbaa !3
  %v1823 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1823, align 8, !tbaa !3
  %v1824 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v1824, align 8, !tbaa !3
  %v1825 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v1825, align 8, !tbaa !3
  %v1836 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1826, i64 2)
  %v1837 = getelementptr i8, ptr %v1836, i64 16
  %v1838 = load ptr, ptr %v1837, align 8, !tbaa !3
  %v1839 = getelementptr i8, ptr %v1838, i64 8
  store ptr %v1817, ptr %v1839, align 8, !tbaa !3
  %v1840 = getelementptr i8, ptr %v1838, i64 16
  store ptr %v1819, ptr %v1840, align 8, !tbaa !3
  %v1883 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1841, i64 1)
  %v1884 = getelementptr i8, ptr %v1883, i64 16
  %v1885 = load ptr, ptr %v1884, align 8, !tbaa !3
  %v1886 = getelementptr i8, ptr %v1885, i64 8
  store ptr %v1821, ptr %v1886, align 8, !tbaa !3
  %v1887 = call ptr @mlf_prim3(i64 37, ptr %v1815, ptr %v1836, ptr %v1883)
  ret ptr %v1887
}

define private ptr @mlf.code.1895(ptr %env, ptr %arg) {
entry:
  %v1896 = getelementptr i8, ptr %env, i64 8
  %v1897 = load ptr, ptr %v1896, align 8, !tbaa !3
  %v1898 = getelementptr i8, ptr %env, i64 16
  %v1899 = load ptr, ptr %v1898, align 8, !tbaa !3
  %v1900 = getelementptr i8, ptr %env, i64 24
  %v1901 = load ptr, ptr %v1900, align 8, !tbaa !3
  %v1902 = getelementptr i8, ptr %env, i64 32
  %v1903 = load ptr, ptr %v1902, align 8, !tbaa !3
  %v1904 = getelementptr i8, ptr %env, i64 40
  %v1905 = load ptr, ptr %v1904, align 8, !tbaa !3
  %v1906 = call ptr @mlf.force(ptr %v1901)
  %v1907 = call ptr @mlf.force(ptr %v1905)
  %v1908 = call ptr @mlf_prim2(i64 8, ptr %v1907, ptr inttoptr (i64 3 to ptr))
  %v1909 = call ptr @mlf_env_new(i64 5)
  %v1910 = getelementptr i8, ptr %v1909, i64 8
  store ptr %v1897, ptr %v1910, align 8, !tbaa !3
  %v1911 = getelementptr i8, ptr %v1909, i64 16
  store ptr %v1899, ptr %v1911, align 8, !tbaa !3
  %v1912 = getelementptr i8, ptr %v1909, i64 24
  store ptr %v1906, ptr %v1912, align 8, !tbaa !3
  %v1913 = getelementptr i8, ptr %v1909, i64 32
  store ptr %v1903, ptr %v1913, align 8, !tbaa !3
  %v1914 = getelementptr i8, ptr %v1909, i64 40
  store ptr %v1908, ptr %v1914, align 8, !tbaa !3
  %v1915 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1753, ptr %v1909)
  ret ptr %v1915
}

define private ptr @mlf.code.1802(ptr %env, ptr %arg) {
entry:
  %v1803 = getelementptr i8, ptr %env, i64 8
  %v1804 = load ptr, ptr %v1803, align 8, !tbaa !3
  %v1805 = getelementptr i8, ptr %env, i64 16
  %v1806 = load ptr, ptr %v1805, align 8, !tbaa !3
  %v1807 = getelementptr i8, ptr %env, i64 24
  %v1808 = load ptr, ptr %v1807, align 8, !tbaa !3
  %v1809 = getelementptr i8, ptr %env, i64 32
  %v1810 = load ptr, ptr %v1809, align 8, !tbaa !3
  %v1811 = getelementptr i8, ptr %env, i64 40
  %v1812 = load ptr, ptr %v1811, align 8, !tbaa !3
  %v1888 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1813, i64 4)
  %v1889 = getelementptr i8, ptr %v1888, i64 16
  %v1890 = load ptr, ptr %v1889, align 8, !tbaa !3
  %v1891 = getelementptr i8, ptr %v1890, i64 8
  store ptr %v1806, ptr %v1891, align 8, !tbaa !3
  %v1892 = getelementptr i8, ptr %v1890, i64 16
  store ptr %v1810, ptr %v1892, align 8, !tbaa !3
  %v1893 = getelementptr i8, ptr %v1890, i64 24
  store ptr %v1812, ptr %v1893, align 8, !tbaa !3
  %v1894 = getelementptr i8, ptr %v1890, i64 32
  store ptr %arg, ptr %v1894, align 8, !tbaa !3
  %v1916 = call ptr @mlf_env_new(i64 5)
  %v1917 = getelementptr i8, ptr %v1916, i64 8
  store ptr %v1804, ptr %v1917, align 8, !tbaa !3
  %v1918 = getelementptr i8, ptr %v1916, i64 16
  store ptr %v1806, ptr %v1918, align 8, !tbaa !3
  %v1919 = getelementptr i8, ptr %v1916, i64 24
  store ptr %v1808, ptr %v1919, align 8, !tbaa !3
  %v1920 = getelementptr i8, ptr %v1916, i64 32
  store ptr %v1810, ptr %v1920, align 8, !tbaa !3
  %v1921 = getelementptr i8, ptr %v1916, i64 40
  store ptr %v1812, ptr %v1921, align 8, !tbaa !3
  %v1922 = call ptr @mlf_closure(ptr @mlf.code.1895, ptr %v1916)
  %v1923 = call ptr @mlf_prim2(i64 1, ptr %v1888, ptr %v1922)
  ret ptr %v1923
}

define private ptr @mlf.worker.17(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) {
entry:
  %v1784 = call ptr @mlf_prim2(i64 11, ptr %a4, ptr %a2)
  %v1785 = icmp eq ptr %v1784, inttoptr (i64 6 to ptr)
  br i1 %v1785, label %yes.1786, label %no.1787
yes.1786:
  %v1797 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1789, i64 2)
  %v1798 = getelementptr i8, ptr %v1797, i64 16
  %v1799 = load ptr, ptr %v1798, align 8, !tbaa !3
  %v1800 = getelementptr i8, ptr %v1799, i64 8
  store ptr %a0, ptr %v1800, align 8, !tbaa !3
  %v1801 = getelementptr i8, ptr %v1799, i64 16
  store ptr %a4, ptr %v1801, align 8, !tbaa !3
  %v1924 = call ptr @mlf_env_new(i64 5)
  %v1925 = getelementptr i8, ptr %v1924, i64 8
  store ptr %a0, ptr %v1925, align 8, !tbaa !3
  %v1926 = getelementptr i8, ptr %v1924, i64 16
  store ptr %a1, ptr %v1926, align 8, !tbaa !3
  %v1927 = getelementptr i8, ptr %v1924, i64 24
  store ptr %a2, ptr %v1927, align 8, !tbaa !3
  %v1928 = getelementptr i8, ptr %v1924, i64 32
  store ptr %a3, ptr %v1928, align 8, !tbaa !3
  %v1929 = getelementptr i8, ptr %v1924, i64 40
  store ptr %a4, ptr %v1929, align 8, !tbaa !3
  %v1930 = call ptr @mlf_closure(ptr @mlf.code.1802, ptr %v1924)
  %v1931 = call ptr @mlf_prim2(i64 1, ptr %v1797, ptr %v1930)
  br label %join.1788
no.1787:
  %v1932 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.1788
join.1788:
  %v1933 = phi ptr [ %v1931, %yes.1786 ], [ %v1932, %no.1787 ]
  ret ptr %v1933
}

define private ptr @mlf.numeric.entry.1753(ptr %env, ptr %arg) {
entry:
  %v1754 = getelementptr i8, ptr %env, i64 8
  %v1755 = load ptr, ptr %v1754, align 8, !tbaa !3
  %v1756 = getelementptr i8, ptr %env, i64 16
  %v1757 = load ptr, ptr %v1756, align 8, !tbaa !3
  %v1758 = getelementptr i8, ptr %env, i64 24
  %v1759 = load ptr, ptr %v1758, align 8, !tbaa !3
  %v1760 = getelementptr i8, ptr %env, i64 32
  %v1761 = load ptr, ptr %v1760, align 8, !tbaa !3
  %v1762 = getelementptr i8, ptr %env, i64 40
  %v1763 = load ptr, ptr %v1762, align 8, !tbaa !3
  %v1764 = call ptr @mlf_peek(ptr %v1755)
  %v1765 = call ptr @mlf_peek(ptr %v1757)
  %v1766 = call ptr @mlf_peek(ptr %v1759)
  %v1767 = call ptr @mlf_peek(ptr %v1761)
  %v1768 = call ptr @mlf_peek(ptr %v1763)
  %v1769 = icmp ne ptr %v1764, null
  %v1770 = icmp ne ptr %v1765, null
  %v1771 = icmp ne ptr %v1766, null
  %v1772 = icmp ne ptr %v1767, null
  %v1773 = icmp ne ptr %v1768, null
  %v1774 = and i1 true, %v1769
  %v1775 = and i1 %v1774, %v1770
  %v1776 = and i1 %v1775, %v1771
  %v1777 = and i1 %v1776, %v1772
  %v1778 = and i1 %v1777, %v1773
  br i1 %v1778, label %yes.1779, label %no.1780
yes.1779:
  %v1782 = call ptr @mlf.numeric.17(ptr %v1764, ptr %v1765, ptr %v1766, ptr %v1767, ptr %v1768)
  %v1783 = call ptr @mlf_prim1(i64 0, ptr %v1782)
  br label %join.1781
no.1780:
  %v1934 = call ptr @mlf.force(ptr %v1759)
  %v1935 = call ptr @mlf.force(ptr %v1763)
  %v1936 = call ptr @mlf.worker.17(ptr %v1755, ptr %v1757, ptr %v1934, ptr %v1761, ptr %v1935)
  br label %join.1781
join.1781:
  %v1937 = phi ptr [ %v1783, %yes.1779 ], [ %v1936, %no.1780 ]
  ret ptr %v1937
}

define private ptr @mlf.code.1740(ptr %env, ptr %arg) {
entry:
  %v1741 = getelementptr i8, ptr %env, i64 8
  %v1742 = load ptr, ptr %v1741, align 8, !tbaa !3
  %v1743 = getelementptr i8, ptr %env, i64 16
  %v1744 = load ptr, ptr %v1743, align 8, !tbaa !3
  %v1745 = getelementptr i8, ptr %env, i64 24
  %v1746 = load ptr, ptr %v1745, align 8, !tbaa !3
  %v1747 = getelementptr i8, ptr %env, i64 32
  %v1748 = load ptr, ptr %v1747, align 8, !tbaa !3
  %v1749 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1749, align 8, !tbaa !3
  %v1750 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1750, align 8, !tbaa !3
  %v1751 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v1751, align 8, !tbaa !3
  %v1752 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v1752, align 8, !tbaa !3
  %v1938 = call ptr @mlf.force(ptr %v1746)
  %v1939 = call ptr @mlf_env_new(i64 5)
  %v1940 = getelementptr i8, ptr %v1939, i64 8
  store ptr %v1744, ptr %v1940, align 8, !tbaa !3
  %v1941 = getelementptr i8, ptr %v1939, i64 16
  store ptr %v1748, ptr %v1941, align 8, !tbaa !3
  %v1942 = getelementptr i8, ptr %v1939, i64 24
  store ptr %v1938, ptr %v1942, align 8, !tbaa !3
  %v1943 = getelementptr i8, ptr %v1939, i64 32
  store ptr %v1742, ptr %v1943, align 8, !tbaa !3
  %v1944 = getelementptr i8, ptr %v1939, i64 40
  store ptr inttoptr (i64 1 to ptr), ptr %v1944, align 8, !tbaa !3
  %v1945 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1753, ptr %v1939)
  ret ptr %v1945
}

define private ptr @mlf.code.1953(ptr %env, ptr %arg) {
entry:
  %v1954 = getelementptr i8, ptr %env, i64 8
  %v1955 = load ptr, ptr %v1954, align 8, !tbaa !3
  %v1956 = getelementptr i8, ptr %env, i64 16
  %v1957 = load ptr, ptr %v1956, align 8, !tbaa !3
  %v1958 = getelementptr i8, ptr %env, i64 24
  %v1959 = load ptr, ptr %v1958, align 8, !tbaa !3
  %v1960 = call ptr @mlf_env_new(i64 3)
  %v1961 = getelementptr i8, ptr %v1960, i64 8
  store ptr %v1959, ptr %v1961, align 8, !tbaa !3
  %v1962 = getelementptr i8, ptr %v1960, i64 16
  store ptr %v1955, ptr %v1962, align 8, !tbaa !3
  %v1963 = getelementptr i8, ptr %v1960, i64 24
  store ptr %v1957, ptr %v1963, align 8, !tbaa !3
  %v1964 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.586, ptr %v1960)
  ret ptr %v1964
}

define private ptr @mlf.code.1727(ptr %env, ptr %arg) {
entry:
  %v1728 = getelementptr i8, ptr %env, i64 8
  %v1729 = load ptr, ptr %v1728, align 8, !tbaa !3
  %v1730 = getelementptr i8, ptr %env, i64 16
  %v1731 = load ptr, ptr %v1730, align 8, !tbaa !3
  %v1732 = getelementptr i8, ptr %env, i64 24
  %v1733 = load ptr, ptr %v1732, align 8, !tbaa !3
  %v1734 = getelementptr i8, ptr %env, i64 32
  %v1735 = load ptr, ptr %v1734, align 8, !tbaa !3
  %v1736 = getelementptr i8, ptr %env, i64 40
  %v1737 = load ptr, ptr %v1736, align 8, !tbaa !3
  %v1738 = getelementptr i8, ptr %env, i64 48
  %v1739 = load ptr, ptr %v1738, align 8, !tbaa !3
  %v1946 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1740, i64 4)
  %v1947 = getelementptr i8, ptr %v1946, i64 16
  %v1948 = load ptr, ptr %v1947, align 8, !tbaa !3
  %v1949 = getelementptr i8, ptr %v1948, i64 8
  store ptr %v1729, ptr %v1949, align 8, !tbaa !3
  %v1950 = getelementptr i8, ptr %v1948, i64 16
  store ptr %v1731, ptr %v1950, align 8, !tbaa !3
  %v1951 = getelementptr i8, ptr %v1948, i64 24
  store ptr %v1733, ptr %v1951, align 8, !tbaa !3
  %v1952 = getelementptr i8, ptr %v1948, i64 32
  store ptr %v1739, ptr %v1952, align 8, !tbaa !3
  %v1965 = call ptr @mlf_env_new(i64 3)
  %v1966 = getelementptr i8, ptr %v1965, i64 8
  store ptr %v1735, ptr %v1966, align 8, !tbaa !3
  %v1967 = getelementptr i8, ptr %v1965, i64 16
  store ptr %v1737, ptr %v1967, align 8, !tbaa !3
  %v1968 = getelementptr i8, ptr %v1965, i64 24
  store ptr %v1739, ptr %v1968, align 8, !tbaa !3
  %v1969 = call ptr @mlf_closure(ptr @mlf.code.1953, ptr %v1965)
  %v1970 = call ptr @mlf_prim2(i64 1, ptr %v1946, ptr %v1969)
  ret ptr %v1970
}

define private ptr @mlf.code.1551(ptr %env, ptr %arg) {
entry:
  %v1552 = getelementptr i8, ptr %env, i64 8
  %v1553 = load ptr, ptr %v1552, align 8, !tbaa !3
  %v1554 = getelementptr i8, ptr %env, i64 16
  %v1555 = load ptr, ptr %v1554, align 8, !tbaa !3
  %v1556 = getelementptr i8, ptr %env, i64 24
  %v1557 = load ptr, ptr %v1556, align 8, !tbaa !3
  %v1558 = getelementptr i8, ptr %env, i64 32
  %v1559 = load ptr, ptr %v1558, align 8, !tbaa !3
  %v1560 = getelementptr i8, ptr %env, i64 40
  %v1561 = load ptr, ptr %v1560, align 8, !tbaa !3
  %v1562 = getelementptr i8, ptr %env, i64 48
  %v1563 = load ptr, ptr %v1562, align 8, !tbaa !3
  %v1721 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1564, i64 3)
  %v1722 = getelementptr i8, ptr %v1721, i64 16
  %v1723 = load ptr, ptr %v1722, align 8, !tbaa !3
  %v1724 = getelementptr i8, ptr %v1723, i64 8
  store ptr %v1553, ptr %v1724, align 8, !tbaa !3
  %v1725 = getelementptr i8, ptr %v1723, i64 16
  store ptr %v1555, ptr %v1725, align 8, !tbaa !3
  %v1726 = getelementptr i8, ptr %v1723, i64 24
  store ptr %arg, ptr %v1726, align 8, !tbaa !3
  %v1971 = call ptr @mlf_env_new(i64 6)
  %v1972 = getelementptr i8, ptr %v1971, i64 8
  store ptr %v1555, ptr %v1972, align 8, !tbaa !3
  %v1973 = getelementptr i8, ptr %v1971, i64 16
  store ptr %v1557, ptr %v1973, align 8, !tbaa !3
  %v1974 = getelementptr i8, ptr %v1971, i64 24
  store ptr %v1559, ptr %v1974, align 8, !tbaa !3
  %v1975 = getelementptr i8, ptr %v1971, i64 32
  store ptr %v1561, ptr %v1975, align 8, !tbaa !3
  %v1976 = getelementptr i8, ptr %v1971, i64 40
  store ptr %v1563, ptr %v1976, align 8, !tbaa !3
  %v1977 = getelementptr i8, ptr %v1971, i64 48
  store ptr %arg, ptr %v1977, align 8, !tbaa !3
  %v1978 = call ptr @mlf_closure(ptr @mlf.code.1727, ptr %v1971)
  %v1979 = call ptr @mlf_prim2(i64 1, ptr %v1721, ptr %v1978)
  ret ptr %v1979
}

define private ptr @mlf.code.1531(ptr %env, ptr %arg) {
entry:
  %v1532 = getelementptr i8, ptr %env, i64 8
  %v1533 = load ptr, ptr %v1532, align 8, !tbaa !3
  %v1534 = getelementptr i8, ptr %env, i64 16
  %v1535 = load ptr, ptr %v1534, align 8, !tbaa !3
  %v1536 = getelementptr i8, ptr %env, i64 24
  %v1537 = load ptr, ptr %v1536, align 8, !tbaa !3
  %v1538 = getelementptr i8, ptr %env, i64 32
  %v1539 = load ptr, ptr %v1538, align 8, !tbaa !3
  %v1540 = getelementptr i8, ptr %env, i64 40
  %v1541 = load ptr, ptr %v1540, align 8, !tbaa !3
  %v1547 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1542, i64 1)
  %v1548 = getelementptr i8, ptr %v1547, i64 16
  %v1549 = load ptr, ptr %v1548, align 8, !tbaa !3
  %v1550 = getelementptr i8, ptr %v1549, i64 8
  store ptr %arg, ptr %v1550, align 8, !tbaa !3
  %v1980 = call ptr @mlf_env_new(i64 6)
  %v1981 = getelementptr i8, ptr %v1980, i64 8
  store ptr %v1533, ptr %v1981, align 8, !tbaa !3
  %v1982 = getelementptr i8, ptr %v1980, i64 16
  store ptr %v1535, ptr %v1982, align 8, !tbaa !3
  %v1983 = getelementptr i8, ptr %v1980, i64 24
  store ptr %v1537, ptr %v1983, align 8, !tbaa !3
  %v1984 = getelementptr i8, ptr %v1980, i64 32
  store ptr %v1539, ptr %v1984, align 8, !tbaa !3
  %v1985 = getelementptr i8, ptr %v1980, i64 40
  store ptr %v1541, ptr %v1985, align 8, !tbaa !3
  %v1986 = getelementptr i8, ptr %v1980, i64 48
  store ptr %arg, ptr %v1986, align 8, !tbaa !3
  %v1987 = call ptr @mlf_closure(ptr @mlf.code.1551, ptr %v1980)
  %v1988 = call ptr @mlf_prim2(i64 1, ptr %v1547, ptr %v1987)
  ret ptr %v1988
}

define private ptr @mlf.code.1997(ptr %env, ptr %arg) {
entry:
  %v1998 = getelementptr i8, ptr %env, i64 8
  %v1999 = load ptr, ptr %v1998, align 8, !tbaa !3
  %v2000 = getelementptr i8, ptr %env, i64 16
  %v2001 = load ptr, ptr %v2000, align 8, !tbaa !3
  %v2002 = getelementptr i8, ptr %env, i64 24
  %v2003 = load ptr, ptr %v2002, align 8, !tbaa !3
  %v2004 = getelementptr i8, ptr %env, i64 32
  %v2005 = load ptr, ptr %v2004, align 8, !tbaa !3
  %v2006 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2006, align 8, !tbaa !3
  %v2007 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2007, align 8, !tbaa !3
  %v2008 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v2008, align 8, !tbaa !3
  %v2009 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v2009, align 8, !tbaa !3
  %v2010 = call ptr @mlf.force(ptr %v2005)
  %v2011 = call ptr @mlf_env_new(i64 5)
  %v2012 = getelementptr i8, ptr %v2011, i64 8
  store ptr %v2003, ptr %v2012, align 8, !tbaa !3
  %v2013 = getelementptr i8, ptr %v2011, i64 16
  store ptr %v1999, ptr %v2013, align 8, !tbaa !3
  %v2014 = getelementptr i8, ptr %v2011, i64 24
  store ptr %v2010, ptr %v2014, align 8, !tbaa !3
  %v2015 = getelementptr i8, ptr %v2011, i64 32
  store ptr %v2001, ptr %v2015, align 8, !tbaa !3
  %v2016 = getelementptr i8, ptr %v2011, i64 40
  store ptr inttoptr (i64 1 to ptr), ptr %v2016, align 8, !tbaa !3
  %v2017 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1753, ptr %v2011)
  ret ptr %v2017
}

define private ptr @mlf.code.2025(ptr %env, ptr %arg) {
entry:
  %v2026 = getelementptr i8, ptr %env, i64 8
  %v2027 = load ptr, ptr %v2026, align 8, !tbaa !3
  %v2028 = getelementptr i8, ptr %env, i64 16
  %v2029 = load ptr, ptr %v2028, align 8, !tbaa !3
  %v2030 = getelementptr i8, ptr %env, i64 24
  %v2031 = load ptr, ptr %v2030, align 8, !tbaa !3
  %v2032 = call ptr @mlf_env_new(i64 3)
  %v2033 = getelementptr i8, ptr %v2032, i64 8
  store ptr %v2027, ptr %v2033, align 8, !tbaa !3
  %v2034 = getelementptr i8, ptr %v2032, i64 16
  store ptr %v2031, ptr %v2034, align 8, !tbaa !3
  %v2035 = getelementptr i8, ptr %v2032, i64 24
  store ptr %v2029, ptr %v2035, align 8, !tbaa !3
  %v2036 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.586, ptr %v2032)
  ret ptr %v2036
}

define private ptr @mlf.code.1463(ptr %env, ptr %arg) {
entry:
  %v1464 = getelementptr i8, ptr %env, i64 8
  %v1465 = load ptr, ptr %v1464, align 8, !tbaa !3
  %v1466 = getelementptr i8, ptr %env, i64 16
  %v1467 = load ptr, ptr %v1466, align 8, !tbaa !3
  %v1468 = getelementptr i8, ptr %env, i64 24
  %v1469 = load ptr, ptr %v1468, align 8, !tbaa !3
  %v1470 = getelementptr i8, ptr %env, i64 32
  %v1471 = load ptr, ptr %v1470, align 8, !tbaa !3
  %v1472 = call ptr @mlf.force(ptr %v1467)
  %v1473 = call ptr @mlf.force(ptr %arg)
  %v1474 = call ptr @mlf_prim2(i64 8, ptr %v1472, ptr %v1473)
  %v1475 = call ptr @mlf.force(ptr %v1469)
  %v1476 = call ptr @mlf_prim2(i64 11, ptr %v1475, ptr %v1474)
  %v1477 = icmp eq ptr %v1476, inttoptr (i64 6 to ptr)
  br i1 %v1477, label %yes.1478, label %no.1479
yes.1478:
  %v1526 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1481, i64 2)
  %v1527 = getelementptr i8, ptr %v1526, i64 16
  %v1528 = load ptr, ptr %v1527, align 8, !tbaa !3
  %v1529 = getelementptr i8, ptr %v1528, i64 8
  store ptr %v1475, ptr %v1529, align 8, !tbaa !3
  %v1530 = getelementptr i8, ptr %v1528, i64 16
  store ptr %v1474, ptr %v1530, align 8, !tbaa !3
  %v1989 = call ptr @mlf_env_new(i64 5)
  %v1990 = getelementptr i8, ptr %v1989, i64 8
  store ptr %v1465, ptr %v1990, align 8, !tbaa !3
  %v1991 = getelementptr i8, ptr %v1989, i64 16
  store ptr %v1472, ptr %v1991, align 8, !tbaa !3
  %v1992 = getelementptr i8, ptr %v1989, i64 24
  store ptr %v1471, ptr %v1992, align 8, !tbaa !3
  %v1993 = getelementptr i8, ptr %v1989, i64 32
  store ptr %v1473, ptr %v1993, align 8, !tbaa !3
  %v1994 = getelementptr i8, ptr %v1989, i64 40
  store ptr %v1474, ptr %v1994, align 8, !tbaa !3
  %v1995 = call ptr @mlf_closure(ptr @mlf.code.1531, ptr %v1989)
  %v1996 = call ptr @mlf_prim2(i64 1, ptr %v1526, ptr %v1995)
  br label %join.1480
no.1479:
  %v2018 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1997, i64 4)
  %v2019 = getelementptr i8, ptr %v2018, i64 16
  %v2020 = load ptr, ptr %v2019, align 8, !tbaa !3
  %v2021 = getelementptr i8, ptr %v2020, i64 8
  store ptr %v1465, ptr %v2021, align 8, !tbaa !3
  %v2022 = getelementptr i8, ptr %v2020, i64 16
  store ptr %v1472, ptr %v2022, align 8, !tbaa !3
  %v2023 = getelementptr i8, ptr %v2020, i64 24
  store ptr %v1471, ptr %v2023, align 8, !tbaa !3
  %v2024 = getelementptr i8, ptr %v2020, i64 32
  store ptr %v1473, ptr %v2024, align 8, !tbaa !3
  %v2037 = call ptr @mlf_env_new(i64 3)
  %v2038 = getelementptr i8, ptr %v2037, i64 8
  store ptr %v1465, ptr %v2038, align 8, !tbaa !3
  %v2039 = getelementptr i8, ptr %v2037, i64 16
  store ptr %v1475, ptr %v2039, align 8, !tbaa !3
  %v2040 = getelementptr i8, ptr %v2037, i64 24
  store ptr %v1474, ptr %v2040, align 8, !tbaa !3
  %v2041 = call ptr @mlf_closure(ptr @mlf.code.2025, ptr %v2037)
  %v2042 = call ptr @mlf_prim2(i64 1, ptr %v2018, ptr %v2041)
  br label %join.1480
join.1480:
  %v2043 = phi ptr [ %v1996, %yes.1478 ], [ %v2042, %no.1479 ]
  ret ptr %v2043
}

define private ptr @mlf.code.1339(ptr %env, ptr %arg) {
entry:
  %v1340 = getelementptr i8, ptr %env, i64 8
  %v1341 = load ptr, ptr %v1340, align 8, !tbaa !3
  %v1342 = getelementptr i8, ptr %env, i64 16
  %v1343 = load ptr, ptr %v1342, align 8, !tbaa !3
  %v1344 = getelementptr i8, ptr %env, i64 24
  %v1345 = load ptr, ptr %v1344, align 8, !tbaa !3
  %v1346 = getelementptr i8, ptr %env, i64 32
  %v1347 = load ptr, ptr %v1346, align 8, !tbaa !3
  %v1348 = getelementptr i8, ptr %env, i64 40
  %v1349 = load ptr, ptr %v1348, align 8, !tbaa !3
  %v1350 = call ptr @mlf.force(ptr %arg)
  %v1351 = call ptr @mlf_prim2(i64 10, ptr %v1350, ptr inttoptr (i64 125 to ptr))
  %v1352 = icmp eq ptr %v1351, inttoptr (i64 6 to ptr)
  br i1 %v1352, label %yes.1353, label %no.1354
yes.1353:
  %v1356 = call ptr @mlf.construct.wide(i64 1, i64 3)
  %v1357 = getelementptr i8, ptr %v1356, i64 24
  store ptr %v1341, ptr %v1357, align 8, !tbaa !3
  %v1358 = getelementptr i8, ptr %v1356, i64 32
  store ptr %v1343, ptr %v1358, align 8, !tbaa !3
  %v1359 = getelementptr i8, ptr %v1356, i64 40
  store ptr %v1345, ptr %v1359, align 8, !tbaa !3
  %v1360 = call ptr @mlf_prim1(i64 0, ptr %v1356)
  br label %join.1355
no.1354:
  %v1458 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1361, i64 2)
  %v1459 = getelementptr i8, ptr %v1458, i64 16
  %v1460 = load ptr, ptr %v1459, align 8, !tbaa !3
  %v1461 = getelementptr i8, ptr %v1460, i64 8
  store ptr %v1347, ptr %v1461, align 8, !tbaa !3
  %v1462 = getelementptr i8, ptr %v1460, i64 16
  store ptr %v1349, ptr %v1462, align 8, !tbaa !3
  %v2044 = call ptr @mlf_env_new(i64 4)
  %v2045 = getelementptr i8, ptr %v2044, i64 8
  store ptr %v1341, ptr %v2045, align 8, !tbaa !3
  %v2046 = getelementptr i8, ptr %v2044, i64 16
  store ptr %v1343, ptr %v2046, align 8, !tbaa !3
  %v2047 = getelementptr i8, ptr %v2044, i64 24
  store ptr %v1345, ptr %v2047, align 8, !tbaa !3
  %v2048 = getelementptr i8, ptr %v2044, i64 32
  store ptr %v1347, ptr %v2048, align 8, !tbaa !3
  %v2049 = call ptr @mlf_closure(ptr @mlf.code.1463, ptr %v2044)
  %v2050 = call ptr @mlf_prim2(i64 1, ptr %v1458, ptr %v2049)
  br label %join.1355
join.1355:
  %v2051 = phi ptr [ %v1360, %yes.1353 ], [ %v2050, %no.1354 ]
  ret ptr %v2051
}

define private ptr @mlf.code.1310(ptr %env, ptr %arg) {
entry:
  %v1311 = getelementptr i8, ptr %env, i64 8
  %v1312 = load ptr, ptr %v1311, align 8, !tbaa !3
  %v1313 = getelementptr i8, ptr %env, i64 16
  %v1314 = load ptr, ptr %v1313, align 8, !tbaa !3
  %v1315 = getelementptr i8, ptr %env, i64 24
  %v1316 = load ptr, ptr %v1315, align 8, !tbaa !3
  %v1317 = getelementptr i8, ptr %env, i64 32
  %v1318 = load ptr, ptr %v1317, align 8, !tbaa !3
  %v1319 = call ptr @mlf.force(ptr %arg)
  %v1320 = call ptr @mlf_prim2(i64 10, ptr %v1319, ptr inttoptr (i64 1 to ptr))
  %v1321 = icmp eq ptr %v1320, inttoptr (i64 6 to ptr)
  br i1 %v1321, label %yes.1322, label %no.1323
yes.1322:
  %v1325 = call ptr @mlf.construct.wide(i64 1, i64 3)
  %v1326 = getelementptr i8, ptr %v1325, i64 24
  store ptr %v1312, ptr %v1326, align 8, !tbaa !3
  %v1327 = getelementptr i8, ptr %v1325, i64 32
  store ptr %v1314, ptr %v1327, align 8, !tbaa !3
  %v1328 = getelementptr i8, ptr %v1325, i64 40
  store ptr %v1316, ptr %v1328, align 8, !tbaa !3
  %v1329 = call ptr @mlf_prim1(i64 0, ptr %v1325)
  br label %join.1324
no.1323:
  %v1335 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1330, i64 1)
  %v1336 = getelementptr i8, ptr %v1335, i64 16
  %v1337 = load ptr, ptr %v1336, align 8, !tbaa !3
  %v1338 = getelementptr i8, ptr %v1337, i64 8
  store ptr %v1318, ptr %v1338, align 8, !tbaa !3
  %v2052 = call ptr @mlf_env_new(i64 5)
  %v2053 = getelementptr i8, ptr %v2052, i64 8
  store ptr %v1312, ptr %v2053, align 8, !tbaa !3
  %v2054 = getelementptr i8, ptr %v2052, i64 16
  store ptr %v1314, ptr %v2054, align 8, !tbaa !3
  %v2055 = getelementptr i8, ptr %v2052, i64 24
  store ptr %v1316, ptr %v2055, align 8, !tbaa !3
  %v2056 = getelementptr i8, ptr %v2052, i64 32
  store ptr %v1318, ptr %v2056, align 8, !tbaa !3
  %v2057 = getelementptr i8, ptr %v2052, i64 40
  store ptr %v1319, ptr %v2057, align 8, !tbaa !3
  %v2058 = call ptr @mlf_closure(ptr @mlf.code.1339, ptr %v2052)
  %v2059 = call ptr @mlf_prim2(i64 1, ptr %v1335, ptr %v2058)
  br label %join.1324
join.1324:
  %v2060 = phi ptr [ %v1329, %yes.1322 ], [ %v2059, %no.1323 ]
  ret ptr %v2060
}

define private ptr @mlf.code.1294(ptr %env, ptr %arg) {
entry:
  %v1295 = getelementptr i8, ptr %env, i64 8
  %v1296 = load ptr, ptr %v1295, align 8, !tbaa !3
  %v1297 = getelementptr i8, ptr %env, i64 16
  %v1298 = load ptr, ptr %v1297, align 8, !tbaa !3
  %v1299 = getelementptr i8, ptr %env, i64 24
  %v1300 = load ptr, ptr %v1299, align 8, !tbaa !3
  %v1306 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1301, i64 1)
  %v1307 = getelementptr i8, ptr %v1306, i64 16
  %v1308 = load ptr, ptr %v1307, align 8, !tbaa !3
  %v1309 = getelementptr i8, ptr %v1308, i64 8
  store ptr %arg, ptr %v1309, align 8, !tbaa !3
  %v2061 = call ptr @mlf_env_new(i64 4)
  %v2062 = getelementptr i8, ptr %v2061, i64 8
  store ptr %v1296, ptr %v2062, align 8, !tbaa !3
  %v2063 = getelementptr i8, ptr %v2061, i64 16
  store ptr %v1298, ptr %v2063, align 8, !tbaa !3
  %v2064 = getelementptr i8, ptr %v2061, i64 24
  store ptr %v1300, ptr %v2064, align 8, !tbaa !3
  %v2065 = getelementptr i8, ptr %v2061, i64 32
  store ptr %arg, ptr %v2065, align 8, !tbaa !3
  %v2066 = call ptr @mlf_closure(ptr @mlf.code.1310, ptr %v2061)
  %v2067 = call ptr @mlf_prim2(i64 1, ptr %v1306, ptr %v2066)
  ret ptr %v2067
}

define private ptr @mlf.worker.38(ptr %a0, ptr %a1, ptr %a2) {
entry:
  %v1293 = call ptr @mlf_primitive(i64 41)
  %v2068 = call ptr @mlf_env_new(i64 3)
  %v2069 = getelementptr i8, ptr %v2068, i64 8
  store ptr %a0, ptr %v2069, align 8, !tbaa !3
  %v2070 = getelementptr i8, ptr %v2068, i64 16
  store ptr %a1, ptr %v2070, align 8, !tbaa !3
  %v2071 = getelementptr i8, ptr %v2068, i64 24
  store ptr %a2, ptr %v2071, align 8, !tbaa !3
  %v2072 = call ptr @mlf_closure(ptr @mlf.code.1294, ptr %v2068)
  %v2073 = call ptr @mlf_prim2(i64 1, ptr %v1293, ptr %v2072)
  ret ptr %v2073
}

define private ptr @mlf.numeric.entry.586(ptr %env, ptr %arg) {
entry:
  %v587 = getelementptr i8, ptr %env, i64 8
  %v588 = load ptr, ptr %v587, align 8, !tbaa !3
  %v589 = getelementptr i8, ptr %env, i64 16
  %v590 = load ptr, ptr %v589, align 8, !tbaa !3
  %v591 = getelementptr i8, ptr %env, i64 24
  %v592 = load ptr, ptr %v591, align 8, !tbaa !3
  %v593 = call ptr @mlf_peek(ptr %v588)
  %v594 = call ptr @mlf_peek(ptr %v590)
  %v595 = call ptr @mlf_peek(ptr %v592)
  %v596 = icmp ne ptr %v593, null
  %v597 = icmp ne ptr %v594, null
  %v598 = icmp ne ptr %v595, null
  %v599 = and i1 true, %v596
  %v600 = and i1 %v599, %v597
  %v601 = and i1 %v600, %v598
  br i1 %v601, label %yes.602, label %no.603
yes.602:
  %v1291 = call ptr @mlf.numeric.38(ptr %v593, ptr %v594, ptr %v595)
  %v1292 = call ptr @mlf_prim1(i64 0, ptr %v1291)
  br label %join.604
no.603:
  %v2074 = call ptr @mlf.worker.38(ptr %v588, ptr %v590, ptr %v592)
  br label %join.604
join.604:
  %v2075 = phi ptr [ %v1292, %yes.602 ], [ %v2074, %no.603 ]
  ret ptr %v2075
}

define private ptr @mlf.code.582(ptr %env, ptr %arg) {
entry:
  %v583 = getelementptr i8, ptr %env, i64 8
  %v584 = load ptr, ptr %v583, align 8, !tbaa !3
  %v585 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v585, align 8, !tbaa !3
  %v2076 = call ptr @mlf_env_new(i64 3)
  %v2077 = getelementptr i8, ptr %v2076, i64 8
  store ptr %v584, ptr %v2077, align 8, !tbaa !3
  %v2078 = getelementptr i8, ptr %v2076, i64 16
  store ptr inttoptr (i64 1 to ptr), ptr %v2078, align 8, !tbaa !3
  %v2079 = getelementptr i8, ptr %v2076, i64 24
  store ptr inttoptr (i64 2049 to ptr), ptr %v2079, align 8, !tbaa !3
  %v2080 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.586, ptr %v2076)
  ret ptr %v2080
}

define private ptr @mlf.numeric.58.piii(ptr %a0, ptr %a1, ptr %a2, ptr %a3) alwaysinline {
entry:
  %v2171 = ptrtoint ptr %a1 to i64
  %v2172 = ptrtoint ptr %a2 to i64
  %v2173 = icmp slt i64 %v2171, %v2172
  %v2174 = select i1 %v2173, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v2175 = icmp eq ptr %v2174, inttoptr (i64 6 to ptr)
  br i1 %v2175, label %tail.yes.2176, label %tail.no.2177
tail.yes.2176:
  %v2178 = getelementptr i8, ptr %a0, i64 8
  %v2179 = load i64, ptr %v2178, align 8, !tbaa !3
  %v2180 = getelementptr i8, ptr %a0, i64 16
  %v2181 = load ptr, ptr %v2180, align 8, !tbaa !3
  %v2182 = ptrtoint ptr %a1 to i64
  %v2183 = ashr i64 %v2182, 1
  %v2184 = and i64 %v2182, 1
  %v2185 = icmp ne i64 %v2184, 0
  %v2186 = icmp ult i64 %v2183, %v2179
  %v2187 = and i1 %v2185, %v2186
  br i1 %v2187, label %array.valid.2188, label %array.invalid.2189
array.invalid.2189:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2188:
  %v2190 = getelementptr i8, ptr %v2181, i64 %v2183
  %v2191 = load i8, ptr %v2190, align 1, !tbaa !4
  %v2192 = zext i8 %v2191 to i64
  %v2193 = shl i64 %v2192, 1
  %v2194 = or i64 %v2193, 1
  %v2195 = inttoptr i64 %v2194 to ptr
  %v2196 = ptrtoint ptr %a1 to i64
  %v2197 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2198 = sub i64 %v2197, 1
  %v2199 = add nsw i64 %v2196, %v2198
  %v2200 = inttoptr i64 %v2199 to ptr
  %v2201 = ptrtoint ptr %a3 to i64
  %v2202 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v2203 = ashr i64 %v2201, 1
  %v2204 = ashr i64 %v2202, 1
  %v2205 = mul nsw i64 %v2203, %v2204
  %v2206 = shl i64 %v2205, 1
  %v2207 = or i64 %v2206, 1
  %v2208 = inttoptr i64 %v2207 to ptr
  %v2209 = ptrtoint ptr %v2208 to i64
  %v2210 = ptrtoint ptr %v2195 to i64
  %v2211 = sub i64 %v2210, 1
  %v2212 = add nsw i64 %v2209, %v2211
  %v2213 = inttoptr i64 %v2212 to ptr
  %v2214 = musttail call ptr @mlf.numeric.58(ptr %a0, ptr %v2200, ptr %a2, ptr %v2213)
  ret ptr %v2214
tail.no.2177:
  ret ptr %a3
}

define private ptr @mlf.numeric.58(ptr %a0, ptr %a1, ptr %a2, ptr %a3) alwaysinline {
entry:
  %v2151 = ptrtoint ptr %a1 to i64
  %v2152 = and i64 %v2151, 1
  %v2153 = icmp ne i64 %v2152, 0
  %v2154 = icmp ult i64 %v2151, 4294967296
  %v2155 = and i1 %v2153, %v2154
  %v2156 = ptrtoint ptr %a2 to i64
  %v2157 = and i64 %v2156, 1
  %v2158 = icmp ne i64 %v2157, 0
  %v2159 = icmp ult i64 %v2156, 4294967296
  %v2160 = and i1 %v2158, %v2159
  %v2161 = ptrtoint ptr %a3 to i64
  %v2162 = and i64 %v2161, 1
  %v2163 = icmp ne i64 %v2162, 0
  %v2164 = icmp ult i64 %v2161, 4294967296
  %v2165 = and i1 %v2163, %v2164
  %v2166 = and i1 true, %v2155
  %v2167 = and i1 %v2166, %v2160
  %v2168 = and i1 %v2167, %v2165
  br i1 %v2168, label %range.fast.2169, label %range.general.2170
range.fast.2169:
  %v2215 = musttail call ptr @mlf.numeric.58.piii(ptr %a0, ptr %a1, ptr %a2, ptr %a3)
  ret ptr %v2215
range.general.2170:
  %v2216 = ptrtoint ptr %a1 to i64
  %v2217 = ptrtoint ptr %a2 to i64
  %v2218 = and i64 %v2216, %v2217
  %v2219 = and i64 %v2218, 1
  %v2220 = icmp ne i64 %v2219, 0
  br i1 %v2220, label %yes.2221, label %no.2222
yes.2221:
  %v2224 = icmp slt i64 %v2216, %v2217
  %v2225 = select i1 %v2224, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.2223
no.2222:
  %v2226 = call ptr @mlf_lt_int(ptr %a1, ptr %a2)
  br label %join.2223
join.2223:
  %v2227 = phi ptr [ %v2225, %yes.2221 ], [ %v2226, %no.2222 ]
  %v2228 = icmp eq ptr %v2227, inttoptr (i64 6 to ptr)
  br i1 %v2228, label %tail.yes.2229, label %tail.no.2230
tail.yes.2229:
  %v2231 = getelementptr i8, ptr %a0, i64 8
  %v2232 = load i64, ptr %v2231, align 8, !tbaa !3
  %v2233 = getelementptr i8, ptr %a0, i64 16
  %v2234 = load ptr, ptr %v2233, align 8, !tbaa !3
  %v2235 = ptrtoint ptr %a1 to i64
  %v2236 = ashr i64 %v2235, 1
  %v2237 = and i64 %v2235, 1
  %v2238 = icmp ne i64 %v2237, 0
  %v2239 = icmp ult i64 %v2236, %v2232
  %v2240 = and i1 %v2238, %v2239
  br i1 %v2240, label %array.valid.2241, label %array.invalid.2242
array.invalid.2242:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2241:
  %v2243 = getelementptr i8, ptr %v2234, i64 %v2236
  %v2244 = load i8, ptr %v2243, align 1, !tbaa !4
  %v2245 = zext i8 %v2244 to i64
  %v2246 = shl i64 %v2245, 1
  %v2247 = or i64 %v2246, 1
  %v2248 = inttoptr i64 %v2247 to ptr
  %v2249 = ptrtoint ptr %a1 to i64
  %v2250 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2251 = sub i64 %v2250, 1
  %v2252 = add nsw i64 %v2249, %v2251
  %v2253 = inttoptr i64 %v2252 to ptr
  %v2254 = ptrtoint ptr %a3 to i64
  %v2255 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v2256 = and i64 %v2254, %v2255
  %v2257 = and i64 %v2256, 1
  %v2258 = icmp ne i64 %v2257, 0
  br i1 %v2258, label %yes.2259, label %no.2260
yes.2259:
  %v2262 = ashr i64 %v2254, 1
  %v2263 = ashr i64 %v2255, 1
  %v2264 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v2262, i64 %v2263)
  %v2265 = extractvalue { i64, i1 } %v2264, 0
  %v2266 = extractvalue { i64, i1 } %v2264, 1
  %v2267 = xor i1 %v2266, true
  %v2268 = icmp sge i64 %v2265, -4611686018427387904
  %v2269 = icmp sle i64 %v2265, 4611686018427387903
  %v2270 = and i1 %v2268, %v2269
  %v2271 = and i1 %v2270, %v2267
  br i1 %v2271, label %yes.2272, label %no.2273
yes.2272:
  %v2275 = shl i64 %v2265, 1
  %v2276 = or i64 %v2275, 1
  %v2277 = inttoptr i64 %v2276 to ptr
  br label %join.2274
no.2273:
  %v2278 = call ptr @mlf_prim2(i64 14, ptr %a3, ptr inttoptr (i64 9 to ptr))
  br label %join.2274
join.2274:
  %v2279 = phi ptr [ %v2277, %yes.2272 ], [ %v2278, %no.2273 ]
  br label %join.2261
no.2260:
  %v2280 = call ptr @mlf_prim2(i64 14, ptr %a3, ptr inttoptr (i64 9 to ptr))
  br label %join.2261
join.2261:
  %v2281 = phi ptr [ %v2279, %join.2274 ], [ %v2280, %no.2260 ]
  %v2282 = ptrtoint ptr %v2281 to i64
  %v2283 = ptrtoint ptr %v2248 to i64
  %v2284 = and i64 %v2282, %v2283
  %v2285 = and i64 %v2284, 1
  %v2286 = icmp ne i64 %v2285, 0
  br i1 %v2286, label %yes.2287, label %no.2288
yes.2287:
  %v2290 = sub i64 %v2283, 1
  %v2291 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2282, i64 %v2290)
  %v2292 = extractvalue { i64, i1 } %v2291, 0
  %v2293 = extractvalue { i64, i1 } %v2291, 1
  br i1 %v2293, label %yes.2294, label %no.2295
yes.2294:
  %v2297 = call ptr @mlf_add_int(ptr %v2281, ptr %v2248)
  br label %join.2296
no.2295:
  %v2298 = inttoptr i64 %v2292 to ptr
  br label %join.2296
join.2296:
  %v2299 = phi ptr [ %v2297, %yes.2294 ], [ %v2298, %no.2295 ]
  br label %join.2289
no.2288:
  %v2300 = call ptr @mlf_add_int(ptr %v2281, ptr %v2248)
  br label %join.2289
join.2289:
  %v2301 = phi ptr [ %v2299, %join.2296 ], [ %v2300, %no.2288 ]
  %v2302 = musttail call ptr @mlf.numeric.58(ptr %a0, ptr %v2253, ptr %a2, ptr %v2301)
  ret ptr %v2302
tail.no.2230:
  ret ptr %a3
}

define private ptr @mlf.numeric.64(ptr %a0, ptr %a1) alwaysinline {
entry:
  %v2304 = ptrtoint ptr %a0 to i64
  %v2305 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v2306 = and i64 %v2304, %v2305
  %v2307 = and i64 %v2306, 1
  %v2308 = icmp ne i64 %v2307, 0
  br i1 %v2308, label %yes.2309, label %no.2310
yes.2309:
  %v2312 = icmp eq i64 %v2304, %v2305
  %v2313 = select i1 %v2312, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.2311
no.2310:
  %v2314 = call ptr @mlf_eq_int(ptr %a0, ptr inttoptr (i64 1 to ptr))
  br label %join.2311
join.2311:
  %v2315 = phi ptr [ %v2313, %yes.2309 ], [ %v2314, %no.2310 ]
  %v2316 = icmp eq ptr %v2315, inttoptr (i64 6 to ptr)
  br i1 %v2316, label %tail.yes.2317, label %tail.no.2318
tail.yes.2317:
  ret ptr %a1
tail.no.2318:
  %v2319 = ptrtoint ptr %a0 to i64
  %v2320 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2321 = and i64 %v2319, %v2320
  %v2322 = and i64 %v2321, 1
  %v2323 = icmp ne i64 %v2322, 0
  br i1 %v2323, label %yes.2324, label %no.2325
yes.2324:
  %v2327 = sub i64 %v2320, 1
  %v2328 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v2319, i64 %v2327)
  %v2329 = extractvalue { i64, i1 } %v2328, 0
  %v2330 = extractvalue { i64, i1 } %v2328, 1
  br i1 %v2330, label %yes.2331, label %no.2332
yes.2331:
  %v2334 = call ptr @mlf_sub_int(ptr %a0, ptr inttoptr (i64 3 to ptr))
  br label %join.2333
no.2332:
  %v2335 = inttoptr i64 %v2329 to ptr
  br label %join.2333
join.2333:
  %v2336 = phi ptr [ %v2334, %yes.2331 ], [ %v2335, %no.2332 ]
  br label %join.2326
no.2325:
  %v2337 = call ptr @mlf_sub_int(ptr %a0, ptr inttoptr (i64 3 to ptr))
  br label %join.2326
join.2326:
  %v2338 = phi ptr [ %v2336, %join.2333 ], [ %v2337, %no.2325 ]
  %v2339 = ptrtoint ptr %a1 to i64
  %v2340 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v2341 = and i64 %v2339, %v2340
  %v2342 = and i64 %v2341, 1
  %v2343 = icmp ne i64 %v2342, 0
  br i1 %v2343, label %yes.2344, label %no.2345
yes.2344:
  %v2347 = ashr i64 %v2339, 1
  %v2348 = ashr i64 %v2340, 1
  %v2349 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v2347, i64 %v2348)
  %v2350 = extractvalue { i64, i1 } %v2349, 0
  %v2351 = extractvalue { i64, i1 } %v2349, 1
  %v2352 = xor i1 %v2351, true
  %v2353 = icmp sge i64 %v2350, -4611686018427387904
  %v2354 = icmp sle i64 %v2350, 4611686018427387903
  %v2355 = and i1 %v2353, %v2354
  %v2356 = and i1 %v2355, %v2352
  br i1 %v2356, label %yes.2357, label %no.2358
yes.2357:
  %v2360 = shl i64 %v2350, 1
  %v2361 = or i64 %v2360, 1
  %v2362 = inttoptr i64 %v2361 to ptr
  br label %join.2359
no.2358:
  %v2363 = call ptr @mlf_prim2(i64 14, ptr %a1, ptr inttoptr (i64 9 to ptr))
  br label %join.2359
join.2359:
  %v2364 = phi ptr [ %v2362, %yes.2357 ], [ %v2363, %no.2358 ]
  br label %join.2346
no.2345:
  %v2365 = call ptr @mlf_prim2(i64 14, ptr %a1, ptr inttoptr (i64 9 to ptr))
  br label %join.2346
join.2346:
  %v2366 = phi ptr [ %v2364, %join.2359 ], [ %v2365, %no.2345 ]
  %v2367 = musttail call ptr @mlf.numeric.64(ptr %v2338, ptr %v2366)
  ret ptr %v2367
}

define private ptr @mlf.numeric.67(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6) alwaysinline {
entry:
  %v2389 = call ptr @mlf_add_int_table(ptr %a1, ptr %a6, ptr inttoptr (i64 3 to ptr))
  %v2390 = ptrtoint ptr %a5 to i64
  %v2391 = ptrtoint ptr %a3 to i64
  %v2392 = and i64 %v2390, %v2391
  %v2393 = and i64 %v2392, 1
  %v2394 = icmp ne i64 %v2393, 0
  br i1 %v2394, label %yes.2395, label %no.2396
yes.2395:
  %v2398 = sub i64 %v2391, 1
  %v2399 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2390, i64 %v2398)
  %v2400 = extractvalue { i64, i1 } %v2399, 0
  %v2401 = extractvalue { i64, i1 } %v2399, 1
  br i1 %v2401, label %yes.2402, label %no.2403
yes.2402:
  %v2405 = call ptr @mlf_add_int(ptr %a5, ptr %a3)
  br label %join.2404
no.2403:
  %v2406 = inttoptr i64 %v2400 to ptr
  br label %join.2404
join.2404:
  %v2407 = phi ptr [ %v2405, %yes.2402 ], [ %v2406, %no.2403 ]
  br label %join.2397
no.2396:
  %v2408 = call ptr @mlf_add_int(ptr %a5, ptr %a3)
  br label %join.2397
join.2397:
  %v2409 = phi ptr [ %v2407, %join.2404 ], [ %v2408, %no.2396 ]
  %v2410 = ptrtoint ptr %v2409 to i64
  %v2411 = ptrtoint ptr %a2 to i64
  %v2412 = and i64 %v2410, %v2411
  %v2413 = and i64 %v2412, 1
  %v2414 = icmp ne i64 %v2413, 0
  br i1 %v2414, label %yes.2415, label %no.2416
yes.2415:
  %v2418 = icmp slt i64 %v2410, %v2411
  %v2419 = select i1 %v2418, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.2417
no.2416:
  %v2420 = call ptr @mlf_lt_int(ptr %v2409, ptr %a2)
  br label %join.2417
join.2417:
  %v2421 = phi ptr [ %v2419, %yes.2415 ], [ %v2420, %no.2416 ]
  %v2422 = icmp eq ptr %v2421, inttoptr (i64 6 to ptr)
  br i1 %v2422, label %tail.yes.2423, label %tail.no.2424
tail.yes.2423:
  %v2425 = getelementptr i8, ptr %a0, i64 8
  %v2426 = load i64, ptr %v2425, align 8, !tbaa !3
  %v2427 = getelementptr i8, ptr %a0, i64 16
  %v2428 = load ptr, ptr %v2427, align 8, !tbaa !3
  %v2429 = ptrtoint ptr %v2409 to i64
  %v2430 = ashr i64 %v2429, 1
  %v2431 = and i64 %v2429, 1
  %v2432 = icmp ne i64 %v2431, 0
  %v2433 = icmp ult i64 %v2430, %v2426
  %v2434 = and i1 %v2432, %v2433
  br i1 %v2434, label %array.valid.2435, label %array.invalid.2436
array.invalid.2436:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2435:
  %v2437 = getelementptr i8, ptr %v2428, i64 %v2430
  %v2438 = load i8, ptr %v2437, align 1, !tbaa !4
  %v2439 = zext i8 %v2438 to i64
  %v2440 = shl i64 %v2439, 1
  %v2441 = or i64 %v2440, 1
  %v2442 = inttoptr i64 %v2441 to ptr
  %v2443 = ptrtoint ptr %a6 to i64
  %v2444 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v2445 = and i64 %v2443, %v2444
  %v2446 = and i64 %v2445, 1
  %v2447 = icmp ne i64 %v2446, 0
  br i1 %v2447, label %yes.2448, label %no.2449
yes.2448:
  %v2451 = ashr i64 %v2443, 1
  %v2452 = ashr i64 %v2444, 1
  %v2453 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v2451, i64 %v2452)
  %v2454 = extractvalue { i64, i1 } %v2453, 0
  %v2455 = extractvalue { i64, i1 } %v2453, 1
  %v2456 = xor i1 %v2455, true
  %v2457 = icmp sge i64 %v2454, -4611686018427387904
  %v2458 = icmp sle i64 %v2454, 4611686018427387903
  %v2459 = and i1 %v2457, %v2458
  %v2460 = and i1 %v2459, %v2456
  br i1 %v2460, label %yes.2461, label %no.2462
yes.2461:
  %v2464 = shl i64 %v2454, 1
  %v2465 = or i64 %v2464, 1
  %v2466 = inttoptr i64 %v2465 to ptr
  br label %join.2463
no.2462:
  %v2467 = call ptr @mlf_prim2(i64 14, ptr %a6, ptr inttoptr (i64 9 to ptr))
  br label %join.2463
join.2463:
  %v2468 = phi ptr [ %v2466, %yes.2461 ], [ %v2467, %no.2462 ]
  br label %join.2450
no.2449:
  %v2469 = call ptr @mlf_prim2(i64 14, ptr %a6, ptr inttoptr (i64 9 to ptr))
  br label %join.2450
join.2450:
  %v2470 = phi ptr [ %v2468, %join.2463 ], [ %v2469, %no.2449 ]
  %v2471 = ptrtoint ptr %v2470 to i64
  %v2472 = ptrtoint ptr %a4 to i64
  %v2473 = and i64 %v2471, %v2472
  %v2474 = and i64 %v2473, 1
  %v2475 = icmp ne i64 %v2474, 0
  br i1 %v2475, label %yes.2476, label %no.2477
yes.2476:
  %v2479 = inttoptr i64 %v2473 to ptr
  br label %join.2478
no.2477:
  %v2480 = call ptr @mlf_prim2(i64 45, ptr %v2470, ptr %a4)
  br label %join.2478
join.2478:
  %v2481 = phi ptr [ %v2479, %yes.2476 ], [ %v2480, %no.2477 ]
  %v2482 = ptrtoint ptr %v2481 to i64
  %v2483 = ptrtoint ptr %v2442 to i64
  %v2484 = and i64 %v2482, %v2483
  %v2485 = and i64 %v2484, 1
  %v2486 = icmp ne i64 %v2485, 0
  br i1 %v2486, label %yes.2487, label %no.2488
yes.2487:
  %v2490 = sub i64 %v2483, 1
  %v2491 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2482, i64 %v2490)
  %v2492 = extractvalue { i64, i1 } %v2491, 0
  %v2493 = extractvalue { i64, i1 } %v2491, 1
  br i1 %v2493, label %yes.2494, label %no.2495
yes.2494:
  %v2497 = call ptr @mlf_add_int(ptr %v2481, ptr %v2442)
  br label %join.2496
no.2495:
  %v2498 = inttoptr i64 %v2492 to ptr
  br label %join.2496
join.2496:
  %v2499 = phi ptr [ %v2497, %yes.2494 ], [ %v2498, %no.2495 ]
  br label %join.2489
no.2488:
  %v2500 = call ptr @mlf_add_int(ptr %v2481, ptr %v2442)
  br label %join.2489
join.2489:
  %v2501 = phi ptr [ %v2499, %join.2496 ], [ %v2500, %no.2488 ]
  %v2502 = ptrtoint ptr %a5 to i64
  %v2503 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2504 = and i64 %v2502, %v2503
  %v2505 = and i64 %v2504, 1
  %v2506 = icmp ne i64 %v2505, 0
  br i1 %v2506, label %yes.2507, label %no.2508
yes.2507:
  %v2510 = sub i64 %v2503, 1
  %v2511 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2502, i64 %v2510)
  %v2512 = extractvalue { i64, i1 } %v2511, 0
  %v2513 = extractvalue { i64, i1 } %v2511, 1
  br i1 %v2513, label %yes.2514, label %no.2515
yes.2514:
  %v2517 = call ptr @mlf_add_int(ptr %a5, ptr inttoptr (i64 3 to ptr))
  br label %join.2516
no.2515:
  %v2518 = inttoptr i64 %v2512 to ptr
  br label %join.2516
join.2516:
  %v2519 = phi ptr [ %v2517, %yes.2514 ], [ %v2518, %no.2515 ]
  br label %join.2509
no.2508:
  %v2520 = call ptr @mlf_add_int(ptr %a5, ptr inttoptr (i64 3 to ptr))
  br label %join.2509
join.2509:
  %v2521 = phi ptr [ %v2519, %join.2516 ], [ %v2520, %no.2508 ]
  %v2522 = musttail call ptr @mlf.numeric.67(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %v2521, ptr %v2501)
  ret ptr %v2522
tail.no.2424:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.numeric.80(ptr %a0, ptr %a1, ptr %a2) {
entry:
  %v2130 = alloca [3 x ptr], align 8
  %v2131 = getelementptr ptr, ptr %v2130, i64 0
  store ptr %a0, ptr %v2131, align 8
  %v2132 = getelementptr ptr, ptr %v2130, i64 1
  store ptr %a1, ptr %v2132, align 8
  %v2133 = getelementptr ptr, ptr %v2130, i64 2
  store ptr %a2, ptr %v2133, align 8
  call void @mlf_gc_check(i64 3, ptr %v2130)
  %v2134 = call ptr @mlf_new_int_table()
  %v2135 = ptrtoint ptr %a1 to i64
  %v2136 = ptrtoint ptr %a2 to i64
  %v2137 = and i64 %v2135, %v2136
  %v2138 = and i64 %v2137, 1
  %v2139 = icmp ne i64 %v2138, 0
  br i1 %v2139, label %yes.2140, label %no.2141
yes.2140:
  %v2143 = icmp slt i64 %v2135, %v2136
  %v2144 = select i1 %v2143, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.2142
no.2141:
  %v2145 = call ptr @mlf_lt_int(ptr %a1, ptr %a2)
  br label %join.2142
join.2142:
  %v2146 = phi ptr [ %v2144, %yes.2140 ], [ %v2145, %no.2141 ]
  %v2147 = icmp eq ptr %v2146, inttoptr (i64 6 to ptr)
  br i1 %v2147, label %yes.2148, label %no.2149
yes.2148:
  br label %join.2150
no.2149:
  %v2303 = call ptr @mlf.numeric.58(ptr %a0, ptr inttoptr (i64 1 to ptr), ptr %a2, ptr inttoptr (i64 1 to ptr))
  %v2368 = call ptr @mlf.numeric.64(ptr %a2, ptr inttoptr (i64 3 to ptr))
  %v2369 = ptrtoint ptr %v2368 to i64
  %v2370 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2371 = and i64 %v2369, %v2370
  %v2372 = and i64 %v2371, 1
  %v2373 = icmp ne i64 %v2372, 0
  br i1 %v2373, label %yes.2374, label %no.2375
yes.2374:
  %v2377 = sub i64 %v2370, 1
  %v2378 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v2369, i64 %v2377)
  %v2379 = extractvalue { i64, i1 } %v2378, 0
  %v2380 = extractvalue { i64, i1 } %v2378, 1
  br i1 %v2380, label %yes.2381, label %no.2382
yes.2381:
  %v2384 = call ptr @mlf_sub_int(ptr %v2368, ptr inttoptr (i64 3 to ptr))
  br label %join.2383
no.2382:
  %v2385 = inttoptr i64 %v2379 to ptr
  br label %join.2383
join.2383:
  %v2386 = phi ptr [ %v2384, %yes.2381 ], [ %v2385, %no.2382 ]
  br label %join.2376
no.2375:
  %v2387 = call ptr @mlf_sub_int(ptr %v2368, ptr inttoptr (i64 3 to ptr))
  br label %join.2376
join.2376:
  %v2388 = phi ptr [ %v2386, %join.2383 ], [ %v2387, %no.2375 ]
  %v2523 = call ptr @mlf.numeric.67(ptr %a0, ptr %v2134, ptr %a1, ptr %a2, ptr %v2388, ptr inttoptr (i64 1 to ptr), ptr %v2303)
  br label %join.2150
join.2150:
  %v2524 = phi ptr [ inttoptr (i64 4 to ptr), %yes.2148 ], [ %v2523, %join.2376 ]
  ret ptr %v2134
}

define private ptr @mlf.code.2594(ptr %env, ptr %arg) {
entry:
  %v2595 = getelementptr i8, ptr %env, i64 8
  %v2596 = load ptr, ptr %v2595, align 8, !tbaa !3
  %v2597 = getelementptr i8, ptr %env, i64 16
  %v2598 = load ptr, ptr %v2597, align 8, !tbaa !3
  %v2599 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2599, align 8, !tbaa !3
  %v2600 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2600, align 8, !tbaa !3
  %v2601 = call ptr @mlf_prim2(i64 36, ptr %v2596, ptr %v2598)
  ret ptr %v2601
}

define private ptr @mlf.code.2619(ptr %env, ptr %arg) {
entry:
  %v2620 = getelementptr i8, ptr %env, i64 8
  %v2621 = load ptr, ptr %v2620, align 8, !tbaa !3
  %v2622 = getelementptr i8, ptr %env, i64 16
  %v2623 = load ptr, ptr %v2622, align 8, !tbaa !3
  %v2624 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2624, align 8, !tbaa !3
  %v2625 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2625, align 8, !tbaa !3
  %v2626 = call ptr @mlf.force(ptr %v2621)
  %v2627 = call ptr @mlf_prim2(i64 14, ptr %v2626, ptr inttoptr (i64 9 to ptr))
  %v2628 = call ptr @mlf.force(ptr %v2623)
  %v2629 = call ptr @mlf_prim2(i64 8, ptr %v2627, ptr %v2628)
  ret ptr %v2629
}

define private ptr @mlf.code.2607(ptr %env, ptr %arg) {
entry:
  %v2608 = getelementptr i8, ptr %env, i64 8
  %v2609 = load ptr, ptr %v2608, align 8, !tbaa !3
  %v2610 = getelementptr i8, ptr %env, i64 16
  %v2611 = load ptr, ptr %v2610, align 8, !tbaa !3
  %v2612 = getelementptr i8, ptr %env, i64 24
  %v2613 = load ptr, ptr %v2612, align 8, !tbaa !3
  %v2614 = getelementptr i8, ptr %env, i64 32
  %v2615 = load ptr, ptr %v2614, align 8, !tbaa !3
  %v2616 = call ptr @mlf.force(ptr %v2611)
  %v2617 = call ptr @mlf_prim2(i64 8, ptr %v2616, ptr inttoptr (i64 3 to ptr))
  %v2618 = call ptr @mlf.force(ptr %v2613)
  %v2630 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2619, i64 2)
  %v2631 = getelementptr i8, ptr %v2630, i64 16
  %v2632 = load ptr, ptr %v2631, align 8, !tbaa !3
  %v2633 = getelementptr i8, ptr %v2632, i64 8
  store ptr %v2615, ptr %v2633, align 8, !tbaa !3
  %v2634 = getelementptr i8, ptr %v2632, i64 16
  store ptr %arg, ptr %v2634, align 8, !tbaa !3
  %v2635 = call ptr @mlf_env_new(i64 4)
  %v2636 = getelementptr i8, ptr %v2635, i64 8
  store ptr %v2609, ptr %v2636, align 8, !tbaa !3
  %v2637 = getelementptr i8, ptr %v2635, i64 16
  store ptr %v2617, ptr %v2637, align 8, !tbaa !3
  %v2638 = getelementptr i8, ptr %v2635, i64 24
  store ptr %v2618, ptr %v2638, align 8, !tbaa !3
  %v2639 = getelementptr i8, ptr %v2635, i64 32
  store ptr %v2630, ptr %v2639, align 8, !tbaa !3
  %v2640 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2563, ptr %v2635)
  ret ptr %v2640
}

define private ptr @mlf.worker.58(ptr %a0, ptr %a1, ptr %a2, ptr %a3) {
entry:
  %v2589 = call ptr @mlf_prim2(i64 11, ptr %a1, ptr %a2)
  %v2590 = icmp eq ptr %v2589, inttoptr (i64 6 to ptr)
  br i1 %v2590, label %yes.2591, label %no.2592
yes.2591:
  %v2602 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2594, i64 2)
  %v2603 = getelementptr i8, ptr %v2602, i64 16
  %v2604 = load ptr, ptr %v2603, align 8, !tbaa !3
  %v2605 = getelementptr i8, ptr %v2604, i64 8
  store ptr %a0, ptr %v2605, align 8, !tbaa !3
  %v2606 = getelementptr i8, ptr %v2604, i64 16
  store ptr %a1, ptr %v2606, align 8, !tbaa !3
  %v2641 = call ptr @mlf_env_new(i64 4)
  %v2642 = getelementptr i8, ptr %v2641, i64 8
  store ptr %a0, ptr %v2642, align 8, !tbaa !3
  %v2643 = getelementptr i8, ptr %v2641, i64 16
  store ptr %a1, ptr %v2643, align 8, !tbaa !3
  %v2644 = getelementptr i8, ptr %v2641, i64 24
  store ptr %a2, ptr %v2644, align 8, !tbaa !3
  %v2645 = getelementptr i8, ptr %v2641, i64 32
  store ptr %a3, ptr %v2645, align 8, !tbaa !3
  %v2646 = call ptr @mlf_closure(ptr @mlf.code.2607, ptr %v2641)
  %v2647 = call ptr @mlf_prim2(i64 1, ptr %v2602, ptr %v2646)
  br label %join.2593
no.2592:
  %v2648 = call ptr @mlf_prim1(i64 0, ptr %a3)
  br label %join.2593
join.2593:
  %v2649 = phi ptr [ %v2647, %yes.2591 ], [ %v2648, %no.2592 ]
  ret ptr %v2649
}

define private ptr @mlf.numeric.entry.2563(ptr %env, ptr %arg) {
entry:
  %v2564 = getelementptr i8, ptr %env, i64 8
  %v2565 = load ptr, ptr %v2564, align 8, !tbaa !3
  %v2566 = getelementptr i8, ptr %env, i64 16
  %v2567 = load ptr, ptr %v2566, align 8, !tbaa !3
  %v2568 = getelementptr i8, ptr %env, i64 24
  %v2569 = load ptr, ptr %v2568, align 8, !tbaa !3
  %v2570 = getelementptr i8, ptr %env, i64 32
  %v2571 = load ptr, ptr %v2570, align 8, !tbaa !3
  %v2572 = call ptr @mlf_peek(ptr %v2565)
  %v2573 = call ptr @mlf_peek(ptr %v2567)
  %v2574 = call ptr @mlf_peek(ptr %v2569)
  %v2575 = call ptr @mlf_peek(ptr %v2571)
  %v2576 = icmp ne ptr %v2572, null
  %v2577 = icmp ne ptr %v2573, null
  %v2578 = icmp ne ptr %v2574, null
  %v2579 = icmp ne ptr %v2575, null
  %v2580 = and i1 true, %v2576
  %v2581 = and i1 %v2580, %v2577
  %v2582 = and i1 %v2581, %v2578
  %v2583 = and i1 %v2582, %v2579
  br i1 %v2583, label %yes.2584, label %no.2585
yes.2584:
  %v2587 = call ptr @mlf.numeric.58(ptr %v2572, ptr %v2573, ptr %v2574, ptr %v2575)
  %v2588 = call ptr @mlf_prim1(i64 0, ptr %v2587)
  br label %join.2586
no.2585:
  %v2650 = call ptr @mlf.force(ptr %v2567)
  %v2651 = call ptr @mlf.force(ptr %v2569)
  %v2652 = call ptr @mlf.worker.58(ptr %v2565, ptr %v2650, ptr %v2651, ptr %v2571)
  br label %join.2586
join.2586:
  %v2653 = phi ptr [ %v2588, %yes.2584 ], [ %v2652, %no.2585 ]
  ret ptr %v2653
}

define private ptr @mlf.code.2556(ptr %env, ptr %arg) {
entry:
  %v2557 = getelementptr i8, ptr %env, i64 8
  %v2558 = load ptr, ptr %v2557, align 8, !tbaa !3
  %v2559 = getelementptr i8, ptr %env, i64 16
  %v2560 = load ptr, ptr %v2559, align 8, !tbaa !3
  %v2561 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2561, align 8, !tbaa !3
  %v2562 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2562, align 8, !tbaa !3
  %v2654 = call ptr @mlf.force(ptr %v2560)
  %v2655 = call ptr @mlf_env_new(i64 4)
  %v2656 = getelementptr i8, ptr %v2655, i64 8
  store ptr %v2558, ptr %v2656, align 8, !tbaa !3
  %v2657 = getelementptr i8, ptr %v2655, i64 16
  store ptr inttoptr (i64 1 to ptr), ptr %v2657, align 8, !tbaa !3
  %v2658 = getelementptr i8, ptr %v2655, i64 24
  store ptr %v2654, ptr %v2658, align 8, !tbaa !3
  %v2659 = getelementptr i8, ptr %v2655, i64 32
  store ptr inttoptr (i64 1 to ptr), ptr %v2659, align 8, !tbaa !3
  %v2660 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2563, ptr %v2655)
  ret ptr %v2660
}

define private ptr @mlf.code.2702(ptr %env, ptr %arg) {
entry:
  %v2703 = getelementptr i8, ptr %env, i64 8
  %v2704 = load ptr, ptr %v2703, align 8, !tbaa !3
  %v2705 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2705, align 8, !tbaa !3
  %v2706 = call ptr @mlf.force(ptr %v2704)
  %v2707 = call ptr @mlf_prim2(i64 14, ptr %v2706, ptr inttoptr (i64 9 to ptr))
  ret ptr %v2707
}

define private ptr @mlf.worker.64(ptr %a0, ptr %a1) {
entry:
  %v2695 = call ptr @mlf_prim2(i64 10, ptr %a0, ptr inttoptr (i64 1 to ptr))
  %v2696 = icmp eq ptr %v2695, inttoptr (i64 6 to ptr)
  br i1 %v2696, label %yes.2697, label %no.2698
yes.2697:
  %v2700 = call ptr @mlf_prim1(i64 0, ptr %a1)
  br label %join.2699
no.2698:
  %v2701 = call ptr @mlf_prim2(i64 9, ptr %a0, ptr inttoptr (i64 3 to ptr))
  %v2708 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2702, i64 1)
  %v2709 = getelementptr i8, ptr %v2708, i64 16
  %v2710 = load ptr, ptr %v2709, align 8, !tbaa !3
  %v2711 = getelementptr i8, ptr %v2710, i64 8
  store ptr %a1, ptr %v2711, align 8, !tbaa !3
  %v2712 = call ptr @mlf_env_new(i64 2)
  %v2713 = getelementptr i8, ptr %v2712, i64 8
  store ptr %v2701, ptr %v2713, align 8, !tbaa !3
  %v2714 = getelementptr i8, ptr %v2712, i64 16
  store ptr %v2708, ptr %v2714, align 8, !tbaa !3
  %v2715 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2679, ptr %v2712)
  br label %join.2699
join.2699:
  %v2716 = phi ptr [ %v2700, %yes.2697 ], [ %v2715, %no.2698 ]
  ret ptr %v2716
}

define private ptr @mlf.numeric.entry.2679(ptr %env, ptr %arg) {
entry:
  %v2680 = getelementptr i8, ptr %env, i64 8
  %v2681 = load ptr, ptr %v2680, align 8, !tbaa !3
  %v2682 = getelementptr i8, ptr %env, i64 16
  %v2683 = load ptr, ptr %v2682, align 8, !tbaa !3
  %v2684 = call ptr @mlf_peek(ptr %v2681)
  %v2685 = call ptr @mlf_peek(ptr %v2683)
  %v2686 = icmp ne ptr %v2684, null
  %v2687 = icmp ne ptr %v2685, null
  %v2688 = and i1 true, %v2686
  %v2689 = and i1 %v2688, %v2687
  br i1 %v2689, label %yes.2690, label %no.2691
yes.2690:
  %v2693 = call ptr @mlf.numeric.64(ptr %v2684, ptr %v2685)
  %v2694 = call ptr @mlf_prim1(i64 0, ptr %v2693)
  br label %join.2692
no.2691:
  %v2717 = call ptr @mlf.force(ptr %v2681)
  %v2718 = call ptr @mlf.worker.64(ptr %v2717, ptr %v2683)
  br label %join.2692
join.2692:
  %v2719 = phi ptr [ %v2694, %yes.2690 ], [ %v2718, %no.2691 ]
  ret ptr %v2719
}

define private ptr @mlf.code.2675(ptr %env, ptr %arg) {
entry:
  %v2676 = getelementptr i8, ptr %env, i64 8
  %v2677 = load ptr, ptr %v2676, align 8, !tbaa !3
  %v2678 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2678, align 8, !tbaa !3
  %v2720 = call ptr @mlf.force(ptr %v2677)
  %v2721 = call ptr @mlf_env_new(i64 2)
  %v2722 = getelementptr i8, ptr %v2721, i64 8
  store ptr %v2720, ptr %v2722, align 8, !tbaa !3
  %v2723 = getelementptr i8, ptr %v2721, i64 16
  store ptr inttoptr (i64 3 to ptr), ptr %v2723, align 8, !tbaa !3
  %v2724 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2679, ptr %v2721)
  ret ptr %v2724
}

define private ptr @mlf.code.2781(ptr %env, ptr %arg) {
entry:
  %v2782 = getelementptr i8, ptr %env, i64 8
  %v2783 = load ptr, ptr %v2782, align 8, !tbaa !3
  %v2784 = getelementptr i8, ptr %env, i64 16
  %v2785 = load ptr, ptr %v2784, align 8, !tbaa !3
  %v2786 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2786, align 8, !tbaa !3
  %v2787 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2787, align 8, !tbaa !3
  %v2788 = call ptr @mlf_prim2(i64 43, ptr %v2783, ptr %v2785)
  ret ptr %v2788
}

define private ptr @mlf.code.2819(ptr %env, ptr %arg) {
entry:
  %v2820 = getelementptr i8, ptr %env, i64 8
  %v2821 = load ptr, ptr %v2820, align 8, !tbaa !3
  %v2822 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2822, align 8, !tbaa !3
  %v2823 = call ptr @mlf.force(ptr %v2821)
  %v2824 = call ptr @mlf_prim2(i64 8, ptr %v2823, ptr inttoptr (i64 3 to ptr))
  ret ptr %v2824
}

define private ptr @mlf.code.2809(ptr %env, ptr %arg) {
entry:
  %v2810 = getelementptr i8, ptr %env, i64 8
  %v2811 = load ptr, ptr %v2810, align 8, !tbaa !3
  %v2812 = getelementptr i8, ptr %env, i64 16
  %v2813 = load ptr, ptr %v2812, align 8, !tbaa !3
  %v2814 = getelementptr i8, ptr %env, i64 24
  %v2815 = load ptr, ptr %v2814, align 8, !tbaa !3
  %v2816 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2816, align 8, !tbaa !3
  %v2817 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2817, align 8, !tbaa !3
  %v2818 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v2818, align 8, !tbaa !3
  %v2825 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2819, i64 1)
  %v2826 = getelementptr i8, ptr %v2825, i64 16
  %v2827 = load ptr, ptr %v2826, align 8, !tbaa !3
  %v2828 = getelementptr i8, ptr %v2827, i64 8
  store ptr %v2815, ptr %v2828, align 8, !tbaa !3
  %v2829 = call ptr @mlf_prim3(i64 44, ptr %v2811, ptr %v2813, ptr %v2825)
  ret ptr %v2829
}

define private ptr @mlf.code.2860(ptr %env, ptr %arg) {
entry:
  %v2861 = getelementptr i8, ptr %env, i64 8
  %v2862 = load ptr, ptr %v2861, align 8, !tbaa !3
  %v2863 = getelementptr i8, ptr %env, i64 16
  %v2864 = load ptr, ptr %v2863, align 8, !tbaa !3
  %v2865 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2865, align 8, !tbaa !3
  %v2866 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2866, align 8, !tbaa !3
  %v2867 = call ptr @mlf_prim2(i64 36, ptr %v2862, ptr %v2864)
  ret ptr %v2867
}

define private ptr @mlf.code.2888(ptr %env, ptr %arg) {
entry:
  %v2889 = getelementptr i8, ptr %env, i64 8
  %v2890 = load ptr, ptr %v2889, align 8, !tbaa !3
  %v2891 = getelementptr i8, ptr %env, i64 16
  %v2892 = load ptr, ptr %v2891, align 8, !tbaa !3
  %v2893 = getelementptr i8, ptr %env, i64 24
  %v2894 = load ptr, ptr %v2893, align 8, !tbaa !3
  %v2895 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2895, align 8, !tbaa !3
  %v2896 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2896, align 8, !tbaa !3
  %v2897 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v2897, align 8, !tbaa !3
  %v2898 = call ptr @mlf.force(ptr %v2892)
  %v2899 = call ptr @mlf_prim2(i64 14, ptr %v2898, ptr inttoptr (i64 9 to ptr))
  %v2900 = call ptr @mlf.force(ptr %v2890)
  %v2901 = call ptr @mlf_prim2(i64 45, ptr %v2899, ptr %v2900)
  %v2902 = call ptr @mlf.force(ptr %v2894)
  %v2903 = call ptr @mlf_prim2(i64 8, ptr %v2901, ptr %v2902)
  ret ptr %v2903
}

define private ptr @mlf.code.2910(ptr %env, ptr %arg) {
entry:
  %v2911 = getelementptr i8, ptr %env, i64 8
  %v2912 = load ptr, ptr %v2911, align 8, !tbaa !3
  %v2913 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2913, align 8, !tbaa !3
  %v2914 = call ptr @mlf.force(ptr %v2912)
  %v2915 = call ptr @mlf_prim2(i64 8, ptr %v2914, ptr inttoptr (i64 3 to ptr))
  ret ptr %v2915
}

define private ptr @mlf.code.2873(ptr %env, ptr %arg) {
entry:
  %v2874 = getelementptr i8, ptr %env, i64 8
  %v2875 = load ptr, ptr %v2874, align 8, !tbaa !3
  %v2876 = getelementptr i8, ptr %env, i64 16
  %v2877 = load ptr, ptr %v2876, align 8, !tbaa !3
  %v2878 = getelementptr i8, ptr %env, i64 24
  %v2879 = load ptr, ptr %v2878, align 8, !tbaa !3
  %v2880 = getelementptr i8, ptr %env, i64 32
  %v2881 = load ptr, ptr %v2880, align 8, !tbaa !3
  %v2882 = getelementptr i8, ptr %env, i64 40
  %v2883 = load ptr, ptr %v2882, align 8, !tbaa !3
  %v2884 = getelementptr i8, ptr %env, i64 48
  %v2885 = load ptr, ptr %v2884, align 8, !tbaa !3
  %v2886 = getelementptr i8, ptr %env, i64 56
  %v2887 = load ptr, ptr %v2886, align 8, !tbaa !3
  %v2904 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2888, i64 3)
  %v2905 = getelementptr i8, ptr %v2904, i64 16
  %v2906 = load ptr, ptr %v2905, align 8, !tbaa !3
  %v2907 = getelementptr i8, ptr %v2906, i64 8
  store ptr %v2883, ptr %v2907, align 8, !tbaa !3
  %v2908 = getelementptr i8, ptr %v2906, i64 16
  store ptr %v2887, ptr %v2908, align 8, !tbaa !3
  %v2909 = getelementptr i8, ptr %v2906, i64 24
  store ptr %arg, ptr %v2909, align 8, !tbaa !3
  %v2916 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2910, i64 1)
  %v2917 = getelementptr i8, ptr %v2916, i64 16
  %v2918 = load ptr, ptr %v2917, align 8, !tbaa !3
  %v2919 = getelementptr i8, ptr %v2918, i64 8
  store ptr %v2885, ptr %v2919, align 8, !tbaa !3
  %v2920 = call ptr @mlf_env_new(i64 7)
  %v2921 = getelementptr i8, ptr %v2920, i64 8
  store ptr %v2875, ptr %v2921, align 8, !tbaa !3
  %v2922 = getelementptr i8, ptr %v2920, i64 16
  store ptr %v2877, ptr %v2922, align 8, !tbaa !3
  %v2923 = getelementptr i8, ptr %v2920, i64 24
  store ptr %v2879, ptr %v2923, align 8, !tbaa !3
  %v2924 = getelementptr i8, ptr %v2920, i64 32
  store ptr %v2881, ptr %v2924, align 8, !tbaa !3
  %v2925 = getelementptr i8, ptr %v2920, i64 40
  store ptr %v2883, ptr %v2925, align 8, !tbaa !3
  %v2926 = getelementptr i8, ptr %v2920, i64 48
  store ptr %v2916, ptr %v2926, align 8, !tbaa !3
  %v2927 = getelementptr i8, ptr %v2920, i64 56
  store ptr %v2904, ptr %v2927, align 8, !tbaa !3
  %v2928 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2740, ptr %v2920)
  ret ptr %v2928
}

define private ptr @mlf.code.2836(ptr %env, ptr %arg) {
entry:
  %v2837 = getelementptr i8, ptr %env, i64 8
  %v2838 = load ptr, ptr %v2837, align 8, !tbaa !3
  %v2839 = getelementptr i8, ptr %env, i64 16
  %v2840 = load ptr, ptr %v2839, align 8, !tbaa !3
  %v2841 = getelementptr i8, ptr %env, i64 24
  %v2842 = load ptr, ptr %v2841, align 8, !tbaa !3
  %v2843 = getelementptr i8, ptr %env, i64 32
  %v2844 = load ptr, ptr %v2843, align 8, !tbaa !3
  %v2845 = getelementptr i8, ptr %env, i64 40
  %v2846 = load ptr, ptr %v2845, align 8, !tbaa !3
  %v2847 = getelementptr i8, ptr %env, i64 48
  %v2848 = load ptr, ptr %v2847, align 8, !tbaa !3
  %v2849 = getelementptr i8, ptr %env, i64 56
  %v2850 = load ptr, ptr %v2849, align 8, !tbaa !3
  %v2851 = call ptr @mlf.force(ptr %v2848)
  %v2852 = call ptr @mlf.force(ptr %v2844)
  %v2853 = call ptr @mlf_prim2(i64 8, ptr %v2851, ptr %v2852)
  %v2854 = call ptr @mlf.force(ptr %v2842)
  %v2855 = call ptr @mlf_prim2(i64 11, ptr %v2853, ptr %v2854)
  %v2856 = icmp eq ptr %v2855, inttoptr (i64 6 to ptr)
  br i1 %v2856, label %yes.2857, label %no.2858
yes.2857:
  %v2868 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2860, i64 2)
  %v2869 = getelementptr i8, ptr %v2868, i64 16
  %v2870 = load ptr, ptr %v2869, align 8, !tbaa !3
  %v2871 = getelementptr i8, ptr %v2870, i64 8
  store ptr %v2838, ptr %v2871, align 8, !tbaa !3
  %v2872 = getelementptr i8, ptr %v2870, i64 16
  store ptr %v2853, ptr %v2872, align 8, !tbaa !3
  %v2929 = call ptr @mlf_env_new(i64 7)
  %v2930 = getelementptr i8, ptr %v2929, i64 8
  store ptr %v2838, ptr %v2930, align 8, !tbaa !3
  %v2931 = getelementptr i8, ptr %v2929, i64 16
  store ptr %v2840, ptr %v2931, align 8, !tbaa !3
  %v2932 = getelementptr i8, ptr %v2929, i64 24
  store ptr %v2854, ptr %v2932, align 8, !tbaa !3
  %v2933 = getelementptr i8, ptr %v2929, i64 32
  store ptr %v2852, ptr %v2933, align 8, !tbaa !3
  %v2934 = getelementptr i8, ptr %v2929, i64 40
  store ptr %v2846, ptr %v2934, align 8, !tbaa !3
  %v2935 = getelementptr i8, ptr %v2929, i64 48
  store ptr %v2851, ptr %v2935, align 8, !tbaa !3
  %v2936 = getelementptr i8, ptr %v2929, i64 56
  store ptr %v2850, ptr %v2936, align 8, !tbaa !3
  %v2937 = call ptr @mlf_closure(ptr @mlf.code.2873, ptr %v2929)
  %v2938 = call ptr @mlf_prim2(i64 1, ptr %v2868, ptr %v2937)
  br label %join.2859
no.2858:
  %v2939 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.2859
join.2859:
  %v2940 = phi ptr [ %v2938, %yes.2857 ], [ %v2939, %no.2858 ]
  ret ptr %v2940
}

define private ptr @mlf.code.2794(ptr %env, ptr %arg) {
entry:
  %v2795 = getelementptr i8, ptr %env, i64 8
  %v2796 = load ptr, ptr %v2795, align 8, !tbaa !3
  %v2797 = getelementptr i8, ptr %env, i64 16
  %v2798 = load ptr, ptr %v2797, align 8, !tbaa !3
  %v2799 = getelementptr i8, ptr %env, i64 24
  %v2800 = load ptr, ptr %v2799, align 8, !tbaa !3
  %v2801 = getelementptr i8, ptr %env, i64 32
  %v2802 = load ptr, ptr %v2801, align 8, !tbaa !3
  %v2803 = getelementptr i8, ptr %env, i64 40
  %v2804 = load ptr, ptr %v2803, align 8, !tbaa !3
  %v2805 = getelementptr i8, ptr %env, i64 48
  %v2806 = load ptr, ptr %v2805, align 8, !tbaa !3
  %v2807 = getelementptr i8, ptr %env, i64 56
  %v2808 = load ptr, ptr %v2807, align 8, !tbaa !3
  %v2830 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2809, i64 3)
  %v2831 = getelementptr i8, ptr %v2830, i64 16
  %v2832 = load ptr, ptr %v2831, align 8, !tbaa !3
  %v2833 = getelementptr i8, ptr %v2832, i64 8
  store ptr %v2798, ptr %v2833, align 8, !tbaa !3
  %v2834 = getelementptr i8, ptr %v2832, i64 16
  store ptr %v2808, ptr %v2834, align 8, !tbaa !3
  %v2835 = getelementptr i8, ptr %v2832, i64 24
  store ptr %arg, ptr %v2835, align 8, !tbaa !3
  %v2941 = call ptr @mlf_env_new(i64 7)
  %v2942 = getelementptr i8, ptr %v2941, i64 8
  store ptr %v2796, ptr %v2942, align 8, !tbaa !3
  %v2943 = getelementptr i8, ptr %v2941, i64 16
  store ptr %v2798, ptr %v2943, align 8, !tbaa !3
  %v2944 = getelementptr i8, ptr %v2941, i64 24
  store ptr %v2800, ptr %v2944, align 8, !tbaa !3
  %v2945 = getelementptr i8, ptr %v2941, i64 32
  store ptr %v2802, ptr %v2945, align 8, !tbaa !3
  %v2946 = getelementptr i8, ptr %v2941, i64 40
  store ptr %v2804, ptr %v2946, align 8, !tbaa !3
  %v2947 = getelementptr i8, ptr %v2941, i64 48
  store ptr %v2806, ptr %v2947, align 8, !tbaa !3
  %v2948 = getelementptr i8, ptr %v2941, i64 56
  store ptr %v2808, ptr %v2948, align 8, !tbaa !3
  %v2949 = call ptr @mlf_closure(ptr @mlf.code.2836, ptr %v2941)
  %v2950 = call ptr @mlf_prim2(i64 1, ptr %v2830, ptr %v2949)
  ret ptr %v2950
}

define private ptr @mlf.worker.67(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6) {
entry:
  %v2789 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2781, i64 2)
  %v2790 = getelementptr i8, ptr %v2789, i64 16
  %v2791 = load ptr, ptr %v2790, align 8, !tbaa !3
  %v2792 = getelementptr i8, ptr %v2791, i64 8
  store ptr %a1, ptr %v2792, align 8, !tbaa !3
  %v2793 = getelementptr i8, ptr %v2791, i64 16
  store ptr %a6, ptr %v2793, align 8, !tbaa !3
  %v2951 = call ptr @mlf_env_new(i64 7)
  %v2952 = getelementptr i8, ptr %v2951, i64 8
  store ptr %a0, ptr %v2952, align 8, !tbaa !3
  %v2953 = getelementptr i8, ptr %v2951, i64 16
  store ptr %a1, ptr %v2953, align 8, !tbaa !3
  %v2954 = getelementptr i8, ptr %v2951, i64 24
  store ptr %a2, ptr %v2954, align 8, !tbaa !3
  %v2955 = getelementptr i8, ptr %v2951, i64 32
  store ptr %a3, ptr %v2955, align 8, !tbaa !3
  %v2956 = getelementptr i8, ptr %v2951, i64 40
  store ptr %a4, ptr %v2956, align 8, !tbaa !3
  %v2957 = getelementptr i8, ptr %v2951, i64 48
  store ptr %a5, ptr %v2957, align 8, !tbaa !3
  %v2958 = getelementptr i8, ptr %v2951, i64 56
  store ptr %a6, ptr %v2958, align 8, !tbaa !3
  %v2959 = call ptr @mlf_closure(ptr @mlf.code.2794, ptr %v2951)
  %v2960 = call ptr @mlf_prim2(i64 1, ptr %v2789, ptr %v2959)
  ret ptr %v2960
}

define private ptr @mlf.numeric.entry.2740(ptr %env, ptr %arg) {
entry:
  %v2741 = getelementptr i8, ptr %env, i64 8
  %v2742 = load ptr, ptr %v2741, align 8, !tbaa !3
  %v2743 = getelementptr i8, ptr %env, i64 16
  %v2744 = load ptr, ptr %v2743, align 8, !tbaa !3
  %v2745 = getelementptr i8, ptr %env, i64 24
  %v2746 = load ptr, ptr %v2745, align 8, !tbaa !3
  %v2747 = getelementptr i8, ptr %env, i64 32
  %v2748 = load ptr, ptr %v2747, align 8, !tbaa !3
  %v2749 = getelementptr i8, ptr %env, i64 40
  %v2750 = load ptr, ptr %v2749, align 8, !tbaa !3
  %v2751 = getelementptr i8, ptr %env, i64 48
  %v2752 = load ptr, ptr %v2751, align 8, !tbaa !3
  %v2753 = getelementptr i8, ptr %env, i64 56
  %v2754 = load ptr, ptr %v2753, align 8, !tbaa !3
  %v2755 = call ptr @mlf_peek(ptr %v2742)
  %v2756 = call ptr @mlf_peek(ptr %v2744)
  %v2757 = call ptr @mlf_peek(ptr %v2746)
  %v2758 = call ptr @mlf_peek(ptr %v2748)
  %v2759 = call ptr @mlf_peek(ptr %v2750)
  %v2760 = call ptr @mlf_peek(ptr %v2752)
  %v2761 = call ptr @mlf_peek(ptr %v2754)
  %v2762 = icmp ne ptr %v2755, null
  %v2763 = icmp ne ptr %v2756, null
  %v2764 = icmp ne ptr %v2757, null
  %v2765 = icmp ne ptr %v2758, null
  %v2766 = icmp ne ptr %v2759, null
  %v2767 = icmp ne ptr %v2760, null
  %v2768 = icmp ne ptr %v2761, null
  %v2769 = and i1 true, %v2762
  %v2770 = and i1 %v2769, %v2763
  %v2771 = and i1 %v2770, %v2764
  %v2772 = and i1 %v2771, %v2765
  %v2773 = and i1 %v2772, %v2766
  %v2774 = and i1 %v2773, %v2767
  %v2775 = and i1 %v2774, %v2768
  br i1 %v2775, label %yes.2776, label %no.2777
yes.2776:
  %v2779 = call ptr @mlf.numeric.67(ptr %v2755, ptr %v2756, ptr %v2757, ptr %v2758, ptr %v2759, ptr %v2760, ptr %v2761)
  %v2780 = call ptr @mlf_prim1(i64 0, ptr %v2779)
  br label %join.2778
no.2777:
  %v2961 = call ptr @mlf.worker.67(ptr %v2742, ptr %v2744, ptr %v2746, ptr %v2748, ptr %v2750, ptr %v2752, ptr %v2754)
  br label %join.2778
join.2778:
  %v2962 = phi ptr [ %v2780, %yes.2776 ], [ %v2961, %no.2777 ]
  ret ptr %v2962
}

define private ptr @mlf.code.2963(ptr %env, ptr %arg) {
entry:
  %v2964 = getelementptr i8, ptr %env, i64 8
  %v2965 = load ptr, ptr %v2964, align 8, !tbaa !3
  %v2966 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2966, align 8, !tbaa !3
  %v2967 = call ptr @mlf.force(ptr %v2965)
  %v2968 = call ptr @mlf_prim2(i64 9, ptr %v2967, ptr inttoptr (i64 3 to ptr))
  ret ptr %v2968
}

define private ptr @mlf.code.2729(ptr %env, ptr %arg) {
entry:
  %v2730 = getelementptr i8, ptr %env, i64 8
  %v2731 = load ptr, ptr %v2730, align 8, !tbaa !3
  %v2732 = getelementptr i8, ptr %env, i64 16
  %v2733 = load ptr, ptr %v2732, align 8, !tbaa !3
  %v2734 = getelementptr i8, ptr %env, i64 24
  %v2735 = load ptr, ptr %v2734, align 8, !tbaa !3
  %v2736 = getelementptr i8, ptr %env, i64 32
  %v2737 = load ptr, ptr %v2736, align 8, !tbaa !3
  %v2738 = getelementptr i8, ptr %env, i64 40
  %v2739 = load ptr, ptr %v2738, align 8, !tbaa !3
  %v2969 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2963, i64 1)
  %v2970 = getelementptr i8, ptr %v2969, i64 16
  %v2971 = load ptr, ptr %v2970, align 8, !tbaa !3
  %v2972 = getelementptr i8, ptr %v2971, i64 8
  store ptr %arg, ptr %v2972, align 8, !tbaa !3
  %v2973 = call ptr @mlf_env_new(i64 7)
  %v2974 = getelementptr i8, ptr %v2973, i64 8
  store ptr %v2731, ptr %v2974, align 8, !tbaa !3
  %v2975 = getelementptr i8, ptr %v2973, i64 16
  store ptr %v2737, ptr %v2975, align 8, !tbaa !3
  %v2976 = getelementptr i8, ptr %v2973, i64 24
  store ptr %v2733, ptr %v2976, align 8, !tbaa !3
  %v2977 = getelementptr i8, ptr %v2973, i64 32
  store ptr %v2735, ptr %v2977, align 8, !tbaa !3
  %v2978 = getelementptr i8, ptr %v2973, i64 40
  store ptr %v2969, ptr %v2978, align 8, !tbaa !3
  %v2979 = getelementptr i8, ptr %v2973, i64 48
  store ptr inttoptr (i64 1 to ptr), ptr %v2979, align 8, !tbaa !3
  %v2980 = getelementptr i8, ptr %v2973, i64 56
  store ptr %v2739, ptr %v2980, align 8, !tbaa !3
  %v2981 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2740, ptr %v2973)
  ret ptr %v2981
}

define private ptr @mlf.code.2666(ptr %env, ptr %arg) {
entry:
  %v2667 = getelementptr i8, ptr %env, i64 8
  %v2668 = load ptr, ptr %v2667, align 8, !tbaa !3
  %v2669 = getelementptr i8, ptr %env, i64 16
  %v2670 = load ptr, ptr %v2669, align 8, !tbaa !3
  %v2671 = getelementptr i8, ptr %env, i64 24
  %v2672 = load ptr, ptr %v2671, align 8, !tbaa !3
  %v2673 = getelementptr i8, ptr %env, i64 32
  %v2674 = load ptr, ptr %v2673, align 8, !tbaa !3
  %v2725 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2675, i64 1)
  %v2726 = getelementptr i8, ptr %v2725, i64 16
  %v2727 = load ptr, ptr %v2726, align 8, !tbaa !3
  %v2728 = getelementptr i8, ptr %v2727, i64 8
  store ptr %v2672, ptr %v2728, align 8, !tbaa !3
  %v2982 = call ptr @mlf_env_new(i64 5)
  %v2983 = getelementptr i8, ptr %v2982, i64 8
  store ptr %v2668, ptr %v2983, align 8, !tbaa !3
  %v2984 = getelementptr i8, ptr %v2982, i64 16
  store ptr %v2670, ptr %v2984, align 8, !tbaa !3
  %v2985 = getelementptr i8, ptr %v2982, i64 24
  store ptr %v2672, ptr %v2985, align 8, !tbaa !3
  %v2986 = getelementptr i8, ptr %v2982, i64 32
  store ptr %v2674, ptr %v2986, align 8, !tbaa !3
  %v2987 = getelementptr i8, ptr %v2982, i64 40
  store ptr %arg, ptr %v2987, align 8, !tbaa !3
  %v2988 = call ptr @mlf_closure(ptr @mlf.code.2729, ptr %v2982)
  %v2989 = call ptr @mlf_prim2(i64 1, ptr %v2725, ptr %v2988)
  ret ptr %v2989
}

define private ptr @mlf.code.2535(ptr %env, ptr %arg) {
entry:
  %v2536 = getelementptr i8, ptr %env, i64 8
  %v2537 = load ptr, ptr %v2536, align 8, !tbaa !3
  %v2538 = getelementptr i8, ptr %env, i64 16
  %v2539 = load ptr, ptr %v2538, align 8, !tbaa !3
  %v2540 = getelementptr i8, ptr %env, i64 24
  %v2541 = load ptr, ptr %v2540, align 8, !tbaa !3
  %v2542 = getelementptr i8, ptr %env, i64 32
  %v2543 = load ptr, ptr %v2542, align 8, !tbaa !3
  %v2544 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2544, align 8, !tbaa !3
  %v2545 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2545, align 8, !tbaa !3
  %v2546 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v2546, align 8, !tbaa !3
  %v2547 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v2547, align 8, !tbaa !3
  %v2548 = call ptr @mlf.force(ptr %v2539)
  %v2549 = call ptr @mlf.force(ptr %v2541)
  %v2550 = call ptr @mlf_prim2(i64 11, ptr %v2548, ptr %v2549)
  %v2551 = icmp eq ptr %v2550, inttoptr (i64 6 to ptr)
  br i1 %v2551, label %yes.2552, label %no.2553
yes.2552:
  %v2555 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.2554
no.2553:
  %v2661 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2556, i64 2)
  %v2662 = getelementptr i8, ptr %v2661, i64 16
  %v2663 = load ptr, ptr %v2662, align 8, !tbaa !3
  %v2664 = getelementptr i8, ptr %v2663, i64 8
  store ptr %v2537, ptr %v2664, align 8, !tbaa !3
  %v2665 = getelementptr i8, ptr %v2663, i64 16
  store ptr %v2549, ptr %v2665, align 8, !tbaa !3
  %v2990 = call ptr @mlf_env_new(i64 4)
  %v2991 = getelementptr i8, ptr %v2990, i64 8
  store ptr %v2537, ptr %v2991, align 8, !tbaa !3
  %v2992 = getelementptr i8, ptr %v2990, i64 16
  store ptr %v2548, ptr %v2992, align 8, !tbaa !3
  %v2993 = getelementptr i8, ptr %v2990, i64 24
  store ptr %v2549, ptr %v2993, align 8, !tbaa !3
  %v2994 = getelementptr i8, ptr %v2990, i64 32
  store ptr %v2543, ptr %v2994, align 8, !tbaa !3
  %v2995 = call ptr @mlf_closure(ptr @mlf.code.2666, ptr %v2990)
  %v2996 = call ptr @mlf_prim2(i64 1, ptr %v2661, ptr %v2995)
  br label %join.2554
join.2554:
  %v2997 = phi ptr [ %v2555, %yes.2552 ], [ %v2996, %no.2553 ]
  ret ptr %v2997
}

define private ptr @mlf.code.3005(ptr %env, ptr %arg) {
entry:
  %v3006 = getelementptr i8, ptr %env, i64 8
  %v3007 = load ptr, ptr %v3006, align 8, !tbaa !3
  %v3008 = call ptr @mlf_prim1(i64 0, ptr %v3007)
  ret ptr %v3008
}

define private ptr @mlf.code.2528(ptr %env, ptr %arg) {
entry:
  %v2529 = getelementptr i8, ptr %env, i64 8
  %v2530 = load ptr, ptr %v2529, align 8, !tbaa !3
  %v2531 = getelementptr i8, ptr %env, i64 16
  %v2532 = load ptr, ptr %v2531, align 8, !tbaa !3
  %v2533 = getelementptr i8, ptr %env, i64 24
  %v2534 = load ptr, ptr %v2533, align 8, !tbaa !3
  %v2998 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2535, i64 4)
  %v2999 = getelementptr i8, ptr %v2998, i64 16
  %v3000 = load ptr, ptr %v2999, align 8, !tbaa !3
  %v3001 = getelementptr i8, ptr %v3000, i64 8
  store ptr %v2530, ptr %v3001, align 8, !tbaa !3
  %v3002 = getelementptr i8, ptr %v3000, i64 16
  store ptr %v2532, ptr %v3002, align 8, !tbaa !3
  %v3003 = getelementptr i8, ptr %v3000, i64 24
  store ptr %v2534, ptr %v3003, align 8, !tbaa !3
  %v3004 = getelementptr i8, ptr %v3000, i64 32
  store ptr %arg, ptr %v3004, align 8, !tbaa !3
  %v3009 = call ptr @mlf_env_new(i64 1)
  %v3010 = getelementptr i8, ptr %v3009, i64 8
  store ptr %arg, ptr %v3010, align 8, !tbaa !3
  %v3011 = call ptr @mlf_closure(ptr @mlf.code.3005, ptr %v3009)
  %v3012 = call ptr @mlf_prim2(i64 1, ptr %v2998, ptr %v3011)
  ret ptr %v3012
}

define private ptr @mlf.worker.80(ptr %a0, ptr %a1, ptr %a2) {
entry:
  %v2527 = call ptr @mlf_primitive(i64 42)
  %v3013 = call ptr @mlf_env_new(i64 3)
  %v3014 = getelementptr i8, ptr %v3013, i64 8
  store ptr %a0, ptr %v3014, align 8, !tbaa !3
  %v3015 = getelementptr i8, ptr %v3013, i64 16
  store ptr %a1, ptr %v3015, align 8, !tbaa !3
  %v3016 = getelementptr i8, ptr %v3013, i64 24
  store ptr %a2, ptr %v3016, align 8, !tbaa !3
  %v3017 = call ptr @mlf_closure(ptr @mlf.code.2528, ptr %v3013)
  %v3018 = call ptr @mlf_prim2(i64 1, ptr %v2527, ptr %v3017)
  ret ptr %v3018
}

define private ptr @mlf.numeric.entry.2111(ptr %env, ptr %arg) {
entry:
  %v2112 = getelementptr i8, ptr %env, i64 8
  %v2113 = load ptr, ptr %v2112, align 8, !tbaa !3
  %v2114 = getelementptr i8, ptr %env, i64 16
  %v2115 = load ptr, ptr %v2114, align 8, !tbaa !3
  %v2116 = getelementptr i8, ptr %env, i64 24
  %v2117 = load ptr, ptr %v2116, align 8, !tbaa !3
  %v2118 = call ptr @mlf_peek(ptr %v2113)
  %v2119 = call ptr @mlf_peek(ptr %v2115)
  %v2120 = call ptr @mlf_peek(ptr %v2117)
  %v2121 = icmp ne ptr %v2118, null
  %v2122 = icmp ne ptr %v2119, null
  %v2123 = icmp ne ptr %v2120, null
  %v2124 = and i1 true, %v2121
  %v2125 = and i1 %v2124, %v2122
  %v2126 = and i1 %v2125, %v2123
  br i1 %v2126, label %yes.2127, label %no.2128
yes.2127:
  %v2525 = call ptr @mlf.numeric.80(ptr %v2118, ptr %v2119, ptr %v2120)
  %v2526 = call ptr @mlf_prim1(i64 0, ptr %v2525)
  br label %join.2129
no.2128:
  %v3019 = call ptr @mlf.worker.80(ptr %v2113, ptr %v2115, ptr %v2117)
  br label %join.2129
join.2129:
  %v3020 = phi ptr [ %v2526, %yes.2127 ], [ %v3019, %no.2128 ]
  ret ptr %v3020
}

define private ptr @mlf.code.2104(ptr %env, ptr %arg) {
entry:
  %v2105 = getelementptr i8, ptr %env, i64 8
  %v2106 = load ptr, ptr %v2105, align 8, !tbaa !3
  %v2107 = getelementptr i8, ptr %env, i64 16
  %v2108 = load ptr, ptr %v2107, align 8, !tbaa !3
  %v2109 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2109, align 8, !tbaa !3
  %v2110 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2110, align 8, !tbaa !3
  %v3021 = call ptr @mlf_env_new(i64 3)
  %v3022 = getelementptr i8, ptr %v3021, i64 8
  store ptr %v2106, ptr %v3022, align 8, !tbaa !3
  %v3023 = getelementptr i8, ptr %v3021, i64 16
  store ptr %v2108, ptr %v3023, align 8, !tbaa !3
  %v3024 = getelementptr i8, ptr %v3021, i64 24
  store ptr inttoptr (i64 3 to ptr), ptr %v3024, align 8, !tbaa !3
  %v3025 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2111, ptr %v3021)
  ret ptr %v3025
}

define private ptr @mlf.numeric.90(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) alwaysinline {
entry:
  %v3097 = ptrtoint ptr %a2 to i64
  %v3098 = ptrtoint ptr %a1 to i64
  %v3099 = and i64 %v3097, %v3098
  %v3100 = and i64 %v3099, 1
  %v3101 = icmp ne i64 %v3100, 0
  br i1 %v3101, label %yes.3102, label %no.3103
yes.3102:
  %v3105 = icmp slt i64 %v3097, %v3098
  %v3106 = select i1 %v3105, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.3104
no.3103:
  %v3107 = call ptr @mlf_lt_int(ptr %a2, ptr %a1)
  br label %join.3104
join.3104:
  %v3108 = phi ptr [ %v3106, %yes.3102 ], [ %v3107, %no.3103 ]
  %v3109 = icmp eq ptr %v3108, inttoptr (i64 6 to ptr)
  br i1 %v3109, label %tail.yes.3110, label %tail.no.3111
tail.yes.3110:
  %v3112 = call ptr @mlf_read_int_table(ptr %a0, ptr %a2)
  %v3113 = ptrtoint ptr %a4 to i64
  %v3114 = ptrtoint ptr %v3112 to i64
  %v3115 = and i64 %v3113, %v3114
  %v3116 = and i64 %v3115, 1
  %v3117 = icmp ne i64 %v3116, 0
  br i1 %v3117, label %yes.3118, label %no.3119
yes.3118:
  %v3121 = icmp slt i64 %v3113, %v3114
  %v3122 = select i1 %v3121, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.3120
no.3119:
  %v3123 = call ptr @mlf_lt_int(ptr %a4, ptr %v3112)
  br label %join.3120
join.3120:
  %v3124 = phi ptr [ %v3122, %yes.3118 ], [ %v3123, %no.3119 ]
  %v3125 = icmp eq ptr %v3124, inttoptr (i64 6 to ptr)
  br i1 %v3125, label %tail.yes.3126, label %tail.no.3127
tail.yes.3126:
  %v3128 = ptrtoint ptr %a2 to i64
  %v3129 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v3130 = and i64 %v3128, %v3129
  %v3131 = and i64 %v3130, 1
  %v3132 = icmp ne i64 %v3131, 0
  br i1 %v3132, label %yes.3133, label %no.3134
yes.3133:
  %v3136 = sub i64 %v3129, 1
  %v3137 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v3128, i64 %v3136)
  %v3138 = extractvalue { i64, i1 } %v3137, 0
  %v3139 = extractvalue { i64, i1 } %v3137, 1
  br i1 %v3139, label %yes.3140, label %no.3141
yes.3140:
  %v3143 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 3 to ptr))
  br label %join.3142
no.3141:
  %v3144 = inttoptr i64 %v3138 to ptr
  br label %join.3142
join.3142:
  %v3145 = phi ptr [ %v3143, %yes.3140 ], [ %v3144, %no.3141 ]
  br label %join.3135
no.3134:
  %v3146 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 3 to ptr))
  br label %join.3135
join.3135:
  %v3147 = phi ptr [ %v3145, %join.3142 ], [ %v3146, %no.3134 ]
  %v3148 = musttail call ptr @mlf.numeric.90(ptr %a0, ptr %a1, ptr %v3147, ptr %a2, ptr %v3112)
  ret ptr %v3148
tail.no.3127:
  %v3149 = ptrtoint ptr %a2 to i64
  %v3150 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v3151 = and i64 %v3149, %v3150
  %v3152 = and i64 %v3151, 1
  %v3153 = icmp ne i64 %v3152, 0
  br i1 %v3153, label %yes.3154, label %no.3155
yes.3154:
  %v3157 = sub i64 %v3150, 1
  %v3158 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v3149, i64 %v3157)
  %v3159 = extractvalue { i64, i1 } %v3158, 0
  %v3160 = extractvalue { i64, i1 } %v3158, 1
  br i1 %v3160, label %yes.3161, label %no.3162
yes.3161:
  %v3164 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 3 to ptr))
  br label %join.3163
no.3162:
  %v3165 = inttoptr i64 %v3159 to ptr
  br label %join.3163
join.3163:
  %v3166 = phi ptr [ %v3164, %yes.3161 ], [ %v3165, %no.3162 ]
  br label %join.3156
no.3155:
  %v3167 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 3 to ptr))
  br label %join.3156
join.3156:
  %v3168 = phi ptr [ %v3166, %join.3163 ], [ %v3167, %no.3155 ]
  %v3169 = musttail call ptr @mlf.numeric.90(ptr %a0, ptr %a1, ptr %v3168, ptr %a3, ptr %a4)
  ret ptr %v3169
tail.no.3111:
  ret ptr %a3
}

define private ptr @mlf.code.3177(ptr %env, ptr %arg) {
entry:
  %v3178 = getelementptr i8, ptr %env, i64 8
  %v3179 = load ptr, ptr %v3178, align 8, !tbaa !3
  %v3180 = getelementptr i8, ptr %env, i64 16
  %v3181 = load ptr, ptr %v3180, align 8, !tbaa !3
  %v3182 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3182, align 8, !tbaa !3
  %v3183 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v3183, align 8, !tbaa !3
  %v3184 = call ptr @mlf_prim2(i64 43, ptr %v3179, ptr %v3181)
  ret ptr %v3184
}

define private ptr @mlf.code.3190(ptr %env, ptr %arg) {
entry:
  %v3191 = getelementptr i8, ptr %env, i64 8
  %v3192 = load ptr, ptr %v3191, align 8, !tbaa !3
  %v3193 = getelementptr i8, ptr %env, i64 16
  %v3194 = load ptr, ptr %v3193, align 8, !tbaa !3
  %v3195 = getelementptr i8, ptr %env, i64 24
  %v3196 = load ptr, ptr %v3195, align 8, !tbaa !3
  %v3197 = getelementptr i8, ptr %env, i64 32
  %v3198 = load ptr, ptr %v3197, align 8, !tbaa !3
  %v3199 = getelementptr i8, ptr %env, i64 40
  %v3200 = load ptr, ptr %v3199, align 8, !tbaa !3
  %v3201 = call ptr @mlf.force(ptr %v3200)
  %v3202 = call ptr @mlf.force(ptr %arg)
  %v3203 = call ptr @mlf_prim2(i64 11, ptr %v3201, ptr %v3202)
  %v3204 = icmp eq ptr %v3203, inttoptr (i64 6 to ptr)
  br i1 %v3204, label %yes.3205, label %no.3206
yes.3205:
  %v3208 = call ptr @mlf.force(ptr %v3194)
  %v3209 = call ptr @mlf.force(ptr %v3196)
  %v3210 = call ptr @mlf_prim2(i64 8, ptr %v3209, ptr inttoptr (i64 3 to ptr))
  %v3211 = call ptr @mlf_env_new(i64 5)
  %v3212 = getelementptr i8, ptr %v3211, i64 8
  store ptr %v3192, ptr %v3212, align 8, !tbaa !3
  %v3213 = getelementptr i8, ptr %v3211, i64 16
  store ptr %v3208, ptr %v3213, align 8, !tbaa !3
  %v3214 = getelementptr i8, ptr %v3211, i64 24
  store ptr %v3210, ptr %v3214, align 8, !tbaa !3
  %v3215 = getelementptr i8, ptr %v3211, i64 32
  store ptr %v3209, ptr %v3215, align 8, !tbaa !3
  %v3216 = getelementptr i8, ptr %v3211, i64 40
  store ptr %v3202, ptr %v3216, align 8, !tbaa !3
  %v3217 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.3068, ptr %v3211)
  br label %join.3207
no.3206:
  %v3218 = call ptr @mlf.force(ptr %v3194)
  %v3219 = call ptr @mlf.force(ptr %v3196)
  %v3220 = call ptr @mlf_prim2(i64 8, ptr %v3219, ptr inttoptr (i64 3 to ptr))
  %v3221 = call ptr @mlf_env_new(i64 5)
  %v3222 = getelementptr i8, ptr %v3221, i64 8
  store ptr %v3192, ptr %v3222, align 8, !tbaa !3
  %v3223 = getelementptr i8, ptr %v3221, i64 16
  store ptr %v3218, ptr %v3223, align 8, !tbaa !3
  %v3224 = getelementptr i8, ptr %v3221, i64 24
  store ptr %v3220, ptr %v3224, align 8, !tbaa !3
  %v3225 = getelementptr i8, ptr %v3221, i64 32
  store ptr %v3198, ptr %v3225, align 8, !tbaa !3
  %v3226 = getelementptr i8, ptr %v3221, i64 40
  store ptr %v3201, ptr %v3226, align 8, !tbaa !3
  %v3227 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.3068, ptr %v3221)
  br label %join.3207
join.3207:
  %v3228 = phi ptr [ %v3217, %yes.3205 ], [ %v3227, %no.3206 ]
  ret ptr %v3228
}

define private ptr @mlf.worker.90(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) {
entry:
  %v3172 = call ptr @mlf_prim2(i64 11, ptr %a2, ptr %a1)
  %v3173 = icmp eq ptr %v3172, inttoptr (i64 6 to ptr)
  br i1 %v3173, label %yes.3174, label %no.3175
yes.3174:
  %v3185 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3177, i64 2)
  %v3186 = getelementptr i8, ptr %v3185, i64 16
  %v3187 = load ptr, ptr %v3186, align 8, !tbaa !3
  %v3188 = getelementptr i8, ptr %v3187, i64 8
  store ptr %a0, ptr %v3188, align 8, !tbaa !3
  %v3189 = getelementptr i8, ptr %v3187, i64 16
  store ptr %a2, ptr %v3189, align 8, !tbaa !3
  %v3229 = call ptr @mlf_env_new(i64 5)
  %v3230 = getelementptr i8, ptr %v3229, i64 8
  store ptr %a0, ptr %v3230, align 8, !tbaa !3
  %v3231 = getelementptr i8, ptr %v3229, i64 16
  store ptr %a1, ptr %v3231, align 8, !tbaa !3
  %v3232 = getelementptr i8, ptr %v3229, i64 24
  store ptr %a2, ptr %v3232, align 8, !tbaa !3
  %v3233 = getelementptr i8, ptr %v3229, i64 32
  store ptr %a3, ptr %v3233, align 8, !tbaa !3
  %v3234 = getelementptr i8, ptr %v3229, i64 40
  store ptr %a4, ptr %v3234, align 8, !tbaa !3
  %v3235 = call ptr @mlf_closure(ptr @mlf.code.3190, ptr %v3229)
  %v3236 = call ptr @mlf_prim2(i64 1, ptr %v3185, ptr %v3235)
  br label %join.3176
no.3175:
  %v3237 = call ptr @mlf_prim1(i64 0, ptr %a3)
  br label %join.3176
join.3176:
  %v3238 = phi ptr [ %v3236, %yes.3174 ], [ %v3237, %no.3175 ]
  ret ptr %v3238
}

define private ptr @mlf.numeric.entry.3068(ptr %env, ptr %arg) {
entry:
  %v3069 = getelementptr i8, ptr %env, i64 8
  %v3070 = load ptr, ptr %v3069, align 8, !tbaa !3
  %v3071 = getelementptr i8, ptr %env, i64 16
  %v3072 = load ptr, ptr %v3071, align 8, !tbaa !3
  %v3073 = getelementptr i8, ptr %env, i64 24
  %v3074 = load ptr, ptr %v3073, align 8, !tbaa !3
  %v3075 = getelementptr i8, ptr %env, i64 32
  %v3076 = load ptr, ptr %v3075, align 8, !tbaa !3
  %v3077 = getelementptr i8, ptr %env, i64 40
  %v3078 = load ptr, ptr %v3077, align 8, !tbaa !3
  %v3079 = call ptr @mlf_peek(ptr %v3070)
  %v3080 = call ptr @mlf_peek(ptr %v3072)
  %v3081 = call ptr @mlf_peek(ptr %v3074)
  %v3082 = call ptr @mlf_peek(ptr %v3076)
  %v3083 = call ptr @mlf_peek(ptr %v3078)
  %v3084 = icmp ne ptr %v3079, null
  %v3085 = icmp ne ptr %v3080, null
  %v3086 = icmp ne ptr %v3081, null
  %v3087 = icmp ne ptr %v3082, null
  %v3088 = icmp ne ptr %v3083, null
  %v3089 = and i1 true, %v3084
  %v3090 = and i1 %v3089, %v3085
  %v3091 = and i1 %v3090, %v3086
  %v3092 = and i1 %v3091, %v3087
  %v3093 = and i1 %v3092, %v3088
  br i1 %v3093, label %yes.3094, label %no.3095
yes.3094:
  %v3170 = call ptr @mlf.numeric.90(ptr %v3079, ptr %v3080, ptr %v3081, ptr %v3082, ptr %v3083)
  %v3171 = call ptr @mlf_prim1(i64 0, ptr %v3170)
  br label %join.3096
no.3095:
  %v3239 = call ptr @mlf.force(ptr %v3072)
  %v3240 = call ptr @mlf.force(ptr %v3074)
  %v3241 = call ptr @mlf.worker.90(ptr %v3070, ptr %v3239, ptr %v3240, ptr %v3076, ptr %v3078)
  br label %join.3096
join.3096:
  %v3242 = phi ptr [ %v3171, %yes.3094 ], [ %v3241, %no.3095 ]
  ret ptr %v3242
}

define private ptr @mlf.code.3061(ptr %env, ptr %arg) {
entry:
  %v3062 = getelementptr i8, ptr %env, i64 8
  %v3063 = load ptr, ptr %v3062, align 8, !tbaa !3
  %v3064 = getelementptr i8, ptr %env, i64 16
  %v3065 = load ptr, ptr %v3064, align 8, !tbaa !3
  %v3066 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3066, align 8, !tbaa !3
  %v3067 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v3067, align 8, !tbaa !3
  %v3243 = call ptr @mlf.force(ptr %v3065)
  %v3244 = call ptr @mlf_env_new(i64 5)
  %v3245 = getelementptr i8, ptr %v3244, i64 8
  store ptr %v3063, ptr %v3245, align 8, !tbaa !3
  %v3246 = getelementptr i8, ptr %v3244, i64 16
  store ptr %v3243, ptr %v3246, align 8, !tbaa !3
  %v3247 = getelementptr i8, ptr %v3244, i64 24
  store ptr inttoptr (i64 1 to ptr), ptr %v3247, align 8, !tbaa !3
  %v3248 = getelementptr i8, ptr %v3244, i64 32
  store ptr inttoptr (i64 1 to ptr), ptr %v3248, align 8, !tbaa !3
  %v3249 = getelementptr i8, ptr %v3244, i64 40
  store ptr inttoptr (i64 1 to ptr), ptr %v3249, align 8, !tbaa !3
  %v3250 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.3068, ptr %v3244)
  ret ptr %v3250
}

define private ptr @mlf.code.3267(ptr %env, ptr %arg) {
entry:
  %v3268 = getelementptr i8, ptr %env, i64 8
  %v3269 = load ptr, ptr %v3268, align 8, !tbaa !3
  %v3270 = getelementptr i8, ptr %env, i64 16
  %v3271 = load ptr, ptr %v3270, align 8, !tbaa !3
  %v3272 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3272, align 8, !tbaa !3
  %v3273 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v3273, align 8, !tbaa !3
  %v3274 = call ptr @mlf_prim2(i64 43, ptr %v3269, ptr %v3271)
  ret ptr %v3274
}

define private ptr @mlf.code.3312(ptr %env, ptr %arg) {
entry:
  %v3313 = getelementptr i8, ptr %env, i64 8
  %v3314 = load ptr, ptr %v3313, align 8, !tbaa !3
  %v3315 = getelementptr i8, ptr %env, i64 16
  %v3316 = load ptr, ptr %v3315, align 8, !tbaa !3
  %v3317 = getelementptr i8, ptr %env, i64 24
  %v3318 = load ptr, ptr %v3317, align 8, !tbaa !3
  %v3319 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3319, align 8, !tbaa !3
  %v3320 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v3320, align 8, !tbaa !3
  %v3321 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v3321, align 8, !tbaa !3
  %v3322 = call ptr @mlf_double(double 0x4059000000000000)
  %v3323 = call ptr @mlf.force(ptr %v3318)
  %v3324 = call ptr @mlf_prim1(i64 25, ptr %v3323)
  %v3325 = getelementptr i8, ptr %v3322, i64 8
  %v3326 = load double, ptr %v3325, align 8, !tbaa !3
  %v3327 = getelementptr i8, ptr %v3324, i64 8
  %v3328 = load double, ptr %v3327, align 8, !tbaa !3
  %v3329 = fmul double %v3326, %v3328
  %v3330 = call ptr @mlf_double(double %v3329)
  %v3331 = call ptr @mlf.force(ptr %v3314)
  %v3332 = call ptr @mlf.force(ptr %v3316)
  %v3333 = ptrtoint ptr %v3331 to i64
  %v3334 = ptrtoint ptr %v3332 to i64
  %v3335 = and i64 %v3333, %v3334
  %v3336 = and i64 %v3335, 1
  %v3337 = icmp ne i64 %v3336, 0
  br i1 %v3337, label %yes.3338, label %no.3339
yes.3338:
  %v3341 = sub i64 %v3334, 1
  %v3342 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v3333, i64 %v3341)
  %v3343 = extractvalue { i64, i1 } %v3342, 0
  %v3344 = extractvalue { i64, i1 } %v3342, 1
  br i1 %v3344, label %yes.3345, label %no.3346
yes.3345:
  %v3348 = call ptr @mlf_sub_int(ptr %v3331, ptr %v3332)
  br label %join.3347
no.3346:
  %v3349 = inttoptr i64 %v3343 to ptr
  br label %join.3347
join.3347:
  %v3350 = phi ptr [ %v3348, %yes.3345 ], [ %v3349, %no.3346 ]
  br label %join.3340
no.3339:
  %v3351 = call ptr @mlf_sub_int(ptr %v3331, ptr %v3332)
  br label %join.3340
join.3340:
  %v3352 = phi ptr [ %v3350, %join.3347 ], [ %v3351, %no.3339 ]
  %v3353 = ptrtoint ptr %v3352 to i64
  %v3354 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v3355 = and i64 %v3353, %v3354
  %v3356 = and i64 %v3355, 1
  %v3357 = icmp ne i64 %v3356, 0
  br i1 %v3357, label %yes.3358, label %no.3359
yes.3358:
  %v3361 = sub i64 %v3354, 1
  %v3362 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v3353, i64 %v3361)
  %v3363 = extractvalue { i64, i1 } %v3362, 0
  %v3364 = extractvalue { i64, i1 } %v3362, 1
  br i1 %v3364, label %yes.3365, label %no.3366
yes.3365:
  %v3368 = call ptr @mlf_add_int(ptr %v3352, ptr inttoptr (i64 3 to ptr))
  br label %join.3367
no.3366:
  %v3369 = inttoptr i64 %v3363 to ptr
  br label %join.3367
join.3367:
  %v3370 = phi ptr [ %v3368, %yes.3365 ], [ %v3369, %no.3366 ]
  br label %join.3360
no.3359:
  %v3371 = call ptr @mlf_add_int(ptr %v3352, ptr inttoptr (i64 3 to ptr))
  br label %join.3360
join.3360:
  %v3372 = phi ptr [ %v3370, %join.3367 ], [ %v3371, %no.3359 ]
  %v3373 = call ptr @mlf_prim1(i64 25, ptr %v3372)
  %v3374 = getelementptr i8, ptr %v3330, i64 8
  %v3375 = load double, ptr %v3374, align 8, !tbaa !3
  %v3376 = getelementptr i8, ptr %v3373, i64 8
  %v3377 = load double, ptr %v3376, align 8, !tbaa !3
  %v3378 = fdiv double %v3375, %v3377
  %v3379 = call ptr @mlf_double(double %v3378)
  ret ptr %v3379
}

define private ptr @mlf.worker.88(ptr %a0) {
entry:
  %v3423 = ptrtoint ptr %a0 to i64
  %v3424 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v3425 = and i64 %v3423, %v3424
  %v3426 = and i64 %v3425, 1
  %v3427 = icmp ne i64 %v3426, 0
  br i1 %v3427, label %yes.3428, label %no.3429
yes.3428:
  %v3431 = icmp eq i64 %v3423, %v3424
  %v3432 = select i1 %v3431, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.3430
no.3429:
  %v3433 = call ptr @mlf_eq_int(ptr %a0, ptr inttoptr (i64 1 to ptr))
  br label %join.3430
join.3430:
  %v3434 = phi ptr [ %v3432, %yes.3428 ], [ %v3433, %no.3429 ]
  %v3435 = icmp eq ptr %v3434, inttoptr (i64 6 to ptr)
  br i1 %v3435, label %yes.3436, label %no.3437
yes.3436:
  br label %join.3438
no.3437:
  %v3440 = ptrtoint ptr %a0 to i64
  %v3441 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v3442 = and i64 %v3440, %v3441
  %v3443 = and i64 %v3442, 1
  %v3444 = icmp ne i64 %v3443, 0
  br i1 %v3444, label %yes.3445, label %no.3446
yes.3445:
  %v3448 = icmp eq i64 %v3440, %v3441
  %v3449 = select i1 %v3448, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.3447
no.3446:
  %v3450 = call ptr @mlf_eq_int(ptr %a0, ptr inttoptr (i64 3 to ptr))
  br label %join.3447
join.3447:
  %v3451 = phi ptr [ %v3449, %yes.3445 ], [ %v3450, %no.3446 ]
  %v3452 = icmp eq ptr %v3451, inttoptr (i64 6 to ptr)
  br i1 %v3452, label %yes.3453, label %no.3454
yes.3453:
  br label %join.3455
no.3454:
  %v3457 = ptrtoint ptr %a0 to i64
  %v3458 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v3459 = and i64 %v3457, %v3458
  %v3460 = and i64 %v3459, 1
  %v3461 = icmp ne i64 %v3460, 0
  br i1 %v3461, label %yes.3462, label %no.3463
yes.3462:
  %v3465 = icmp eq i64 %v3457, %v3458
  %v3466 = select i1 %v3465, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.3464
no.3463:
  %v3467 = call ptr @mlf_eq_int(ptr %a0, ptr inttoptr (i64 5 to ptr))
  br label %join.3464
join.3464:
  %v3468 = phi ptr [ %v3466, %yes.3462 ], [ %v3467, %no.3463 ]
  %v3469 = icmp eq ptr %v3468, inttoptr (i64 6 to ptr)
  br i1 %v3469, label %yes.3470, label %no.3471
yes.3470:
  br label %join.3472
no.3471:
  br label %join.3472
join.3472:
  %v3475 = phi ptr [ @mlf.bytes.3473.value, %yes.3470 ], [ @mlf.bytes.3474.value, %no.3471 ]
  br label %join.3455
join.3455:
  %v3476 = phi ptr [ @mlf.bytes.3456.value, %yes.3453 ], [ %v3475, %join.3472 ]
  br label %join.3438
join.3438:
  %v3477 = phi ptr [ @mlf.bytes.3439.value, %yes.3436 ], [ %v3476, %join.3455 ]
  ret ptr %v3477
}

define private ptr @mlf.code.3396(ptr %env, ptr %arg) {
entry:
  %v3397 = getelementptr i8, ptr %env, i64 8
  %v3398 = load ptr, ptr %v3397, align 8, !tbaa !3
  %v3399 = getelementptr i8, ptr %env, i64 16
  %v3400 = load ptr, ptr %v3399, align 8, !tbaa !3
  %v3401 = getelementptr i8, ptr %env, i64 24
  %v3402 = load ptr, ptr %v3401, align 8, !tbaa !3
  %v3403 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3403, align 8, !tbaa !3
  %v3404 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v3404, align 8, !tbaa !3
  %v3405 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v3405, align 8, !tbaa !3
  %v3406 = call ptr @mlf.force(ptr %v3398)
  %v3407 = ptrtoint ptr %v3406 to i64
  %v3408 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v3409 = and i64 %v3407, %v3408
  %v3410 = and i64 %v3409, 1
  %v3411 = icmp ne i64 %v3410, 0
  br i1 %v3411, label %yes.3412, label %no.3413
yes.3412:
  %v3415 = icmp eq i64 %v3407, %v3408
  %v3416 = select i1 %v3415, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.3414
no.3413:
  %v3417 = call ptr @mlf_eq_int(ptr %v3406, ptr inttoptr (i64 3 to ptr))
  br label %join.3414
join.3414:
  %v3418 = phi ptr [ %v3416, %yes.3412 ], [ %v3417, %no.3413 ]
  %v3419 = icmp eq ptr %v3418, inttoptr (i64 6 to ptr)
  br i1 %v3419, label %yes.3420, label %no.3421
yes.3420:
  %v3478 = call ptr @mlf.force(ptr %v3400)
  %v3479 = call ptr @mlf.worker.88(ptr %v3478)
  br label %join.3422
no.3421:
  %v3480 = call ptr @mlf.force(ptr %v3400)
  %v3481 = ptrtoint ptr %v3480 to i64
  %v3482 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v3483 = and i64 %v3481, %v3482
  %v3484 = and i64 %v3483, 1
  %v3485 = icmp ne i64 %v3484, 0
  br i1 %v3485, label %yes.3486, label %no.3487
yes.3486:
  %v3489 = ashr i64 %v3481, 1
  %v3490 = ashr i64 %v3482, 1
  %v3491 = icmp ne i64 %v3490, 0
  %v3492 = icmp eq i64 %v3489, -4611686018427387904
  %v3493 = icmp eq i64 %v3490, -1
  %v3494 = and i1 %v3492, %v3493
  %v3495 = xor i1 %v3494, true
  %v3496 = and i1 %v3491, %v3495
  br i1 %v3496, label %yes.3497, label %no.3498
yes.3497:
  %v3500 = sdiv i64 %v3489, %v3490
  %v3501 = shl i64 %v3500, 1
  %v3502 = or i64 %v3501, 1
  %v3503 = inttoptr i64 %v3502 to ptr
  br label %join.3499
no.3498:
  %v3504 = call ptr @mlf_prim2(i64 15, ptr %v3480, ptr inttoptr (i64 9 to ptr))
  br label %join.3499
join.3499:
  %v3505 = phi ptr [ %v3503, %yes.3497 ], [ %v3504, %no.3498 ]
  br label %join.3488
no.3487:
  %v3506 = call ptr @mlf_prim2(i64 15, ptr %v3480, ptr inttoptr (i64 9 to ptr))
  br label %join.3488
join.3488:
  %v3507 = phi ptr [ %v3505, %join.3499 ], [ %v3506, %no.3487 ]
  %v3508 = call ptr @mlf.worker.88(ptr %v3507)
  %v3509 = ptrtoint ptr %v3480 to i64
  %v3510 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v3511 = and i64 %v3509, %v3510
  %v3512 = and i64 %v3511, 1
  %v3513 = icmp ne i64 %v3512, 0
  br i1 %v3513, label %yes.3514, label %no.3515
yes.3514:
  %v3517 = ashr i64 %v3509, 1
  %v3518 = ashr i64 %v3510, 1
  %v3519 = icmp ne i64 %v3518, 0
  %v3520 = icmp eq i64 %v3517, -4611686018427387904
  %v3521 = icmp eq i64 %v3518, -1
  %v3522 = and i1 %v3520, %v3521
  %v3523 = xor i1 %v3522, true
  %v3524 = and i1 %v3519, %v3523
  br i1 %v3524, label %yes.3525, label %no.3526
yes.3525:
  %v3528 = srem i64 %v3517, %v3518
  %v3529 = shl i64 %v3528, 1
  %v3530 = or i64 %v3529, 1
  %v3531 = inttoptr i64 %v3530 to ptr
  br label %join.3527
no.3526:
  %v3532 = call ptr @mlf_prim2(i64 16, ptr %v3480, ptr inttoptr (i64 9 to ptr))
  br label %join.3527
join.3527:
  %v3533 = phi ptr [ %v3531, %yes.3525 ], [ %v3532, %no.3526 ]
  br label %join.3516
no.3515:
  %v3534 = call ptr @mlf_prim2(i64 16, ptr %v3480, ptr inttoptr (i64 9 to ptr))
  br label %join.3516
join.3516:
  %v3535 = phi ptr [ %v3533, %join.3527 ], [ %v3534, %no.3515 ]
  %v3536 = call ptr @mlf.worker.88(ptr %v3535)
  %v3537 = call ptr @mlf_prim2(i64 6, ptr %v3508, ptr %v3536)
  br label %join.3422
join.3422:
  %v3538 = phi ptr [ %v3479, %yes.3420 ], [ %v3537, %join.3516 ]
  %v3540 = call ptr @mlf.force(ptr %v3402)
  %v3541 = call ptr @mlf_prim2(i64 26, ptr inttoptr (i64 7 to ptr), ptr %v3540)
  %v3542 = call ptr @mlf_prim2(i64 6, ptr @mlf.bytes.3539.value, ptr %v3541)
  %v3543 = call ptr @mlf_prim2(i64 6, ptr %v3538, ptr %v3542)
  ret ptr %v3543
}

define private ptr @mlf.code.3386(ptr %env, ptr %arg) {
entry:
  %v3387 = getelementptr i8, ptr %env, i64 8
  %v3388 = load ptr, ptr %v3387, align 8, !tbaa !3
  %v3389 = getelementptr i8, ptr %env, i64 16
  %v3390 = load ptr, ptr %v3389, align 8, !tbaa !3
  %v3391 = getelementptr i8, ptr %env, i64 24
  %v3392 = load ptr, ptr %v3391, align 8, !tbaa !3
  %v3393 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3393, align 8, !tbaa !3
  %v3394 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v3394, align 8, !tbaa !3
  %v3395 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v3395, align 8, !tbaa !3
  %v3544 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3396, i64 3)
  %v3545 = getelementptr i8, ptr %v3544, i64 16
  %v3546 = load ptr, ptr %v3545, align 8, !tbaa !3
  %v3547 = getelementptr i8, ptr %v3546, i64 8
  store ptr %v3388, ptr %v3547, align 8, !tbaa !3
  %v3548 = getelementptr i8, ptr %v3546, i64 16
  store ptr %v3390, ptr %v3548, align 8, !tbaa !3
  %v3549 = getelementptr i8, ptr %v3546, i64 24
  store ptr %v3392, ptr %v3549, align 8, !tbaa !3
  %v3550 = call ptr @mlf_prim1(i64 3, ptr %v3544)
  ret ptr %v3550
}

define private ptr @mlf.code.3570(ptr %env, ptr %arg) {
entry:
  %v3571 = getelementptr i8, ptr %env, i64 8
  %v3572 = load ptr, ptr %v3571, align 8, !tbaa !3
  %v3573 = getelementptr i8, ptr %env, i64 16
  %v3574 = load ptr, ptr %v3573, align 8, !tbaa !3
  %v3575 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3575, align 8, !tbaa !3
  %v3576 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v3576, align 8, !tbaa !3
  %v3577 = call ptr @mlf_prim3(i64 44, ptr %v3572, ptr %v3574, ptr inttoptr (i64 1 to ptr))
  ret ptr %v3577
}

define private ptr @mlf.code.3583(ptr %env, ptr %arg) {
entry:
  %v3584 = getelementptr i8, ptr %env, i64 8
  %v3585 = load ptr, ptr %v3584, align 8, !tbaa !3
  %v3586 = getelementptr i8, ptr %env, i64 16
  %v3587 = load ptr, ptr %v3586, align 8, !tbaa !3
  %v3588 = getelementptr i8, ptr %env, i64 24
  %v3589 = load ptr, ptr %v3588, align 8, !tbaa !3
  %v3590 = getelementptr i8, ptr %env, i64 32
  %v3591 = load ptr, ptr %v3590, align 8, !tbaa !3
  %v3592 = getelementptr i8, ptr %env, i64 40
  %v3593 = load ptr, ptr %v3592, align 8, !tbaa !3
  %v3594 = call ptr @mlf.force(ptr %v3593)
  %v3595 = ptrtoint ptr %v3594 to i64
  %v3596 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v3597 = and i64 %v3595, %v3596
  %v3598 = and i64 %v3597, 1
  %v3599 = icmp ne i64 %v3598, 0
  br i1 %v3599, label %yes.3600, label %no.3601
yes.3600:
  %v3603 = sub i64 %v3596, 1
  %v3604 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v3595, i64 %v3603)
  %v3605 = extractvalue { i64, i1 } %v3604, 0
  %v3606 = extractvalue { i64, i1 } %v3604, 1
  br i1 %v3606, label %yes.3607, label %no.3608
yes.3607:
  %v3610 = call ptr @mlf_sub_int(ptr %v3594, ptr inttoptr (i64 3 to ptr))
  br label %join.3609
no.3608:
  %v3611 = inttoptr i64 %v3605 to ptr
  br label %join.3609
join.3609:
  %v3612 = phi ptr [ %v3610, %yes.3607 ], [ %v3611, %no.3608 ]
  br label %join.3602
no.3601:
  %v3613 = call ptr @mlf_sub_int(ptr %v3594, ptr inttoptr (i64 3 to ptr))
  br label %join.3602
join.3602:
  %v3614 = phi ptr [ %v3612, %join.3609 ], [ %v3613, %no.3601 ]
  %v3615 = call ptr @mlf.worker.97(ptr %v3585, ptr %v3587, ptr %v3589, ptr %v3591, ptr %v3614)
  ret ptr %v3615
}

define private ptr @mlf.code.3557(ptr %env, ptr %arg) {
entry:
  %v3558 = getelementptr i8, ptr %env, i64 8
  %v3559 = load ptr, ptr %v3558, align 8, !tbaa !3
  %v3560 = getelementptr i8, ptr %env, i64 16
  %v3561 = load ptr, ptr %v3560, align 8, !tbaa !3
  %v3562 = getelementptr i8, ptr %env, i64 24
  %v3563 = load ptr, ptr %v3562, align 8, !tbaa !3
  %v3564 = getelementptr i8, ptr %env, i64 32
  %v3565 = load ptr, ptr %v3564, align 8, !tbaa !3
  %v3566 = getelementptr i8, ptr %env, i64 40
  %v3567 = load ptr, ptr %v3566, align 8, !tbaa !3
  %v3568 = getelementptr i8, ptr %env, i64 48
  %v3569 = load ptr, ptr %v3568, align 8, !tbaa !3
  %v3578 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3570, i64 2)
  %v3579 = getelementptr i8, ptr %v3578, i64 16
  %v3580 = load ptr, ptr %v3579, align 8, !tbaa !3
  %v3581 = getelementptr i8, ptr %v3580, i64 8
  store ptr %v3559, ptr %v3581, align 8, !tbaa !3
  %v3582 = getelementptr i8, ptr %v3580, i64 16
  store ptr %v3569, ptr %v3582, align 8, !tbaa !3
  %v3616 = call ptr @mlf_env_new(i64 5)
  %v3617 = getelementptr i8, ptr %v3616, i64 8
  store ptr %v3559, ptr %v3617, align 8, !tbaa !3
  %v3618 = getelementptr i8, ptr %v3616, i64 16
  store ptr %v3561, ptr %v3618, align 8, !tbaa !3
  %v3619 = getelementptr i8, ptr %v3616, i64 24
  store ptr %v3563, ptr %v3619, align 8, !tbaa !3
  %v3620 = getelementptr i8, ptr %v3616, i64 32
  store ptr %v3565, ptr %v3620, align 8, !tbaa !3
  %v3621 = getelementptr i8, ptr %v3616, i64 40
  store ptr %v3567, ptr %v3621, align 8, !tbaa !3
  %v3622 = call ptr @mlf_closure(ptr @mlf.code.3583, ptr %v3616)
  %v3623 = call ptr @mlf_prim2(i64 1, ptr %v3578, ptr %v3622)
  ret ptr %v3623
}

define private ptr @mlf.code.3280(ptr %env, ptr %arg) {
entry:
  %v3281 = getelementptr i8, ptr %env, i64 8
  %v3282 = load ptr, ptr %v3281, align 8, !tbaa !3
  %v3283 = getelementptr i8, ptr %env, i64 16
  %v3284 = load ptr, ptr %v3283, align 8, !tbaa !3
  %v3285 = getelementptr i8, ptr %env, i64 24
  %v3286 = load ptr, ptr %v3285, align 8, !tbaa !3
  %v3287 = getelementptr i8, ptr %env, i64 32
  %v3288 = load ptr, ptr %v3287, align 8, !tbaa !3
  %v3289 = getelementptr i8, ptr %env, i64 40
  %v3290 = load ptr, ptr %v3289, align 8, !tbaa !3
  %v3291 = getelementptr i8, ptr %env, i64 48
  %v3292 = load ptr, ptr %v3291, align 8, !tbaa !3
  %v3293 = call ptr @mlf.force(ptr %arg)
  %v3294 = ptrtoint ptr %v3293 to i64
  %v3295 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v3296 = and i64 %v3294, %v3295
  %v3297 = and i64 %v3296, 1
  %v3298 = icmp ne i64 %v3297, 0
  br i1 %v3298, label %yes.3299, label %no.3300
yes.3299:
  %v3302 = icmp eq i64 %v3294, %v3295
  %v3303 = select i1 %v3302, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.3301
no.3300:
  %v3304 = call ptr @mlf_eq_int(ptr %v3293, ptr inttoptr (i64 1 to ptr))
  br label %join.3301
join.3301:
  %v3305 = phi ptr [ %v3303, %yes.3299 ], [ %v3304, %no.3300 ]
  %v3306 = icmp eq ptr %v3305, inttoptr (i64 6 to ptr)
  br i1 %v3306, label %yes.3307, label %no.3308
yes.3307:
  %v3311 = call ptr @mlf_prim1(i64 3, ptr @mlf.bytes.3310.value)
  br label %join.3309
no.3308:
  %v3380 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3312, i64 3)
  %v3381 = getelementptr i8, ptr %v3380, i64 16
  %v3382 = load ptr, ptr %v3381, align 8, !tbaa !3
  %v3383 = getelementptr i8, ptr %v3382, i64 8
  store ptr %v3284, ptr %v3383, align 8, !tbaa !3
  %v3384 = getelementptr i8, ptr %v3382, i64 16
  store ptr %v3286, ptr %v3384, align 8, !tbaa !3
  %v3385 = getelementptr i8, ptr %v3382, i64 24
  store ptr %v3293, ptr %v3385, align 8, !tbaa !3
  %v3551 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3386, i64 3)
  %v3552 = getelementptr i8, ptr %v3551, i64 16
  %v3553 = load ptr, ptr %v3552, align 8, !tbaa !3
  %v3554 = getelementptr i8, ptr %v3553, i64 8
  store ptr %v3286, ptr %v3554, align 8, !tbaa !3
  %v3555 = getelementptr i8, ptr %v3553, i64 16
  store ptr %v3292, ptr %v3555, align 8, !tbaa !3
  %v3556 = getelementptr i8, ptr %v3553, i64 24
  store ptr %v3380, ptr %v3556, align 8, !tbaa !3
  %v3624 = call ptr @mlf_env_new(i64 6)
  %v3625 = getelementptr i8, ptr %v3624, i64 8
  store ptr %v3282, ptr %v3625, align 8, !tbaa !3
  %v3626 = getelementptr i8, ptr %v3624, i64 16
  store ptr %v3284, ptr %v3626, align 8, !tbaa !3
  %v3627 = getelementptr i8, ptr %v3624, i64 24
  store ptr %v3286, ptr %v3627, align 8, !tbaa !3
  %v3628 = getelementptr i8, ptr %v3624, i64 32
  store ptr %v3288, ptr %v3628, align 8, !tbaa !3
  %v3629 = getelementptr i8, ptr %v3624, i64 40
  store ptr %v3290, ptr %v3629, align 8, !tbaa !3
  %v3630 = getelementptr i8, ptr %v3624, i64 48
  store ptr %v3292, ptr %v3630, align 8, !tbaa !3
  %v3631 = call ptr @mlf_closure(ptr @mlf.code.3557, ptr %v3624)
  %v3632 = call ptr @mlf_prim2(i64 1, ptr %v3551, ptr %v3631)
  br label %join.3309
join.3309:
  %v3633 = phi ptr [ %v3311, %yes.3307 ], [ %v3632, %no.3308 ]
  ret ptr %v3633
}

define private ptr @mlf.code.3256(ptr %env, ptr %arg) {
entry:
  %v3257 = getelementptr i8, ptr %env, i64 8
  %v3258 = load ptr, ptr %v3257, align 8, !tbaa !3
  %v3259 = getelementptr i8, ptr %env, i64 16
  %v3260 = load ptr, ptr %v3259, align 8, !tbaa !3
  %v3261 = getelementptr i8, ptr %env, i64 24
  %v3262 = load ptr, ptr %v3261, align 8, !tbaa !3
  %v3263 = getelementptr i8, ptr %env, i64 32
  %v3264 = load ptr, ptr %v3263, align 8, !tbaa !3
  %v3265 = getelementptr i8, ptr %env, i64 40
  %v3266 = load ptr, ptr %v3265, align 8, !tbaa !3
  %v3275 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3267, i64 2)
  %v3276 = getelementptr i8, ptr %v3275, i64 16
  %v3277 = load ptr, ptr %v3276, align 8, !tbaa !3
  %v3278 = getelementptr i8, ptr %v3277, i64 8
  store ptr %v3258, ptr %v3278, align 8, !tbaa !3
  %v3279 = getelementptr i8, ptr %v3277, i64 16
  store ptr %arg, ptr %v3279, align 8, !tbaa !3
  %v3634 = call ptr @mlf_env_new(i64 6)
  %v3635 = getelementptr i8, ptr %v3634, i64 8
  store ptr %v3258, ptr %v3635, align 8, !tbaa !3
  %v3636 = getelementptr i8, ptr %v3634, i64 16
  store ptr %v3260, ptr %v3636, align 8, !tbaa !3
  %v3637 = getelementptr i8, ptr %v3634, i64 24
  store ptr %v3262, ptr %v3637, align 8, !tbaa !3
  %v3638 = getelementptr i8, ptr %v3634, i64 32
  store ptr %v3264, ptr %v3638, align 8, !tbaa !3
  %v3639 = getelementptr i8, ptr %v3634, i64 40
  store ptr %v3266, ptr %v3639, align 8, !tbaa !3
  %v3640 = getelementptr i8, ptr %v3634, i64 48
  store ptr %arg, ptr %v3640, align 8, !tbaa !3
  %v3641 = call ptr @mlf_closure(ptr @mlf.code.3280, ptr %v3634)
  %v3642 = call ptr @mlf_prim2(i64 1, ptr %v3275, ptr %v3641)
  ret ptr %v3642
}

define private ptr @mlf.worker.97(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) {
entry:
  %v3043 = ptrtoint ptr %a4 to i64
  %v3044 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v3045 = and i64 %v3043, %v3044
  %v3046 = and i64 %v3045, 1
  %v3047 = icmp ne i64 %v3046, 0
  br i1 %v3047, label %yes.3048, label %no.3049
yes.3048:
  %v3051 = icmp eq i64 %v3043, %v3044
  %v3052 = select i1 %v3051, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.3050
no.3049:
  %v3053 = call ptr @mlf_eq_int(ptr %a4, ptr inttoptr (i64 1 to ptr))
  br label %join.3050
join.3050:
  %v3054 = phi ptr [ %v3052, %yes.3048 ], [ %v3053, %no.3049 ]
  %v3055 = icmp eq ptr %v3054, inttoptr (i64 6 to ptr)
  br i1 %v3055, label %yes.3056, label %no.3057
yes.3056:
  %v3060 = call ptr @mlf_prim1(i64 3, ptr @mlf.bytes.3059.value)
  br label %join.3058
no.3057:
  %v3251 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3061, i64 2)
  %v3252 = getelementptr i8, ptr %v3251, i64 16
  %v3253 = load ptr, ptr %v3252, align 8, !tbaa !3
  %v3254 = getelementptr i8, ptr %v3253, i64 8
  store ptr %a0, ptr %v3254, align 8, !tbaa !3
  %v3255 = getelementptr i8, ptr %v3253, i64 16
  store ptr %a3, ptr %v3255, align 8, !tbaa !3
  %v3643 = call ptr @mlf_env_new(i64 5)
  %v3644 = getelementptr i8, ptr %v3643, i64 8
  store ptr %a0, ptr %v3644, align 8, !tbaa !3
  %v3645 = getelementptr i8, ptr %v3643, i64 16
  store ptr %a1, ptr %v3645, align 8, !tbaa !3
  %v3646 = getelementptr i8, ptr %v3643, i64 24
  store ptr %a2, ptr %v3646, align 8, !tbaa !3
  %v3647 = getelementptr i8, ptr %v3643, i64 32
  store ptr %a3, ptr %v3647, align 8, !tbaa !3
  %v3648 = getelementptr i8, ptr %v3643, i64 40
  store ptr %a4, ptr %v3648, align 8, !tbaa !3
  %v3649 = call ptr @mlf_closure(ptr @mlf.code.3256, ptr %v3643)
  %v3650 = call ptr @mlf_prim2(i64 1, ptr %v3251, ptr %v3649)
  br label %join.3058
join.3058:
  %v3651 = phi ptr [ %v3060, %yes.3056 ], [ %v3650, %no.3057 ]
  ret ptr %v3651
}

define private ptr @mlf.code.3036(ptr %env, ptr %arg) {
entry:
  %v3037 = getelementptr i8, ptr %env, i64 8
  %v3038 = load ptr, ptr %v3037, align 8, !tbaa !3
  %v3039 = getelementptr i8, ptr %env, i64 16
  %v3040 = load ptr, ptr %v3039, align 8, !tbaa !3
  %v3041 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3041, align 8, !tbaa !3
  %v3042 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v3042, align 8, !tbaa !3
  %v3652 = call ptr @mlf.worker.97(ptr %v3040, ptr %v3038, ptr inttoptr (i64 3 to ptr), ptr inttoptr (i64 9 to ptr), ptr inttoptr (i64 9 to ptr))
  ret ptr %v3652
}

define private ptr @mlf.code.3663(ptr %env, ptr %arg) {
entry:
  %v3664 = getelementptr i8, ptr %env, i64 8
  %v3665 = load ptr, ptr %v3664, align 8, !tbaa !3
  %v3666 = getelementptr i8, ptr %env, i64 16
  %v3667 = load ptr, ptr %v3666, align 8, !tbaa !3
  %v3668 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3668, align 8, !tbaa !3
  %v3669 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v3669, align 8, !tbaa !3
  %v3670 = call ptr @mlf_env_new(i64 3)
  %v3671 = getelementptr i8, ptr %v3670, i64 8
  store ptr %v3665, ptr %v3671, align 8, !tbaa !3
  %v3672 = getelementptr i8, ptr %v3670, i64 16
  store ptr %v3667, ptr %v3672, align 8, !tbaa !3
  %v3673 = getelementptr i8, ptr %v3670, i64 24
  store ptr inttoptr (i64 5 to ptr), ptr %v3673, align 8, !tbaa !3
  %v3674 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2111, ptr %v3670)
  ret ptr %v3674
}

define private ptr @mlf.code.3685(ptr %env, ptr %arg) {
entry:
  %v3686 = getelementptr i8, ptr %env, i64 8
  %v3687 = load ptr, ptr %v3686, align 8, !tbaa !3
  %v3688 = getelementptr i8, ptr %env, i64 16
  %v3689 = load ptr, ptr %v3688, align 8, !tbaa !3
  %v3690 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3690, align 8, !tbaa !3
  %v3691 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v3691, align 8, !tbaa !3
  %v3692 = call ptr @mlf.worker.97(ptr %v3689, ptr %v3687, ptr inttoptr (i64 5 to ptr), ptr inttoptr (i64 33 to ptr), ptr inttoptr (i64 33 to ptr))
  ret ptr %v3692
}

define private ptr @mlf.code.3710(ptr %env, ptr %arg) {
entry:
  %v3711 = getelementptr i8, ptr %env, i64 8
  %v3712 = load ptr, ptr %v3711, align 8, !tbaa !3
  %v3713 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3713, align 8, !tbaa !3
  %v3714 = call ptr @mlf_prim1(i64 39, ptr %v3712)
  ret ptr %v3714
}

define private ptr @mlf.code.3726(ptr %env, ptr %arg) {
entry:
  %v3727 = getelementptr i8, ptr %env, i64 8
  %v3728 = load ptr, ptr %v3727, align 8, !tbaa !3
  %v3729 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3729, align 8, !tbaa !3
  %v3730 = call ptr @mlf_prim1(i64 38, ptr %v3728)
  ret ptr %v3730
}

define private ptr @mlf.numeric.52.piii(ptr %a0, ptr %a1, ptr %a2, ptr %a3) alwaysinline {
entry:
  %v3795 = ptrtoint ptr %a1 to i64
  %v3796 = ptrtoint ptr %a2 to i64
  %v3797 = icmp slt i64 %v3795, %v3796
  %v3798 = select i1 %v3797, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v3799 = icmp eq ptr %v3798, inttoptr (i64 6 to ptr)
  br i1 %v3799, label %tail.yes.3800, label %tail.no.3801
tail.yes.3800:
  %v3802 = getelementptr i8, ptr %a0, i64 8
  %v3803 = load i64, ptr %v3802, align 8, !tbaa !3
  %v3804 = getelementptr i8, ptr %a0, i64 16
  %v3805 = load ptr, ptr %v3804, align 8, !tbaa !3
  %v3806 = ptrtoint ptr %a1 to i64
  %v3807 = ashr i64 %v3806, 1
  %v3808 = and i64 %v3806, 1
  %v3809 = icmp ne i64 %v3808, 0
  %v3810 = icmp ult i64 %v3807, %v3803
  %v3811 = and i1 %v3809, %v3810
  br i1 %v3811, label %array.valid.3812, label %array.invalid.3813
array.invalid.3813:
  call void @mlf_bounds_failure()
  unreachable
array.valid.3812:
  %v3814 = getelementptr i8, ptr %v3805, i64 %v3807
  %v3815 = load i8, ptr %v3814, align 1, !tbaa !4
  %v3816 = zext i8 %v3815 to i64
  %v3817 = shl i64 %v3816, 1
  %v3818 = or i64 %v3817, 1
  %v3819 = inttoptr i64 %v3818 to ptr
  %v3820 = ptrtoint ptr %a1 to i64
  %v3821 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v3822 = sub i64 %v3821, 1
  %v3823 = add nsw i64 %v3820, %v3822
  %v3824 = inttoptr i64 %v3823 to ptr
  %v3825 = ptrtoint ptr %a3 to i64
  %v3826 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v3827 = ashr i64 %v3825, 1
  %v3828 = ashr i64 %v3826, 1
  %v3829 = mul nsw i64 %v3827, %v3828
  %v3830 = shl i64 %v3829, 1
  %v3831 = or i64 %v3830, 1
  %v3832 = inttoptr i64 %v3831 to ptr
  %v3833 = ptrtoint ptr %v3819 to i64
  %v3834 = ptrtoint ptr inttoptr (i64 131 to ptr) to i64
  %v3835 = icmp eq i64 %v3833, %v3834
  %v3836 = select i1 %v3835, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v3837 = icmp eq ptr %v3836, inttoptr (i64 6 to ptr)
  br i1 %v3837, label %yes.3838, label %no.3839
yes.3838:
  br label %join.3840
no.3839:
  %v3841 = ptrtoint ptr %v3819 to i64
  %v3842 = ptrtoint ptr inttoptr (i64 195 to ptr) to i64
  %v3843 = icmp eq i64 %v3841, %v3842
  %v3844 = select i1 %v3843, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v3845 = icmp eq ptr %v3844, inttoptr (i64 6 to ptr)
  br i1 %v3845, label %yes.3846, label %no.3847
yes.3846:
  br label %join.3848
no.3847:
  %v3849 = ptrtoint ptr %v3819 to i64
  %v3850 = ptrtoint ptr inttoptr (i64 135 to ptr) to i64
  %v3851 = icmp eq i64 %v3849, %v3850
  %v3852 = select i1 %v3851, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v3853 = icmp eq ptr %v3852, inttoptr (i64 6 to ptr)
  br i1 %v3853, label %yes.3854, label %no.3855
yes.3854:
  br label %join.3856
no.3855:
  %v3857 = ptrtoint ptr %v3819 to i64
  %v3858 = ptrtoint ptr inttoptr (i64 199 to ptr) to i64
  %v3859 = icmp eq i64 %v3857, %v3858
  %v3860 = select i1 %v3859, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v3861 = icmp eq ptr %v3860, inttoptr (i64 6 to ptr)
  br i1 %v3861, label %yes.3862, label %no.3863
yes.3862:
  br label %join.3864
no.3863:
  %v3865 = ptrtoint ptr %v3819 to i64
  %v3866 = ptrtoint ptr inttoptr (i64 143 to ptr) to i64
  %v3867 = icmp eq i64 %v3865, %v3866
  %v3868 = select i1 %v3867, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v3869 = icmp eq ptr %v3868, inttoptr (i64 6 to ptr)
  br i1 %v3869, label %yes.3870, label %no.3871
yes.3870:
  br label %join.3872
no.3871:
  %v3873 = ptrtoint ptr %v3819 to i64
  %v3874 = ptrtoint ptr inttoptr (i64 207 to ptr) to i64
  %v3875 = icmp eq i64 %v3873, %v3874
  %v3876 = select i1 %v3875, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v3877 = icmp eq ptr %v3876, inttoptr (i64 6 to ptr)
  br i1 %v3877, label %yes.3878, label %no.3879
yes.3878:
  br label %join.3880
no.3879:
  br label %join.3880
join.3880:
  %v3881 = phi ptr [ inttoptr (i64 5 to ptr), %yes.3878 ], [ inttoptr (i64 7 to ptr), %no.3879 ]
  br label %join.3872
join.3872:
  %v3882 = phi ptr [ inttoptr (i64 5 to ptr), %yes.3870 ], [ %v3881, %join.3880 ]
  br label %join.3864
join.3864:
  %v3883 = phi ptr [ inttoptr (i64 3 to ptr), %yes.3862 ], [ %v3882, %join.3872 ]
  br label %join.3856
join.3856:
  %v3884 = phi ptr [ inttoptr (i64 3 to ptr), %yes.3854 ], [ %v3883, %join.3864 ]
  br label %join.3848
join.3848:
  %v3885 = phi ptr [ inttoptr (i64 1 to ptr), %yes.3846 ], [ %v3884, %join.3856 ]
  br label %join.3840
join.3840:
  %v3886 = phi ptr [ inttoptr (i64 1 to ptr), %yes.3838 ], [ %v3885, %join.3848 ]
  %v3887 = ptrtoint ptr %v3832 to i64
  %v3888 = ptrtoint ptr %v3886 to i64
  %v3889 = sub i64 %v3888, 1
  %v3890 = add nsw i64 %v3887, %v3889
  %v3891 = inttoptr i64 %v3890 to ptr
  %v3892 = musttail call ptr @mlf.numeric.52(ptr %a0, ptr %v3824, ptr %a2, ptr %v3891)
  ret ptr %v3892
tail.no.3801:
  ret ptr %a3
}

define private ptr @mlf.numeric.52(ptr %a0, ptr %a1, ptr %a2, ptr %a3) alwaysinline {
entry:
  %v3775 = ptrtoint ptr %a1 to i64
  %v3776 = and i64 %v3775, 1
  %v3777 = icmp ne i64 %v3776, 0
  %v3778 = icmp ult i64 %v3775, 4294967296
  %v3779 = and i1 %v3777, %v3778
  %v3780 = ptrtoint ptr %a2 to i64
  %v3781 = and i64 %v3780, 1
  %v3782 = icmp ne i64 %v3781, 0
  %v3783 = icmp ult i64 %v3780, 4294967296
  %v3784 = and i1 %v3782, %v3783
  %v3785 = ptrtoint ptr %a3 to i64
  %v3786 = and i64 %v3785, 1
  %v3787 = icmp ne i64 %v3786, 0
  %v3788 = icmp ult i64 %v3785, 4294967296
  %v3789 = and i1 %v3787, %v3788
  %v3790 = and i1 true, %v3779
  %v3791 = and i1 %v3790, %v3784
  %v3792 = and i1 %v3791, %v3789
  br i1 %v3792, label %range.fast.3793, label %range.general.3794
range.fast.3793:
  %v3893 = musttail call ptr @mlf.numeric.52.piii(ptr %a0, ptr %a1, ptr %a2, ptr %a3)
  ret ptr %v3893
range.general.3794:
  %v3894 = ptrtoint ptr %a1 to i64
  %v3895 = ptrtoint ptr %a2 to i64
  %v3896 = and i64 %v3894, %v3895
  %v3897 = and i64 %v3896, 1
  %v3898 = icmp ne i64 %v3897, 0
  br i1 %v3898, label %yes.3899, label %no.3900
yes.3899:
  %v3902 = icmp slt i64 %v3894, %v3895
  %v3903 = select i1 %v3902, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.3901
no.3900:
  %v3904 = call ptr @mlf_lt_int(ptr %a1, ptr %a2)
  br label %join.3901
join.3901:
  %v3905 = phi ptr [ %v3903, %yes.3899 ], [ %v3904, %no.3900 ]
  %v3906 = icmp eq ptr %v3905, inttoptr (i64 6 to ptr)
  br i1 %v3906, label %tail.yes.3907, label %tail.no.3908
tail.yes.3907:
  %v3909 = getelementptr i8, ptr %a0, i64 8
  %v3910 = load i64, ptr %v3909, align 8, !tbaa !3
  %v3911 = getelementptr i8, ptr %a0, i64 16
  %v3912 = load ptr, ptr %v3911, align 8, !tbaa !3
  %v3913 = ptrtoint ptr %a1 to i64
  %v3914 = ashr i64 %v3913, 1
  %v3915 = and i64 %v3913, 1
  %v3916 = icmp ne i64 %v3915, 0
  %v3917 = icmp ult i64 %v3914, %v3910
  %v3918 = and i1 %v3916, %v3917
  br i1 %v3918, label %array.valid.3919, label %array.invalid.3920
array.invalid.3920:
  call void @mlf_bounds_failure()
  unreachable
array.valid.3919:
  %v3921 = getelementptr i8, ptr %v3912, i64 %v3914
  %v3922 = load i8, ptr %v3921, align 1, !tbaa !4
  %v3923 = zext i8 %v3922 to i64
  %v3924 = shl i64 %v3923, 1
  %v3925 = or i64 %v3924, 1
  %v3926 = inttoptr i64 %v3925 to ptr
  %v3927 = ptrtoint ptr %a1 to i64
  %v3928 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v3929 = sub i64 %v3928, 1
  %v3930 = add nsw i64 %v3927, %v3929
  %v3931 = inttoptr i64 %v3930 to ptr
  %v3932 = ptrtoint ptr %a3 to i64
  %v3933 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v3934 = and i64 %v3932, %v3933
  %v3935 = and i64 %v3934, 1
  %v3936 = icmp ne i64 %v3935, 0
  br i1 %v3936, label %yes.3937, label %no.3938
yes.3937:
  %v3940 = ashr i64 %v3932, 1
  %v3941 = ashr i64 %v3933, 1
  %v3942 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v3940, i64 %v3941)
  %v3943 = extractvalue { i64, i1 } %v3942, 0
  %v3944 = extractvalue { i64, i1 } %v3942, 1
  %v3945 = xor i1 %v3944, true
  %v3946 = icmp sge i64 %v3943, -4611686018427387904
  %v3947 = icmp sle i64 %v3943, 4611686018427387903
  %v3948 = and i1 %v3946, %v3947
  %v3949 = and i1 %v3948, %v3945
  br i1 %v3949, label %yes.3950, label %no.3951
yes.3950:
  %v3953 = shl i64 %v3943, 1
  %v3954 = or i64 %v3953, 1
  %v3955 = inttoptr i64 %v3954 to ptr
  br label %join.3952
no.3951:
  %v3956 = call ptr @mlf_prim2(i64 14, ptr %a3, ptr inttoptr (i64 9 to ptr))
  br label %join.3952
join.3952:
  %v3957 = phi ptr [ %v3955, %yes.3950 ], [ %v3956, %no.3951 ]
  br label %join.3939
no.3938:
  %v3958 = call ptr @mlf_prim2(i64 14, ptr %a3, ptr inttoptr (i64 9 to ptr))
  br label %join.3939
join.3939:
  %v3959 = phi ptr [ %v3957, %join.3952 ], [ %v3958, %no.3938 ]
  %v3960 = ptrtoint ptr %v3926 to i64
  %v3961 = ptrtoint ptr inttoptr (i64 131 to ptr) to i64
  %v3962 = icmp eq i64 %v3960, %v3961
  %v3963 = select i1 %v3962, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v3964 = icmp eq ptr %v3963, inttoptr (i64 6 to ptr)
  br i1 %v3964, label %yes.3965, label %no.3966
yes.3965:
  br label %join.3967
no.3966:
  %v3968 = ptrtoint ptr %v3926 to i64
  %v3969 = ptrtoint ptr inttoptr (i64 195 to ptr) to i64
  %v3970 = icmp eq i64 %v3968, %v3969
  %v3971 = select i1 %v3970, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v3972 = icmp eq ptr %v3971, inttoptr (i64 6 to ptr)
  br i1 %v3972, label %yes.3973, label %no.3974
yes.3973:
  br label %join.3975
no.3974:
  %v3976 = ptrtoint ptr %v3926 to i64
  %v3977 = ptrtoint ptr inttoptr (i64 135 to ptr) to i64
  %v3978 = icmp eq i64 %v3976, %v3977
  %v3979 = select i1 %v3978, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v3980 = icmp eq ptr %v3979, inttoptr (i64 6 to ptr)
  br i1 %v3980, label %yes.3981, label %no.3982
yes.3981:
  br label %join.3983
no.3982:
  %v3984 = ptrtoint ptr %v3926 to i64
  %v3985 = ptrtoint ptr inttoptr (i64 199 to ptr) to i64
  %v3986 = icmp eq i64 %v3984, %v3985
  %v3987 = select i1 %v3986, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v3988 = icmp eq ptr %v3987, inttoptr (i64 6 to ptr)
  br i1 %v3988, label %yes.3989, label %no.3990
yes.3989:
  br label %join.3991
no.3990:
  %v3992 = ptrtoint ptr %v3926 to i64
  %v3993 = ptrtoint ptr inttoptr (i64 143 to ptr) to i64
  %v3994 = icmp eq i64 %v3992, %v3993
  %v3995 = select i1 %v3994, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v3996 = icmp eq ptr %v3995, inttoptr (i64 6 to ptr)
  br i1 %v3996, label %yes.3997, label %no.3998
yes.3997:
  br label %join.3999
no.3998:
  %v4000 = ptrtoint ptr %v3926 to i64
  %v4001 = ptrtoint ptr inttoptr (i64 207 to ptr) to i64
  %v4002 = icmp eq i64 %v4000, %v4001
  %v4003 = select i1 %v4002, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v4004 = icmp eq ptr %v4003, inttoptr (i64 6 to ptr)
  br i1 %v4004, label %yes.4005, label %no.4006
yes.4005:
  br label %join.4007
no.4006:
  br label %join.4007
join.4007:
  %v4008 = phi ptr [ inttoptr (i64 5 to ptr), %yes.4005 ], [ inttoptr (i64 7 to ptr), %no.4006 ]
  br label %join.3999
join.3999:
  %v4009 = phi ptr [ inttoptr (i64 5 to ptr), %yes.3997 ], [ %v4008, %join.4007 ]
  br label %join.3991
join.3991:
  %v4010 = phi ptr [ inttoptr (i64 3 to ptr), %yes.3989 ], [ %v4009, %join.3999 ]
  br label %join.3983
join.3983:
  %v4011 = phi ptr [ inttoptr (i64 3 to ptr), %yes.3981 ], [ %v4010, %join.3991 ]
  br label %join.3975
join.3975:
  %v4012 = phi ptr [ inttoptr (i64 1 to ptr), %yes.3973 ], [ %v4011, %join.3983 ]
  br label %join.3967
join.3967:
  %v4013 = phi ptr [ inttoptr (i64 1 to ptr), %yes.3965 ], [ %v4012, %join.3975 ]
  %v4014 = ptrtoint ptr %v3959 to i64
  %v4015 = ptrtoint ptr %v4013 to i64
  %v4016 = and i64 %v4014, %v4015
  %v4017 = and i64 %v4016, 1
  %v4018 = icmp ne i64 %v4017, 0
  br i1 %v4018, label %yes.4019, label %no.4020
yes.4019:
  %v4022 = sub i64 %v4015, 1
  %v4023 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v4014, i64 %v4022)
  %v4024 = extractvalue { i64, i1 } %v4023, 0
  %v4025 = extractvalue { i64, i1 } %v4023, 1
  br i1 %v4025, label %yes.4026, label %no.4027
yes.4026:
  %v4029 = call ptr @mlf_add_int(ptr %v3959, ptr %v4013)
  br label %join.4028
no.4027:
  %v4030 = inttoptr i64 %v4024 to ptr
  br label %join.4028
join.4028:
  %v4031 = phi ptr [ %v4029, %yes.4026 ], [ %v4030, %no.4027 ]
  br label %join.4021
no.4020:
  %v4032 = call ptr @mlf_add_int(ptr %v3959, ptr %v4013)
  br label %join.4021
join.4021:
  %v4033 = phi ptr [ %v4031, %join.4028 ], [ %v4032, %no.4020 ]
  %v4034 = musttail call ptr @mlf.numeric.52(ptr %a0, ptr %v3931, ptr %a2, ptr %v4033)
  ret ptr %v4034
tail.no.3908:
  ret ptr %a3
}

define private ptr @mlf.code.4042(ptr %env, ptr %arg) {
entry:
  %v4043 = getelementptr i8, ptr %env, i64 8
  %v4044 = load ptr, ptr %v4043, align 8, !tbaa !3
  %v4045 = getelementptr i8, ptr %env, i64 16
  %v4046 = load ptr, ptr %v4045, align 8, !tbaa !3
  %v4047 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4047, align 8, !tbaa !3
  %v4048 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v4048, align 8, !tbaa !3
  %v4049 = call ptr @mlf_prim2(i64 36, ptr %v4044, ptr %v4046)
  ret ptr %v4049
}

define private ptr @mlf.code.4067(ptr %env, ptr %arg) {
entry:
  %v4068 = getelementptr i8, ptr %env, i64 8
  %v4069 = load ptr, ptr %v4068, align 8, !tbaa !3
  %v4070 = getelementptr i8, ptr %env, i64 16
  %v4071 = load ptr, ptr %v4070, align 8, !tbaa !3
  %v4072 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4072, align 8, !tbaa !3
  %v4073 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v4073, align 8, !tbaa !3
  %v4074 = call ptr @mlf.force(ptr %v4069)
  %v4075 = call ptr @mlf_prim2(i64 14, ptr %v4074, ptr inttoptr (i64 9 to ptr))
  %v4076 = call ptr @mlf.force(ptr %v4071)
  %v4077 = call ptr @mlf.worker.15(ptr %v4076)
  %v4078 = call ptr @mlf_prim2(i64 8, ptr %v4075, ptr %v4077)
  ret ptr %v4078
}

define private ptr @mlf.code.4055(ptr %env, ptr %arg) {
entry:
  %v4056 = getelementptr i8, ptr %env, i64 8
  %v4057 = load ptr, ptr %v4056, align 8, !tbaa !3
  %v4058 = getelementptr i8, ptr %env, i64 16
  %v4059 = load ptr, ptr %v4058, align 8, !tbaa !3
  %v4060 = getelementptr i8, ptr %env, i64 24
  %v4061 = load ptr, ptr %v4060, align 8, !tbaa !3
  %v4062 = getelementptr i8, ptr %env, i64 32
  %v4063 = load ptr, ptr %v4062, align 8, !tbaa !3
  %v4064 = call ptr @mlf.force(ptr %v4059)
  %v4065 = call ptr @mlf_prim2(i64 8, ptr %v4064, ptr inttoptr (i64 3 to ptr))
  %v4066 = call ptr @mlf.force(ptr %v4061)
  %v4079 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4067, i64 2)
  %v4080 = getelementptr i8, ptr %v4079, i64 16
  %v4081 = load ptr, ptr %v4080, align 8, !tbaa !3
  %v4082 = getelementptr i8, ptr %v4081, i64 8
  store ptr %v4063, ptr %v4082, align 8, !tbaa !3
  %v4083 = getelementptr i8, ptr %v4081, i64 16
  store ptr %arg, ptr %v4083, align 8, !tbaa !3
  %v4084 = call ptr @mlf_env_new(i64 4)
  %v4085 = getelementptr i8, ptr %v4084, i64 8
  store ptr %v4057, ptr %v4085, align 8, !tbaa !3
  %v4086 = getelementptr i8, ptr %v4084, i64 16
  store ptr %v4065, ptr %v4086, align 8, !tbaa !3
  %v4087 = getelementptr i8, ptr %v4084, i64 24
  store ptr %v4066, ptr %v4087, align 8, !tbaa !3
  %v4088 = getelementptr i8, ptr %v4084, i64 32
  store ptr %v4079, ptr %v4088, align 8, !tbaa !3
  %v4089 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.3751, ptr %v4084)
  ret ptr %v4089
}

define private ptr @mlf.worker.52(ptr %a0, ptr %a1, ptr %a2, ptr %a3) {
entry:
  %v4037 = call ptr @mlf_prim2(i64 11, ptr %a1, ptr %a2)
  %v4038 = icmp eq ptr %v4037, inttoptr (i64 6 to ptr)
  br i1 %v4038, label %yes.4039, label %no.4040
yes.4039:
  %v4050 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4042, i64 2)
  %v4051 = getelementptr i8, ptr %v4050, i64 16
  %v4052 = load ptr, ptr %v4051, align 8, !tbaa !3
  %v4053 = getelementptr i8, ptr %v4052, i64 8
  store ptr %a0, ptr %v4053, align 8, !tbaa !3
  %v4054 = getelementptr i8, ptr %v4052, i64 16
  store ptr %a1, ptr %v4054, align 8, !tbaa !3
  %v4090 = call ptr @mlf_env_new(i64 4)
  %v4091 = getelementptr i8, ptr %v4090, i64 8
  store ptr %a0, ptr %v4091, align 8, !tbaa !3
  %v4092 = getelementptr i8, ptr %v4090, i64 16
  store ptr %a1, ptr %v4092, align 8, !tbaa !3
  %v4093 = getelementptr i8, ptr %v4090, i64 24
  store ptr %a2, ptr %v4093, align 8, !tbaa !3
  %v4094 = getelementptr i8, ptr %v4090, i64 32
  store ptr %a3, ptr %v4094, align 8, !tbaa !3
  %v4095 = call ptr @mlf_closure(ptr @mlf.code.4055, ptr %v4090)
  %v4096 = call ptr @mlf_prim2(i64 1, ptr %v4050, ptr %v4095)
  br label %join.4041
no.4040:
  %v4097 = call ptr @mlf_prim1(i64 0, ptr %a3)
  br label %join.4041
join.4041:
  %v4098 = phi ptr [ %v4096, %yes.4039 ], [ %v4097, %no.4040 ]
  ret ptr %v4098
}

define private ptr @mlf.numeric.entry.3751(ptr %env, ptr %arg) {
entry:
  %v3752 = getelementptr i8, ptr %env, i64 8
  %v3753 = load ptr, ptr %v3752, align 8, !tbaa !3
  %v3754 = getelementptr i8, ptr %env, i64 16
  %v3755 = load ptr, ptr %v3754, align 8, !tbaa !3
  %v3756 = getelementptr i8, ptr %env, i64 24
  %v3757 = load ptr, ptr %v3756, align 8, !tbaa !3
  %v3758 = getelementptr i8, ptr %env, i64 32
  %v3759 = load ptr, ptr %v3758, align 8, !tbaa !3
  %v3760 = call ptr @mlf_peek(ptr %v3753)
  %v3761 = call ptr @mlf_peek(ptr %v3755)
  %v3762 = call ptr @mlf_peek(ptr %v3757)
  %v3763 = call ptr @mlf_peek(ptr %v3759)
  %v3764 = icmp ne ptr %v3760, null
  %v3765 = icmp ne ptr %v3761, null
  %v3766 = icmp ne ptr %v3762, null
  %v3767 = icmp ne ptr %v3763, null
  %v3768 = and i1 true, %v3764
  %v3769 = and i1 %v3768, %v3765
  %v3770 = and i1 %v3769, %v3766
  %v3771 = and i1 %v3770, %v3767
  br i1 %v3771, label %yes.3772, label %no.3773
yes.3772:
  %v4035 = call ptr @mlf.numeric.52(ptr %v3760, ptr %v3761, ptr %v3762, ptr %v3763)
  %v4036 = call ptr @mlf_prim1(i64 0, ptr %v4035)
  br label %join.3774
no.3773:
  %v4099 = call ptr @mlf.force(ptr %v3755)
  %v4100 = call ptr @mlf.force(ptr %v3757)
  %v4101 = call ptr @mlf.worker.52(ptr %v3753, ptr %v4099, ptr %v4100, ptr %v3759)
  br label %join.3774
join.3774:
  %v4102 = phi ptr [ %v4036, %yes.3772 ], [ %v4101, %no.3773 ]
  ret ptr %v4102
}

define private ptr @mlf.code.3744(ptr %env, ptr %arg) {
entry:
  %v3745 = getelementptr i8, ptr %env, i64 8
  %v3746 = load ptr, ptr %v3745, align 8, !tbaa !3
  %v3747 = getelementptr i8, ptr %env, i64 16
  %v3748 = load ptr, ptr %v3747, align 8, !tbaa !3
  %v3749 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3749, align 8, !tbaa !3
  %v3750 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v3750, align 8, !tbaa !3
  %v4103 = call ptr @mlf.force(ptr %v3748)
  %v4104 = call ptr @mlf_env_new(i64 4)
  %v4105 = getelementptr i8, ptr %v4104, i64 8
  store ptr %v3746, ptr %v4105, align 8, !tbaa !3
  %v4106 = getelementptr i8, ptr %v4104, i64 16
  store ptr inttoptr (i64 1 to ptr), ptr %v4106, align 8, !tbaa !3
  %v4107 = getelementptr i8, ptr %v4104, i64 24
  store ptr %v4103, ptr %v4107, align 8, !tbaa !3
  %v4108 = getelementptr i8, ptr %v4104, i64 32
  store ptr inttoptr (i64 1 to ptr), ptr %v4108, align 8, !tbaa !3
  %v4109 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.3751, ptr %v4104)
  ret ptr %v4109
}

define private ptr @mlf.code.4124(ptr %env, ptr %arg) {
entry:
  %v4125 = getelementptr i8, ptr %env, i64 8
  %v4126 = load ptr, ptr %v4125, align 8, !tbaa !3
  %v4127 = getelementptr i8, ptr %env, i64 16
  %v4128 = load ptr, ptr %v4127, align 8, !tbaa !3
  %v4129 = getelementptr i8, ptr %env, i64 24
  %v4130 = load ptr, ptr %v4129, align 8, !tbaa !3
  %v4131 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4131, align 8, !tbaa !3
  %v4132 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v4132, align 8, !tbaa !3
  %v4133 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v4133, align 8, !tbaa !3
  %v4134 = call ptr @mlf_env_new(i64 3)
  %v4135 = getelementptr i8, ptr %v4134, i64 8
  store ptr %v4126, ptr %v4135, align 8, !tbaa !3
  %v4136 = getelementptr i8, ptr %v4134, i64 16
  store ptr %v4128, ptr %v4136, align 8, !tbaa !3
  %v4137 = getelementptr i8, ptr %v4134, i64 24
  store ptr %v4130, ptr %v4137, align 8, !tbaa !3
  %v4138 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2111, ptr %v4134)
  ret ptr %v4138
}

define private ptr @mlf.code.4150(ptr %env, ptr %arg) {
entry:
  %v4151 = getelementptr i8, ptr %env, i64 8
  %v4152 = load ptr, ptr %v4151, align 8, !tbaa !3
  %v4153 = getelementptr i8, ptr %env, i64 16
  %v4154 = load ptr, ptr %v4153, align 8, !tbaa !3
  %v4155 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4155, align 8, !tbaa !3
  %v4156 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v4156, align 8, !tbaa !3
  %v4157 = call ptr @mlf_prim2(i64 43, ptr %v4154, ptr %v4152)
  ret ptr %v4157
}

define private ptr @mlf.code.4166(ptr %env, ptr %arg) {
entry:
  %v4167 = getelementptr i8, ptr %env, i64 8
  %v4168 = load ptr, ptr %v4167, align 8, !tbaa !3
  %v4169 = getelementptr i8, ptr %env, i64 16
  %v4170 = load ptr, ptr %v4169, align 8, !tbaa !3
  %v4171 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4171, align 8, !tbaa !3
  %v4172 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v4172, align 8, !tbaa !3
  %v4173 = call ptr @mlf.force(ptr %v4170)
  %v4174 = call ptr @mlf_prim1(i64 7, ptr %v4173)
  %v4176 = call ptr @mlf.force(ptr %v4168)
  %v4177 = call ptr @mlf_prim2(i64 6, ptr @mlf.bytes.4175.value, ptr %v4176)
  %v4178 = call ptr @mlf_prim2(i64 6, ptr %v4174, ptr %v4177)
  ret ptr %v4178
}

define private ptr @mlf.code.4163(ptr %env, ptr %arg) {
entry:
  %v4164 = getelementptr i8, ptr %env, i64 8
  %v4165 = load ptr, ptr %v4164, align 8, !tbaa !3
  %v4179 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4166, i64 2)
  %v4180 = getelementptr i8, ptr %v4179, i64 16
  %v4181 = load ptr, ptr %v4180, align 8, !tbaa !3
  %v4182 = getelementptr i8, ptr %v4181, i64 8
  store ptr %v4165, ptr %v4182, align 8, !tbaa !3
  %v4183 = getelementptr i8, ptr %v4181, i64 16
  store ptr %arg, ptr %v4183, align 8, !tbaa !3
  %v4184 = call ptr @mlf_prim1(i64 3, ptr %v4179)
  ret ptr %v4184
}

define private ptr @mlf.code.4145(ptr %env, ptr %arg) {
entry:
  %v4146 = getelementptr i8, ptr %env, i64 8
  %v4147 = load ptr, ptr %v4146, align 8, !tbaa !3
  %v4148 = getelementptr i8, ptr %env, i64 16
  %v4149 = load ptr, ptr %v4148, align 8, !tbaa !3
  %v4158 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4150, i64 2)
  %v4159 = getelementptr i8, ptr %v4158, i64 16
  %v4160 = load ptr, ptr %v4159, align 8, !tbaa !3
  %v4161 = getelementptr i8, ptr %v4160, i64 8
  store ptr %v4149, ptr %v4161, align 8, !tbaa !3
  %v4162 = getelementptr i8, ptr %v4160, i64 16
  store ptr %arg, ptr %v4162, align 8, !tbaa !3
  %v4185 = call ptr @mlf_env_new(i64 1)
  %v4186 = getelementptr i8, ptr %v4185, i64 8
  store ptr %v4147, ptr %v4186, align 8, !tbaa !3
  %v4187 = call ptr @mlf_closure(ptr @mlf.code.4163, ptr %v4185)
  %v4188 = call ptr @mlf_prim2(i64 1, ptr %v4158, ptr %v4187)
  ret ptr %v4188
}

define private ptr @mlf.code.4115(ptr %env, ptr %arg) {
entry:
  %v4116 = getelementptr i8, ptr %env, i64 8
  %v4117 = load ptr, ptr %v4116, align 8, !tbaa !3
  %v4118 = getelementptr i8, ptr %env, i64 16
  %v4119 = load ptr, ptr %v4118, align 8, !tbaa !3
  %v4120 = getelementptr i8, ptr %env, i64 24
  %v4121 = load ptr, ptr %v4120, align 8, !tbaa !3
  %v4122 = getelementptr i8, ptr %env, i64 32
  %v4123 = load ptr, ptr %v4122, align 8, !tbaa !3
  %v4139 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4124, i64 3)
  %v4140 = getelementptr i8, ptr %v4139, i64 16
  %v4141 = load ptr, ptr %v4140, align 8, !tbaa !3
  %v4142 = getelementptr i8, ptr %v4141, i64 8
  store ptr %v4117, ptr %v4142, align 8, !tbaa !3
  %v4143 = getelementptr i8, ptr %v4141, i64 16
  store ptr %v4119, ptr %v4143, align 8, !tbaa !3
  %v4144 = getelementptr i8, ptr %v4141, i64 24
  store ptr %v4123, ptr %v4144, align 8, !tbaa !3
  %v4189 = call ptr @mlf_env_new(i64 2)
  %v4190 = getelementptr i8, ptr %v4189, i64 8
  store ptr %v4121, ptr %v4190, align 8, !tbaa !3
  %v4191 = getelementptr i8, ptr %v4189, i64 16
  store ptr %arg, ptr %v4191, align 8, !tbaa !3
  %v4192 = call ptr @mlf_closure(ptr @mlf.code.4145, ptr %v4189)
  %v4193 = call ptr @mlf_prim2(i64 1, ptr %v4139, ptr %v4192)
  ret ptr %v4193
}

define private ptr @mlf.code.3735(ptr %env, ptr %arg) {
entry:
  %v3736 = getelementptr i8, ptr %env, i64 8
  %v3737 = load ptr, ptr %v3736, align 8, !tbaa !3
  %v3738 = getelementptr i8, ptr %env, i64 16
  %v3739 = load ptr, ptr %v3738, align 8, !tbaa !3
  %v3740 = getelementptr i8, ptr %env, i64 24
  %v3741 = load ptr, ptr %v3740, align 8, !tbaa !3
  %v3742 = getelementptr i8, ptr %env, i64 32
  %v3743 = load ptr, ptr %v3742, align 8, !tbaa !3
  %v4110 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3744, i64 2)
  %v4111 = getelementptr i8, ptr %v4110, i64 16
  %v4112 = load ptr, ptr %v4111, align 8, !tbaa !3
  %v4113 = getelementptr i8, ptr %v4112, i64 8
  store ptr %v3743, ptr %v4113, align 8, !tbaa !3
  %v4114 = getelementptr i8, ptr %v4112, i64 16
  store ptr %arg, ptr %v4114, align 8, !tbaa !3
  %v4194 = call ptr @mlf_env_new(i64 4)
  %v4195 = getelementptr i8, ptr %v4194, i64 8
  store ptr %v3737, ptr %v4195, align 8, !tbaa !3
  %v4196 = getelementptr i8, ptr %v4194, i64 16
  store ptr %v3739, ptr %v4196, align 8, !tbaa !3
  %v4197 = getelementptr i8, ptr %v4194, i64 24
  store ptr %v3741, ptr %v4197, align 8, !tbaa !3
  %v4198 = getelementptr i8, ptr %v4194, i64 32
  store ptr %arg, ptr %v4198, align 8, !tbaa !3
  %v4199 = call ptr @mlf_closure(ptr @mlf.code.4115, ptr %v4194)
  %v4200 = call ptr @mlf_prim2(i64 1, ptr %v4110, ptr %v4199)
  ret ptr %v4200
}

define private ptr @mlf.code.3719(ptr %env, ptr %arg) {
entry:
  %v3720 = getelementptr i8, ptr %env, i64 8
  %v3721 = load ptr, ptr %v3720, align 8, !tbaa !3
  %v3722 = getelementptr i8, ptr %env, i64 16
  %v3723 = load ptr, ptr %v3722, align 8, !tbaa !3
  %v3724 = getelementptr i8, ptr %env, i64 24
  %v3725 = load ptr, ptr %v3724, align 8, !tbaa !3
  %v3731 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3726, i64 1)
  %v3732 = getelementptr i8, ptr %v3731, i64 16
  %v3733 = load ptr, ptr %v3732, align 8, !tbaa !3
  %v3734 = getelementptr i8, ptr %v3733, i64 8
  store ptr %arg, ptr %v3734, align 8, !tbaa !3
  %v4201 = call ptr @mlf_env_new(i64 4)
  %v4202 = getelementptr i8, ptr %v4201, i64 8
  store ptr %v3721, ptr %v4202, align 8, !tbaa !3
  %v4203 = getelementptr i8, ptr %v4201, i64 16
  store ptr %v3723, ptr %v4203, align 8, !tbaa !3
  %v4204 = getelementptr i8, ptr %v4201, i64 24
  store ptr %v3725, ptr %v4204, align 8, !tbaa !3
  %v4205 = getelementptr i8, ptr %v4201, i64 32
  store ptr %arg, ptr %v4205, align 8, !tbaa !3
  %v4206 = call ptr @mlf_closure(ptr @mlf.code.3735, ptr %v4201)
  %v4207 = call ptr @mlf_prim2(i64 1, ptr %v3731, ptr %v4206)
  ret ptr %v4207
}

define private ptr @mlf.worker.108(ptr %a0, ptr %a1, ptr %a2) {
entry:
  %v3715 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3710, i64 1)
  %v3716 = getelementptr i8, ptr %v3715, i64 16
  %v3717 = load ptr, ptr %v3716, align 8, !tbaa !3
  %v3718 = getelementptr i8, ptr %v3717, i64 8
  store ptr %a2, ptr %v3718, align 8, !tbaa !3
  %v4208 = call ptr @mlf_env_new(i64 3)
  %v4209 = getelementptr i8, ptr %v4208, i64 8
  store ptr %a0, ptr %v4209, align 8, !tbaa !3
  %v4210 = getelementptr i8, ptr %v4208, i64 16
  store ptr %a1, ptr %v4210, align 8, !tbaa !3
  %v4211 = getelementptr i8, ptr %v4208, i64 24
  store ptr %a2, ptr %v4211, align 8, !tbaa !3
  %v4212 = call ptr @mlf_closure(ptr @mlf.code.3719, ptr %v4208)
  %v4213 = call ptr @mlf_prim2(i64 1, ptr %v3715, ptr %v4212)
  ret ptr %v4213
}

define private ptr @mlf.code.3703(ptr %env, ptr %arg) {
entry:
  %v3704 = getelementptr i8, ptr %env, i64 8
  %v3705 = load ptr, ptr %v3704, align 8, !tbaa !3
  %v3706 = getelementptr i8, ptr %env, i64 16
  %v3707 = load ptr, ptr %v3706, align 8, !tbaa !3
  %v3708 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3708, align 8, !tbaa !3
  %v3709 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v3709, align 8, !tbaa !3
  %v4215 = call ptr @mlf.worker.108(ptr %v3705, ptr %v3707, ptr @mlf.bytes.4214.value)
  ret ptr %v4215
}

define private ptr @mlf.code.4226(ptr %env, ptr %arg) {
entry:
  %v4227 = getelementptr i8, ptr %env, i64 8
  %v4228 = load ptr, ptr %v4227, align 8, !tbaa !3
  %v4229 = getelementptr i8, ptr %env, i64 16
  %v4230 = load ptr, ptr %v4229, align 8, !tbaa !3
  %v4231 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4231, align 8, !tbaa !3
  %v4232 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v4232, align 8, !tbaa !3
  %v4234 = call ptr @mlf.worker.108(ptr %v4228, ptr %v4230, ptr @mlf.bytes.4233.value)
  ret ptr %v4234
}

define private ptr @mlf.code.4245(ptr %env, ptr %arg) {
entry:
  %v4246 = getelementptr i8, ptr %env, i64 8
  %v4247 = load ptr, ptr %v4246, align 8, !tbaa !3
  %v4248 = getelementptr i8, ptr %env, i64 16
  %v4249 = load ptr, ptr %v4248, align 8, !tbaa !3
  %v4250 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4250, align 8, !tbaa !3
  %v4251 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v4251, align 8, !tbaa !3
  %v4253 = call ptr @mlf.worker.108(ptr %v4247, ptr %v4249, ptr @mlf.bytes.4252.value)
  ret ptr %v4253
}

define private ptr @mlf.code.4264(ptr %env, ptr %arg) {
entry:
  %v4265 = getelementptr i8, ptr %env, i64 8
  %v4266 = load ptr, ptr %v4265, align 8, !tbaa !3
  %v4267 = getelementptr i8, ptr %env, i64 16
  %v4268 = load ptr, ptr %v4267, align 8, !tbaa !3
  %v4269 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4269, align 8, !tbaa !3
  %v4270 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v4270, align 8, !tbaa !3
  %v4272 = call ptr @mlf.worker.108(ptr %v4266, ptr %v4268, ptr @mlf.bytes.4271.value)
  ret ptr %v4272
}

define private ptr @mlf.code.4278(ptr %env, ptr %arg) {
entry:
  %v4279 = getelementptr i8, ptr %env, i64 8
  %v4280 = load ptr, ptr %v4279, align 8, !tbaa !3
  %v4281 = getelementptr i8, ptr %env, i64 16
  %v4282 = load ptr, ptr %v4281, align 8, !tbaa !3
  %v4284 = call ptr @mlf.worker.108(ptr %v4280, ptr %v4282, ptr @mlf.bytes.4283.value)
  ret ptr %v4284
}

define private ptr @mlf.code.4259(ptr %env, ptr %arg) {
entry:
  %v4260 = getelementptr i8, ptr %env, i64 8
  %v4261 = load ptr, ptr %v4260, align 8, !tbaa !3
  %v4262 = getelementptr i8, ptr %env, i64 16
  %v4263 = load ptr, ptr %v4262, align 8, !tbaa !3
  %v4273 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4264, i64 2)
  %v4274 = getelementptr i8, ptr %v4273, i64 16
  %v4275 = load ptr, ptr %v4274, align 8, !tbaa !3
  %v4276 = getelementptr i8, ptr %v4275, i64 8
  store ptr %v4261, ptr %v4276, align 8, !tbaa !3
  %v4277 = getelementptr i8, ptr %v4275, i64 16
  store ptr %v4263, ptr %v4277, align 8, !tbaa !3
  %v4285 = call ptr @mlf_env_new(i64 2)
  %v4286 = getelementptr i8, ptr %v4285, i64 8
  store ptr %v4261, ptr %v4286, align 8, !tbaa !3
  %v4287 = getelementptr i8, ptr %v4285, i64 16
  store ptr %v4263, ptr %v4287, align 8, !tbaa !3
  %v4288 = call ptr @mlf_closure(ptr @mlf.code.4278, ptr %v4285)
  %v4289 = call ptr @mlf_prim2(i64 1, ptr %v4273, ptr %v4288)
  ret ptr %v4289
}

define private ptr @mlf.code.4240(ptr %env, ptr %arg) {
entry:
  %v4241 = getelementptr i8, ptr %env, i64 8
  %v4242 = load ptr, ptr %v4241, align 8, !tbaa !3
  %v4243 = getelementptr i8, ptr %env, i64 16
  %v4244 = load ptr, ptr %v4243, align 8, !tbaa !3
  %v4254 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4245, i64 2)
  %v4255 = getelementptr i8, ptr %v4254, i64 16
  %v4256 = load ptr, ptr %v4255, align 8, !tbaa !3
  %v4257 = getelementptr i8, ptr %v4256, i64 8
  store ptr %v4242, ptr %v4257, align 8, !tbaa !3
  %v4258 = getelementptr i8, ptr %v4256, i64 16
  store ptr %v4244, ptr %v4258, align 8, !tbaa !3
  %v4290 = call ptr @mlf_env_new(i64 2)
  %v4291 = getelementptr i8, ptr %v4290, i64 8
  store ptr %v4242, ptr %v4291, align 8, !tbaa !3
  %v4292 = getelementptr i8, ptr %v4290, i64 16
  store ptr %v4244, ptr %v4292, align 8, !tbaa !3
  %v4293 = call ptr @mlf_closure(ptr @mlf.code.4259, ptr %v4290)
  %v4294 = call ptr @mlf_prim2(i64 1, ptr %v4254, ptr %v4293)
  ret ptr %v4294
}

define private ptr @mlf.code.4221(ptr %env, ptr %arg) {
entry:
  %v4222 = getelementptr i8, ptr %env, i64 8
  %v4223 = load ptr, ptr %v4222, align 8, !tbaa !3
  %v4224 = getelementptr i8, ptr %env, i64 16
  %v4225 = load ptr, ptr %v4224, align 8, !tbaa !3
  %v4235 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4226, i64 2)
  %v4236 = getelementptr i8, ptr %v4235, i64 16
  %v4237 = load ptr, ptr %v4236, align 8, !tbaa !3
  %v4238 = getelementptr i8, ptr %v4237, i64 8
  store ptr %v4223, ptr %v4238, align 8, !tbaa !3
  %v4239 = getelementptr i8, ptr %v4237, i64 16
  store ptr %v4225, ptr %v4239, align 8, !tbaa !3
  %v4295 = call ptr @mlf_env_new(i64 2)
  %v4296 = getelementptr i8, ptr %v4295, i64 8
  store ptr %v4223, ptr %v4296, align 8, !tbaa !3
  %v4297 = getelementptr i8, ptr %v4295, i64 16
  store ptr %v4225, ptr %v4297, align 8, !tbaa !3
  %v4298 = call ptr @mlf_closure(ptr @mlf.code.4240, ptr %v4295)
  %v4299 = call ptr @mlf_prim2(i64 1, ptr %v4235, ptr %v4298)
  ret ptr %v4299
}

define private ptr @mlf.code.3698(ptr %env, ptr %arg) {
entry:
  %v3699 = getelementptr i8, ptr %env, i64 8
  %v3700 = load ptr, ptr %v3699, align 8, !tbaa !3
  %v3701 = getelementptr i8, ptr %env, i64 16
  %v3702 = load ptr, ptr %v3701, align 8, !tbaa !3
  %v4216 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3703, i64 2)
  %v4217 = getelementptr i8, ptr %v4216, i64 16
  %v4218 = load ptr, ptr %v4217, align 8, !tbaa !3
  %v4219 = getelementptr i8, ptr %v4218, i64 8
  store ptr %v3700, ptr %v4219, align 8, !tbaa !3
  %v4220 = getelementptr i8, ptr %v4218, i64 16
  store ptr %v3702, ptr %v4220, align 8, !tbaa !3
  %v4300 = call ptr @mlf_env_new(i64 2)
  %v4301 = getelementptr i8, ptr %v4300, i64 8
  store ptr %v3700, ptr %v4301, align 8, !tbaa !3
  %v4302 = getelementptr i8, ptr %v4300, i64 16
  store ptr %v3702, ptr %v4302, align 8, !tbaa !3
  %v4303 = call ptr @mlf_closure(ptr @mlf.code.4221, ptr %v4300)
  %v4304 = call ptr @mlf_prim2(i64 1, ptr %v4216, ptr %v4303)
  ret ptr %v4304
}

define private ptr @mlf.code.3680(ptr %env, ptr %arg) {
entry:
  %v3681 = getelementptr i8, ptr %env, i64 8
  %v3682 = load ptr, ptr %v3681, align 8, !tbaa !3
  %v3683 = getelementptr i8, ptr %env, i64 16
  %v3684 = load ptr, ptr %v3683, align 8, !tbaa !3
  %v3693 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3685, i64 2)
  %v3694 = getelementptr i8, ptr %v3693, i64 16
  %v3695 = load ptr, ptr %v3694, align 8, !tbaa !3
  %v3696 = getelementptr i8, ptr %v3695, i64 8
  store ptr %v3684, ptr %v3696, align 8, !tbaa !3
  %v3697 = getelementptr i8, ptr %v3695, i64 16
  store ptr %arg, ptr %v3697, align 8, !tbaa !3
  %v4305 = call ptr @mlf_env_new(i64 2)
  %v4306 = getelementptr i8, ptr %v4305, i64 8
  store ptr %v3682, ptr %v4306, align 8, !tbaa !3
  %v4307 = getelementptr i8, ptr %v4305, i64 16
  store ptr %v3684, ptr %v4307, align 8, !tbaa !3
  %v4308 = call ptr @mlf_closure(ptr @mlf.code.3698, ptr %v4305)
  %v4309 = call ptr @mlf_prim2(i64 1, ptr %v3693, ptr %v4308)
  ret ptr %v4309
}

define private ptr @mlf.code.3658(ptr %env, ptr %arg) {
entry:
  %v3659 = getelementptr i8, ptr %env, i64 8
  %v3660 = load ptr, ptr %v3659, align 8, !tbaa !3
  %v3661 = getelementptr i8, ptr %env, i64 16
  %v3662 = load ptr, ptr %v3661, align 8, !tbaa !3
  %v3675 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3663, i64 2)
  %v3676 = getelementptr i8, ptr %v3675, i64 16
  %v3677 = load ptr, ptr %v3676, align 8, !tbaa !3
  %v3678 = getelementptr i8, ptr %v3677, i64 8
  store ptr %v3660, ptr %v3678, align 8, !tbaa !3
  %v3679 = getelementptr i8, ptr %v3677, i64 16
  store ptr %v3662, ptr %v3679, align 8, !tbaa !3
  %v4310 = call ptr @mlf_env_new(i64 2)
  %v4311 = getelementptr i8, ptr %v4310, i64 8
  store ptr %v3660, ptr %v4311, align 8, !tbaa !3
  %v4312 = getelementptr i8, ptr %v4310, i64 16
  store ptr %v3662, ptr %v4312, align 8, !tbaa !3
  %v4313 = call ptr @mlf_closure(ptr @mlf.code.3680, ptr %v4310)
  %v4314 = call ptr @mlf_prim2(i64 1, ptr %v3675, ptr %v4313)
  ret ptr %v4314
}

define private ptr @mlf.code.3031(ptr %env, ptr %arg) {
entry:
  %v3032 = getelementptr i8, ptr %env, i64 8
  %v3033 = load ptr, ptr %v3032, align 8, !tbaa !3
  %v3034 = getelementptr i8, ptr %env, i64 16
  %v3035 = load ptr, ptr %v3034, align 8, !tbaa !3
  %v3653 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3036, i64 2)
  %v3654 = getelementptr i8, ptr %v3653, i64 16
  %v3655 = load ptr, ptr %v3654, align 8, !tbaa !3
  %v3656 = getelementptr i8, ptr %v3655, i64 8
  store ptr %v3035, ptr %v3656, align 8, !tbaa !3
  %v3657 = getelementptr i8, ptr %v3655, i64 16
  store ptr %arg, ptr %v3657, align 8, !tbaa !3
  %v4315 = call ptr @mlf_env_new(i64 2)
  %v4316 = getelementptr i8, ptr %v4315, i64 8
  store ptr %v3033, ptr %v4316, align 8, !tbaa !3
  %v4317 = getelementptr i8, ptr %v4315, i64 16
  store ptr %v3035, ptr %v4317, align 8, !tbaa !3
  %v4318 = call ptr @mlf_closure(ptr @mlf.code.3658, ptr %v4315)
  %v4319 = call ptr @mlf_prim2(i64 1, ptr %v3653, ptr %v4318)
  ret ptr %v4319
}

define private ptr @mlf.code.2085(ptr %env, ptr %arg) {
entry:
  %v2086 = call ptr @mlf.force(ptr %arg)
  %v2087 = ptrtoint ptr %v2086 to i64
  %v2088 = and i64 %v2087, 7
  %v2089 = icmp eq i64 %v2088, 4
  br i1 %v2089, label %yes.2090, label %no.2091
yes.2090:
  %v2093 = lshr i64 %v2087, 3
  br label %join.2092
no.2091:
  %v2094 = getelementptr i8, ptr %v2086, i64 8
  %v2095 = load i64, ptr %v2094, align 8, !tbaa !3
  br label %join.2092
join.2092:
  %v2096 = phi i64 [ %v2093, %yes.2090 ], [ %v2095, %no.2091 ]
  switch i64 %v2096, label %case.missing.2098 [
    i64 1, label %case.2097
  ]
case.2097:
  %v2100 = getelementptr i8, ptr %v2086, i64 24
  %v2101 = load ptr, ptr %v2100, align 8, !tbaa !3
  %v2102 = getelementptr i8, ptr %v2086, i64 32
  %v2103 = load ptr, ptr %v2102, align 8, !tbaa !3
  %v3026 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2104, i64 2)
  %v3027 = getelementptr i8, ptr %v3026, i64 16
  %v3028 = load ptr, ptr %v3027, align 8, !tbaa !3
  %v3029 = getelementptr i8, ptr %v3028, i64 8
  store ptr %v2101, ptr %v3029, align 8, !tbaa !3
  %v3030 = getelementptr i8, ptr %v3028, i64 16
  store ptr %v2103, ptr %v3030, align 8, !tbaa !3
  %v4320 = call ptr @mlf_env_new(i64 2)
  %v4321 = getelementptr i8, ptr %v4320, i64 8
  store ptr %v2101, ptr %v4321, align 8, !tbaa !3
  %v4322 = getelementptr i8, ptr %v4320, i64 16
  store ptr %v2103, ptr %v4322, align 8, !tbaa !3
  %v4323 = call ptr @mlf_closure(ptr @mlf.code.3031, ptr %v4320)
  %v4324 = call ptr @mlf_prim2(i64 1, ptr %v3026, ptr %v4323)
  br label %case.join.2099
case.missing.2098:
  call void @mlf_match_failure()
  unreachable
case.join.2099:
  %v4325 = phi ptr [ %v4324, %case.2097 ]
  ret ptr %v4325
}

define private ptr @mlf.code.581(ptr %env, ptr %arg) {
entry:
  %v2081 = call ptr @mlf.allocate.thunk(ptr @mlf.code.582, i64 1)
  %v2082 = getelementptr i8, ptr %v2081, i64 16
  %v2083 = load ptr, ptr %v2082, align 8, !tbaa !3
  %v2084 = getelementptr i8, ptr %v2083, i64 8
  store ptr %arg, ptr %v2084, align 8, !tbaa !3
  %v4326 = call ptr @mlf_closure(ptr @mlf.code.2085, ptr null)
  %v4327 = call ptr @mlf_prim2(i64 1, ptr %v2081, ptr %v4326)
  ret ptr %v4327
}

define private ptr @mlf.code.577(ptr %env, ptr %arg) {
entry:
  %v580 = call ptr @mlf_thunk(ptr @mlf.code.578, ptr null)
  %v4328 = call ptr @mlf_closure(ptr @mlf.code.581, ptr null)
  %v4329 = call ptr @mlf_prim2(i64 1, ptr %v580, ptr %v4328)
  ret ptr %v4329
}

define private ptr @mlf.code.0(ptr %env, ptr %arg) {
entry:
  %v576 = call ptr @mlf_thunk(ptr @mlf.code.1, ptr null)
  %v4330 = call ptr @mlf_closure(ptr @mlf.code.577, ptr null)
  %v4331 = call ptr @mlf_prim2(i64 1, ptr %v576, ptr %v4330)
  ret ptr %v4331
}

declare void @mlf_require_compact_gc_abi()
define ptr @mlf_entry() {
  call void @mlf_require_compact_gc_abi()
  %root = call ptr @mlf.code.0(ptr null, ptr null)
  ret ptr %root
}
define i32 @main(i32 %argc, ptr %argv) {
  call void @mlf_set_args(i32 %argc, ptr %argv)
  %root = call ptr @mlf_entry()
  %status = call i32 @mlf_run(ptr %root, i64 1)
  ret i32 %status
}
