; Generated from independently checked xMLF.
source_filename = "emlf"

declare ptr @mlf_thunk_new(ptr, i64)
declare ptr @mlf_execute_st_lazy(ptr)
declare ptr @mlf_st_new_array(ptr, ptr)
declare ptr @mlf_st_read_array(ptr, ptr)
declare ptr @mlf_st_write_array(ptr, ptr, ptr)
declare ptr @mlf_st_length_array(ptr)
declare void @mlf_set_args(i32, ptr)
declare ptr @mlf_env_new(i64)
declare void @mlf_env_set(ptr, i64, ptr)
declare ptr @mlf_env_get(ptr, i64)
declare ptr @mlf_thunk(ptr, ptr)
declare ptr @mlf_closure(ptr, ptr)
declare ptr @mlf_application(ptr, ptr)
declare ptr @mlf_hole()
declare void @mlf_fill(ptr, ptr)
declare ptr @mlf_integer(ptr)
declare ptr @mlf_string(ptr, i64)
declare ptr @mlf_double(double)
declare double @llvm.sqrt.f64(double)
declare double @mlf_int_to_double(ptr)
declare ptr @mlf_read_int_table(ptr, ptr)
declare ptr @mlf_write_int_table(ptr, ptr, ptr)
declare ptr @mlf_add_int_table(ptr, ptr, ptr)
declare void @mlf_roots_enter(ptr, i64, ptr)
declare void @mlf_roots_leave(ptr)
declare void @mlf_gc_check(i64, ptr)
declare ptr @mlf_get_byte_line()
declare ptr @mlf_new_array(i64, ptr, ptr)
declare ptr @mlf_bytes_from_string(ptr)
declare ptr @mlf_put_bytes(ptr, ptr, ptr)
declare ptr @mlf_new_int_table()
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare i8 @mlf_byte(ptr)
declare ptr @mlf_peek(ptr)
declare ptr @mlf_native_io(ptr, ptr)
declare void @mlf_bounds_failure() noreturn
declare ptr @mlf_primitive(i64)
declare ptr @mlf_prim1(i64, ptr)
declare ptr @mlf_prim2(i64, ptr, ptr)
declare i64 @mlf_truth(ptr)
declare ptr @mlf_prim3(i64, ptr, ptr, ptr)
declare ptr @mlf_force(ptr)
declare ptr @mlf_add_int(ptr, ptr)
declare ptr @mlf_sub_int(ptr, ptr)
declare ptr @mlf_eq_int(ptr, ptr)
declare ptr @mlf_lt_int(ptr, ptr)
declare ptr @mlf_constructor(i64, i64)
declare ptr @mlf_constructor1(i64, ptr)
declare ptr @mlf_constructor2(i64, ptr, ptr)
declare ptr @mlf_constructor_fields(i64, ptr)
declare ptr @mlf_constructor_new(i64, i64)
declare ptr @mlf_field(ptr, i64)
declare void @mlf_match_failure() noreturn
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare i32 @mlf_run(ptr, i64)

@mlf_constructor_pending = external global [33 x ptr]
declare ptr @mlf_constructor_allocate(i64, i64)
define private ptr @mlf.allocate.constructor(i64 %identity, i64 %count, i64 %size) alwaysinline {
entry:
  %small = icmp ule i64 %size, 256
  br i1 %small, label %batch, label %slow
batch:
  %index = lshr i64 %size, 3
  %slot = getelementptr [33 x ptr], ptr @mlf_constructor_pending, i64 0, i64 %index
  %value = load ptr, ptr %slot, align 8
  %empty = icmp eq ptr %value, null
  br i1 %empty, label %slow, label %ready
ready:
  %next = load ptr, ptr %value, align 8
  store ptr %next, ptr %slot, align 8
  store i64 0, ptr %value, align 8
  ret ptr %value
slow:
  %allocated = call ptr @mlf_constructor_allocate(i64 %identity, i64 %count)
  ret ptr %allocated
}
define private ptr @mlf.construct.1(i64 %identity, ptr %a) alwaysinline {
entry:
  %value = call ptr @mlf.allocate.constructor(i64 %identity, i64 1, i64 24)
  store i32 12, ptr %value, align 4
  %id = getelementptr i8, ptr %value, i64 8
  store i64 %identity, ptr %id, align 8
  %first = getelementptr i8, ptr %value, i64 16
  store ptr %a, ptr %first, align 8
  ret ptr %value
}
define private ptr @mlf.construct.2(i64 %identity, ptr %a, ptr %b) alwaysinline {
entry:
  %value = call ptr @mlf.allocate.constructor(i64 %identity, i64 2, i64 32)
  store i32 13, ptr %value, align 4
  %id = getelementptr i8, ptr %value, i64 8
  store i64 %identity, ptr %id, align 8
  %first = getelementptr i8, ptr %value, i64 16
  store ptr %a, ptr %first, align 8
  %second = getelementptr i8, ptr %value, i64 24
  store ptr %b, ptr %second, align 8
  ret ptr %value
}
define private ptr @mlf.construct.wide(i64 %identity, i64 %count) alwaysinline {
entry:
  %fields = mul i64 %count, 8
  %size = add i64 %fields, 24
  %value = call ptr @mlf.allocate.constructor(i64 %identity, i64 %count, i64 %size)
  store i32 28, ptr %value, align 4
  %id = getelementptr i8, ptr %value, i64 8
  store i64 %identity, ptr %id, align 8
  %arity = getelementptr i8, ptr %value, i64 16
  store i64 %count, ptr %arity, align 8
  ret ptr %value
}
@mlf_compact_pending = external global [17 x ptr]
define private ptr @mlf.allocate.thunk(ptr %code, i64 %count) alwaysinline {
entry:
  %words = add i64 %count, 4
  %index = lshr i64 %words, 1
  %slot = getelementptr [17 x ptr], ptr @mlf_compact_pending, i64 0, i64 %index
  %value = load ptr, ptr %slot, align 8
  %empty = icmp eq ptr %value, null
  br i1 %empty, label %slow, label %ready
ready:
  %next = load ptr, ptr %value, align 8
  store ptr %next, ptr %slot, align 8
  store i64 3, ptr %value, align 8
  %function = getelementptr i8, ptr %value, i64 8
  store ptr %code, ptr %function, align 8
  %environment = getelementptr i8, ptr %value, i64 24
  %capture = getelementptr i8, ptr %value, i64 16
  store ptr %environment, ptr %capture, align 8
  store i64 %count, ptr %environment, align 8
  ret ptr %value
slow:
  %allocated = call ptr @mlf_thunk_new(ptr %code, i64 %count)
  ret ptr %allocated
}
define private ptr @mlf.force(ptr %value) alwaysinline {
entry:
  %null = icmp eq ptr %value, null
  br i1 %null, label %slow, label %test
test:
  %bits = ptrtoint ptr %value to i64
  %kind = and i64 %bits, 7
  %immediate = icmp ne i64 %kind, 0
  br i1 %immediate, label %done, label %tagged
tagged:
  %tag = load i32, ptr %value, align 4
  %ready = icmp uge i32 %tag, 5
  br i1 %ready, label %done, label %deferred
deferred:
  %isthunk = icmp eq i32 %tag, 3
  br i1 %isthunk, label %enter, label %indirect
indirect:
  %forwarded = icmp eq i32 %tag, 2
  br i1 %forwarded, label %next, label %slow
next:
  %slot = getelementptr i8, ptr %value, i64 8
  %p = load ptr, ptr %slot, align 8
  %missing = icmp eq ptr %p, null
  br i1 %missing, label %slow, label %nexttest
nexttest:
  %pbits = ptrtoint ptr %p to i64
  %pkind = and i64 %pbits, 7
  %pimm = icmp ne i64 %pkind, 0
  br i1 %pimm, label %forward, label %ptagged
ptagged:
  %ptag = load i32, ptr %p, align 4
  %pready = icmp uge i32 %ptag, 5
  br i1 %pready, label %forward, label %slow
forward:
  ret ptr %p
done:
  ret ptr %value
enter:
  %code.slot = getelementptr i8, ptr %value, i64 8
  %env.slot = getelementptr i8, ptr %value, i64 16
  %code = load ptr, ptr %code.slot, align 8
  %env = load ptr, ptr %env.slot, align 8
  store i32 1, ptr %value, align 4
  store ptr null, ptr %code.slot, align 8
  store ptr null, ptr %env.slot, align 8
  %returned = call ptr %code(ptr %env, ptr null)
  %canonical = call ptr @mlf_force(ptr %returned)
  store i32 2, ptr %value, align 4
  store ptr %canonical, ptr %code.slot, align 8
  ret ptr %canonical
slow:
  %result = tail call ptr @mlf_force(ptr %value)
  ret ptr %result
}
!0 = !{!"MLF storage"}
!1 = !{!"managed object", !0}
!2 = !{!"array cells", !0}
!3 = !{!1, !1, i64 0}
!4 = !{!2, !2, i64 0}
@mlf.bytes.89 = private unnamed_addr constant [4 x i8] c"\50\34\0a\00", align 1
@mlf.bytes.89.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 3, ptr @mlf.bytes.89, ptr null }, align 8
@mlf.bytes.92 = private unnamed_addr constant [2 x i8] c"\20\00", align 1
@mlf.bytes.92.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 1, ptr @mlf.bytes.92, ptr null }, align 8
define private ptr @mlf.code.3(ptr %env, ptr %arg) {
entry:
  %v4 = getelementptr i8, ptr %env, i64 8
  %v5 = load ptr, ptr %v4, align 8, !tbaa !3
  %v6 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v6, align 8, !tbaa !3
  %v7 = call ptr @mlf.force(ptr %v5)
  %v8 = call ptr @mlf_prim1(i64 17, ptr %v7)
  ret ptr %v8
}

define private ptr @mlf.code.17(ptr %env, ptr %arg) {
entry:
  %v18 = getelementptr i8, ptr %env, i64 8
  %v19 = load ptr, ptr %v18, align 8, !tbaa !3
  %v20 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v20, align 8, !tbaa !3
  %v21 = call ptr @mlf.force(ptr %v19)
  %v22 = ptrtoint ptr %v21 to i64
  %v23 = ptrtoint ptr inttoptr (i64 15 to ptr) to i64
  %v24 = and i64 %v22, %v23
  %v25 = and i64 %v24, 1
  %v26 = icmp ne i64 %v25, 0
  br i1 %v26, label %yes.27, label %no.28
yes.27:
  %v30 = sub i64 %v23, 1
  %v31 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v22, i64 %v30)
  %v32 = extractvalue { i64, i1 } %v31, 0
  %v33 = extractvalue { i64, i1 } %v31, 1
  br i1 %v33, label %yes.34, label %no.35
yes.34:
  %v37 = call ptr @mlf_add_int(ptr %v21, ptr inttoptr (i64 15 to ptr))
  br label %join.36
no.35:
  %v38 = inttoptr i64 %v32 to ptr
  br label %join.36
join.36:
  %v39 = phi ptr [ %v37, %yes.34 ], [ %v38, %no.35 ]
  br label %join.29
no.28:
  %v40 = call ptr @mlf_add_int(ptr %v21, ptr inttoptr (i64 15 to ptr))
  br label %join.29
join.29:
  %v41 = phi ptr [ %v39, %join.36 ], [ %v40, %no.28 ]
  %v42 = ptrtoint ptr %v41 to i64
  %v43 = ptrtoint ptr inttoptr (i64 17 to ptr) to i64
  %v44 = and i64 %v42, %v43
  %v45 = and i64 %v44, 1
  %v46 = icmp ne i64 %v45, 0
  br i1 %v46, label %yes.47, label %no.48
yes.47:
  %v50 = ashr i64 %v42, 1
  %v51 = ashr i64 %v43, 1
  %v52 = icmp ne i64 %v51, 0
  %v53 = icmp eq i64 %v50, -4611686018427387904
  %v54 = icmp eq i64 %v51, -1
  %v55 = and i1 %v53, %v54
  %v56 = xor i1 %v55, true
  %v57 = and i1 %v52, %v56
  br i1 %v57, label %yes.58, label %no.59
yes.58:
  %v61 = sdiv i64 %v50, %v51
  %v62 = shl i64 %v61, 1
  %v63 = or i64 %v62, 1
  %v64 = inttoptr i64 %v63 to ptr
  br label %join.60
no.59:
  %v65 = call ptr @mlf_prim2(i64 15, ptr %v41, ptr inttoptr (i64 17 to ptr))
  br label %join.60
join.60:
  %v66 = phi ptr [ %v64, %yes.58 ], [ %v65, %no.59 ]
  br label %join.49
no.48:
  %v67 = call ptr @mlf_prim2(i64 15, ptr %v41, ptr inttoptr (i64 17 to ptr))
  br label %join.49
join.49:
  %v68 = phi ptr [ %v66, %join.60 ], [ %v67, %no.48 ]
  ret ptr %v68
}

define private ptr @mlf.code.13(ptr %env, ptr %arg) {
entry:
  %v14 = getelementptr i8, ptr %env, i64 8
  %v15 = load ptr, ptr %v14, align 8, !tbaa !3
  %v16 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v16, align 8, !tbaa !3
  %v69 = call ptr @mlf.allocate.thunk(ptr @mlf.code.17, i64 1)
  %v70 = getelementptr i8, ptr %v69, i64 16
  %v71 = load ptr, ptr %v70, align 8, !tbaa !3
  %v72 = getelementptr i8, ptr %v71, i64 8
  store ptr %v15, ptr %v72, align 8, !tbaa !3
  %v73 = call ptr @mlf_prim2(i64 35, ptr %v69, ptr inttoptr (i64 1 to ptr))
  ret ptr %v73
}

define private ptr @mlf.code.85(ptr %env, ptr %arg) {
entry:
  %v86 = getelementptr i8, ptr %env, i64 8
  %v87 = load ptr, ptr %v86, align 8, !tbaa !3
  %v88 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v88, align 8, !tbaa !3
  %v90 = call ptr @mlf.force(ptr %v87)
  %v91 = call ptr @mlf_prim1(i64 7, ptr %v90)
  %v93 = call ptr @mlf_prim1(i64 7, ptr %v90)
  %v94 = call ptr @mlf_prim2(i64 6, ptr @mlf.bytes.92.value, ptr %v93)
  %v95 = call ptr @mlf_prim2(i64 6, ptr %v91, ptr %v94)
  %v96 = call ptr @mlf_prim2(i64 6, ptr @mlf.bytes.89.value, ptr %v95)
  ret ptr %v96
}

define private ptr @mlf.code.81(ptr %env, ptr %arg) {
entry:
  %v82 = getelementptr i8, ptr %env, i64 8
  %v83 = load ptr, ptr %v82, align 8, !tbaa !3
  %v84 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v84, align 8, !tbaa !3
  %v97 = call ptr @mlf.allocate.thunk(ptr @mlf.code.85, i64 1)
  %v98 = getelementptr i8, ptr %v97, i64 16
  %v99 = load ptr, ptr %v98, align 8, !tbaa !3
  %v100 = getelementptr i8, ptr %v99, i64 8
  store ptr %v83, ptr %v100, align 8, !tbaa !3
  %v101 = call ptr @mlf_prim1(i64 3, ptr %v97)
  ret ptr %v101
}

define private ptr @mlf.numeric.10.dddddddddddppn(double %a0, double %a1, double %a2, double %a3, double %a4, double %a5, double %a6, double %a7, double %a8, double %a9, double %a10, ptr %a11, ptr %a12, ptr %a13) alwaysinline {
entry:
  %v389 = fadd double %a2, %a3
  %v390 = fcmp olt double 0x4010000000000000, %v389
  %v391 = select i1 %v390, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v392 = icmp eq ptr %v391, inttoptr (i64 6 to ptr)
  br i1 %v392, label %yes.393, label %no.394
yes.393:
  br label %join.395
no.394:
  br label %join.395
join.395:
  %v396 = phi ptr [ inttoptr (i64 2 to ptr), %yes.393 ], [ %a11, %no.394 ]
  %v397 = fadd double %a7, %a8
  %v398 = fcmp olt double 0x4010000000000000, %v397
  %v399 = select i1 %v398, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v400 = icmp eq ptr %v399, inttoptr (i64 6 to ptr)
  br i1 %v400, label %yes.401, label %no.402
yes.401:
  br label %join.403
no.402:
  br label %join.403
join.403:
  %v404 = phi ptr [ inttoptr (i64 2 to ptr), %yes.401 ], [ %a12, %no.402 ]
  %v405 = icmp eq ptr %v396, inttoptr (i64 6 to ptr)
  br i1 %v405, label %yes.406, label %no.407
yes.406:
  br label %join.408
no.407:
  br label %join.408
join.408:
  %v409 = phi ptr [ inttoptr (i64 6 to ptr), %yes.406 ], [ %v404, %no.407 ]
  %v410 = icmp eq ptr %v409, inttoptr (i64 6 to ptr)
  br i1 %v410, label %tail.yes.411, label %tail.no.412
tail.yes.411:
  %v413 = ptrtoint ptr %a13 to i64
  %v414 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v415 = icmp eq i64 %v413, %v414
  %v416 = select i1 %v415, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v417 = icmp eq ptr %v416, inttoptr (i64 6 to ptr)
  br i1 %v417, label %tail.yes.418, label %tail.no.419
tail.yes.418:
  %v420 = icmp eq ptr %v396, inttoptr (i64 6 to ptr)
  br i1 %v420, label %yes.421, label %no.422
yes.421:
  br label %join.423
no.422:
  br label %join.423
join.423:
  %v424 = phi ptr [ inttoptr (i64 5 to ptr), %yes.421 ], [ inttoptr (i64 1 to ptr), %no.422 ]
  %v425 = icmp eq ptr %v404, inttoptr (i64 6 to ptr)
  br i1 %v425, label %yes.426, label %no.427
yes.426:
  br label %join.428
no.427:
  br label %join.428
join.428:
  %v429 = phi ptr [ inttoptr (i64 3 to ptr), %yes.426 ], [ inttoptr (i64 1 to ptr), %no.427 ]
  %v430 = ptrtoint ptr %v424 to i64
  %v431 = ptrtoint ptr %v429 to i64
  %v432 = sub i64 %v431, 1
  %v433 = add nsw i64 %v430, %v432
  %v434 = inttoptr i64 %v433 to ptr
  ret ptr %v434
tail.no.419:
  %v435 = fmul double 0x4000000000000000, %a0
  %v436 = fmul double %v435, %a1
  %v437 = fadd double %v436, %a10
  %v438 = fsub double %a2, %a3
  %v439 = fadd double %v438, %a4
  %v440 = fmul double 0x4000000000000000, %a5
  %v441 = fmul double %v440, %a6
  %v442 = fadd double %v441, %a10
  %v443 = fsub double %a7, %a8
  %v444 = fadd double %v443, %a9
  %v445 = fmul double %v439, %v439
  %v446 = fmul double %v437, %v437
  %v447 = fmul double %v444, %v444
  %v448 = fmul double %v442, %v442
  %v449 = ptrtoint ptr %a13 to i64
  %v450 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v451 = sub i64 %v450, 1
  %v452 = sub nsw i64 %v449, %v451
  %v453 = inttoptr i64 %v452 to ptr
  %v454 = musttail call ptr @mlf.numeric.10.dddddddddddppn(double %v439, double %v437, double %v445, double %v446, double %a4, double %v444, double %v442, double %v447, double %v448, double %a9, double %a10, ptr %v396, ptr %v404, ptr %v453)
  ret ptr %v454
tail.no.412:
  ret ptr inttoptr (i64 1 to ptr)
}

define private ptr @mlf.numeric.0.ddddddn(double %a0, double %a1, double %a2, double %a3, double %a4, double %a5, ptr %a6) alwaysinline {
entry:
  %v526 = fadd double %a2, %a3
  %v527 = fcmp olt double 0x4010000000000000, %v526
  %v528 = select i1 %v527, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v529 = icmp eq ptr %v528, inttoptr (i64 6 to ptr)
  br i1 %v529, label %tail.yes.530, label %tail.no.531
tail.yes.530:
  ret ptr inttoptr (i64 1 to ptr)
tail.no.531:
  %v532 = ptrtoint ptr %a6 to i64
  %v533 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v534 = icmp eq i64 %v532, %v533
  %v535 = select i1 %v534, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v536 = icmp eq ptr %v535, inttoptr (i64 6 to ptr)
  br i1 %v536, label %tail.yes.537, label %tail.no.538
tail.yes.537:
  ret ptr inttoptr (i64 3 to ptr)
tail.no.538:
  %v539 = fmul double 0x4000000000000000, %a0
  %v540 = fmul double %v539, %a1
  %v541 = fadd double %v540, %a5
  %v542 = fsub double %a2, %a3
  %v543 = fadd double %v542, %a4
  %v544 = fmul double %v543, %v543
  %v545 = fmul double %v541, %v541
  %v546 = ptrtoint ptr %a6 to i64
  %v547 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v548 = sub i64 %v547, 1
  %v549 = sub nsw i64 %v546, %v548
  %v550 = inttoptr i64 %v549 to ptr
  %v551 = musttail call ptr @mlf.numeric.0.ddddddn(double %v543, double %v541, double %v544, double %v545, double %a4, double %a5, ptr %v550)
  ret ptr %v551
}

define private ptr @mlf.numeric.31.pii(ptr %a0, ptr %a1, ptr %a2) alwaysinline {
entry:
  %v755 = ptrtoint ptr %a2 to i64
  %v756 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v757 = icmp eq i64 %v755, %v756
  %v758 = select i1 %v757, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v759 = icmp eq ptr %v758, inttoptr (i64 6 to ptr)
  br i1 %v759, label %tail.yes.760, label %tail.no.761
tail.yes.760:
  ret ptr inttoptr (i64 4 to ptr)
tail.no.761:
  %v762 = getelementptr i8, ptr %a0, i64 8
  %v763 = load i64, ptr %v762, align 8, !tbaa !3
  %v764 = getelementptr i8, ptr %a0, i64 16
  %v765 = load ptr, ptr %v764, align 8, !tbaa !3
  %v766 = ptrtoint ptr %a1 to i64
  %v767 = ashr i64 %v766, 1
  %v768 = and i64 %v766, 1
  %v769 = icmp ne i64 %v768, 0
  %v770 = icmp ult i64 %v767, %v763
  %v771 = and i1 %v769, %v770
  br i1 %v771, label %array.valid.772, label %array.invalid.773
array.invalid.773:
  call void @mlf_bounds_failure()
  unreachable
array.valid.772:
  %v774 = getelementptr i8, ptr %v765, i64 %v767
  %v775 = load i8, ptr %v774, align 1, !tbaa !4
  %v776 = zext i8 %v775 to i64
  %v777 = shl i64 %v776, 1
  %v778 = or i64 %v777, 1
  %v779 = inttoptr i64 %v778 to ptr
  %v780 = ptrtoint ptr %v779 to i64
  %v781 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v782 = ashr i64 %v780, 1
  %v783 = ashr i64 %v781, 1
  %v784 = mul nsw i64 %v782, %v783
  %v785 = shl i64 %v784, 1
  %v786 = or i64 %v785, 1
  %v787 = inttoptr i64 %v786 to ptr
  %v788 = ptrtoint ptr %a1 to i64
  %v789 = ashr i64 %v788, 1
  %v790 = and i64 %v788, 1
  %v791 = icmp ne i64 %v790, 0
  %v792 = icmp ult i64 %v789, %v763
  %v793 = and i1 %v791, %v792
  br i1 %v793, label %array.valid.794, label %array.invalid.795
array.invalid.795:
  call void @mlf_bounds_failure()
  unreachable
array.valid.794:
  %v796 = getelementptr i8, ptr %v765, i64 %v789
  %v797 = ptrtoint ptr %v787 to i64
  %v798 = ashr i64 %v797, 1
  %v799 = and i64 %v797, 1
  %v800 = icmp ne i64 %v799, 0
  %v801 = icmp ult i64 %v798, 256
  %v802 = and i1 %v800, %v801
  br i1 %v802, label %yes.803, label %no.804
yes.803:
  %v806 = trunc i64 %v798 to i8
  br label %join.805
no.804:
  %v807 = call i8 @mlf_byte(ptr %v787)
  br label %join.805
join.805:
  %v808 = phi i8 [ %v806, %yes.803 ], [ %v807, %no.804 ]
  store i8 %v808, ptr %v796, align 1, !tbaa !4
  %v809 = ptrtoint ptr %a2 to i64
  %v810 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v811 = sub i64 %v810, 1
  %v812 = sub nsw i64 %v809, %v811
  %v813 = inttoptr i64 %v812 to ptr
  %v814 = musttail call ptr @mlf.numeric.31.pii(ptr %a0, ptr %a1, ptr %v813)
  ret ptr %v814
}

define private ptr @mlf.numeric.31(ptr %a0, ptr %a1, ptr %a2) alwaysinline {
entry:
  %v741 = ptrtoint ptr %a1 to i64
  %v742 = and i64 %v741, 1
  %v743 = icmp ne i64 %v742, 0
  %v744 = icmp ult i64 %v741, 4294967296
  %v745 = and i1 %v743, %v744
  %v746 = ptrtoint ptr %a2 to i64
  %v747 = and i64 %v746, 1
  %v748 = icmp ne i64 %v747, 0
  %v749 = icmp ult i64 %v746, 4294967296
  %v750 = and i1 %v748, %v749
  %v751 = and i1 true, %v745
  %v752 = and i1 %v751, %v750
  br i1 %v752, label %range.fast.753, label %range.general.754
range.fast.753:
  %v815 = musttail call ptr @mlf.numeric.31.pii(ptr %a0, ptr %a1, ptr %a2)
  ret ptr %v815
range.general.754:
  %v816 = ptrtoint ptr %a2 to i64
  %v817 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v818 = and i64 %v816, %v817
  %v819 = and i64 %v818, 1
  %v820 = icmp ne i64 %v819, 0
  br i1 %v820, label %yes.821, label %no.822
yes.821:
  %v824 = icmp eq i64 %v816, %v817
  %v825 = select i1 %v824, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.823
no.822:
  %v826 = call ptr @mlf_eq_int(ptr %a2, ptr inttoptr (i64 1 to ptr))
  br label %join.823
join.823:
  %v827 = phi ptr [ %v825, %yes.821 ], [ %v826, %no.822 ]
  %v828 = icmp eq ptr %v827, inttoptr (i64 6 to ptr)
  br i1 %v828, label %tail.yes.829, label %tail.no.830
tail.yes.829:
  ret ptr inttoptr (i64 4 to ptr)
tail.no.830:
  %v831 = getelementptr i8, ptr %a0, i64 8
  %v832 = load i64, ptr %v831, align 8, !tbaa !3
  %v833 = getelementptr i8, ptr %a0, i64 16
  %v834 = load ptr, ptr %v833, align 8, !tbaa !3
  %v835 = ptrtoint ptr %a1 to i64
  %v836 = ashr i64 %v835, 1
  %v837 = and i64 %v835, 1
  %v838 = icmp ne i64 %v837, 0
  %v839 = icmp ult i64 %v836, %v832
  %v840 = and i1 %v838, %v839
  br i1 %v840, label %array.valid.841, label %array.invalid.842
array.invalid.842:
  call void @mlf_bounds_failure()
  unreachable
array.valid.841:
  %v843 = getelementptr i8, ptr %v834, i64 %v836
  %v844 = load i8, ptr %v843, align 1, !tbaa !4
  %v845 = zext i8 %v844 to i64
  %v846 = shl i64 %v845, 1
  %v847 = or i64 %v846, 1
  %v848 = inttoptr i64 %v847 to ptr
  %v849 = ptrtoint ptr %v848 to i64
  %v850 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v851 = ashr i64 %v849, 1
  %v852 = ashr i64 %v850, 1
  %v853 = mul nsw i64 %v851, %v852
  %v854 = shl i64 %v853, 1
  %v855 = or i64 %v854, 1
  %v856 = inttoptr i64 %v855 to ptr
  %v857 = ptrtoint ptr %a1 to i64
  %v858 = ashr i64 %v857, 1
  %v859 = and i64 %v857, 1
  %v860 = icmp ne i64 %v859, 0
  %v861 = icmp ult i64 %v858, %v832
  %v862 = and i1 %v860, %v861
  br i1 %v862, label %array.valid.863, label %array.invalid.864
array.invalid.864:
  call void @mlf_bounds_failure()
  unreachable
array.valid.863:
  %v865 = getelementptr i8, ptr %v834, i64 %v858
  %v866 = ptrtoint ptr %v856 to i64
  %v867 = ashr i64 %v866, 1
  %v868 = and i64 %v866, 1
  %v869 = icmp ne i64 %v868, 0
  %v870 = icmp ult i64 %v867, 256
  %v871 = and i1 %v869, %v870
  br i1 %v871, label %yes.872, label %no.873
yes.872:
  %v875 = trunc i64 %v867 to i8
  br label %join.874
no.873:
  %v876 = call i8 @mlf_byte(ptr %v856)
  br label %join.874
join.874:
  %v877 = phi i8 [ %v875, %yes.872 ], [ %v876, %no.873 ]
  store i8 %v877, ptr %v865, align 1, !tbaa !4
  %v878 = ptrtoint ptr %a2 to i64
  %v879 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v880 = and i64 %v878, %v879
  %v881 = and i64 %v880, 1
  %v882 = icmp ne i64 %v881, 0
  br i1 %v882, label %yes.883, label %no.884
yes.883:
  %v886 = sub i64 %v879, 1
  %v887 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v878, i64 %v886)
  %v888 = extractvalue { i64, i1 } %v887, 0
  %v889 = extractvalue { i64, i1 } %v887, 1
  br i1 %v889, label %yes.890, label %no.891
yes.890:
  %v893 = call ptr @mlf_sub_int(ptr %a2, ptr inttoptr (i64 3 to ptr))
  br label %join.892
no.891:
  %v894 = inttoptr i64 %v888 to ptr
  br label %join.892
join.892:
  %v895 = phi ptr [ %v893, %yes.890 ], [ %v894, %no.891 ]
  br label %join.885
no.884:
  %v896 = call ptr @mlf_sub_int(ptr %a2, ptr inttoptr (i64 3 to ptr))
  br label %join.885
join.885:
  %v897 = phi ptr [ %v895, %join.892 ], [ %v896, %no.884 ]
  %v898 = musttail call ptr @mlf.numeric.31(ptr %a0, ptr %a1, ptr %v897)
  ret ptr %v898
}

define private ptr @mlf.numeric.37(ptr %a0, ptr %a1, ptr %a2, ptr %a3) alwaysinline {
entry:
  %v145 = ptrtoint ptr %a3 to i64
  %v146 = ptrtoint ptr %a1 to i64
  %v147 = and i64 %v145, %v146
  %v148 = and i64 %v147, 1
  %v149 = icmp ne i64 %v148, 0
  br i1 %v149, label %yes.150, label %no.151
yes.150:
  %v153 = icmp slt i64 %v145, %v146
  %v154 = select i1 %v153, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.152
no.151:
  %v155 = call ptr @mlf_lt_int(ptr %a3, ptr %a1)
  br label %join.152
join.152:
  %v156 = phi ptr [ %v154, %yes.150 ], [ %v155, %no.151 ]
  %v157 = icmp eq ptr %v156, inttoptr (i64 6 to ptr)
  br i1 %v157, label %tail.yes.158, label %tail.no.159
tail.yes.158:
  %v160 = ptrtoint ptr %a3 to i64
  %v161 = and i64 %v160, 1
  %v162 = icmp ne i64 %v161, 0
  br i1 %v162, label %yes.163, label %no.164
yes.163:
  %v166 = ashr i64 %v160, 1
  %v167 = sitofp i64 %v166 to double
  br label %join.165
no.164:
  %v168 = call double @mlf_int_to_double(ptr %a3)
  br label %join.165
join.165:
  %v169 = phi double [ %v167, %yes.163 ], [ %v168, %no.164 ]
  %v170 = fmul double 0x4000000000000000, %v169
  %v171 = ptrtoint ptr %a1 to i64
  %v172 = and i64 %v171, 1
  %v173 = icmp ne i64 %v172, 0
  br i1 %v173, label %yes.174, label %no.175
yes.174:
  %v177 = ashr i64 %v171, 1
  %v178 = sitofp i64 %v177 to double
  br label %join.176
no.175:
  %v179 = call double @mlf_int_to_double(ptr %a1)
  br label %join.176
join.176:
  %v180 = phi double [ %v178, %yes.174 ], [ %v179, %no.175 ]
  %v181 = fdiv double %v170, %v180
  %v182 = fsub double %v181, 0x3ff8000000000000
  %v183 = ptrtoint ptr %a2 to i64
  %v184 = and i64 %v183, 1
  %v185 = icmp ne i64 %v184, 0
  br i1 %v185, label %yes.186, label %no.187
yes.186:
  %v189 = ashr i64 %v183, 1
  %v190 = sitofp i64 %v189 to double
  br label %join.188
no.187:
  %v191 = call double @mlf_int_to_double(ptr %a2)
  br label %join.188
join.188:
  %v192 = phi double [ %v190, %yes.186 ], [ %v191, %no.187 ]
  %v193 = fmul double 0x4000000000000000, %v192
  %v194 = ptrtoint ptr %a1 to i64
  %v195 = and i64 %v194, 1
  %v196 = icmp ne i64 %v195, 0
  br i1 %v196, label %yes.197, label %no.198
yes.197:
  %v200 = ashr i64 %v194, 1
  %v201 = sitofp i64 %v200 to double
  br label %join.199
no.198:
  %v202 = call double @mlf_int_to_double(ptr %a1)
  br label %join.199
join.199:
  %v203 = phi double [ %v201, %yes.197 ], [ %v202, %no.198 ]
  %v204 = fdiv double %v193, %v203
  %v205 = fsub double %v204, 0x3ff0000000000000
  %v206 = ptrtoint ptr %a3 to i64
  %v207 = ptrtoint ptr inttoptr (i64 17 to ptr) to i64
  %v208 = and i64 %v206, %v207
  %v209 = and i64 %v208, 1
  %v210 = icmp ne i64 %v209, 0
  br i1 %v210, label %yes.211, label %no.212
yes.211:
  %v214 = ashr i64 %v206, 1
  %v215 = ashr i64 %v207, 1
  %v216 = icmp ne i64 %v215, 0
  %v217 = icmp eq i64 %v214, -4611686018427387904
  %v218 = icmp eq i64 %v215, -1
  %v219 = and i1 %v217, %v218
  %v220 = xor i1 %v219, true
  %v221 = and i1 %v216, %v220
  br i1 %v221, label %yes.222, label %no.223
yes.222:
  %v225 = sdiv i64 %v214, %v215
  %v226 = shl i64 %v225, 1
  %v227 = or i64 %v226, 1
  %v228 = inttoptr i64 %v227 to ptr
  br label %join.224
no.223:
  %v229 = call ptr @mlf_prim2(i64 15, ptr %a3, ptr inttoptr (i64 17 to ptr))
  br label %join.224
join.224:
  %v230 = phi ptr [ %v228, %yes.222 ], [ %v229, %no.223 ]
  br label %join.213
no.212:
  %v231 = call ptr @mlf_prim2(i64 15, ptr %a3, ptr inttoptr (i64 17 to ptr))
  br label %join.213
join.213:
  %v232 = phi ptr [ %v230, %join.224 ], [ %v231, %no.212 ]
  %v233 = ptrtoint ptr %a3 to i64
  %v234 = ptrtoint ptr inttoptr (i64 17 to ptr) to i64
  %v235 = and i64 %v233, %v234
  %v236 = and i64 %v235, 1
  %v237 = icmp ne i64 %v236, 0
  br i1 %v237, label %yes.238, label %no.239
yes.238:
  %v241 = ashr i64 %v233, 1
  %v242 = ashr i64 %v234, 1
  %v243 = icmp ne i64 %v242, 0
  %v244 = icmp eq i64 %v241, -4611686018427387904
  %v245 = icmp eq i64 %v242, -1
  %v246 = and i1 %v244, %v245
  %v247 = xor i1 %v246, true
  %v248 = and i1 %v243, %v247
  br i1 %v248, label %yes.249, label %no.250
yes.249:
  %v252 = srem i64 %v241, %v242
  %v253 = shl i64 %v252, 1
  %v254 = or i64 %v253, 1
  %v255 = inttoptr i64 %v254 to ptr
  br label %join.251
no.250:
  %v256 = call ptr @mlf_prim2(i64 16, ptr %a3, ptr inttoptr (i64 17 to ptr))
  br label %join.251
join.251:
  %v257 = phi ptr [ %v255, %yes.249 ], [ %v256, %no.250 ]
  br label %join.240
no.239:
  %v258 = call ptr @mlf_prim2(i64 16, ptr %a3, ptr inttoptr (i64 17 to ptr))
  br label %join.240
join.240:
  %v259 = phi ptr [ %v257, %join.251 ], [ %v258, %no.239 ]
  %v260 = ptrtoint ptr %v259 to i64
  %v261 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v262 = and i64 %v260, %v261
  %v263 = and i64 %v262, 1
  %v264 = icmp ne i64 %v263, 0
  br i1 %v264, label %yes.265, label %no.266
yes.265:
  %v268 = icmp eq i64 %v260, %v261
  %v269 = select i1 %v268, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.267
no.266:
  %v270 = call ptr @mlf_eq_int(ptr %v259, ptr inttoptr (i64 1 to ptr))
  br label %join.267
join.267:
  %v271 = phi ptr [ %v269, %yes.265 ], [ %v270, %no.266 ]
  %v272 = icmp eq ptr %v271, inttoptr (i64 6 to ptr)
  br i1 %v272, label %yes.273, label %no.274
yes.273:
  %v276 = getelementptr i8, ptr %a0, i64 8
  %v277 = load i64, ptr %v276, align 8, !tbaa !3
  %v278 = getelementptr i8, ptr %a0, i64 16
  %v279 = load ptr, ptr %v278, align 8, !tbaa !3
  %v280 = ptrtoint ptr %v232 to i64
  %v281 = ashr i64 %v280, 1
  %v282 = and i64 %v280, 1
  %v283 = icmp ne i64 %v282, 0
  %v284 = icmp ult i64 %v281, %v277
  %v285 = and i1 %v283, %v284
  br i1 %v285, label %array.valid.286, label %array.invalid.287
array.invalid.287:
  call void @mlf_bounds_failure()
  unreachable
array.valid.286:
  %v288 = getelementptr i8, ptr %v279, i64 %v281
  %v289 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v290 = ashr i64 %v289, 1
  %v291 = trunc i64 %v290 to i8
  store i8 %v291, ptr %v288, align 1, !tbaa !4
  br label %join.275
no.274:
  br label %join.275
join.275:
  %v292 = phi ptr [ inttoptr (i64 4 to ptr), %array.valid.286 ], [ inttoptr (i64 4 to ptr), %no.274 ]
  %v293 = getelementptr i8, ptr %a0, i64 8
  %v294 = load i64, ptr %v293, align 8, !tbaa !3
  %v295 = getelementptr i8, ptr %a0, i64 16
  %v296 = load ptr, ptr %v295, align 8, !tbaa !3
  %v297 = ptrtoint ptr %v232 to i64
  %v298 = ashr i64 %v297, 1
  %v299 = and i64 %v297, 1
  %v300 = icmp ne i64 %v299, 0
  %v301 = icmp ult i64 %v298, %v294
  %v302 = and i1 %v300, %v301
  br i1 %v302, label %array.valid.303, label %array.invalid.304
array.invalid.304:
  call void @mlf_bounds_failure()
  unreachable
array.valid.303:
  %v305 = getelementptr i8, ptr %v296, i64 %v298
  %v306 = load i8, ptr %v305, align 1, !tbaa !4
  %v307 = zext i8 %v306 to i64
  %v308 = shl i64 %v307, 1
  %v309 = or i64 %v308, 1
  %v310 = inttoptr i64 %v309 to ptr
  %v311 = ptrtoint ptr %a3 to i64
  %v312 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v313 = and i64 %v311, %v312
  %v314 = and i64 %v313, 1
  %v315 = icmp ne i64 %v314, 0
  br i1 %v315, label %yes.316, label %no.317
yes.316:
  %v319 = sub i64 %v312, 1
  %v320 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v311, i64 %v319)
  %v321 = extractvalue { i64, i1 } %v320, 0
  %v322 = extractvalue { i64, i1 } %v320, 1
  br i1 %v322, label %yes.323, label %no.324
yes.323:
  %v326 = call ptr @mlf_add_int(ptr %a3, ptr inttoptr (i64 3 to ptr))
  br label %join.325
no.324:
  %v327 = inttoptr i64 %v321 to ptr
  br label %join.325
join.325:
  %v328 = phi ptr [ %v326, %yes.323 ], [ %v327, %no.324 ]
  br label %join.318
no.317:
  %v329 = call ptr @mlf_add_int(ptr %a3, ptr inttoptr (i64 3 to ptr))
  br label %join.318
join.318:
  %v330 = phi ptr [ %v328, %join.325 ], [ %v329, %no.317 ]
  %v331 = ptrtoint ptr %v330 to i64
  %v332 = ptrtoint ptr %a1 to i64
  %v333 = and i64 %v331, %v332
  %v334 = and i64 %v333, 1
  %v335 = icmp ne i64 %v334, 0
  br i1 %v335, label %yes.336, label %no.337
yes.336:
  %v339 = icmp slt i64 %v331, %v332
  %v340 = select i1 %v339, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.338
no.337:
  %v341 = call ptr @mlf_lt_int(ptr %v330, ptr %a1)
  br label %join.338
join.338:
  %v342 = phi ptr [ %v340, %yes.336 ], [ %v341, %no.337 ]
  %v343 = icmp eq ptr %v342, inttoptr (i64 6 to ptr)
  br i1 %v343, label %tail.yes.344, label %tail.no.345
tail.yes.344:
  %v346 = ptrtoint ptr %a3 to i64
  %v347 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v348 = and i64 %v346, %v347
  %v349 = and i64 %v348, 1
  %v350 = icmp ne i64 %v349, 0
  br i1 %v350, label %yes.351, label %no.352
yes.351:
  %v354 = sub i64 %v347, 1
  %v355 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v346, i64 %v354)
  %v356 = extractvalue { i64, i1 } %v355, 0
  %v357 = extractvalue { i64, i1 } %v355, 1
  br i1 %v357, label %yes.358, label %no.359
yes.358:
  %v361 = call ptr @mlf_add_int(ptr %a3, ptr inttoptr (i64 3 to ptr))
  br label %join.360
no.359:
  %v362 = inttoptr i64 %v356 to ptr
  br label %join.360
join.360:
  %v363 = phi ptr [ %v361, %yes.358 ], [ %v362, %no.359 ]
  br label %join.353
no.352:
  %v364 = call ptr @mlf_add_int(ptr %a3, ptr inttoptr (i64 3 to ptr))
  br label %join.353
join.353:
  %v365 = phi ptr [ %v363, %join.360 ], [ %v364, %no.352 ]
  %v366 = ptrtoint ptr %v365 to i64
  %v367 = and i64 %v366, 1
  %v368 = icmp ne i64 %v367, 0
  br i1 %v368, label %yes.369, label %no.370
yes.369:
  %v372 = ashr i64 %v366, 1
  %v373 = sitofp i64 %v372 to double
  br label %join.371
no.370:
  %v374 = call double @mlf_int_to_double(ptr %v365)
  br label %join.371
join.371:
  %v375 = phi double [ %v373, %yes.369 ], [ %v374, %no.370 ]
  %v376 = fmul double 0x4000000000000000, %v375
  %v377 = ptrtoint ptr %a1 to i64
  %v378 = and i64 %v377, 1
  %v379 = icmp ne i64 %v378, 0
  br i1 %v379, label %yes.380, label %no.381
yes.380:
  %v383 = ashr i64 %v377, 1
  %v384 = sitofp i64 %v383 to double
  br label %join.382
no.381:
  %v385 = call double @mlf_int_to_double(ptr %a1)
  br label %join.382
join.382:
  %v386 = phi double [ %v384, %yes.380 ], [ %v385, %no.381 ]
  %v387 = fdiv double %v376, %v386
  %v388 = fsub double %v387, 0x3ff8000000000000
  %v455 = call ptr @mlf.numeric.10.dddddddddddppn(double 0x0000000000000000, double 0x0000000000000000, double 0x0000000000000000, double 0x0000000000000000, double %v182, double 0x0000000000000000, double 0x0000000000000000, double 0x0000000000000000, double 0x0000000000000000, double %v388, double %v205, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 101 to ptr))
  %v456 = ptrtoint ptr %v310 to i64
  %v457 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v458 = ashr i64 %v456, 1
  %v459 = ashr i64 %v457, 1
  %v460 = mul nsw i64 %v458, %v459
  %v461 = shl i64 %v460, 1
  %v462 = or i64 %v461, 1
  %v463 = inttoptr i64 %v462 to ptr
  %v464 = ptrtoint ptr %v463 to i64
  %v465 = ptrtoint ptr %v455 to i64
  %v466 = and i64 %v464, %v465
  %v467 = and i64 %v466, 1
  %v468 = icmp ne i64 %v467, 0
  br i1 %v468, label %yes.469, label %no.470
yes.469:
  %v472 = sub i64 %v465, 1
  %v473 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v464, i64 %v472)
  %v474 = extractvalue { i64, i1 } %v473, 0
  %v475 = extractvalue { i64, i1 } %v473, 1
  br i1 %v475, label %yes.476, label %no.477
yes.476:
  %v479 = call ptr @mlf_add_int(ptr %v463, ptr %v455)
  br label %join.478
no.477:
  %v480 = inttoptr i64 %v474 to ptr
  br label %join.478
join.478:
  %v481 = phi ptr [ %v479, %yes.476 ], [ %v480, %no.477 ]
  br label %join.471
no.470:
  %v482 = call ptr @mlf_add_int(ptr %v463, ptr %v455)
  br label %join.471
join.471:
  %v483 = phi ptr [ %v481, %join.478 ], [ %v482, %no.470 ]
  %v484 = ptrtoint ptr %v232 to i64
  %v485 = ashr i64 %v484, 1
  %v486 = and i64 %v484, 1
  %v487 = icmp ne i64 %v486, 0
  %v488 = icmp ult i64 %v485, %v294
  %v489 = and i1 %v487, %v488
  br i1 %v489, label %array.valid.490, label %array.invalid.491
array.invalid.491:
  call void @mlf_bounds_failure()
  unreachable
array.valid.490:
  %v492 = getelementptr i8, ptr %v296, i64 %v485
  %v493 = ptrtoint ptr %v483 to i64
  %v494 = ashr i64 %v493, 1
  %v495 = and i64 %v493, 1
  %v496 = icmp ne i64 %v495, 0
  %v497 = icmp ult i64 %v494, 256
  %v498 = and i1 %v496, %v497
  br i1 %v498, label %yes.499, label %no.500
yes.499:
  %v502 = trunc i64 %v494 to i8
  br label %join.501
no.500:
  %v503 = call i8 @mlf_byte(ptr %v483)
  br label %join.501
join.501:
  %v504 = phi i8 [ %v502, %yes.499 ], [ %v503, %no.500 ]
  store i8 %v504, ptr %v492, align 1, !tbaa !4
  %v505 = ptrtoint ptr %a3 to i64
  %v506 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v507 = and i64 %v505, %v506
  %v508 = and i64 %v507, 1
  %v509 = icmp ne i64 %v508, 0
  br i1 %v509, label %yes.510, label %no.511
yes.510:
  %v513 = sub i64 %v506, 1
  %v514 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v505, i64 %v513)
  %v515 = extractvalue { i64, i1 } %v514, 0
  %v516 = extractvalue { i64, i1 } %v514, 1
  br i1 %v516, label %yes.517, label %no.518
yes.517:
  %v520 = call ptr @mlf_add_int(ptr %a3, ptr inttoptr (i64 5 to ptr))
  br label %join.519
no.518:
  %v521 = inttoptr i64 %v515 to ptr
  br label %join.519
join.519:
  %v522 = phi ptr [ %v520, %yes.517 ], [ %v521, %no.518 ]
  br label %join.512
no.511:
  %v523 = call ptr @mlf_add_int(ptr %a3, ptr inttoptr (i64 5 to ptr))
  br label %join.512
join.512:
  %v524 = phi ptr [ %v522, %join.519 ], [ %v523, %no.511 ]
  %v525 = musttail call ptr @mlf.numeric.37(ptr %a0, ptr %a1, ptr %a2, ptr %v524)
  ret ptr %v525
tail.no.345:
  %v552 = call ptr @mlf.numeric.0.ddddddn(double 0x0000000000000000, double 0x0000000000000000, double 0x0000000000000000, double 0x0000000000000000, double %v182, double %v205, ptr inttoptr (i64 101 to ptr))
  %v553 = ptrtoint ptr %v310 to i64
  %v554 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v555 = ashr i64 %v553, 1
  %v556 = ashr i64 %v554, 1
  %v557 = mul nsw i64 %v555, %v556
  %v558 = shl i64 %v557, 1
  %v559 = or i64 %v558, 1
  %v560 = inttoptr i64 %v559 to ptr
  %v561 = ptrtoint ptr %v560 to i64
  %v562 = ptrtoint ptr %v552 to i64
  %v563 = and i64 %v561, %v562
  %v564 = and i64 %v563, 1
  %v565 = icmp ne i64 %v564, 0
  br i1 %v565, label %yes.566, label %no.567
yes.566:
  %v569 = sub i64 %v562, 1
  %v570 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v561, i64 %v569)
  %v571 = extractvalue { i64, i1 } %v570, 0
  %v572 = extractvalue { i64, i1 } %v570, 1
  br i1 %v572, label %yes.573, label %no.574
yes.573:
  %v576 = call ptr @mlf_add_int(ptr %v560, ptr %v552)
  br label %join.575
no.574:
  %v577 = inttoptr i64 %v571 to ptr
  br label %join.575
join.575:
  %v578 = phi ptr [ %v576, %yes.573 ], [ %v577, %no.574 ]
  br label %join.568
no.567:
  %v579 = call ptr @mlf_add_int(ptr %v560, ptr %v552)
  br label %join.568
join.568:
  %v580 = phi ptr [ %v578, %join.575 ], [ %v579, %no.567 ]
  %v581 = ptrtoint ptr %v232 to i64
  %v582 = ashr i64 %v581, 1
  %v583 = and i64 %v581, 1
  %v584 = icmp ne i64 %v583, 0
  %v585 = icmp ult i64 %v582, %v294
  %v586 = and i1 %v584, %v585
  br i1 %v586, label %array.valid.587, label %array.invalid.588
array.invalid.588:
  call void @mlf_bounds_failure()
  unreachable
array.valid.587:
  %v589 = getelementptr i8, ptr %v296, i64 %v582
  %v590 = ptrtoint ptr %v580 to i64
  %v591 = ashr i64 %v590, 1
  %v592 = and i64 %v590, 1
  %v593 = icmp ne i64 %v592, 0
  %v594 = icmp ult i64 %v591, 256
  %v595 = and i1 %v593, %v594
  br i1 %v595, label %yes.596, label %no.597
yes.596:
  %v599 = trunc i64 %v591 to i8
  br label %join.598
no.597:
  %v600 = call i8 @mlf_byte(ptr %v580)
  br label %join.598
join.598:
  %v601 = phi i8 [ %v599, %yes.596 ], [ %v600, %no.597 ]
  store i8 %v601, ptr %v589, align 1, !tbaa !4
  %v602 = ptrtoint ptr %a3 to i64
  %v603 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v604 = and i64 %v602, %v603
  %v605 = and i64 %v604, 1
  %v606 = icmp ne i64 %v605, 0
  br i1 %v606, label %yes.607, label %no.608
yes.607:
  %v610 = sub i64 %v603, 1
  %v611 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v602, i64 %v610)
  %v612 = extractvalue { i64, i1 } %v611, 0
  %v613 = extractvalue { i64, i1 } %v611, 1
  br i1 %v613, label %yes.614, label %no.615
yes.614:
  %v617 = call ptr @mlf_add_int(ptr %a3, ptr inttoptr (i64 3 to ptr))
  br label %join.616
no.615:
  %v618 = inttoptr i64 %v612 to ptr
  br label %join.616
join.616:
  %v619 = phi ptr [ %v617, %yes.614 ], [ %v618, %no.615 ]
  br label %join.609
no.608:
  %v620 = call ptr @mlf_add_int(ptr %a3, ptr inttoptr (i64 3 to ptr))
  br label %join.609
join.609:
  %v621 = phi ptr [ %v619, %join.616 ], [ %v620, %no.608 ]
  %v622 = musttail call ptr @mlf.numeric.37(ptr %a0, ptr %a1, ptr %a2, ptr %v621)
  ret ptr %v622
tail.no.159:
  %v623 = ptrtoint ptr %a1 to i64
  %v624 = ptrtoint ptr inttoptr (i64 17 to ptr) to i64
  %v625 = and i64 %v623, %v624
  %v626 = and i64 %v625, 1
  %v627 = icmp ne i64 %v626, 0
  br i1 %v627, label %yes.628, label %no.629
yes.628:
  %v631 = ashr i64 %v623, 1
  %v632 = ashr i64 %v624, 1
  %v633 = icmp ne i64 %v632, 0
  %v634 = icmp eq i64 %v631, -4611686018427387904
  %v635 = icmp eq i64 %v632, -1
  %v636 = and i1 %v634, %v635
  %v637 = xor i1 %v636, true
  %v638 = and i1 %v633, %v637
  br i1 %v638, label %yes.639, label %no.640
yes.639:
  %v642 = sdiv i64 %v631, %v632
  %v643 = shl i64 %v642, 1
  %v644 = or i64 %v643, 1
  %v645 = inttoptr i64 %v644 to ptr
  br label %join.641
no.640:
  %v646 = call ptr @mlf_prim2(i64 15, ptr %a1, ptr inttoptr (i64 17 to ptr))
  br label %join.641
join.641:
  %v647 = phi ptr [ %v645, %yes.639 ], [ %v646, %no.640 ]
  br label %join.630
no.629:
  %v648 = call ptr @mlf_prim2(i64 15, ptr %a1, ptr inttoptr (i64 17 to ptr))
  br label %join.630
join.630:
  %v649 = phi ptr [ %v647, %join.641 ], [ %v648, %no.629 ]
  %v650 = ptrtoint ptr %a1 to i64
  %v651 = ptrtoint ptr inttoptr (i64 17 to ptr) to i64
  %v652 = and i64 %v650, %v651
  %v653 = and i64 %v652, 1
  %v654 = icmp ne i64 %v653, 0
  br i1 %v654, label %yes.655, label %no.656
yes.655:
  %v658 = ashr i64 %v650, 1
  %v659 = ashr i64 %v651, 1
  %v660 = icmp ne i64 %v659, 0
  %v661 = icmp eq i64 %v658, -4611686018427387904
  %v662 = icmp eq i64 %v659, -1
  %v663 = and i1 %v661, %v662
  %v664 = xor i1 %v663, true
  %v665 = and i1 %v660, %v664
  br i1 %v665, label %yes.666, label %no.667
yes.666:
  %v669 = srem i64 %v658, %v659
  %v670 = shl i64 %v669, 1
  %v671 = or i64 %v670, 1
  %v672 = inttoptr i64 %v671 to ptr
  br label %join.668
no.667:
  %v673 = call ptr @mlf_prim2(i64 16, ptr %a1, ptr inttoptr (i64 17 to ptr))
  br label %join.668
join.668:
  %v674 = phi ptr [ %v672, %yes.666 ], [ %v673, %no.667 ]
  br label %join.657
no.656:
  %v675 = call ptr @mlf_prim2(i64 16, ptr %a1, ptr inttoptr (i64 17 to ptr))
  br label %join.657
join.657:
  %v676 = phi ptr [ %v674, %join.668 ], [ %v675, %no.656 ]
  %v677 = ptrtoint ptr %v676 to i64
  %v678 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v679 = and i64 %v677, %v678
  %v680 = and i64 %v679, 1
  %v681 = icmp ne i64 %v680, 0
  br i1 %v681, label %yes.682, label %no.683
yes.682:
  %v685 = icmp eq i64 %v677, %v678
  %v686 = select i1 %v685, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.684
no.683:
  %v687 = call ptr @mlf_eq_int(ptr %v676, ptr inttoptr (i64 1 to ptr))
  br label %join.684
join.684:
  %v688 = phi ptr [ %v686, %yes.682 ], [ %v687, %no.683 ]
  %v689 = icmp eq ptr %v688, inttoptr (i64 6 to ptr)
  br i1 %v689, label %yes.690, label %no.691
yes.690:
  br label %join.692
no.691:
  %v693 = ptrtoint ptr %a1 to i64
  %v694 = ptrtoint ptr inttoptr (i64 17 to ptr) to i64
  %v695 = and i64 %v693, %v694
  %v696 = and i64 %v695, 1
  %v697 = icmp ne i64 %v696, 0
  br i1 %v697, label %yes.698, label %no.699
yes.698:
  %v701 = ashr i64 %v693, 1
  %v702 = ashr i64 %v694, 1
  %v703 = icmp ne i64 %v702, 0
  %v704 = icmp eq i64 %v701, -4611686018427387904
  %v705 = icmp eq i64 %v702, -1
  %v706 = and i1 %v704, %v705
  %v707 = xor i1 %v706, true
  %v708 = and i1 %v703, %v707
  br i1 %v708, label %yes.709, label %no.710
yes.709:
  %v712 = srem i64 %v701, %v702
  %v713 = shl i64 %v712, 1
  %v714 = or i64 %v713, 1
  %v715 = inttoptr i64 %v714 to ptr
  br label %join.711
no.710:
  %v716 = call ptr @mlf_prim2(i64 16, ptr %a1, ptr inttoptr (i64 17 to ptr))
  br label %join.711
join.711:
  %v717 = phi ptr [ %v715, %yes.709 ], [ %v716, %no.710 ]
  br label %join.700
no.699:
  %v718 = call ptr @mlf_prim2(i64 16, ptr %a1, ptr inttoptr (i64 17 to ptr))
  br label %join.700
join.700:
  %v719 = phi ptr [ %v717, %join.711 ], [ %v718, %no.699 ]
  %v720 = ptrtoint ptr inttoptr (i64 17 to ptr) to i64
  %v721 = ptrtoint ptr %v719 to i64
  %v722 = and i64 %v720, %v721
  %v723 = and i64 %v722, 1
  %v724 = icmp ne i64 %v723, 0
  br i1 %v724, label %yes.725, label %no.726
yes.725:
  %v728 = sub i64 %v721, 1
  %v729 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v720, i64 %v728)
  %v730 = extractvalue { i64, i1 } %v729, 0
  %v731 = extractvalue { i64, i1 } %v729, 1
  br i1 %v731, label %yes.732, label %no.733
yes.732:
  %v735 = call ptr @mlf_sub_int(ptr inttoptr (i64 17 to ptr), ptr %v719)
  br label %join.734
no.733:
  %v736 = inttoptr i64 %v730 to ptr
  br label %join.734
join.734:
  %v737 = phi ptr [ %v735, %yes.732 ], [ %v736, %no.733 ]
  br label %join.727
no.726:
  %v738 = call ptr @mlf_sub_int(ptr inttoptr (i64 17 to ptr), ptr %v719)
  br label %join.727
join.727:
  %v739 = phi ptr [ %v737, %join.734 ], [ %v738, %no.726 ]
  br label %join.692
join.692:
  %v740 = phi ptr [ inttoptr (i64 1 to ptr), %yes.690 ], [ %v739, %join.727 ]
  %v899 = call ptr @mlf.numeric.31(ptr %a0, ptr %v649, ptr %v740)
  ret ptr %v899
}

define private ptr @mlf.numeric.52(ptr %a0, ptr %a1, ptr %a2) alwaysinline {
entry:
  %v130 = ptrtoint ptr %a2 to i64
  %v131 = ptrtoint ptr %a1 to i64
  %v132 = and i64 %v130, %v131
  %v133 = and i64 %v132, 1
  %v134 = icmp ne i64 %v133, 0
  br i1 %v134, label %yes.135, label %no.136
yes.135:
  %v138 = icmp slt i64 %v130, %v131
  %v139 = select i1 %v138, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.137
no.136:
  %v140 = call ptr @mlf_lt_int(ptr %a2, ptr %a1)
  br label %join.137
join.137:
  %v141 = phi ptr [ %v139, %yes.135 ], [ %v140, %no.136 ]
  %v142 = icmp eq ptr %v141, inttoptr (i64 6 to ptr)
  br i1 %v142, label %tail.yes.143, label %tail.no.144
tail.yes.143:
  %v900 = call ptr @mlf.numeric.37(ptr %a0, ptr %a1, ptr %a2, ptr inttoptr (i64 1 to ptr))
  %v901 = ptrtoint ptr %a1 to i64
  %v902 = ptrtoint ptr inttoptr (i64 15 to ptr) to i64
  %v903 = and i64 %v901, %v902
  %v904 = and i64 %v903, 1
  %v905 = icmp ne i64 %v904, 0
  br i1 %v905, label %yes.906, label %no.907
yes.906:
  %v909 = sub i64 %v902, 1
  %v910 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v901, i64 %v909)
  %v911 = extractvalue { i64, i1 } %v910, 0
  %v912 = extractvalue { i64, i1 } %v910, 1
  br i1 %v912, label %yes.913, label %no.914
yes.913:
  %v916 = call ptr @mlf_add_int(ptr %a1, ptr inttoptr (i64 15 to ptr))
  br label %join.915
no.914:
  %v917 = inttoptr i64 %v911 to ptr
  br label %join.915
join.915:
  %v918 = phi ptr [ %v916, %yes.913 ], [ %v917, %no.914 ]
  br label %join.908
no.907:
  %v919 = call ptr @mlf_add_int(ptr %a1, ptr inttoptr (i64 15 to ptr))
  br label %join.908
join.908:
  %v920 = phi ptr [ %v918, %join.915 ], [ %v919, %no.907 ]
  %v921 = ptrtoint ptr %v920 to i64
  %v922 = ptrtoint ptr inttoptr (i64 17 to ptr) to i64
  %v923 = and i64 %v921, %v922
  %v924 = and i64 %v923, 1
  %v925 = icmp ne i64 %v924, 0
  br i1 %v925, label %yes.926, label %no.927
yes.926:
  %v929 = ashr i64 %v921, 1
  %v930 = ashr i64 %v922, 1
  %v931 = icmp ne i64 %v930, 0
  %v932 = icmp eq i64 %v929, -4611686018427387904
  %v933 = icmp eq i64 %v930, -1
  %v934 = and i1 %v932, %v933
  %v935 = xor i1 %v934, true
  %v936 = and i1 %v931, %v935
  br i1 %v936, label %yes.937, label %no.938
yes.937:
  %v940 = sdiv i64 %v929, %v930
  %v941 = shl i64 %v940, 1
  %v942 = or i64 %v941, 1
  %v943 = inttoptr i64 %v942 to ptr
  br label %join.939
no.938:
  %v944 = call ptr @mlf_prim2(i64 15, ptr %v920, ptr inttoptr (i64 17 to ptr))
  br label %join.939
join.939:
  %v945 = phi ptr [ %v943, %yes.937 ], [ %v944, %no.938 ]
  br label %join.928
no.927:
  %v946 = call ptr @mlf_prim2(i64 15, ptr %v920, ptr inttoptr (i64 17 to ptr))
  br label %join.928
join.928:
  %v947 = phi ptr [ %v945, %join.939 ], [ %v946, %no.927 ]
  %v948 = call ptr @mlf_put_bytes(ptr %a0, ptr inttoptr (i64 1 to ptr), ptr %v947)
  %v949 = ptrtoint ptr %a2 to i64
  %v950 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v951 = and i64 %v949, %v950
  %v952 = and i64 %v951, 1
  %v953 = icmp ne i64 %v952, 0
  br i1 %v953, label %yes.954, label %no.955
yes.954:
  %v957 = sub i64 %v950, 1
  %v958 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v949, i64 %v957)
  %v959 = extractvalue { i64, i1 } %v958, 0
  %v960 = extractvalue { i64, i1 } %v958, 1
  br i1 %v960, label %yes.961, label %no.962
yes.961:
  %v964 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 3 to ptr))
  br label %join.963
no.962:
  %v965 = inttoptr i64 %v959 to ptr
  br label %join.963
join.963:
  %v966 = phi ptr [ %v964, %yes.961 ], [ %v965, %no.962 ]
  br label %join.956
no.955:
  %v967 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 3 to ptr))
  br label %join.956
join.956:
  %v968 = phi ptr [ %v966, %join.963 ], [ %v967, %no.955 ]
  %v969 = musttail call ptr @mlf.numeric.52(ptr %a0, ptr %a1, ptr %v968)
  ret ptr %v969
tail.no.144:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.code.1018(ptr %env, ptr %arg) {
entry:
  %v1019 = getelementptr i8, ptr %env, i64 8
  %v1020 = load ptr, ptr %v1019, align 8, !tbaa !3
  %v1021 = getelementptr i8, ptr %env, i64 16
  %v1022 = load ptr, ptr %v1021, align 8, !tbaa !3
  %v1023 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1023, align 8, !tbaa !3
  %v1024 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1024, align 8, !tbaa !3
  %v1025 = call ptr @mlf_double(double 0x4000000000000000)
  %v1026 = call ptr @mlf.force(ptr %v1022)
  %v1027 = call ptr @mlf_prim1(i64 25, ptr %v1026)
  %v1028 = call ptr @mlf_prim2(i64 20, ptr %v1025, ptr %v1027)
  %v1029 = call ptr @mlf.force(ptr %v1020)
  %v1030 = call ptr @mlf_prim1(i64 25, ptr %v1029)
  %v1031 = call ptr @mlf_prim2(i64 21, ptr %v1028, ptr %v1030)
  %v1032 = call ptr @mlf_double(double 0x3ff8000000000000)
  %v1033 = call ptr @mlf_prim2(i64 19, ptr %v1031, ptr %v1032)
  ret ptr %v1033
}

define private ptr @mlf.code.1039(ptr %env, ptr %arg) {
entry:
  %v1040 = getelementptr i8, ptr %env, i64 8
  %v1041 = load ptr, ptr %v1040, align 8, !tbaa !3
  %v1042 = getelementptr i8, ptr %env, i64 16
  %v1043 = load ptr, ptr %v1042, align 8, !tbaa !3
  %v1044 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1044, align 8, !tbaa !3
  %v1045 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1045, align 8, !tbaa !3
  %v1046 = call ptr @mlf_double(double 0x4000000000000000)
  %v1047 = call ptr @mlf.force(ptr %v1043)
  %v1048 = call ptr @mlf_prim1(i64 25, ptr %v1047)
  %v1049 = call ptr @mlf_prim2(i64 20, ptr %v1046, ptr %v1048)
  %v1050 = call ptr @mlf.force(ptr %v1041)
  %v1051 = call ptr @mlf_prim1(i64 25, ptr %v1050)
  %v1052 = call ptr @mlf_prim2(i64 21, ptr %v1049, ptr %v1051)
  %v1053 = call ptr @mlf_double(double 0x3ff0000000000000)
  %v1054 = call ptr @mlf_prim2(i64 19, ptr %v1052, ptr %v1053)
  ret ptr %v1054
}

define private ptr @mlf.code.1060(ptr %env, ptr %arg) {
entry:
  %v1061 = getelementptr i8, ptr %env, i64 8
  %v1062 = load ptr, ptr %v1061, align 8, !tbaa !3
  %v1063 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1063, align 8, !tbaa !3
  %v1064 = call ptr @mlf.force(ptr %v1062)
  %v1065 = call ptr @mlf_prim2(i64 15, ptr %v1064, ptr inttoptr (i64 17 to ptr))
  ret ptr %v1065
}

define private ptr @mlf.code.1070(ptr %env, ptr %arg) {
entry:
  %v1071 = getelementptr i8, ptr %env, i64 8
  %v1072 = load ptr, ptr %v1071, align 8, !tbaa !3
  %v1073 = getelementptr i8, ptr %env, i64 16
  %v1074 = load ptr, ptr %v1073, align 8, !tbaa !3
  %v1075 = getelementptr i8, ptr %env, i64 24
  %v1076 = load ptr, ptr %v1075, align 8, !tbaa !3
  %v1077 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1077, align 8, !tbaa !3
  %v1078 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1078, align 8, !tbaa !3
  %v1079 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v1079, align 8, !tbaa !3
  %v1080 = call ptr @mlf.force(ptr %v1074)
  %v1081 = call ptr @mlf_prim2(i64 16, ptr %v1080, ptr inttoptr (i64 17 to ptr))
  %v1082 = call ptr @mlf_prim2(i64 10, ptr %v1081, ptr inttoptr (i64 1 to ptr))
  %v1083 = icmp eq ptr %v1082, inttoptr (i64 6 to ptr)
  br i1 %v1083, label %yes.1084, label %no.1085
yes.1084:
  %v1087 = call ptr @mlf_prim3(i64 37, ptr %v1072, ptr %v1076, ptr inttoptr (i64 1 to ptr))
  br label %join.1086
no.1085:
  %v1088 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.1086
join.1086:
  %v1089 = phi ptr [ %v1087, %yes.1084 ], [ %v1088, %no.1085 ]
  ret ptr %v1089
}

define private ptr @mlf.code.1111(ptr %env, ptr %arg) {
entry:
  %v1112 = getelementptr i8, ptr %env, i64 8
  %v1113 = load ptr, ptr %v1112, align 8, !tbaa !3
  %v1114 = getelementptr i8, ptr %env, i64 16
  %v1115 = load ptr, ptr %v1114, align 8, !tbaa !3
  %v1116 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1116, align 8, !tbaa !3
  %v1117 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1117, align 8, !tbaa !3
  %v1118 = call ptr @mlf_prim2(i64 36, ptr %v1113, ptr %v1115)
  ret ptr %v1118
}

define private ptr @mlf.code.1147(ptr %env, ptr %arg) {
entry:
  %v1148 = getelementptr i8, ptr %env, i64 8
  %v1149 = load ptr, ptr %v1148, align 8, !tbaa !3
  %v1150 = getelementptr i8, ptr %env, i64 16
  %v1151 = load ptr, ptr %v1150, align 8, !tbaa !3
  %v1152 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1152, align 8, !tbaa !3
  %v1153 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1153, align 8, !tbaa !3
  %v1154 = call ptr @mlf_double(double 0x4000000000000000)
  %v1155 = call ptr @mlf.force(ptr %v1151)
  %v1156 = call ptr @mlf_prim2(i64 8, ptr %v1155, ptr inttoptr (i64 3 to ptr))
  %v1157 = call ptr @mlf_prim1(i64 25, ptr %v1156)
  %v1158 = call ptr @mlf_prim2(i64 20, ptr %v1154, ptr %v1157)
  %v1159 = call ptr @mlf.force(ptr %v1149)
  %v1160 = call ptr @mlf_prim1(i64 25, ptr %v1159)
  %v1161 = call ptr @mlf_prim2(i64 21, ptr %v1158, ptr %v1160)
  %v1162 = call ptr @mlf_double(double 0x3ff8000000000000)
  %v1163 = call ptr @mlf_prim2(i64 19, ptr %v1161, ptr %v1162)
  ret ptr %v1163
}

define private ptr @mlf.numeric.10.dddddddddddppp(double %a0, double %a1, double %a2, double %a3, double %a4, double %a5, double %a6, double %a7, double %a8, double %a9, double %a10, ptr %a11, ptr %a12, ptr %a13) alwaysinline {
entry:
  %v1363 = fadd double %a2, %a3
  %v1364 = fcmp olt double 0x4010000000000000, %v1363
  %v1365 = select i1 %v1364, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1366 = icmp eq ptr %v1365, inttoptr (i64 6 to ptr)
  br i1 %v1366, label %yes.1367, label %no.1368
yes.1367:
  br label %join.1369
no.1368:
  br label %join.1369
join.1369:
  %v1370 = phi ptr [ inttoptr (i64 2 to ptr), %yes.1367 ], [ %a11, %no.1368 ]
  %v1371 = fadd double %a7, %a8
  %v1372 = fcmp olt double 0x4010000000000000, %v1371
  %v1373 = select i1 %v1372, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1374 = icmp eq ptr %v1373, inttoptr (i64 6 to ptr)
  br i1 %v1374, label %yes.1375, label %no.1376
yes.1375:
  br label %join.1377
no.1376:
  br label %join.1377
join.1377:
  %v1378 = phi ptr [ inttoptr (i64 2 to ptr), %yes.1375 ], [ %a12, %no.1376 ]
  %v1379 = icmp eq ptr %v1370, inttoptr (i64 6 to ptr)
  br i1 %v1379, label %yes.1380, label %no.1381
yes.1380:
  br label %join.1382
no.1381:
  br label %join.1382
join.1382:
  %v1383 = phi ptr [ inttoptr (i64 6 to ptr), %yes.1380 ], [ %v1378, %no.1381 ]
  %v1384 = icmp eq ptr %v1383, inttoptr (i64 6 to ptr)
  br i1 %v1384, label %tail.yes.1385, label %tail.no.1386
tail.yes.1385:
  %v1387 = ptrtoint ptr %a13 to i64
  %v1388 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v1389 = and i64 %v1387, %v1388
  %v1390 = and i64 %v1389, 1
  %v1391 = icmp ne i64 %v1390, 0
  br i1 %v1391, label %yes.1392, label %no.1393
yes.1392:
  %v1395 = icmp eq i64 %v1387, %v1388
  %v1396 = select i1 %v1395, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1394
no.1393:
  %v1397 = call ptr @mlf_eq_int(ptr %a13, ptr inttoptr (i64 1 to ptr))
  br label %join.1394
join.1394:
  %v1398 = phi ptr [ %v1396, %yes.1392 ], [ %v1397, %no.1393 ]
  %v1399 = icmp eq ptr %v1398, inttoptr (i64 6 to ptr)
  br i1 %v1399, label %tail.yes.1400, label %tail.no.1401
tail.yes.1400:
  %v1402 = icmp eq ptr %v1370, inttoptr (i64 6 to ptr)
  br i1 %v1402, label %yes.1403, label %no.1404
yes.1403:
  br label %join.1405
no.1404:
  br label %join.1405
join.1405:
  %v1406 = phi ptr [ inttoptr (i64 5 to ptr), %yes.1403 ], [ inttoptr (i64 1 to ptr), %no.1404 ]
  %v1407 = icmp eq ptr %v1378, inttoptr (i64 6 to ptr)
  br i1 %v1407, label %yes.1408, label %no.1409
yes.1408:
  br label %join.1410
no.1409:
  br label %join.1410
join.1410:
  %v1411 = phi ptr [ inttoptr (i64 3 to ptr), %yes.1408 ], [ inttoptr (i64 1 to ptr), %no.1409 ]
  %v1412 = ptrtoint ptr %v1406 to i64
  %v1413 = ptrtoint ptr %v1411 to i64
  %v1414 = sub i64 %v1413, 1
  %v1415 = add nsw i64 %v1412, %v1414
  %v1416 = inttoptr i64 %v1415 to ptr
  ret ptr %v1416
tail.no.1401:
  %v1417 = fmul double 0x4000000000000000, %a0
  %v1418 = fmul double %v1417, %a1
  %v1419 = fadd double %v1418, %a10
  %v1420 = fsub double %a2, %a3
  %v1421 = fadd double %v1420, %a4
  %v1422 = fmul double 0x4000000000000000, %a5
  %v1423 = fmul double %v1422, %a6
  %v1424 = fadd double %v1423, %a10
  %v1425 = fsub double %a7, %a8
  %v1426 = fadd double %v1425, %a9
  %v1427 = fmul double %v1421, %v1421
  %v1428 = fmul double %v1419, %v1419
  %v1429 = fmul double %v1426, %v1426
  %v1430 = fmul double %v1424, %v1424
  %v1431 = ptrtoint ptr %a13 to i64
  %v1432 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1433 = and i64 %v1431, %v1432
  %v1434 = and i64 %v1433, 1
  %v1435 = icmp ne i64 %v1434, 0
  br i1 %v1435, label %yes.1436, label %no.1437
yes.1436:
  %v1439 = sub i64 %v1432, 1
  %v1440 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v1431, i64 %v1439)
  %v1441 = extractvalue { i64, i1 } %v1440, 0
  %v1442 = extractvalue { i64, i1 } %v1440, 1
  br i1 %v1442, label %yes.1443, label %no.1444
yes.1443:
  %v1446 = call ptr @mlf_sub_int(ptr %a13, ptr inttoptr (i64 3 to ptr))
  br label %join.1445
no.1444:
  %v1447 = inttoptr i64 %v1441 to ptr
  br label %join.1445
join.1445:
  %v1448 = phi ptr [ %v1446, %yes.1443 ], [ %v1447, %no.1444 ]
  br label %join.1438
no.1437:
  %v1449 = call ptr @mlf_sub_int(ptr %a13, ptr inttoptr (i64 3 to ptr))
  br label %join.1438
join.1438:
  %v1450 = phi ptr [ %v1448, %join.1445 ], [ %v1449, %no.1437 ]
  %v1451 = musttail call ptr @mlf.numeric.10.dddddddddddppp(double %v1421, double %v1419, double %v1427, double %v1428, double %a4, double %v1426, double %v1424, double %v1429, double %v1430, double %a9, double %a10, ptr %v1370, ptr %v1378, ptr %v1450)
  ret ptr %v1451
tail.no.1386:
  ret ptr inttoptr (i64 1 to ptr)
}

define private ptr @mlf.numeric.10(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6, ptr %a7, ptr %a8, ptr %a9, ptr %a10, ptr %a11, ptr %a12, ptr %a13) alwaysinline {
entry:
  %v1253 = getelementptr i8, ptr %a2, i64 8
  %v1254 = load double, ptr %v1253, align 8, !tbaa !3
  %v1255 = getelementptr i8, ptr %a3, i64 8
  %v1256 = load double, ptr %v1255, align 8, !tbaa !3
  %v1257 = fadd double %v1254, %v1256
  %v1258 = fcmp olt double 0x4010000000000000, %v1257
  %v1259 = select i1 %v1258, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1260 = icmp eq ptr %v1259, inttoptr (i64 6 to ptr)
  br i1 %v1260, label %yes.1261, label %no.1262
yes.1261:
  br label %join.1263
no.1262:
  br label %join.1263
join.1263:
  %v1264 = phi ptr [ inttoptr (i64 2 to ptr), %yes.1261 ], [ %a11, %no.1262 ]
  %v1265 = getelementptr i8, ptr %a7, i64 8
  %v1266 = load double, ptr %v1265, align 8, !tbaa !3
  %v1267 = getelementptr i8, ptr %a8, i64 8
  %v1268 = load double, ptr %v1267, align 8, !tbaa !3
  %v1269 = fadd double %v1266, %v1268
  %v1270 = fcmp olt double 0x4010000000000000, %v1269
  %v1271 = select i1 %v1270, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1272 = icmp eq ptr %v1271, inttoptr (i64 6 to ptr)
  br i1 %v1272, label %yes.1273, label %no.1274
yes.1273:
  br label %join.1275
no.1274:
  br label %join.1275
join.1275:
  %v1276 = phi ptr [ inttoptr (i64 2 to ptr), %yes.1273 ], [ %a12, %no.1274 ]
  %v1277 = icmp eq ptr %v1264, inttoptr (i64 6 to ptr)
  br i1 %v1277, label %yes.1278, label %no.1279
yes.1278:
  br label %join.1280
no.1279:
  br label %join.1280
join.1280:
  %v1281 = phi ptr [ inttoptr (i64 6 to ptr), %yes.1278 ], [ %v1276, %no.1279 ]
  %v1282 = icmp eq ptr %v1281, inttoptr (i64 6 to ptr)
  br i1 %v1282, label %tail.yes.1283, label %tail.no.1284
tail.yes.1283:
  %v1285 = ptrtoint ptr %a13 to i64
  %v1286 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v1287 = and i64 %v1285, %v1286
  %v1288 = and i64 %v1287, 1
  %v1289 = icmp ne i64 %v1288, 0
  br i1 %v1289, label %yes.1290, label %no.1291
yes.1290:
  %v1293 = icmp eq i64 %v1285, %v1286
  %v1294 = select i1 %v1293, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1292
no.1291:
  %v1295 = call ptr @mlf_eq_int(ptr %a13, ptr inttoptr (i64 1 to ptr))
  br label %join.1292
join.1292:
  %v1296 = phi ptr [ %v1294, %yes.1290 ], [ %v1295, %no.1291 ]
  %v1297 = icmp eq ptr %v1296, inttoptr (i64 6 to ptr)
  br i1 %v1297, label %tail.yes.1298, label %tail.no.1299
tail.yes.1298:
  %v1300 = icmp eq ptr %v1264, inttoptr (i64 6 to ptr)
  br i1 %v1300, label %yes.1301, label %no.1302
yes.1301:
  br label %join.1303
no.1302:
  br label %join.1303
join.1303:
  %v1304 = phi ptr [ inttoptr (i64 5 to ptr), %yes.1301 ], [ inttoptr (i64 1 to ptr), %no.1302 ]
  %v1305 = icmp eq ptr %v1276, inttoptr (i64 6 to ptr)
  br i1 %v1305, label %yes.1306, label %no.1307
yes.1306:
  br label %join.1308
no.1307:
  br label %join.1308
join.1308:
  %v1309 = phi ptr [ inttoptr (i64 3 to ptr), %yes.1306 ], [ inttoptr (i64 1 to ptr), %no.1307 ]
  %v1310 = ptrtoint ptr %v1304 to i64
  %v1311 = ptrtoint ptr %v1309 to i64
  %v1312 = sub i64 %v1311, 1
  %v1313 = add nsw i64 %v1310, %v1312
  %v1314 = inttoptr i64 %v1313 to ptr
  ret ptr %v1314
tail.no.1299:
  %v1315 = getelementptr i8, ptr %a0, i64 8
  %v1316 = load double, ptr %v1315, align 8, !tbaa !3
  %v1317 = fmul double 0x4000000000000000, %v1316
  %v1318 = getelementptr i8, ptr %a1, i64 8
  %v1319 = load double, ptr %v1318, align 8, !tbaa !3
  %v1320 = fmul double %v1317, %v1319
  %v1321 = getelementptr i8, ptr %a10, i64 8
  %v1322 = load double, ptr %v1321, align 8, !tbaa !3
  %v1323 = fadd double %v1320, %v1322
  %v1324 = fsub double %v1254, %v1256
  %v1325 = getelementptr i8, ptr %a4, i64 8
  %v1326 = load double, ptr %v1325, align 8, !tbaa !3
  %v1327 = fadd double %v1324, %v1326
  %v1328 = getelementptr i8, ptr %a5, i64 8
  %v1329 = load double, ptr %v1328, align 8, !tbaa !3
  %v1330 = fmul double 0x4000000000000000, %v1329
  %v1331 = getelementptr i8, ptr %a6, i64 8
  %v1332 = load double, ptr %v1331, align 8, !tbaa !3
  %v1333 = fmul double %v1330, %v1332
  %v1334 = fadd double %v1333, %v1322
  %v1335 = fsub double %v1266, %v1268
  %v1336 = getelementptr i8, ptr %a9, i64 8
  %v1337 = load double, ptr %v1336, align 8, !tbaa !3
  %v1338 = fadd double %v1335, %v1337
  %v1339 = fmul double %v1327, %v1327
  %v1340 = fmul double %v1323, %v1323
  %v1341 = fmul double %v1338, %v1338
  %v1342 = fmul double %v1334, %v1334
  %v1343 = ptrtoint ptr %a13 to i64
  %v1344 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1345 = and i64 %v1343, %v1344
  %v1346 = and i64 %v1345, 1
  %v1347 = icmp ne i64 %v1346, 0
  br i1 %v1347, label %yes.1348, label %no.1349
yes.1348:
  %v1351 = sub i64 %v1344, 1
  %v1352 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v1343, i64 %v1351)
  %v1353 = extractvalue { i64, i1 } %v1352, 0
  %v1354 = extractvalue { i64, i1 } %v1352, 1
  br i1 %v1354, label %yes.1355, label %no.1356
yes.1355:
  %v1358 = call ptr @mlf_sub_int(ptr %a13, ptr inttoptr (i64 3 to ptr))
  br label %join.1357
no.1356:
  %v1359 = inttoptr i64 %v1353 to ptr
  br label %join.1357
join.1357:
  %v1360 = phi ptr [ %v1358, %yes.1355 ], [ %v1359, %no.1356 ]
  br label %join.1350
no.1349:
  %v1361 = call ptr @mlf_sub_int(ptr %a13, ptr inttoptr (i64 3 to ptr))
  br label %join.1350
join.1350:
  %v1362 = phi ptr [ %v1360, %join.1357 ], [ %v1361, %no.1349 ]
  %v1452 = call ptr @mlf.numeric.10.dddddddddddppp(double %v1327, double %v1323, double %v1339, double %v1340, double %v1326, double %v1338, double %v1334, double %v1341, double %v1342, double %v1337, double %v1322, ptr %v1264, ptr %v1276, ptr %v1362)
  ret ptr %v1452
tail.no.1284:
  ret ptr inttoptr (i64 1 to ptr)
}

define private ptr @mlf.code.1464(ptr %env, ptr %arg) {
entry:
  %v1465 = getelementptr i8, ptr %env, i64 8
  %v1466 = load ptr, ptr %v1465, align 8, !tbaa !3
  %v1467 = getelementptr i8, ptr %env, i64 16
  %v1468 = load ptr, ptr %v1467, align 8, !tbaa !3
  %v1469 = getelementptr i8, ptr %env, i64 24
  %v1470 = load ptr, ptr %v1469, align 8, !tbaa !3
  %v1471 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1471, align 8, !tbaa !3
  %v1472 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1472, align 8, !tbaa !3
  %v1473 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v1473, align 8, !tbaa !3
  %v1474 = call ptr @mlf_double(double 0x4010000000000000)
  %v1475 = call ptr @mlf.force(ptr %v1466)
  %v1476 = call ptr @mlf.force(ptr %v1468)
  %v1477 = call ptr @mlf_prim2(i64 18, ptr %v1475, ptr %v1476)
  %v1478 = call ptr @mlf_prim2(i64 24, ptr %v1474, ptr %v1477)
  %v1479 = icmp eq ptr %v1478, inttoptr (i64 6 to ptr)
  br i1 %v1479, label %yes.1480, label %no.1481
yes.1480:
  br label %join.1482
no.1481:
  %v1483 = call ptr @mlf.force(ptr %v1470)
  br label %join.1482
join.1482:
  %v1484 = phi ptr [ inttoptr (i64 2 to ptr), %yes.1480 ], [ %v1483, %no.1481 ]
  ret ptr %v1484
}

define private ptr @mlf.code.1507(ptr %env, ptr %arg) {
entry:
  %v1508 = getelementptr i8, ptr %env, i64 8
  %v1509 = load ptr, ptr %v1508, align 8, !tbaa !3
  %v1510 = getelementptr i8, ptr %env, i64 16
  %v1511 = load ptr, ptr %v1510, align 8, !tbaa !3
  %v1512 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1512, align 8, !tbaa !3
  %v1513 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1513, align 8, !tbaa !3
  %v1514 = call ptr @mlf.force(ptr %v1509)
  %v1515 = icmp eq ptr %v1514, inttoptr (i64 6 to ptr)
  br i1 %v1515, label %yes.1516, label %no.1517
yes.1516:
  br label %join.1518
no.1517:
  br label %join.1518
join.1518:
  %v1519 = phi ptr [ inttoptr (i64 5 to ptr), %yes.1516 ], [ inttoptr (i64 1 to ptr), %no.1517 ]
  %v1520 = call ptr @mlf.force(ptr %v1511)
  %v1521 = icmp eq ptr %v1520, inttoptr (i64 6 to ptr)
  br i1 %v1521, label %yes.1522, label %no.1523
yes.1522:
  br label %join.1524
no.1523:
  br label %join.1524
join.1524:
  %v1525 = phi ptr [ inttoptr (i64 3 to ptr), %yes.1522 ], [ inttoptr (i64 1 to ptr), %no.1523 ]
  %v1526 = call ptr @mlf_prim2(i64 8, ptr %v1519, ptr %v1525)
  ret ptr %v1526
}

define private ptr @mlf.code.1543(ptr %env, ptr %arg) {
entry:
  %v1544 = getelementptr i8, ptr %env, i64 8
  %v1545 = load ptr, ptr %v1544, align 8, !tbaa !3
  %v1546 = getelementptr i8, ptr %env, i64 16
  %v1547 = load ptr, ptr %v1546, align 8, !tbaa !3
  %v1548 = getelementptr i8, ptr %env, i64 24
  %v1549 = load ptr, ptr %v1548, align 8, !tbaa !3
  %v1550 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1550, align 8, !tbaa !3
  %v1551 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1551, align 8, !tbaa !3
  %v1552 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v1552, align 8, !tbaa !3
  %v1553 = call ptr @mlf_double(double 0x4000000000000000)
  %v1554 = call ptr @mlf.force(ptr %v1545)
  %v1555 = call ptr @mlf_prim2(i64 20, ptr %v1553, ptr %v1554)
  %v1556 = call ptr @mlf.force(ptr %v1547)
  %v1557 = call ptr @mlf_prim2(i64 20, ptr %v1555, ptr %v1556)
  %v1558 = call ptr @mlf.force(ptr %v1549)
  %v1559 = call ptr @mlf_prim2(i64 18, ptr %v1557, ptr %v1558)
  ret ptr %v1559
}

define private ptr @mlf.code.1566(ptr %env, ptr %arg) {
entry:
  %v1567 = getelementptr i8, ptr %env, i64 8
  %v1568 = load ptr, ptr %v1567, align 8, !tbaa !3
  %v1569 = getelementptr i8, ptr %env, i64 16
  %v1570 = load ptr, ptr %v1569, align 8, !tbaa !3
  %v1571 = getelementptr i8, ptr %env, i64 24
  %v1572 = load ptr, ptr %v1571, align 8, !tbaa !3
  %v1573 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1573, align 8, !tbaa !3
  %v1574 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1574, align 8, !tbaa !3
  %v1575 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v1575, align 8, !tbaa !3
  %v1576 = call ptr @mlf.force(ptr %v1568)
  %v1577 = call ptr @mlf.force(ptr %v1570)
  %v1578 = call ptr @mlf_prim2(i64 19, ptr %v1576, ptr %v1577)
  %v1579 = call ptr @mlf.force(ptr %v1572)
  %v1580 = call ptr @mlf_prim2(i64 18, ptr %v1578, ptr %v1579)
  ret ptr %v1580
}

define private ptr @mlf.code.1589(ptr %env, ptr %arg) {
entry:
  %v1590 = getelementptr i8, ptr %env, i64 8
  %v1591 = load ptr, ptr %v1590, align 8, !tbaa !3
  %v1592 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1592, align 8, !tbaa !3
  %v1593 = call ptr @mlf.force(ptr %v1591)
  %v1594 = call ptr @mlf_prim2(i64 20, ptr %v1593, ptr %v1593)
  ret ptr %v1594
}

define private ptr @mlf.code.1599(ptr %env, ptr %arg) {
entry:
  %v1600 = getelementptr i8, ptr %env, i64 8
  %v1601 = load ptr, ptr %v1600, align 8, !tbaa !3
  %v1602 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1602, align 8, !tbaa !3
  %v1603 = call ptr @mlf.force(ptr %v1601)
  %v1604 = call ptr @mlf_prim2(i64 20, ptr %v1603, ptr %v1603)
  ret ptr %v1604
}

define private ptr @mlf.code.1609(ptr %env, ptr %arg) {
entry:
  %v1610 = getelementptr i8, ptr %env, i64 8
  %v1611 = load ptr, ptr %v1610, align 8, !tbaa !3
  %v1612 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1612, align 8, !tbaa !3
  %v1613 = call ptr @mlf.force(ptr %v1611)
  %v1614 = call ptr @mlf_prim2(i64 9, ptr %v1613, ptr inttoptr (i64 3 to ptr))
  ret ptr %v1614
}

define private ptr @mlf.worker.10(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6, ptr %a7, ptr %a8, ptr %a9, ptr %a10, ptr %a11, ptr %a12, ptr %a13) {
entry:
  %v1455 = call ptr @mlf_double(double 0x4010000000000000)
  %v1456 = call ptr @mlf_prim2(i64 18, ptr %a2, ptr %a3)
  %v1457 = call ptr @mlf_prim2(i64 24, ptr %v1455, ptr %v1456)
  %v1458 = icmp eq ptr %v1457, inttoptr (i64 6 to ptr)
  br i1 %v1458, label %yes.1459, label %no.1460
yes.1459:
  br label %join.1461
no.1460:
  %v1462 = call ptr @mlf.force(ptr %a11)
  br label %join.1461
join.1461:
  %v1463 = phi ptr [ inttoptr (i64 2 to ptr), %yes.1459 ], [ %v1462, %no.1460 ]
  %v1485 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1464, i64 3)
  %v1486 = getelementptr i8, ptr %v1485, i64 16
  %v1487 = load ptr, ptr %v1486, align 8, !tbaa !3
  %v1488 = getelementptr i8, ptr %v1487, i64 8
  store ptr %a7, ptr %v1488, align 8, !tbaa !3
  %v1489 = getelementptr i8, ptr %v1487, i64 16
  store ptr %a8, ptr %v1489, align 8, !tbaa !3
  %v1490 = getelementptr i8, ptr %v1487, i64 24
  store ptr %a12, ptr %v1490, align 8, !tbaa !3
  %v1491 = icmp eq ptr %v1463, inttoptr (i64 6 to ptr)
  br i1 %v1491, label %yes.1492, label %no.1493
yes.1492:
  br label %join.1494
no.1493:
  %v1495 = call ptr @mlf.force(ptr %v1485)
  br label %join.1494
join.1494:
  %v1496 = phi ptr [ inttoptr (i64 6 to ptr), %yes.1492 ], [ %v1495, %no.1493 ]
  %v1497 = icmp eq ptr %v1496, inttoptr (i64 6 to ptr)
  br i1 %v1497, label %yes.1498, label %no.1499
yes.1498:
  %v1501 = call ptr @mlf.force(ptr %a13)
  %v1502 = call ptr @mlf_prim2(i64 10, ptr %v1501, ptr inttoptr (i64 1 to ptr))
  %v1503 = icmp eq ptr %v1502, inttoptr (i64 6 to ptr)
  br i1 %v1503, label %yes.1504, label %no.1505
yes.1504:
  %v1527 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1507, i64 2)
  %v1528 = getelementptr i8, ptr %v1527, i64 16
  %v1529 = load ptr, ptr %v1528, align 8, !tbaa !3
  %v1530 = getelementptr i8, ptr %v1529, i64 8
  store ptr %v1463, ptr %v1530, align 8, !tbaa !3
  %v1531 = getelementptr i8, ptr %v1529, i64 16
  store ptr %v1485, ptr %v1531, align 8, !tbaa !3
  %v1532 = call ptr @mlf_prim1(i64 0, ptr %v1527)
  br label %join.1506
no.1505:
  %v1533 = call ptr @mlf_double(double 0x4000000000000000)
  %v1534 = call ptr @mlf.force(ptr %a0)
  %v1535 = call ptr @mlf_prim2(i64 20, ptr %v1533, ptr %v1534)
  %v1536 = call ptr @mlf.force(ptr %a1)
  %v1537 = call ptr @mlf_prim2(i64 20, ptr %v1535, ptr %v1536)
  %v1538 = call ptr @mlf.force(ptr %a10)
  %v1539 = call ptr @mlf_prim2(i64 18, ptr %v1537, ptr %v1538)
  %v1540 = call ptr @mlf_prim2(i64 19, ptr %a2, ptr %a3)
  %v1541 = call ptr @mlf.force(ptr %a4)
  %v1542 = call ptr @mlf_prim2(i64 18, ptr %v1540, ptr %v1541)
  %v1560 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1543, i64 3)
  %v1561 = getelementptr i8, ptr %v1560, i64 16
  %v1562 = load ptr, ptr %v1561, align 8, !tbaa !3
  %v1563 = getelementptr i8, ptr %v1562, i64 8
  store ptr %a5, ptr %v1563, align 8, !tbaa !3
  %v1564 = getelementptr i8, ptr %v1562, i64 16
  store ptr %a6, ptr %v1564, align 8, !tbaa !3
  %v1565 = getelementptr i8, ptr %v1562, i64 24
  store ptr %v1538, ptr %v1565, align 8, !tbaa !3
  %v1581 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1566, i64 3)
  %v1582 = getelementptr i8, ptr %v1581, i64 16
  %v1583 = load ptr, ptr %v1582, align 8, !tbaa !3
  %v1584 = getelementptr i8, ptr %v1583, i64 8
  store ptr %a7, ptr %v1584, align 8, !tbaa !3
  %v1585 = getelementptr i8, ptr %v1583, i64 16
  store ptr %a8, ptr %v1585, align 8, !tbaa !3
  %v1586 = getelementptr i8, ptr %v1583, i64 24
  store ptr %a9, ptr %v1586, align 8, !tbaa !3
  %v1587 = call ptr @mlf_prim2(i64 20, ptr %v1542, ptr %v1542)
  %v1588 = call ptr @mlf_prim2(i64 20, ptr %v1539, ptr %v1539)
  %v1595 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1589, i64 1)
  %v1596 = getelementptr i8, ptr %v1595, i64 16
  %v1597 = load ptr, ptr %v1596, align 8, !tbaa !3
  %v1598 = getelementptr i8, ptr %v1597, i64 8
  store ptr %v1581, ptr %v1598, align 8, !tbaa !3
  %v1605 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1599, i64 1)
  %v1606 = getelementptr i8, ptr %v1605, i64 16
  %v1607 = load ptr, ptr %v1606, align 8, !tbaa !3
  %v1608 = getelementptr i8, ptr %v1607, i64 8
  store ptr %v1560, ptr %v1608, align 8, !tbaa !3
  %v1615 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1609, i64 1)
  %v1616 = getelementptr i8, ptr %v1615, i64 16
  %v1617 = load ptr, ptr %v1616, align 8, !tbaa !3
  %v1618 = getelementptr i8, ptr %v1617, i64 8
  store ptr %v1501, ptr %v1618, align 8, !tbaa !3
  %v1619 = call ptr @mlf_env_new(i64 14)
  %v1620 = getelementptr i8, ptr %v1619, i64 8
  store ptr %v1542, ptr %v1620, align 8, !tbaa !3
  %v1621 = getelementptr i8, ptr %v1619, i64 16
  store ptr %v1539, ptr %v1621, align 8, !tbaa !3
  %v1622 = getelementptr i8, ptr %v1619, i64 24
  store ptr %v1587, ptr %v1622, align 8, !tbaa !3
  %v1623 = getelementptr i8, ptr %v1619, i64 32
  store ptr %v1588, ptr %v1623, align 8, !tbaa !3
  %v1624 = getelementptr i8, ptr %v1619, i64 40
  store ptr %v1541, ptr %v1624, align 8, !tbaa !3
  %v1625 = getelementptr i8, ptr %v1619, i64 48
  store ptr %v1581, ptr %v1625, align 8, !tbaa !3
  %v1626 = getelementptr i8, ptr %v1619, i64 56
  store ptr %v1560, ptr %v1626, align 8, !tbaa !3
  %v1627 = getelementptr i8, ptr %v1619, i64 64
  store ptr %v1595, ptr %v1627, align 8, !tbaa !3
  %v1628 = getelementptr i8, ptr %v1619, i64 72
  store ptr %v1605, ptr %v1628, align 8, !tbaa !3
  %v1629 = getelementptr i8, ptr %v1619, i64 80
  store ptr %a9, ptr %v1629, align 8, !tbaa !3
  %v1630 = getelementptr i8, ptr %v1619, i64 88
  store ptr %v1538, ptr %v1630, align 8, !tbaa !3
  %v1631 = getelementptr i8, ptr %v1619, i64 96
  store ptr %v1463, ptr %v1631, align 8, !tbaa !3
  %v1632 = getelementptr i8, ptr %v1619, i64 104
  store ptr %v1485, ptr %v1632, align 8, !tbaa !3
  %v1633 = getelementptr i8, ptr %v1619, i64 112
  store ptr %v1615, ptr %v1633, align 8, !tbaa !3
  %v1634 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1179, ptr %v1619)
  br label %join.1506
join.1506:
  %v1635 = phi ptr [ %v1532, %yes.1504 ], [ %v1634, %no.1505 ]
  br label %join.1500
no.1499:
  %v1636 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 1 to ptr))
  br label %join.1500
join.1500:
  %v1637 = phi ptr [ %v1635, %join.1506 ], [ %v1636, %no.1499 ]
  ret ptr %v1637
}

define private ptr @mlf.numeric.entry.1179(ptr %env, ptr %arg) {
entry:
  %v1180 = getelementptr i8, ptr %env, i64 8
  %v1181 = load ptr, ptr %v1180, align 8, !tbaa !3
  %v1182 = getelementptr i8, ptr %env, i64 16
  %v1183 = load ptr, ptr %v1182, align 8, !tbaa !3
  %v1184 = getelementptr i8, ptr %env, i64 24
  %v1185 = load ptr, ptr %v1184, align 8, !tbaa !3
  %v1186 = getelementptr i8, ptr %env, i64 32
  %v1187 = load ptr, ptr %v1186, align 8, !tbaa !3
  %v1188 = getelementptr i8, ptr %env, i64 40
  %v1189 = load ptr, ptr %v1188, align 8, !tbaa !3
  %v1190 = getelementptr i8, ptr %env, i64 48
  %v1191 = load ptr, ptr %v1190, align 8, !tbaa !3
  %v1192 = getelementptr i8, ptr %env, i64 56
  %v1193 = load ptr, ptr %v1192, align 8, !tbaa !3
  %v1194 = getelementptr i8, ptr %env, i64 64
  %v1195 = load ptr, ptr %v1194, align 8, !tbaa !3
  %v1196 = getelementptr i8, ptr %env, i64 72
  %v1197 = load ptr, ptr %v1196, align 8, !tbaa !3
  %v1198 = getelementptr i8, ptr %env, i64 80
  %v1199 = load ptr, ptr %v1198, align 8, !tbaa !3
  %v1200 = getelementptr i8, ptr %env, i64 88
  %v1201 = load ptr, ptr %v1200, align 8, !tbaa !3
  %v1202 = getelementptr i8, ptr %env, i64 96
  %v1203 = load ptr, ptr %v1202, align 8, !tbaa !3
  %v1204 = getelementptr i8, ptr %env, i64 104
  %v1205 = load ptr, ptr %v1204, align 8, !tbaa !3
  %v1206 = getelementptr i8, ptr %env, i64 112
  %v1207 = load ptr, ptr %v1206, align 8, !tbaa !3
  %v1208 = call ptr @mlf_peek(ptr %v1181)
  %v1209 = call ptr @mlf_peek(ptr %v1183)
  %v1210 = call ptr @mlf_peek(ptr %v1185)
  %v1211 = call ptr @mlf_peek(ptr %v1187)
  %v1212 = call ptr @mlf_peek(ptr %v1189)
  %v1213 = call ptr @mlf_peek(ptr %v1191)
  %v1214 = call ptr @mlf_peek(ptr %v1193)
  %v1215 = call ptr @mlf_peek(ptr %v1195)
  %v1216 = call ptr @mlf_peek(ptr %v1197)
  %v1217 = call ptr @mlf_peek(ptr %v1199)
  %v1218 = call ptr @mlf_peek(ptr %v1201)
  %v1219 = call ptr @mlf_peek(ptr %v1203)
  %v1220 = call ptr @mlf_peek(ptr %v1205)
  %v1221 = call ptr @mlf_peek(ptr %v1207)
  %v1222 = icmp ne ptr %v1208, null
  %v1223 = icmp ne ptr %v1209, null
  %v1224 = icmp ne ptr %v1210, null
  %v1225 = icmp ne ptr %v1211, null
  %v1226 = icmp ne ptr %v1212, null
  %v1227 = icmp ne ptr %v1213, null
  %v1228 = icmp ne ptr %v1214, null
  %v1229 = icmp ne ptr %v1215, null
  %v1230 = icmp ne ptr %v1216, null
  %v1231 = icmp ne ptr %v1217, null
  %v1232 = icmp ne ptr %v1218, null
  %v1233 = icmp ne ptr %v1219, null
  %v1234 = icmp ne ptr %v1220, null
  %v1235 = icmp ne ptr %v1221, null
  %v1236 = and i1 true, %v1222
  %v1237 = and i1 %v1236, %v1223
  %v1238 = and i1 %v1237, %v1224
  %v1239 = and i1 %v1238, %v1225
  %v1240 = and i1 %v1239, %v1226
  %v1241 = and i1 %v1240, %v1227
  %v1242 = and i1 %v1241, %v1228
  %v1243 = and i1 %v1242, %v1229
  %v1244 = and i1 %v1243, %v1230
  %v1245 = and i1 %v1244, %v1231
  %v1246 = and i1 %v1245, %v1232
  %v1247 = and i1 %v1246, %v1233
  %v1248 = and i1 %v1247, %v1234
  %v1249 = and i1 %v1248, %v1235
  br i1 %v1249, label %yes.1250, label %no.1251
yes.1250:
  %v1453 = call ptr @mlf.numeric.10(ptr %v1208, ptr %v1209, ptr %v1210, ptr %v1211, ptr %v1212, ptr %v1213, ptr %v1214, ptr %v1215, ptr %v1216, ptr %v1217, ptr %v1218, ptr %v1219, ptr %v1220, ptr %v1221)
  %v1454 = call ptr @mlf_prim1(i64 0, ptr %v1453)
  br label %join.1252
no.1251:
  %v1638 = call ptr @mlf.force(ptr %v1185)
  %v1639 = call ptr @mlf.force(ptr %v1187)
  %v1640 = call ptr @mlf.worker.10(ptr %v1181, ptr %v1183, ptr %v1638, ptr %v1639, ptr %v1189, ptr %v1191, ptr %v1193, ptr %v1195, ptr %v1197, ptr %v1199, ptr %v1201, ptr %v1203, ptr %v1205, ptr %v1207)
  br label %join.1252
join.1252:
  %v1641 = phi ptr [ %v1454, %yes.1250 ], [ %v1640, %no.1251 ]
  ret ptr %v1641
}

define private ptr @mlf.code.1169(ptr %env, ptr %arg) {
entry:
  %v1170 = getelementptr i8, ptr %env, i64 8
  %v1171 = load ptr, ptr %v1170, align 8, !tbaa !3
  %v1172 = getelementptr i8, ptr %env, i64 16
  %v1173 = load ptr, ptr %v1172, align 8, !tbaa !3
  %v1174 = getelementptr i8, ptr %env, i64 24
  %v1175 = load ptr, ptr %v1174, align 8, !tbaa !3
  %v1176 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1176, align 8, !tbaa !3
  %v1177 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1177, align 8, !tbaa !3
  %v1178 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v1178, align 8, !tbaa !3
  %v1642 = call ptr @mlf_double(double 0x0000000000000000)
  %v1643 = call ptr @mlf_double(double 0x0000000000000000)
  %v1644 = call ptr @mlf_double(double 0x0000000000000000)
  %v1645 = call ptr @mlf_double(double 0x0000000000000000)
  %v1646 = call ptr @mlf_double(double 0x0000000000000000)
  %v1647 = call ptr @mlf_double(double 0x0000000000000000)
  %v1648 = call ptr @mlf_double(double 0x0000000000000000)
  %v1649 = call ptr @mlf_double(double 0x0000000000000000)
  %v1650 = call ptr @mlf_env_new(i64 14)
  %v1651 = getelementptr i8, ptr %v1650, i64 8
  store ptr %v1642, ptr %v1651, align 8, !tbaa !3
  %v1652 = getelementptr i8, ptr %v1650, i64 16
  store ptr %v1643, ptr %v1652, align 8, !tbaa !3
  %v1653 = getelementptr i8, ptr %v1650, i64 24
  store ptr %v1644, ptr %v1653, align 8, !tbaa !3
  %v1654 = getelementptr i8, ptr %v1650, i64 32
  store ptr %v1645, ptr %v1654, align 8, !tbaa !3
  %v1655 = getelementptr i8, ptr %v1650, i64 40
  store ptr %v1171, ptr %v1655, align 8, !tbaa !3
  %v1656 = getelementptr i8, ptr %v1650, i64 48
  store ptr %v1646, ptr %v1656, align 8, !tbaa !3
  %v1657 = getelementptr i8, ptr %v1650, i64 56
  store ptr %v1647, ptr %v1657, align 8, !tbaa !3
  %v1658 = getelementptr i8, ptr %v1650, i64 64
  store ptr %v1648, ptr %v1658, align 8, !tbaa !3
  %v1659 = getelementptr i8, ptr %v1650, i64 72
  store ptr %v1649, ptr %v1659, align 8, !tbaa !3
  %v1660 = getelementptr i8, ptr %v1650, i64 80
  store ptr %v1175, ptr %v1660, align 8, !tbaa !3
  %v1661 = getelementptr i8, ptr %v1650, i64 88
  store ptr %v1173, ptr %v1661, align 8, !tbaa !3
  %v1662 = getelementptr i8, ptr %v1650, i64 96
  store ptr inttoptr (i64 6 to ptr), ptr %v1662, align 8, !tbaa !3
  %v1663 = getelementptr i8, ptr %v1650, i64 104
  store ptr inttoptr (i64 6 to ptr), ptr %v1663, align 8, !tbaa !3
  %v1664 = getelementptr i8, ptr %v1650, i64 112
  store ptr inttoptr (i64 101 to ptr), ptr %v1664, align 8, !tbaa !3
  %v1665 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1179, ptr %v1650)
  ret ptr %v1665
}

define private ptr @mlf.code.1698(ptr %env, ptr %arg) {
entry:
  %v1699 = getelementptr i8, ptr %env, i64 8
  %v1700 = load ptr, ptr %v1699, align 8, !tbaa !3
  %v1701 = getelementptr i8, ptr %env, i64 16
  %v1702 = load ptr, ptr %v1701, align 8, !tbaa !3
  %v1703 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1703, align 8, !tbaa !3
  %v1704 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1704, align 8, !tbaa !3
  %v1705 = call ptr @mlf.force(ptr %v1700)
  %v1706 = call ptr @mlf_prim2(i64 14, ptr %v1705, ptr inttoptr (i64 9 to ptr))
  %v1707 = call ptr @mlf.force(ptr %v1702)
  %v1708 = call ptr @mlf_prim2(i64 8, ptr %v1706, ptr %v1707)
  ret ptr %v1708
}

define private ptr @mlf.code.1685(ptr %env, ptr %arg) {
entry:
  %v1686 = getelementptr i8, ptr %env, i64 8
  %v1687 = load ptr, ptr %v1686, align 8, !tbaa !3
  %v1688 = getelementptr i8, ptr %env, i64 16
  %v1689 = load ptr, ptr %v1688, align 8, !tbaa !3
  %v1690 = getelementptr i8, ptr %env, i64 24
  %v1691 = load ptr, ptr %v1690, align 8, !tbaa !3
  %v1692 = getelementptr i8, ptr %env, i64 32
  %v1693 = load ptr, ptr %v1692, align 8, !tbaa !3
  %v1694 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1694, align 8, !tbaa !3
  %v1695 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1695, align 8, !tbaa !3
  %v1696 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v1696, align 8, !tbaa !3
  %v1697 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v1697, align 8, !tbaa !3
  %v1709 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1698, i64 2)
  %v1710 = getelementptr i8, ptr %v1709, i64 16
  %v1711 = load ptr, ptr %v1710, align 8, !tbaa !3
  %v1712 = getelementptr i8, ptr %v1711, i64 8
  store ptr %v1691, ptr %v1712, align 8, !tbaa !3
  %v1713 = getelementptr i8, ptr %v1711, i64 16
  store ptr %v1693, ptr %v1713, align 8, !tbaa !3
  %v1714 = call ptr @mlf_prim3(i64 37, ptr %v1687, ptr %v1689, ptr %v1709)
  ret ptr %v1714
}

define private ptr @mlf.code.1722(ptr %env, ptr %arg) {
entry:
  %v1723 = getelementptr i8, ptr %env, i64 8
  %v1724 = load ptr, ptr %v1723, align 8, !tbaa !3
  %v1725 = getelementptr i8, ptr %env, i64 16
  %v1726 = load ptr, ptr %v1725, align 8, !tbaa !3
  %v1727 = getelementptr i8, ptr %env, i64 24
  %v1728 = load ptr, ptr %v1727, align 8, !tbaa !3
  %v1729 = getelementptr i8, ptr %env, i64 32
  %v1730 = load ptr, ptr %v1729, align 8, !tbaa !3
  %v1731 = call ptr @mlf.force(ptr %v1726)
  %v1732 = call ptr @mlf.force(ptr %v1730)
  %v1733 = call ptr @mlf_prim2(i64 8, ptr %v1732, ptr inttoptr (i64 5 to ptr))
  %v1734 = call ptr @mlf_env_new(i64 4)
  %v1735 = getelementptr i8, ptr %v1734, i64 8
  store ptr %v1724, ptr %v1735, align 8, !tbaa !3
  %v1736 = getelementptr i8, ptr %v1734, i64 16
  store ptr %v1731, ptr %v1736, align 8, !tbaa !3
  %v1737 = getelementptr i8, ptr %v1734, i64 24
  store ptr %v1728, ptr %v1737, align 8, !tbaa !3
  %v1738 = getelementptr i8, ptr %v1734, i64 32
  store ptr %v1733, ptr %v1738, align 8, !tbaa !3
  %v1739 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.987, ptr %v1734)
  ret ptr %v1739
}

define private ptr @mlf.code.1672(ptr %env, ptr %arg) {
entry:
  %v1673 = getelementptr i8, ptr %env, i64 8
  %v1674 = load ptr, ptr %v1673, align 8, !tbaa !3
  %v1675 = getelementptr i8, ptr %env, i64 16
  %v1676 = load ptr, ptr %v1675, align 8, !tbaa !3
  %v1677 = getelementptr i8, ptr %env, i64 24
  %v1678 = load ptr, ptr %v1677, align 8, !tbaa !3
  %v1679 = getelementptr i8, ptr %env, i64 32
  %v1680 = load ptr, ptr %v1679, align 8, !tbaa !3
  %v1681 = getelementptr i8, ptr %env, i64 40
  %v1682 = load ptr, ptr %v1681, align 8, !tbaa !3
  %v1683 = getelementptr i8, ptr %env, i64 48
  %v1684 = load ptr, ptr %v1683, align 8, !tbaa !3
  %v1715 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1685, i64 4)
  %v1716 = getelementptr i8, ptr %v1715, i64 16
  %v1717 = load ptr, ptr %v1716, align 8, !tbaa !3
  %v1718 = getelementptr i8, ptr %v1717, i64 8
  store ptr %v1674, ptr %v1718, align 8, !tbaa !3
  %v1719 = getelementptr i8, ptr %v1717, i64 16
  store ptr %v1682, ptr %v1719, align 8, !tbaa !3
  %v1720 = getelementptr i8, ptr %v1717, i64 24
  store ptr %v1684, ptr %v1720, align 8, !tbaa !3
  %v1721 = getelementptr i8, ptr %v1717, i64 32
  store ptr %arg, ptr %v1721, align 8, !tbaa !3
  %v1740 = call ptr @mlf_env_new(i64 4)
  %v1741 = getelementptr i8, ptr %v1740, i64 8
  store ptr %v1674, ptr %v1741, align 8, !tbaa !3
  %v1742 = getelementptr i8, ptr %v1740, i64 16
  store ptr %v1676, ptr %v1742, align 8, !tbaa !3
  %v1743 = getelementptr i8, ptr %v1740, i64 24
  store ptr %v1678, ptr %v1743, align 8, !tbaa !3
  %v1744 = getelementptr i8, ptr %v1740, i64 32
  store ptr %v1680, ptr %v1744, align 8, !tbaa !3
  %v1745 = call ptr @mlf_closure(ptr @mlf.code.1722, ptr %v1740)
  %v1746 = call ptr @mlf_prim2(i64 1, ptr %v1715, ptr %v1745)
  ret ptr %v1746
}

define private ptr @mlf.numeric.0.ddddddp(double %a0, double %a1, double %a2, double %a3, double %a4, double %a5, ptr %a6) alwaysinline {
entry:
  %v1862 = fadd double %a2, %a3
  %v1863 = fcmp olt double 0x4010000000000000, %v1862
  %v1864 = select i1 %v1863, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1865 = icmp eq ptr %v1864, inttoptr (i64 6 to ptr)
  br i1 %v1865, label %tail.yes.1866, label %tail.no.1867
tail.yes.1866:
  ret ptr inttoptr (i64 1 to ptr)
tail.no.1867:
  %v1868 = ptrtoint ptr %a6 to i64
  %v1869 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v1870 = and i64 %v1868, %v1869
  %v1871 = and i64 %v1870, 1
  %v1872 = icmp ne i64 %v1871, 0
  br i1 %v1872, label %yes.1873, label %no.1874
yes.1873:
  %v1876 = icmp eq i64 %v1868, %v1869
  %v1877 = select i1 %v1876, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1875
no.1874:
  %v1878 = call ptr @mlf_eq_int(ptr %a6, ptr inttoptr (i64 1 to ptr))
  br label %join.1875
join.1875:
  %v1879 = phi ptr [ %v1877, %yes.1873 ], [ %v1878, %no.1874 ]
  %v1880 = icmp eq ptr %v1879, inttoptr (i64 6 to ptr)
  br i1 %v1880, label %tail.yes.1881, label %tail.no.1882
tail.yes.1881:
  ret ptr inttoptr (i64 3 to ptr)
tail.no.1882:
  %v1883 = fmul double 0x4000000000000000, %a0
  %v1884 = fmul double %v1883, %a1
  %v1885 = fadd double %v1884, %a5
  %v1886 = fsub double %a2, %a3
  %v1887 = fadd double %v1886, %a4
  %v1888 = fmul double %v1887, %v1887
  %v1889 = fmul double %v1885, %v1885
  %v1890 = ptrtoint ptr %a6 to i64
  %v1891 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1892 = and i64 %v1890, %v1891
  %v1893 = and i64 %v1892, 1
  %v1894 = icmp ne i64 %v1893, 0
  br i1 %v1894, label %yes.1895, label %no.1896
yes.1895:
  %v1898 = sub i64 %v1891, 1
  %v1899 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v1890, i64 %v1898)
  %v1900 = extractvalue { i64, i1 } %v1899, 0
  %v1901 = extractvalue { i64, i1 } %v1899, 1
  br i1 %v1901, label %yes.1902, label %no.1903
yes.1902:
  %v1905 = call ptr @mlf_sub_int(ptr %a6, ptr inttoptr (i64 3 to ptr))
  br label %join.1904
no.1903:
  %v1906 = inttoptr i64 %v1900 to ptr
  br label %join.1904
join.1904:
  %v1907 = phi ptr [ %v1905, %yes.1902 ], [ %v1906, %no.1903 ]
  br label %join.1897
no.1896:
  %v1908 = call ptr @mlf_sub_int(ptr %a6, ptr inttoptr (i64 3 to ptr))
  br label %join.1897
join.1897:
  %v1909 = phi ptr [ %v1907, %join.1904 ], [ %v1908, %no.1896 ]
  %v1910 = musttail call ptr @mlf.numeric.0.ddddddp(double %v1887, double %v1885, double %v1888, double %v1889, double %a4, double %a5, ptr %v1909)
  ret ptr %v1910
}

define private ptr @mlf.numeric.0(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6) alwaysinline {
entry:
  %v1802 = getelementptr i8, ptr %a2, i64 8
  %v1803 = load double, ptr %v1802, align 8, !tbaa !3
  %v1804 = getelementptr i8, ptr %a3, i64 8
  %v1805 = load double, ptr %v1804, align 8, !tbaa !3
  %v1806 = fadd double %v1803, %v1805
  %v1807 = fcmp olt double 0x4010000000000000, %v1806
  %v1808 = select i1 %v1807, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1809 = icmp eq ptr %v1808, inttoptr (i64 6 to ptr)
  br i1 %v1809, label %tail.yes.1810, label %tail.no.1811
tail.yes.1810:
  ret ptr inttoptr (i64 1 to ptr)
tail.no.1811:
  %v1812 = ptrtoint ptr %a6 to i64
  %v1813 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v1814 = and i64 %v1812, %v1813
  %v1815 = and i64 %v1814, 1
  %v1816 = icmp ne i64 %v1815, 0
  br i1 %v1816, label %yes.1817, label %no.1818
yes.1817:
  %v1820 = icmp eq i64 %v1812, %v1813
  %v1821 = select i1 %v1820, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1819
no.1818:
  %v1822 = call ptr @mlf_eq_int(ptr %a6, ptr inttoptr (i64 1 to ptr))
  br label %join.1819
join.1819:
  %v1823 = phi ptr [ %v1821, %yes.1817 ], [ %v1822, %no.1818 ]
  %v1824 = icmp eq ptr %v1823, inttoptr (i64 6 to ptr)
  br i1 %v1824, label %tail.yes.1825, label %tail.no.1826
tail.yes.1825:
  ret ptr inttoptr (i64 3 to ptr)
tail.no.1826:
  %v1827 = getelementptr i8, ptr %a0, i64 8
  %v1828 = load double, ptr %v1827, align 8, !tbaa !3
  %v1829 = fmul double 0x4000000000000000, %v1828
  %v1830 = getelementptr i8, ptr %a1, i64 8
  %v1831 = load double, ptr %v1830, align 8, !tbaa !3
  %v1832 = fmul double %v1829, %v1831
  %v1833 = getelementptr i8, ptr %a5, i64 8
  %v1834 = load double, ptr %v1833, align 8, !tbaa !3
  %v1835 = fadd double %v1832, %v1834
  %v1836 = fsub double %v1803, %v1805
  %v1837 = getelementptr i8, ptr %a4, i64 8
  %v1838 = load double, ptr %v1837, align 8, !tbaa !3
  %v1839 = fadd double %v1836, %v1838
  %v1840 = fmul double %v1839, %v1839
  %v1841 = fmul double %v1835, %v1835
  %v1842 = ptrtoint ptr %a6 to i64
  %v1843 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1844 = and i64 %v1842, %v1843
  %v1845 = and i64 %v1844, 1
  %v1846 = icmp ne i64 %v1845, 0
  br i1 %v1846, label %yes.1847, label %no.1848
yes.1847:
  %v1850 = sub i64 %v1843, 1
  %v1851 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v1842, i64 %v1850)
  %v1852 = extractvalue { i64, i1 } %v1851, 0
  %v1853 = extractvalue { i64, i1 } %v1851, 1
  br i1 %v1853, label %yes.1854, label %no.1855
yes.1854:
  %v1857 = call ptr @mlf_sub_int(ptr %a6, ptr inttoptr (i64 3 to ptr))
  br label %join.1856
no.1855:
  %v1858 = inttoptr i64 %v1852 to ptr
  br label %join.1856
join.1856:
  %v1859 = phi ptr [ %v1857, %yes.1854 ], [ %v1858, %no.1855 ]
  br label %join.1849
no.1848:
  %v1860 = call ptr @mlf_sub_int(ptr %a6, ptr inttoptr (i64 3 to ptr))
  br label %join.1849
join.1849:
  %v1861 = phi ptr [ %v1859, %join.1856 ], [ %v1860, %no.1848 ]
  %v1911 = call ptr @mlf.numeric.0.ddddddp(double %v1839, double %v1835, double %v1840, double %v1841, double %v1838, double %v1834, ptr %v1861)
  ret ptr %v1911
}

define private ptr @mlf.code.1941(ptr %env, ptr %arg) {
entry:
  %v1942 = getelementptr i8, ptr %env, i64 8
  %v1943 = load ptr, ptr %v1942, align 8, !tbaa !3
  %v1944 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1944, align 8, !tbaa !3
  %v1945 = call ptr @mlf.force(ptr %v1943)
  %v1946 = call ptr @mlf_prim2(i64 9, ptr %v1945, ptr inttoptr (i64 3 to ptr))
  ret ptr %v1946
}

define private ptr @mlf.worker.0(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6) {
entry:
  %v1914 = call ptr @mlf_double(double 0x4010000000000000)
  %v1915 = call ptr @mlf_prim2(i64 18, ptr %a2, ptr %a3)
  %v1916 = call ptr @mlf_prim2(i64 24, ptr %v1914, ptr %v1915)
  %v1917 = icmp eq ptr %v1916, inttoptr (i64 6 to ptr)
  br i1 %v1917, label %yes.1918, label %no.1919
yes.1918:
  %v1921 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 1 to ptr))
  br label %join.1920
no.1919:
  %v1922 = call ptr @mlf.force(ptr %a6)
  %v1923 = call ptr @mlf_prim2(i64 10, ptr %v1922, ptr inttoptr (i64 1 to ptr))
  %v1924 = icmp eq ptr %v1923, inttoptr (i64 6 to ptr)
  br i1 %v1924, label %yes.1925, label %no.1926
yes.1925:
  %v1928 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 3 to ptr))
  br label %join.1927
no.1926:
  %v1929 = call ptr @mlf_double(double 0x4000000000000000)
  %v1930 = call ptr @mlf.force(ptr %a0)
  %v1931 = call ptr @mlf_prim2(i64 20, ptr %v1929, ptr %v1930)
  %v1932 = call ptr @mlf.force(ptr %a1)
  %v1933 = call ptr @mlf_prim2(i64 20, ptr %v1931, ptr %v1932)
  %v1934 = call ptr @mlf.force(ptr %a5)
  %v1935 = call ptr @mlf_prim2(i64 18, ptr %v1933, ptr %v1934)
  %v1936 = call ptr @mlf_prim2(i64 19, ptr %a2, ptr %a3)
  %v1937 = call ptr @mlf.force(ptr %a4)
  %v1938 = call ptr @mlf_prim2(i64 18, ptr %v1936, ptr %v1937)
  %v1939 = call ptr @mlf_prim2(i64 20, ptr %v1938, ptr %v1938)
  %v1940 = call ptr @mlf_prim2(i64 20, ptr %v1935, ptr %v1935)
  %v1947 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1941, i64 1)
  %v1948 = getelementptr i8, ptr %v1947, i64 16
  %v1949 = load ptr, ptr %v1948, align 8, !tbaa !3
  %v1950 = getelementptr i8, ptr %v1949, i64 8
  store ptr %v1922, ptr %v1950, align 8, !tbaa !3
  %v1951 = call ptr @mlf_env_new(i64 7)
  %v1952 = getelementptr i8, ptr %v1951, i64 8
  store ptr %v1938, ptr %v1952, align 8, !tbaa !3
  %v1953 = getelementptr i8, ptr %v1951, i64 16
  store ptr %v1935, ptr %v1953, align 8, !tbaa !3
  %v1954 = getelementptr i8, ptr %v1951, i64 24
  store ptr %v1939, ptr %v1954, align 8, !tbaa !3
  %v1955 = getelementptr i8, ptr %v1951, i64 32
  store ptr %v1940, ptr %v1955, align 8, !tbaa !3
  %v1956 = getelementptr i8, ptr %v1951, i64 40
  store ptr %v1937, ptr %v1956, align 8, !tbaa !3
  %v1957 = getelementptr i8, ptr %v1951, i64 48
  store ptr %v1934, ptr %v1957, align 8, !tbaa !3
  %v1958 = getelementptr i8, ptr %v1951, i64 56
  store ptr %v1947, ptr %v1958, align 8, !tbaa !3
  %v1959 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1763, ptr %v1951)
  br label %join.1927
join.1927:
  %v1960 = phi ptr [ %v1928, %yes.1925 ], [ %v1959, %no.1926 ]
  br label %join.1920
join.1920:
  %v1961 = phi ptr [ %v1921, %yes.1918 ], [ %v1960, %join.1927 ]
  ret ptr %v1961
}

define private ptr @mlf.numeric.entry.1763(ptr %env, ptr %arg) {
entry:
  %v1764 = getelementptr i8, ptr %env, i64 8
  %v1765 = load ptr, ptr %v1764, align 8, !tbaa !3
  %v1766 = getelementptr i8, ptr %env, i64 16
  %v1767 = load ptr, ptr %v1766, align 8, !tbaa !3
  %v1768 = getelementptr i8, ptr %env, i64 24
  %v1769 = load ptr, ptr %v1768, align 8, !tbaa !3
  %v1770 = getelementptr i8, ptr %env, i64 32
  %v1771 = load ptr, ptr %v1770, align 8, !tbaa !3
  %v1772 = getelementptr i8, ptr %env, i64 40
  %v1773 = load ptr, ptr %v1772, align 8, !tbaa !3
  %v1774 = getelementptr i8, ptr %env, i64 48
  %v1775 = load ptr, ptr %v1774, align 8, !tbaa !3
  %v1776 = getelementptr i8, ptr %env, i64 56
  %v1777 = load ptr, ptr %v1776, align 8, !tbaa !3
  %v1778 = call ptr @mlf_peek(ptr %v1765)
  %v1779 = call ptr @mlf_peek(ptr %v1767)
  %v1780 = call ptr @mlf_peek(ptr %v1769)
  %v1781 = call ptr @mlf_peek(ptr %v1771)
  %v1782 = call ptr @mlf_peek(ptr %v1773)
  %v1783 = call ptr @mlf_peek(ptr %v1775)
  %v1784 = call ptr @mlf_peek(ptr %v1777)
  %v1785 = icmp ne ptr %v1778, null
  %v1786 = icmp ne ptr %v1779, null
  %v1787 = icmp ne ptr %v1780, null
  %v1788 = icmp ne ptr %v1781, null
  %v1789 = icmp ne ptr %v1782, null
  %v1790 = icmp ne ptr %v1783, null
  %v1791 = icmp ne ptr %v1784, null
  %v1792 = and i1 true, %v1785
  %v1793 = and i1 %v1792, %v1786
  %v1794 = and i1 %v1793, %v1787
  %v1795 = and i1 %v1794, %v1788
  %v1796 = and i1 %v1795, %v1789
  %v1797 = and i1 %v1796, %v1790
  %v1798 = and i1 %v1797, %v1791
  br i1 %v1798, label %yes.1799, label %no.1800
yes.1799:
  %v1912 = call ptr @mlf.numeric.0(ptr %v1778, ptr %v1779, ptr %v1780, ptr %v1781, ptr %v1782, ptr %v1783, ptr %v1784)
  %v1913 = call ptr @mlf_prim1(i64 0, ptr %v1912)
  br label %join.1801
no.1800:
  %v1962 = call ptr @mlf.force(ptr %v1769)
  %v1963 = call ptr @mlf.force(ptr %v1771)
  %v1964 = call ptr @mlf.worker.0(ptr %v1765, ptr %v1767, ptr %v1962, ptr %v1963, ptr %v1773, ptr %v1775, ptr %v1777)
  br label %join.1801
join.1801:
  %v1965 = phi ptr [ %v1913, %yes.1799 ], [ %v1964, %no.1800 ]
  ret ptr %v1965
}

define private ptr @mlf.code.1756(ptr %env, ptr %arg) {
entry:
  %v1757 = getelementptr i8, ptr %env, i64 8
  %v1758 = load ptr, ptr %v1757, align 8, !tbaa !3
  %v1759 = getelementptr i8, ptr %env, i64 16
  %v1760 = load ptr, ptr %v1759, align 8, !tbaa !3
  %v1761 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1761, align 8, !tbaa !3
  %v1762 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1762, align 8, !tbaa !3
  %v1966 = call ptr @mlf_double(double 0x0000000000000000)
  %v1967 = call ptr @mlf_double(double 0x0000000000000000)
  %v1968 = call ptr @mlf_double(double 0x0000000000000000)
  %v1969 = call ptr @mlf_double(double 0x0000000000000000)
  %v1970 = call ptr @mlf_env_new(i64 7)
  %v1971 = getelementptr i8, ptr %v1970, i64 8
  store ptr %v1966, ptr %v1971, align 8, !tbaa !3
  %v1972 = getelementptr i8, ptr %v1970, i64 16
  store ptr %v1967, ptr %v1972, align 8, !tbaa !3
  %v1973 = getelementptr i8, ptr %v1970, i64 24
  store ptr %v1968, ptr %v1973, align 8, !tbaa !3
  %v1974 = getelementptr i8, ptr %v1970, i64 32
  store ptr %v1969, ptr %v1974, align 8, !tbaa !3
  %v1975 = getelementptr i8, ptr %v1970, i64 40
  store ptr %v1758, ptr %v1975, align 8, !tbaa !3
  %v1976 = getelementptr i8, ptr %v1970, i64 48
  store ptr %v1760, ptr %v1976, align 8, !tbaa !3
  %v1977 = getelementptr i8, ptr %v1970, i64 56
  store ptr inttoptr (i64 101 to ptr), ptr %v1977, align 8, !tbaa !3
  %v1978 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1763, ptr %v1970)
  ret ptr %v1978
}

define private ptr @mlf.code.2010(ptr %env, ptr %arg) {
entry:
  %v2011 = getelementptr i8, ptr %env, i64 8
  %v2012 = load ptr, ptr %v2011, align 8, !tbaa !3
  %v2013 = getelementptr i8, ptr %env, i64 16
  %v2014 = load ptr, ptr %v2013, align 8, !tbaa !3
  %v2015 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2015, align 8, !tbaa !3
  %v2016 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2016, align 8, !tbaa !3
  %v2017 = call ptr @mlf.force(ptr %v2012)
  %v2018 = call ptr @mlf_prim2(i64 14, ptr %v2017, ptr inttoptr (i64 5 to ptr))
  %v2019 = call ptr @mlf.force(ptr %v2014)
  %v2020 = call ptr @mlf_prim2(i64 8, ptr %v2018, ptr %v2019)
  ret ptr %v2020
}

define private ptr @mlf.code.1997(ptr %env, ptr %arg) {
entry:
  %v1998 = getelementptr i8, ptr %env, i64 8
  %v1999 = load ptr, ptr %v1998, align 8, !tbaa !3
  %v2000 = getelementptr i8, ptr %env, i64 16
  %v2001 = load ptr, ptr %v2000, align 8, !tbaa !3
  %v2002 = getelementptr i8, ptr %env, i64 24
  %v2003 = load ptr, ptr %v2002, align 8, !tbaa !3
  %v2004 = getelementptr i8, ptr %env, i64 32
  %v2005 = load ptr, ptr %v2004, align 8, !tbaa !3
  %v2006 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2006, align 8, !tbaa !3
  %v2007 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2007, align 8, !tbaa !3
  %v2008 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v2008, align 8, !tbaa !3
  %v2009 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v2009, align 8, !tbaa !3
  %v2021 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2010, i64 2)
  %v2022 = getelementptr i8, ptr %v2021, i64 16
  %v2023 = load ptr, ptr %v2022, align 8, !tbaa !3
  %v2024 = getelementptr i8, ptr %v2023, i64 8
  store ptr %v2003, ptr %v2024, align 8, !tbaa !3
  %v2025 = getelementptr i8, ptr %v2023, i64 16
  store ptr %v2005, ptr %v2025, align 8, !tbaa !3
  %v2026 = call ptr @mlf_prim3(i64 37, ptr %v1999, ptr %v2001, ptr %v2021)
  ret ptr %v2026
}

define private ptr @mlf.code.2034(ptr %env, ptr %arg) {
entry:
  %v2035 = getelementptr i8, ptr %env, i64 8
  %v2036 = load ptr, ptr %v2035, align 8, !tbaa !3
  %v2037 = getelementptr i8, ptr %env, i64 16
  %v2038 = load ptr, ptr %v2037, align 8, !tbaa !3
  %v2039 = getelementptr i8, ptr %env, i64 24
  %v2040 = load ptr, ptr %v2039, align 8, !tbaa !3
  %v2041 = getelementptr i8, ptr %env, i64 32
  %v2042 = load ptr, ptr %v2041, align 8, !tbaa !3
  %v2043 = call ptr @mlf.force(ptr %v2038)
  %v2044 = call ptr @mlf.force(ptr %v2042)
  %v2045 = call ptr @mlf_prim2(i64 8, ptr %v2044, ptr inttoptr (i64 3 to ptr))
  %v2046 = call ptr @mlf_env_new(i64 4)
  %v2047 = getelementptr i8, ptr %v2046, i64 8
  store ptr %v2036, ptr %v2047, align 8, !tbaa !3
  %v2048 = getelementptr i8, ptr %v2046, i64 16
  store ptr %v2043, ptr %v2048, align 8, !tbaa !3
  %v2049 = getelementptr i8, ptr %v2046, i64 24
  store ptr %v2040, ptr %v2049, align 8, !tbaa !3
  %v2050 = getelementptr i8, ptr %v2046, i64 32
  store ptr %v2045, ptr %v2050, align 8, !tbaa !3
  %v2051 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.987, ptr %v2046)
  ret ptr %v2051
}

define private ptr @mlf.code.1984(ptr %env, ptr %arg) {
entry:
  %v1985 = getelementptr i8, ptr %env, i64 8
  %v1986 = load ptr, ptr %v1985, align 8, !tbaa !3
  %v1987 = getelementptr i8, ptr %env, i64 16
  %v1988 = load ptr, ptr %v1987, align 8, !tbaa !3
  %v1989 = getelementptr i8, ptr %env, i64 24
  %v1990 = load ptr, ptr %v1989, align 8, !tbaa !3
  %v1991 = getelementptr i8, ptr %env, i64 32
  %v1992 = load ptr, ptr %v1991, align 8, !tbaa !3
  %v1993 = getelementptr i8, ptr %env, i64 40
  %v1994 = load ptr, ptr %v1993, align 8, !tbaa !3
  %v1995 = getelementptr i8, ptr %env, i64 48
  %v1996 = load ptr, ptr %v1995, align 8, !tbaa !3
  %v2027 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1997, i64 4)
  %v2028 = getelementptr i8, ptr %v2027, i64 16
  %v2029 = load ptr, ptr %v2028, align 8, !tbaa !3
  %v2030 = getelementptr i8, ptr %v2029, i64 8
  store ptr %v1986, ptr %v2030, align 8, !tbaa !3
  %v2031 = getelementptr i8, ptr %v2029, i64 16
  store ptr %v1994, ptr %v2031, align 8, !tbaa !3
  %v2032 = getelementptr i8, ptr %v2029, i64 24
  store ptr %v1996, ptr %v2032, align 8, !tbaa !3
  %v2033 = getelementptr i8, ptr %v2029, i64 32
  store ptr %arg, ptr %v2033, align 8, !tbaa !3
  %v2052 = call ptr @mlf_env_new(i64 4)
  %v2053 = getelementptr i8, ptr %v2052, i64 8
  store ptr %v1986, ptr %v2053, align 8, !tbaa !3
  %v2054 = getelementptr i8, ptr %v2052, i64 16
  store ptr %v1988, ptr %v2054, align 8, !tbaa !3
  %v2055 = getelementptr i8, ptr %v2052, i64 24
  store ptr %v1990, ptr %v2055, align 8, !tbaa !3
  %v2056 = getelementptr i8, ptr %v2052, i64 32
  store ptr %v1992, ptr %v2056, align 8, !tbaa !3
  %v2057 = call ptr @mlf_closure(ptr @mlf.code.2034, ptr %v2052)
  %v2058 = call ptr @mlf_prim2(i64 1, ptr %v2027, ptr %v2057)
  ret ptr %v2058
}

define private ptr @mlf.code.1124(ptr %env, ptr %arg) {
entry:
  %v1125 = getelementptr i8, ptr %env, i64 8
  %v1126 = load ptr, ptr %v1125, align 8, !tbaa !3
  %v1127 = getelementptr i8, ptr %env, i64 16
  %v1128 = load ptr, ptr %v1127, align 8, !tbaa !3
  %v1129 = getelementptr i8, ptr %env, i64 24
  %v1130 = load ptr, ptr %v1129, align 8, !tbaa !3
  %v1131 = getelementptr i8, ptr %env, i64 32
  %v1132 = load ptr, ptr %v1131, align 8, !tbaa !3
  %v1133 = getelementptr i8, ptr %env, i64 40
  %v1134 = load ptr, ptr %v1133, align 8, !tbaa !3
  %v1135 = getelementptr i8, ptr %env, i64 48
  %v1136 = load ptr, ptr %v1135, align 8, !tbaa !3
  %v1137 = getelementptr i8, ptr %env, i64 56
  %v1138 = load ptr, ptr %v1137, align 8, !tbaa !3
  %v1139 = call ptr @mlf.force(ptr %v1132)
  %v1140 = call ptr @mlf_prim2(i64 8, ptr %v1139, ptr inttoptr (i64 3 to ptr))
  %v1141 = call ptr @mlf.force(ptr %v1128)
  %v1142 = call ptr @mlf_prim2(i64 11, ptr %v1140, ptr %v1141)
  %v1143 = icmp eq ptr %v1142, inttoptr (i64 6 to ptr)
  br i1 %v1143, label %yes.1144, label %no.1145
yes.1144:
  %v1164 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1147, i64 2)
  %v1165 = getelementptr i8, ptr %v1164, i64 16
  %v1166 = load ptr, ptr %v1165, align 8, !tbaa !3
  %v1167 = getelementptr i8, ptr %v1166, i64 8
  store ptr %v1141, ptr %v1167, align 8, !tbaa !3
  %v1168 = getelementptr i8, ptr %v1166, i64 16
  store ptr %v1139, ptr %v1168, align 8, !tbaa !3
  %v1666 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1169, i64 3)
  %v1667 = getelementptr i8, ptr %v1666, i64 16
  %v1668 = load ptr, ptr %v1667, align 8, !tbaa !3
  %v1669 = getelementptr i8, ptr %v1668, i64 8
  store ptr %v1134, ptr %v1669, align 8, !tbaa !3
  %v1670 = getelementptr i8, ptr %v1668, i64 16
  store ptr %v1136, ptr %v1670, align 8, !tbaa !3
  %v1671 = getelementptr i8, ptr %v1668, i64 24
  store ptr %v1164, ptr %v1671, align 8, !tbaa !3
  %v1747 = call ptr @mlf_env_new(i64 6)
  %v1748 = getelementptr i8, ptr %v1747, i64 8
  store ptr %v1126, ptr %v1748, align 8, !tbaa !3
  %v1749 = getelementptr i8, ptr %v1747, i64 16
  store ptr %v1141, ptr %v1749, align 8, !tbaa !3
  %v1750 = getelementptr i8, ptr %v1747, i64 24
  store ptr %v1130, ptr %v1750, align 8, !tbaa !3
  %v1751 = getelementptr i8, ptr %v1747, i64 32
  store ptr %v1139, ptr %v1751, align 8, !tbaa !3
  %v1752 = getelementptr i8, ptr %v1747, i64 40
  store ptr %v1138, ptr %v1752, align 8, !tbaa !3
  %v1753 = getelementptr i8, ptr %v1747, i64 48
  store ptr %arg, ptr %v1753, align 8, !tbaa !3
  %v1754 = call ptr @mlf_closure(ptr @mlf.code.1672, ptr %v1747)
  %v1755 = call ptr @mlf_prim2(i64 1, ptr %v1666, ptr %v1754)
  br label %join.1146
no.1145:
  %v1979 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1756, i64 2)
  %v1980 = getelementptr i8, ptr %v1979, i64 16
  %v1981 = load ptr, ptr %v1980, align 8, !tbaa !3
  %v1982 = getelementptr i8, ptr %v1981, i64 8
  store ptr %v1134, ptr %v1982, align 8, !tbaa !3
  %v1983 = getelementptr i8, ptr %v1981, i64 16
  store ptr %v1136, ptr %v1983, align 8, !tbaa !3
  %v2059 = call ptr @mlf_env_new(i64 6)
  %v2060 = getelementptr i8, ptr %v2059, i64 8
  store ptr %v1126, ptr %v2060, align 8, !tbaa !3
  %v2061 = getelementptr i8, ptr %v2059, i64 16
  store ptr %v1141, ptr %v2061, align 8, !tbaa !3
  %v2062 = getelementptr i8, ptr %v2059, i64 24
  store ptr %v1130, ptr %v2062, align 8, !tbaa !3
  %v2063 = getelementptr i8, ptr %v2059, i64 32
  store ptr %v1139, ptr %v2063, align 8, !tbaa !3
  %v2064 = getelementptr i8, ptr %v2059, i64 40
  store ptr %v1138, ptr %v2064, align 8, !tbaa !3
  %v2065 = getelementptr i8, ptr %v2059, i64 48
  store ptr %arg, ptr %v2065, align 8, !tbaa !3
  %v2066 = call ptr @mlf_closure(ptr @mlf.code.1984, ptr %v2059)
  %v2067 = call ptr @mlf_prim2(i64 1, ptr %v1979, ptr %v2066)
  br label %join.1146
join.1146:
  %v2068 = phi ptr [ %v1755, %yes.1144 ], [ %v2067, %no.1145 ]
  ret ptr %v2068
}

define private ptr @mlf.code.1096(ptr %env, ptr %arg) {
entry:
  %v1097 = getelementptr i8, ptr %env, i64 8
  %v1098 = load ptr, ptr %v1097, align 8, !tbaa !3
  %v1099 = getelementptr i8, ptr %env, i64 16
  %v1100 = load ptr, ptr %v1099, align 8, !tbaa !3
  %v1101 = getelementptr i8, ptr %env, i64 24
  %v1102 = load ptr, ptr %v1101, align 8, !tbaa !3
  %v1103 = getelementptr i8, ptr %env, i64 32
  %v1104 = load ptr, ptr %v1103, align 8, !tbaa !3
  %v1105 = getelementptr i8, ptr %env, i64 40
  %v1106 = load ptr, ptr %v1105, align 8, !tbaa !3
  %v1107 = getelementptr i8, ptr %env, i64 48
  %v1108 = load ptr, ptr %v1107, align 8, !tbaa !3
  %v1109 = getelementptr i8, ptr %env, i64 56
  %v1110 = load ptr, ptr %v1109, align 8, !tbaa !3
  %v1119 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1111, i64 2)
  %v1120 = getelementptr i8, ptr %v1119, i64 16
  %v1121 = load ptr, ptr %v1120, align 8, !tbaa !3
  %v1122 = getelementptr i8, ptr %v1121, i64 8
  store ptr %v1098, ptr %v1122, align 8, !tbaa !3
  %v1123 = getelementptr i8, ptr %v1121, i64 16
  store ptr %v1110, ptr %v1123, align 8, !tbaa !3
  %v2069 = call ptr @mlf_env_new(i64 7)
  %v2070 = getelementptr i8, ptr %v2069, i64 8
  store ptr %v1098, ptr %v2070, align 8, !tbaa !3
  %v2071 = getelementptr i8, ptr %v2069, i64 16
  store ptr %v1100, ptr %v2071, align 8, !tbaa !3
  %v2072 = getelementptr i8, ptr %v2069, i64 24
  store ptr %v1102, ptr %v2072, align 8, !tbaa !3
  %v2073 = getelementptr i8, ptr %v2069, i64 32
  store ptr %v1104, ptr %v2073, align 8, !tbaa !3
  %v2074 = getelementptr i8, ptr %v2069, i64 40
  store ptr %v1106, ptr %v2074, align 8, !tbaa !3
  %v2075 = getelementptr i8, ptr %v2069, i64 48
  store ptr %v1108, ptr %v2075, align 8, !tbaa !3
  %v2076 = getelementptr i8, ptr %v2069, i64 56
  store ptr %v1110, ptr %v2076, align 8, !tbaa !3
  %v2077 = call ptr @mlf_closure(ptr @mlf.code.1124, ptr %v2069)
  %v2078 = call ptr @mlf_prim2(i64 1, ptr %v1119, ptr %v2077)
  ret ptr %v2078
}

define private ptr @mlf.code.2116(ptr %env, ptr %arg) {
entry:
  %v2117 = getelementptr i8, ptr %env, i64 8
  %v2118 = load ptr, ptr %v2117, align 8, !tbaa !3
  %v2119 = getelementptr i8, ptr %env, i64 16
  %v2120 = load ptr, ptr %v2119, align 8, !tbaa !3
  %v2121 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2121, align 8, !tbaa !3
  %v2122 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2122, align 8, !tbaa !3
  %v2123 = call ptr @mlf_prim2(i64 36, ptr %v2118, ptr %v2120)
  ret ptr %v2123
}

define private ptr @mlf.code.2146(ptr %env, ptr %arg) {
entry:
  %v2147 = getelementptr i8, ptr %env, i64 8
  %v2148 = load ptr, ptr %v2147, align 8, !tbaa !3
  %v2149 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2149, align 8, !tbaa !3
  %v2150 = call ptr @mlf.force(ptr %v2148)
  %v2151 = call ptr @mlf_prim2(i64 14, ptr %v2150, ptr inttoptr (i64 5 to ptr))
  ret ptr %v2151
}

define private ptr @mlf.code.2136(ptr %env, ptr %arg) {
entry:
  %v2137 = getelementptr i8, ptr %env, i64 8
  %v2138 = load ptr, ptr %v2137, align 8, !tbaa !3
  %v2139 = getelementptr i8, ptr %env, i64 16
  %v2140 = load ptr, ptr %v2139, align 8, !tbaa !3
  %v2141 = getelementptr i8, ptr %env, i64 24
  %v2142 = load ptr, ptr %v2141, align 8, !tbaa !3
  %v2143 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2143, align 8, !tbaa !3
  %v2144 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2144, align 8, !tbaa !3
  %v2145 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v2145, align 8, !tbaa !3
  %v2152 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2146, i64 1)
  %v2153 = getelementptr i8, ptr %v2152, i64 16
  %v2154 = load ptr, ptr %v2153, align 8, !tbaa !3
  %v2155 = getelementptr i8, ptr %v2154, i64 8
  store ptr %v2142, ptr %v2155, align 8, !tbaa !3
  %v2156 = call ptr @mlf_prim3(i64 37, ptr %v2138, ptr %v2140, ptr %v2152)
  ret ptr %v2156
}

define private ptr @mlf.code.2163(ptr %env, ptr %arg) {
entry:
  %v2164 = getelementptr i8, ptr %env, i64 8
  %v2165 = load ptr, ptr %v2164, align 8, !tbaa !3
  %v2166 = getelementptr i8, ptr %env, i64 16
  %v2167 = load ptr, ptr %v2166, align 8, !tbaa !3
  %v2168 = getelementptr i8, ptr %env, i64 24
  %v2169 = load ptr, ptr %v2168, align 8, !tbaa !3
  %v2170 = call ptr @mlf.force(ptr %v2169)
  %v2171 = call ptr @mlf_prim2(i64 9, ptr %v2170, ptr inttoptr (i64 3 to ptr))
  %v2172 = call ptr @mlf_env_new(i64 3)
  %v2173 = getelementptr i8, ptr %v2172, i64 8
  store ptr %v2165, ptr %v2173, align 8, !tbaa !3
  %v2174 = getelementptr i8, ptr %v2172, i64 16
  store ptr %v2167, ptr %v2174, align 8, !tbaa !3
  %v2175 = getelementptr i8, ptr %v2172, i64 24
  store ptr %v2171, ptr %v2175, align 8, !tbaa !3
  %v2176 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2089, ptr %v2172)
  ret ptr %v2176
}

define private ptr @mlf.code.2129(ptr %env, ptr %arg) {
entry:
  %v2130 = getelementptr i8, ptr %env, i64 8
  %v2131 = load ptr, ptr %v2130, align 8, !tbaa !3
  %v2132 = getelementptr i8, ptr %env, i64 16
  %v2133 = load ptr, ptr %v2132, align 8, !tbaa !3
  %v2134 = getelementptr i8, ptr %env, i64 24
  %v2135 = load ptr, ptr %v2134, align 8, !tbaa !3
  %v2157 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2136, i64 3)
  %v2158 = getelementptr i8, ptr %v2157, i64 16
  %v2159 = load ptr, ptr %v2158, align 8, !tbaa !3
  %v2160 = getelementptr i8, ptr %v2159, i64 8
  store ptr %v2131, ptr %v2160, align 8, !tbaa !3
  %v2161 = getelementptr i8, ptr %v2159, i64 16
  store ptr %v2133, ptr %v2161, align 8, !tbaa !3
  %v2162 = getelementptr i8, ptr %v2159, i64 24
  store ptr %arg, ptr %v2162, align 8, !tbaa !3
  %v2177 = call ptr @mlf_env_new(i64 3)
  %v2178 = getelementptr i8, ptr %v2177, i64 8
  store ptr %v2131, ptr %v2178, align 8, !tbaa !3
  %v2179 = getelementptr i8, ptr %v2177, i64 16
  store ptr %v2133, ptr %v2179, align 8, !tbaa !3
  %v2180 = getelementptr i8, ptr %v2177, i64 24
  store ptr %v2135, ptr %v2180, align 8, !tbaa !3
  %v2181 = call ptr @mlf_closure(ptr @mlf.code.2163, ptr %v2177)
  %v2182 = call ptr @mlf_prim2(i64 1, ptr %v2157, ptr %v2181)
  ret ptr %v2182
}

define private ptr @mlf.worker.31(ptr %a0, ptr %a1, ptr %a2) {
entry:
  %v2110 = call ptr @mlf_prim2(i64 10, ptr %a2, ptr inttoptr (i64 1 to ptr))
  %v2111 = icmp eq ptr %v2110, inttoptr (i64 6 to ptr)
  br i1 %v2111, label %yes.2112, label %no.2113
yes.2112:
  %v2115 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.2114
no.2113:
  %v2124 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2116, i64 2)
  %v2125 = getelementptr i8, ptr %v2124, i64 16
  %v2126 = load ptr, ptr %v2125, align 8, !tbaa !3
  %v2127 = getelementptr i8, ptr %v2126, i64 8
  store ptr %a0, ptr %v2127, align 8, !tbaa !3
  %v2128 = getelementptr i8, ptr %v2126, i64 16
  store ptr %a1, ptr %v2128, align 8, !tbaa !3
  %v2183 = call ptr @mlf_env_new(i64 3)
  %v2184 = getelementptr i8, ptr %v2183, i64 8
  store ptr %a0, ptr %v2184, align 8, !tbaa !3
  %v2185 = getelementptr i8, ptr %v2183, i64 16
  store ptr %a1, ptr %v2185, align 8, !tbaa !3
  %v2186 = getelementptr i8, ptr %v2183, i64 24
  store ptr %a2, ptr %v2186, align 8, !tbaa !3
  %v2187 = call ptr @mlf_closure(ptr @mlf.code.2129, ptr %v2183)
  %v2188 = call ptr @mlf_prim2(i64 1, ptr %v2124, ptr %v2187)
  br label %join.2114
join.2114:
  %v2189 = phi ptr [ %v2115, %yes.2112 ], [ %v2188, %no.2113 ]
  ret ptr %v2189
}

define private ptr @mlf.numeric.entry.2089(ptr %env, ptr %arg) {
entry:
  %v2090 = getelementptr i8, ptr %env, i64 8
  %v2091 = load ptr, ptr %v2090, align 8, !tbaa !3
  %v2092 = getelementptr i8, ptr %env, i64 16
  %v2093 = load ptr, ptr %v2092, align 8, !tbaa !3
  %v2094 = getelementptr i8, ptr %env, i64 24
  %v2095 = load ptr, ptr %v2094, align 8, !tbaa !3
  %v2096 = call ptr @mlf_peek(ptr %v2091)
  %v2097 = call ptr @mlf_peek(ptr %v2093)
  %v2098 = call ptr @mlf_peek(ptr %v2095)
  %v2099 = icmp ne ptr %v2096, null
  %v2100 = icmp ne ptr %v2097, null
  %v2101 = icmp ne ptr %v2098, null
  %v2102 = and i1 true, %v2099
  %v2103 = and i1 %v2102, %v2100
  %v2104 = and i1 %v2103, %v2101
  br i1 %v2104, label %yes.2105, label %no.2106
yes.2105:
  %v2108 = call ptr @mlf.numeric.31(ptr %v2096, ptr %v2097, ptr %v2098)
  %v2109 = call ptr @mlf_prim1(i64 0, ptr %v2108)
  br label %join.2107
no.2106:
  %v2190 = call ptr @mlf.force(ptr %v2095)
  %v2191 = call ptr @mlf.worker.31(ptr %v2091, ptr %v2093, ptr %v2190)
  br label %join.2107
join.2107:
  %v2192 = phi ptr [ %v2109, %yes.2105 ], [ %v2191, %no.2106 ]
  ret ptr %v2192
}

define private ptr @mlf.code.2193(ptr %env, ptr %arg) {
entry:
  %v2194 = getelementptr i8, ptr %env, i64 8
  %v2195 = load ptr, ptr %v2194, align 8, !tbaa !3
  %v2196 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2196, align 8, !tbaa !3
  %v2197 = call ptr @mlf.force(ptr %v2195)
  %v2198 = call ptr @mlf_prim2(i64 15, ptr %v2197, ptr inttoptr (i64 17 to ptr))
  ret ptr %v2198
}

define private ptr @mlf.worker.37(ptr %a0, ptr %a1, ptr %a2, ptr %a3) {
entry:
  %v1013 = call ptr @mlf_prim2(i64 11, ptr %a3, ptr %a1)
  %v1014 = icmp eq ptr %v1013, inttoptr (i64 6 to ptr)
  br i1 %v1014, label %yes.1015, label %no.1016
yes.1015:
  %v1034 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1018, i64 2)
  %v1035 = getelementptr i8, ptr %v1034, i64 16
  %v1036 = load ptr, ptr %v1035, align 8, !tbaa !3
  %v1037 = getelementptr i8, ptr %v1036, i64 8
  store ptr %a1, ptr %v1037, align 8, !tbaa !3
  %v1038 = getelementptr i8, ptr %v1036, i64 16
  store ptr %a3, ptr %v1038, align 8, !tbaa !3
  %v1055 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1039, i64 2)
  %v1056 = getelementptr i8, ptr %v1055, i64 16
  %v1057 = load ptr, ptr %v1056, align 8, !tbaa !3
  %v1058 = getelementptr i8, ptr %v1057, i64 8
  store ptr %a1, ptr %v1058, align 8, !tbaa !3
  %v1059 = getelementptr i8, ptr %v1057, i64 16
  store ptr %a2, ptr %v1059, align 8, !tbaa !3
  %v1066 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1060, i64 1)
  %v1067 = getelementptr i8, ptr %v1066, i64 16
  %v1068 = load ptr, ptr %v1067, align 8, !tbaa !3
  %v1069 = getelementptr i8, ptr %v1068, i64 8
  store ptr %a3, ptr %v1069, align 8, !tbaa !3
  %v1090 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1070, i64 3)
  %v1091 = getelementptr i8, ptr %v1090, i64 16
  %v1092 = load ptr, ptr %v1091, align 8, !tbaa !3
  %v1093 = getelementptr i8, ptr %v1092, i64 8
  store ptr %a0, ptr %v1093, align 8, !tbaa !3
  %v1094 = getelementptr i8, ptr %v1092, i64 16
  store ptr %a3, ptr %v1094, align 8, !tbaa !3
  %v1095 = getelementptr i8, ptr %v1092, i64 24
  store ptr %v1066, ptr %v1095, align 8, !tbaa !3
  %v2079 = call ptr @mlf_env_new(i64 7)
  %v2080 = getelementptr i8, ptr %v2079, i64 8
  store ptr %a0, ptr %v2080, align 8, !tbaa !3
  %v2081 = getelementptr i8, ptr %v2079, i64 16
  store ptr %a1, ptr %v2081, align 8, !tbaa !3
  %v2082 = getelementptr i8, ptr %v2079, i64 24
  store ptr %a2, ptr %v2082, align 8, !tbaa !3
  %v2083 = getelementptr i8, ptr %v2079, i64 32
  store ptr %a3, ptr %v2083, align 8, !tbaa !3
  %v2084 = getelementptr i8, ptr %v2079, i64 40
  store ptr %v1034, ptr %v2084, align 8, !tbaa !3
  %v2085 = getelementptr i8, ptr %v2079, i64 48
  store ptr %v1055, ptr %v2085, align 8, !tbaa !3
  %v2086 = getelementptr i8, ptr %v2079, i64 56
  store ptr %v1066, ptr %v2086, align 8, !tbaa !3
  %v2087 = call ptr @mlf_closure(ptr @mlf.code.1096, ptr %v2079)
  %v2088 = call ptr @mlf_prim2(i64 1, ptr %v1090, ptr %v2087)
  br label %join.1017
no.1016:
  %v2199 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2193, i64 1)
  %v2200 = getelementptr i8, ptr %v2199, i64 16
  %v2201 = load ptr, ptr %v2200, align 8, !tbaa !3
  %v2202 = getelementptr i8, ptr %v2201, i64 8
  store ptr %a1, ptr %v2202, align 8, !tbaa !3
  %v2203 = call ptr @mlf_prim2(i64 16, ptr %a1, ptr inttoptr (i64 17 to ptr))
  %v2204 = call ptr @mlf_prim2(i64 10, ptr %v2203, ptr inttoptr (i64 1 to ptr))
  %v2205 = icmp eq ptr %v2204, inttoptr (i64 6 to ptr)
  br i1 %v2205, label %yes.2206, label %no.2207
yes.2206:
  br label %join.2208
no.2207:
  %v2209 = call ptr @mlf_prim2(i64 16, ptr %a1, ptr inttoptr (i64 17 to ptr))
  %v2210 = call ptr @mlf_prim2(i64 9, ptr inttoptr (i64 17 to ptr), ptr %v2209)
  br label %join.2208
join.2208:
  %v2211 = phi ptr [ inttoptr (i64 1 to ptr), %yes.2206 ], [ %v2210, %no.2207 ]
  %v2212 = call ptr @mlf_env_new(i64 3)
  %v2213 = getelementptr i8, ptr %v2212, i64 8
  store ptr %a0, ptr %v2213, align 8, !tbaa !3
  %v2214 = getelementptr i8, ptr %v2212, i64 16
  store ptr %v2199, ptr %v2214, align 8, !tbaa !3
  %v2215 = getelementptr i8, ptr %v2212, i64 24
  store ptr %v2211, ptr %v2215, align 8, !tbaa !3
  %v2216 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2089, ptr %v2212)
  br label %join.1017
join.1017:
  %v2217 = phi ptr [ %v2088, %yes.1015 ], [ %v2216, %join.2208 ]
  ret ptr %v2217
}

define private ptr @mlf.numeric.entry.987(ptr %env, ptr %arg) {
entry:
  %v988 = getelementptr i8, ptr %env, i64 8
  %v989 = load ptr, ptr %v988, align 8, !tbaa !3
  %v990 = getelementptr i8, ptr %env, i64 16
  %v991 = load ptr, ptr %v990, align 8, !tbaa !3
  %v992 = getelementptr i8, ptr %env, i64 24
  %v993 = load ptr, ptr %v992, align 8, !tbaa !3
  %v994 = getelementptr i8, ptr %env, i64 32
  %v995 = load ptr, ptr %v994, align 8, !tbaa !3
  %v996 = call ptr @mlf_peek(ptr %v989)
  %v997 = call ptr @mlf_peek(ptr %v991)
  %v998 = call ptr @mlf_peek(ptr %v993)
  %v999 = call ptr @mlf_peek(ptr %v995)
  %v1000 = icmp ne ptr %v996, null
  %v1001 = icmp ne ptr %v997, null
  %v1002 = icmp ne ptr %v998, null
  %v1003 = icmp ne ptr %v999, null
  %v1004 = and i1 true, %v1000
  %v1005 = and i1 %v1004, %v1001
  %v1006 = and i1 %v1005, %v1002
  %v1007 = and i1 %v1006, %v1003
  br i1 %v1007, label %yes.1008, label %no.1009
yes.1008:
  %v1011 = call ptr @mlf.numeric.37(ptr %v996, ptr %v997, ptr %v998, ptr %v999)
  %v1012 = call ptr @mlf_prim1(i64 0, ptr %v1011)
  br label %join.1010
no.1009:
  %v2218 = call ptr @mlf.force(ptr %v991)
  %v2219 = call ptr @mlf.force(ptr %v995)
  %v2220 = call ptr @mlf.worker.37(ptr %v989, ptr %v2218, ptr %v993, ptr %v2219)
  br label %join.1010
join.1010:
  %v2221 = phi ptr [ %v1012, %yes.1008 ], [ %v2220, %no.1009 ]
  ret ptr %v2221
}

define private ptr @mlf.code.977(ptr %env, ptr %arg) {
entry:
  %v978 = getelementptr i8, ptr %env, i64 8
  %v979 = load ptr, ptr %v978, align 8, !tbaa !3
  %v980 = getelementptr i8, ptr %env, i64 16
  %v981 = load ptr, ptr %v980, align 8, !tbaa !3
  %v982 = getelementptr i8, ptr %env, i64 24
  %v983 = load ptr, ptr %v982, align 8, !tbaa !3
  %v984 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v984, align 8, !tbaa !3
  %v985 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v985, align 8, !tbaa !3
  %v986 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v986, align 8, !tbaa !3
  %v2222 = call ptr @mlf.force(ptr %v981)
  %v2223 = call ptr @mlf_env_new(i64 4)
  %v2224 = getelementptr i8, ptr %v2223, i64 8
  store ptr %v979, ptr %v2224, align 8, !tbaa !3
  %v2225 = getelementptr i8, ptr %v2223, i64 16
  store ptr %v2222, ptr %v2225, align 8, !tbaa !3
  %v2226 = getelementptr i8, ptr %v2223, i64 24
  store ptr %v983, ptr %v2226, align 8, !tbaa !3
  %v2227 = getelementptr i8, ptr %v2223, i64 32
  store ptr inttoptr (i64 1 to ptr), ptr %v2227, align 8, !tbaa !3
  %v2228 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.987, ptr %v2223)
  ret ptr %v2228
}

define private ptr @mlf.code.2249(ptr %env, ptr %arg) {
entry:
  %v2250 = getelementptr i8, ptr %env, i64 8
  %v2251 = load ptr, ptr %v2250, align 8, !tbaa !3
  %v2252 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2252, align 8, !tbaa !3
  %v2253 = call ptr @mlf.force(ptr %v2251)
  %v2254 = call ptr @mlf_prim2(i64 8, ptr %v2253, ptr inttoptr (i64 15 to ptr))
  %v2255 = call ptr @mlf_prim2(i64 15, ptr %v2254, ptr inttoptr (i64 17 to ptr))
  ret ptr %v2255
}

define private ptr @mlf.code.2242(ptr %env, ptr %arg) {
entry:
  %v2243 = getelementptr i8, ptr %env, i64 8
  %v2244 = load ptr, ptr %v2243, align 8, !tbaa !3
  %v2245 = getelementptr i8, ptr %env, i64 16
  %v2246 = load ptr, ptr %v2245, align 8, !tbaa !3
  %v2247 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2247, align 8, !tbaa !3
  %v2248 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2248, align 8, !tbaa !3
  %v2256 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2249, i64 1)
  %v2257 = getelementptr i8, ptr %v2256, i64 16
  %v2258 = load ptr, ptr %v2257, align 8, !tbaa !3
  %v2259 = getelementptr i8, ptr %v2258, i64 8
  store ptr %v2246, ptr %v2259, align 8, !tbaa !3
  %v2260 = call ptr @mlf_prim3(i64 40, ptr %v2244, ptr inttoptr (i64 1 to ptr), ptr %v2256)
  ret ptr %v2260
}

define private ptr @mlf.code.2266(ptr %env, ptr %arg) {
entry:
  %v2267 = getelementptr i8, ptr %env, i64 8
  %v2268 = load ptr, ptr %v2267, align 8, !tbaa !3
  %v2269 = getelementptr i8, ptr %env, i64 16
  %v2270 = load ptr, ptr %v2269, align 8, !tbaa !3
  %v2271 = getelementptr i8, ptr %env, i64 24
  %v2272 = load ptr, ptr %v2271, align 8, !tbaa !3
  %v2273 = call ptr @mlf.force(ptr %v2270)
  %v2274 = call ptr @mlf.force(ptr %v2272)
  %v2275 = call ptr @mlf_prim2(i64 8, ptr %v2274, ptr inttoptr (i64 3 to ptr))
  %v2276 = call ptr @mlf_env_new(i64 3)
  %v2277 = getelementptr i8, ptr %v2276, i64 8
  store ptr %v2268, ptr %v2277, align 8, !tbaa !3
  %v2278 = getelementptr i8, ptr %v2276, i64 16
  store ptr %v2273, ptr %v2278, align 8, !tbaa !3
  %v2279 = getelementptr i8, ptr %v2276, i64 24
  store ptr %v2275, ptr %v2279, align 8, !tbaa !3
  %v2280 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.111, ptr %v2276)
  ret ptr %v2280
}

define private ptr @mlf.code.2235(ptr %env, ptr %arg) {
entry:
  %v2236 = getelementptr i8, ptr %env, i64 8
  %v2237 = load ptr, ptr %v2236, align 8, !tbaa !3
  %v2238 = getelementptr i8, ptr %env, i64 16
  %v2239 = load ptr, ptr %v2238, align 8, !tbaa !3
  %v2240 = getelementptr i8, ptr %env, i64 24
  %v2241 = load ptr, ptr %v2240, align 8, !tbaa !3
  %v2261 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2242, i64 2)
  %v2262 = getelementptr i8, ptr %v2261, i64 16
  %v2263 = load ptr, ptr %v2262, align 8, !tbaa !3
  %v2264 = getelementptr i8, ptr %v2263, i64 8
  store ptr %v2237, ptr %v2264, align 8, !tbaa !3
  %v2265 = getelementptr i8, ptr %v2263, i64 16
  store ptr %v2239, ptr %v2265, align 8, !tbaa !3
  %v2281 = call ptr @mlf_env_new(i64 3)
  %v2282 = getelementptr i8, ptr %v2281, i64 8
  store ptr %v2237, ptr %v2282, align 8, !tbaa !3
  %v2283 = getelementptr i8, ptr %v2281, i64 16
  store ptr %v2239, ptr %v2283, align 8, !tbaa !3
  %v2284 = getelementptr i8, ptr %v2281, i64 24
  store ptr %v2241, ptr %v2284, align 8, !tbaa !3
  %v2285 = call ptr @mlf_closure(ptr @mlf.code.2266, ptr %v2281)
  %v2286 = call ptr @mlf_prim2(i64 1, ptr %v2261, ptr %v2285)
  ret ptr %v2286
}

define private ptr @mlf.worker.52(ptr %a0, ptr %a1, ptr %a2) {
entry:
  %v972 = call ptr @mlf_prim2(i64 11, ptr %a2, ptr %a1)
  %v973 = icmp eq ptr %v972, inttoptr (i64 6 to ptr)
  br i1 %v973, label %yes.974, label %no.975
yes.974:
  %v2229 = call ptr @mlf.allocate.thunk(ptr @mlf.code.977, i64 3)
  %v2230 = getelementptr i8, ptr %v2229, i64 16
  %v2231 = load ptr, ptr %v2230, align 8, !tbaa !3
  %v2232 = getelementptr i8, ptr %v2231, i64 8
  store ptr %a0, ptr %v2232, align 8, !tbaa !3
  %v2233 = getelementptr i8, ptr %v2231, i64 16
  store ptr %a1, ptr %v2233, align 8, !tbaa !3
  %v2234 = getelementptr i8, ptr %v2231, i64 24
  store ptr %a2, ptr %v2234, align 8, !tbaa !3
  %v2287 = call ptr @mlf_env_new(i64 3)
  %v2288 = getelementptr i8, ptr %v2287, i64 8
  store ptr %a0, ptr %v2288, align 8, !tbaa !3
  %v2289 = getelementptr i8, ptr %v2287, i64 16
  store ptr %a1, ptr %v2289, align 8, !tbaa !3
  %v2290 = getelementptr i8, ptr %v2287, i64 24
  store ptr %a2, ptr %v2290, align 8, !tbaa !3
  %v2291 = call ptr @mlf_closure(ptr @mlf.code.2235, ptr %v2287)
  %v2292 = call ptr @mlf_prim2(i64 1, ptr %v2229, ptr %v2291)
  br label %join.976
no.975:
  %v2293 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.976
join.976:
  %v2294 = phi ptr [ %v2292, %yes.974 ], [ %v2293, %no.975 ]
  ret ptr %v2294
}

define private ptr @mlf.numeric.entry.111(ptr %env, ptr %arg) {
entry:
  %v112 = getelementptr i8, ptr %env, i64 8
  %v113 = load ptr, ptr %v112, align 8, !tbaa !3
  %v114 = getelementptr i8, ptr %env, i64 16
  %v115 = load ptr, ptr %v114, align 8, !tbaa !3
  %v116 = getelementptr i8, ptr %env, i64 24
  %v117 = load ptr, ptr %v116, align 8, !tbaa !3
  %v118 = call ptr @mlf_peek(ptr %v113)
  %v119 = call ptr @mlf_peek(ptr %v115)
  %v120 = call ptr @mlf_peek(ptr %v117)
  %v121 = icmp ne ptr %v118, null
  %v122 = icmp ne ptr %v119, null
  %v123 = icmp ne ptr %v120, null
  %v124 = and i1 true, %v121
  %v125 = and i1 %v124, %v122
  %v126 = and i1 %v125, %v123
  br i1 %v126, label %yes.127, label %no.128
yes.127:
  %v970 = call ptr @mlf.numeric.52(ptr %v118, ptr %v119, ptr %v120)
  %v971 = call ptr @mlf_prim1(i64 0, ptr %v970)
  br label %join.129
no.128:
  %v2295 = call ptr @mlf.force(ptr %v115)
  %v2296 = call ptr @mlf.force(ptr %v117)
  %v2297 = call ptr @mlf.worker.52(ptr %v113, ptr %v2295, ptr %v2296)
  br label %join.129
join.129:
  %v2298 = phi ptr [ %v971, %yes.127 ], [ %v2297, %no.128 ]
  ret ptr %v2298
}

define private ptr @mlf.code.106(ptr %env, ptr %arg) {
entry:
  %v107 = getelementptr i8, ptr %env, i64 8
  %v108 = load ptr, ptr %v107, align 8, !tbaa !3
  %v109 = getelementptr i8, ptr %env, i64 16
  %v110 = load ptr, ptr %v109, align 8, !tbaa !3
  %v2299 = call ptr @mlf.force(ptr %v108)
  %v2300 = call ptr @mlf_env_new(i64 3)
  %v2301 = getelementptr i8, ptr %v2300, i64 8
  store ptr %v110, ptr %v2301, align 8, !tbaa !3
  %v2302 = getelementptr i8, ptr %v2300, i64 16
  store ptr %v2299, ptr %v2302, align 8, !tbaa !3
  %v2303 = getelementptr i8, ptr %v2300, i64 24
  store ptr inttoptr (i64 1 to ptr), ptr %v2303, align 8, !tbaa !3
  %v2304 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.111, ptr %v2300)
  ret ptr %v2304
}

define private ptr @mlf.code.78(ptr %env, ptr %arg) {
entry:
  %v79 = getelementptr i8, ptr %env, i64 8
  %v80 = load ptr, ptr %v79, align 8, !tbaa !3
  %v102 = call ptr @mlf.allocate.thunk(ptr @mlf.code.81, i64 1)
  %v103 = getelementptr i8, ptr %v102, i64 16
  %v104 = load ptr, ptr %v103, align 8, !tbaa !3
  %v105 = getelementptr i8, ptr %v104, i64 8
  store ptr %v80, ptr %v105, align 8, !tbaa !3
  %v2305 = call ptr @mlf_env_new(i64 2)
  %v2306 = getelementptr i8, ptr %v2305, i64 8
  store ptr %v80, ptr %v2306, align 8, !tbaa !3
  %v2307 = getelementptr i8, ptr %v2305, i64 16
  store ptr %arg, ptr %v2307, align 8, !tbaa !3
  %v2308 = call ptr @mlf_closure(ptr @mlf.code.106, ptr %v2305)
  %v2309 = call ptr @mlf_prim2(i64 1, ptr %v102, ptr %v2308)
  ret ptr %v2309
}

define private ptr @mlf.code.2(ptr %env, ptr %arg) {
entry:
  %v9 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3, i64 1)
  %v10 = getelementptr i8, ptr %v9, i64 16
  %v11 = load ptr, ptr %v10, align 8, !tbaa !3
  %v12 = getelementptr i8, ptr %v11, i64 8
  store ptr %arg, ptr %v12, align 8, !tbaa !3
  %v74 = call ptr @mlf.allocate.thunk(ptr @mlf.code.13, i64 1)
  %v75 = getelementptr i8, ptr %v74, i64 16
  %v76 = load ptr, ptr %v75, align 8, !tbaa !3
  %v77 = getelementptr i8, ptr %v76, i64 8
  store ptr %v9, ptr %v77, align 8, !tbaa !3
  %v2310 = call ptr @mlf_env_new(i64 1)
  %v2311 = getelementptr i8, ptr %v2310, i64 8
  store ptr %v9, ptr %v2311, align 8, !tbaa !3
  %v2312 = call ptr @mlf_closure(ptr @mlf.code.78, ptr %v2310)
  %v2313 = call ptr @mlf_prim2(i64 1, ptr %v74, ptr %v2312)
  ret ptr %v2313
}

define private ptr @mlf.code.0(ptr %env, ptr %arg) {
entry:
  %v1 = call ptr @mlf_primitive(i64 4)
  %v2314 = call ptr @mlf_closure(ptr @mlf.code.2, ptr null)
  %v2315 = call ptr @mlf_prim2(i64 1, ptr %v1, ptr %v2314)
  ret ptr %v2315
}

declare void @mlf_require_compact_gc_abi()
define ptr @mlf_entry() {
  call void @mlf_require_compact_gc_abi()
  %root = call ptr @mlf.code.0(ptr null, ptr null)
  ret ptr %root
}
define i32 @main(i32 %argc, ptr %argv) {
  call void @mlf_set_args(i32 %argc, ptr %argv)
  %root = call ptr @mlf_entry()
  %status = call i32 @mlf_run(ptr %root, i64 1)
  ret i32 %status
}
