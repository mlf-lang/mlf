; Generated from independently checked xMLF.
source_filename = "emlf"

declare ptr @mlf_thunk_new(ptr, i64)
declare ptr @mlf_execute_st_lazy(ptr)
declare ptr @mlf_st_new_array(ptr, ptr)
declare ptr @mlf_st_read_array(ptr, ptr)
declare ptr @mlf_st_write_array(ptr, ptr, ptr)
declare ptr @mlf_st_length_array(ptr)
declare void @mlf_set_args(i32, ptr)
declare ptr @mlf_env_new(i64)
declare void @mlf_env_set(ptr, i64, ptr)
declare ptr @mlf_env_get(ptr, i64)
declare ptr @mlf_thunk(ptr, ptr)
declare ptr @mlf_closure(ptr, ptr)
declare ptr @mlf_application(ptr, ptr)
declare ptr @mlf_hole()
declare void @mlf_fill(ptr, ptr)
declare ptr @mlf_integer(ptr)
declare ptr @mlf_string(ptr, i64)
declare ptr @mlf_double(double)
declare double @llvm.sqrt.f64(double)
declare double @mlf_int_to_double(ptr)
declare ptr @mlf_read_int_table(ptr, ptr)
declare ptr @mlf_write_int_table(ptr, ptr, ptr)
declare ptr @mlf_add_int_table(ptr, ptr, ptr)
declare void @mlf_roots_enter(ptr, i64, ptr)
declare void @mlf_roots_leave(ptr)
declare void @mlf_gc_check(i64, ptr)
declare ptr @mlf_get_byte_line()
declare ptr @mlf_new_array(i64, ptr, ptr)
declare ptr @mlf_bytes_from_string(ptr)
declare ptr @mlf_put_bytes(ptr, ptr, ptr)
declare ptr @mlf_new_int_table()
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare i8 @mlf_byte(ptr)
declare ptr @mlf_peek(ptr)
declare ptr @mlf_native_io(ptr, ptr)
declare void @mlf_bounds_failure() noreturn
declare ptr @mlf_primitive(i64)
declare ptr @mlf_prim1(i64, ptr)
declare ptr @mlf_prim2(i64, ptr, ptr)
declare i64 @mlf_truth(ptr)
declare ptr @mlf_prim3(i64, ptr, ptr, ptr)
declare ptr @mlf_force(ptr)
declare ptr @mlf_add_int(ptr, ptr)
declare ptr @mlf_sub_int(ptr, ptr)
declare ptr @mlf_eq_int(ptr, ptr)
declare ptr @mlf_lt_int(ptr, ptr)
declare ptr @mlf_constructor(i64, i64)
declare ptr @mlf_constructor1(i64, ptr)
declare ptr @mlf_constructor2(i64, ptr, ptr)
declare ptr @mlf_constructor_fields(i64, ptr)
declare ptr @mlf_constructor_new(i64, i64)
declare ptr @mlf_field(ptr, i64)
declare void @mlf_match_failure() noreturn
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare i32 @mlf_run(ptr, i64)

@mlf_constructor_pending = external global [33 x ptr]
declare ptr @mlf_constructor_allocate(i64, i64)
define private ptr @mlf.allocate.constructor(i64 %identity, i64 %count, i64 %size) alwaysinline {
entry:
  %small = icmp ule i64 %size, 256
  br i1 %small, label %batch, label %slow
batch:
  %index = lshr i64 %size, 3
  %slot = getelementptr [33 x ptr], ptr @mlf_constructor_pending, i64 0, i64 %index
  %value = load ptr, ptr %slot, align 8
  %empty = icmp eq ptr %value, null
  br i1 %empty, label %slow, label %ready
ready:
  %next = load ptr, ptr %value, align 8
  store ptr %next, ptr %slot, align 8
  store i64 0, ptr %value, align 8
  ret ptr %value
slow:
  %allocated = call ptr @mlf_constructor_allocate(i64 %identity, i64 %count)
  ret ptr %allocated
}
define private ptr @mlf.construct.1(i64 %identity, ptr %a) alwaysinline {
entry:
  %value = call ptr @mlf.allocate.constructor(i64 %identity, i64 1, i64 24)
  store i32 12, ptr %value, align 4
  %id = getelementptr i8, ptr %value, i64 8
  store i64 %identity, ptr %id, align 8
  %first = getelementptr i8, ptr %value, i64 16
  store ptr %a, ptr %first, align 8
  ret ptr %value
}
define private ptr @mlf.construct.2(i64 %identity, ptr %a, ptr %b) alwaysinline {
entry:
  %value = call ptr @mlf.allocate.constructor(i64 %identity, i64 2, i64 32)
  store i32 13, ptr %value, align 4
  %id = getelementptr i8, ptr %value, i64 8
  store i64 %identity, ptr %id, align 8
  %first = getelementptr i8, ptr %value, i64 16
  store ptr %a, ptr %first, align 8
  %second = getelementptr i8, ptr %value, i64 24
  store ptr %b, ptr %second, align 8
  ret ptr %value
}
define private ptr @mlf.construct.wide(i64 %identity, i64 %count) alwaysinline {
entry:
  %fields = mul i64 %count, 8
  %size = add i64 %fields, 24
  %value = call ptr @mlf.allocate.constructor(i64 %identity, i64 %count, i64 %size)
  store i32 28, ptr %value, align 4
  %id = getelementptr i8, ptr %value, i64 8
  store i64 %identity, ptr %id, align 8
  %arity = getelementptr i8, ptr %value, i64 16
  store i64 %count, ptr %arity, align 8
  ret ptr %value
}
@mlf_compact_pending = external global [17 x ptr]
define private ptr @mlf.allocate.thunk(ptr %code, i64 %count) alwaysinline {
entry:
  %words = add i64 %count, 4
  %index = lshr i64 %words, 1
  %slot = getelementptr [17 x ptr], ptr @mlf_compact_pending, i64 0, i64 %index
  %value = load ptr, ptr %slot, align 8
  %empty = icmp eq ptr %value, null
  br i1 %empty, label %slow, label %ready
ready:
  %next = load ptr, ptr %value, align 8
  store ptr %next, ptr %slot, align 8
  store i64 3, ptr %value, align 8
  %function = getelementptr i8, ptr %value, i64 8
  store ptr %code, ptr %function, align 8
  %environment = getelementptr i8, ptr %value, i64 24
  %capture = getelementptr i8, ptr %value, i64 16
  store ptr %environment, ptr %capture, align 8
  store i64 %count, ptr %environment, align 8
  ret ptr %value
slow:
  %allocated = call ptr @mlf_thunk_new(ptr %code, i64 %count)
  ret ptr %allocated
}
define private ptr @mlf.force(ptr %value) alwaysinline {
entry:
  %null = icmp eq ptr %value, null
  br i1 %null, label %slow, label %test
test:
  %bits = ptrtoint ptr %value to i64
  %kind = and i64 %bits, 7
  %immediate = icmp ne i64 %kind, 0
  br i1 %immediate, label %done, label %tagged
tagged:
  %tag = load i32, ptr %value, align 4
  %ready = icmp uge i32 %tag, 5
  br i1 %ready, label %done, label %deferred
deferred:
  %isthunk = icmp eq i32 %tag, 3
  br i1 %isthunk, label %enter, label %indirect
indirect:
  %forwarded = icmp eq i32 %tag, 2
  br i1 %forwarded, label %next, label %slow
next:
  %slot = getelementptr i8, ptr %value, i64 8
  %p = load ptr, ptr %slot, align 8
  %missing = icmp eq ptr %p, null
  br i1 %missing, label %slow, label %nexttest
nexttest:
  %pbits = ptrtoint ptr %p to i64
  %pkind = and i64 %pbits, 7
  %pimm = icmp ne i64 %pkind, 0
  br i1 %pimm, label %forward, label %ptagged
ptagged:
  %ptag = load i32, ptr %p, align 4
  %pready = icmp uge i32 %ptag, 5
  br i1 %pready, label %forward, label %slow
forward:
  ret ptr %p
done:
  ret ptr %value
enter:
  %code.slot = getelementptr i8, ptr %value, i64 8
  %env.slot = getelementptr i8, ptr %value, i64 16
  %code = load ptr, ptr %code.slot, align 8
  %env = load ptr, ptr %env.slot, align 8
  store i32 1, ptr %value, align 4
  store ptr null, ptr %code.slot, align 8
  store ptr null, ptr %env.slot, align 8
  %returned = call ptr %code(ptr %env, ptr null)
  %canonical = call ptr @mlf_force(ptr %returned)
  store i32 2, ptr %value, align 4
  store ptr %canonical, ptr %code.slot, align 8
  ret ptr %canonical
slow:
  %result = tail call ptr @mlf_force(ptr %value)
  ret ptr %result
}
!0 = !{!"MLF storage"}
!1 = !{!"managed object", !0}
!2 = !{!"array cells", !0}
!3 = !{!1, !1, i64 0}
!4 = !{!2, !2, i64 0}
define private ptr @mlf.code.1(ptr %env, ptr %arg) {
entry:
  %v2 = call ptr @mlf_double(double 0x4010000000000000)
  %v3 = call ptr @mlf_double(double 0x400921fb54442d18)
  %v4 = getelementptr i8, ptr %v2, i64 8
  %v5 = load double, ptr %v4, align 8, !tbaa !3
  %v6 = getelementptr i8, ptr %v3, i64 8
  %v7 = load double, ptr %v6, align 8, !tbaa !3
  %v8 = fmul double %v5, %v7
  %v9 = call ptr @mlf_double(double %v8)
  %v10 = call ptr @mlf_double(double 0x400921fb54442d18)
  %v11 = getelementptr i8, ptr %v9, i64 8
  %v12 = load double, ptr %v11, align 8, !tbaa !3
  %v13 = getelementptr i8, ptr %v10, i64 8
  %v14 = load double, ptr %v13, align 8, !tbaa !3
  %v15 = fmul double %v12, %v14
  %v16 = call ptr @mlf_double(double %v15)
  ret ptr %v16
}

define private ptr @mlf.code.22(ptr %env, ptr %arg) {
entry:
  %v23 = call ptr @mlf_double(double 0x0000000000000000)
  %v24 = call ptr @mlf_prim2(i64 31, ptr inttoptr (i64 71 to ptr), ptr %v23)
  ret ptr %v24
}

define private ptr @mlf.code.45(ptr %env, ptr %arg) {
entry:
  %v46 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v47 = ptrtoint ptr inttoptr (i64 13 to ptr) to i64
  %v48 = and i64 %v46, %v47
  %v49 = and i64 %v48, 1
  %v50 = icmp ne i64 %v49, 0
  br i1 %v50, label %yes.51, label %no.52
yes.51:
  %v54 = sub i64 %v47, 1
  %v55 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v46, i64 %v54)
  %v56 = extractvalue { i64, i1 } %v55, 0
  %v57 = extractvalue { i64, i1 } %v55, 1
  br i1 %v57, label %yes.58, label %no.59
yes.58:
  %v61 = call ptr @mlf_add_int(ptr inttoptr (i64 1 to ptr), ptr inttoptr (i64 13 to ptr))
  br label %join.60
no.59:
  %v62 = inttoptr i64 %v56 to ptr
  br label %join.60
join.60:
  %v63 = phi ptr [ %v61, %yes.58 ], [ %v62, %no.59 ]
  br label %join.53
no.52:
  %v64 = call ptr @mlf_add_int(ptr inttoptr (i64 1 to ptr), ptr inttoptr (i64 13 to ptr))
  br label %join.53
join.53:
  %v65 = phi ptr [ %v63, %join.60 ], [ %v64, %no.52 ]
  ret ptr %v65
}

define private ptr @mlf.code.38(ptr %env, ptr %arg) {
entry:
  %v39 = getelementptr i8, ptr %env, i64 8
  %v40 = load ptr, ptr %v39, align 8, !tbaa !3
  %v41 = getelementptr i8, ptr %env, i64 16
  %v42 = load ptr, ptr %v41, align 8, !tbaa !3
  %v43 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v43, align 8, !tbaa !3
  %v44 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v44, align 8, !tbaa !3
  %v66 = call ptr @mlf_thunk(ptr @mlf.code.45, ptr null)
  %v67 = call ptr @mlf_prim3(i64 33, ptr %v42, ptr %v66, ptr %v40)
  ret ptr %v67
}

define private ptr @mlf.code.82(ptr %env, ptr %arg) {
entry:
  %v83 = ptrtoint ptr inttoptr (i64 15 to ptr) to i64
  %v84 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v85 = and i64 %v83, %v84
  %v86 = and i64 %v85, 1
  %v87 = icmp ne i64 %v86, 0
  br i1 %v87, label %yes.88, label %no.89
yes.88:
  %v91 = sub i64 %v84, 1
  %v92 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v83, i64 %v91)
  %v93 = extractvalue { i64, i1 } %v92, 0
  %v94 = extractvalue { i64, i1 } %v92, 1
  br i1 %v94, label %yes.95, label %no.96
yes.95:
  %v98 = call ptr @mlf_add_int(ptr inttoptr (i64 15 to ptr), ptr inttoptr (i64 1 to ptr))
  br label %join.97
no.96:
  %v99 = inttoptr i64 %v93 to ptr
  br label %join.97
join.97:
  %v100 = phi ptr [ %v98, %yes.95 ], [ %v99, %no.96 ]
  br label %join.90
no.89:
  %v101 = call ptr @mlf_add_int(ptr inttoptr (i64 15 to ptr), ptr inttoptr (i64 1 to ptr))
  br label %join.90
join.90:
  %v102 = phi ptr [ %v100, %join.97 ], [ %v101, %no.89 ]
  ret ptr %v102
}

define private ptr @mlf.code.78(ptr %env, ptr %arg) {
entry:
  %v79 = getelementptr i8, ptr %env, i64 8
  %v80 = load ptr, ptr %v79, align 8, !tbaa !3
  %v81 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v81, align 8, !tbaa !3
  %v103 = call ptr @mlf_thunk(ptr @mlf.code.82, ptr null)
  %v104 = call ptr @mlf_double(double 0x40135da0343cd92c)
  %v105 = call ptr @mlf_prim3(i64 33, ptr %v80, ptr %v103, ptr %v104)
  ret ptr %v105
}

define private ptr @mlf.code.119(ptr %env, ptr %arg) {
entry:
  %v120 = ptrtoint ptr inttoptr (i64 15 to ptr) to i64
  %v121 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v122 = and i64 %v120, %v121
  %v123 = and i64 %v122, 1
  %v124 = icmp ne i64 %v123, 0
  br i1 %v124, label %yes.125, label %no.126
yes.125:
  %v128 = sub i64 %v121, 1
  %v129 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v120, i64 %v128)
  %v130 = extractvalue { i64, i1 } %v129, 0
  %v131 = extractvalue { i64, i1 } %v129, 1
  br i1 %v131, label %yes.132, label %no.133
yes.132:
  %v135 = call ptr @mlf_add_int(ptr inttoptr (i64 15 to ptr), ptr inttoptr (i64 3 to ptr))
  br label %join.134
no.133:
  %v136 = inttoptr i64 %v130 to ptr
  br label %join.134
join.134:
  %v137 = phi ptr [ %v135, %yes.132 ], [ %v136, %no.133 ]
  br label %join.127
no.126:
  %v138 = call ptr @mlf_add_int(ptr inttoptr (i64 15 to ptr), ptr inttoptr (i64 3 to ptr))
  br label %join.127
join.127:
  %v139 = phi ptr [ %v137, %join.134 ], [ %v138, %no.126 ]
  ret ptr %v139
}

define private ptr @mlf.code.115(ptr %env, ptr %arg) {
entry:
  %v116 = getelementptr i8, ptr %env, i64 8
  %v117 = load ptr, ptr %v116, align 8, !tbaa !3
  %v118 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v118, align 8, !tbaa !3
  %v140 = call ptr @mlf_thunk(ptr @mlf.code.119, ptr null)
  %v141 = call ptr @mlf_double(double 0xbff290abc01fdb7c)
  %v142 = call ptr @mlf_prim3(i64 33, ptr %v117, ptr %v140, ptr %v141)
  ret ptr %v142
}

define private ptr @mlf.code.156(ptr %env, ptr %arg) {
entry:
  %v157 = ptrtoint ptr inttoptr (i64 15 to ptr) to i64
  %v158 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v159 = and i64 %v157, %v158
  %v160 = and i64 %v159, 1
  %v161 = icmp ne i64 %v160, 0
  br i1 %v161, label %yes.162, label %no.163
yes.162:
  %v165 = sub i64 %v158, 1
  %v166 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v157, i64 %v165)
  %v167 = extractvalue { i64, i1 } %v166, 0
  %v168 = extractvalue { i64, i1 } %v166, 1
  br i1 %v168, label %yes.169, label %no.170
yes.169:
  %v172 = call ptr @mlf_add_int(ptr inttoptr (i64 15 to ptr), ptr inttoptr (i64 5 to ptr))
  br label %join.171
no.170:
  %v173 = inttoptr i64 %v167 to ptr
  br label %join.171
join.171:
  %v174 = phi ptr [ %v172, %yes.169 ], [ %v173, %no.170 ]
  br label %join.164
no.163:
  %v175 = call ptr @mlf_add_int(ptr inttoptr (i64 15 to ptr), ptr inttoptr (i64 5 to ptr))
  br label %join.164
join.164:
  %v176 = phi ptr [ %v174, %join.171 ], [ %v175, %no.163 ]
  ret ptr %v176
}

define private ptr @mlf.code.152(ptr %env, ptr %arg) {
entry:
  %v153 = getelementptr i8, ptr %env, i64 8
  %v154 = load ptr, ptr %v153, align 8, !tbaa !3
  %v155 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v155, align 8, !tbaa !3
  %v177 = call ptr @mlf_thunk(ptr @mlf.code.156, ptr null)
  %v178 = call ptr @mlf_double(double 0xbfba86f96c25ebf0)
  %v179 = call ptr @mlf_prim3(i64 33, ptr %v154, ptr %v177, ptr %v178)
  ret ptr %v179
}

define private ptr @mlf.code.193(ptr %env, ptr %arg) {
entry:
  %v194 = call ptr @mlf_double(double 0x3f5b32ddb8ec9209)
  %v195 = call ptr @mlf_double(double 0x4076d3d70a3d70a4)
  %v196 = getelementptr i8, ptr %v194, i64 8
  %v197 = load double, ptr %v196, align 8, !tbaa !3
  %v198 = getelementptr i8, ptr %v195, i64 8
  %v199 = load double, ptr %v198, align 8, !tbaa !3
  %v200 = fmul double %v197, %v199
  %v201 = call ptr @mlf_double(double %v200)
  ret ptr %v201
}

define private ptr @mlf.code.203(ptr %env, ptr %arg) {
entry:
  %v204 = ptrtoint ptr inttoptr (i64 15 to ptr) to i64
  %v205 = ptrtoint ptr inttoptr (i64 7 to ptr) to i64
  %v206 = and i64 %v204, %v205
  %v207 = and i64 %v206, 1
  %v208 = icmp ne i64 %v207, 0
  br i1 %v208, label %yes.209, label %no.210
yes.209:
  %v212 = sub i64 %v205, 1
  %v213 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v204, i64 %v212)
  %v214 = extractvalue { i64, i1 } %v213, 0
  %v215 = extractvalue { i64, i1 } %v213, 1
  br i1 %v215, label %yes.216, label %no.217
yes.216:
  %v219 = call ptr @mlf_add_int(ptr inttoptr (i64 15 to ptr), ptr inttoptr (i64 7 to ptr))
  br label %join.218
no.217:
  %v220 = inttoptr i64 %v214 to ptr
  br label %join.218
join.218:
  %v221 = phi ptr [ %v219, %yes.216 ], [ %v220, %no.217 ]
  br label %join.211
no.210:
  %v222 = call ptr @mlf_add_int(ptr inttoptr (i64 15 to ptr), ptr inttoptr (i64 7 to ptr))
  br label %join.211
join.211:
  %v223 = phi ptr [ %v221, %join.218 ], [ %v222, %no.210 ]
  ret ptr %v223
}

define private ptr @mlf.code.189(ptr %env, ptr %arg) {
entry:
  %v190 = getelementptr i8, ptr %env, i64 8
  %v191 = load ptr, ptr %v190, align 8, !tbaa !3
  %v192 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v192, align 8, !tbaa !3
  %v202 = call ptr @mlf_thunk(ptr @mlf.code.193, ptr null)
  %v224 = call ptr @mlf_thunk(ptr @mlf.code.203, ptr null)
  %v225 = call ptr @mlf_prim3(i64 33, ptr %v191, ptr %v224, ptr %v202)
  ret ptr %v225
}

define private ptr @mlf.code.239(ptr %env, ptr %arg) {
entry:
  %v240 = call ptr @mlf_double(double 0x3f7f88ff93f670b6)
  %v241 = call ptr @mlf_double(double 0x4076d3d70a3d70a4)
  %v242 = getelementptr i8, ptr %v240, i64 8
  %v243 = load double, ptr %v242, align 8, !tbaa !3
  %v244 = getelementptr i8, ptr %v241, i64 8
  %v245 = load double, ptr %v244, align 8, !tbaa !3
  %v246 = fmul double %v243, %v245
  %v247 = call ptr @mlf_double(double %v246)
  ret ptr %v247
}

define private ptr @mlf.code.249(ptr %env, ptr %arg) {
entry:
  %v250 = ptrtoint ptr inttoptr (i64 15 to ptr) to i64
  %v251 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v252 = and i64 %v250, %v251
  %v253 = and i64 %v252, 1
  %v254 = icmp ne i64 %v253, 0
  br i1 %v254, label %yes.255, label %no.256
yes.255:
  %v258 = sub i64 %v251, 1
  %v259 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v250, i64 %v258)
  %v260 = extractvalue { i64, i1 } %v259, 0
  %v261 = extractvalue { i64, i1 } %v259, 1
  br i1 %v261, label %yes.262, label %no.263
yes.262:
  %v265 = call ptr @mlf_add_int(ptr inttoptr (i64 15 to ptr), ptr inttoptr (i64 9 to ptr))
  br label %join.264
no.263:
  %v266 = inttoptr i64 %v260 to ptr
  br label %join.264
join.264:
  %v267 = phi ptr [ %v265, %yes.262 ], [ %v266, %no.263 ]
  br label %join.257
no.256:
  %v268 = call ptr @mlf_add_int(ptr inttoptr (i64 15 to ptr), ptr inttoptr (i64 9 to ptr))
  br label %join.257
join.257:
  %v269 = phi ptr [ %v267, %join.264 ], [ %v268, %no.256 ]
  ret ptr %v269
}

define private ptr @mlf.code.235(ptr %env, ptr %arg) {
entry:
  %v236 = getelementptr i8, ptr %env, i64 8
  %v237 = load ptr, ptr %v236, align 8, !tbaa !3
  %v238 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v238, align 8, !tbaa !3
  %v248 = call ptr @mlf_thunk(ptr @mlf.code.239, ptr null)
  %v270 = call ptr @mlf_thunk(ptr @mlf.code.249, ptr null)
  %v271 = call ptr @mlf_prim3(i64 33, ptr %v237, ptr %v270, ptr %v248)
  ret ptr %v271
}

define private ptr @mlf.code.285(ptr %env, ptr %arg) {
entry:
  %v286 = call ptr @mlf_double(double 0xbf12199946debd80)
  %v287 = call ptr @mlf_double(double 0x4076d3d70a3d70a4)
  %v288 = getelementptr i8, ptr %v286, i64 8
  %v289 = load double, ptr %v288, align 8, !tbaa !3
  %v290 = getelementptr i8, ptr %v287, i64 8
  %v291 = load double, ptr %v290, align 8, !tbaa !3
  %v292 = fmul double %v289, %v291
  %v293 = call ptr @mlf_double(double %v292)
  ret ptr %v293
}

define private ptr @mlf.code.295(ptr %env, ptr %arg) {
entry:
  %v296 = ptrtoint ptr inttoptr (i64 15 to ptr) to i64
  %v297 = ptrtoint ptr inttoptr (i64 11 to ptr) to i64
  %v298 = and i64 %v296, %v297
  %v299 = and i64 %v298, 1
  %v300 = icmp ne i64 %v299, 0
  br i1 %v300, label %yes.301, label %no.302
yes.301:
  %v304 = sub i64 %v297, 1
  %v305 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v296, i64 %v304)
  %v306 = extractvalue { i64, i1 } %v305, 0
  %v307 = extractvalue { i64, i1 } %v305, 1
  br i1 %v307, label %yes.308, label %no.309
yes.308:
  %v311 = call ptr @mlf_add_int(ptr inttoptr (i64 15 to ptr), ptr inttoptr (i64 11 to ptr))
  br label %join.310
no.309:
  %v312 = inttoptr i64 %v306 to ptr
  br label %join.310
join.310:
  %v313 = phi ptr [ %v311, %yes.308 ], [ %v312, %no.309 ]
  br label %join.303
no.302:
  %v314 = call ptr @mlf_add_int(ptr inttoptr (i64 15 to ptr), ptr inttoptr (i64 11 to ptr))
  br label %join.303
join.303:
  %v315 = phi ptr [ %v313, %join.310 ], [ %v314, %no.302 ]
  ret ptr %v315
}

define private ptr @mlf.code.281(ptr %env, ptr %arg) {
entry:
  %v282 = getelementptr i8, ptr %env, i64 8
  %v283 = load ptr, ptr %v282, align 8, !tbaa !3
  %v284 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v284, align 8, !tbaa !3
  %v294 = call ptr @mlf_thunk(ptr @mlf.code.285, ptr null)
  %v316 = call ptr @mlf_thunk(ptr @mlf.code.295, ptr null)
  %v317 = call ptr @mlf_prim3(i64 33, ptr %v283, ptr %v316, ptr %v294)
  ret ptr %v317
}

define private ptr @mlf.code.334(ptr %env, ptr %arg) {
entry:
  %v335 = getelementptr i8, ptr %env, i64 8
  %v336 = load ptr, ptr %v335, align 8, !tbaa !3
  %v337 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v337, align 8, !tbaa !3
  %v338 = call ptr @mlf_double(double 0x3f4f49601333c135)
  %v339 = call ptr @mlf.force(ptr %v336)
  %v340 = getelementptr i8, ptr %v338, i64 8
  %v341 = load double, ptr %v340, align 8, !tbaa !3
  %v342 = getelementptr i8, ptr %v339, i64 8
  %v343 = load double, ptr %v342, align 8, !tbaa !3
  %v344 = fmul double %v341, %v343
  %v345 = call ptr @mlf_double(double %v344)
  ret ptr %v345
}

define private ptr @mlf.code.350(ptr %env, ptr %arg) {
entry:
  %v351 = ptrtoint ptr inttoptr (i64 15 to ptr) to i64
  %v352 = ptrtoint ptr inttoptr (i64 13 to ptr) to i64
  %v353 = and i64 %v351, %v352
  %v354 = and i64 %v353, 1
  %v355 = icmp ne i64 %v354, 0
  br i1 %v355, label %yes.356, label %no.357
yes.356:
  %v359 = sub i64 %v352, 1
  %v360 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v351, i64 %v359)
  %v361 = extractvalue { i64, i1 } %v360, 0
  %v362 = extractvalue { i64, i1 } %v360, 1
  br i1 %v362, label %yes.363, label %no.364
yes.363:
  %v366 = call ptr @mlf_add_int(ptr inttoptr (i64 15 to ptr), ptr inttoptr (i64 13 to ptr))
  br label %join.365
no.364:
  %v367 = inttoptr i64 %v361 to ptr
  br label %join.365
join.365:
  %v368 = phi ptr [ %v366, %yes.363 ], [ %v367, %no.364 ]
  br label %join.358
no.357:
  %v369 = call ptr @mlf_add_int(ptr inttoptr (i64 15 to ptr), ptr inttoptr (i64 13 to ptr))
  br label %join.358
join.358:
  %v370 = phi ptr [ %v368, %join.365 ], [ %v369, %no.357 ]
  ret ptr %v370
}

define private ptr @mlf.code.327(ptr %env, ptr %arg) {
entry:
  %v328 = getelementptr i8, ptr %env, i64 8
  %v329 = load ptr, ptr %v328, align 8, !tbaa !3
  %v330 = getelementptr i8, ptr %env, i64 16
  %v331 = load ptr, ptr %v330, align 8, !tbaa !3
  %v332 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v332, align 8, !tbaa !3
  %v333 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v333, align 8, !tbaa !3
  %v346 = call ptr @mlf.allocate.thunk(ptr @mlf.code.334, i64 1)
  %v347 = getelementptr i8, ptr %v346, i64 16
  %v348 = load ptr, ptr %v347, align 8, !tbaa !3
  %v349 = getelementptr i8, ptr %v348, i64 8
  store ptr %v329, ptr %v349, align 8, !tbaa !3
  %v371 = call ptr @mlf_thunk(ptr @mlf.code.350, ptr null)
  %v372 = call ptr @mlf_prim3(i64 33, ptr %v331, ptr %v371, ptr %v346)
  ret ptr %v372
}

define private ptr @mlf.code.387(ptr %env, ptr %arg) {
entry:
  %v388 = ptrtoint ptr inttoptr (i64 29 to ptr) to i64
  %v389 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v390 = and i64 %v388, %v389
  %v391 = and i64 %v390, 1
  %v392 = icmp ne i64 %v391, 0
  br i1 %v392, label %yes.393, label %no.394
yes.393:
  %v396 = sub i64 %v389, 1
  %v397 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v388, i64 %v396)
  %v398 = extractvalue { i64, i1 } %v397, 0
  %v399 = extractvalue { i64, i1 } %v397, 1
  br i1 %v399, label %yes.400, label %no.401
yes.400:
  %v403 = call ptr @mlf_add_int(ptr inttoptr (i64 29 to ptr), ptr inttoptr (i64 1 to ptr))
  br label %join.402
no.401:
  %v404 = inttoptr i64 %v398 to ptr
  br label %join.402
join.402:
  %v405 = phi ptr [ %v403, %yes.400 ], [ %v404, %no.401 ]
  br label %join.395
no.394:
  %v406 = call ptr @mlf_add_int(ptr inttoptr (i64 29 to ptr), ptr inttoptr (i64 1 to ptr))
  br label %join.395
join.395:
  %v407 = phi ptr [ %v405, %join.402 ], [ %v406, %no.394 ]
  ret ptr %v407
}

define private ptr @mlf.code.383(ptr %env, ptr %arg) {
entry:
  %v384 = getelementptr i8, ptr %env, i64 8
  %v385 = load ptr, ptr %v384, align 8, !tbaa !3
  %v386 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v386, align 8, !tbaa !3
  %v408 = call ptr @mlf_thunk(ptr @mlf.code.387, ptr null)
  %v409 = call ptr @mlf_double(double 0x4020afcdc332ca67)
  %v410 = call ptr @mlf_prim3(i64 33, ptr %v385, ptr %v408, ptr %v409)
  ret ptr %v410
}

define private ptr @mlf.code.424(ptr %env, ptr %arg) {
entry:
  %v425 = ptrtoint ptr inttoptr (i64 29 to ptr) to i64
  %v426 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v427 = and i64 %v425, %v426
  %v428 = and i64 %v427, 1
  %v429 = icmp ne i64 %v428, 0
  br i1 %v429, label %yes.430, label %no.431
yes.430:
  %v433 = sub i64 %v426, 1
  %v434 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v425, i64 %v433)
  %v435 = extractvalue { i64, i1 } %v434, 0
  %v436 = extractvalue { i64, i1 } %v434, 1
  br i1 %v436, label %yes.437, label %no.438
yes.437:
  %v440 = call ptr @mlf_add_int(ptr inttoptr (i64 29 to ptr), ptr inttoptr (i64 3 to ptr))
  br label %join.439
no.438:
  %v441 = inttoptr i64 %v435 to ptr
  br label %join.439
join.439:
  %v442 = phi ptr [ %v440, %yes.437 ], [ %v441, %no.438 ]
  br label %join.432
no.431:
  %v443 = call ptr @mlf_add_int(ptr inttoptr (i64 29 to ptr), ptr inttoptr (i64 3 to ptr))
  br label %join.432
join.432:
  %v444 = phi ptr [ %v442, %join.439 ], [ %v443, %no.431 ]
  ret ptr %v444
}

define private ptr @mlf.code.420(ptr %env, ptr %arg) {
entry:
  %v421 = getelementptr i8, ptr %env, i64 8
  %v422 = load ptr, ptr %v421, align 8, !tbaa !3
  %v423 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v423, align 8, !tbaa !3
  %v445 = call ptr @mlf_thunk(ptr @mlf.code.424, ptr null)
  %v446 = call ptr @mlf_double(double 0x40107fcb31de01b0)
  %v447 = call ptr @mlf_prim3(i64 33, ptr %v422, ptr %v445, ptr %v446)
  ret ptr %v447
}

define private ptr @mlf.code.461(ptr %env, ptr %arg) {
entry:
  %v462 = ptrtoint ptr inttoptr (i64 29 to ptr) to i64
  %v463 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v464 = and i64 %v462, %v463
  %v465 = and i64 %v464, 1
  %v466 = icmp ne i64 %v465, 0
  br i1 %v466, label %yes.467, label %no.468
yes.467:
  %v470 = sub i64 %v463, 1
  %v471 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v462, i64 %v470)
  %v472 = extractvalue { i64, i1 } %v471, 0
  %v473 = extractvalue { i64, i1 } %v471, 1
  br i1 %v473, label %yes.474, label %no.475
yes.474:
  %v477 = call ptr @mlf_add_int(ptr inttoptr (i64 29 to ptr), ptr inttoptr (i64 5 to ptr))
  br label %join.476
no.475:
  %v478 = inttoptr i64 %v472 to ptr
  br label %join.476
join.476:
  %v479 = phi ptr [ %v477, %yes.474 ], [ %v478, %no.475 ]
  br label %join.469
no.468:
  %v480 = call ptr @mlf_add_int(ptr inttoptr (i64 29 to ptr), ptr inttoptr (i64 5 to ptr))
  br label %join.469
join.469:
  %v481 = phi ptr [ %v479, %join.476 ], [ %v480, %no.468 ]
  ret ptr %v481
}

define private ptr @mlf.code.457(ptr %env, ptr %arg) {
entry:
  %v458 = getelementptr i8, ptr %env, i64 8
  %v459 = load ptr, ptr %v458, align 8, !tbaa !3
  %v460 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v460, align 8, !tbaa !3
  %v482 = call ptr @mlf_thunk(ptr @mlf.code.461, ptr null)
  %v483 = call ptr @mlf_double(double 0xbfd9d353e1eb467c)
  %v484 = call ptr @mlf_prim3(i64 33, ptr %v459, ptr %v482, ptr %v483)
  ret ptr %v484
}

define private ptr @mlf.code.498(ptr %env, ptr %arg) {
entry:
  %v499 = call ptr @mlf_double(double 0xbf66abb60a8e1d76)
  %v500 = call ptr @mlf_double(double 0x4076d3d70a3d70a4)
  %v501 = getelementptr i8, ptr %v499, i64 8
  %v502 = load double, ptr %v501, align 8, !tbaa !3
  %v503 = getelementptr i8, ptr %v500, i64 8
  %v504 = load double, ptr %v503, align 8, !tbaa !3
  %v505 = fmul double %v502, %v504
  %v506 = call ptr @mlf_double(double %v505)
  ret ptr %v506
}

define private ptr @mlf.code.508(ptr %env, ptr %arg) {
entry:
  %v509 = ptrtoint ptr inttoptr (i64 29 to ptr) to i64
  %v510 = ptrtoint ptr inttoptr (i64 7 to ptr) to i64
  %v511 = and i64 %v509, %v510
  %v512 = and i64 %v511, 1
  %v513 = icmp ne i64 %v512, 0
  br i1 %v513, label %yes.514, label %no.515
yes.514:
  %v517 = sub i64 %v510, 1
  %v518 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v509, i64 %v517)
  %v519 = extractvalue { i64, i1 } %v518, 0
  %v520 = extractvalue { i64, i1 } %v518, 1
  br i1 %v520, label %yes.521, label %no.522
yes.521:
  %v524 = call ptr @mlf_add_int(ptr inttoptr (i64 29 to ptr), ptr inttoptr (i64 7 to ptr))
  br label %join.523
no.522:
  %v525 = inttoptr i64 %v519 to ptr
  br label %join.523
join.523:
  %v526 = phi ptr [ %v524, %yes.521 ], [ %v525, %no.522 ]
  br label %join.516
no.515:
  %v527 = call ptr @mlf_add_int(ptr inttoptr (i64 29 to ptr), ptr inttoptr (i64 7 to ptr))
  br label %join.516
join.516:
  %v528 = phi ptr [ %v526, %join.523 ], [ %v527, %no.515 ]
  ret ptr %v528
}

define private ptr @mlf.code.494(ptr %env, ptr %arg) {
entry:
  %v495 = getelementptr i8, ptr %env, i64 8
  %v496 = load ptr, ptr %v495, align 8, !tbaa !3
  %v497 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v497, align 8, !tbaa !3
  %v507 = call ptr @mlf_thunk(ptr @mlf.code.498, ptr null)
  %v529 = call ptr @mlf_thunk(ptr @mlf.code.508, ptr null)
  %v530 = call ptr @mlf_prim3(i64 33, ptr %v496, ptr %v529, ptr %v507)
  ret ptr %v530
}

define private ptr @mlf.code.544(ptr %env, ptr %arg) {
entry:
  %v545 = call ptr @mlf_double(double 0x3f747956257578b8)
  %v546 = call ptr @mlf_double(double 0x4076d3d70a3d70a4)
  %v547 = getelementptr i8, ptr %v545, i64 8
  %v548 = load double, ptr %v547, align 8, !tbaa !3
  %v549 = getelementptr i8, ptr %v546, i64 8
  %v550 = load double, ptr %v549, align 8, !tbaa !3
  %v551 = fmul double %v548, %v550
  %v552 = call ptr @mlf_double(double %v551)
  ret ptr %v552
}

define private ptr @mlf.code.554(ptr %env, ptr %arg) {
entry:
  %v555 = ptrtoint ptr inttoptr (i64 29 to ptr) to i64
  %v556 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v557 = and i64 %v555, %v556
  %v558 = and i64 %v557, 1
  %v559 = icmp ne i64 %v558, 0
  br i1 %v559, label %yes.560, label %no.561
yes.560:
  %v563 = sub i64 %v556, 1
  %v564 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v555, i64 %v563)
  %v565 = extractvalue { i64, i1 } %v564, 0
  %v566 = extractvalue { i64, i1 } %v564, 1
  br i1 %v566, label %yes.567, label %no.568
yes.567:
  %v570 = call ptr @mlf_add_int(ptr inttoptr (i64 29 to ptr), ptr inttoptr (i64 9 to ptr))
  br label %join.569
no.568:
  %v571 = inttoptr i64 %v565 to ptr
  br label %join.569
join.569:
  %v572 = phi ptr [ %v570, %yes.567 ], [ %v571, %no.568 ]
  br label %join.562
no.561:
  %v573 = call ptr @mlf_add_int(ptr inttoptr (i64 29 to ptr), ptr inttoptr (i64 9 to ptr))
  br label %join.562
join.562:
  %v574 = phi ptr [ %v572, %join.569 ], [ %v573, %no.561 ]
  ret ptr %v574
}

define private ptr @mlf.code.540(ptr %env, ptr %arg) {
entry:
  %v541 = getelementptr i8, ptr %env, i64 8
  %v542 = load ptr, ptr %v541, align 8, !tbaa !3
  %v543 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v543, align 8, !tbaa !3
  %v553 = call ptr @mlf_thunk(ptr @mlf.code.544, ptr null)
  %v575 = call ptr @mlf_thunk(ptr @mlf.code.554, ptr null)
  %v576 = call ptr @mlf_prim3(i64 33, ptr %v542, ptr %v575, ptr %v553)
  ret ptr %v576
}

define private ptr @mlf.code.590(ptr %env, ptr %arg) {
entry:
  %v591 = call ptr @mlf_double(double 0x3ef829379cad4ac0)
  %v592 = call ptr @mlf_double(double 0x4076d3d70a3d70a4)
  %v593 = getelementptr i8, ptr %v591, i64 8
  %v594 = load double, ptr %v593, align 8, !tbaa !3
  %v595 = getelementptr i8, ptr %v592, i64 8
  %v596 = load double, ptr %v595, align 8, !tbaa !3
  %v597 = fmul double %v594, %v596
  %v598 = call ptr @mlf_double(double %v597)
  ret ptr %v598
}

define private ptr @mlf.code.600(ptr %env, ptr %arg) {
entry:
  %v601 = ptrtoint ptr inttoptr (i64 29 to ptr) to i64
  %v602 = ptrtoint ptr inttoptr (i64 11 to ptr) to i64
  %v603 = and i64 %v601, %v602
  %v604 = and i64 %v603, 1
  %v605 = icmp ne i64 %v604, 0
  br i1 %v605, label %yes.606, label %no.607
yes.606:
  %v609 = sub i64 %v602, 1
  %v610 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v601, i64 %v609)
  %v611 = extractvalue { i64, i1 } %v610, 0
  %v612 = extractvalue { i64, i1 } %v610, 1
  br i1 %v612, label %yes.613, label %no.614
yes.613:
  %v616 = call ptr @mlf_add_int(ptr inttoptr (i64 29 to ptr), ptr inttoptr (i64 11 to ptr))
  br label %join.615
no.614:
  %v617 = inttoptr i64 %v611 to ptr
  br label %join.615
join.615:
  %v618 = phi ptr [ %v616, %yes.613 ], [ %v617, %no.614 ]
  br label %join.608
no.607:
  %v619 = call ptr @mlf_add_int(ptr inttoptr (i64 29 to ptr), ptr inttoptr (i64 11 to ptr))
  br label %join.608
join.608:
  %v620 = phi ptr [ %v618, %join.615 ], [ %v619, %no.607 ]
  ret ptr %v620
}

define private ptr @mlf.code.586(ptr %env, ptr %arg) {
entry:
  %v587 = getelementptr i8, ptr %env, i64 8
  %v588 = load ptr, ptr %v587, align 8, !tbaa !3
  %v589 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v589, align 8, !tbaa !3
  %v599 = call ptr @mlf_thunk(ptr @mlf.code.590, ptr null)
  %v621 = call ptr @mlf_thunk(ptr @mlf.code.600, ptr null)
  %v622 = call ptr @mlf_prim3(i64 33, ptr %v588, ptr %v621, ptr %v599)
  ret ptr %v622
}

define private ptr @mlf.code.639(ptr %env, ptr %arg) {
entry:
  %v640 = getelementptr i8, ptr %env, i64 8
  %v641 = load ptr, ptr %v640, align 8, !tbaa !3
  %v642 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v642, align 8, !tbaa !3
  %v643 = call ptr @mlf_double(double 0x3f32bc5eeff5e6f8)
  %v644 = call ptr @mlf.force(ptr %v641)
  %v645 = getelementptr i8, ptr %v643, i64 8
  %v646 = load double, ptr %v645, align 8, !tbaa !3
  %v647 = getelementptr i8, ptr %v644, i64 8
  %v648 = load double, ptr %v647, align 8, !tbaa !3
  %v649 = fmul double %v646, %v648
  %v650 = call ptr @mlf_double(double %v649)
  ret ptr %v650
}

define private ptr @mlf.code.655(ptr %env, ptr %arg) {
entry:
  %v656 = ptrtoint ptr inttoptr (i64 29 to ptr) to i64
  %v657 = ptrtoint ptr inttoptr (i64 13 to ptr) to i64
  %v658 = and i64 %v656, %v657
  %v659 = and i64 %v658, 1
  %v660 = icmp ne i64 %v659, 0
  br i1 %v660, label %yes.661, label %no.662
yes.661:
  %v664 = sub i64 %v657, 1
  %v665 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v656, i64 %v664)
  %v666 = extractvalue { i64, i1 } %v665, 0
  %v667 = extractvalue { i64, i1 } %v665, 1
  br i1 %v667, label %yes.668, label %no.669
yes.668:
  %v671 = call ptr @mlf_add_int(ptr inttoptr (i64 29 to ptr), ptr inttoptr (i64 13 to ptr))
  br label %join.670
no.669:
  %v672 = inttoptr i64 %v666 to ptr
  br label %join.670
join.670:
  %v673 = phi ptr [ %v671, %yes.668 ], [ %v672, %no.669 ]
  br label %join.663
no.662:
  %v674 = call ptr @mlf_add_int(ptr inttoptr (i64 29 to ptr), ptr inttoptr (i64 13 to ptr))
  br label %join.663
join.663:
  %v675 = phi ptr [ %v673, %join.670 ], [ %v674, %no.662 ]
  ret ptr %v675
}

define private ptr @mlf.code.632(ptr %env, ptr %arg) {
entry:
  %v633 = getelementptr i8, ptr %env, i64 8
  %v634 = load ptr, ptr %v633, align 8, !tbaa !3
  %v635 = getelementptr i8, ptr %env, i64 16
  %v636 = load ptr, ptr %v635, align 8, !tbaa !3
  %v637 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v637, align 8, !tbaa !3
  %v638 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v638, align 8, !tbaa !3
  %v651 = call ptr @mlf.allocate.thunk(ptr @mlf.code.639, i64 1)
  %v652 = getelementptr i8, ptr %v651, i64 16
  %v653 = load ptr, ptr %v652, align 8, !tbaa !3
  %v654 = getelementptr i8, ptr %v653, i64 8
  store ptr %v634, ptr %v654, align 8, !tbaa !3
  %v676 = call ptr @mlf_thunk(ptr @mlf.code.655, ptr null)
  %v677 = call ptr @mlf_prim3(i64 33, ptr %v636, ptr %v676, ptr %v651)
  ret ptr %v677
}

define private ptr @mlf.code.692(ptr %env, ptr %arg) {
entry:
  %v693 = ptrtoint ptr inttoptr (i64 43 to ptr) to i64
  %v694 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v695 = and i64 %v693, %v694
  %v696 = and i64 %v695, 1
  %v697 = icmp ne i64 %v696, 0
  br i1 %v697, label %yes.698, label %no.699
yes.698:
  %v701 = sub i64 %v694, 1
  %v702 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v693, i64 %v701)
  %v703 = extractvalue { i64, i1 } %v702, 0
  %v704 = extractvalue { i64, i1 } %v702, 1
  br i1 %v704, label %yes.705, label %no.706
yes.705:
  %v708 = call ptr @mlf_add_int(ptr inttoptr (i64 43 to ptr), ptr inttoptr (i64 1 to ptr))
  br label %join.707
no.706:
  %v709 = inttoptr i64 %v703 to ptr
  br label %join.707
join.707:
  %v710 = phi ptr [ %v708, %yes.705 ], [ %v709, %no.706 ]
  br label %join.700
no.699:
  %v711 = call ptr @mlf_add_int(ptr inttoptr (i64 43 to ptr), ptr inttoptr (i64 1 to ptr))
  br label %join.700
join.700:
  %v712 = phi ptr [ %v710, %join.707 ], [ %v711, %no.699 ]
  ret ptr %v712
}

define private ptr @mlf.code.688(ptr %env, ptr %arg) {
entry:
  %v689 = getelementptr i8, ptr %env, i64 8
  %v690 = load ptr, ptr %v689, align 8, !tbaa !3
  %v691 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v691, align 8, !tbaa !3
  %v713 = call ptr @mlf_thunk(ptr @mlf.code.692, ptr null)
  %v714 = call ptr @mlf_double(double 0x4029c9eacea7d9cf)
  %v715 = call ptr @mlf_prim3(i64 33, ptr %v690, ptr %v713, ptr %v714)
  ret ptr %v715
}

define private ptr @mlf.code.729(ptr %env, ptr %arg) {
entry:
  %v730 = ptrtoint ptr inttoptr (i64 43 to ptr) to i64
  %v731 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v732 = and i64 %v730, %v731
  %v733 = and i64 %v732, 1
  %v734 = icmp ne i64 %v733, 0
  br i1 %v734, label %yes.735, label %no.736
yes.735:
  %v738 = sub i64 %v731, 1
  %v739 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v730, i64 %v738)
  %v740 = extractvalue { i64, i1 } %v739, 0
  %v741 = extractvalue { i64, i1 } %v739, 1
  br i1 %v741, label %yes.742, label %no.743
yes.742:
  %v745 = call ptr @mlf_add_int(ptr inttoptr (i64 43 to ptr), ptr inttoptr (i64 3 to ptr))
  br label %join.744
no.743:
  %v746 = inttoptr i64 %v740 to ptr
  br label %join.744
join.744:
  %v747 = phi ptr [ %v745, %yes.742 ], [ %v746, %no.743 ]
  br label %join.737
no.736:
  %v748 = call ptr @mlf_add_int(ptr inttoptr (i64 43 to ptr), ptr inttoptr (i64 3 to ptr))
  br label %join.737
join.737:
  %v749 = phi ptr [ %v747, %join.744 ], [ %v748, %no.736 ]
  ret ptr %v749
}

define private ptr @mlf.code.725(ptr %env, ptr %arg) {
entry:
  %v726 = getelementptr i8, ptr %env, i64 8
  %v727 = load ptr, ptr %v726, align 8, !tbaa !3
  %v728 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v728, align 8, !tbaa !3
  %v750 = call ptr @mlf_thunk(ptr @mlf.code.729, ptr null)
  %v751 = call ptr @mlf_double(double 0xc02e38e8d626667e)
  %v752 = call ptr @mlf_prim3(i64 33, ptr %v727, ptr %v750, ptr %v751)
  ret ptr %v752
}

define private ptr @mlf.code.766(ptr %env, ptr %arg) {
entry:
  %v767 = ptrtoint ptr inttoptr (i64 43 to ptr) to i64
  %v768 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v769 = and i64 %v767, %v768
  %v770 = and i64 %v769, 1
  %v771 = icmp ne i64 %v770, 0
  br i1 %v771, label %yes.772, label %no.773
yes.772:
  %v775 = sub i64 %v768, 1
  %v776 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v767, i64 %v775)
  %v777 = extractvalue { i64, i1 } %v776, 0
  %v778 = extractvalue { i64, i1 } %v776, 1
  br i1 %v778, label %yes.779, label %no.780
yes.779:
  %v782 = call ptr @mlf_add_int(ptr inttoptr (i64 43 to ptr), ptr inttoptr (i64 5 to ptr))
  br label %join.781
no.780:
  %v783 = inttoptr i64 %v777 to ptr
  br label %join.781
join.781:
  %v784 = phi ptr [ %v782, %yes.779 ], [ %v783, %no.780 ]
  br label %join.774
no.773:
  %v785 = call ptr @mlf_add_int(ptr inttoptr (i64 43 to ptr), ptr inttoptr (i64 5 to ptr))
  br label %join.774
join.774:
  %v786 = phi ptr [ %v784, %join.781 ], [ %v785, %no.773 ]
  ret ptr %v786
}

define private ptr @mlf.code.762(ptr %env, ptr %arg) {
entry:
  %v763 = getelementptr i8, ptr %env, i64 8
  %v764 = load ptr, ptr %v763, align 8, !tbaa !3
  %v765 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v765, align 8, !tbaa !3
  %v787 = call ptr @mlf_thunk(ptr @mlf.code.766, ptr null)
  %v788 = call ptr @mlf_double(double 0xbfcc9557be257da0)
  %v789 = call ptr @mlf_prim3(i64 33, ptr %v764, ptr %v787, ptr %v788)
  ret ptr %v789
}

define private ptr @mlf.code.803(ptr %env, ptr %arg) {
entry:
  %v804 = call ptr @mlf_double(double 0x3f6849383e87d954)
  %v805 = call ptr @mlf_double(double 0x4076d3d70a3d70a4)
  %v806 = getelementptr i8, ptr %v804, i64 8
  %v807 = load double, ptr %v806, align 8, !tbaa !3
  %v808 = getelementptr i8, ptr %v805, i64 8
  %v809 = load double, ptr %v808, align 8, !tbaa !3
  %v810 = fmul double %v807, %v809
  %v811 = call ptr @mlf_double(double %v810)
  ret ptr %v811
}

define private ptr @mlf.code.813(ptr %env, ptr %arg) {
entry:
  %v814 = ptrtoint ptr inttoptr (i64 43 to ptr) to i64
  %v815 = ptrtoint ptr inttoptr (i64 7 to ptr) to i64
  %v816 = and i64 %v814, %v815
  %v817 = and i64 %v816, 1
  %v818 = icmp ne i64 %v817, 0
  br i1 %v818, label %yes.819, label %no.820
yes.819:
  %v822 = sub i64 %v815, 1
  %v823 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v814, i64 %v822)
  %v824 = extractvalue { i64, i1 } %v823, 0
  %v825 = extractvalue { i64, i1 } %v823, 1
  br i1 %v825, label %yes.826, label %no.827
yes.826:
  %v829 = call ptr @mlf_add_int(ptr inttoptr (i64 43 to ptr), ptr inttoptr (i64 7 to ptr))
  br label %join.828
no.827:
  %v830 = inttoptr i64 %v824 to ptr
  br label %join.828
join.828:
  %v831 = phi ptr [ %v829, %yes.826 ], [ %v830, %no.827 ]
  br label %join.821
no.820:
  %v832 = call ptr @mlf_add_int(ptr inttoptr (i64 43 to ptr), ptr inttoptr (i64 7 to ptr))
  br label %join.821
join.821:
  %v833 = phi ptr [ %v831, %join.828 ], [ %v832, %no.820 ]
  ret ptr %v833
}

define private ptr @mlf.code.799(ptr %env, ptr %arg) {
entry:
  %v800 = getelementptr i8, ptr %env, i64 8
  %v801 = load ptr, ptr %v800, align 8, !tbaa !3
  %v802 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v802, align 8, !tbaa !3
  %v812 = call ptr @mlf_thunk(ptr @mlf.code.803, ptr null)
  %v834 = call ptr @mlf_thunk(ptr @mlf.code.813, ptr null)
  %v835 = call ptr @mlf_prim3(i64 33, ptr %v801, ptr %v834, ptr %v812)
  ret ptr %v835
}

define private ptr @mlf.code.849(ptr %env, ptr %arg) {
entry:
  %v850 = call ptr @mlf_double(double 0x3f637c044ac0ace1)
  %v851 = call ptr @mlf_double(double 0x4076d3d70a3d70a4)
  %v852 = getelementptr i8, ptr %v850, i64 8
  %v853 = load double, ptr %v852, align 8, !tbaa !3
  %v854 = getelementptr i8, ptr %v851, i64 8
  %v855 = load double, ptr %v854, align 8, !tbaa !3
  %v856 = fmul double %v853, %v855
  %v857 = call ptr @mlf_double(double %v856)
  ret ptr %v857
}

define private ptr @mlf.code.859(ptr %env, ptr %arg) {
entry:
  %v860 = ptrtoint ptr inttoptr (i64 43 to ptr) to i64
  %v861 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v862 = and i64 %v860, %v861
  %v863 = and i64 %v862, 1
  %v864 = icmp ne i64 %v863, 0
  br i1 %v864, label %yes.865, label %no.866
yes.865:
  %v868 = sub i64 %v861, 1
  %v869 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v860, i64 %v868)
  %v870 = extractvalue { i64, i1 } %v869, 0
  %v871 = extractvalue { i64, i1 } %v869, 1
  br i1 %v871, label %yes.872, label %no.873
yes.872:
  %v875 = call ptr @mlf_add_int(ptr inttoptr (i64 43 to ptr), ptr inttoptr (i64 9 to ptr))
  br label %join.874
no.873:
  %v876 = inttoptr i64 %v870 to ptr
  br label %join.874
join.874:
  %v877 = phi ptr [ %v875, %yes.872 ], [ %v876, %no.873 ]
  br label %join.867
no.866:
  %v878 = call ptr @mlf_add_int(ptr inttoptr (i64 43 to ptr), ptr inttoptr (i64 9 to ptr))
  br label %join.867
join.867:
  %v879 = phi ptr [ %v877, %join.874 ], [ %v878, %no.866 ]
  ret ptr %v879
}

define private ptr @mlf.code.845(ptr %env, ptr %arg) {
entry:
  %v846 = getelementptr i8, ptr %env, i64 8
  %v847 = load ptr, ptr %v846, align 8, !tbaa !3
  %v848 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v848, align 8, !tbaa !3
  %v858 = call ptr @mlf_thunk(ptr @mlf.code.849, ptr null)
  %v880 = call ptr @mlf_thunk(ptr @mlf.code.859, ptr null)
  %v881 = call ptr @mlf_prim3(i64 33, ptr %v847, ptr %v880, ptr %v858)
  ret ptr %v881
}

define private ptr @mlf.code.895(ptr %env, ptr %arg) {
entry:
  %v896 = call ptr @mlf_double(double 0xbeff1983fedbfaa0)
  %v897 = call ptr @mlf_double(double 0x4076d3d70a3d70a4)
  %v898 = getelementptr i8, ptr %v896, i64 8
  %v899 = load double, ptr %v898, align 8, !tbaa !3
  %v900 = getelementptr i8, ptr %v897, i64 8
  %v901 = load double, ptr %v900, align 8, !tbaa !3
  %v902 = fmul double %v899, %v901
  %v903 = call ptr @mlf_double(double %v902)
  ret ptr %v903
}

define private ptr @mlf.code.905(ptr %env, ptr %arg) {
entry:
  %v906 = ptrtoint ptr inttoptr (i64 43 to ptr) to i64
  %v907 = ptrtoint ptr inttoptr (i64 11 to ptr) to i64
  %v908 = and i64 %v906, %v907
  %v909 = and i64 %v908, 1
  %v910 = icmp ne i64 %v909, 0
  br i1 %v910, label %yes.911, label %no.912
yes.911:
  %v914 = sub i64 %v907, 1
  %v915 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v906, i64 %v914)
  %v916 = extractvalue { i64, i1 } %v915, 0
  %v917 = extractvalue { i64, i1 } %v915, 1
  br i1 %v917, label %yes.918, label %no.919
yes.918:
  %v921 = call ptr @mlf_add_int(ptr inttoptr (i64 43 to ptr), ptr inttoptr (i64 11 to ptr))
  br label %join.920
no.919:
  %v922 = inttoptr i64 %v916 to ptr
  br label %join.920
join.920:
  %v923 = phi ptr [ %v921, %yes.918 ], [ %v922, %no.919 ]
  br label %join.913
no.912:
  %v924 = call ptr @mlf_add_int(ptr inttoptr (i64 43 to ptr), ptr inttoptr (i64 11 to ptr))
  br label %join.913
join.913:
  %v925 = phi ptr [ %v923, %join.920 ], [ %v924, %no.912 ]
  ret ptr %v925
}

define private ptr @mlf.code.891(ptr %env, ptr %arg) {
entry:
  %v892 = getelementptr i8, ptr %env, i64 8
  %v893 = load ptr, ptr %v892, align 8, !tbaa !3
  %v894 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v894, align 8, !tbaa !3
  %v904 = call ptr @mlf_thunk(ptr @mlf.code.895, ptr null)
  %v926 = call ptr @mlf_thunk(ptr @mlf.code.905, ptr null)
  %v927 = call ptr @mlf_prim3(i64 33, ptr %v893, ptr %v926, ptr %v904)
  ret ptr %v927
}

define private ptr @mlf.code.944(ptr %env, ptr %arg) {
entry:
  %v945 = getelementptr i8, ptr %env, i64 8
  %v946 = load ptr, ptr %v945, align 8, !tbaa !3
  %v947 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v947, align 8, !tbaa !3
  %v948 = call ptr @mlf_double(double 0x3f06e44607a13bd6)
  %v949 = call ptr @mlf.force(ptr %v946)
  %v950 = getelementptr i8, ptr %v948, i64 8
  %v951 = load double, ptr %v950, align 8, !tbaa !3
  %v952 = getelementptr i8, ptr %v949, i64 8
  %v953 = load double, ptr %v952, align 8, !tbaa !3
  %v954 = fmul double %v951, %v953
  %v955 = call ptr @mlf_double(double %v954)
  ret ptr %v955
}

define private ptr @mlf.code.960(ptr %env, ptr %arg) {
entry:
  %v961 = ptrtoint ptr inttoptr (i64 43 to ptr) to i64
  %v962 = ptrtoint ptr inttoptr (i64 13 to ptr) to i64
  %v963 = and i64 %v961, %v962
  %v964 = and i64 %v963, 1
  %v965 = icmp ne i64 %v964, 0
  br i1 %v965, label %yes.966, label %no.967
yes.966:
  %v969 = sub i64 %v962, 1
  %v970 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v961, i64 %v969)
  %v971 = extractvalue { i64, i1 } %v970, 0
  %v972 = extractvalue { i64, i1 } %v970, 1
  br i1 %v972, label %yes.973, label %no.974
yes.973:
  %v976 = call ptr @mlf_add_int(ptr inttoptr (i64 43 to ptr), ptr inttoptr (i64 13 to ptr))
  br label %join.975
no.974:
  %v977 = inttoptr i64 %v971 to ptr
  br label %join.975
join.975:
  %v978 = phi ptr [ %v976, %yes.973 ], [ %v977, %no.974 ]
  br label %join.968
no.967:
  %v979 = call ptr @mlf_add_int(ptr inttoptr (i64 43 to ptr), ptr inttoptr (i64 13 to ptr))
  br label %join.968
join.968:
  %v980 = phi ptr [ %v978, %join.975 ], [ %v979, %no.967 ]
  ret ptr %v980
}

define private ptr @mlf.code.937(ptr %env, ptr %arg) {
entry:
  %v938 = getelementptr i8, ptr %env, i64 8
  %v939 = load ptr, ptr %v938, align 8, !tbaa !3
  %v940 = getelementptr i8, ptr %env, i64 16
  %v941 = load ptr, ptr %v940, align 8, !tbaa !3
  %v942 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v942, align 8, !tbaa !3
  %v943 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v943, align 8, !tbaa !3
  %v956 = call ptr @mlf.allocate.thunk(ptr @mlf.code.944, i64 1)
  %v957 = getelementptr i8, ptr %v956, i64 16
  %v958 = load ptr, ptr %v957, align 8, !tbaa !3
  %v959 = getelementptr i8, ptr %v958, i64 8
  store ptr %v939, ptr %v959, align 8, !tbaa !3
  %v981 = call ptr @mlf_thunk(ptr @mlf.code.960, ptr null)
  %v982 = call ptr @mlf_prim3(i64 33, ptr %v941, ptr %v981, ptr %v956)
  ret ptr %v982
}

define private ptr @mlf.code.997(ptr %env, ptr %arg) {
entry:
  %v998 = ptrtoint ptr inttoptr (i64 57 to ptr) to i64
  %v999 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v1000 = and i64 %v998, %v999
  %v1001 = and i64 %v1000, 1
  %v1002 = icmp ne i64 %v1001, 0
  br i1 %v1002, label %yes.1003, label %no.1004
yes.1003:
  %v1006 = sub i64 %v999, 1
  %v1007 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v998, i64 %v1006)
  %v1008 = extractvalue { i64, i1 } %v1007, 0
  %v1009 = extractvalue { i64, i1 } %v1007, 1
  br i1 %v1009, label %yes.1010, label %no.1011
yes.1010:
  %v1013 = call ptr @mlf_add_int(ptr inttoptr (i64 57 to ptr), ptr inttoptr (i64 1 to ptr))
  br label %join.1012
no.1011:
  %v1014 = inttoptr i64 %v1008 to ptr
  br label %join.1012
join.1012:
  %v1015 = phi ptr [ %v1013, %yes.1010 ], [ %v1014, %no.1011 ]
  br label %join.1005
no.1004:
  %v1016 = call ptr @mlf_add_int(ptr inttoptr (i64 57 to ptr), ptr inttoptr (i64 1 to ptr))
  br label %join.1005
join.1005:
  %v1017 = phi ptr [ %v1015, %join.1012 ], [ %v1016, %no.1004 ]
  ret ptr %v1017
}

define private ptr @mlf.code.993(ptr %env, ptr %arg) {
entry:
  %v994 = getelementptr i8, ptr %env, i64 8
  %v995 = load ptr, ptr %v994, align 8, !tbaa !3
  %v996 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v996, align 8, !tbaa !3
  %v1018 = call ptr @mlf_thunk(ptr @mlf.code.997, ptr null)
  %v1019 = call ptr @mlf_double(double 0x402ec267a905572a)
  %v1020 = call ptr @mlf_prim3(i64 33, ptr %v995, ptr %v1018, ptr %v1019)
  ret ptr %v1020
}

define private ptr @mlf.code.1034(ptr %env, ptr %arg) {
entry:
  %v1035 = ptrtoint ptr inttoptr (i64 57 to ptr) to i64
  %v1036 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1037 = and i64 %v1035, %v1036
  %v1038 = and i64 %v1037, 1
  %v1039 = icmp ne i64 %v1038, 0
  br i1 %v1039, label %yes.1040, label %no.1041
yes.1040:
  %v1043 = sub i64 %v1036, 1
  %v1044 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1035, i64 %v1043)
  %v1045 = extractvalue { i64, i1 } %v1044, 0
  %v1046 = extractvalue { i64, i1 } %v1044, 1
  br i1 %v1046, label %yes.1047, label %no.1048
yes.1047:
  %v1050 = call ptr @mlf_add_int(ptr inttoptr (i64 57 to ptr), ptr inttoptr (i64 3 to ptr))
  br label %join.1049
no.1048:
  %v1051 = inttoptr i64 %v1045 to ptr
  br label %join.1049
join.1049:
  %v1052 = phi ptr [ %v1050, %yes.1047 ], [ %v1051, %no.1048 ]
  br label %join.1042
no.1041:
  %v1053 = call ptr @mlf_add_int(ptr inttoptr (i64 57 to ptr), ptr inttoptr (i64 3 to ptr))
  br label %join.1042
join.1042:
  %v1054 = phi ptr [ %v1052, %join.1049 ], [ %v1053, %no.1041 ]
  ret ptr %v1054
}

define private ptr @mlf.code.1030(ptr %env, ptr %arg) {
entry:
  %v1031 = getelementptr i8, ptr %env, i64 8
  %v1032 = load ptr, ptr %v1031, align 8, !tbaa !3
  %v1033 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1033, align 8, !tbaa !3
  %v1055 = call ptr @mlf_thunk(ptr @mlf.code.1034, ptr null)
  %v1056 = call ptr @mlf_double(double 0xc039eb5833c8a220)
  %v1057 = call ptr @mlf_prim3(i64 33, ptr %v1032, ptr %v1055, ptr %v1056)
  ret ptr %v1057
}

define private ptr @mlf.code.1071(ptr %env, ptr %arg) {
entry:
  %v1072 = ptrtoint ptr inttoptr (i64 57 to ptr) to i64
  %v1073 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v1074 = and i64 %v1072, %v1073
  %v1075 = and i64 %v1074, 1
  %v1076 = icmp ne i64 %v1075, 0
  br i1 %v1076, label %yes.1077, label %no.1078
yes.1077:
  %v1080 = sub i64 %v1073, 1
  %v1081 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1072, i64 %v1080)
  %v1082 = extractvalue { i64, i1 } %v1081, 0
  %v1083 = extractvalue { i64, i1 } %v1081, 1
  br i1 %v1083, label %yes.1084, label %no.1085
yes.1084:
  %v1087 = call ptr @mlf_add_int(ptr inttoptr (i64 57 to ptr), ptr inttoptr (i64 5 to ptr))
  br label %join.1086
no.1085:
  %v1088 = inttoptr i64 %v1082 to ptr
  br label %join.1086
join.1086:
  %v1089 = phi ptr [ %v1087, %yes.1084 ], [ %v1088, %no.1085 ]
  br label %join.1079
no.1078:
  %v1090 = call ptr @mlf_add_int(ptr inttoptr (i64 57 to ptr), ptr inttoptr (i64 5 to ptr))
  br label %join.1079
join.1079:
  %v1091 = phi ptr [ %v1089, %join.1086 ], [ %v1090, %no.1078 ]
  ret ptr %v1091
}

define private ptr @mlf.code.1067(ptr %env, ptr %arg) {
entry:
  %v1068 = getelementptr i8, ptr %env, i64 8
  %v1069 = load ptr, ptr %v1068, align 8, !tbaa !3
  %v1070 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1070, align 8, !tbaa !3
  %v1092 = call ptr @mlf_thunk(ptr @mlf.code.1071, ptr null)
  %v1093 = call ptr @mlf_double(double 0x3fc6f1f393abe540)
  %v1094 = call ptr @mlf_prim3(i64 33, ptr %v1069, ptr %v1092, ptr %v1093)
  ret ptr %v1094
}

define private ptr @mlf.code.1108(ptr %env, ptr %arg) {
entry:
  %v1109 = call ptr @mlf_double(double 0x3f65f5c9e51b4320)
  %v1110 = call ptr @mlf_double(double 0x4076d3d70a3d70a4)
  %v1111 = getelementptr i8, ptr %v1109, i64 8
  %v1112 = load double, ptr %v1111, align 8, !tbaa !3
  %v1113 = getelementptr i8, ptr %v1110, i64 8
  %v1114 = load double, ptr %v1113, align 8, !tbaa !3
  %v1115 = fmul double %v1112, %v1114
  %v1116 = call ptr @mlf_double(double %v1115)
  ret ptr %v1116
}

define private ptr @mlf.code.1118(ptr %env, ptr %arg) {
entry:
  %v1119 = ptrtoint ptr inttoptr (i64 57 to ptr) to i64
  %v1120 = ptrtoint ptr inttoptr (i64 7 to ptr) to i64
  %v1121 = and i64 %v1119, %v1120
  %v1122 = and i64 %v1121, 1
  %v1123 = icmp ne i64 %v1122, 0
  br i1 %v1123, label %yes.1124, label %no.1125
yes.1124:
  %v1127 = sub i64 %v1120, 1
  %v1128 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1119, i64 %v1127)
  %v1129 = extractvalue { i64, i1 } %v1128, 0
  %v1130 = extractvalue { i64, i1 } %v1128, 1
  br i1 %v1130, label %yes.1131, label %no.1132
yes.1131:
  %v1134 = call ptr @mlf_add_int(ptr inttoptr (i64 57 to ptr), ptr inttoptr (i64 7 to ptr))
  br label %join.1133
no.1132:
  %v1135 = inttoptr i64 %v1129 to ptr
  br label %join.1133
join.1133:
  %v1136 = phi ptr [ %v1134, %yes.1131 ], [ %v1135, %no.1132 ]
  br label %join.1126
no.1125:
  %v1137 = call ptr @mlf_add_int(ptr inttoptr (i64 57 to ptr), ptr inttoptr (i64 7 to ptr))
  br label %join.1126
join.1126:
  %v1138 = phi ptr [ %v1136, %join.1133 ], [ %v1137, %no.1125 ]
  ret ptr %v1138
}

define private ptr @mlf.code.1104(ptr %env, ptr %arg) {
entry:
  %v1105 = getelementptr i8, ptr %env, i64 8
  %v1106 = load ptr, ptr %v1105, align 8, !tbaa !3
  %v1107 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1107, align 8, !tbaa !3
  %v1117 = call ptr @mlf_thunk(ptr @mlf.code.1108, ptr null)
  %v1139 = call ptr @mlf_thunk(ptr @mlf.code.1118, ptr null)
  %v1140 = call ptr @mlf_prim3(i64 33, ptr %v1106, ptr %v1139, ptr %v1117)
  ret ptr %v1140
}

define private ptr @mlf.code.1154(ptr %env, ptr %arg) {
entry:
  %v1155 = call ptr @mlf_double(double 0x3f5aad5736999d88)
  %v1156 = call ptr @mlf_double(double 0x4076d3d70a3d70a4)
  %v1157 = getelementptr i8, ptr %v1155, i64 8
  %v1158 = load double, ptr %v1157, align 8, !tbaa !3
  %v1159 = getelementptr i8, ptr %v1156, i64 8
  %v1160 = load double, ptr %v1159, align 8, !tbaa !3
  %v1161 = fmul double %v1158, %v1160
  %v1162 = call ptr @mlf_double(double %v1161)
  ret ptr %v1162
}

define private ptr @mlf.code.1164(ptr %env, ptr %arg) {
entry:
  %v1165 = ptrtoint ptr inttoptr (i64 57 to ptr) to i64
  %v1166 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v1167 = and i64 %v1165, %v1166
  %v1168 = and i64 %v1167, 1
  %v1169 = icmp ne i64 %v1168, 0
  br i1 %v1169, label %yes.1170, label %no.1171
yes.1170:
  %v1173 = sub i64 %v1166, 1
  %v1174 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1165, i64 %v1173)
  %v1175 = extractvalue { i64, i1 } %v1174, 0
  %v1176 = extractvalue { i64, i1 } %v1174, 1
  br i1 %v1176, label %yes.1177, label %no.1178
yes.1177:
  %v1180 = call ptr @mlf_add_int(ptr inttoptr (i64 57 to ptr), ptr inttoptr (i64 9 to ptr))
  br label %join.1179
no.1178:
  %v1181 = inttoptr i64 %v1175 to ptr
  br label %join.1179
join.1179:
  %v1182 = phi ptr [ %v1180, %yes.1177 ], [ %v1181, %no.1178 ]
  br label %join.1172
no.1171:
  %v1183 = call ptr @mlf_add_int(ptr inttoptr (i64 57 to ptr), ptr inttoptr (i64 9 to ptr))
  br label %join.1172
join.1172:
  %v1184 = phi ptr [ %v1182, %join.1179 ], [ %v1183, %no.1171 ]
  ret ptr %v1184
}

define private ptr @mlf.code.1150(ptr %env, ptr %arg) {
entry:
  %v1151 = getelementptr i8, ptr %env, i64 8
  %v1152 = load ptr, ptr %v1151, align 8, !tbaa !3
  %v1153 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1153, align 8, !tbaa !3
  %v1163 = call ptr @mlf_thunk(ptr @mlf.code.1154, ptr null)
  %v1185 = call ptr @mlf_thunk(ptr @mlf.code.1164, ptr null)
  %v1186 = call ptr @mlf_prim3(i64 33, ptr %v1152, ptr %v1185, ptr %v1163)
  ret ptr %v1186
}

define private ptr @mlf.code.1200(ptr %env, ptr %arg) {
entry:
  %v1201 = call ptr @mlf_double(double 0xbf18f2070b7f9750)
  %v1202 = call ptr @mlf_double(double 0x4076d3d70a3d70a4)
  %v1203 = getelementptr i8, ptr %v1201, i64 8
  %v1204 = load double, ptr %v1203, align 8, !tbaa !3
  %v1205 = getelementptr i8, ptr %v1202, i64 8
  %v1206 = load double, ptr %v1205, align 8, !tbaa !3
  %v1207 = fmul double %v1204, %v1206
  %v1208 = call ptr @mlf_double(double %v1207)
  ret ptr %v1208
}

define private ptr @mlf.code.1210(ptr %env, ptr %arg) {
entry:
  %v1211 = ptrtoint ptr inttoptr (i64 57 to ptr) to i64
  %v1212 = ptrtoint ptr inttoptr (i64 11 to ptr) to i64
  %v1213 = and i64 %v1211, %v1212
  %v1214 = and i64 %v1213, 1
  %v1215 = icmp ne i64 %v1214, 0
  br i1 %v1215, label %yes.1216, label %no.1217
yes.1216:
  %v1219 = sub i64 %v1212, 1
  %v1220 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1211, i64 %v1219)
  %v1221 = extractvalue { i64, i1 } %v1220, 0
  %v1222 = extractvalue { i64, i1 } %v1220, 1
  br i1 %v1222, label %yes.1223, label %no.1224
yes.1223:
  %v1226 = call ptr @mlf_add_int(ptr inttoptr (i64 57 to ptr), ptr inttoptr (i64 11 to ptr))
  br label %join.1225
no.1224:
  %v1227 = inttoptr i64 %v1221 to ptr
  br label %join.1225
join.1225:
  %v1228 = phi ptr [ %v1226, %yes.1223 ], [ %v1227, %no.1224 ]
  br label %join.1218
no.1217:
  %v1229 = call ptr @mlf_add_int(ptr inttoptr (i64 57 to ptr), ptr inttoptr (i64 11 to ptr))
  br label %join.1218
join.1218:
  %v1230 = phi ptr [ %v1228, %join.1225 ], [ %v1229, %no.1217 ]
  ret ptr %v1230
}

define private ptr @mlf.code.1196(ptr %env, ptr %arg) {
entry:
  %v1197 = getelementptr i8, ptr %env, i64 8
  %v1198 = load ptr, ptr %v1197, align 8, !tbaa !3
  %v1199 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1199, align 8, !tbaa !3
  %v1209 = call ptr @mlf_thunk(ptr @mlf.code.1200, ptr null)
  %v1231 = call ptr @mlf_thunk(ptr @mlf.code.1210, ptr null)
  %v1232 = call ptr @mlf_prim3(i64 33, ptr %v1198, ptr %v1231, ptr %v1209)
  ret ptr %v1232
}

define private ptr @mlf.code.1242(ptr %env, ptr %arg) {
entry:
  %v1243 = getelementptr i8, ptr %env, i64 8
  %v1244 = load ptr, ptr %v1243, align 8, !tbaa !3
  %v1245 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1245, align 8, !tbaa !3
  %v1246 = call ptr @mlf_double(double 0x3f0b0213ca2d0eec)
  %v1247 = call ptr @mlf.force(ptr %v1244)
  %v1248 = getelementptr i8, ptr %v1246, i64 8
  %v1249 = load double, ptr %v1248, align 8, !tbaa !3
  %v1250 = getelementptr i8, ptr %v1247, i64 8
  %v1251 = load double, ptr %v1250, align 8, !tbaa !3
  %v1252 = fmul double %v1249, %v1251
  %v1253 = call ptr @mlf_double(double %v1252)
  ret ptr %v1253
}

define private ptr @mlf.code.1258(ptr %env, ptr %arg) {
entry:
  %v1259 = ptrtoint ptr inttoptr (i64 57 to ptr) to i64
  %v1260 = ptrtoint ptr inttoptr (i64 13 to ptr) to i64
  %v1261 = and i64 %v1259, %v1260
  %v1262 = and i64 %v1261, 1
  %v1263 = icmp ne i64 %v1262, 0
  br i1 %v1263, label %yes.1264, label %no.1265
yes.1264:
  %v1267 = sub i64 %v1260, 1
  %v1268 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1259, i64 %v1267)
  %v1269 = extractvalue { i64, i1 } %v1268, 0
  %v1270 = extractvalue { i64, i1 } %v1268, 1
  br i1 %v1270, label %yes.1271, label %no.1272
yes.1271:
  %v1274 = call ptr @mlf_add_int(ptr inttoptr (i64 57 to ptr), ptr inttoptr (i64 13 to ptr))
  br label %join.1273
no.1272:
  %v1275 = inttoptr i64 %v1269 to ptr
  br label %join.1273
join.1273:
  %v1276 = phi ptr [ %v1274, %yes.1271 ], [ %v1275, %no.1272 ]
  br label %join.1266
no.1265:
  %v1277 = call ptr @mlf_add_int(ptr inttoptr (i64 57 to ptr), ptr inttoptr (i64 13 to ptr))
  br label %join.1266
join.1266:
  %v1278 = phi ptr [ %v1276, %join.1273 ], [ %v1277, %no.1265 ]
  ret ptr %v1278
}

define private ptr @mlf.code.1237(ptr %env, ptr %arg) {
entry:
  %v1238 = getelementptr i8, ptr %env, i64 8
  %v1239 = load ptr, ptr %v1238, align 8, !tbaa !3
  %v1240 = getelementptr i8, ptr %env, i64 16
  %v1241 = load ptr, ptr %v1240, align 8, !tbaa !3
  %v1254 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1242, i64 1)
  %v1255 = getelementptr i8, ptr %v1254, i64 16
  %v1256 = load ptr, ptr %v1255, align 8, !tbaa !3
  %v1257 = getelementptr i8, ptr %v1256, i64 8
  store ptr %v1239, ptr %v1257, align 8, !tbaa !3
  %v1279 = call ptr @mlf_thunk(ptr @mlf.code.1258, ptr null)
  %v1280 = call ptr @mlf_prim3(i64 33, ptr %v1241, ptr %v1279, ptr %v1254)
  ret ptr %v1280
}

define private ptr @mlf.code.1191(ptr %env, ptr %arg) {
entry:
  %v1192 = getelementptr i8, ptr %env, i64 8
  %v1193 = load ptr, ptr %v1192, align 8, !tbaa !3
  %v1194 = getelementptr i8, ptr %env, i64 16
  %v1195 = load ptr, ptr %v1194, align 8, !tbaa !3
  %v1233 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1196, i64 1)
  %v1234 = getelementptr i8, ptr %v1233, i64 16
  %v1235 = load ptr, ptr %v1234, align 8, !tbaa !3
  %v1236 = getelementptr i8, ptr %v1235, i64 8
  store ptr %v1195, ptr %v1236, align 8, !tbaa !3
  %v1281 = call ptr @mlf_env_new(i64 2)
  %v1282 = getelementptr i8, ptr %v1281, i64 8
  store ptr %v1193, ptr %v1282, align 8, !tbaa !3
  %v1283 = getelementptr i8, ptr %v1281, i64 16
  store ptr %v1195, ptr %v1283, align 8, !tbaa !3
  %v1284 = call ptr @mlf_closure(ptr @mlf.code.1237, ptr %v1281)
  %v1285 = call ptr @mlf_prim2(i64 1, ptr %v1233, ptr %v1284)
  ret ptr %v1285
}

define private ptr @mlf.code.1145(ptr %env, ptr %arg) {
entry:
  %v1146 = getelementptr i8, ptr %env, i64 8
  %v1147 = load ptr, ptr %v1146, align 8, !tbaa !3
  %v1148 = getelementptr i8, ptr %env, i64 16
  %v1149 = load ptr, ptr %v1148, align 8, !tbaa !3
  %v1187 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1150, i64 1)
  %v1188 = getelementptr i8, ptr %v1187, i64 16
  %v1189 = load ptr, ptr %v1188, align 8, !tbaa !3
  %v1190 = getelementptr i8, ptr %v1189, i64 8
  store ptr %v1149, ptr %v1190, align 8, !tbaa !3
  %v1286 = call ptr @mlf_env_new(i64 2)
  %v1287 = getelementptr i8, ptr %v1286, i64 8
  store ptr %v1147, ptr %v1287, align 8, !tbaa !3
  %v1288 = getelementptr i8, ptr %v1286, i64 16
  store ptr %v1149, ptr %v1288, align 8, !tbaa !3
  %v1289 = call ptr @mlf_closure(ptr @mlf.code.1191, ptr %v1286)
  %v1290 = call ptr @mlf_prim2(i64 1, ptr %v1187, ptr %v1289)
  ret ptr %v1290
}

define private ptr @mlf.code.1099(ptr %env, ptr %arg) {
entry:
  %v1100 = getelementptr i8, ptr %env, i64 8
  %v1101 = load ptr, ptr %v1100, align 8, !tbaa !3
  %v1102 = getelementptr i8, ptr %env, i64 16
  %v1103 = load ptr, ptr %v1102, align 8, !tbaa !3
  %v1141 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1104, i64 1)
  %v1142 = getelementptr i8, ptr %v1141, i64 16
  %v1143 = load ptr, ptr %v1142, align 8, !tbaa !3
  %v1144 = getelementptr i8, ptr %v1143, i64 8
  store ptr %v1103, ptr %v1144, align 8, !tbaa !3
  %v1291 = call ptr @mlf_env_new(i64 2)
  %v1292 = getelementptr i8, ptr %v1291, i64 8
  store ptr %v1101, ptr %v1292, align 8, !tbaa !3
  %v1293 = getelementptr i8, ptr %v1291, i64 16
  store ptr %v1103, ptr %v1293, align 8, !tbaa !3
  %v1294 = call ptr @mlf_closure(ptr @mlf.code.1145, ptr %v1291)
  %v1295 = call ptr @mlf_prim2(i64 1, ptr %v1141, ptr %v1294)
  ret ptr %v1295
}

define private ptr @mlf.code.1062(ptr %env, ptr %arg) {
entry:
  %v1063 = getelementptr i8, ptr %env, i64 8
  %v1064 = load ptr, ptr %v1063, align 8, !tbaa !3
  %v1065 = getelementptr i8, ptr %env, i64 16
  %v1066 = load ptr, ptr %v1065, align 8, !tbaa !3
  %v1095 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1067, i64 1)
  %v1096 = getelementptr i8, ptr %v1095, i64 16
  %v1097 = load ptr, ptr %v1096, align 8, !tbaa !3
  %v1098 = getelementptr i8, ptr %v1097, i64 8
  store ptr %v1066, ptr %v1098, align 8, !tbaa !3
  %v1296 = call ptr @mlf_env_new(i64 2)
  %v1297 = getelementptr i8, ptr %v1296, i64 8
  store ptr %v1064, ptr %v1297, align 8, !tbaa !3
  %v1298 = getelementptr i8, ptr %v1296, i64 16
  store ptr %v1066, ptr %v1298, align 8, !tbaa !3
  %v1299 = call ptr @mlf_closure(ptr @mlf.code.1099, ptr %v1296)
  %v1300 = call ptr @mlf_prim2(i64 1, ptr %v1095, ptr %v1299)
  ret ptr %v1300
}

define private ptr @mlf.code.1025(ptr %env, ptr %arg) {
entry:
  %v1026 = getelementptr i8, ptr %env, i64 8
  %v1027 = load ptr, ptr %v1026, align 8, !tbaa !3
  %v1028 = getelementptr i8, ptr %env, i64 16
  %v1029 = load ptr, ptr %v1028, align 8, !tbaa !3
  %v1058 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1030, i64 1)
  %v1059 = getelementptr i8, ptr %v1058, i64 16
  %v1060 = load ptr, ptr %v1059, align 8, !tbaa !3
  %v1061 = getelementptr i8, ptr %v1060, i64 8
  store ptr %v1029, ptr %v1061, align 8, !tbaa !3
  %v1301 = call ptr @mlf_env_new(i64 2)
  %v1302 = getelementptr i8, ptr %v1301, i64 8
  store ptr %v1027, ptr %v1302, align 8, !tbaa !3
  %v1303 = getelementptr i8, ptr %v1301, i64 16
  store ptr %v1029, ptr %v1303, align 8, !tbaa !3
  %v1304 = call ptr @mlf_closure(ptr @mlf.code.1062, ptr %v1301)
  %v1305 = call ptr @mlf_prim2(i64 1, ptr %v1058, ptr %v1304)
  ret ptr %v1305
}

define private ptr @mlf.code.988(ptr %env, ptr %arg) {
entry:
  %v989 = getelementptr i8, ptr %env, i64 8
  %v990 = load ptr, ptr %v989, align 8, !tbaa !3
  %v991 = getelementptr i8, ptr %env, i64 16
  %v992 = load ptr, ptr %v991, align 8, !tbaa !3
  %v1021 = call ptr @mlf.allocate.thunk(ptr @mlf.code.993, i64 1)
  %v1022 = getelementptr i8, ptr %v1021, i64 16
  %v1023 = load ptr, ptr %v1022, align 8, !tbaa !3
  %v1024 = getelementptr i8, ptr %v1023, i64 8
  store ptr %v992, ptr %v1024, align 8, !tbaa !3
  %v1306 = call ptr @mlf_env_new(i64 2)
  %v1307 = getelementptr i8, ptr %v1306, i64 8
  store ptr %v990, ptr %v1307, align 8, !tbaa !3
  %v1308 = getelementptr i8, ptr %v1306, i64 16
  store ptr %v992, ptr %v1308, align 8, !tbaa !3
  %v1309 = call ptr @mlf_closure(ptr @mlf.code.1025, ptr %v1306)
  %v1310 = call ptr @mlf_prim2(i64 1, ptr %v1021, ptr %v1309)
  ret ptr %v1310
}

define private ptr @mlf.code.932(ptr %env, ptr %arg) {
entry:
  %v933 = getelementptr i8, ptr %env, i64 8
  %v934 = load ptr, ptr %v933, align 8, !tbaa !3
  %v935 = getelementptr i8, ptr %env, i64 16
  %v936 = load ptr, ptr %v935, align 8, !tbaa !3
  %v983 = call ptr @mlf.allocate.thunk(ptr @mlf.code.937, i64 2)
  %v984 = getelementptr i8, ptr %v983, i64 16
  %v985 = load ptr, ptr %v984, align 8, !tbaa !3
  %v986 = getelementptr i8, ptr %v985, i64 8
  store ptr %v934, ptr %v986, align 8, !tbaa !3
  %v987 = getelementptr i8, ptr %v985, i64 16
  store ptr %v936, ptr %v987, align 8, !tbaa !3
  %v1311 = call ptr @mlf_env_new(i64 2)
  %v1312 = getelementptr i8, ptr %v1311, i64 8
  store ptr %v934, ptr %v1312, align 8, !tbaa !3
  %v1313 = getelementptr i8, ptr %v1311, i64 16
  store ptr %v936, ptr %v1313, align 8, !tbaa !3
  %v1314 = call ptr @mlf_closure(ptr @mlf.code.988, ptr %v1311)
  %v1315 = call ptr @mlf_prim2(i64 1, ptr %v983, ptr %v1314)
  ret ptr %v1315
}

define private ptr @mlf.code.886(ptr %env, ptr %arg) {
entry:
  %v887 = getelementptr i8, ptr %env, i64 8
  %v888 = load ptr, ptr %v887, align 8, !tbaa !3
  %v889 = getelementptr i8, ptr %env, i64 16
  %v890 = load ptr, ptr %v889, align 8, !tbaa !3
  %v928 = call ptr @mlf.allocate.thunk(ptr @mlf.code.891, i64 1)
  %v929 = getelementptr i8, ptr %v928, i64 16
  %v930 = load ptr, ptr %v929, align 8, !tbaa !3
  %v931 = getelementptr i8, ptr %v930, i64 8
  store ptr %v890, ptr %v931, align 8, !tbaa !3
  %v1316 = call ptr @mlf_env_new(i64 2)
  %v1317 = getelementptr i8, ptr %v1316, i64 8
  store ptr %v888, ptr %v1317, align 8, !tbaa !3
  %v1318 = getelementptr i8, ptr %v1316, i64 16
  store ptr %v890, ptr %v1318, align 8, !tbaa !3
  %v1319 = call ptr @mlf_closure(ptr @mlf.code.932, ptr %v1316)
  %v1320 = call ptr @mlf_prim2(i64 1, ptr %v928, ptr %v1319)
  ret ptr %v1320
}

define private ptr @mlf.code.840(ptr %env, ptr %arg) {
entry:
  %v841 = getelementptr i8, ptr %env, i64 8
  %v842 = load ptr, ptr %v841, align 8, !tbaa !3
  %v843 = getelementptr i8, ptr %env, i64 16
  %v844 = load ptr, ptr %v843, align 8, !tbaa !3
  %v882 = call ptr @mlf.allocate.thunk(ptr @mlf.code.845, i64 1)
  %v883 = getelementptr i8, ptr %v882, i64 16
  %v884 = load ptr, ptr %v883, align 8, !tbaa !3
  %v885 = getelementptr i8, ptr %v884, i64 8
  store ptr %v844, ptr %v885, align 8, !tbaa !3
  %v1321 = call ptr @mlf_env_new(i64 2)
  %v1322 = getelementptr i8, ptr %v1321, i64 8
  store ptr %v842, ptr %v1322, align 8, !tbaa !3
  %v1323 = getelementptr i8, ptr %v1321, i64 16
  store ptr %v844, ptr %v1323, align 8, !tbaa !3
  %v1324 = call ptr @mlf_closure(ptr @mlf.code.886, ptr %v1321)
  %v1325 = call ptr @mlf_prim2(i64 1, ptr %v882, ptr %v1324)
  ret ptr %v1325
}

define private ptr @mlf.code.794(ptr %env, ptr %arg) {
entry:
  %v795 = getelementptr i8, ptr %env, i64 8
  %v796 = load ptr, ptr %v795, align 8, !tbaa !3
  %v797 = getelementptr i8, ptr %env, i64 16
  %v798 = load ptr, ptr %v797, align 8, !tbaa !3
  %v836 = call ptr @mlf.allocate.thunk(ptr @mlf.code.799, i64 1)
  %v837 = getelementptr i8, ptr %v836, i64 16
  %v838 = load ptr, ptr %v837, align 8, !tbaa !3
  %v839 = getelementptr i8, ptr %v838, i64 8
  store ptr %v798, ptr %v839, align 8, !tbaa !3
  %v1326 = call ptr @mlf_env_new(i64 2)
  %v1327 = getelementptr i8, ptr %v1326, i64 8
  store ptr %v796, ptr %v1327, align 8, !tbaa !3
  %v1328 = getelementptr i8, ptr %v1326, i64 16
  store ptr %v798, ptr %v1328, align 8, !tbaa !3
  %v1329 = call ptr @mlf_closure(ptr @mlf.code.840, ptr %v1326)
  %v1330 = call ptr @mlf_prim2(i64 1, ptr %v836, ptr %v1329)
  ret ptr %v1330
}

define private ptr @mlf.code.757(ptr %env, ptr %arg) {
entry:
  %v758 = getelementptr i8, ptr %env, i64 8
  %v759 = load ptr, ptr %v758, align 8, !tbaa !3
  %v760 = getelementptr i8, ptr %env, i64 16
  %v761 = load ptr, ptr %v760, align 8, !tbaa !3
  %v790 = call ptr @mlf.allocate.thunk(ptr @mlf.code.762, i64 1)
  %v791 = getelementptr i8, ptr %v790, i64 16
  %v792 = load ptr, ptr %v791, align 8, !tbaa !3
  %v793 = getelementptr i8, ptr %v792, i64 8
  store ptr %v761, ptr %v793, align 8, !tbaa !3
  %v1331 = call ptr @mlf_env_new(i64 2)
  %v1332 = getelementptr i8, ptr %v1331, i64 8
  store ptr %v759, ptr %v1332, align 8, !tbaa !3
  %v1333 = getelementptr i8, ptr %v1331, i64 16
  store ptr %v761, ptr %v1333, align 8, !tbaa !3
  %v1334 = call ptr @mlf_closure(ptr @mlf.code.794, ptr %v1331)
  %v1335 = call ptr @mlf_prim2(i64 1, ptr %v790, ptr %v1334)
  ret ptr %v1335
}

define private ptr @mlf.code.720(ptr %env, ptr %arg) {
entry:
  %v721 = getelementptr i8, ptr %env, i64 8
  %v722 = load ptr, ptr %v721, align 8, !tbaa !3
  %v723 = getelementptr i8, ptr %env, i64 16
  %v724 = load ptr, ptr %v723, align 8, !tbaa !3
  %v753 = call ptr @mlf.allocate.thunk(ptr @mlf.code.725, i64 1)
  %v754 = getelementptr i8, ptr %v753, i64 16
  %v755 = load ptr, ptr %v754, align 8, !tbaa !3
  %v756 = getelementptr i8, ptr %v755, i64 8
  store ptr %v724, ptr %v756, align 8, !tbaa !3
  %v1336 = call ptr @mlf_env_new(i64 2)
  %v1337 = getelementptr i8, ptr %v1336, i64 8
  store ptr %v722, ptr %v1337, align 8, !tbaa !3
  %v1338 = getelementptr i8, ptr %v1336, i64 16
  store ptr %v724, ptr %v1338, align 8, !tbaa !3
  %v1339 = call ptr @mlf_closure(ptr @mlf.code.757, ptr %v1336)
  %v1340 = call ptr @mlf_prim2(i64 1, ptr %v753, ptr %v1339)
  ret ptr %v1340
}

define private ptr @mlf.code.683(ptr %env, ptr %arg) {
entry:
  %v684 = getelementptr i8, ptr %env, i64 8
  %v685 = load ptr, ptr %v684, align 8, !tbaa !3
  %v686 = getelementptr i8, ptr %env, i64 16
  %v687 = load ptr, ptr %v686, align 8, !tbaa !3
  %v716 = call ptr @mlf.allocate.thunk(ptr @mlf.code.688, i64 1)
  %v717 = getelementptr i8, ptr %v716, i64 16
  %v718 = load ptr, ptr %v717, align 8, !tbaa !3
  %v719 = getelementptr i8, ptr %v718, i64 8
  store ptr %v687, ptr %v719, align 8, !tbaa !3
  %v1341 = call ptr @mlf_env_new(i64 2)
  %v1342 = getelementptr i8, ptr %v1341, i64 8
  store ptr %v685, ptr %v1342, align 8, !tbaa !3
  %v1343 = getelementptr i8, ptr %v1341, i64 16
  store ptr %v687, ptr %v1343, align 8, !tbaa !3
  %v1344 = call ptr @mlf_closure(ptr @mlf.code.720, ptr %v1341)
  %v1345 = call ptr @mlf_prim2(i64 1, ptr %v716, ptr %v1344)
  ret ptr %v1345
}

define private ptr @mlf.code.627(ptr %env, ptr %arg) {
entry:
  %v628 = getelementptr i8, ptr %env, i64 8
  %v629 = load ptr, ptr %v628, align 8, !tbaa !3
  %v630 = getelementptr i8, ptr %env, i64 16
  %v631 = load ptr, ptr %v630, align 8, !tbaa !3
  %v678 = call ptr @mlf.allocate.thunk(ptr @mlf.code.632, i64 2)
  %v679 = getelementptr i8, ptr %v678, i64 16
  %v680 = load ptr, ptr %v679, align 8, !tbaa !3
  %v681 = getelementptr i8, ptr %v680, i64 8
  store ptr %v629, ptr %v681, align 8, !tbaa !3
  %v682 = getelementptr i8, ptr %v680, i64 16
  store ptr %v631, ptr %v682, align 8, !tbaa !3
  %v1346 = call ptr @mlf_env_new(i64 2)
  %v1347 = getelementptr i8, ptr %v1346, i64 8
  store ptr %v629, ptr %v1347, align 8, !tbaa !3
  %v1348 = getelementptr i8, ptr %v1346, i64 16
  store ptr %v631, ptr %v1348, align 8, !tbaa !3
  %v1349 = call ptr @mlf_closure(ptr @mlf.code.683, ptr %v1346)
  %v1350 = call ptr @mlf_prim2(i64 1, ptr %v678, ptr %v1349)
  ret ptr %v1350
}

define private ptr @mlf.code.581(ptr %env, ptr %arg) {
entry:
  %v582 = getelementptr i8, ptr %env, i64 8
  %v583 = load ptr, ptr %v582, align 8, !tbaa !3
  %v584 = getelementptr i8, ptr %env, i64 16
  %v585 = load ptr, ptr %v584, align 8, !tbaa !3
  %v623 = call ptr @mlf.allocate.thunk(ptr @mlf.code.586, i64 1)
  %v624 = getelementptr i8, ptr %v623, i64 16
  %v625 = load ptr, ptr %v624, align 8, !tbaa !3
  %v626 = getelementptr i8, ptr %v625, i64 8
  store ptr %v585, ptr %v626, align 8, !tbaa !3
  %v1351 = call ptr @mlf_env_new(i64 2)
  %v1352 = getelementptr i8, ptr %v1351, i64 8
  store ptr %v583, ptr %v1352, align 8, !tbaa !3
  %v1353 = getelementptr i8, ptr %v1351, i64 16
  store ptr %v585, ptr %v1353, align 8, !tbaa !3
  %v1354 = call ptr @mlf_closure(ptr @mlf.code.627, ptr %v1351)
  %v1355 = call ptr @mlf_prim2(i64 1, ptr %v623, ptr %v1354)
  ret ptr %v1355
}

define private ptr @mlf.code.535(ptr %env, ptr %arg) {
entry:
  %v536 = getelementptr i8, ptr %env, i64 8
  %v537 = load ptr, ptr %v536, align 8, !tbaa !3
  %v538 = getelementptr i8, ptr %env, i64 16
  %v539 = load ptr, ptr %v538, align 8, !tbaa !3
  %v577 = call ptr @mlf.allocate.thunk(ptr @mlf.code.540, i64 1)
  %v578 = getelementptr i8, ptr %v577, i64 16
  %v579 = load ptr, ptr %v578, align 8, !tbaa !3
  %v580 = getelementptr i8, ptr %v579, i64 8
  store ptr %v539, ptr %v580, align 8, !tbaa !3
  %v1356 = call ptr @mlf_env_new(i64 2)
  %v1357 = getelementptr i8, ptr %v1356, i64 8
  store ptr %v537, ptr %v1357, align 8, !tbaa !3
  %v1358 = getelementptr i8, ptr %v1356, i64 16
  store ptr %v539, ptr %v1358, align 8, !tbaa !3
  %v1359 = call ptr @mlf_closure(ptr @mlf.code.581, ptr %v1356)
  %v1360 = call ptr @mlf_prim2(i64 1, ptr %v577, ptr %v1359)
  ret ptr %v1360
}

define private ptr @mlf.code.489(ptr %env, ptr %arg) {
entry:
  %v490 = getelementptr i8, ptr %env, i64 8
  %v491 = load ptr, ptr %v490, align 8, !tbaa !3
  %v492 = getelementptr i8, ptr %env, i64 16
  %v493 = load ptr, ptr %v492, align 8, !tbaa !3
  %v531 = call ptr @mlf.allocate.thunk(ptr @mlf.code.494, i64 1)
  %v532 = getelementptr i8, ptr %v531, i64 16
  %v533 = load ptr, ptr %v532, align 8, !tbaa !3
  %v534 = getelementptr i8, ptr %v533, i64 8
  store ptr %v493, ptr %v534, align 8, !tbaa !3
  %v1361 = call ptr @mlf_env_new(i64 2)
  %v1362 = getelementptr i8, ptr %v1361, i64 8
  store ptr %v491, ptr %v1362, align 8, !tbaa !3
  %v1363 = getelementptr i8, ptr %v1361, i64 16
  store ptr %v493, ptr %v1363, align 8, !tbaa !3
  %v1364 = call ptr @mlf_closure(ptr @mlf.code.535, ptr %v1361)
  %v1365 = call ptr @mlf_prim2(i64 1, ptr %v531, ptr %v1364)
  ret ptr %v1365
}

define private ptr @mlf.code.452(ptr %env, ptr %arg) {
entry:
  %v453 = getelementptr i8, ptr %env, i64 8
  %v454 = load ptr, ptr %v453, align 8, !tbaa !3
  %v455 = getelementptr i8, ptr %env, i64 16
  %v456 = load ptr, ptr %v455, align 8, !tbaa !3
  %v485 = call ptr @mlf.allocate.thunk(ptr @mlf.code.457, i64 1)
  %v486 = getelementptr i8, ptr %v485, i64 16
  %v487 = load ptr, ptr %v486, align 8, !tbaa !3
  %v488 = getelementptr i8, ptr %v487, i64 8
  store ptr %v456, ptr %v488, align 8, !tbaa !3
  %v1366 = call ptr @mlf_env_new(i64 2)
  %v1367 = getelementptr i8, ptr %v1366, i64 8
  store ptr %v454, ptr %v1367, align 8, !tbaa !3
  %v1368 = getelementptr i8, ptr %v1366, i64 16
  store ptr %v456, ptr %v1368, align 8, !tbaa !3
  %v1369 = call ptr @mlf_closure(ptr @mlf.code.489, ptr %v1366)
  %v1370 = call ptr @mlf_prim2(i64 1, ptr %v485, ptr %v1369)
  ret ptr %v1370
}

define private ptr @mlf.code.415(ptr %env, ptr %arg) {
entry:
  %v416 = getelementptr i8, ptr %env, i64 8
  %v417 = load ptr, ptr %v416, align 8, !tbaa !3
  %v418 = getelementptr i8, ptr %env, i64 16
  %v419 = load ptr, ptr %v418, align 8, !tbaa !3
  %v448 = call ptr @mlf.allocate.thunk(ptr @mlf.code.420, i64 1)
  %v449 = getelementptr i8, ptr %v448, i64 16
  %v450 = load ptr, ptr %v449, align 8, !tbaa !3
  %v451 = getelementptr i8, ptr %v450, i64 8
  store ptr %v419, ptr %v451, align 8, !tbaa !3
  %v1371 = call ptr @mlf_env_new(i64 2)
  %v1372 = getelementptr i8, ptr %v1371, i64 8
  store ptr %v417, ptr %v1372, align 8, !tbaa !3
  %v1373 = getelementptr i8, ptr %v1371, i64 16
  store ptr %v419, ptr %v1373, align 8, !tbaa !3
  %v1374 = call ptr @mlf_closure(ptr @mlf.code.452, ptr %v1371)
  %v1375 = call ptr @mlf_prim2(i64 1, ptr %v448, ptr %v1374)
  ret ptr %v1375
}

define private ptr @mlf.code.378(ptr %env, ptr %arg) {
entry:
  %v379 = getelementptr i8, ptr %env, i64 8
  %v380 = load ptr, ptr %v379, align 8, !tbaa !3
  %v381 = getelementptr i8, ptr %env, i64 16
  %v382 = load ptr, ptr %v381, align 8, !tbaa !3
  %v411 = call ptr @mlf.allocate.thunk(ptr @mlf.code.383, i64 1)
  %v412 = getelementptr i8, ptr %v411, i64 16
  %v413 = load ptr, ptr %v412, align 8, !tbaa !3
  %v414 = getelementptr i8, ptr %v413, i64 8
  store ptr %v382, ptr %v414, align 8, !tbaa !3
  %v1376 = call ptr @mlf_env_new(i64 2)
  %v1377 = getelementptr i8, ptr %v1376, i64 8
  store ptr %v380, ptr %v1377, align 8, !tbaa !3
  %v1378 = getelementptr i8, ptr %v1376, i64 16
  store ptr %v382, ptr %v1378, align 8, !tbaa !3
  %v1379 = call ptr @mlf_closure(ptr @mlf.code.415, ptr %v1376)
  %v1380 = call ptr @mlf_prim2(i64 1, ptr %v411, ptr %v1379)
  ret ptr %v1380
}

define private ptr @mlf.code.322(ptr %env, ptr %arg) {
entry:
  %v323 = getelementptr i8, ptr %env, i64 8
  %v324 = load ptr, ptr %v323, align 8, !tbaa !3
  %v325 = getelementptr i8, ptr %env, i64 16
  %v326 = load ptr, ptr %v325, align 8, !tbaa !3
  %v373 = call ptr @mlf.allocate.thunk(ptr @mlf.code.327, i64 2)
  %v374 = getelementptr i8, ptr %v373, i64 16
  %v375 = load ptr, ptr %v374, align 8, !tbaa !3
  %v376 = getelementptr i8, ptr %v375, i64 8
  store ptr %v324, ptr %v376, align 8, !tbaa !3
  %v377 = getelementptr i8, ptr %v375, i64 16
  store ptr %v326, ptr %v377, align 8, !tbaa !3
  %v1381 = call ptr @mlf_env_new(i64 2)
  %v1382 = getelementptr i8, ptr %v1381, i64 8
  store ptr %v324, ptr %v1382, align 8, !tbaa !3
  %v1383 = getelementptr i8, ptr %v1381, i64 16
  store ptr %v326, ptr %v1383, align 8, !tbaa !3
  %v1384 = call ptr @mlf_closure(ptr @mlf.code.378, ptr %v1381)
  %v1385 = call ptr @mlf_prim2(i64 1, ptr %v373, ptr %v1384)
  ret ptr %v1385
}

define private ptr @mlf.code.276(ptr %env, ptr %arg) {
entry:
  %v277 = getelementptr i8, ptr %env, i64 8
  %v278 = load ptr, ptr %v277, align 8, !tbaa !3
  %v279 = getelementptr i8, ptr %env, i64 16
  %v280 = load ptr, ptr %v279, align 8, !tbaa !3
  %v318 = call ptr @mlf.allocate.thunk(ptr @mlf.code.281, i64 1)
  %v319 = getelementptr i8, ptr %v318, i64 16
  %v320 = load ptr, ptr %v319, align 8, !tbaa !3
  %v321 = getelementptr i8, ptr %v320, i64 8
  store ptr %v280, ptr %v321, align 8, !tbaa !3
  %v1386 = call ptr @mlf_env_new(i64 2)
  %v1387 = getelementptr i8, ptr %v1386, i64 8
  store ptr %v278, ptr %v1387, align 8, !tbaa !3
  %v1388 = getelementptr i8, ptr %v1386, i64 16
  store ptr %v280, ptr %v1388, align 8, !tbaa !3
  %v1389 = call ptr @mlf_closure(ptr @mlf.code.322, ptr %v1386)
  %v1390 = call ptr @mlf_prim2(i64 1, ptr %v318, ptr %v1389)
  ret ptr %v1390
}

define private ptr @mlf.code.230(ptr %env, ptr %arg) {
entry:
  %v231 = getelementptr i8, ptr %env, i64 8
  %v232 = load ptr, ptr %v231, align 8, !tbaa !3
  %v233 = getelementptr i8, ptr %env, i64 16
  %v234 = load ptr, ptr %v233, align 8, !tbaa !3
  %v272 = call ptr @mlf.allocate.thunk(ptr @mlf.code.235, i64 1)
  %v273 = getelementptr i8, ptr %v272, i64 16
  %v274 = load ptr, ptr %v273, align 8, !tbaa !3
  %v275 = getelementptr i8, ptr %v274, i64 8
  store ptr %v234, ptr %v275, align 8, !tbaa !3
  %v1391 = call ptr @mlf_env_new(i64 2)
  %v1392 = getelementptr i8, ptr %v1391, i64 8
  store ptr %v232, ptr %v1392, align 8, !tbaa !3
  %v1393 = getelementptr i8, ptr %v1391, i64 16
  store ptr %v234, ptr %v1393, align 8, !tbaa !3
  %v1394 = call ptr @mlf_closure(ptr @mlf.code.276, ptr %v1391)
  %v1395 = call ptr @mlf_prim2(i64 1, ptr %v272, ptr %v1394)
  ret ptr %v1395
}

define private ptr @mlf.code.184(ptr %env, ptr %arg) {
entry:
  %v185 = getelementptr i8, ptr %env, i64 8
  %v186 = load ptr, ptr %v185, align 8, !tbaa !3
  %v187 = getelementptr i8, ptr %env, i64 16
  %v188 = load ptr, ptr %v187, align 8, !tbaa !3
  %v226 = call ptr @mlf.allocate.thunk(ptr @mlf.code.189, i64 1)
  %v227 = getelementptr i8, ptr %v226, i64 16
  %v228 = load ptr, ptr %v227, align 8, !tbaa !3
  %v229 = getelementptr i8, ptr %v228, i64 8
  store ptr %v188, ptr %v229, align 8, !tbaa !3
  %v1396 = call ptr @mlf_env_new(i64 2)
  %v1397 = getelementptr i8, ptr %v1396, i64 8
  store ptr %v186, ptr %v1397, align 8, !tbaa !3
  %v1398 = getelementptr i8, ptr %v1396, i64 16
  store ptr %v188, ptr %v1398, align 8, !tbaa !3
  %v1399 = call ptr @mlf_closure(ptr @mlf.code.230, ptr %v1396)
  %v1400 = call ptr @mlf_prim2(i64 1, ptr %v226, ptr %v1399)
  ret ptr %v1400
}

define private ptr @mlf.code.147(ptr %env, ptr %arg) {
entry:
  %v148 = getelementptr i8, ptr %env, i64 8
  %v149 = load ptr, ptr %v148, align 8, !tbaa !3
  %v150 = getelementptr i8, ptr %env, i64 16
  %v151 = load ptr, ptr %v150, align 8, !tbaa !3
  %v180 = call ptr @mlf.allocate.thunk(ptr @mlf.code.152, i64 1)
  %v181 = getelementptr i8, ptr %v180, i64 16
  %v182 = load ptr, ptr %v181, align 8, !tbaa !3
  %v183 = getelementptr i8, ptr %v182, i64 8
  store ptr %v151, ptr %v183, align 8, !tbaa !3
  %v1401 = call ptr @mlf_env_new(i64 2)
  %v1402 = getelementptr i8, ptr %v1401, i64 8
  store ptr %v149, ptr %v1402, align 8, !tbaa !3
  %v1403 = getelementptr i8, ptr %v1401, i64 16
  store ptr %v151, ptr %v1403, align 8, !tbaa !3
  %v1404 = call ptr @mlf_closure(ptr @mlf.code.184, ptr %v1401)
  %v1405 = call ptr @mlf_prim2(i64 1, ptr %v180, ptr %v1404)
  ret ptr %v1405
}

define private ptr @mlf.code.110(ptr %env, ptr %arg) {
entry:
  %v111 = getelementptr i8, ptr %env, i64 8
  %v112 = load ptr, ptr %v111, align 8, !tbaa !3
  %v113 = getelementptr i8, ptr %env, i64 16
  %v114 = load ptr, ptr %v113, align 8, !tbaa !3
  %v143 = call ptr @mlf.allocate.thunk(ptr @mlf.code.115, i64 1)
  %v144 = getelementptr i8, ptr %v143, i64 16
  %v145 = load ptr, ptr %v144, align 8, !tbaa !3
  %v146 = getelementptr i8, ptr %v145, i64 8
  store ptr %v114, ptr %v146, align 8, !tbaa !3
  %v1406 = call ptr @mlf_env_new(i64 2)
  %v1407 = getelementptr i8, ptr %v1406, i64 8
  store ptr %v112, ptr %v1407, align 8, !tbaa !3
  %v1408 = getelementptr i8, ptr %v1406, i64 16
  store ptr %v114, ptr %v1408, align 8, !tbaa !3
  %v1409 = call ptr @mlf_closure(ptr @mlf.code.147, ptr %v1406)
  %v1410 = call ptr @mlf_prim2(i64 1, ptr %v143, ptr %v1409)
  ret ptr %v1410
}

define private ptr @mlf.code.73(ptr %env, ptr %arg) {
entry:
  %v74 = getelementptr i8, ptr %env, i64 8
  %v75 = load ptr, ptr %v74, align 8, !tbaa !3
  %v76 = getelementptr i8, ptr %env, i64 16
  %v77 = load ptr, ptr %v76, align 8, !tbaa !3
  %v106 = call ptr @mlf.allocate.thunk(ptr @mlf.code.78, i64 1)
  %v107 = getelementptr i8, ptr %v106, i64 16
  %v108 = load ptr, ptr %v107, align 8, !tbaa !3
  %v109 = getelementptr i8, ptr %v108, i64 8
  store ptr %v77, ptr %v109, align 8, !tbaa !3
  %v1411 = call ptr @mlf_env_new(i64 2)
  %v1412 = getelementptr i8, ptr %v1411, i64 8
  store ptr %v75, ptr %v1412, align 8, !tbaa !3
  %v1413 = getelementptr i8, ptr %v1411, i64 16
  store ptr %v77, ptr %v1413, align 8, !tbaa !3
  %v1414 = call ptr @mlf_closure(ptr @mlf.code.110, ptr %v1411)
  %v1415 = call ptr @mlf_prim2(i64 1, ptr %v106, ptr %v1414)
  ret ptr %v1415
}

define private ptr @mlf.code.31(ptr %env, ptr %arg) {
entry:
  %v32 = getelementptr i8, ptr %env, i64 8
  %v33 = load ptr, ptr %v32, align 8, !tbaa !3
  %v34 = getelementptr i8, ptr %env, i64 16
  %v35 = load ptr, ptr %v34, align 8, !tbaa !3
  %v36 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v36, align 8, !tbaa !3
  %v37 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v37, align 8, !tbaa !3
  %v68 = call ptr @mlf.allocate.thunk(ptr @mlf.code.38, i64 2)
  %v69 = getelementptr i8, ptr %v68, i64 16
  %v70 = load ptr, ptr %v69, align 8, !tbaa !3
  %v71 = getelementptr i8, ptr %v70, i64 8
  store ptr %v33, ptr %v71, align 8, !tbaa !3
  %v72 = getelementptr i8, ptr %v70, i64 16
  store ptr %v35, ptr %v72, align 8, !tbaa !3
  %v1416 = call ptr @mlf_env_new(i64 2)
  %v1417 = getelementptr i8, ptr %v1416, i64 8
  store ptr %v33, ptr %v1417, align 8, !tbaa !3
  %v1418 = getelementptr i8, ptr %v1416, i64 16
  store ptr %v35, ptr %v1418, align 8, !tbaa !3
  %v1419 = call ptr @mlf_closure(ptr @mlf.code.73, ptr %v1416)
  %v1420 = call ptr @mlf_prim2(i64 1, ptr %v68, ptr %v1419)
  ret ptr %v1420
}

define private ptr @mlf.numeric.1.pppddd(ptr %a0, ptr %a1, ptr %a2, double %a3, double %a4, double %a5) alwaysinline {
entry:
  %v1690 = ptrtoint ptr %a2 to i64
  %v1691 = ptrtoint ptr inttoptr (i64 71 to ptr) to i64
  %v1692 = and i64 %v1690, %v1691
  %v1693 = and i64 %v1692, 1
  %v1694 = icmp ne i64 %v1693, 0
  br i1 %v1694, label %yes.1695, label %no.1696
yes.1695:
  %v1698 = icmp eq i64 %v1690, %v1691
  %v1699 = select i1 %v1698, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1697
no.1696:
  %v1700 = call ptr @mlf_eq_int(ptr %a2, ptr inttoptr (i64 71 to ptr))
  br label %join.1697
join.1697:
  %v1701 = phi ptr [ %v1699, %yes.1695 ], [ %v1700, %no.1696 ]
  %v1702 = icmp eq ptr %v1701, inttoptr (i64 6 to ptr)
  br i1 %v1702, label %tail.yes.1703, label %tail.no.1704
tail.yes.1703:
  %v1705 = fsub double 0x0000000000000000, %a3
  %v1706 = getelementptr i8, ptr %a0, i64 8
  %v1707 = load double, ptr %v1706, align 8, !tbaa !3
  %v1708 = fdiv double %v1705, %v1707
  %v1709 = getelementptr i8, ptr %a1, i64 8
  %v1710 = load i64, ptr %v1709, align 8, !tbaa !3
  %v1711 = getelementptr i8, ptr %a1, i64 16
  %v1712 = load ptr, ptr %v1711, align 8, !tbaa !3
  %v1713 = ptrtoint ptr inttoptr (i64 7 to ptr) to i64
  %v1714 = ashr i64 %v1713, 1
  %v1715 = and i64 %v1713, 1
  %v1716 = icmp ne i64 %v1715, 0
  %v1717 = icmp ult i64 %v1714, %v1710
  %v1718 = and i1 %v1716, %v1717
  br i1 %v1718, label %array.valid.1719, label %array.invalid.1720
array.invalid.1720:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1719:
  %v1721 = getelementptr i64, ptr %v1712, i64 %v1714
  store double %v1708, ptr %v1721, align 8, !tbaa !4
  %v1722 = fsub double 0x0000000000000000, %a4
  %v1723 = fdiv double %v1722, %v1707
  %v1724 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v1725 = ashr i64 %v1724, 1
  %v1726 = and i64 %v1724, 1
  %v1727 = icmp ne i64 %v1726, 0
  %v1728 = icmp ult i64 %v1725, %v1710
  %v1729 = and i1 %v1727, %v1728
  br i1 %v1729, label %array.valid.1730, label %array.invalid.1731
array.invalid.1731:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1730:
  %v1732 = getelementptr i64, ptr %v1712, i64 %v1725
  store double %v1723, ptr %v1732, align 8, !tbaa !4
  %v1733 = fsub double 0x0000000000000000, %a5
  %v1734 = fdiv double %v1733, %v1707
  %v1735 = ptrtoint ptr inttoptr (i64 11 to ptr) to i64
  %v1736 = ashr i64 %v1735, 1
  %v1737 = and i64 %v1735, 1
  %v1738 = icmp ne i64 %v1737, 0
  %v1739 = icmp ult i64 %v1736, %v1710
  %v1740 = and i1 %v1738, %v1739
  br i1 %v1740, label %array.valid.1741, label %array.invalid.1742
array.invalid.1742:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1741:
  %v1743 = getelementptr i64, ptr %v1712, i64 %v1736
  store double %v1734, ptr %v1743, align 8, !tbaa !4
  ret ptr inttoptr (i64 4 to ptr)
tail.no.1704:
  %v1744 = ptrtoint ptr %a2 to i64
  %v1745 = ptrtoint ptr inttoptr (i64 7 to ptr) to i64
  %v1746 = and i64 %v1744, %v1745
  %v1747 = and i64 %v1746, 1
  %v1748 = icmp ne i64 %v1747, 0
  br i1 %v1748, label %yes.1749, label %no.1750
yes.1749:
  %v1752 = sub i64 %v1745, 1
  %v1753 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1744, i64 %v1752)
  %v1754 = extractvalue { i64, i1 } %v1753, 0
  %v1755 = extractvalue { i64, i1 } %v1753, 1
  br i1 %v1755, label %yes.1756, label %no.1757
yes.1756:
  %v1759 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 7 to ptr))
  br label %join.1758
no.1757:
  %v1760 = inttoptr i64 %v1754 to ptr
  br label %join.1758
join.1758:
  %v1761 = phi ptr [ %v1759, %yes.1756 ], [ %v1760, %no.1757 ]
  br label %join.1751
no.1750:
  %v1762 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 7 to ptr))
  br label %join.1751
join.1751:
  %v1763 = phi ptr [ %v1761, %join.1758 ], [ %v1762, %no.1750 ]
  %v1764 = getelementptr i8, ptr %a1, i64 8
  %v1765 = load i64, ptr %v1764, align 8, !tbaa !3
  %v1766 = getelementptr i8, ptr %a1, i64 16
  %v1767 = load ptr, ptr %v1766, align 8, !tbaa !3
  %v1768 = ptrtoint ptr %v1763 to i64
  %v1769 = ashr i64 %v1768, 1
  %v1770 = and i64 %v1768, 1
  %v1771 = icmp ne i64 %v1770, 0
  %v1772 = icmp ult i64 %v1769, %v1765
  %v1773 = and i1 %v1771, %v1772
  br i1 %v1773, label %array.valid.1774, label %array.invalid.1775
array.invalid.1775:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1774:
  %v1776 = getelementptr i64, ptr %v1767, i64 %v1769
  %v1777 = load double, ptr %v1776, align 8, !tbaa !4
  %v1778 = ptrtoint ptr %a2 to i64
  %v1779 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v1780 = and i64 %v1778, %v1779
  %v1781 = and i64 %v1780, 1
  %v1782 = icmp ne i64 %v1781, 0
  br i1 %v1782, label %yes.1783, label %no.1784
yes.1783:
  %v1786 = sub i64 %v1779, 1
  %v1787 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1778, i64 %v1786)
  %v1788 = extractvalue { i64, i1 } %v1787, 0
  %v1789 = extractvalue { i64, i1 } %v1787, 1
  br i1 %v1789, label %yes.1790, label %no.1791
yes.1790:
  %v1793 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 9 to ptr))
  br label %join.1792
no.1791:
  %v1794 = inttoptr i64 %v1788 to ptr
  br label %join.1792
join.1792:
  %v1795 = phi ptr [ %v1793, %yes.1790 ], [ %v1794, %no.1791 ]
  br label %join.1785
no.1784:
  %v1796 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 9 to ptr))
  br label %join.1785
join.1785:
  %v1797 = phi ptr [ %v1795, %join.1792 ], [ %v1796, %no.1784 ]
  %v1798 = ptrtoint ptr %v1797 to i64
  %v1799 = ashr i64 %v1798, 1
  %v1800 = and i64 %v1798, 1
  %v1801 = icmp ne i64 %v1800, 0
  %v1802 = icmp ult i64 %v1799, %v1765
  %v1803 = and i1 %v1801, %v1802
  br i1 %v1803, label %array.valid.1804, label %array.invalid.1805
array.invalid.1805:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1804:
  %v1806 = getelementptr i64, ptr %v1767, i64 %v1799
  %v1807 = load double, ptr %v1806, align 8, !tbaa !4
  %v1808 = ptrtoint ptr %a2 to i64
  %v1809 = ptrtoint ptr inttoptr (i64 11 to ptr) to i64
  %v1810 = and i64 %v1808, %v1809
  %v1811 = and i64 %v1810, 1
  %v1812 = icmp ne i64 %v1811, 0
  br i1 %v1812, label %yes.1813, label %no.1814
yes.1813:
  %v1816 = sub i64 %v1809, 1
  %v1817 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1808, i64 %v1816)
  %v1818 = extractvalue { i64, i1 } %v1817, 0
  %v1819 = extractvalue { i64, i1 } %v1817, 1
  br i1 %v1819, label %yes.1820, label %no.1821
yes.1820:
  %v1823 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 11 to ptr))
  br label %join.1822
no.1821:
  %v1824 = inttoptr i64 %v1818 to ptr
  br label %join.1822
join.1822:
  %v1825 = phi ptr [ %v1823, %yes.1820 ], [ %v1824, %no.1821 ]
  br label %join.1815
no.1814:
  %v1826 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 11 to ptr))
  br label %join.1815
join.1815:
  %v1827 = phi ptr [ %v1825, %join.1822 ], [ %v1826, %no.1814 ]
  %v1828 = ptrtoint ptr %v1827 to i64
  %v1829 = ashr i64 %v1828, 1
  %v1830 = and i64 %v1828, 1
  %v1831 = icmp ne i64 %v1830, 0
  %v1832 = icmp ult i64 %v1829, %v1765
  %v1833 = and i1 %v1831, %v1832
  br i1 %v1833, label %array.valid.1834, label %array.invalid.1835
array.invalid.1835:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1834:
  %v1836 = getelementptr i64, ptr %v1767, i64 %v1829
  %v1837 = load double, ptr %v1836, align 8, !tbaa !4
  %v1838 = ptrtoint ptr %a2 to i64
  %v1839 = ptrtoint ptr inttoptr (i64 13 to ptr) to i64
  %v1840 = and i64 %v1838, %v1839
  %v1841 = and i64 %v1840, 1
  %v1842 = icmp ne i64 %v1841, 0
  br i1 %v1842, label %yes.1843, label %no.1844
yes.1843:
  %v1846 = sub i64 %v1839, 1
  %v1847 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1838, i64 %v1846)
  %v1848 = extractvalue { i64, i1 } %v1847, 0
  %v1849 = extractvalue { i64, i1 } %v1847, 1
  br i1 %v1849, label %yes.1850, label %no.1851
yes.1850:
  %v1853 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 13 to ptr))
  br label %join.1852
no.1851:
  %v1854 = inttoptr i64 %v1848 to ptr
  br label %join.1852
join.1852:
  %v1855 = phi ptr [ %v1853, %yes.1850 ], [ %v1854, %no.1851 ]
  br label %join.1845
no.1844:
  %v1856 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 13 to ptr))
  br label %join.1845
join.1845:
  %v1857 = phi ptr [ %v1855, %join.1852 ], [ %v1856, %no.1844 ]
  %v1858 = ptrtoint ptr %v1857 to i64
  %v1859 = ashr i64 %v1858, 1
  %v1860 = and i64 %v1858, 1
  %v1861 = icmp ne i64 %v1860, 0
  %v1862 = icmp ult i64 %v1859, %v1765
  %v1863 = and i1 %v1861, %v1862
  br i1 %v1863, label %array.valid.1864, label %array.invalid.1865
array.invalid.1865:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1864:
  %v1866 = getelementptr i64, ptr %v1767, i64 %v1859
  %v1867 = load double, ptr %v1866, align 8, !tbaa !4
  %v1868 = ptrtoint ptr %a2 to i64
  %v1869 = ptrtoint ptr inttoptr (i64 15 to ptr) to i64
  %v1870 = and i64 %v1868, %v1869
  %v1871 = and i64 %v1870, 1
  %v1872 = icmp ne i64 %v1871, 0
  br i1 %v1872, label %yes.1873, label %no.1874
yes.1873:
  %v1876 = sub i64 %v1869, 1
  %v1877 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1868, i64 %v1876)
  %v1878 = extractvalue { i64, i1 } %v1877, 0
  %v1879 = extractvalue { i64, i1 } %v1877, 1
  br i1 %v1879, label %yes.1880, label %no.1881
yes.1880:
  %v1883 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 15 to ptr))
  br label %join.1882
no.1881:
  %v1884 = inttoptr i64 %v1878 to ptr
  br label %join.1882
join.1882:
  %v1885 = phi ptr [ %v1883, %yes.1880 ], [ %v1884, %no.1881 ]
  br label %join.1875
no.1874:
  %v1886 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 15 to ptr))
  br label %join.1875
join.1875:
  %v1887 = phi ptr [ %v1885, %join.1882 ], [ %v1886, %no.1874 ]
  %v1888 = fmul double %v1777, %v1867
  %v1889 = fadd double %a3, %v1888
  %v1890 = fmul double %v1807, %v1867
  %v1891 = fadd double %a4, %v1890
  %v1892 = fmul double %v1837, %v1867
  %v1893 = fadd double %a5, %v1892
  %v1894 = musttail call ptr @mlf.numeric.1.pppddd(ptr %a0, ptr %a1, ptr %v1887, double %v1889, double %v1891, double %v1893)
  ret ptr %v1894
}

define private ptr @mlf.numeric.1(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5) alwaysinline {
entry:
  %v1474 = ptrtoint ptr %a2 to i64
  %v1475 = ptrtoint ptr inttoptr (i64 71 to ptr) to i64
  %v1476 = and i64 %v1474, %v1475
  %v1477 = and i64 %v1476, 1
  %v1478 = icmp ne i64 %v1477, 0
  br i1 %v1478, label %yes.1479, label %no.1480
yes.1479:
  %v1482 = icmp eq i64 %v1474, %v1475
  %v1483 = select i1 %v1482, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1481
no.1480:
  %v1484 = call ptr @mlf_eq_int(ptr %a2, ptr inttoptr (i64 71 to ptr))
  br label %join.1481
join.1481:
  %v1485 = phi ptr [ %v1483, %yes.1479 ], [ %v1484, %no.1480 ]
  %v1486 = icmp eq ptr %v1485, inttoptr (i64 6 to ptr)
  br i1 %v1486, label %tail.yes.1487, label %tail.no.1488
tail.yes.1487:
  %v1489 = getelementptr i8, ptr %a3, i64 8
  %v1490 = load double, ptr %v1489, align 8, !tbaa !3
  %v1491 = fsub double 0x0000000000000000, %v1490
  %v1492 = getelementptr i8, ptr %a0, i64 8
  %v1493 = load double, ptr %v1492, align 8, !tbaa !3
  %v1494 = fdiv double %v1491, %v1493
  %v1495 = getelementptr i8, ptr %a1, i64 8
  %v1496 = load i64, ptr %v1495, align 8, !tbaa !3
  %v1497 = getelementptr i8, ptr %a1, i64 16
  %v1498 = load ptr, ptr %v1497, align 8, !tbaa !3
  %v1499 = ptrtoint ptr inttoptr (i64 7 to ptr) to i64
  %v1500 = ashr i64 %v1499, 1
  %v1501 = and i64 %v1499, 1
  %v1502 = icmp ne i64 %v1501, 0
  %v1503 = icmp ult i64 %v1500, %v1496
  %v1504 = and i1 %v1502, %v1503
  br i1 %v1504, label %array.valid.1505, label %array.invalid.1506
array.invalid.1506:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1505:
  %v1507 = getelementptr i64, ptr %v1498, i64 %v1500
  store double %v1494, ptr %v1507, align 8, !tbaa !4
  %v1508 = getelementptr i8, ptr %a4, i64 8
  %v1509 = load double, ptr %v1508, align 8, !tbaa !3
  %v1510 = fsub double 0x0000000000000000, %v1509
  %v1511 = fdiv double %v1510, %v1493
  %v1512 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v1513 = ashr i64 %v1512, 1
  %v1514 = and i64 %v1512, 1
  %v1515 = icmp ne i64 %v1514, 0
  %v1516 = icmp ult i64 %v1513, %v1496
  %v1517 = and i1 %v1515, %v1516
  br i1 %v1517, label %array.valid.1518, label %array.invalid.1519
array.invalid.1519:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1518:
  %v1520 = getelementptr i64, ptr %v1498, i64 %v1513
  store double %v1511, ptr %v1520, align 8, !tbaa !4
  %v1521 = getelementptr i8, ptr %a5, i64 8
  %v1522 = load double, ptr %v1521, align 8, !tbaa !3
  %v1523 = fsub double 0x0000000000000000, %v1522
  %v1524 = fdiv double %v1523, %v1493
  %v1525 = ptrtoint ptr inttoptr (i64 11 to ptr) to i64
  %v1526 = ashr i64 %v1525, 1
  %v1527 = and i64 %v1525, 1
  %v1528 = icmp ne i64 %v1527, 0
  %v1529 = icmp ult i64 %v1526, %v1496
  %v1530 = and i1 %v1528, %v1529
  br i1 %v1530, label %array.valid.1531, label %array.invalid.1532
array.invalid.1532:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1531:
  %v1533 = getelementptr i64, ptr %v1498, i64 %v1526
  store double %v1524, ptr %v1533, align 8, !tbaa !4
  ret ptr inttoptr (i64 4 to ptr)
tail.no.1488:
  %v1534 = ptrtoint ptr %a2 to i64
  %v1535 = ptrtoint ptr inttoptr (i64 7 to ptr) to i64
  %v1536 = and i64 %v1534, %v1535
  %v1537 = and i64 %v1536, 1
  %v1538 = icmp ne i64 %v1537, 0
  br i1 %v1538, label %yes.1539, label %no.1540
yes.1539:
  %v1542 = sub i64 %v1535, 1
  %v1543 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1534, i64 %v1542)
  %v1544 = extractvalue { i64, i1 } %v1543, 0
  %v1545 = extractvalue { i64, i1 } %v1543, 1
  br i1 %v1545, label %yes.1546, label %no.1547
yes.1546:
  %v1549 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 7 to ptr))
  br label %join.1548
no.1547:
  %v1550 = inttoptr i64 %v1544 to ptr
  br label %join.1548
join.1548:
  %v1551 = phi ptr [ %v1549, %yes.1546 ], [ %v1550, %no.1547 ]
  br label %join.1541
no.1540:
  %v1552 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 7 to ptr))
  br label %join.1541
join.1541:
  %v1553 = phi ptr [ %v1551, %join.1548 ], [ %v1552, %no.1540 ]
  %v1554 = getelementptr i8, ptr %a1, i64 8
  %v1555 = load i64, ptr %v1554, align 8, !tbaa !3
  %v1556 = getelementptr i8, ptr %a1, i64 16
  %v1557 = load ptr, ptr %v1556, align 8, !tbaa !3
  %v1558 = ptrtoint ptr %v1553 to i64
  %v1559 = ashr i64 %v1558, 1
  %v1560 = and i64 %v1558, 1
  %v1561 = icmp ne i64 %v1560, 0
  %v1562 = icmp ult i64 %v1559, %v1555
  %v1563 = and i1 %v1561, %v1562
  br i1 %v1563, label %array.valid.1564, label %array.invalid.1565
array.invalid.1565:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1564:
  %v1566 = getelementptr i64, ptr %v1557, i64 %v1559
  %v1567 = load double, ptr %v1566, align 8, !tbaa !4
  %v1568 = ptrtoint ptr %a2 to i64
  %v1569 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v1570 = and i64 %v1568, %v1569
  %v1571 = and i64 %v1570, 1
  %v1572 = icmp ne i64 %v1571, 0
  br i1 %v1572, label %yes.1573, label %no.1574
yes.1573:
  %v1576 = sub i64 %v1569, 1
  %v1577 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1568, i64 %v1576)
  %v1578 = extractvalue { i64, i1 } %v1577, 0
  %v1579 = extractvalue { i64, i1 } %v1577, 1
  br i1 %v1579, label %yes.1580, label %no.1581
yes.1580:
  %v1583 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 9 to ptr))
  br label %join.1582
no.1581:
  %v1584 = inttoptr i64 %v1578 to ptr
  br label %join.1582
join.1582:
  %v1585 = phi ptr [ %v1583, %yes.1580 ], [ %v1584, %no.1581 ]
  br label %join.1575
no.1574:
  %v1586 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 9 to ptr))
  br label %join.1575
join.1575:
  %v1587 = phi ptr [ %v1585, %join.1582 ], [ %v1586, %no.1574 ]
  %v1588 = ptrtoint ptr %v1587 to i64
  %v1589 = ashr i64 %v1588, 1
  %v1590 = and i64 %v1588, 1
  %v1591 = icmp ne i64 %v1590, 0
  %v1592 = icmp ult i64 %v1589, %v1555
  %v1593 = and i1 %v1591, %v1592
  br i1 %v1593, label %array.valid.1594, label %array.invalid.1595
array.invalid.1595:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1594:
  %v1596 = getelementptr i64, ptr %v1557, i64 %v1589
  %v1597 = load double, ptr %v1596, align 8, !tbaa !4
  %v1598 = ptrtoint ptr %a2 to i64
  %v1599 = ptrtoint ptr inttoptr (i64 11 to ptr) to i64
  %v1600 = and i64 %v1598, %v1599
  %v1601 = and i64 %v1600, 1
  %v1602 = icmp ne i64 %v1601, 0
  br i1 %v1602, label %yes.1603, label %no.1604
yes.1603:
  %v1606 = sub i64 %v1599, 1
  %v1607 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1598, i64 %v1606)
  %v1608 = extractvalue { i64, i1 } %v1607, 0
  %v1609 = extractvalue { i64, i1 } %v1607, 1
  br i1 %v1609, label %yes.1610, label %no.1611
yes.1610:
  %v1613 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 11 to ptr))
  br label %join.1612
no.1611:
  %v1614 = inttoptr i64 %v1608 to ptr
  br label %join.1612
join.1612:
  %v1615 = phi ptr [ %v1613, %yes.1610 ], [ %v1614, %no.1611 ]
  br label %join.1605
no.1604:
  %v1616 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 11 to ptr))
  br label %join.1605
join.1605:
  %v1617 = phi ptr [ %v1615, %join.1612 ], [ %v1616, %no.1604 ]
  %v1618 = ptrtoint ptr %v1617 to i64
  %v1619 = ashr i64 %v1618, 1
  %v1620 = and i64 %v1618, 1
  %v1621 = icmp ne i64 %v1620, 0
  %v1622 = icmp ult i64 %v1619, %v1555
  %v1623 = and i1 %v1621, %v1622
  br i1 %v1623, label %array.valid.1624, label %array.invalid.1625
array.invalid.1625:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1624:
  %v1626 = getelementptr i64, ptr %v1557, i64 %v1619
  %v1627 = load double, ptr %v1626, align 8, !tbaa !4
  %v1628 = ptrtoint ptr %a2 to i64
  %v1629 = ptrtoint ptr inttoptr (i64 13 to ptr) to i64
  %v1630 = and i64 %v1628, %v1629
  %v1631 = and i64 %v1630, 1
  %v1632 = icmp ne i64 %v1631, 0
  br i1 %v1632, label %yes.1633, label %no.1634
yes.1633:
  %v1636 = sub i64 %v1629, 1
  %v1637 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1628, i64 %v1636)
  %v1638 = extractvalue { i64, i1 } %v1637, 0
  %v1639 = extractvalue { i64, i1 } %v1637, 1
  br i1 %v1639, label %yes.1640, label %no.1641
yes.1640:
  %v1643 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 13 to ptr))
  br label %join.1642
no.1641:
  %v1644 = inttoptr i64 %v1638 to ptr
  br label %join.1642
join.1642:
  %v1645 = phi ptr [ %v1643, %yes.1640 ], [ %v1644, %no.1641 ]
  br label %join.1635
no.1634:
  %v1646 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 13 to ptr))
  br label %join.1635
join.1635:
  %v1647 = phi ptr [ %v1645, %join.1642 ], [ %v1646, %no.1634 ]
  %v1648 = ptrtoint ptr %v1647 to i64
  %v1649 = ashr i64 %v1648, 1
  %v1650 = and i64 %v1648, 1
  %v1651 = icmp ne i64 %v1650, 0
  %v1652 = icmp ult i64 %v1649, %v1555
  %v1653 = and i1 %v1651, %v1652
  br i1 %v1653, label %array.valid.1654, label %array.invalid.1655
array.invalid.1655:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1654:
  %v1656 = getelementptr i64, ptr %v1557, i64 %v1649
  %v1657 = load double, ptr %v1656, align 8, !tbaa !4
  %v1658 = ptrtoint ptr %a2 to i64
  %v1659 = ptrtoint ptr inttoptr (i64 15 to ptr) to i64
  %v1660 = and i64 %v1658, %v1659
  %v1661 = and i64 %v1660, 1
  %v1662 = icmp ne i64 %v1661, 0
  br i1 %v1662, label %yes.1663, label %no.1664
yes.1663:
  %v1666 = sub i64 %v1659, 1
  %v1667 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1658, i64 %v1666)
  %v1668 = extractvalue { i64, i1 } %v1667, 0
  %v1669 = extractvalue { i64, i1 } %v1667, 1
  br i1 %v1669, label %yes.1670, label %no.1671
yes.1670:
  %v1673 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 15 to ptr))
  br label %join.1672
no.1671:
  %v1674 = inttoptr i64 %v1668 to ptr
  br label %join.1672
join.1672:
  %v1675 = phi ptr [ %v1673, %yes.1670 ], [ %v1674, %no.1671 ]
  br label %join.1665
no.1664:
  %v1676 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 15 to ptr))
  br label %join.1665
join.1665:
  %v1677 = phi ptr [ %v1675, %join.1672 ], [ %v1676, %no.1664 ]
  %v1678 = fmul double %v1567, %v1657
  %v1679 = getelementptr i8, ptr %a3, i64 8
  %v1680 = load double, ptr %v1679, align 8, !tbaa !3
  %v1681 = fadd double %v1680, %v1678
  %v1682 = fmul double %v1597, %v1657
  %v1683 = getelementptr i8, ptr %a4, i64 8
  %v1684 = load double, ptr %v1683, align 8, !tbaa !3
  %v1685 = fadd double %v1684, %v1682
  %v1686 = fmul double %v1627, %v1657
  %v1687 = getelementptr i8, ptr %a5, i64 8
  %v1688 = load double, ptr %v1687, align 8, !tbaa !3
  %v1689 = fadd double %v1688, %v1686
  %v1895 = call ptr @mlf.numeric.1.pppddd(ptr %a0, ptr %a1, ptr %v1677, double %v1681, double %v1685, double %v1689)
  ret ptr %v1895
}

define private ptr @mlf.code.1913(ptr %env, ptr %arg) {
entry:
  %v1914 = getelementptr i8, ptr %env, i64 8
  %v1915 = load ptr, ptr %v1914, align 8, !tbaa !3
  %v1916 = getelementptr i8, ptr %env, i64 16
  %v1917 = load ptr, ptr %v1916, align 8, !tbaa !3
  %v1918 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1918, align 8, !tbaa !3
  %v1919 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1919, align 8, !tbaa !3
  %v1920 = call ptr @mlf_double(double 0x0000000000000000)
  %v1921 = call ptr @mlf.force(ptr %v1917)
  %v1922 = call ptr @mlf_prim2(i64 19, ptr %v1920, ptr %v1921)
  %v1923 = call ptr @mlf.force(ptr %v1915)
  %v1924 = call ptr @mlf_prim2(i64 21, ptr %v1922, ptr %v1923)
  ret ptr %v1924
}

define private ptr @mlf.code.1930(ptr %env, ptr %arg) {
entry:
  %v1931 = call ptr @mlf_prim2(i64 8, ptr inttoptr (i64 1 to ptr), ptr inttoptr (i64 7 to ptr))
  ret ptr %v1931
}

define private ptr @mlf.code.1903(ptr %env, ptr %arg) {
entry:
  %v1904 = getelementptr i8, ptr %env, i64 8
  %v1905 = load ptr, ptr %v1904, align 8, !tbaa !3
  %v1906 = getelementptr i8, ptr %env, i64 16
  %v1907 = load ptr, ptr %v1906, align 8, !tbaa !3
  %v1908 = getelementptr i8, ptr %env, i64 24
  %v1909 = load ptr, ptr %v1908, align 8, !tbaa !3
  %v1910 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1910, align 8, !tbaa !3
  %v1911 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1911, align 8, !tbaa !3
  %v1912 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v1912, align 8, !tbaa !3
  %v1925 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1913, i64 2)
  %v1926 = getelementptr i8, ptr %v1925, i64 16
  %v1927 = load ptr, ptr %v1926, align 8, !tbaa !3
  %v1928 = getelementptr i8, ptr %v1927, i64 8
  store ptr %v1905, ptr %v1928, align 8, !tbaa !3
  %v1929 = getelementptr i8, ptr %v1927, i64 16
  store ptr %v1909, ptr %v1929, align 8, !tbaa !3
  %v1932 = call ptr @mlf_thunk(ptr @mlf.code.1930, ptr null)
  %v1933 = call ptr @mlf_prim3(i64 33, ptr %v1907, ptr %v1932, ptr %v1925)
  ret ptr %v1933
}

define private ptr @mlf.code.1959(ptr %env, ptr %arg) {
entry:
  %v1960 = getelementptr i8, ptr %env, i64 8
  %v1961 = load ptr, ptr %v1960, align 8, !tbaa !3
  %v1962 = getelementptr i8, ptr %env, i64 16
  %v1963 = load ptr, ptr %v1962, align 8, !tbaa !3
  %v1964 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1964, align 8, !tbaa !3
  %v1965 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1965, align 8, !tbaa !3
  %v1966 = call ptr @mlf_double(double 0x0000000000000000)
  %v1967 = call ptr @mlf.force(ptr %v1963)
  %v1968 = call ptr @mlf_prim2(i64 19, ptr %v1966, ptr %v1967)
  %v1969 = call ptr @mlf.force(ptr %v1961)
  %v1970 = call ptr @mlf_prim2(i64 21, ptr %v1968, ptr %v1969)
  ret ptr %v1970
}

define private ptr @mlf.code.1976(ptr %env, ptr %arg) {
entry:
  %v1977 = call ptr @mlf_prim2(i64 8, ptr inttoptr (i64 1 to ptr), ptr inttoptr (i64 9 to ptr))
  ret ptr %v1977
}

define private ptr @mlf.code.1949(ptr %env, ptr %arg) {
entry:
  %v1950 = getelementptr i8, ptr %env, i64 8
  %v1951 = load ptr, ptr %v1950, align 8, !tbaa !3
  %v1952 = getelementptr i8, ptr %env, i64 16
  %v1953 = load ptr, ptr %v1952, align 8, !tbaa !3
  %v1954 = getelementptr i8, ptr %env, i64 24
  %v1955 = load ptr, ptr %v1954, align 8, !tbaa !3
  %v1956 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1956, align 8, !tbaa !3
  %v1957 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1957, align 8, !tbaa !3
  %v1958 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v1958, align 8, !tbaa !3
  %v1971 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1959, i64 2)
  %v1972 = getelementptr i8, ptr %v1971, i64 16
  %v1973 = load ptr, ptr %v1972, align 8, !tbaa !3
  %v1974 = getelementptr i8, ptr %v1973, i64 8
  store ptr %v1951, ptr %v1974, align 8, !tbaa !3
  %v1975 = getelementptr i8, ptr %v1973, i64 16
  store ptr %v1955, ptr %v1975, align 8, !tbaa !3
  %v1978 = call ptr @mlf_thunk(ptr @mlf.code.1976, ptr null)
  %v1979 = call ptr @mlf_prim3(i64 33, ptr %v1953, ptr %v1978, ptr %v1971)
  ret ptr %v1979
}

define private ptr @mlf.code.1993(ptr %env, ptr %arg) {
entry:
  %v1994 = getelementptr i8, ptr %env, i64 8
  %v1995 = load ptr, ptr %v1994, align 8, !tbaa !3
  %v1996 = getelementptr i8, ptr %env, i64 16
  %v1997 = load ptr, ptr %v1996, align 8, !tbaa !3
  %v1998 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1998, align 8, !tbaa !3
  %v1999 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1999, align 8, !tbaa !3
  %v2000 = call ptr @mlf_double(double 0x0000000000000000)
  %v2001 = call ptr @mlf.force(ptr %v1997)
  %v2002 = call ptr @mlf_prim2(i64 19, ptr %v2000, ptr %v2001)
  %v2003 = call ptr @mlf.force(ptr %v1995)
  %v2004 = call ptr @mlf_prim2(i64 21, ptr %v2002, ptr %v2003)
  ret ptr %v2004
}

define private ptr @mlf.code.2010(ptr %env, ptr %arg) {
entry:
  %v2011 = call ptr @mlf_prim2(i64 8, ptr inttoptr (i64 1 to ptr), ptr inttoptr (i64 11 to ptr))
  ret ptr %v2011
}

define private ptr @mlf.code.1986(ptr %env, ptr %arg) {
entry:
  %v1987 = getelementptr i8, ptr %env, i64 8
  %v1988 = load ptr, ptr %v1987, align 8, !tbaa !3
  %v1989 = getelementptr i8, ptr %env, i64 16
  %v1990 = load ptr, ptr %v1989, align 8, !tbaa !3
  %v1991 = getelementptr i8, ptr %env, i64 24
  %v1992 = load ptr, ptr %v1991, align 8, !tbaa !3
  %v2005 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1993, i64 2)
  %v2006 = getelementptr i8, ptr %v2005, i64 16
  %v2007 = load ptr, ptr %v2006, align 8, !tbaa !3
  %v2008 = getelementptr i8, ptr %v2007, i64 8
  store ptr %v1988, ptr %v2008, align 8, !tbaa !3
  %v2009 = getelementptr i8, ptr %v2007, i64 16
  store ptr %v1992, ptr %v2009, align 8, !tbaa !3
  %v2012 = call ptr @mlf_thunk(ptr @mlf.code.2010, ptr null)
  %v2013 = call ptr @mlf_prim3(i64 33, ptr %v1990, ptr %v2012, ptr %v2005)
  ret ptr %v2013
}

define private ptr @mlf.code.1940(ptr %env, ptr %arg) {
entry:
  %v1941 = getelementptr i8, ptr %env, i64 8
  %v1942 = load ptr, ptr %v1941, align 8, !tbaa !3
  %v1943 = getelementptr i8, ptr %env, i64 16
  %v1944 = load ptr, ptr %v1943, align 8, !tbaa !3
  %v1945 = getelementptr i8, ptr %env, i64 24
  %v1946 = load ptr, ptr %v1945, align 8, !tbaa !3
  %v1947 = getelementptr i8, ptr %env, i64 32
  %v1948 = load ptr, ptr %v1947, align 8, !tbaa !3
  %v1980 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1949, i64 3)
  %v1981 = getelementptr i8, ptr %v1980, i64 16
  %v1982 = load ptr, ptr %v1981, align 8, !tbaa !3
  %v1983 = getelementptr i8, ptr %v1982, i64 8
  store ptr %v1942, ptr %v1983, align 8, !tbaa !3
  %v1984 = getelementptr i8, ptr %v1982, i64 16
  store ptr %v1944, ptr %v1984, align 8, !tbaa !3
  %v1985 = getelementptr i8, ptr %v1982, i64 24
  store ptr %v1946, ptr %v1985, align 8, !tbaa !3
  %v2014 = call ptr @mlf_env_new(i64 3)
  %v2015 = getelementptr i8, ptr %v2014, i64 8
  store ptr %v1942, ptr %v2015, align 8, !tbaa !3
  %v2016 = getelementptr i8, ptr %v2014, i64 16
  store ptr %v1944, ptr %v2016, align 8, !tbaa !3
  %v2017 = getelementptr i8, ptr %v2014, i64 24
  store ptr %v1948, ptr %v2017, align 8, !tbaa !3
  %v2018 = call ptr @mlf_closure(ptr @mlf.code.1986, ptr %v2014)
  %v2019 = call ptr @mlf_prim2(i64 1, ptr %v1980, ptr %v2018)
  ret ptr %v2019
}

define private ptr @mlf.code.2034(ptr %env, ptr %arg) {
entry:
  %v2035 = getelementptr i8, ptr %env, i64 8
  %v2036 = load ptr, ptr %v2035, align 8, !tbaa !3
  %v2037 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2037, align 8, !tbaa !3
  %v2038 = call ptr @mlf.force(ptr %v2036)
  %v2039 = call ptr @mlf_prim2(i64 8, ptr %v2038, ptr inttoptr (i64 7 to ptr))
  ret ptr %v2039
}

define private ptr @mlf.code.2027(ptr %env, ptr %arg) {
entry:
  %v2028 = getelementptr i8, ptr %env, i64 8
  %v2029 = load ptr, ptr %v2028, align 8, !tbaa !3
  %v2030 = getelementptr i8, ptr %env, i64 16
  %v2031 = load ptr, ptr %v2030, align 8, !tbaa !3
  %v2032 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2032, align 8, !tbaa !3
  %v2033 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2033, align 8, !tbaa !3
  %v2040 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2034, i64 1)
  %v2041 = getelementptr i8, ptr %v2040, i64 16
  %v2042 = load ptr, ptr %v2041, align 8, !tbaa !3
  %v2043 = getelementptr i8, ptr %v2042, i64 8
  store ptr %v2031, ptr %v2043, align 8, !tbaa !3
  %v2044 = call ptr @mlf_prim2(i64 32, ptr %v2029, ptr %v2040)
  ret ptr %v2044
}

define private ptr @mlf.code.2070(ptr %env, ptr %arg) {
entry:
  %v2071 = getelementptr i8, ptr %env, i64 8
  %v2072 = load ptr, ptr %v2071, align 8, !tbaa !3
  %v2073 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2073, align 8, !tbaa !3
  %v2074 = call ptr @mlf.force(ptr %v2072)
  %v2075 = call ptr @mlf_prim2(i64 8, ptr %v2074, ptr inttoptr (i64 9 to ptr))
  ret ptr %v2075
}

define private ptr @mlf.code.2063(ptr %env, ptr %arg) {
entry:
  %v2064 = getelementptr i8, ptr %env, i64 8
  %v2065 = load ptr, ptr %v2064, align 8, !tbaa !3
  %v2066 = getelementptr i8, ptr %env, i64 16
  %v2067 = load ptr, ptr %v2066, align 8, !tbaa !3
  %v2068 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2068, align 8, !tbaa !3
  %v2069 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2069, align 8, !tbaa !3
  %v2076 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2070, i64 1)
  %v2077 = getelementptr i8, ptr %v2076, i64 16
  %v2078 = load ptr, ptr %v2077, align 8, !tbaa !3
  %v2079 = getelementptr i8, ptr %v2078, i64 8
  store ptr %v2067, ptr %v2079, align 8, !tbaa !3
  %v2080 = call ptr @mlf_prim2(i64 32, ptr %v2065, ptr %v2076)
  ret ptr %v2080
}

define private ptr @mlf.code.2108(ptr %env, ptr %arg) {
entry:
  %v2109 = getelementptr i8, ptr %env, i64 8
  %v2110 = load ptr, ptr %v2109, align 8, !tbaa !3
  %v2111 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2111, align 8, !tbaa !3
  %v2112 = call ptr @mlf.force(ptr %v2110)
  %v2113 = call ptr @mlf_prim2(i64 8, ptr %v2112, ptr inttoptr (i64 11 to ptr))
  ret ptr %v2113
}

define private ptr @mlf.code.2101(ptr %env, ptr %arg) {
entry:
  %v2102 = getelementptr i8, ptr %env, i64 8
  %v2103 = load ptr, ptr %v2102, align 8, !tbaa !3
  %v2104 = getelementptr i8, ptr %env, i64 16
  %v2105 = load ptr, ptr %v2104, align 8, !tbaa !3
  %v2106 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2106, align 8, !tbaa !3
  %v2107 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2107, align 8, !tbaa !3
  %v2114 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2108, i64 1)
  %v2115 = getelementptr i8, ptr %v2114, i64 16
  %v2116 = load ptr, ptr %v2115, align 8, !tbaa !3
  %v2117 = getelementptr i8, ptr %v2116, i64 8
  store ptr %v2105, ptr %v2117, align 8, !tbaa !3
  %v2118 = call ptr @mlf_prim2(i64 32, ptr %v2103, ptr %v2114)
  ret ptr %v2118
}

define private ptr @mlf.code.2148(ptr %env, ptr %arg) {
entry:
  %v2149 = getelementptr i8, ptr %env, i64 8
  %v2150 = load ptr, ptr %v2149, align 8, !tbaa !3
  %v2151 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2151, align 8, !tbaa !3
  %v2152 = call ptr @mlf.force(ptr %v2150)
  %v2153 = call ptr @mlf_prim2(i64 8, ptr %v2152, ptr inttoptr (i64 13 to ptr))
  ret ptr %v2153
}

define private ptr @mlf.code.2141(ptr %env, ptr %arg) {
entry:
  %v2142 = getelementptr i8, ptr %env, i64 8
  %v2143 = load ptr, ptr %v2142, align 8, !tbaa !3
  %v2144 = getelementptr i8, ptr %env, i64 16
  %v2145 = load ptr, ptr %v2144, align 8, !tbaa !3
  %v2146 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2146, align 8, !tbaa !3
  %v2147 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2147, align 8, !tbaa !3
  %v2154 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2148, i64 1)
  %v2155 = getelementptr i8, ptr %v2154, i64 16
  %v2156 = load ptr, ptr %v2155, align 8, !tbaa !3
  %v2157 = getelementptr i8, ptr %v2156, i64 8
  store ptr %v2145, ptr %v2157, align 8, !tbaa !3
  %v2158 = call ptr @mlf_prim2(i64 32, ptr %v2143, ptr %v2154)
  ret ptr %v2158
}

define private ptr @mlf.code.2185(ptr %env, ptr %arg) {
entry:
  %v2186 = getelementptr i8, ptr %env, i64 8
  %v2187 = load ptr, ptr %v2186, align 8, !tbaa !3
  %v2188 = getelementptr i8, ptr %env, i64 16
  %v2189 = load ptr, ptr %v2188, align 8, !tbaa !3
  %v2190 = getelementptr i8, ptr %env, i64 24
  %v2191 = load ptr, ptr %v2190, align 8, !tbaa !3
  %v2192 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2192, align 8, !tbaa !3
  %v2193 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2193, align 8, !tbaa !3
  %v2194 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v2194, align 8, !tbaa !3
  %v2195 = call ptr @mlf.force(ptr %v2187)
  %v2196 = call ptr @mlf.force(ptr %v2189)
  %v2197 = call ptr @mlf.force(ptr %v2191)
  %v2198 = call ptr @mlf_prim2(i64 20, ptr %v2196, ptr %v2197)
  %v2199 = call ptr @mlf_prim2(i64 18, ptr %v2195, ptr %v2198)
  ret ptr %v2199
}

define private ptr @mlf.code.2206(ptr %env, ptr %arg) {
entry:
  %v2207 = getelementptr i8, ptr %env, i64 8
  %v2208 = load ptr, ptr %v2207, align 8, !tbaa !3
  %v2209 = getelementptr i8, ptr %env, i64 16
  %v2210 = load ptr, ptr %v2209, align 8, !tbaa !3
  %v2211 = getelementptr i8, ptr %env, i64 24
  %v2212 = load ptr, ptr %v2211, align 8, !tbaa !3
  %v2213 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2213, align 8, !tbaa !3
  %v2214 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2214, align 8, !tbaa !3
  %v2215 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v2215, align 8, !tbaa !3
  %v2216 = call ptr @mlf.force(ptr %v2208)
  %v2217 = call ptr @mlf.force(ptr %v2210)
  %v2218 = call ptr @mlf.force(ptr %v2212)
  %v2219 = call ptr @mlf_prim2(i64 20, ptr %v2217, ptr %v2218)
  %v2220 = call ptr @mlf_prim2(i64 18, ptr %v2216, ptr %v2219)
  ret ptr %v2220
}

define private ptr @mlf.code.2227(ptr %env, ptr %arg) {
entry:
  %v2228 = getelementptr i8, ptr %env, i64 8
  %v2229 = load ptr, ptr %v2228, align 8, !tbaa !3
  %v2230 = getelementptr i8, ptr %env, i64 16
  %v2231 = load ptr, ptr %v2230, align 8, !tbaa !3
  %v2232 = getelementptr i8, ptr %env, i64 24
  %v2233 = load ptr, ptr %v2232, align 8, !tbaa !3
  %v2234 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2234, align 8, !tbaa !3
  %v2235 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2235, align 8, !tbaa !3
  %v2236 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v2236, align 8, !tbaa !3
  %v2237 = call ptr @mlf.force(ptr %v2229)
  %v2238 = call ptr @mlf.force(ptr %v2231)
  %v2239 = call ptr @mlf.force(ptr %v2233)
  %v2240 = call ptr @mlf_prim2(i64 20, ptr %v2238, ptr %v2239)
  %v2241 = call ptr @mlf_prim2(i64 18, ptr %v2237, ptr %v2240)
  ret ptr %v2241
}

define private ptr @mlf.code.2164(ptr %env, ptr %arg) {
entry:
  %v2165 = getelementptr i8, ptr %env, i64 8
  %v2166 = load ptr, ptr %v2165, align 8, !tbaa !3
  %v2167 = getelementptr i8, ptr %env, i64 16
  %v2168 = load ptr, ptr %v2167, align 8, !tbaa !3
  %v2169 = getelementptr i8, ptr %env, i64 24
  %v2170 = load ptr, ptr %v2169, align 8, !tbaa !3
  %v2171 = getelementptr i8, ptr %env, i64 32
  %v2172 = load ptr, ptr %v2171, align 8, !tbaa !3
  %v2173 = getelementptr i8, ptr %env, i64 40
  %v2174 = load ptr, ptr %v2173, align 8, !tbaa !3
  %v2175 = getelementptr i8, ptr %env, i64 48
  %v2176 = load ptr, ptr %v2175, align 8, !tbaa !3
  %v2177 = getelementptr i8, ptr %env, i64 56
  %v2178 = load ptr, ptr %v2177, align 8, !tbaa !3
  %v2179 = getelementptr i8, ptr %env, i64 64
  %v2180 = load ptr, ptr %v2179, align 8, !tbaa !3
  %v2181 = getelementptr i8, ptr %env, i64 72
  %v2182 = load ptr, ptr %v2181, align 8, !tbaa !3
  %v2183 = call ptr @mlf.force(ptr %v2170)
  %v2184 = call ptr @mlf_prim2(i64 8, ptr %v2183, ptr inttoptr (i64 15 to ptr))
  %v2200 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2185, i64 3)
  %v2201 = getelementptr i8, ptr %v2200, i64 16
  %v2202 = load ptr, ptr %v2201, align 8, !tbaa !3
  %v2203 = getelementptr i8, ptr %v2202, i64 8
  store ptr %v2172, ptr %v2203, align 8, !tbaa !3
  %v2204 = getelementptr i8, ptr %v2202, i64 16
  store ptr %v2178, ptr %v2204, align 8, !tbaa !3
  %v2205 = getelementptr i8, ptr %v2202, i64 24
  store ptr %arg, ptr %v2205, align 8, !tbaa !3
  %v2221 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2206, i64 3)
  %v2222 = getelementptr i8, ptr %v2221, i64 16
  %v2223 = load ptr, ptr %v2222, align 8, !tbaa !3
  %v2224 = getelementptr i8, ptr %v2223, i64 8
  store ptr %v2174, ptr %v2224, align 8, !tbaa !3
  %v2225 = getelementptr i8, ptr %v2223, i64 16
  store ptr %v2180, ptr %v2225, align 8, !tbaa !3
  %v2226 = getelementptr i8, ptr %v2223, i64 24
  store ptr %arg, ptr %v2226, align 8, !tbaa !3
  %v2242 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2227, i64 3)
  %v2243 = getelementptr i8, ptr %v2242, i64 16
  %v2244 = load ptr, ptr %v2243, align 8, !tbaa !3
  %v2245 = getelementptr i8, ptr %v2244, i64 8
  store ptr %v2176, ptr %v2245, align 8, !tbaa !3
  %v2246 = getelementptr i8, ptr %v2244, i64 16
  store ptr %v2182, ptr %v2246, align 8, !tbaa !3
  %v2247 = getelementptr i8, ptr %v2244, i64 24
  store ptr %arg, ptr %v2247, align 8, !tbaa !3
  %v2248 = call ptr @mlf_env_new(i64 6)
  %v2249 = getelementptr i8, ptr %v2248, i64 8
  store ptr %v2166, ptr %v2249, align 8, !tbaa !3
  %v2250 = getelementptr i8, ptr %v2248, i64 16
  store ptr %v2168, ptr %v2250, align 8, !tbaa !3
  %v2251 = getelementptr i8, ptr %v2248, i64 24
  store ptr %v2184, ptr %v2251, align 8, !tbaa !3
  %v2252 = getelementptr i8, ptr %v2248, i64 32
  store ptr %v2200, ptr %v2252, align 8, !tbaa !3
  %v2253 = getelementptr i8, ptr %v2248, i64 40
  store ptr %v2221, ptr %v2253, align 8, !tbaa !3
  %v2254 = getelementptr i8, ptr %v2248, i64 48
  store ptr %v2242, ptr %v2254, align 8, !tbaa !3
  %v2255 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1440, ptr %v2248)
  ret ptr %v2255
}

define private ptr @mlf.code.2124(ptr %env, ptr %arg) {
entry:
  %v2125 = getelementptr i8, ptr %env, i64 8
  %v2126 = load ptr, ptr %v2125, align 8, !tbaa !3
  %v2127 = getelementptr i8, ptr %env, i64 16
  %v2128 = load ptr, ptr %v2127, align 8, !tbaa !3
  %v2129 = getelementptr i8, ptr %env, i64 24
  %v2130 = load ptr, ptr %v2129, align 8, !tbaa !3
  %v2131 = getelementptr i8, ptr %env, i64 32
  %v2132 = load ptr, ptr %v2131, align 8, !tbaa !3
  %v2133 = getelementptr i8, ptr %env, i64 40
  %v2134 = load ptr, ptr %v2133, align 8, !tbaa !3
  %v2135 = getelementptr i8, ptr %env, i64 48
  %v2136 = load ptr, ptr %v2135, align 8, !tbaa !3
  %v2137 = getelementptr i8, ptr %env, i64 56
  %v2138 = load ptr, ptr %v2137, align 8, !tbaa !3
  %v2139 = getelementptr i8, ptr %env, i64 64
  %v2140 = load ptr, ptr %v2139, align 8, !tbaa !3
  %v2159 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2141, i64 2)
  %v2160 = getelementptr i8, ptr %v2159, i64 16
  %v2161 = load ptr, ptr %v2160, align 8, !tbaa !3
  %v2162 = getelementptr i8, ptr %v2161, i64 8
  store ptr %v2128, ptr %v2162, align 8, !tbaa !3
  %v2163 = getelementptr i8, ptr %v2161, i64 16
  store ptr %v2130, ptr %v2163, align 8, !tbaa !3
  %v2256 = call ptr @mlf_env_new(i64 9)
  %v2257 = getelementptr i8, ptr %v2256, i64 8
  store ptr %v2126, ptr %v2257, align 8, !tbaa !3
  %v2258 = getelementptr i8, ptr %v2256, i64 16
  store ptr %v2128, ptr %v2258, align 8, !tbaa !3
  %v2259 = getelementptr i8, ptr %v2256, i64 24
  store ptr %v2130, ptr %v2259, align 8, !tbaa !3
  %v2260 = getelementptr i8, ptr %v2256, i64 32
  store ptr %v2132, ptr %v2260, align 8, !tbaa !3
  %v2261 = getelementptr i8, ptr %v2256, i64 40
  store ptr %v2134, ptr %v2261, align 8, !tbaa !3
  %v2262 = getelementptr i8, ptr %v2256, i64 48
  store ptr %v2136, ptr %v2262, align 8, !tbaa !3
  %v2263 = getelementptr i8, ptr %v2256, i64 56
  store ptr %v2138, ptr %v2263, align 8, !tbaa !3
  %v2264 = getelementptr i8, ptr %v2256, i64 64
  store ptr %v2140, ptr %v2264, align 8, !tbaa !3
  %v2265 = getelementptr i8, ptr %v2256, i64 72
  store ptr %arg, ptr %v2265, align 8, !tbaa !3
  %v2266 = call ptr @mlf_closure(ptr @mlf.code.2164, ptr %v2256)
  %v2267 = call ptr @mlf_prim2(i64 1, ptr %v2159, ptr %v2266)
  ret ptr %v2267
}

define private ptr @mlf.code.2086(ptr %env, ptr %arg) {
entry:
  %v2087 = getelementptr i8, ptr %env, i64 8
  %v2088 = load ptr, ptr %v2087, align 8, !tbaa !3
  %v2089 = getelementptr i8, ptr %env, i64 16
  %v2090 = load ptr, ptr %v2089, align 8, !tbaa !3
  %v2091 = getelementptr i8, ptr %env, i64 24
  %v2092 = load ptr, ptr %v2091, align 8, !tbaa !3
  %v2093 = getelementptr i8, ptr %env, i64 32
  %v2094 = load ptr, ptr %v2093, align 8, !tbaa !3
  %v2095 = getelementptr i8, ptr %env, i64 40
  %v2096 = load ptr, ptr %v2095, align 8, !tbaa !3
  %v2097 = getelementptr i8, ptr %env, i64 48
  %v2098 = load ptr, ptr %v2097, align 8, !tbaa !3
  %v2099 = getelementptr i8, ptr %env, i64 56
  %v2100 = load ptr, ptr %v2099, align 8, !tbaa !3
  %v2119 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2101, i64 2)
  %v2120 = getelementptr i8, ptr %v2119, i64 16
  %v2121 = load ptr, ptr %v2120, align 8, !tbaa !3
  %v2122 = getelementptr i8, ptr %v2121, i64 8
  store ptr %v2090, ptr %v2122, align 8, !tbaa !3
  %v2123 = getelementptr i8, ptr %v2121, i64 16
  store ptr %v2092, ptr %v2123, align 8, !tbaa !3
  %v2268 = call ptr @mlf_env_new(i64 8)
  %v2269 = getelementptr i8, ptr %v2268, i64 8
  store ptr %v2088, ptr %v2269, align 8, !tbaa !3
  %v2270 = getelementptr i8, ptr %v2268, i64 16
  store ptr %v2090, ptr %v2270, align 8, !tbaa !3
  %v2271 = getelementptr i8, ptr %v2268, i64 24
  store ptr %v2092, ptr %v2271, align 8, !tbaa !3
  %v2272 = getelementptr i8, ptr %v2268, i64 32
  store ptr %v2094, ptr %v2272, align 8, !tbaa !3
  %v2273 = getelementptr i8, ptr %v2268, i64 40
  store ptr %v2096, ptr %v2273, align 8, !tbaa !3
  %v2274 = getelementptr i8, ptr %v2268, i64 48
  store ptr %v2098, ptr %v2274, align 8, !tbaa !3
  %v2275 = getelementptr i8, ptr %v2268, i64 56
  store ptr %v2100, ptr %v2275, align 8, !tbaa !3
  %v2276 = getelementptr i8, ptr %v2268, i64 64
  store ptr %arg, ptr %v2276, align 8, !tbaa !3
  %v2277 = call ptr @mlf_closure(ptr @mlf.code.2124, ptr %v2268)
  %v2278 = call ptr @mlf_prim2(i64 1, ptr %v2119, ptr %v2277)
  ret ptr %v2278
}

define private ptr @mlf.code.2050(ptr %env, ptr %arg) {
entry:
  %v2051 = getelementptr i8, ptr %env, i64 8
  %v2052 = load ptr, ptr %v2051, align 8, !tbaa !3
  %v2053 = getelementptr i8, ptr %env, i64 16
  %v2054 = load ptr, ptr %v2053, align 8, !tbaa !3
  %v2055 = getelementptr i8, ptr %env, i64 24
  %v2056 = load ptr, ptr %v2055, align 8, !tbaa !3
  %v2057 = getelementptr i8, ptr %env, i64 32
  %v2058 = load ptr, ptr %v2057, align 8, !tbaa !3
  %v2059 = getelementptr i8, ptr %env, i64 40
  %v2060 = load ptr, ptr %v2059, align 8, !tbaa !3
  %v2061 = getelementptr i8, ptr %env, i64 48
  %v2062 = load ptr, ptr %v2061, align 8, !tbaa !3
  %v2081 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2063, i64 2)
  %v2082 = getelementptr i8, ptr %v2081, i64 16
  %v2083 = load ptr, ptr %v2082, align 8, !tbaa !3
  %v2084 = getelementptr i8, ptr %v2083, i64 8
  store ptr %v2054, ptr %v2084, align 8, !tbaa !3
  %v2085 = getelementptr i8, ptr %v2083, i64 16
  store ptr %v2056, ptr %v2085, align 8, !tbaa !3
  %v2279 = call ptr @mlf_env_new(i64 7)
  %v2280 = getelementptr i8, ptr %v2279, i64 8
  store ptr %v2052, ptr %v2280, align 8, !tbaa !3
  %v2281 = getelementptr i8, ptr %v2279, i64 16
  store ptr %v2054, ptr %v2281, align 8, !tbaa !3
  %v2282 = getelementptr i8, ptr %v2279, i64 24
  store ptr %v2056, ptr %v2282, align 8, !tbaa !3
  %v2283 = getelementptr i8, ptr %v2279, i64 32
  store ptr %v2058, ptr %v2283, align 8, !tbaa !3
  %v2284 = getelementptr i8, ptr %v2279, i64 40
  store ptr %v2060, ptr %v2284, align 8, !tbaa !3
  %v2285 = getelementptr i8, ptr %v2279, i64 48
  store ptr %v2062, ptr %v2285, align 8, !tbaa !3
  %v2286 = getelementptr i8, ptr %v2279, i64 56
  store ptr %arg, ptr %v2286, align 8, !tbaa !3
  %v2287 = call ptr @mlf_closure(ptr @mlf.code.2086, ptr %v2279)
  %v2288 = call ptr @mlf_prim2(i64 1, ptr %v2081, ptr %v2287)
  ret ptr %v2288
}

define private ptr @mlf.worker.1(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5) {
entry:
  %v1898 = call ptr @mlf_prim2(i64 10, ptr %a2, ptr inttoptr (i64 71 to ptr))
  %v1899 = icmp eq ptr %v1898, inttoptr (i64 6 to ptr)
  br i1 %v1899, label %yes.1900, label %no.1901
yes.1900:
  %v1934 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1903, i64 3)
  %v1935 = getelementptr i8, ptr %v1934, i64 16
  %v1936 = load ptr, ptr %v1935, align 8, !tbaa !3
  %v1937 = getelementptr i8, ptr %v1936, i64 8
  store ptr %a0, ptr %v1937, align 8, !tbaa !3
  %v1938 = getelementptr i8, ptr %v1936, i64 16
  store ptr %a1, ptr %v1938, align 8, !tbaa !3
  %v1939 = getelementptr i8, ptr %v1936, i64 24
  store ptr %a3, ptr %v1939, align 8, !tbaa !3
  %v2020 = call ptr @mlf_env_new(i64 4)
  %v2021 = getelementptr i8, ptr %v2020, i64 8
  store ptr %a0, ptr %v2021, align 8, !tbaa !3
  %v2022 = getelementptr i8, ptr %v2020, i64 16
  store ptr %a1, ptr %v2022, align 8, !tbaa !3
  %v2023 = getelementptr i8, ptr %v2020, i64 24
  store ptr %a4, ptr %v2023, align 8, !tbaa !3
  %v2024 = getelementptr i8, ptr %v2020, i64 32
  store ptr %a5, ptr %v2024, align 8, !tbaa !3
  %v2025 = call ptr @mlf_closure(ptr @mlf.code.1940, ptr %v2020)
  %v2026 = call ptr @mlf_prim2(i64 1, ptr %v1934, ptr %v2025)
  br label %join.1902
no.1901:
  %v2045 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2027, i64 2)
  %v2046 = getelementptr i8, ptr %v2045, i64 16
  %v2047 = load ptr, ptr %v2046, align 8, !tbaa !3
  %v2048 = getelementptr i8, ptr %v2047, i64 8
  store ptr %a1, ptr %v2048, align 8, !tbaa !3
  %v2049 = getelementptr i8, ptr %v2047, i64 16
  store ptr %a2, ptr %v2049, align 8, !tbaa !3
  %v2289 = call ptr @mlf_env_new(i64 6)
  %v2290 = getelementptr i8, ptr %v2289, i64 8
  store ptr %a0, ptr %v2290, align 8, !tbaa !3
  %v2291 = getelementptr i8, ptr %v2289, i64 16
  store ptr %a1, ptr %v2291, align 8, !tbaa !3
  %v2292 = getelementptr i8, ptr %v2289, i64 24
  store ptr %a2, ptr %v2292, align 8, !tbaa !3
  %v2293 = getelementptr i8, ptr %v2289, i64 32
  store ptr %a3, ptr %v2293, align 8, !tbaa !3
  %v2294 = getelementptr i8, ptr %v2289, i64 40
  store ptr %a4, ptr %v2294, align 8, !tbaa !3
  %v2295 = getelementptr i8, ptr %v2289, i64 48
  store ptr %a5, ptr %v2295, align 8, !tbaa !3
  %v2296 = call ptr @mlf_closure(ptr @mlf.code.2050, ptr %v2289)
  %v2297 = call ptr @mlf_prim2(i64 1, ptr %v2045, ptr %v2296)
  br label %join.1902
join.1902:
  %v2298 = phi ptr [ %v2026, %yes.1900 ], [ %v2297, %no.1901 ]
  ret ptr %v2298
}

define private ptr @mlf.numeric.entry.1440(ptr %env, ptr %arg) {
entry:
  %v1441 = getelementptr i8, ptr %env, i64 8
  %v1442 = load ptr, ptr %v1441, align 8, !tbaa !3
  %v1443 = getelementptr i8, ptr %env, i64 16
  %v1444 = load ptr, ptr %v1443, align 8, !tbaa !3
  %v1445 = getelementptr i8, ptr %env, i64 24
  %v1446 = load ptr, ptr %v1445, align 8, !tbaa !3
  %v1447 = getelementptr i8, ptr %env, i64 32
  %v1448 = load ptr, ptr %v1447, align 8, !tbaa !3
  %v1449 = getelementptr i8, ptr %env, i64 40
  %v1450 = load ptr, ptr %v1449, align 8, !tbaa !3
  %v1451 = getelementptr i8, ptr %env, i64 48
  %v1452 = load ptr, ptr %v1451, align 8, !tbaa !3
  %v1453 = call ptr @mlf_peek(ptr %v1442)
  %v1454 = call ptr @mlf_peek(ptr %v1444)
  %v1455 = call ptr @mlf_peek(ptr %v1446)
  %v1456 = call ptr @mlf_peek(ptr %v1448)
  %v1457 = call ptr @mlf_peek(ptr %v1450)
  %v1458 = call ptr @mlf_peek(ptr %v1452)
  %v1459 = icmp ne ptr %v1453, null
  %v1460 = icmp ne ptr %v1454, null
  %v1461 = icmp ne ptr %v1455, null
  %v1462 = icmp ne ptr %v1456, null
  %v1463 = icmp ne ptr %v1457, null
  %v1464 = icmp ne ptr %v1458, null
  %v1465 = and i1 true, %v1459
  %v1466 = and i1 %v1465, %v1460
  %v1467 = and i1 %v1466, %v1461
  %v1468 = and i1 %v1467, %v1462
  %v1469 = and i1 %v1468, %v1463
  %v1470 = and i1 %v1469, %v1464
  br i1 %v1470, label %yes.1471, label %no.1472
yes.1471:
  %v1896 = call ptr @mlf.numeric.1(ptr %v1453, ptr %v1454, ptr %v1455, ptr %v1456, ptr %v1457, ptr %v1458)
  %v1897 = call ptr @mlf_prim1(i64 0, ptr %v1896)
  br label %join.1473
no.1472:
  %v2299 = call ptr @mlf.force(ptr %v1446)
  %v2300 = call ptr @mlf.worker.1(ptr %v1442, ptr %v1444, ptr %v2299, ptr %v1448, ptr %v1450, ptr %v1452)
  br label %join.1473
join.1473:
  %v2301 = phi ptr [ %v1897, %yes.1471 ], [ %v2300, %no.1472 ]
  ret ptr %v2301
}

define private ptr @mlf.code.1433(ptr %env, ptr %arg) {
entry:
  %v1434 = getelementptr i8, ptr %env, i64 8
  %v1435 = load ptr, ptr %v1434, align 8, !tbaa !3
  %v1436 = getelementptr i8, ptr %env, i64 16
  %v1437 = load ptr, ptr %v1436, align 8, !tbaa !3
  %v1438 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1438, align 8, !tbaa !3
  %v1439 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1439, align 8, !tbaa !3
  %v2302 = call ptr @mlf_double(double 0x0000000000000000)
  %v2303 = call ptr @mlf_double(double 0x0000000000000000)
  %v2304 = call ptr @mlf_double(double 0x0000000000000000)
  %v2305 = call ptr @mlf_env_new(i64 6)
  %v2306 = getelementptr i8, ptr %v2305, i64 8
  store ptr %v1435, ptr %v2306, align 8, !tbaa !3
  %v2307 = getelementptr i8, ptr %v2305, i64 16
  store ptr %v1437, ptr %v2307, align 8, !tbaa !3
  %v2308 = getelementptr i8, ptr %v2305, i64 24
  store ptr inttoptr (i64 1 to ptr), ptr %v2308, align 8, !tbaa !3
  %v2309 = getelementptr i8, ptr %v2305, i64 32
  store ptr %v2302, ptr %v2309, align 8, !tbaa !3
  %v2310 = getelementptr i8, ptr %v2305, i64 40
  store ptr %v2303, ptr %v2310, align 8, !tbaa !3
  %v2311 = getelementptr i8, ptr %v2305, i64 48
  store ptr %v2304, ptr %v2311, align 8, !tbaa !3
  %v2312 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1440, ptr %v2305)
  ret ptr %v2312
}

define private ptr @mlf.numeric.16.pppd(ptr %a0, ptr %a1, ptr %a2, double %a3) alwaysinline {
entry:
  %v2515 = ptrtoint ptr %a2 to i64
  %v2516 = ptrtoint ptr inttoptr (i64 71 to ptr) to i64
  %v2517 = and i64 %v2515, %v2516
  %v2518 = and i64 %v2517, 1
  %v2519 = icmp ne i64 %v2518, 0
  br i1 %v2519, label %yes.2520, label %no.2521
yes.2520:
  %v2523 = icmp eq i64 %v2515, %v2516
  %v2524 = select i1 %v2523, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.2522
no.2521:
  %v2525 = call ptr @mlf_eq_int(ptr %a2, ptr inttoptr (i64 71 to ptr))
  br label %join.2522
join.2522:
  %v2526 = phi ptr [ %v2524, %yes.2520 ], [ %v2525, %no.2521 ]
  %v2527 = icmp eq ptr %v2526, inttoptr (i64 6 to ptr)
  br i1 %v2527, label %tail.yes.2528, label %tail.no.2529
tail.yes.2528:
  %v2530 = call ptr @mlf_double(double %a3)
  ret ptr %v2530
tail.no.2529:
  %v2531 = getelementptr i8, ptr %a0, i64 8
  %v2532 = load i64, ptr %v2531, align 8, !tbaa !3
  %v2533 = getelementptr i8, ptr %a0, i64 16
  %v2534 = load ptr, ptr %v2533, align 8, !tbaa !3
  %v2535 = ptrtoint ptr %a1 to i64
  %v2536 = ashr i64 %v2535, 1
  %v2537 = and i64 %v2535, 1
  %v2538 = icmp ne i64 %v2537, 0
  %v2539 = icmp ult i64 %v2536, %v2532
  %v2540 = and i1 %v2538, %v2539
  br i1 %v2540, label %array.valid.2541, label %array.invalid.2542
array.invalid.2542:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2541:
  %v2543 = getelementptr i64, ptr %v2534, i64 %v2536
  %v2544 = load double, ptr %v2543, align 8, !tbaa !4
  %v2545 = ptrtoint ptr %a1 to i64
  %v2546 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2547 = sub i64 %v2546, 1
  %v2548 = add nsw i64 %v2545, %v2547
  %v2549 = inttoptr i64 %v2548 to ptr
  %v2550 = ptrtoint ptr %v2549 to i64
  %v2551 = ashr i64 %v2550, 1
  %v2552 = and i64 %v2550, 1
  %v2553 = icmp ne i64 %v2552, 0
  %v2554 = icmp ult i64 %v2551, %v2532
  %v2555 = and i1 %v2553, %v2554
  br i1 %v2555, label %array.valid.2556, label %array.invalid.2557
array.invalid.2557:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2556:
  %v2558 = getelementptr i64, ptr %v2534, i64 %v2551
  %v2559 = load double, ptr %v2558, align 8, !tbaa !4
  %v2560 = ptrtoint ptr %a1 to i64
  %v2561 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v2562 = sub i64 %v2561, 1
  %v2563 = add nsw i64 %v2560, %v2562
  %v2564 = inttoptr i64 %v2563 to ptr
  %v2565 = ptrtoint ptr %v2564 to i64
  %v2566 = ashr i64 %v2565, 1
  %v2567 = and i64 %v2565, 1
  %v2568 = icmp ne i64 %v2567, 0
  %v2569 = icmp ult i64 %v2566, %v2532
  %v2570 = and i1 %v2568, %v2569
  br i1 %v2570, label %array.valid.2571, label %array.invalid.2572
array.invalid.2572:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2571:
  %v2573 = getelementptr i64, ptr %v2534, i64 %v2566
  %v2574 = load double, ptr %v2573, align 8, !tbaa !4
  %v2575 = ptrtoint ptr %a1 to i64
  %v2576 = ptrtoint ptr inttoptr (i64 13 to ptr) to i64
  %v2577 = sub i64 %v2576, 1
  %v2578 = add nsw i64 %v2575, %v2577
  %v2579 = inttoptr i64 %v2578 to ptr
  %v2580 = ptrtoint ptr %v2579 to i64
  %v2581 = ashr i64 %v2580, 1
  %v2582 = and i64 %v2580, 1
  %v2583 = icmp ne i64 %v2582, 0
  %v2584 = icmp ult i64 %v2581, %v2532
  %v2585 = and i1 %v2583, %v2584
  br i1 %v2585, label %array.valid.2586, label %array.invalid.2587
array.invalid.2587:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2586:
  %v2588 = getelementptr i64, ptr %v2534, i64 %v2581
  %v2589 = load double, ptr %v2588, align 8, !tbaa !4
  %v2590 = ptrtoint ptr %a2 to i64
  %v2591 = ashr i64 %v2590, 1
  %v2592 = and i64 %v2590, 1
  %v2593 = icmp ne i64 %v2592, 0
  %v2594 = icmp ult i64 %v2591, %v2532
  %v2595 = and i1 %v2593, %v2594
  br i1 %v2595, label %array.valid.2596, label %array.invalid.2597
array.invalid.2597:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2596:
  %v2598 = getelementptr i64, ptr %v2534, i64 %v2591
  %v2599 = load double, ptr %v2598, align 8, !tbaa !4
  %v2600 = ptrtoint ptr %a2 to i64
  %v2601 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2602 = sub i64 %v2601, 1
  %v2603 = add nsw i64 %v2600, %v2602
  %v2604 = inttoptr i64 %v2603 to ptr
  %v2605 = ptrtoint ptr %v2604 to i64
  %v2606 = ashr i64 %v2605, 1
  %v2607 = and i64 %v2605, 1
  %v2608 = icmp ne i64 %v2607, 0
  %v2609 = icmp ult i64 %v2606, %v2532
  %v2610 = and i1 %v2608, %v2609
  br i1 %v2610, label %array.valid.2611, label %array.invalid.2612
array.invalid.2612:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2611:
  %v2613 = getelementptr i64, ptr %v2534, i64 %v2606
  %v2614 = load double, ptr %v2613, align 8, !tbaa !4
  %v2615 = ptrtoint ptr %a2 to i64
  %v2616 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v2617 = sub i64 %v2616, 1
  %v2618 = add nsw i64 %v2615, %v2617
  %v2619 = inttoptr i64 %v2618 to ptr
  %v2620 = ptrtoint ptr %v2619 to i64
  %v2621 = ashr i64 %v2620, 1
  %v2622 = and i64 %v2620, 1
  %v2623 = icmp ne i64 %v2622, 0
  %v2624 = icmp ult i64 %v2621, %v2532
  %v2625 = and i1 %v2623, %v2624
  br i1 %v2625, label %array.valid.2626, label %array.invalid.2627
array.invalid.2627:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2626:
  %v2628 = getelementptr i64, ptr %v2534, i64 %v2621
  %v2629 = load double, ptr %v2628, align 8, !tbaa !4
  %v2630 = ptrtoint ptr %a2 to i64
  %v2631 = ptrtoint ptr inttoptr (i64 13 to ptr) to i64
  %v2632 = sub i64 %v2631, 1
  %v2633 = add nsw i64 %v2630, %v2632
  %v2634 = inttoptr i64 %v2633 to ptr
  %v2635 = ptrtoint ptr %v2634 to i64
  %v2636 = ashr i64 %v2635, 1
  %v2637 = and i64 %v2635, 1
  %v2638 = icmp ne i64 %v2637, 0
  %v2639 = icmp ult i64 %v2636, %v2532
  %v2640 = and i1 %v2638, %v2639
  br i1 %v2640, label %array.valid.2641, label %array.invalid.2642
array.invalid.2642:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2641:
  %v2643 = getelementptr i64, ptr %v2534, i64 %v2636
  %v2644 = load double, ptr %v2643, align 8, !tbaa !4
  %v2645 = fsub double %v2544, %v2599
  %v2646 = fsub double %v2559, %v2614
  %v2647 = fsub double %v2574, %v2629
  %v2648 = fmul double %v2645, %v2645
  %v2649 = fmul double %v2646, %v2646
  %v2650 = fadd double %v2648, %v2649
  %v2651 = fmul double %v2647, %v2647
  %v2652 = fadd double %v2650, %v2651
  %v2653 = call double @llvm.sqrt.f64(double %v2652)
  %v2654 = ptrtoint ptr %a2 to i64
  %v2655 = ptrtoint ptr inttoptr (i64 15 to ptr) to i64
  %v2656 = sub i64 %v2655, 1
  %v2657 = add nsw i64 %v2654, %v2656
  %v2658 = inttoptr i64 %v2657 to ptr
  %v2659 = fmul double %v2589, %v2644
  %v2660 = fdiv double %v2659, %v2653
  %v2661 = fsub double %a3, %v2660
  %v2662 = musttail call ptr @mlf.numeric.16.pppd(ptr %a0, ptr %a1, ptr %v2658, double %v2661)
  ret ptr %v2662
}

define private ptr @mlf.numeric.33(ptr %a0, ptr %a1, ptr %a2) alwaysinline {
entry:
  %v2346 = ptrtoint ptr %a1 to i64
  %v2347 = ptrtoint ptr inttoptr (i64 71 to ptr) to i64
  %v2348 = and i64 %v2346, %v2347
  %v2349 = and i64 %v2348, 1
  %v2350 = icmp ne i64 %v2349, 0
  br i1 %v2350, label %yes.2351, label %no.2352
yes.2351:
  %v2354 = icmp eq i64 %v2346, %v2347
  %v2355 = select i1 %v2354, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.2353
no.2352:
  %v2356 = call ptr @mlf_eq_int(ptr %a1, ptr inttoptr (i64 71 to ptr))
  br label %join.2353
join.2353:
  %v2357 = phi ptr [ %v2355, %yes.2351 ], [ %v2356, %no.2352 ]
  %v2358 = icmp eq ptr %v2357, inttoptr (i64 6 to ptr)
  br i1 %v2358, label %tail.yes.2359, label %tail.no.2360
tail.yes.2359:
  ret ptr %a2
tail.no.2360:
  %v2361 = ptrtoint ptr %a1 to i64
  %v2362 = ptrtoint ptr inttoptr (i64 7 to ptr) to i64
  %v2363 = and i64 %v2361, %v2362
  %v2364 = and i64 %v2363, 1
  %v2365 = icmp ne i64 %v2364, 0
  br i1 %v2365, label %yes.2366, label %no.2367
yes.2366:
  %v2369 = sub i64 %v2362, 1
  %v2370 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2361, i64 %v2369)
  %v2371 = extractvalue { i64, i1 } %v2370, 0
  %v2372 = extractvalue { i64, i1 } %v2370, 1
  br i1 %v2372, label %yes.2373, label %no.2374
yes.2373:
  %v2376 = call ptr @mlf_add_int(ptr %a1, ptr inttoptr (i64 7 to ptr))
  br label %join.2375
no.2374:
  %v2377 = inttoptr i64 %v2371 to ptr
  br label %join.2375
join.2375:
  %v2378 = phi ptr [ %v2376, %yes.2373 ], [ %v2377, %no.2374 ]
  br label %join.2368
no.2367:
  %v2379 = call ptr @mlf_add_int(ptr %a1, ptr inttoptr (i64 7 to ptr))
  br label %join.2368
join.2368:
  %v2380 = phi ptr [ %v2378, %join.2375 ], [ %v2379, %no.2367 ]
  %v2381 = getelementptr i8, ptr %a0, i64 8
  %v2382 = load i64, ptr %v2381, align 8, !tbaa !3
  %v2383 = getelementptr i8, ptr %a0, i64 16
  %v2384 = load ptr, ptr %v2383, align 8, !tbaa !3
  %v2385 = ptrtoint ptr %v2380 to i64
  %v2386 = ashr i64 %v2385, 1
  %v2387 = and i64 %v2385, 1
  %v2388 = icmp ne i64 %v2387, 0
  %v2389 = icmp ult i64 %v2386, %v2382
  %v2390 = and i1 %v2388, %v2389
  br i1 %v2390, label %array.valid.2391, label %array.invalid.2392
array.invalid.2392:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2391:
  %v2393 = getelementptr i64, ptr %v2384, i64 %v2386
  %v2394 = load double, ptr %v2393, align 8, !tbaa !4
  %v2395 = ptrtoint ptr %a1 to i64
  %v2396 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v2397 = and i64 %v2395, %v2396
  %v2398 = and i64 %v2397, 1
  %v2399 = icmp ne i64 %v2398, 0
  br i1 %v2399, label %yes.2400, label %no.2401
yes.2400:
  %v2403 = sub i64 %v2396, 1
  %v2404 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2395, i64 %v2403)
  %v2405 = extractvalue { i64, i1 } %v2404, 0
  %v2406 = extractvalue { i64, i1 } %v2404, 1
  br i1 %v2406, label %yes.2407, label %no.2408
yes.2407:
  %v2410 = call ptr @mlf_add_int(ptr %a1, ptr inttoptr (i64 9 to ptr))
  br label %join.2409
no.2408:
  %v2411 = inttoptr i64 %v2405 to ptr
  br label %join.2409
join.2409:
  %v2412 = phi ptr [ %v2410, %yes.2407 ], [ %v2411, %no.2408 ]
  br label %join.2402
no.2401:
  %v2413 = call ptr @mlf_add_int(ptr %a1, ptr inttoptr (i64 9 to ptr))
  br label %join.2402
join.2402:
  %v2414 = phi ptr [ %v2412, %join.2409 ], [ %v2413, %no.2401 ]
  %v2415 = ptrtoint ptr %v2414 to i64
  %v2416 = ashr i64 %v2415, 1
  %v2417 = and i64 %v2415, 1
  %v2418 = icmp ne i64 %v2417, 0
  %v2419 = icmp ult i64 %v2416, %v2382
  %v2420 = and i1 %v2418, %v2419
  br i1 %v2420, label %array.valid.2421, label %array.invalid.2422
array.invalid.2422:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2421:
  %v2423 = getelementptr i64, ptr %v2384, i64 %v2416
  %v2424 = load double, ptr %v2423, align 8, !tbaa !4
  %v2425 = ptrtoint ptr %a1 to i64
  %v2426 = ptrtoint ptr inttoptr (i64 11 to ptr) to i64
  %v2427 = and i64 %v2425, %v2426
  %v2428 = and i64 %v2427, 1
  %v2429 = icmp ne i64 %v2428, 0
  br i1 %v2429, label %yes.2430, label %no.2431
yes.2430:
  %v2433 = sub i64 %v2426, 1
  %v2434 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2425, i64 %v2433)
  %v2435 = extractvalue { i64, i1 } %v2434, 0
  %v2436 = extractvalue { i64, i1 } %v2434, 1
  br i1 %v2436, label %yes.2437, label %no.2438
yes.2437:
  %v2440 = call ptr @mlf_add_int(ptr %a1, ptr inttoptr (i64 11 to ptr))
  br label %join.2439
no.2438:
  %v2441 = inttoptr i64 %v2435 to ptr
  br label %join.2439
join.2439:
  %v2442 = phi ptr [ %v2440, %yes.2437 ], [ %v2441, %no.2438 ]
  br label %join.2432
no.2431:
  %v2443 = call ptr @mlf_add_int(ptr %a1, ptr inttoptr (i64 11 to ptr))
  br label %join.2432
join.2432:
  %v2444 = phi ptr [ %v2442, %join.2439 ], [ %v2443, %no.2431 ]
  %v2445 = ptrtoint ptr %v2444 to i64
  %v2446 = ashr i64 %v2445, 1
  %v2447 = and i64 %v2445, 1
  %v2448 = icmp ne i64 %v2447, 0
  %v2449 = icmp ult i64 %v2446, %v2382
  %v2450 = and i1 %v2448, %v2449
  br i1 %v2450, label %array.valid.2451, label %array.invalid.2452
array.invalid.2452:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2451:
  %v2453 = getelementptr i64, ptr %v2384, i64 %v2446
  %v2454 = load double, ptr %v2453, align 8, !tbaa !4
  %v2455 = ptrtoint ptr %a1 to i64
  %v2456 = ptrtoint ptr inttoptr (i64 13 to ptr) to i64
  %v2457 = and i64 %v2455, %v2456
  %v2458 = and i64 %v2457, 1
  %v2459 = icmp ne i64 %v2458, 0
  br i1 %v2459, label %yes.2460, label %no.2461
yes.2460:
  %v2463 = sub i64 %v2456, 1
  %v2464 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2455, i64 %v2463)
  %v2465 = extractvalue { i64, i1 } %v2464, 0
  %v2466 = extractvalue { i64, i1 } %v2464, 1
  br i1 %v2466, label %yes.2467, label %no.2468
yes.2467:
  %v2470 = call ptr @mlf_add_int(ptr %a1, ptr inttoptr (i64 13 to ptr))
  br label %join.2469
no.2468:
  %v2471 = inttoptr i64 %v2465 to ptr
  br label %join.2469
join.2469:
  %v2472 = phi ptr [ %v2470, %yes.2467 ], [ %v2471, %no.2468 ]
  br label %join.2462
no.2461:
  %v2473 = call ptr @mlf_add_int(ptr %a1, ptr inttoptr (i64 13 to ptr))
  br label %join.2462
join.2462:
  %v2474 = phi ptr [ %v2472, %join.2469 ], [ %v2473, %no.2461 ]
  %v2475 = ptrtoint ptr %v2474 to i64
  %v2476 = ashr i64 %v2475, 1
  %v2477 = and i64 %v2475, 1
  %v2478 = icmp ne i64 %v2477, 0
  %v2479 = icmp ult i64 %v2476, %v2382
  %v2480 = and i1 %v2478, %v2479
  br i1 %v2480, label %array.valid.2481, label %array.invalid.2482
array.invalid.2482:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2481:
  %v2483 = getelementptr i64, ptr %v2384, i64 %v2476
  %v2484 = load double, ptr %v2483, align 8, !tbaa !4
  %v2485 = ptrtoint ptr %a1 to i64
  %v2486 = ptrtoint ptr inttoptr (i64 15 to ptr) to i64
  %v2487 = and i64 %v2485, %v2486
  %v2488 = and i64 %v2487, 1
  %v2489 = icmp ne i64 %v2488, 0
  br i1 %v2489, label %yes.2490, label %no.2491
yes.2490:
  %v2493 = sub i64 %v2486, 1
  %v2494 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2485, i64 %v2493)
  %v2495 = extractvalue { i64, i1 } %v2494, 0
  %v2496 = extractvalue { i64, i1 } %v2494, 1
  br i1 %v2496, label %yes.2497, label %no.2498
yes.2497:
  %v2500 = call ptr @mlf_add_int(ptr %a1, ptr inttoptr (i64 15 to ptr))
  br label %join.2499
no.2498:
  %v2501 = inttoptr i64 %v2495 to ptr
  br label %join.2499
join.2499:
  %v2502 = phi ptr [ %v2500, %yes.2497 ], [ %v2501, %no.2498 ]
  br label %join.2492
no.2491:
  %v2503 = call ptr @mlf_add_int(ptr %a1, ptr inttoptr (i64 15 to ptr))
  br label %join.2492
join.2492:
  %v2504 = phi ptr [ %v2502, %join.2499 ], [ %v2503, %no.2491 ]
  %v2505 = fmul double 0x3fe0000000000000, %v2484
  %v2506 = fmul double %v2394, %v2394
  %v2507 = fmul double %v2424, %v2424
  %v2508 = fadd double %v2506, %v2507
  %v2509 = fmul double %v2454, %v2454
  %v2510 = fadd double %v2508, %v2509
  %v2511 = fmul double %v2505, %v2510
  %v2512 = getelementptr i8, ptr %a2, i64 8
  %v2513 = load double, ptr %v2512, align 8, !tbaa !3
  %v2514 = fadd double %v2513, %v2511
  %v2663 = call ptr @mlf.numeric.16.pppd(ptr %a0, ptr %a1, ptr %v2504, double %v2514)
  %v2664 = ptrtoint ptr %a1 to i64
  %v2665 = ptrtoint ptr inttoptr (i64 15 to ptr) to i64
  %v2666 = and i64 %v2664, %v2665
  %v2667 = and i64 %v2666, 1
  %v2668 = icmp ne i64 %v2667, 0
  br i1 %v2668, label %yes.2669, label %no.2670
yes.2669:
  %v2672 = sub i64 %v2665, 1
  %v2673 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2664, i64 %v2672)
  %v2674 = extractvalue { i64, i1 } %v2673, 0
  %v2675 = extractvalue { i64, i1 } %v2673, 1
  br i1 %v2675, label %yes.2676, label %no.2677
yes.2676:
  %v2679 = call ptr @mlf_add_int(ptr %a1, ptr inttoptr (i64 15 to ptr))
  br label %join.2678
no.2677:
  %v2680 = inttoptr i64 %v2674 to ptr
  br label %join.2678
join.2678:
  %v2681 = phi ptr [ %v2679, %yes.2676 ], [ %v2680, %no.2677 ]
  br label %join.2671
no.2670:
  %v2682 = call ptr @mlf_add_int(ptr %a1, ptr inttoptr (i64 15 to ptr))
  br label %join.2671
join.2671:
  %v2683 = phi ptr [ %v2681, %join.2678 ], [ %v2682, %no.2670 ]
  %v2684 = musttail call ptr @mlf.numeric.33(ptr %a0, ptr %v2683, ptr %v2663)
  ret ptr %v2684
}

define private ptr @mlf.code.2700(ptr %env, ptr %arg) {
entry:
  %v2701 = getelementptr i8, ptr %env, i64 8
  %v2702 = load ptr, ptr %v2701, align 8, !tbaa !3
  %v2703 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2703, align 8, !tbaa !3
  %v2704 = call ptr @mlf.force(ptr %v2702)
  %v2705 = call ptr @mlf_prim2(i64 8, ptr %v2704, ptr inttoptr (i64 7 to ptr))
  ret ptr %v2705
}

define private ptr @mlf.code.2693(ptr %env, ptr %arg) {
entry:
  %v2694 = getelementptr i8, ptr %env, i64 8
  %v2695 = load ptr, ptr %v2694, align 8, !tbaa !3
  %v2696 = getelementptr i8, ptr %env, i64 16
  %v2697 = load ptr, ptr %v2696, align 8, !tbaa !3
  %v2698 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2698, align 8, !tbaa !3
  %v2699 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2699, align 8, !tbaa !3
  %v2706 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2700, i64 1)
  %v2707 = getelementptr i8, ptr %v2706, i64 16
  %v2708 = load ptr, ptr %v2707, align 8, !tbaa !3
  %v2709 = getelementptr i8, ptr %v2708, i64 8
  store ptr %v2697, ptr %v2709, align 8, !tbaa !3
  %v2710 = call ptr @mlf_prim2(i64 32, ptr %v2695, ptr %v2706)
  ret ptr %v2710
}

define private ptr @mlf.code.2730(ptr %env, ptr %arg) {
entry:
  %v2731 = getelementptr i8, ptr %env, i64 8
  %v2732 = load ptr, ptr %v2731, align 8, !tbaa !3
  %v2733 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2733, align 8, !tbaa !3
  %v2734 = call ptr @mlf.force(ptr %v2732)
  %v2735 = call ptr @mlf_prim2(i64 8, ptr %v2734, ptr inttoptr (i64 9 to ptr))
  ret ptr %v2735
}

define private ptr @mlf.code.2723(ptr %env, ptr %arg) {
entry:
  %v2724 = getelementptr i8, ptr %env, i64 8
  %v2725 = load ptr, ptr %v2724, align 8, !tbaa !3
  %v2726 = getelementptr i8, ptr %env, i64 16
  %v2727 = load ptr, ptr %v2726, align 8, !tbaa !3
  %v2728 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2728, align 8, !tbaa !3
  %v2729 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2729, align 8, !tbaa !3
  %v2736 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2730, i64 1)
  %v2737 = getelementptr i8, ptr %v2736, i64 16
  %v2738 = load ptr, ptr %v2737, align 8, !tbaa !3
  %v2739 = getelementptr i8, ptr %v2738, i64 8
  store ptr %v2727, ptr %v2739, align 8, !tbaa !3
  %v2740 = call ptr @mlf_prim2(i64 32, ptr %v2725, ptr %v2736)
  ret ptr %v2740
}

define private ptr @mlf.code.2762(ptr %env, ptr %arg) {
entry:
  %v2763 = getelementptr i8, ptr %env, i64 8
  %v2764 = load ptr, ptr %v2763, align 8, !tbaa !3
  %v2765 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2765, align 8, !tbaa !3
  %v2766 = call ptr @mlf.force(ptr %v2764)
  %v2767 = call ptr @mlf_prim2(i64 8, ptr %v2766, ptr inttoptr (i64 11 to ptr))
  ret ptr %v2767
}

define private ptr @mlf.code.2755(ptr %env, ptr %arg) {
entry:
  %v2756 = getelementptr i8, ptr %env, i64 8
  %v2757 = load ptr, ptr %v2756, align 8, !tbaa !3
  %v2758 = getelementptr i8, ptr %env, i64 16
  %v2759 = load ptr, ptr %v2758, align 8, !tbaa !3
  %v2760 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2760, align 8, !tbaa !3
  %v2761 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2761, align 8, !tbaa !3
  %v2768 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2762, i64 1)
  %v2769 = getelementptr i8, ptr %v2768, i64 16
  %v2770 = load ptr, ptr %v2769, align 8, !tbaa !3
  %v2771 = getelementptr i8, ptr %v2770, i64 8
  store ptr %v2759, ptr %v2771, align 8, !tbaa !3
  %v2772 = call ptr @mlf_prim2(i64 32, ptr %v2757, ptr %v2768)
  ret ptr %v2772
}

define private ptr @mlf.code.2796(ptr %env, ptr %arg) {
entry:
  %v2797 = getelementptr i8, ptr %env, i64 8
  %v2798 = load ptr, ptr %v2797, align 8, !tbaa !3
  %v2799 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2799, align 8, !tbaa !3
  %v2800 = call ptr @mlf.force(ptr %v2798)
  %v2801 = call ptr @mlf_prim2(i64 8, ptr %v2800, ptr inttoptr (i64 13 to ptr))
  ret ptr %v2801
}

define private ptr @mlf.code.2789(ptr %env, ptr %arg) {
entry:
  %v2790 = getelementptr i8, ptr %env, i64 8
  %v2791 = load ptr, ptr %v2790, align 8, !tbaa !3
  %v2792 = getelementptr i8, ptr %env, i64 16
  %v2793 = load ptr, ptr %v2792, align 8, !tbaa !3
  %v2794 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2794, align 8, !tbaa !3
  %v2795 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2795, align 8, !tbaa !3
  %v2802 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2796, i64 1)
  %v2803 = getelementptr i8, ptr %v2802, i64 16
  %v2804 = load ptr, ptr %v2803, align 8, !tbaa !3
  %v2805 = getelementptr i8, ptr %v2804, i64 8
  store ptr %v2793, ptr %v2805, align 8, !tbaa !3
  %v2806 = call ptr @mlf_prim2(i64 32, ptr %v2791, ptr %v2802)
  ret ptr %v2806
}

define private ptr @mlf.numeric.16(ptr %a0, ptr %a1, ptr %a2, ptr %a3) alwaysinline {
entry:
  %v2871 = ptrtoint ptr %a2 to i64
  %v2872 = ptrtoint ptr inttoptr (i64 71 to ptr) to i64
  %v2873 = and i64 %v2871, %v2872
  %v2874 = and i64 %v2873, 1
  %v2875 = icmp ne i64 %v2874, 0
  br i1 %v2875, label %yes.2876, label %no.2877
yes.2876:
  %v2879 = icmp eq i64 %v2871, %v2872
  %v2880 = select i1 %v2879, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.2878
no.2877:
  %v2881 = call ptr @mlf_eq_int(ptr %a2, ptr inttoptr (i64 71 to ptr))
  br label %join.2878
join.2878:
  %v2882 = phi ptr [ %v2880, %yes.2876 ], [ %v2881, %no.2877 ]
  %v2883 = icmp eq ptr %v2882, inttoptr (i64 6 to ptr)
  br i1 %v2883, label %tail.yes.2884, label %tail.no.2885
tail.yes.2884:
  ret ptr %a3
tail.no.2885:
  %v2886 = getelementptr i8, ptr %a0, i64 8
  %v2887 = load i64, ptr %v2886, align 8, !tbaa !3
  %v2888 = getelementptr i8, ptr %a0, i64 16
  %v2889 = load ptr, ptr %v2888, align 8, !tbaa !3
  %v2890 = ptrtoint ptr %a1 to i64
  %v2891 = ashr i64 %v2890, 1
  %v2892 = and i64 %v2890, 1
  %v2893 = icmp ne i64 %v2892, 0
  %v2894 = icmp ult i64 %v2891, %v2887
  %v2895 = and i1 %v2893, %v2894
  br i1 %v2895, label %array.valid.2896, label %array.invalid.2897
array.invalid.2897:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2896:
  %v2898 = getelementptr i64, ptr %v2889, i64 %v2891
  %v2899 = load double, ptr %v2898, align 8, !tbaa !4
  %v2900 = ptrtoint ptr %a1 to i64
  %v2901 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2902 = sub i64 %v2901, 1
  %v2903 = add nsw i64 %v2900, %v2902
  %v2904 = inttoptr i64 %v2903 to ptr
  %v2905 = ptrtoint ptr %v2904 to i64
  %v2906 = ashr i64 %v2905, 1
  %v2907 = and i64 %v2905, 1
  %v2908 = icmp ne i64 %v2907, 0
  %v2909 = icmp ult i64 %v2906, %v2887
  %v2910 = and i1 %v2908, %v2909
  br i1 %v2910, label %array.valid.2911, label %array.invalid.2912
array.invalid.2912:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2911:
  %v2913 = getelementptr i64, ptr %v2889, i64 %v2906
  %v2914 = load double, ptr %v2913, align 8, !tbaa !4
  %v2915 = ptrtoint ptr %a1 to i64
  %v2916 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v2917 = sub i64 %v2916, 1
  %v2918 = add nsw i64 %v2915, %v2917
  %v2919 = inttoptr i64 %v2918 to ptr
  %v2920 = ptrtoint ptr %v2919 to i64
  %v2921 = ashr i64 %v2920, 1
  %v2922 = and i64 %v2920, 1
  %v2923 = icmp ne i64 %v2922, 0
  %v2924 = icmp ult i64 %v2921, %v2887
  %v2925 = and i1 %v2923, %v2924
  br i1 %v2925, label %array.valid.2926, label %array.invalid.2927
array.invalid.2927:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2926:
  %v2928 = getelementptr i64, ptr %v2889, i64 %v2921
  %v2929 = load double, ptr %v2928, align 8, !tbaa !4
  %v2930 = ptrtoint ptr %a1 to i64
  %v2931 = ptrtoint ptr inttoptr (i64 13 to ptr) to i64
  %v2932 = sub i64 %v2931, 1
  %v2933 = add nsw i64 %v2930, %v2932
  %v2934 = inttoptr i64 %v2933 to ptr
  %v2935 = ptrtoint ptr %v2934 to i64
  %v2936 = ashr i64 %v2935, 1
  %v2937 = and i64 %v2935, 1
  %v2938 = icmp ne i64 %v2937, 0
  %v2939 = icmp ult i64 %v2936, %v2887
  %v2940 = and i1 %v2938, %v2939
  br i1 %v2940, label %array.valid.2941, label %array.invalid.2942
array.invalid.2942:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2941:
  %v2943 = getelementptr i64, ptr %v2889, i64 %v2936
  %v2944 = load double, ptr %v2943, align 8, !tbaa !4
  %v2945 = ptrtoint ptr %a2 to i64
  %v2946 = ashr i64 %v2945, 1
  %v2947 = and i64 %v2945, 1
  %v2948 = icmp ne i64 %v2947, 0
  %v2949 = icmp ult i64 %v2946, %v2887
  %v2950 = and i1 %v2948, %v2949
  br i1 %v2950, label %array.valid.2951, label %array.invalid.2952
array.invalid.2952:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2951:
  %v2953 = getelementptr i64, ptr %v2889, i64 %v2946
  %v2954 = load double, ptr %v2953, align 8, !tbaa !4
  %v2955 = ptrtoint ptr %a2 to i64
  %v2956 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2957 = sub i64 %v2956, 1
  %v2958 = add nsw i64 %v2955, %v2957
  %v2959 = inttoptr i64 %v2958 to ptr
  %v2960 = ptrtoint ptr %v2959 to i64
  %v2961 = ashr i64 %v2960, 1
  %v2962 = and i64 %v2960, 1
  %v2963 = icmp ne i64 %v2962, 0
  %v2964 = icmp ult i64 %v2961, %v2887
  %v2965 = and i1 %v2963, %v2964
  br i1 %v2965, label %array.valid.2966, label %array.invalid.2967
array.invalid.2967:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2966:
  %v2968 = getelementptr i64, ptr %v2889, i64 %v2961
  %v2969 = load double, ptr %v2968, align 8, !tbaa !4
  %v2970 = ptrtoint ptr %a2 to i64
  %v2971 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v2972 = sub i64 %v2971, 1
  %v2973 = add nsw i64 %v2970, %v2972
  %v2974 = inttoptr i64 %v2973 to ptr
  %v2975 = ptrtoint ptr %v2974 to i64
  %v2976 = ashr i64 %v2975, 1
  %v2977 = and i64 %v2975, 1
  %v2978 = icmp ne i64 %v2977, 0
  %v2979 = icmp ult i64 %v2976, %v2887
  %v2980 = and i1 %v2978, %v2979
  br i1 %v2980, label %array.valid.2981, label %array.invalid.2982
array.invalid.2982:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2981:
  %v2983 = getelementptr i64, ptr %v2889, i64 %v2976
  %v2984 = load double, ptr %v2983, align 8, !tbaa !4
  %v2985 = ptrtoint ptr %a2 to i64
  %v2986 = ptrtoint ptr inttoptr (i64 13 to ptr) to i64
  %v2987 = sub i64 %v2986, 1
  %v2988 = add nsw i64 %v2985, %v2987
  %v2989 = inttoptr i64 %v2988 to ptr
  %v2990 = ptrtoint ptr %v2989 to i64
  %v2991 = ashr i64 %v2990, 1
  %v2992 = and i64 %v2990, 1
  %v2993 = icmp ne i64 %v2992, 0
  %v2994 = icmp ult i64 %v2991, %v2887
  %v2995 = and i1 %v2993, %v2994
  br i1 %v2995, label %array.valid.2996, label %array.invalid.2997
array.invalid.2997:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2996:
  %v2998 = getelementptr i64, ptr %v2889, i64 %v2991
  %v2999 = load double, ptr %v2998, align 8, !tbaa !4
  %v3000 = fsub double %v2899, %v2954
  %v3001 = fsub double %v2914, %v2969
  %v3002 = fsub double %v2929, %v2984
  %v3003 = fmul double %v3000, %v3000
  %v3004 = fmul double %v3001, %v3001
  %v3005 = fadd double %v3003, %v3004
  %v3006 = fmul double %v3002, %v3002
  %v3007 = fadd double %v3005, %v3006
  %v3008 = call double @llvm.sqrt.f64(double %v3007)
  %v3009 = ptrtoint ptr %a2 to i64
  %v3010 = ptrtoint ptr inttoptr (i64 15 to ptr) to i64
  %v3011 = sub i64 %v3010, 1
  %v3012 = add nsw i64 %v3009, %v3011
  %v3013 = inttoptr i64 %v3012 to ptr
  %v3014 = fmul double %v2944, %v2999
  %v3015 = fdiv double %v3014, %v3008
  %v3016 = getelementptr i8, ptr %a3, i64 8
  %v3017 = load double, ptr %v3016, align 8, !tbaa !3
  %v3018 = fsub double %v3017, %v3015
  %v3019 = call ptr @mlf.numeric.16.pppd(ptr %a0, ptr %a1, ptr %v3013, double %v3018)
  ret ptr %v3019
}

define private ptr @mlf.code.3035(ptr %env, ptr %arg) {
entry:
  %v3036 = getelementptr i8, ptr %env, i64 8
  %v3037 = load ptr, ptr %v3036, align 8, !tbaa !3
  %v3038 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3038, align 8, !tbaa !3
  %v3039 = call ptr @mlf.force(ptr %v3037)
  %v3040 = call ptr @mlf_prim2(i64 8, ptr %v3039, ptr inttoptr (i64 1 to ptr))
  ret ptr %v3040
}

define private ptr @mlf.code.3028(ptr %env, ptr %arg) {
entry:
  %v3029 = getelementptr i8, ptr %env, i64 8
  %v3030 = load ptr, ptr %v3029, align 8, !tbaa !3
  %v3031 = getelementptr i8, ptr %env, i64 16
  %v3032 = load ptr, ptr %v3031, align 8, !tbaa !3
  %v3033 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3033, align 8, !tbaa !3
  %v3034 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v3034, align 8, !tbaa !3
  %v3041 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3035, i64 1)
  %v3042 = getelementptr i8, ptr %v3041, i64 16
  %v3043 = load ptr, ptr %v3042, align 8, !tbaa !3
  %v3044 = getelementptr i8, ptr %v3043, i64 8
  store ptr %v3032, ptr %v3044, align 8, !tbaa !3
  %v3045 = call ptr @mlf_prim2(i64 32, ptr %v3030, ptr %v3041)
  ret ptr %v3045
}

define private ptr @mlf.code.3067(ptr %env, ptr %arg) {
entry:
  %v3068 = getelementptr i8, ptr %env, i64 8
  %v3069 = load ptr, ptr %v3068, align 8, !tbaa !3
  %v3070 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3070, align 8, !tbaa !3
  %v3071 = call ptr @mlf.force(ptr %v3069)
  %v3072 = call ptr @mlf_prim2(i64 8, ptr %v3071, ptr inttoptr (i64 3 to ptr))
  ret ptr %v3072
}

define private ptr @mlf.code.3060(ptr %env, ptr %arg) {
entry:
  %v3061 = getelementptr i8, ptr %env, i64 8
  %v3062 = load ptr, ptr %v3061, align 8, !tbaa !3
  %v3063 = getelementptr i8, ptr %env, i64 16
  %v3064 = load ptr, ptr %v3063, align 8, !tbaa !3
  %v3065 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3065, align 8, !tbaa !3
  %v3066 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v3066, align 8, !tbaa !3
  %v3073 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3067, i64 1)
  %v3074 = getelementptr i8, ptr %v3073, i64 16
  %v3075 = load ptr, ptr %v3074, align 8, !tbaa !3
  %v3076 = getelementptr i8, ptr %v3075, i64 8
  store ptr %v3064, ptr %v3076, align 8, !tbaa !3
  %v3077 = call ptr @mlf_prim2(i64 32, ptr %v3062, ptr %v3073)
  ret ptr %v3077
}

define private ptr @mlf.code.3101(ptr %env, ptr %arg) {
entry:
  %v3102 = getelementptr i8, ptr %env, i64 8
  %v3103 = load ptr, ptr %v3102, align 8, !tbaa !3
  %v3104 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3104, align 8, !tbaa !3
  %v3105 = call ptr @mlf.force(ptr %v3103)
  %v3106 = call ptr @mlf_prim2(i64 8, ptr %v3105, ptr inttoptr (i64 5 to ptr))
  ret ptr %v3106
}

define private ptr @mlf.code.3094(ptr %env, ptr %arg) {
entry:
  %v3095 = getelementptr i8, ptr %env, i64 8
  %v3096 = load ptr, ptr %v3095, align 8, !tbaa !3
  %v3097 = getelementptr i8, ptr %env, i64 16
  %v3098 = load ptr, ptr %v3097, align 8, !tbaa !3
  %v3099 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3099, align 8, !tbaa !3
  %v3100 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v3100, align 8, !tbaa !3
  %v3107 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3101, i64 1)
  %v3108 = getelementptr i8, ptr %v3107, i64 16
  %v3109 = load ptr, ptr %v3108, align 8, !tbaa !3
  %v3110 = getelementptr i8, ptr %v3109, i64 8
  store ptr %v3098, ptr %v3110, align 8, !tbaa !3
  %v3111 = call ptr @mlf_prim2(i64 32, ptr %v3096, ptr %v3107)
  ret ptr %v3111
}

define private ptr @mlf.code.3137(ptr %env, ptr %arg) {
entry:
  %v3138 = getelementptr i8, ptr %env, i64 8
  %v3139 = load ptr, ptr %v3138, align 8, !tbaa !3
  %v3140 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3140, align 8, !tbaa !3
  %v3141 = call ptr @mlf.force(ptr %v3139)
  %v3142 = call ptr @mlf_prim2(i64 8, ptr %v3141, ptr inttoptr (i64 13 to ptr))
  ret ptr %v3142
}

define private ptr @mlf.code.3130(ptr %env, ptr %arg) {
entry:
  %v3131 = getelementptr i8, ptr %env, i64 8
  %v3132 = load ptr, ptr %v3131, align 8, !tbaa !3
  %v3133 = getelementptr i8, ptr %env, i64 16
  %v3134 = load ptr, ptr %v3133, align 8, !tbaa !3
  %v3135 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3135, align 8, !tbaa !3
  %v3136 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v3136, align 8, !tbaa !3
  %v3143 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3137, i64 1)
  %v3144 = getelementptr i8, ptr %v3143, i64 16
  %v3145 = load ptr, ptr %v3144, align 8, !tbaa !3
  %v3146 = getelementptr i8, ptr %v3145, i64 8
  store ptr %v3134, ptr %v3146, align 8, !tbaa !3
  %v3147 = call ptr @mlf_prim2(i64 32, ptr %v3132, ptr %v3143)
  ret ptr %v3147
}

define private ptr @mlf.code.3175(ptr %env, ptr %arg) {
entry:
  %v3176 = getelementptr i8, ptr %env, i64 8
  %v3177 = load ptr, ptr %v3176, align 8, !tbaa !3
  %v3178 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3178, align 8, !tbaa !3
  %v3179 = call ptr @mlf.force(ptr %v3177)
  %v3180 = call ptr @mlf_prim2(i64 8, ptr %v3179, ptr inttoptr (i64 1 to ptr))
  ret ptr %v3180
}

define private ptr @mlf.code.3168(ptr %env, ptr %arg) {
entry:
  %v3169 = getelementptr i8, ptr %env, i64 8
  %v3170 = load ptr, ptr %v3169, align 8, !tbaa !3
  %v3171 = getelementptr i8, ptr %env, i64 16
  %v3172 = load ptr, ptr %v3171, align 8, !tbaa !3
  %v3173 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3173, align 8, !tbaa !3
  %v3174 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v3174, align 8, !tbaa !3
  %v3181 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3175, i64 1)
  %v3182 = getelementptr i8, ptr %v3181, i64 16
  %v3183 = load ptr, ptr %v3182, align 8, !tbaa !3
  %v3184 = getelementptr i8, ptr %v3183, i64 8
  store ptr %v3172, ptr %v3184, align 8, !tbaa !3
  %v3185 = call ptr @mlf_prim2(i64 32, ptr %v3170, ptr %v3181)
  ret ptr %v3185
}

define private ptr @mlf.code.3215(ptr %env, ptr %arg) {
entry:
  %v3216 = getelementptr i8, ptr %env, i64 8
  %v3217 = load ptr, ptr %v3216, align 8, !tbaa !3
  %v3218 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3218, align 8, !tbaa !3
  %v3219 = call ptr @mlf.force(ptr %v3217)
  %v3220 = call ptr @mlf_prim2(i64 8, ptr %v3219, ptr inttoptr (i64 3 to ptr))
  ret ptr %v3220
}

define private ptr @mlf.code.3208(ptr %env, ptr %arg) {
entry:
  %v3209 = getelementptr i8, ptr %env, i64 8
  %v3210 = load ptr, ptr %v3209, align 8, !tbaa !3
  %v3211 = getelementptr i8, ptr %env, i64 16
  %v3212 = load ptr, ptr %v3211, align 8, !tbaa !3
  %v3213 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3213, align 8, !tbaa !3
  %v3214 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v3214, align 8, !tbaa !3
  %v3221 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3215, i64 1)
  %v3222 = getelementptr i8, ptr %v3221, i64 16
  %v3223 = load ptr, ptr %v3222, align 8, !tbaa !3
  %v3224 = getelementptr i8, ptr %v3223, i64 8
  store ptr %v3212, ptr %v3224, align 8, !tbaa !3
  %v3225 = call ptr @mlf_prim2(i64 32, ptr %v3210, ptr %v3221)
  ret ptr %v3225
}

define private ptr @mlf.code.3257(ptr %env, ptr %arg) {
entry:
  %v3258 = getelementptr i8, ptr %env, i64 8
  %v3259 = load ptr, ptr %v3258, align 8, !tbaa !3
  %v3260 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3260, align 8, !tbaa !3
  %v3261 = call ptr @mlf.force(ptr %v3259)
  %v3262 = call ptr @mlf_prim2(i64 8, ptr %v3261, ptr inttoptr (i64 5 to ptr))
  ret ptr %v3262
}

define private ptr @mlf.code.3250(ptr %env, ptr %arg) {
entry:
  %v3251 = getelementptr i8, ptr %env, i64 8
  %v3252 = load ptr, ptr %v3251, align 8, !tbaa !3
  %v3253 = getelementptr i8, ptr %env, i64 16
  %v3254 = load ptr, ptr %v3253, align 8, !tbaa !3
  %v3255 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3255, align 8, !tbaa !3
  %v3256 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v3256, align 8, !tbaa !3
  %v3263 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3257, i64 1)
  %v3264 = getelementptr i8, ptr %v3263, i64 16
  %v3265 = load ptr, ptr %v3264, align 8, !tbaa !3
  %v3266 = getelementptr i8, ptr %v3265, i64 8
  store ptr %v3254, ptr %v3266, align 8, !tbaa !3
  %v3267 = call ptr @mlf_prim2(i64 32, ptr %v3252, ptr %v3263)
  ret ptr %v3267
}

define private ptr @mlf.code.3301(ptr %env, ptr %arg) {
entry:
  %v3302 = getelementptr i8, ptr %env, i64 8
  %v3303 = load ptr, ptr %v3302, align 8, !tbaa !3
  %v3304 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3304, align 8, !tbaa !3
  %v3305 = call ptr @mlf.force(ptr %v3303)
  %v3306 = call ptr @mlf_prim2(i64 8, ptr %v3305, ptr inttoptr (i64 13 to ptr))
  ret ptr %v3306
}

define private ptr @mlf.code.3294(ptr %env, ptr %arg) {
entry:
  %v3295 = getelementptr i8, ptr %env, i64 8
  %v3296 = load ptr, ptr %v3295, align 8, !tbaa !3
  %v3297 = getelementptr i8, ptr %env, i64 16
  %v3298 = load ptr, ptr %v3297, align 8, !tbaa !3
  %v3299 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3299, align 8, !tbaa !3
  %v3300 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v3300, align 8, !tbaa !3
  %v3307 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3301, i64 1)
  %v3308 = getelementptr i8, ptr %v3307, i64 16
  %v3309 = load ptr, ptr %v3308, align 8, !tbaa !3
  %v3310 = getelementptr i8, ptr %v3309, i64 8
  store ptr %v3298, ptr %v3310, align 8, !tbaa !3
  %v3311 = call ptr @mlf_prim2(i64 32, ptr %v3296, ptr %v3307)
  ret ptr %v3311
}

define private ptr @mlf.code.3340(ptr %env, ptr %arg) {
entry:
  %v3341 = getelementptr i8, ptr %env, i64 8
  %v3342 = load ptr, ptr %v3341, align 8, !tbaa !3
  %v3343 = getelementptr i8, ptr %env, i64 16
  %v3344 = load ptr, ptr %v3343, align 8, !tbaa !3
  %v3345 = getelementptr i8, ptr %env, i64 24
  %v3346 = load ptr, ptr %v3345, align 8, !tbaa !3
  %v3347 = getelementptr i8, ptr %env, i64 32
  %v3348 = load ptr, ptr %v3347, align 8, !tbaa !3
  %v3349 = getelementptr i8, ptr %env, i64 40
  %v3350 = load ptr, ptr %v3349, align 8, !tbaa !3
  %v3351 = getelementptr i8, ptr %env, i64 48
  %v3352 = load ptr, ptr %v3351, align 8, !tbaa !3
  %v3353 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3353, align 8, !tbaa !3
  %v3354 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v3354, align 8, !tbaa !3
  %v3355 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v3355, align 8, !tbaa !3
  %v3356 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v3356, align 8, !tbaa !3
  %v3357 = getelementptr i8, ptr %env, i64 40
  store ptr null, ptr %v3357, align 8, !tbaa !3
  %v3358 = getelementptr i8, ptr %env, i64 48
  store ptr null, ptr %v3358, align 8, !tbaa !3
  %v3359 = call ptr @mlf.force(ptr %v3342)
  %v3360 = call ptr @mlf.force(ptr %v3348)
  %v3361 = call ptr @mlf_prim2(i64 19, ptr %v3359, ptr %v3360)
  %v3362 = call ptr @mlf.force(ptr %v3344)
  %v3363 = call ptr @mlf.force(ptr %v3350)
  %v3364 = call ptr @mlf_prim2(i64 19, ptr %v3362, ptr %v3363)
  %v3365 = call ptr @mlf.force(ptr %v3346)
  %v3366 = call ptr @mlf.force(ptr %v3352)
  %v3367 = call ptr @mlf_prim2(i64 19, ptr %v3365, ptr %v3366)
  %v3368 = call ptr @mlf_prim2(i64 20, ptr %v3361, ptr %v3361)
  %v3369 = call ptr @mlf_prim2(i64 20, ptr %v3364, ptr %v3364)
  %v3370 = call ptr @mlf_prim2(i64 18, ptr %v3368, ptr %v3369)
  %v3371 = call ptr @mlf_prim2(i64 20, ptr %v3367, ptr %v3367)
  %v3372 = call ptr @mlf_prim2(i64 18, ptr %v3370, ptr %v3371)
  %v3373 = call ptr @mlf_prim1(i64 22, ptr %v3372)
  ret ptr %v3373
}

define private ptr @mlf.code.3385(ptr %env, ptr %arg) {
entry:
  %v3386 = getelementptr i8, ptr %env, i64 8
  %v3387 = load ptr, ptr %v3386, align 8, !tbaa !3
  %v3388 = getelementptr i8, ptr %env, i64 16
  %v3389 = load ptr, ptr %v3388, align 8, !tbaa !3
  %v3390 = getelementptr i8, ptr %env, i64 24
  %v3391 = load ptr, ptr %v3390, align 8, !tbaa !3
  %v3392 = getelementptr i8, ptr %env, i64 32
  %v3393 = load ptr, ptr %v3392, align 8, !tbaa !3
  %v3394 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3394, align 8, !tbaa !3
  %v3395 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v3395, align 8, !tbaa !3
  %v3396 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v3396, align 8, !tbaa !3
  %v3397 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v3397, align 8, !tbaa !3
  %v3398 = call ptr @mlf.force(ptr %v3387)
  %v3399 = call ptr @mlf.force(ptr %v3389)
  %v3400 = call ptr @mlf.force(ptr %v3391)
  %v3401 = call ptr @mlf_prim2(i64 20, ptr %v3399, ptr %v3400)
  %v3402 = call ptr @mlf.force(ptr %v3393)
  %v3403 = call ptr @mlf_prim2(i64 21, ptr %v3401, ptr %v3402)
  %v3404 = call ptr @mlf_prim2(i64 19, ptr %v3398, ptr %v3403)
  ret ptr %v3404
}

define private ptr @mlf.code.3317(ptr %env, ptr %arg) {
entry:
  %v3318 = getelementptr i8, ptr %env, i64 8
  %v3319 = load ptr, ptr %v3318, align 8, !tbaa !3
  %v3320 = getelementptr i8, ptr %env, i64 16
  %v3321 = load ptr, ptr %v3320, align 8, !tbaa !3
  %v3322 = getelementptr i8, ptr %env, i64 24
  %v3323 = load ptr, ptr %v3322, align 8, !tbaa !3
  %v3324 = getelementptr i8, ptr %env, i64 32
  %v3325 = load ptr, ptr %v3324, align 8, !tbaa !3
  %v3326 = getelementptr i8, ptr %env, i64 40
  %v3327 = load ptr, ptr %v3326, align 8, !tbaa !3
  %v3328 = getelementptr i8, ptr %env, i64 48
  %v3329 = load ptr, ptr %v3328, align 8, !tbaa !3
  %v3330 = getelementptr i8, ptr %env, i64 56
  %v3331 = load ptr, ptr %v3330, align 8, !tbaa !3
  %v3332 = getelementptr i8, ptr %env, i64 64
  %v3333 = load ptr, ptr %v3332, align 8, !tbaa !3
  %v3334 = getelementptr i8, ptr %env, i64 72
  %v3335 = load ptr, ptr %v3334, align 8, !tbaa !3
  %v3336 = getelementptr i8, ptr %env, i64 80
  %v3337 = load ptr, ptr %v3336, align 8, !tbaa !3
  %v3338 = getelementptr i8, ptr %env, i64 88
  %v3339 = load ptr, ptr %v3338, align 8, !tbaa !3
  %v3374 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3340, i64 6)
  %v3375 = getelementptr i8, ptr %v3374, i64 16
  %v3376 = load ptr, ptr %v3375, align 8, !tbaa !3
  %v3377 = getelementptr i8, ptr %v3376, i64 8
  store ptr %v3327, ptr %v3377, align 8, !tbaa !3
  %v3378 = getelementptr i8, ptr %v3376, i64 16
  store ptr %v3329, ptr %v3378, align 8, !tbaa !3
  %v3379 = getelementptr i8, ptr %v3376, i64 24
  store ptr %v3331, ptr %v3379, align 8, !tbaa !3
  %v3380 = getelementptr i8, ptr %v3376, i64 32
  store ptr %v3335, ptr %v3380, align 8, !tbaa !3
  %v3381 = getelementptr i8, ptr %v3376, i64 40
  store ptr %v3337, ptr %v3381, align 8, !tbaa !3
  %v3382 = getelementptr i8, ptr %v3376, i64 48
  store ptr %v3339, ptr %v3382, align 8, !tbaa !3
  %v3383 = call ptr @mlf.force(ptr %v3323)
  %v3384 = call ptr @mlf_prim2(i64 8, ptr %v3383, ptr inttoptr (i64 15 to ptr))
  %v3405 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3385, i64 4)
  %v3406 = getelementptr i8, ptr %v3405, i64 16
  %v3407 = load ptr, ptr %v3406, align 8, !tbaa !3
  %v3408 = getelementptr i8, ptr %v3407, i64 8
  store ptr %v3325, ptr %v3408, align 8, !tbaa !3
  %v3409 = getelementptr i8, ptr %v3407, i64 16
  store ptr %v3333, ptr %v3409, align 8, !tbaa !3
  %v3410 = getelementptr i8, ptr %v3407, i64 24
  store ptr %arg, ptr %v3410, align 8, !tbaa !3
  %v3411 = getelementptr i8, ptr %v3407, i64 32
  store ptr %v3374, ptr %v3411, align 8, !tbaa !3
  %v3412 = call ptr @mlf_env_new(i64 4)
  %v3413 = getelementptr i8, ptr %v3412, i64 8
  store ptr %v3319, ptr %v3413, align 8, !tbaa !3
  %v3414 = getelementptr i8, ptr %v3412, i64 16
  store ptr %v3321, ptr %v3414, align 8, !tbaa !3
  %v3415 = getelementptr i8, ptr %v3412, i64 24
  store ptr %v3384, ptr %v3415, align 8, !tbaa !3
  %v3416 = getelementptr i8, ptr %v3412, i64 32
  store ptr %v3405, ptr %v3416, align 8, !tbaa !3
  %v3417 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2847, ptr %v3412)
  ret ptr %v3417
}

define private ptr @mlf.code.3273(ptr %env, ptr %arg) {
entry:
  %v3274 = getelementptr i8, ptr %env, i64 8
  %v3275 = load ptr, ptr %v3274, align 8, !tbaa !3
  %v3276 = getelementptr i8, ptr %env, i64 16
  %v3277 = load ptr, ptr %v3276, align 8, !tbaa !3
  %v3278 = getelementptr i8, ptr %env, i64 24
  %v3279 = load ptr, ptr %v3278, align 8, !tbaa !3
  %v3280 = getelementptr i8, ptr %env, i64 32
  %v3281 = load ptr, ptr %v3280, align 8, !tbaa !3
  %v3282 = getelementptr i8, ptr %env, i64 40
  %v3283 = load ptr, ptr %v3282, align 8, !tbaa !3
  %v3284 = getelementptr i8, ptr %env, i64 48
  %v3285 = load ptr, ptr %v3284, align 8, !tbaa !3
  %v3286 = getelementptr i8, ptr %env, i64 56
  %v3287 = load ptr, ptr %v3286, align 8, !tbaa !3
  %v3288 = getelementptr i8, ptr %env, i64 64
  %v3289 = load ptr, ptr %v3288, align 8, !tbaa !3
  %v3290 = getelementptr i8, ptr %env, i64 72
  %v3291 = load ptr, ptr %v3290, align 8, !tbaa !3
  %v3292 = getelementptr i8, ptr %env, i64 80
  %v3293 = load ptr, ptr %v3292, align 8, !tbaa !3
  %v3312 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3294, i64 2)
  %v3313 = getelementptr i8, ptr %v3312, i64 16
  %v3314 = load ptr, ptr %v3313, align 8, !tbaa !3
  %v3315 = getelementptr i8, ptr %v3314, i64 8
  store ptr %v3275, ptr %v3315, align 8, !tbaa !3
  %v3316 = getelementptr i8, ptr %v3314, i64 16
  store ptr %v3279, ptr %v3316, align 8, !tbaa !3
  %v3418 = call ptr @mlf_env_new(i64 11)
  %v3419 = getelementptr i8, ptr %v3418, i64 8
  store ptr %v3275, ptr %v3419, align 8, !tbaa !3
  %v3420 = getelementptr i8, ptr %v3418, i64 16
  store ptr %v3277, ptr %v3420, align 8, !tbaa !3
  %v3421 = getelementptr i8, ptr %v3418, i64 24
  store ptr %v3279, ptr %v3421, align 8, !tbaa !3
  %v3422 = getelementptr i8, ptr %v3418, i64 32
  store ptr %v3281, ptr %v3422, align 8, !tbaa !3
  %v3423 = getelementptr i8, ptr %v3418, i64 40
  store ptr %v3283, ptr %v3423, align 8, !tbaa !3
  %v3424 = getelementptr i8, ptr %v3418, i64 48
  store ptr %v3285, ptr %v3424, align 8, !tbaa !3
  %v3425 = getelementptr i8, ptr %v3418, i64 56
  store ptr %v3287, ptr %v3425, align 8, !tbaa !3
  %v3426 = getelementptr i8, ptr %v3418, i64 64
  store ptr %v3289, ptr %v3426, align 8, !tbaa !3
  %v3427 = getelementptr i8, ptr %v3418, i64 72
  store ptr %v3291, ptr %v3427, align 8, !tbaa !3
  %v3428 = getelementptr i8, ptr %v3418, i64 80
  store ptr %v3293, ptr %v3428, align 8, !tbaa !3
  %v3429 = getelementptr i8, ptr %v3418, i64 88
  store ptr %arg, ptr %v3429, align 8, !tbaa !3
  %v3430 = call ptr @mlf_closure(ptr @mlf.code.3317, ptr %v3418)
  %v3431 = call ptr @mlf_prim2(i64 1, ptr %v3312, ptr %v3430)
  ret ptr %v3431
}

define private ptr @mlf.code.3231(ptr %env, ptr %arg) {
entry:
  %v3232 = getelementptr i8, ptr %env, i64 8
  %v3233 = load ptr, ptr %v3232, align 8, !tbaa !3
  %v3234 = getelementptr i8, ptr %env, i64 16
  %v3235 = load ptr, ptr %v3234, align 8, !tbaa !3
  %v3236 = getelementptr i8, ptr %env, i64 24
  %v3237 = load ptr, ptr %v3236, align 8, !tbaa !3
  %v3238 = getelementptr i8, ptr %env, i64 32
  %v3239 = load ptr, ptr %v3238, align 8, !tbaa !3
  %v3240 = getelementptr i8, ptr %env, i64 40
  %v3241 = load ptr, ptr %v3240, align 8, !tbaa !3
  %v3242 = getelementptr i8, ptr %env, i64 48
  %v3243 = load ptr, ptr %v3242, align 8, !tbaa !3
  %v3244 = getelementptr i8, ptr %env, i64 56
  %v3245 = load ptr, ptr %v3244, align 8, !tbaa !3
  %v3246 = getelementptr i8, ptr %env, i64 64
  %v3247 = load ptr, ptr %v3246, align 8, !tbaa !3
  %v3248 = getelementptr i8, ptr %env, i64 72
  %v3249 = load ptr, ptr %v3248, align 8, !tbaa !3
  %v3268 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3250, i64 2)
  %v3269 = getelementptr i8, ptr %v3268, i64 16
  %v3270 = load ptr, ptr %v3269, align 8, !tbaa !3
  %v3271 = getelementptr i8, ptr %v3270, i64 8
  store ptr %v3233, ptr %v3271, align 8, !tbaa !3
  %v3272 = getelementptr i8, ptr %v3270, i64 16
  store ptr %v3237, ptr %v3272, align 8, !tbaa !3
  %v3432 = call ptr @mlf_env_new(i64 10)
  %v3433 = getelementptr i8, ptr %v3432, i64 8
  store ptr %v3233, ptr %v3433, align 8, !tbaa !3
  %v3434 = getelementptr i8, ptr %v3432, i64 16
  store ptr %v3235, ptr %v3434, align 8, !tbaa !3
  %v3435 = getelementptr i8, ptr %v3432, i64 24
  store ptr %v3237, ptr %v3435, align 8, !tbaa !3
  %v3436 = getelementptr i8, ptr %v3432, i64 32
  store ptr %v3239, ptr %v3436, align 8, !tbaa !3
  %v3437 = getelementptr i8, ptr %v3432, i64 40
  store ptr %v3241, ptr %v3437, align 8, !tbaa !3
  %v3438 = getelementptr i8, ptr %v3432, i64 48
  store ptr %v3243, ptr %v3438, align 8, !tbaa !3
  %v3439 = getelementptr i8, ptr %v3432, i64 56
  store ptr %v3245, ptr %v3439, align 8, !tbaa !3
  %v3440 = getelementptr i8, ptr %v3432, i64 64
  store ptr %v3247, ptr %v3440, align 8, !tbaa !3
  %v3441 = getelementptr i8, ptr %v3432, i64 72
  store ptr %v3249, ptr %v3441, align 8, !tbaa !3
  %v3442 = getelementptr i8, ptr %v3432, i64 80
  store ptr %arg, ptr %v3442, align 8, !tbaa !3
  %v3443 = call ptr @mlf_closure(ptr @mlf.code.3273, ptr %v3432)
  %v3444 = call ptr @mlf_prim2(i64 1, ptr %v3268, ptr %v3443)
  ret ptr %v3444
}

define private ptr @mlf.code.3191(ptr %env, ptr %arg) {
entry:
  %v3192 = getelementptr i8, ptr %env, i64 8
  %v3193 = load ptr, ptr %v3192, align 8, !tbaa !3
  %v3194 = getelementptr i8, ptr %env, i64 16
  %v3195 = load ptr, ptr %v3194, align 8, !tbaa !3
  %v3196 = getelementptr i8, ptr %env, i64 24
  %v3197 = load ptr, ptr %v3196, align 8, !tbaa !3
  %v3198 = getelementptr i8, ptr %env, i64 32
  %v3199 = load ptr, ptr %v3198, align 8, !tbaa !3
  %v3200 = getelementptr i8, ptr %env, i64 40
  %v3201 = load ptr, ptr %v3200, align 8, !tbaa !3
  %v3202 = getelementptr i8, ptr %env, i64 48
  %v3203 = load ptr, ptr %v3202, align 8, !tbaa !3
  %v3204 = getelementptr i8, ptr %env, i64 56
  %v3205 = load ptr, ptr %v3204, align 8, !tbaa !3
  %v3206 = getelementptr i8, ptr %env, i64 64
  %v3207 = load ptr, ptr %v3206, align 8, !tbaa !3
  %v3226 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3208, i64 2)
  %v3227 = getelementptr i8, ptr %v3226, i64 16
  %v3228 = load ptr, ptr %v3227, align 8, !tbaa !3
  %v3229 = getelementptr i8, ptr %v3228, i64 8
  store ptr %v3193, ptr %v3229, align 8, !tbaa !3
  %v3230 = getelementptr i8, ptr %v3228, i64 16
  store ptr %v3197, ptr %v3230, align 8, !tbaa !3
  %v3445 = call ptr @mlf_env_new(i64 9)
  %v3446 = getelementptr i8, ptr %v3445, i64 8
  store ptr %v3193, ptr %v3446, align 8, !tbaa !3
  %v3447 = getelementptr i8, ptr %v3445, i64 16
  store ptr %v3195, ptr %v3447, align 8, !tbaa !3
  %v3448 = getelementptr i8, ptr %v3445, i64 24
  store ptr %v3197, ptr %v3448, align 8, !tbaa !3
  %v3449 = getelementptr i8, ptr %v3445, i64 32
  store ptr %v3199, ptr %v3449, align 8, !tbaa !3
  %v3450 = getelementptr i8, ptr %v3445, i64 40
  store ptr %v3201, ptr %v3450, align 8, !tbaa !3
  %v3451 = getelementptr i8, ptr %v3445, i64 48
  store ptr %v3203, ptr %v3451, align 8, !tbaa !3
  %v3452 = getelementptr i8, ptr %v3445, i64 56
  store ptr %v3205, ptr %v3452, align 8, !tbaa !3
  %v3453 = getelementptr i8, ptr %v3445, i64 64
  store ptr %v3207, ptr %v3453, align 8, !tbaa !3
  %v3454 = getelementptr i8, ptr %v3445, i64 72
  store ptr %arg, ptr %v3454, align 8, !tbaa !3
  %v3455 = call ptr @mlf_closure(ptr @mlf.code.3231, ptr %v3445)
  %v3456 = call ptr @mlf_prim2(i64 1, ptr %v3226, ptr %v3455)
  ret ptr %v3456
}

define private ptr @mlf.code.3153(ptr %env, ptr %arg) {
entry:
  %v3154 = getelementptr i8, ptr %env, i64 8
  %v3155 = load ptr, ptr %v3154, align 8, !tbaa !3
  %v3156 = getelementptr i8, ptr %env, i64 16
  %v3157 = load ptr, ptr %v3156, align 8, !tbaa !3
  %v3158 = getelementptr i8, ptr %env, i64 24
  %v3159 = load ptr, ptr %v3158, align 8, !tbaa !3
  %v3160 = getelementptr i8, ptr %env, i64 32
  %v3161 = load ptr, ptr %v3160, align 8, !tbaa !3
  %v3162 = getelementptr i8, ptr %env, i64 40
  %v3163 = load ptr, ptr %v3162, align 8, !tbaa !3
  %v3164 = getelementptr i8, ptr %env, i64 48
  %v3165 = load ptr, ptr %v3164, align 8, !tbaa !3
  %v3166 = getelementptr i8, ptr %env, i64 56
  %v3167 = load ptr, ptr %v3166, align 8, !tbaa !3
  %v3186 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3168, i64 2)
  %v3187 = getelementptr i8, ptr %v3186, i64 16
  %v3188 = load ptr, ptr %v3187, align 8, !tbaa !3
  %v3189 = getelementptr i8, ptr %v3188, i64 8
  store ptr %v3155, ptr %v3189, align 8, !tbaa !3
  %v3190 = getelementptr i8, ptr %v3188, i64 16
  store ptr %v3159, ptr %v3190, align 8, !tbaa !3
  %v3457 = call ptr @mlf_env_new(i64 8)
  %v3458 = getelementptr i8, ptr %v3457, i64 8
  store ptr %v3155, ptr %v3458, align 8, !tbaa !3
  %v3459 = getelementptr i8, ptr %v3457, i64 16
  store ptr %v3157, ptr %v3459, align 8, !tbaa !3
  %v3460 = getelementptr i8, ptr %v3457, i64 24
  store ptr %v3159, ptr %v3460, align 8, !tbaa !3
  %v3461 = getelementptr i8, ptr %v3457, i64 32
  store ptr %v3161, ptr %v3461, align 8, !tbaa !3
  %v3462 = getelementptr i8, ptr %v3457, i64 40
  store ptr %v3163, ptr %v3462, align 8, !tbaa !3
  %v3463 = getelementptr i8, ptr %v3457, i64 48
  store ptr %v3165, ptr %v3463, align 8, !tbaa !3
  %v3464 = getelementptr i8, ptr %v3457, i64 56
  store ptr %v3167, ptr %v3464, align 8, !tbaa !3
  %v3465 = getelementptr i8, ptr %v3457, i64 64
  store ptr %arg, ptr %v3465, align 8, !tbaa !3
  %v3466 = call ptr @mlf_closure(ptr @mlf.code.3191, ptr %v3457)
  %v3467 = call ptr @mlf_prim2(i64 1, ptr %v3186, ptr %v3466)
  ret ptr %v3467
}

define private ptr @mlf.code.3117(ptr %env, ptr %arg) {
entry:
  %v3118 = getelementptr i8, ptr %env, i64 8
  %v3119 = load ptr, ptr %v3118, align 8, !tbaa !3
  %v3120 = getelementptr i8, ptr %env, i64 16
  %v3121 = load ptr, ptr %v3120, align 8, !tbaa !3
  %v3122 = getelementptr i8, ptr %env, i64 24
  %v3123 = load ptr, ptr %v3122, align 8, !tbaa !3
  %v3124 = getelementptr i8, ptr %env, i64 32
  %v3125 = load ptr, ptr %v3124, align 8, !tbaa !3
  %v3126 = getelementptr i8, ptr %env, i64 40
  %v3127 = load ptr, ptr %v3126, align 8, !tbaa !3
  %v3128 = getelementptr i8, ptr %env, i64 48
  %v3129 = load ptr, ptr %v3128, align 8, !tbaa !3
  %v3148 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3130, i64 2)
  %v3149 = getelementptr i8, ptr %v3148, i64 16
  %v3150 = load ptr, ptr %v3149, align 8, !tbaa !3
  %v3151 = getelementptr i8, ptr %v3150, i64 8
  store ptr %v3119, ptr %v3151, align 8, !tbaa !3
  %v3152 = getelementptr i8, ptr %v3150, i64 16
  store ptr %v3121, ptr %v3152, align 8, !tbaa !3
  %v3468 = call ptr @mlf_env_new(i64 7)
  %v3469 = getelementptr i8, ptr %v3468, i64 8
  store ptr %v3119, ptr %v3469, align 8, !tbaa !3
  %v3470 = getelementptr i8, ptr %v3468, i64 16
  store ptr %v3121, ptr %v3470, align 8, !tbaa !3
  %v3471 = getelementptr i8, ptr %v3468, i64 24
  store ptr %v3123, ptr %v3471, align 8, !tbaa !3
  %v3472 = getelementptr i8, ptr %v3468, i64 32
  store ptr %v3125, ptr %v3472, align 8, !tbaa !3
  %v3473 = getelementptr i8, ptr %v3468, i64 40
  store ptr %v3127, ptr %v3473, align 8, !tbaa !3
  %v3474 = getelementptr i8, ptr %v3468, i64 48
  store ptr %v3129, ptr %v3474, align 8, !tbaa !3
  %v3475 = getelementptr i8, ptr %v3468, i64 56
  store ptr %arg, ptr %v3475, align 8, !tbaa !3
  %v3476 = call ptr @mlf_closure(ptr @mlf.code.3153, ptr %v3468)
  %v3477 = call ptr @mlf_prim2(i64 1, ptr %v3148, ptr %v3476)
  ret ptr %v3477
}

define private ptr @mlf.code.3083(ptr %env, ptr %arg) {
entry:
  %v3084 = getelementptr i8, ptr %env, i64 8
  %v3085 = load ptr, ptr %v3084, align 8, !tbaa !3
  %v3086 = getelementptr i8, ptr %env, i64 16
  %v3087 = load ptr, ptr %v3086, align 8, !tbaa !3
  %v3088 = getelementptr i8, ptr %env, i64 24
  %v3089 = load ptr, ptr %v3088, align 8, !tbaa !3
  %v3090 = getelementptr i8, ptr %env, i64 32
  %v3091 = load ptr, ptr %v3090, align 8, !tbaa !3
  %v3092 = getelementptr i8, ptr %env, i64 40
  %v3093 = load ptr, ptr %v3092, align 8, !tbaa !3
  %v3112 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3094, i64 2)
  %v3113 = getelementptr i8, ptr %v3112, i64 16
  %v3114 = load ptr, ptr %v3113, align 8, !tbaa !3
  %v3115 = getelementptr i8, ptr %v3114, i64 8
  store ptr %v3085, ptr %v3115, align 8, !tbaa !3
  %v3116 = getelementptr i8, ptr %v3114, i64 16
  store ptr %v3087, ptr %v3116, align 8, !tbaa !3
  %v3478 = call ptr @mlf_env_new(i64 6)
  %v3479 = getelementptr i8, ptr %v3478, i64 8
  store ptr %v3085, ptr %v3479, align 8, !tbaa !3
  %v3480 = getelementptr i8, ptr %v3478, i64 16
  store ptr %v3087, ptr %v3480, align 8, !tbaa !3
  %v3481 = getelementptr i8, ptr %v3478, i64 24
  store ptr %v3089, ptr %v3481, align 8, !tbaa !3
  %v3482 = getelementptr i8, ptr %v3478, i64 32
  store ptr %v3091, ptr %v3482, align 8, !tbaa !3
  %v3483 = getelementptr i8, ptr %v3478, i64 40
  store ptr %v3093, ptr %v3483, align 8, !tbaa !3
  %v3484 = getelementptr i8, ptr %v3478, i64 48
  store ptr %arg, ptr %v3484, align 8, !tbaa !3
  %v3485 = call ptr @mlf_closure(ptr @mlf.code.3117, ptr %v3478)
  %v3486 = call ptr @mlf_prim2(i64 1, ptr %v3112, ptr %v3485)
  ret ptr %v3486
}

define private ptr @mlf.code.3051(ptr %env, ptr %arg) {
entry:
  %v3052 = getelementptr i8, ptr %env, i64 8
  %v3053 = load ptr, ptr %v3052, align 8, !tbaa !3
  %v3054 = getelementptr i8, ptr %env, i64 16
  %v3055 = load ptr, ptr %v3054, align 8, !tbaa !3
  %v3056 = getelementptr i8, ptr %env, i64 24
  %v3057 = load ptr, ptr %v3056, align 8, !tbaa !3
  %v3058 = getelementptr i8, ptr %env, i64 32
  %v3059 = load ptr, ptr %v3058, align 8, !tbaa !3
  %v3078 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3060, i64 2)
  %v3079 = getelementptr i8, ptr %v3078, i64 16
  %v3080 = load ptr, ptr %v3079, align 8, !tbaa !3
  %v3081 = getelementptr i8, ptr %v3080, i64 8
  store ptr %v3053, ptr %v3081, align 8, !tbaa !3
  %v3082 = getelementptr i8, ptr %v3080, i64 16
  store ptr %v3055, ptr %v3082, align 8, !tbaa !3
  %v3487 = call ptr @mlf_env_new(i64 5)
  %v3488 = getelementptr i8, ptr %v3487, i64 8
  store ptr %v3053, ptr %v3488, align 8, !tbaa !3
  %v3489 = getelementptr i8, ptr %v3487, i64 16
  store ptr %v3055, ptr %v3489, align 8, !tbaa !3
  %v3490 = getelementptr i8, ptr %v3487, i64 24
  store ptr %v3057, ptr %v3490, align 8, !tbaa !3
  %v3491 = getelementptr i8, ptr %v3487, i64 32
  store ptr %v3059, ptr %v3491, align 8, !tbaa !3
  %v3492 = getelementptr i8, ptr %v3487, i64 40
  store ptr %arg, ptr %v3492, align 8, !tbaa !3
  %v3493 = call ptr @mlf_closure(ptr @mlf.code.3083, ptr %v3487)
  %v3494 = call ptr @mlf_prim2(i64 1, ptr %v3078, ptr %v3493)
  ret ptr %v3494
}

define private ptr @mlf.worker.16(ptr %a0, ptr %a1, ptr %a2, ptr %a3) {
entry:
  %v3022 = call ptr @mlf_prim2(i64 10, ptr %a2, ptr inttoptr (i64 71 to ptr))
  %v3023 = icmp eq ptr %v3022, inttoptr (i64 6 to ptr)
  br i1 %v3023, label %yes.3024, label %no.3025
yes.3024:
  %v3027 = call ptr @mlf_prim1(i64 0, ptr %a3)
  br label %join.3026
no.3025:
  %v3046 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3028, i64 2)
  %v3047 = getelementptr i8, ptr %v3046, i64 16
  %v3048 = load ptr, ptr %v3047, align 8, !tbaa !3
  %v3049 = getelementptr i8, ptr %v3048, i64 8
  store ptr %a0, ptr %v3049, align 8, !tbaa !3
  %v3050 = getelementptr i8, ptr %v3048, i64 16
  store ptr %a1, ptr %v3050, align 8, !tbaa !3
  %v3495 = call ptr @mlf_env_new(i64 4)
  %v3496 = getelementptr i8, ptr %v3495, i64 8
  store ptr %a0, ptr %v3496, align 8, !tbaa !3
  %v3497 = getelementptr i8, ptr %v3495, i64 16
  store ptr %a1, ptr %v3497, align 8, !tbaa !3
  %v3498 = getelementptr i8, ptr %v3495, i64 24
  store ptr %a2, ptr %v3498, align 8, !tbaa !3
  %v3499 = getelementptr i8, ptr %v3495, i64 32
  store ptr %a3, ptr %v3499, align 8, !tbaa !3
  %v3500 = call ptr @mlf_closure(ptr @mlf.code.3051, ptr %v3495)
  %v3501 = call ptr @mlf_prim2(i64 1, ptr %v3046, ptr %v3500)
  br label %join.3026
join.3026:
  %v3502 = phi ptr [ %v3027, %yes.3024 ], [ %v3501, %no.3025 ]
  ret ptr %v3502
}

define private ptr @mlf.numeric.entry.2847(ptr %env, ptr %arg) {
entry:
  %v2848 = getelementptr i8, ptr %env, i64 8
  %v2849 = load ptr, ptr %v2848, align 8, !tbaa !3
  %v2850 = getelementptr i8, ptr %env, i64 16
  %v2851 = load ptr, ptr %v2850, align 8, !tbaa !3
  %v2852 = getelementptr i8, ptr %env, i64 24
  %v2853 = load ptr, ptr %v2852, align 8, !tbaa !3
  %v2854 = getelementptr i8, ptr %env, i64 32
  %v2855 = load ptr, ptr %v2854, align 8, !tbaa !3
  %v2856 = call ptr @mlf_peek(ptr %v2849)
  %v2857 = call ptr @mlf_peek(ptr %v2851)
  %v2858 = call ptr @mlf_peek(ptr %v2853)
  %v2859 = call ptr @mlf_peek(ptr %v2855)
  %v2860 = icmp ne ptr %v2856, null
  %v2861 = icmp ne ptr %v2857, null
  %v2862 = icmp ne ptr %v2858, null
  %v2863 = icmp ne ptr %v2859, null
  %v2864 = and i1 true, %v2860
  %v2865 = and i1 %v2864, %v2861
  %v2866 = and i1 %v2865, %v2862
  %v2867 = and i1 %v2866, %v2863
  br i1 %v2867, label %yes.2868, label %no.2869
yes.2868:
  %v3020 = call ptr @mlf.numeric.16(ptr %v2856, ptr %v2857, ptr %v2858, ptr %v2859)
  %v3021 = call ptr @mlf_prim1(i64 0, ptr %v3020)
  br label %join.2870
no.2869:
  %v3503 = call ptr @mlf.force(ptr %v2853)
  %v3504 = call ptr @mlf.worker.16(ptr %v2849, ptr %v2851, ptr %v3503, ptr %v2855)
  br label %join.2870
join.2870:
  %v3505 = phi ptr [ %v3021, %yes.2868 ], [ %v3504, %no.2869 ]
  ret ptr %v3505
}

define private ptr @mlf.code.3508(ptr %env, ptr %arg) {
entry:
  %v3509 = getelementptr i8, ptr %env, i64 8
  %v3510 = load ptr, ptr %v3509, align 8, !tbaa !3
  %v3511 = getelementptr i8, ptr %env, i64 16
  %v3512 = load ptr, ptr %v3511, align 8, !tbaa !3
  %v3513 = getelementptr i8, ptr %env, i64 24
  %v3514 = load ptr, ptr %v3513, align 8, !tbaa !3
  %v3515 = getelementptr i8, ptr %env, i64 32
  %v3516 = load ptr, ptr %v3515, align 8, !tbaa !3
  %v3517 = getelementptr i8, ptr %env, i64 40
  %v3518 = load ptr, ptr %v3517, align 8, !tbaa !3
  %v3519 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3519, align 8, !tbaa !3
  %v3520 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v3520, align 8, !tbaa !3
  %v3521 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v3521, align 8, !tbaa !3
  %v3522 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v3522, align 8, !tbaa !3
  %v3523 = getelementptr i8, ptr %env, i64 40
  store ptr null, ptr %v3523, align 8, !tbaa !3
  %v3524 = call ptr @mlf.force(ptr %v3510)
  %v3525 = call ptr @mlf_double(double 0x3fe0000000000000)
  %v3526 = call ptr @mlf.force(ptr %v3518)
  %v3527 = call ptr @mlf_prim2(i64 20, ptr %v3525, ptr %v3526)
  %v3528 = call ptr @mlf.force(ptr %v3512)
  %v3529 = call ptr @mlf_prim2(i64 20, ptr %v3528, ptr %v3528)
  %v3530 = call ptr @mlf.force(ptr %v3514)
  %v3531 = call ptr @mlf_prim2(i64 20, ptr %v3530, ptr %v3530)
  %v3532 = call ptr @mlf_prim2(i64 18, ptr %v3529, ptr %v3531)
  %v3533 = call ptr @mlf.force(ptr %v3516)
  %v3534 = call ptr @mlf_prim2(i64 20, ptr %v3533, ptr %v3533)
  %v3535 = call ptr @mlf_prim2(i64 18, ptr %v3532, ptr %v3534)
  %v3536 = call ptr @mlf_prim2(i64 20, ptr %v3527, ptr %v3535)
  %v3537 = call ptr @mlf_prim2(i64 18, ptr %v3524, ptr %v3536)
  ret ptr %v3537
}

define private ptr @mlf.code.2825(ptr %env, ptr %arg) {
entry:
  %v2826 = getelementptr i8, ptr %env, i64 8
  %v2827 = load ptr, ptr %v2826, align 8, !tbaa !3
  %v2828 = getelementptr i8, ptr %env, i64 16
  %v2829 = load ptr, ptr %v2828, align 8, !tbaa !3
  %v2830 = getelementptr i8, ptr %env, i64 24
  %v2831 = load ptr, ptr %v2830, align 8, !tbaa !3
  %v2832 = getelementptr i8, ptr %env, i64 32
  %v2833 = load ptr, ptr %v2832, align 8, !tbaa !3
  %v2834 = getelementptr i8, ptr %env, i64 40
  %v2835 = load ptr, ptr %v2834, align 8, !tbaa !3
  %v2836 = getelementptr i8, ptr %env, i64 48
  %v2837 = load ptr, ptr %v2836, align 8, !tbaa !3
  %v2838 = getelementptr i8, ptr %env, i64 56
  %v2839 = load ptr, ptr %v2838, align 8, !tbaa !3
  %v2840 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2840, align 8, !tbaa !3
  %v2841 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2841, align 8, !tbaa !3
  %v2842 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v2842, align 8, !tbaa !3
  %v2843 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v2843, align 8, !tbaa !3
  %v2844 = getelementptr i8, ptr %env, i64 40
  store ptr null, ptr %v2844, align 8, !tbaa !3
  %v2845 = getelementptr i8, ptr %env, i64 48
  store ptr null, ptr %v2845, align 8, !tbaa !3
  %v2846 = getelementptr i8, ptr %env, i64 56
  store ptr null, ptr %v2846, align 8, !tbaa !3
  %v3506 = call ptr @mlf.force(ptr %v2829)
  %v3507 = call ptr @mlf_prim2(i64 8, ptr %v3506, ptr inttoptr (i64 15 to ptr))
  %v3538 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3508, i64 5)
  %v3539 = getelementptr i8, ptr %v3538, i64 16
  %v3540 = load ptr, ptr %v3539, align 8, !tbaa !3
  %v3541 = getelementptr i8, ptr %v3540, i64 8
  store ptr %v2831, ptr %v3541, align 8, !tbaa !3
  %v3542 = getelementptr i8, ptr %v3540, i64 16
  store ptr %v2833, ptr %v3542, align 8, !tbaa !3
  %v3543 = getelementptr i8, ptr %v3540, i64 24
  store ptr %v2835, ptr %v3543, align 8, !tbaa !3
  %v3544 = getelementptr i8, ptr %v3540, i64 32
  store ptr %v2837, ptr %v3544, align 8, !tbaa !3
  %v3545 = getelementptr i8, ptr %v3540, i64 40
  store ptr %v2839, ptr %v3545, align 8, !tbaa !3
  %v3546 = call ptr @mlf_env_new(i64 4)
  %v3547 = getelementptr i8, ptr %v3546, i64 8
  store ptr %v2827, ptr %v3547, align 8, !tbaa !3
  %v3548 = getelementptr i8, ptr %v3546, i64 16
  store ptr %v2829, ptr %v3548, align 8, !tbaa !3
  %v3549 = getelementptr i8, ptr %v3546, i64 24
  store ptr %v3507, ptr %v3549, align 8, !tbaa !3
  %v3550 = getelementptr i8, ptr %v3546, i64 32
  store ptr %v3538, ptr %v3550, align 8, !tbaa !3
  %v3551 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2847, ptr %v3546)
  ret ptr %v3551
}

define private ptr @mlf.code.3562(ptr %env, ptr %arg) {
entry:
  %v3563 = getelementptr i8, ptr %env, i64 8
  %v3564 = load ptr, ptr %v3563, align 8, !tbaa !3
  %v3565 = getelementptr i8, ptr %env, i64 16
  %v3566 = load ptr, ptr %v3565, align 8, !tbaa !3
  %v3567 = call ptr @mlf.force(ptr %v3566)
  %v3568 = call ptr @mlf_prim2(i64 8, ptr %v3567, ptr inttoptr (i64 15 to ptr))
  %v3569 = call ptr @mlf_env_new(i64 3)
  %v3570 = getelementptr i8, ptr %v3569, i64 8
  store ptr %v3564, ptr %v3570, align 8, !tbaa !3
  %v3571 = getelementptr i8, ptr %v3569, i64 16
  store ptr %v3568, ptr %v3571, align 8, !tbaa !3
  %v3572 = getelementptr i8, ptr %v3569, i64 24
  store ptr %arg, ptr %v3572, align 8, !tbaa !3
  %v3573 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2327, ptr %v3569)
  ret ptr %v3573
}

define private ptr @mlf.code.2812(ptr %env, ptr %arg) {
entry:
  %v2813 = getelementptr i8, ptr %env, i64 8
  %v2814 = load ptr, ptr %v2813, align 8, !tbaa !3
  %v2815 = getelementptr i8, ptr %env, i64 16
  %v2816 = load ptr, ptr %v2815, align 8, !tbaa !3
  %v2817 = getelementptr i8, ptr %env, i64 24
  %v2818 = load ptr, ptr %v2817, align 8, !tbaa !3
  %v2819 = getelementptr i8, ptr %env, i64 32
  %v2820 = load ptr, ptr %v2819, align 8, !tbaa !3
  %v2821 = getelementptr i8, ptr %env, i64 40
  %v2822 = load ptr, ptr %v2821, align 8, !tbaa !3
  %v2823 = getelementptr i8, ptr %env, i64 48
  %v2824 = load ptr, ptr %v2823, align 8, !tbaa !3
  %v3552 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2825, i64 7)
  %v3553 = getelementptr i8, ptr %v3552, i64 16
  %v3554 = load ptr, ptr %v3553, align 8, !tbaa !3
  %v3555 = getelementptr i8, ptr %v3554, i64 8
  store ptr %v2814, ptr %v3555, align 8, !tbaa !3
  %v3556 = getelementptr i8, ptr %v3554, i64 16
  store ptr %v2816, ptr %v3556, align 8, !tbaa !3
  %v3557 = getelementptr i8, ptr %v3554, i64 24
  store ptr %v2818, ptr %v3557, align 8, !tbaa !3
  %v3558 = getelementptr i8, ptr %v3554, i64 32
  store ptr %v2820, ptr %v3558, align 8, !tbaa !3
  %v3559 = getelementptr i8, ptr %v3554, i64 40
  store ptr %v2822, ptr %v3559, align 8, !tbaa !3
  %v3560 = getelementptr i8, ptr %v3554, i64 48
  store ptr %v2824, ptr %v3560, align 8, !tbaa !3
  %v3561 = getelementptr i8, ptr %v3554, i64 56
  store ptr %arg, ptr %v3561, align 8, !tbaa !3
  %v3574 = call ptr @mlf_env_new(i64 2)
  %v3575 = getelementptr i8, ptr %v3574, i64 8
  store ptr %v2814, ptr %v3575, align 8, !tbaa !3
  %v3576 = getelementptr i8, ptr %v3574, i64 16
  store ptr %v2816, ptr %v3576, align 8, !tbaa !3
  %v3577 = call ptr @mlf_closure(ptr @mlf.code.3562, ptr %v3574)
  %v3578 = call ptr @mlf_prim2(i64 1, ptr %v3552, ptr %v3577)
  ret ptr %v3578
}

define private ptr @mlf.code.2778(ptr %env, ptr %arg) {
entry:
  %v2779 = getelementptr i8, ptr %env, i64 8
  %v2780 = load ptr, ptr %v2779, align 8, !tbaa !3
  %v2781 = getelementptr i8, ptr %env, i64 16
  %v2782 = load ptr, ptr %v2781, align 8, !tbaa !3
  %v2783 = getelementptr i8, ptr %env, i64 24
  %v2784 = load ptr, ptr %v2783, align 8, !tbaa !3
  %v2785 = getelementptr i8, ptr %env, i64 32
  %v2786 = load ptr, ptr %v2785, align 8, !tbaa !3
  %v2787 = getelementptr i8, ptr %env, i64 40
  %v2788 = load ptr, ptr %v2787, align 8, !tbaa !3
  %v2807 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2789, i64 2)
  %v2808 = getelementptr i8, ptr %v2807, i64 16
  %v2809 = load ptr, ptr %v2808, align 8, !tbaa !3
  %v2810 = getelementptr i8, ptr %v2809, i64 8
  store ptr %v2780, ptr %v2810, align 8, !tbaa !3
  %v2811 = getelementptr i8, ptr %v2809, i64 16
  store ptr %v2782, ptr %v2811, align 8, !tbaa !3
  %v3579 = call ptr @mlf_env_new(i64 6)
  %v3580 = getelementptr i8, ptr %v3579, i64 8
  store ptr %v2780, ptr %v3580, align 8, !tbaa !3
  %v3581 = getelementptr i8, ptr %v3579, i64 16
  store ptr %v2782, ptr %v3581, align 8, !tbaa !3
  %v3582 = getelementptr i8, ptr %v3579, i64 24
  store ptr %v2784, ptr %v3582, align 8, !tbaa !3
  %v3583 = getelementptr i8, ptr %v3579, i64 32
  store ptr %v2786, ptr %v3583, align 8, !tbaa !3
  %v3584 = getelementptr i8, ptr %v3579, i64 40
  store ptr %v2788, ptr %v3584, align 8, !tbaa !3
  %v3585 = getelementptr i8, ptr %v3579, i64 48
  store ptr %arg, ptr %v3585, align 8, !tbaa !3
  %v3586 = call ptr @mlf_closure(ptr @mlf.code.2812, ptr %v3579)
  %v3587 = call ptr @mlf_prim2(i64 1, ptr %v2807, ptr %v3586)
  ret ptr %v3587
}

define private ptr @mlf.code.2746(ptr %env, ptr %arg) {
entry:
  %v2747 = getelementptr i8, ptr %env, i64 8
  %v2748 = load ptr, ptr %v2747, align 8, !tbaa !3
  %v2749 = getelementptr i8, ptr %env, i64 16
  %v2750 = load ptr, ptr %v2749, align 8, !tbaa !3
  %v2751 = getelementptr i8, ptr %env, i64 24
  %v2752 = load ptr, ptr %v2751, align 8, !tbaa !3
  %v2753 = getelementptr i8, ptr %env, i64 32
  %v2754 = load ptr, ptr %v2753, align 8, !tbaa !3
  %v2773 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2755, i64 2)
  %v2774 = getelementptr i8, ptr %v2773, i64 16
  %v2775 = load ptr, ptr %v2774, align 8, !tbaa !3
  %v2776 = getelementptr i8, ptr %v2775, i64 8
  store ptr %v2748, ptr %v2776, align 8, !tbaa !3
  %v2777 = getelementptr i8, ptr %v2775, i64 16
  store ptr %v2750, ptr %v2777, align 8, !tbaa !3
  %v3588 = call ptr @mlf_env_new(i64 5)
  %v3589 = getelementptr i8, ptr %v3588, i64 8
  store ptr %v2748, ptr %v3589, align 8, !tbaa !3
  %v3590 = getelementptr i8, ptr %v3588, i64 16
  store ptr %v2750, ptr %v3590, align 8, !tbaa !3
  %v3591 = getelementptr i8, ptr %v3588, i64 24
  store ptr %v2752, ptr %v3591, align 8, !tbaa !3
  %v3592 = getelementptr i8, ptr %v3588, i64 32
  store ptr %v2754, ptr %v3592, align 8, !tbaa !3
  %v3593 = getelementptr i8, ptr %v3588, i64 40
  store ptr %arg, ptr %v3593, align 8, !tbaa !3
  %v3594 = call ptr @mlf_closure(ptr @mlf.code.2778, ptr %v3588)
  %v3595 = call ptr @mlf_prim2(i64 1, ptr %v2773, ptr %v3594)
  ret ptr %v3595
}

define private ptr @mlf.code.2716(ptr %env, ptr %arg) {
entry:
  %v2717 = getelementptr i8, ptr %env, i64 8
  %v2718 = load ptr, ptr %v2717, align 8, !tbaa !3
  %v2719 = getelementptr i8, ptr %env, i64 16
  %v2720 = load ptr, ptr %v2719, align 8, !tbaa !3
  %v2721 = getelementptr i8, ptr %env, i64 24
  %v2722 = load ptr, ptr %v2721, align 8, !tbaa !3
  %v2741 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2723, i64 2)
  %v2742 = getelementptr i8, ptr %v2741, i64 16
  %v2743 = load ptr, ptr %v2742, align 8, !tbaa !3
  %v2744 = getelementptr i8, ptr %v2743, i64 8
  store ptr %v2718, ptr %v2744, align 8, !tbaa !3
  %v2745 = getelementptr i8, ptr %v2743, i64 16
  store ptr %v2720, ptr %v2745, align 8, !tbaa !3
  %v3596 = call ptr @mlf_env_new(i64 4)
  %v3597 = getelementptr i8, ptr %v3596, i64 8
  store ptr %v2718, ptr %v3597, align 8, !tbaa !3
  %v3598 = getelementptr i8, ptr %v3596, i64 16
  store ptr %v2720, ptr %v3598, align 8, !tbaa !3
  %v3599 = getelementptr i8, ptr %v3596, i64 24
  store ptr %v2722, ptr %v3599, align 8, !tbaa !3
  %v3600 = getelementptr i8, ptr %v3596, i64 32
  store ptr %arg, ptr %v3600, align 8, !tbaa !3
  %v3601 = call ptr @mlf_closure(ptr @mlf.code.2746, ptr %v3596)
  %v3602 = call ptr @mlf_prim2(i64 1, ptr %v2741, ptr %v3601)
  ret ptr %v3602
}

define private ptr @mlf.worker.33(ptr %a0, ptr %a1, ptr %a2) {
entry:
  %v2687 = call ptr @mlf_prim2(i64 10, ptr %a1, ptr inttoptr (i64 71 to ptr))
  %v2688 = icmp eq ptr %v2687, inttoptr (i64 6 to ptr)
  br i1 %v2688, label %yes.2689, label %no.2690
yes.2689:
  %v2692 = call ptr @mlf_prim1(i64 0, ptr %a2)
  br label %join.2691
no.2690:
  %v2711 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2693, i64 2)
  %v2712 = getelementptr i8, ptr %v2711, i64 16
  %v2713 = load ptr, ptr %v2712, align 8, !tbaa !3
  %v2714 = getelementptr i8, ptr %v2713, i64 8
  store ptr %a0, ptr %v2714, align 8, !tbaa !3
  %v2715 = getelementptr i8, ptr %v2713, i64 16
  store ptr %a1, ptr %v2715, align 8, !tbaa !3
  %v3603 = call ptr @mlf_env_new(i64 3)
  %v3604 = getelementptr i8, ptr %v3603, i64 8
  store ptr %a0, ptr %v3604, align 8, !tbaa !3
  %v3605 = getelementptr i8, ptr %v3603, i64 16
  store ptr %a1, ptr %v3605, align 8, !tbaa !3
  %v3606 = getelementptr i8, ptr %v3603, i64 24
  store ptr %a2, ptr %v3606, align 8, !tbaa !3
  %v3607 = call ptr @mlf_closure(ptr @mlf.code.2716, ptr %v3603)
  %v3608 = call ptr @mlf_prim2(i64 1, ptr %v2711, ptr %v3607)
  br label %join.2691
join.2691:
  %v3609 = phi ptr [ %v2692, %yes.2689 ], [ %v3608, %no.2690 ]
  ret ptr %v3609
}

define private ptr @mlf.numeric.entry.2327(ptr %env, ptr %arg) {
entry:
  %v2328 = getelementptr i8, ptr %env, i64 8
  %v2329 = load ptr, ptr %v2328, align 8, !tbaa !3
  %v2330 = getelementptr i8, ptr %env, i64 16
  %v2331 = load ptr, ptr %v2330, align 8, !tbaa !3
  %v2332 = getelementptr i8, ptr %env, i64 24
  %v2333 = load ptr, ptr %v2332, align 8, !tbaa !3
  %v2334 = call ptr @mlf_peek(ptr %v2329)
  %v2335 = call ptr @mlf_peek(ptr %v2331)
  %v2336 = call ptr @mlf_peek(ptr %v2333)
  %v2337 = icmp ne ptr %v2334, null
  %v2338 = icmp ne ptr %v2335, null
  %v2339 = icmp ne ptr %v2336, null
  %v2340 = and i1 true, %v2337
  %v2341 = and i1 %v2340, %v2338
  %v2342 = and i1 %v2341, %v2339
  br i1 %v2342, label %yes.2343, label %no.2344
yes.2343:
  %v2685 = call ptr @mlf.numeric.33(ptr %v2334, ptr %v2335, ptr %v2336)
  %v2686 = call ptr @mlf_prim1(i64 0, ptr %v2685)
  br label %join.2345
no.2344:
  %v3610 = call ptr @mlf.force(ptr %v2331)
  %v3611 = call ptr @mlf.worker.33(ptr %v2329, ptr %v3610, ptr %v2333)
  br label %join.2345
join.2345:
  %v3612 = phi ptr [ %v2686, %yes.2343 ], [ %v3611, %no.2344 ]
  ret ptr %v3612
}

define private ptr @mlf.code.2323(ptr %env, ptr %arg) {
entry:
  %v2324 = getelementptr i8, ptr %env, i64 8
  %v2325 = load ptr, ptr %v2324, align 8, !tbaa !3
  %v2326 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2326, align 8, !tbaa !3
  %v3613 = call ptr @mlf_double(double 0x0000000000000000)
  %v3614 = call ptr @mlf_env_new(i64 3)
  %v3615 = getelementptr i8, ptr %v3614, i64 8
  store ptr %v2325, ptr %v3615, align 8, !tbaa !3
  %v3616 = getelementptr i8, ptr %v3614, i64 16
  store ptr inttoptr (i64 1 to ptr), ptr %v3616, align 8, !tbaa !3
  %v3617 = getelementptr i8, ptr %v3614, i64 24
  store ptr %v3613, ptr %v3617, align 8, !tbaa !3
  %v3618 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2327, ptr %v3614)
  ret ptr %v3618
}

define private ptr @mlf.code.3632(ptr %env, ptr %arg) {
entry:
  %v3633 = getelementptr i8, ptr %env, i64 8
  %v3634 = load ptr, ptr %v3633, align 8, !tbaa !3
  %v3635 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3635, align 8, !tbaa !3
  %v3636 = call ptr @mlf.force(ptr %v3634)
  %v3637 = call ptr @mlf_prim2(i64 26, ptr inttoptr (i64 19 to ptr), ptr %v3636)
  ret ptr %v3637
}

define private ptr @mlf.code.3628(ptr %env, ptr %arg) {
entry:
  %v3629 = getelementptr i8, ptr %env, i64 8
  %v3630 = load ptr, ptr %v3629, align 8, !tbaa !3
  %v3631 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3631, align 8, !tbaa !3
  %v3638 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3632, i64 1)
  %v3639 = getelementptr i8, ptr %v3638, i64 16
  %v3640 = load ptr, ptr %v3639, align 8, !tbaa !3
  %v3641 = getelementptr i8, ptr %v3640, i64 8
  store ptr %v3630, ptr %v3641, align 8, !tbaa !3
  %v3642 = call ptr @mlf_prim1(i64 3, ptr %v3638)
  ret ptr %v3642
}

define private ptr @mlf.numeric.42(ptr %a0, ptr %a1, ptr %a2) alwaysinline {
entry:
  %v3723 = ptrtoint ptr %a2 to i64
  %v3724 = ptrtoint ptr inttoptr (i64 71 to ptr) to i64
  %v3725 = and i64 %v3723, %v3724
  %v3726 = and i64 %v3725, 1
  %v3727 = icmp ne i64 %v3726, 0
  br i1 %v3727, label %yes.3728, label %no.3729
yes.3728:
  %v3731 = icmp eq i64 %v3723, %v3724
  %v3732 = select i1 %v3731, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.3730
no.3729:
  %v3733 = call ptr @mlf_eq_int(ptr %a2, ptr inttoptr (i64 71 to ptr))
  br label %join.3730
join.3730:
  %v3734 = phi ptr [ %v3732, %yes.3728 ], [ %v3733, %no.3729 ]
  %v3735 = icmp eq ptr %v3734, inttoptr (i64 6 to ptr)
  br i1 %v3735, label %tail.yes.3736, label %tail.no.3737
tail.yes.3736:
  ret ptr inttoptr (i64 4 to ptr)
tail.no.3737:
  %v3738 = getelementptr i8, ptr %a0, i64 8
  %v3739 = load i64, ptr %v3738, align 8, !tbaa !3
  %v3740 = getelementptr i8, ptr %a0, i64 16
  %v3741 = load ptr, ptr %v3740, align 8, !tbaa !3
  %v3742 = ptrtoint ptr %a1 to i64
  %v3743 = ashr i64 %v3742, 1
  %v3744 = and i64 %v3742, 1
  %v3745 = icmp ne i64 %v3744, 0
  %v3746 = icmp ult i64 %v3743, %v3739
  %v3747 = and i1 %v3745, %v3746
  br i1 %v3747, label %array.valid.3748, label %array.invalid.3749
array.invalid.3749:
  call void @mlf_bounds_failure()
  unreachable
array.valid.3748:
  %v3750 = getelementptr i64, ptr %v3741, i64 %v3743
  %v3751 = load double, ptr %v3750, align 8, !tbaa !4
  %v3752 = ptrtoint ptr %a1 to i64
  %v3753 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v3754 = sub i64 %v3753, 1
  %v3755 = add nsw i64 %v3752, %v3754
  %v3756 = inttoptr i64 %v3755 to ptr
  %v3757 = ptrtoint ptr %v3756 to i64
  %v3758 = ashr i64 %v3757, 1
  %v3759 = and i64 %v3757, 1
  %v3760 = icmp ne i64 %v3759, 0
  %v3761 = icmp ult i64 %v3758, %v3739
  %v3762 = and i1 %v3760, %v3761
  br i1 %v3762, label %array.valid.3763, label %array.invalid.3764
array.invalid.3764:
  call void @mlf_bounds_failure()
  unreachable
array.valid.3763:
  %v3765 = getelementptr i64, ptr %v3741, i64 %v3758
  %v3766 = load double, ptr %v3765, align 8, !tbaa !4
  %v3767 = ptrtoint ptr %a1 to i64
  %v3768 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v3769 = sub i64 %v3768, 1
  %v3770 = add nsw i64 %v3767, %v3769
  %v3771 = inttoptr i64 %v3770 to ptr
  %v3772 = ptrtoint ptr %v3771 to i64
  %v3773 = ashr i64 %v3772, 1
  %v3774 = and i64 %v3772, 1
  %v3775 = icmp ne i64 %v3774, 0
  %v3776 = icmp ult i64 %v3773, %v3739
  %v3777 = and i1 %v3775, %v3776
  br i1 %v3777, label %array.valid.3778, label %array.invalid.3779
array.invalid.3779:
  call void @mlf_bounds_failure()
  unreachable
array.valid.3778:
  %v3780 = getelementptr i64, ptr %v3741, i64 %v3773
  %v3781 = load double, ptr %v3780, align 8, !tbaa !4
  %v3782 = ptrtoint ptr %a1 to i64
  %v3783 = ptrtoint ptr inttoptr (i64 13 to ptr) to i64
  %v3784 = sub i64 %v3783, 1
  %v3785 = add nsw i64 %v3782, %v3784
  %v3786 = inttoptr i64 %v3785 to ptr
  %v3787 = ptrtoint ptr %v3786 to i64
  %v3788 = ashr i64 %v3787, 1
  %v3789 = and i64 %v3787, 1
  %v3790 = icmp ne i64 %v3789, 0
  %v3791 = icmp ult i64 %v3788, %v3739
  %v3792 = and i1 %v3790, %v3791
  br i1 %v3792, label %array.valid.3793, label %array.invalid.3794
array.invalid.3794:
  call void @mlf_bounds_failure()
  unreachable
array.valid.3793:
  %v3795 = getelementptr i64, ptr %v3741, i64 %v3788
  %v3796 = load double, ptr %v3795, align 8, !tbaa !4
  %v3797 = ptrtoint ptr %a2 to i64
  %v3798 = ashr i64 %v3797, 1
  %v3799 = and i64 %v3797, 1
  %v3800 = icmp ne i64 %v3799, 0
  %v3801 = icmp ult i64 %v3798, %v3739
  %v3802 = and i1 %v3800, %v3801
  br i1 %v3802, label %array.valid.3803, label %array.invalid.3804
array.invalid.3804:
  call void @mlf_bounds_failure()
  unreachable
array.valid.3803:
  %v3805 = getelementptr i64, ptr %v3741, i64 %v3798
  %v3806 = load double, ptr %v3805, align 8, !tbaa !4
  %v3807 = ptrtoint ptr %a2 to i64
  %v3808 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v3809 = sub i64 %v3808, 1
  %v3810 = add nsw i64 %v3807, %v3809
  %v3811 = inttoptr i64 %v3810 to ptr
  %v3812 = ptrtoint ptr %v3811 to i64
  %v3813 = ashr i64 %v3812, 1
  %v3814 = and i64 %v3812, 1
  %v3815 = icmp ne i64 %v3814, 0
  %v3816 = icmp ult i64 %v3813, %v3739
  %v3817 = and i1 %v3815, %v3816
  br i1 %v3817, label %array.valid.3818, label %array.invalid.3819
array.invalid.3819:
  call void @mlf_bounds_failure()
  unreachable
array.valid.3818:
  %v3820 = getelementptr i64, ptr %v3741, i64 %v3813
  %v3821 = load double, ptr %v3820, align 8, !tbaa !4
  %v3822 = ptrtoint ptr %a2 to i64
  %v3823 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v3824 = sub i64 %v3823, 1
  %v3825 = add nsw i64 %v3822, %v3824
  %v3826 = inttoptr i64 %v3825 to ptr
  %v3827 = ptrtoint ptr %v3826 to i64
  %v3828 = ashr i64 %v3827, 1
  %v3829 = and i64 %v3827, 1
  %v3830 = icmp ne i64 %v3829, 0
  %v3831 = icmp ult i64 %v3828, %v3739
  %v3832 = and i1 %v3830, %v3831
  br i1 %v3832, label %array.valid.3833, label %array.invalid.3834
array.invalid.3834:
  call void @mlf_bounds_failure()
  unreachable
array.valid.3833:
  %v3835 = getelementptr i64, ptr %v3741, i64 %v3828
  %v3836 = load double, ptr %v3835, align 8, !tbaa !4
  %v3837 = ptrtoint ptr %a2 to i64
  %v3838 = ptrtoint ptr inttoptr (i64 13 to ptr) to i64
  %v3839 = sub i64 %v3838, 1
  %v3840 = add nsw i64 %v3837, %v3839
  %v3841 = inttoptr i64 %v3840 to ptr
  %v3842 = ptrtoint ptr %v3841 to i64
  %v3843 = ashr i64 %v3842, 1
  %v3844 = and i64 %v3842, 1
  %v3845 = icmp ne i64 %v3844, 0
  %v3846 = icmp ult i64 %v3843, %v3739
  %v3847 = and i1 %v3845, %v3846
  br i1 %v3847, label %array.valid.3848, label %array.invalid.3849
array.invalid.3849:
  call void @mlf_bounds_failure()
  unreachable
array.valid.3848:
  %v3850 = getelementptr i64, ptr %v3741, i64 %v3843
  %v3851 = load double, ptr %v3850, align 8, !tbaa !4
  %v3852 = fsub double %v3751, %v3806
  %v3853 = fsub double %v3766, %v3821
  %v3854 = fsub double %v3781, %v3836
  %v3855 = fmul double %v3852, %v3852
  %v3856 = fmul double %v3853, %v3853
  %v3857 = fadd double %v3855, %v3856
  %v3858 = fmul double %v3854, %v3854
  %v3859 = fadd double %v3857, %v3858
  %v3860 = call double @llvm.sqrt.f64(double %v3859)
  %v3861 = fmul double %v3860, %v3860
  %v3862 = fmul double %v3861, %v3860
  %v3863 = fdiv double 0x3f847ae147ae147b, %v3862
  %v3864 = ptrtoint ptr %a1 to i64
  %v3865 = ptrtoint ptr inttoptr (i64 7 to ptr) to i64
  %v3866 = sub i64 %v3865, 1
  %v3867 = add nsw i64 %v3864, %v3866
  %v3868 = inttoptr i64 %v3867 to ptr
  %v3869 = ptrtoint ptr %v3868 to i64
  %v3870 = ashr i64 %v3869, 1
  %v3871 = and i64 %v3869, 1
  %v3872 = icmp ne i64 %v3871, 0
  %v3873 = icmp ult i64 %v3870, %v3739
  %v3874 = and i1 %v3872, %v3873
  br i1 %v3874, label %array.valid.3875, label %array.invalid.3876
array.invalid.3876:
  call void @mlf_bounds_failure()
  unreachable
array.valid.3875:
  %v3877 = getelementptr i64, ptr %v3741, i64 %v3870
  %v3878 = load double, ptr %v3877, align 8, !tbaa !4
  %v3879 = ptrtoint ptr %a1 to i64
  %v3880 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v3881 = sub i64 %v3880, 1
  %v3882 = add nsw i64 %v3879, %v3881
  %v3883 = inttoptr i64 %v3882 to ptr
  %v3884 = ptrtoint ptr %v3883 to i64
  %v3885 = ashr i64 %v3884, 1
  %v3886 = and i64 %v3884, 1
  %v3887 = icmp ne i64 %v3886, 0
  %v3888 = icmp ult i64 %v3885, %v3739
  %v3889 = and i1 %v3887, %v3888
  br i1 %v3889, label %array.valid.3890, label %array.invalid.3891
array.invalid.3891:
  call void @mlf_bounds_failure()
  unreachable
array.valid.3890:
  %v3892 = getelementptr i64, ptr %v3741, i64 %v3885
  %v3893 = load double, ptr %v3892, align 8, !tbaa !4
  %v3894 = ptrtoint ptr %a1 to i64
  %v3895 = ptrtoint ptr inttoptr (i64 11 to ptr) to i64
  %v3896 = sub i64 %v3895, 1
  %v3897 = add nsw i64 %v3894, %v3896
  %v3898 = inttoptr i64 %v3897 to ptr
  %v3899 = ptrtoint ptr %v3898 to i64
  %v3900 = ashr i64 %v3899, 1
  %v3901 = and i64 %v3899, 1
  %v3902 = icmp ne i64 %v3901, 0
  %v3903 = icmp ult i64 %v3900, %v3739
  %v3904 = and i1 %v3902, %v3903
  br i1 %v3904, label %array.valid.3905, label %array.invalid.3906
array.invalid.3906:
  call void @mlf_bounds_failure()
  unreachable
array.valid.3905:
  %v3907 = getelementptr i64, ptr %v3741, i64 %v3900
  %v3908 = load double, ptr %v3907, align 8, !tbaa !4
  %v3909 = ptrtoint ptr %a2 to i64
  %v3910 = ptrtoint ptr inttoptr (i64 7 to ptr) to i64
  %v3911 = sub i64 %v3910, 1
  %v3912 = add nsw i64 %v3909, %v3911
  %v3913 = inttoptr i64 %v3912 to ptr
  %v3914 = ptrtoint ptr %v3913 to i64
  %v3915 = ashr i64 %v3914, 1
  %v3916 = and i64 %v3914, 1
  %v3917 = icmp ne i64 %v3916, 0
  %v3918 = icmp ult i64 %v3915, %v3739
  %v3919 = and i1 %v3917, %v3918
  br i1 %v3919, label %array.valid.3920, label %array.invalid.3921
array.invalid.3921:
  call void @mlf_bounds_failure()
  unreachable
array.valid.3920:
  %v3922 = getelementptr i64, ptr %v3741, i64 %v3915
  %v3923 = load double, ptr %v3922, align 8, !tbaa !4
  %v3924 = ptrtoint ptr %a2 to i64
  %v3925 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v3926 = sub i64 %v3925, 1
  %v3927 = add nsw i64 %v3924, %v3926
  %v3928 = inttoptr i64 %v3927 to ptr
  %v3929 = ptrtoint ptr %v3928 to i64
  %v3930 = ashr i64 %v3929, 1
  %v3931 = and i64 %v3929, 1
  %v3932 = icmp ne i64 %v3931, 0
  %v3933 = icmp ult i64 %v3930, %v3739
  %v3934 = and i1 %v3932, %v3933
  br i1 %v3934, label %array.valid.3935, label %array.invalid.3936
array.invalid.3936:
  call void @mlf_bounds_failure()
  unreachable
array.valid.3935:
  %v3937 = getelementptr i64, ptr %v3741, i64 %v3930
  %v3938 = load double, ptr %v3937, align 8, !tbaa !4
  %v3939 = ptrtoint ptr %a2 to i64
  %v3940 = ptrtoint ptr inttoptr (i64 11 to ptr) to i64
  %v3941 = sub i64 %v3940, 1
  %v3942 = add nsw i64 %v3939, %v3941
  %v3943 = inttoptr i64 %v3942 to ptr
  %v3944 = ptrtoint ptr %v3943 to i64
  %v3945 = ashr i64 %v3944, 1
  %v3946 = and i64 %v3944, 1
  %v3947 = icmp ne i64 %v3946, 0
  %v3948 = icmp ult i64 %v3945, %v3739
  %v3949 = and i1 %v3947, %v3948
  br i1 %v3949, label %array.valid.3950, label %array.invalid.3951
array.invalid.3951:
  call void @mlf_bounds_failure()
  unreachable
array.valid.3950:
  %v3952 = getelementptr i64, ptr %v3741, i64 %v3945
  %v3953 = load double, ptr %v3952, align 8, !tbaa !4
  %v3954 = fmul double %v3852, %v3851
  %v3955 = fmul double %v3954, %v3863
  %v3956 = fsub double %v3878, %v3955
  %v3957 = ptrtoint ptr %a1 to i64
  %v3958 = ptrtoint ptr inttoptr (i64 7 to ptr) to i64
  %v3959 = sub i64 %v3958, 1
  %v3960 = add nsw i64 %v3957, %v3959
  %v3961 = inttoptr i64 %v3960 to ptr
  %v3962 = ptrtoint ptr %v3961 to i64
  %v3963 = ashr i64 %v3962, 1
  %v3964 = and i64 %v3962, 1
  %v3965 = icmp ne i64 %v3964, 0
  %v3966 = icmp ult i64 %v3963, %v3739
  %v3967 = and i1 %v3965, %v3966
  br i1 %v3967, label %array.valid.3968, label %array.invalid.3969
array.invalid.3969:
  call void @mlf_bounds_failure()
  unreachable
array.valid.3968:
  %v3970 = getelementptr i64, ptr %v3741, i64 %v3963
  store double %v3956, ptr %v3970, align 8, !tbaa !4
  %v3971 = fmul double %v3853, %v3851
  %v3972 = fmul double %v3971, %v3863
  %v3973 = fsub double %v3893, %v3972
  %v3974 = ptrtoint ptr %a1 to i64
  %v3975 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v3976 = sub i64 %v3975, 1
  %v3977 = add nsw i64 %v3974, %v3976
  %v3978 = inttoptr i64 %v3977 to ptr
  %v3979 = ptrtoint ptr %v3978 to i64
  %v3980 = ashr i64 %v3979, 1
  %v3981 = and i64 %v3979, 1
  %v3982 = icmp ne i64 %v3981, 0
  %v3983 = icmp ult i64 %v3980, %v3739
  %v3984 = and i1 %v3982, %v3983
  br i1 %v3984, label %array.valid.3985, label %array.invalid.3986
array.invalid.3986:
  call void @mlf_bounds_failure()
  unreachable
array.valid.3985:
  %v3987 = getelementptr i64, ptr %v3741, i64 %v3980
  store double %v3973, ptr %v3987, align 8, !tbaa !4
  %v3988 = fmul double %v3854, %v3851
  %v3989 = fmul double %v3988, %v3863
  %v3990 = fsub double %v3908, %v3989
  %v3991 = ptrtoint ptr %a1 to i64
  %v3992 = ptrtoint ptr inttoptr (i64 11 to ptr) to i64
  %v3993 = sub i64 %v3992, 1
  %v3994 = add nsw i64 %v3991, %v3993
  %v3995 = inttoptr i64 %v3994 to ptr
  %v3996 = ptrtoint ptr %v3995 to i64
  %v3997 = ashr i64 %v3996, 1
  %v3998 = and i64 %v3996, 1
  %v3999 = icmp ne i64 %v3998, 0
  %v4000 = icmp ult i64 %v3997, %v3739
  %v4001 = and i1 %v3999, %v4000
  br i1 %v4001, label %array.valid.4002, label %array.invalid.4003
array.invalid.4003:
  call void @mlf_bounds_failure()
  unreachable
array.valid.4002:
  %v4004 = getelementptr i64, ptr %v3741, i64 %v3997
  store double %v3990, ptr %v4004, align 8, !tbaa !4
  %v4005 = fmul double %v3852, %v3796
  %v4006 = fmul double %v4005, %v3863
  %v4007 = fadd double %v3923, %v4006
  %v4008 = ptrtoint ptr %a2 to i64
  %v4009 = ptrtoint ptr inttoptr (i64 7 to ptr) to i64
  %v4010 = sub i64 %v4009, 1
  %v4011 = add nsw i64 %v4008, %v4010
  %v4012 = inttoptr i64 %v4011 to ptr
  %v4013 = ptrtoint ptr %v4012 to i64
  %v4014 = ashr i64 %v4013, 1
  %v4015 = and i64 %v4013, 1
  %v4016 = icmp ne i64 %v4015, 0
  %v4017 = icmp ult i64 %v4014, %v3739
  %v4018 = and i1 %v4016, %v4017
  br i1 %v4018, label %array.valid.4019, label %array.invalid.4020
array.invalid.4020:
  call void @mlf_bounds_failure()
  unreachable
array.valid.4019:
  %v4021 = getelementptr i64, ptr %v3741, i64 %v4014
  store double %v4007, ptr %v4021, align 8, !tbaa !4
  %v4022 = fmul double %v3853, %v3796
  %v4023 = fmul double %v4022, %v3863
  %v4024 = fadd double %v3938, %v4023
  %v4025 = ptrtoint ptr %a2 to i64
  %v4026 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v4027 = sub i64 %v4026, 1
  %v4028 = add nsw i64 %v4025, %v4027
  %v4029 = inttoptr i64 %v4028 to ptr
  %v4030 = ptrtoint ptr %v4029 to i64
  %v4031 = ashr i64 %v4030, 1
  %v4032 = and i64 %v4030, 1
  %v4033 = icmp ne i64 %v4032, 0
  %v4034 = icmp ult i64 %v4031, %v3739
  %v4035 = and i1 %v4033, %v4034
  br i1 %v4035, label %array.valid.4036, label %array.invalid.4037
array.invalid.4037:
  call void @mlf_bounds_failure()
  unreachable
array.valid.4036:
  %v4038 = getelementptr i64, ptr %v3741, i64 %v4031
  store double %v4024, ptr %v4038, align 8, !tbaa !4
  %v4039 = fmul double %v3854, %v3796
  %v4040 = fmul double %v4039, %v3863
  %v4041 = fadd double %v3953, %v4040
  %v4042 = ptrtoint ptr %a2 to i64
  %v4043 = ptrtoint ptr inttoptr (i64 11 to ptr) to i64
  %v4044 = sub i64 %v4043, 1
  %v4045 = add nsw i64 %v4042, %v4044
  %v4046 = inttoptr i64 %v4045 to ptr
  %v4047 = ptrtoint ptr %v4046 to i64
  %v4048 = ashr i64 %v4047, 1
  %v4049 = and i64 %v4047, 1
  %v4050 = icmp ne i64 %v4049, 0
  %v4051 = icmp ult i64 %v4048, %v3739
  %v4052 = and i1 %v4050, %v4051
  br i1 %v4052, label %array.valid.4053, label %array.invalid.4054
array.invalid.4054:
  call void @mlf_bounds_failure()
  unreachable
array.valid.4053:
  %v4055 = getelementptr i64, ptr %v3741, i64 %v4048
  store double %v4041, ptr %v4055, align 8, !tbaa !4
  %v4056 = ptrtoint ptr %a2 to i64
  %v4057 = ptrtoint ptr inttoptr (i64 15 to ptr) to i64
  %v4058 = sub i64 %v4057, 1
  %v4059 = add nsw i64 %v4056, %v4058
  %v4060 = inttoptr i64 %v4059 to ptr
  %v4061 = musttail call ptr @mlf.numeric.42(ptr %a0, ptr %a1, ptr %v4060)
  ret ptr %v4061
}

define private ptr @mlf.numeric.77(ptr %a0, ptr %a1) alwaysinline {
entry:
  %v3688 = ptrtoint ptr %a1 to i64
  %v3689 = ptrtoint ptr inttoptr (i64 71 to ptr) to i64
  %v3690 = and i64 %v3688, %v3689
  %v3691 = and i64 %v3690, 1
  %v3692 = icmp ne i64 %v3691, 0
  br i1 %v3692, label %yes.3693, label %no.3694
yes.3693:
  %v3696 = icmp eq i64 %v3688, %v3689
  %v3697 = select i1 %v3696, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.3695
no.3694:
  %v3698 = call ptr @mlf_eq_int(ptr %a1, ptr inttoptr (i64 71 to ptr))
  br label %join.3695
join.3695:
  %v3699 = phi ptr [ %v3697, %yes.3693 ], [ %v3698, %no.3694 ]
  %v3700 = icmp eq ptr %v3699, inttoptr (i64 6 to ptr)
  br i1 %v3700, label %tail.yes.3701, label %tail.no.3702
tail.yes.3701:
  ret ptr inttoptr (i64 4 to ptr)
tail.no.3702:
  %v3703 = ptrtoint ptr %a1 to i64
  %v3704 = ptrtoint ptr inttoptr (i64 15 to ptr) to i64
  %v3705 = and i64 %v3703, %v3704
  %v3706 = and i64 %v3705, 1
  %v3707 = icmp ne i64 %v3706, 0
  br i1 %v3707, label %yes.3708, label %no.3709
yes.3708:
  %v3711 = sub i64 %v3704, 1
  %v3712 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v3703, i64 %v3711)
  %v3713 = extractvalue { i64, i1 } %v3712, 0
  %v3714 = extractvalue { i64, i1 } %v3712, 1
  br i1 %v3714, label %yes.3715, label %no.3716
yes.3715:
  %v3718 = call ptr @mlf_add_int(ptr %a1, ptr inttoptr (i64 15 to ptr))
  br label %join.3717
no.3716:
  %v3719 = inttoptr i64 %v3713 to ptr
  br label %join.3717
join.3717:
  %v3720 = phi ptr [ %v3718, %yes.3715 ], [ %v3719, %no.3716 ]
  br label %join.3710
no.3709:
  %v3721 = call ptr @mlf_add_int(ptr %a1, ptr inttoptr (i64 15 to ptr))
  br label %join.3710
join.3710:
  %v3722 = phi ptr [ %v3720, %join.3717 ], [ %v3721, %no.3709 ]
  %v4062 = call ptr @mlf.numeric.42(ptr %a0, ptr %a1, ptr %v3722)
  %v4063 = ptrtoint ptr %a1 to i64
  %v4064 = ptrtoint ptr inttoptr (i64 15 to ptr) to i64
  %v4065 = and i64 %v4063, %v4064
  %v4066 = and i64 %v4065, 1
  %v4067 = icmp ne i64 %v4066, 0
  br i1 %v4067, label %yes.4068, label %no.4069
yes.4068:
  %v4071 = sub i64 %v4064, 1
  %v4072 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v4063, i64 %v4071)
  %v4073 = extractvalue { i64, i1 } %v4072, 0
  %v4074 = extractvalue { i64, i1 } %v4072, 1
  br i1 %v4074, label %yes.4075, label %no.4076
yes.4075:
  %v4078 = call ptr @mlf_add_int(ptr %a1, ptr inttoptr (i64 15 to ptr))
  br label %join.4077
no.4076:
  %v4079 = inttoptr i64 %v4073 to ptr
  br label %join.4077
join.4077:
  %v4080 = phi ptr [ %v4078, %yes.4075 ], [ %v4079, %no.4076 ]
  br label %join.4070
no.4069:
  %v4081 = call ptr @mlf_add_int(ptr %a1, ptr inttoptr (i64 15 to ptr))
  br label %join.4070
join.4070:
  %v4082 = phi ptr [ %v4080, %join.4077 ], [ %v4081, %no.4069 ]
  %v4083 = musttail call ptr @mlf.numeric.77(ptr %a0, ptr %v4082)
  ret ptr %v4083
}

define private ptr @mlf.numeric.81(ptr %a0, ptr %a1) alwaysinline {
entry:
  %v4085 = ptrtoint ptr %a1 to i64
  %v4086 = ptrtoint ptr inttoptr (i64 71 to ptr) to i64
  %v4087 = and i64 %v4085, %v4086
  %v4088 = and i64 %v4087, 1
  %v4089 = icmp ne i64 %v4088, 0
  br i1 %v4089, label %yes.4090, label %no.4091
yes.4090:
  %v4093 = icmp eq i64 %v4085, %v4086
  %v4094 = select i1 %v4093, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.4092
no.4091:
  %v4095 = call ptr @mlf_eq_int(ptr %a1, ptr inttoptr (i64 71 to ptr))
  br label %join.4092
join.4092:
  %v4096 = phi ptr [ %v4094, %yes.4090 ], [ %v4095, %no.4091 ]
  %v4097 = icmp eq ptr %v4096, inttoptr (i64 6 to ptr)
  br i1 %v4097, label %tail.yes.4098, label %tail.no.4099
tail.yes.4098:
  ret ptr inttoptr (i64 4 to ptr)
tail.no.4099:
  %v4100 = getelementptr i8, ptr %a0, i64 8
  %v4101 = load i64, ptr %v4100, align 8, !tbaa !3
  %v4102 = getelementptr i8, ptr %a0, i64 16
  %v4103 = load ptr, ptr %v4102, align 8, !tbaa !3
  %v4104 = ptrtoint ptr %a1 to i64
  %v4105 = ashr i64 %v4104, 1
  %v4106 = and i64 %v4104, 1
  %v4107 = icmp ne i64 %v4106, 0
  %v4108 = icmp ult i64 %v4105, %v4101
  %v4109 = and i1 %v4107, %v4108
  br i1 %v4109, label %array.valid.4110, label %array.invalid.4111
array.invalid.4111:
  call void @mlf_bounds_failure()
  unreachable
array.valid.4110:
  %v4112 = getelementptr i64, ptr %v4103, i64 %v4105
  %v4113 = load double, ptr %v4112, align 8, !tbaa !4
  %v4114 = ptrtoint ptr %a1 to i64
  %v4115 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v4116 = sub i64 %v4115, 1
  %v4117 = add nsw i64 %v4114, %v4116
  %v4118 = inttoptr i64 %v4117 to ptr
  %v4119 = ptrtoint ptr %v4118 to i64
  %v4120 = ashr i64 %v4119, 1
  %v4121 = and i64 %v4119, 1
  %v4122 = icmp ne i64 %v4121, 0
  %v4123 = icmp ult i64 %v4120, %v4101
  %v4124 = and i1 %v4122, %v4123
  br i1 %v4124, label %array.valid.4125, label %array.invalid.4126
array.invalid.4126:
  call void @mlf_bounds_failure()
  unreachable
array.valid.4125:
  %v4127 = getelementptr i64, ptr %v4103, i64 %v4120
  %v4128 = load double, ptr %v4127, align 8, !tbaa !4
  %v4129 = ptrtoint ptr %a1 to i64
  %v4130 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v4131 = sub i64 %v4130, 1
  %v4132 = add nsw i64 %v4129, %v4131
  %v4133 = inttoptr i64 %v4132 to ptr
  %v4134 = ptrtoint ptr %v4133 to i64
  %v4135 = ashr i64 %v4134, 1
  %v4136 = and i64 %v4134, 1
  %v4137 = icmp ne i64 %v4136, 0
  %v4138 = icmp ult i64 %v4135, %v4101
  %v4139 = and i1 %v4137, %v4138
  br i1 %v4139, label %array.valid.4140, label %array.invalid.4141
array.invalid.4141:
  call void @mlf_bounds_failure()
  unreachable
array.valid.4140:
  %v4142 = getelementptr i64, ptr %v4103, i64 %v4135
  %v4143 = load double, ptr %v4142, align 8, !tbaa !4
  %v4144 = ptrtoint ptr %a1 to i64
  %v4145 = ptrtoint ptr inttoptr (i64 7 to ptr) to i64
  %v4146 = sub i64 %v4145, 1
  %v4147 = add nsw i64 %v4144, %v4146
  %v4148 = inttoptr i64 %v4147 to ptr
  %v4149 = ptrtoint ptr %v4148 to i64
  %v4150 = ashr i64 %v4149, 1
  %v4151 = and i64 %v4149, 1
  %v4152 = icmp ne i64 %v4151, 0
  %v4153 = icmp ult i64 %v4150, %v4101
  %v4154 = and i1 %v4152, %v4153
  br i1 %v4154, label %array.valid.4155, label %array.invalid.4156
array.invalid.4156:
  call void @mlf_bounds_failure()
  unreachable
array.valid.4155:
  %v4157 = getelementptr i64, ptr %v4103, i64 %v4150
  %v4158 = load double, ptr %v4157, align 8, !tbaa !4
  %v4159 = ptrtoint ptr %a1 to i64
  %v4160 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v4161 = sub i64 %v4160, 1
  %v4162 = add nsw i64 %v4159, %v4161
  %v4163 = inttoptr i64 %v4162 to ptr
  %v4164 = ptrtoint ptr %v4163 to i64
  %v4165 = ashr i64 %v4164, 1
  %v4166 = and i64 %v4164, 1
  %v4167 = icmp ne i64 %v4166, 0
  %v4168 = icmp ult i64 %v4165, %v4101
  %v4169 = and i1 %v4167, %v4168
  br i1 %v4169, label %array.valid.4170, label %array.invalid.4171
array.invalid.4171:
  call void @mlf_bounds_failure()
  unreachable
array.valid.4170:
  %v4172 = getelementptr i64, ptr %v4103, i64 %v4165
  %v4173 = load double, ptr %v4172, align 8, !tbaa !4
  %v4174 = ptrtoint ptr %a1 to i64
  %v4175 = ptrtoint ptr inttoptr (i64 11 to ptr) to i64
  %v4176 = sub i64 %v4175, 1
  %v4177 = add nsw i64 %v4174, %v4176
  %v4178 = inttoptr i64 %v4177 to ptr
  %v4179 = ptrtoint ptr %v4178 to i64
  %v4180 = ashr i64 %v4179, 1
  %v4181 = and i64 %v4179, 1
  %v4182 = icmp ne i64 %v4181, 0
  %v4183 = icmp ult i64 %v4180, %v4101
  %v4184 = and i1 %v4182, %v4183
  br i1 %v4184, label %array.valid.4185, label %array.invalid.4186
array.invalid.4186:
  call void @mlf_bounds_failure()
  unreachable
array.valid.4185:
  %v4187 = getelementptr i64, ptr %v4103, i64 %v4180
  %v4188 = load double, ptr %v4187, align 8, !tbaa !4
  %v4189 = fmul double 0x3f847ae147ae147b, %v4158
  %v4190 = fadd double %v4113, %v4189
  %v4191 = ptrtoint ptr %a1 to i64
  %v4192 = ashr i64 %v4191, 1
  %v4193 = and i64 %v4191, 1
  %v4194 = icmp ne i64 %v4193, 0
  %v4195 = icmp ult i64 %v4192, %v4101
  %v4196 = and i1 %v4194, %v4195
  br i1 %v4196, label %array.valid.4197, label %array.invalid.4198
array.invalid.4198:
  call void @mlf_bounds_failure()
  unreachable
array.valid.4197:
  %v4199 = getelementptr i64, ptr %v4103, i64 %v4192
  store double %v4190, ptr %v4199, align 8, !tbaa !4
  %v4200 = fmul double 0x3f847ae147ae147b, %v4173
  %v4201 = fadd double %v4128, %v4200
  %v4202 = ptrtoint ptr %a1 to i64
  %v4203 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v4204 = sub i64 %v4203, 1
  %v4205 = add nsw i64 %v4202, %v4204
  %v4206 = inttoptr i64 %v4205 to ptr
  %v4207 = ptrtoint ptr %v4206 to i64
  %v4208 = ashr i64 %v4207, 1
  %v4209 = and i64 %v4207, 1
  %v4210 = icmp ne i64 %v4209, 0
  %v4211 = icmp ult i64 %v4208, %v4101
  %v4212 = and i1 %v4210, %v4211
  br i1 %v4212, label %array.valid.4213, label %array.invalid.4214
array.invalid.4214:
  call void @mlf_bounds_failure()
  unreachable
array.valid.4213:
  %v4215 = getelementptr i64, ptr %v4103, i64 %v4208
  store double %v4201, ptr %v4215, align 8, !tbaa !4
  %v4216 = fmul double 0x3f847ae147ae147b, %v4188
  %v4217 = fadd double %v4143, %v4216
  %v4218 = ptrtoint ptr %a1 to i64
  %v4219 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v4220 = sub i64 %v4219, 1
  %v4221 = add nsw i64 %v4218, %v4220
  %v4222 = inttoptr i64 %v4221 to ptr
  %v4223 = ptrtoint ptr %v4222 to i64
  %v4224 = ashr i64 %v4223, 1
  %v4225 = and i64 %v4223, 1
  %v4226 = icmp ne i64 %v4225, 0
  %v4227 = icmp ult i64 %v4224, %v4101
  %v4228 = and i1 %v4226, %v4227
  br i1 %v4228, label %array.valid.4229, label %array.invalid.4230
array.invalid.4230:
  call void @mlf_bounds_failure()
  unreachable
array.valid.4229:
  %v4231 = getelementptr i64, ptr %v4103, i64 %v4224
  store double %v4217, ptr %v4231, align 8, !tbaa !4
  %v4232 = ptrtoint ptr %a1 to i64
  %v4233 = ptrtoint ptr inttoptr (i64 15 to ptr) to i64
  %v4234 = sub i64 %v4233, 1
  %v4235 = add nsw i64 %v4232, %v4234
  %v4236 = inttoptr i64 %v4235 to ptr
  %v4237 = musttail call ptr @mlf.numeric.81(ptr %a0, ptr %v4236)
  ret ptr %v4237
}

define private ptr @mlf.numeric.96(ptr %a0, ptr %a1) alwaysinline {
entry:
  %v3673 = ptrtoint ptr %a1 to i64
  %v3674 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v3675 = and i64 %v3673, %v3674
  %v3676 = and i64 %v3675, 1
  %v3677 = icmp ne i64 %v3676, 0
  br i1 %v3677, label %yes.3678, label %no.3679
yes.3678:
  %v3681 = icmp eq i64 %v3673, %v3674
  %v3682 = select i1 %v3681, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.3680
no.3679:
  %v3683 = call ptr @mlf_eq_int(ptr %a1, ptr inttoptr (i64 1 to ptr))
  br label %join.3680
join.3680:
  %v3684 = phi ptr [ %v3682, %yes.3678 ], [ %v3683, %no.3679 ]
  %v3685 = icmp eq ptr %v3684, inttoptr (i64 6 to ptr)
  br i1 %v3685, label %tail.yes.3686, label %tail.no.3687
tail.yes.3686:
  ret ptr inttoptr (i64 4 to ptr)
tail.no.3687:
  %v4084 = call ptr @mlf.numeric.77(ptr %a0, ptr inttoptr (i64 1 to ptr))
  %v4238 = call ptr @mlf.numeric.81(ptr %a0, ptr inttoptr (i64 1 to ptr))
  %v4239 = ptrtoint ptr %a1 to i64
  %v4240 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v4241 = and i64 %v4239, %v4240
  %v4242 = and i64 %v4241, 1
  %v4243 = icmp ne i64 %v4242, 0
  br i1 %v4243, label %yes.4244, label %no.4245
yes.4244:
  %v4247 = sub i64 %v4240, 1
  %v4248 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v4239, i64 %v4247)
  %v4249 = extractvalue { i64, i1 } %v4248, 0
  %v4250 = extractvalue { i64, i1 } %v4248, 1
  br i1 %v4250, label %yes.4251, label %no.4252
yes.4251:
  %v4254 = call ptr @mlf_sub_int(ptr %a1, ptr inttoptr (i64 3 to ptr))
  br label %join.4253
no.4252:
  %v4255 = inttoptr i64 %v4249 to ptr
  br label %join.4253
join.4253:
  %v4256 = phi ptr [ %v4254, %yes.4251 ], [ %v4255, %no.4252 ]
  br label %join.4246
no.4245:
  %v4257 = call ptr @mlf_sub_int(ptr %a1, ptr inttoptr (i64 3 to ptr))
  br label %join.4246
join.4246:
  %v4258 = phi ptr [ %v4256, %join.4253 ], [ %v4257, %no.4245 ]
  %v4259 = musttail call ptr @mlf.numeric.96(ptr %a0, ptr %v4258)
  ret ptr %v4259
}

define private ptr @mlf.code.4335(ptr %env, ptr %arg) {
entry:
  %v4336 = getelementptr i8, ptr %env, i64 8
  %v4337 = load ptr, ptr %v4336, align 8, !tbaa !3
  %v4338 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4338, align 8, !tbaa !3
  %v4339 = call ptr @mlf.force(ptr %v4337)
  %v4340 = call ptr @mlf_prim2(i64 8, ptr %v4339, ptr inttoptr (i64 1 to ptr))
  ret ptr %v4340
}

define private ptr @mlf.code.4328(ptr %env, ptr %arg) {
entry:
  %v4329 = getelementptr i8, ptr %env, i64 8
  %v4330 = load ptr, ptr %v4329, align 8, !tbaa !3
  %v4331 = getelementptr i8, ptr %env, i64 16
  %v4332 = load ptr, ptr %v4331, align 8, !tbaa !3
  %v4333 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4333, align 8, !tbaa !3
  %v4334 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v4334, align 8, !tbaa !3
  %v4341 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4335, i64 1)
  %v4342 = getelementptr i8, ptr %v4341, i64 16
  %v4343 = load ptr, ptr %v4342, align 8, !tbaa !3
  %v4344 = getelementptr i8, ptr %v4343, i64 8
  store ptr %v4332, ptr %v4344, align 8, !tbaa !3
  %v4345 = call ptr @mlf_prim2(i64 32, ptr %v4330, ptr %v4341)
  ret ptr %v4345
}

define private ptr @mlf.code.4365(ptr %env, ptr %arg) {
entry:
  %v4366 = getelementptr i8, ptr %env, i64 8
  %v4367 = load ptr, ptr %v4366, align 8, !tbaa !3
  %v4368 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4368, align 8, !tbaa !3
  %v4369 = call ptr @mlf.force(ptr %v4367)
  %v4370 = call ptr @mlf_prim2(i64 8, ptr %v4369, ptr inttoptr (i64 3 to ptr))
  ret ptr %v4370
}

define private ptr @mlf.code.4358(ptr %env, ptr %arg) {
entry:
  %v4359 = getelementptr i8, ptr %env, i64 8
  %v4360 = load ptr, ptr %v4359, align 8, !tbaa !3
  %v4361 = getelementptr i8, ptr %env, i64 16
  %v4362 = load ptr, ptr %v4361, align 8, !tbaa !3
  %v4363 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4363, align 8, !tbaa !3
  %v4364 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v4364, align 8, !tbaa !3
  %v4371 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4365, i64 1)
  %v4372 = getelementptr i8, ptr %v4371, i64 16
  %v4373 = load ptr, ptr %v4372, align 8, !tbaa !3
  %v4374 = getelementptr i8, ptr %v4373, i64 8
  store ptr %v4362, ptr %v4374, align 8, !tbaa !3
  %v4375 = call ptr @mlf_prim2(i64 32, ptr %v4360, ptr %v4371)
  ret ptr %v4375
}

define private ptr @mlf.code.4397(ptr %env, ptr %arg) {
entry:
  %v4398 = getelementptr i8, ptr %env, i64 8
  %v4399 = load ptr, ptr %v4398, align 8, !tbaa !3
  %v4400 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4400, align 8, !tbaa !3
  %v4401 = call ptr @mlf.force(ptr %v4399)
  %v4402 = call ptr @mlf_prim2(i64 8, ptr %v4401, ptr inttoptr (i64 5 to ptr))
  ret ptr %v4402
}

define private ptr @mlf.code.4390(ptr %env, ptr %arg) {
entry:
  %v4391 = getelementptr i8, ptr %env, i64 8
  %v4392 = load ptr, ptr %v4391, align 8, !tbaa !3
  %v4393 = getelementptr i8, ptr %env, i64 16
  %v4394 = load ptr, ptr %v4393, align 8, !tbaa !3
  %v4395 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4395, align 8, !tbaa !3
  %v4396 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v4396, align 8, !tbaa !3
  %v4403 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4397, i64 1)
  %v4404 = getelementptr i8, ptr %v4403, i64 16
  %v4405 = load ptr, ptr %v4404, align 8, !tbaa !3
  %v4406 = getelementptr i8, ptr %v4405, i64 8
  store ptr %v4394, ptr %v4406, align 8, !tbaa !3
  %v4407 = call ptr @mlf_prim2(i64 32, ptr %v4392, ptr %v4403)
  ret ptr %v4407
}

define private ptr @mlf.code.4431(ptr %env, ptr %arg) {
entry:
  %v4432 = getelementptr i8, ptr %env, i64 8
  %v4433 = load ptr, ptr %v4432, align 8, !tbaa !3
  %v4434 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4434, align 8, !tbaa !3
  %v4435 = call ptr @mlf.force(ptr %v4433)
  %v4436 = call ptr @mlf_prim2(i64 8, ptr %v4435, ptr inttoptr (i64 13 to ptr))
  ret ptr %v4436
}

define private ptr @mlf.code.4424(ptr %env, ptr %arg) {
entry:
  %v4425 = getelementptr i8, ptr %env, i64 8
  %v4426 = load ptr, ptr %v4425, align 8, !tbaa !3
  %v4427 = getelementptr i8, ptr %env, i64 16
  %v4428 = load ptr, ptr %v4427, align 8, !tbaa !3
  %v4429 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4429, align 8, !tbaa !3
  %v4430 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v4430, align 8, !tbaa !3
  %v4437 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4431, i64 1)
  %v4438 = getelementptr i8, ptr %v4437, i64 16
  %v4439 = load ptr, ptr %v4438, align 8, !tbaa !3
  %v4440 = getelementptr i8, ptr %v4439, i64 8
  store ptr %v4428, ptr %v4440, align 8, !tbaa !3
  %v4441 = call ptr @mlf_prim2(i64 32, ptr %v4426, ptr %v4437)
  ret ptr %v4441
}

define private ptr @mlf.code.4467(ptr %env, ptr %arg) {
entry:
  %v4468 = getelementptr i8, ptr %env, i64 8
  %v4469 = load ptr, ptr %v4468, align 8, !tbaa !3
  %v4470 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4470, align 8, !tbaa !3
  %v4471 = call ptr @mlf.force(ptr %v4469)
  %v4472 = call ptr @mlf_prim2(i64 8, ptr %v4471, ptr inttoptr (i64 1 to ptr))
  ret ptr %v4472
}

define private ptr @mlf.code.4460(ptr %env, ptr %arg) {
entry:
  %v4461 = getelementptr i8, ptr %env, i64 8
  %v4462 = load ptr, ptr %v4461, align 8, !tbaa !3
  %v4463 = getelementptr i8, ptr %env, i64 16
  %v4464 = load ptr, ptr %v4463, align 8, !tbaa !3
  %v4465 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4465, align 8, !tbaa !3
  %v4466 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v4466, align 8, !tbaa !3
  %v4473 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4467, i64 1)
  %v4474 = getelementptr i8, ptr %v4473, i64 16
  %v4475 = load ptr, ptr %v4474, align 8, !tbaa !3
  %v4476 = getelementptr i8, ptr %v4475, i64 8
  store ptr %v4464, ptr %v4476, align 8, !tbaa !3
  %v4477 = call ptr @mlf_prim2(i64 32, ptr %v4462, ptr %v4473)
  ret ptr %v4477
}

define private ptr @mlf.code.4505(ptr %env, ptr %arg) {
entry:
  %v4506 = getelementptr i8, ptr %env, i64 8
  %v4507 = load ptr, ptr %v4506, align 8, !tbaa !3
  %v4508 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4508, align 8, !tbaa !3
  %v4509 = call ptr @mlf.force(ptr %v4507)
  %v4510 = call ptr @mlf_prim2(i64 8, ptr %v4509, ptr inttoptr (i64 3 to ptr))
  ret ptr %v4510
}

define private ptr @mlf.code.4498(ptr %env, ptr %arg) {
entry:
  %v4499 = getelementptr i8, ptr %env, i64 8
  %v4500 = load ptr, ptr %v4499, align 8, !tbaa !3
  %v4501 = getelementptr i8, ptr %env, i64 16
  %v4502 = load ptr, ptr %v4501, align 8, !tbaa !3
  %v4503 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4503, align 8, !tbaa !3
  %v4504 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v4504, align 8, !tbaa !3
  %v4511 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4505, i64 1)
  %v4512 = getelementptr i8, ptr %v4511, i64 16
  %v4513 = load ptr, ptr %v4512, align 8, !tbaa !3
  %v4514 = getelementptr i8, ptr %v4513, i64 8
  store ptr %v4502, ptr %v4514, align 8, !tbaa !3
  %v4515 = call ptr @mlf_prim2(i64 32, ptr %v4500, ptr %v4511)
  ret ptr %v4515
}

define private ptr @mlf.code.4545(ptr %env, ptr %arg) {
entry:
  %v4546 = getelementptr i8, ptr %env, i64 8
  %v4547 = load ptr, ptr %v4546, align 8, !tbaa !3
  %v4548 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4548, align 8, !tbaa !3
  %v4549 = call ptr @mlf.force(ptr %v4547)
  %v4550 = call ptr @mlf_prim2(i64 8, ptr %v4549, ptr inttoptr (i64 5 to ptr))
  ret ptr %v4550
}

define private ptr @mlf.code.4538(ptr %env, ptr %arg) {
entry:
  %v4539 = getelementptr i8, ptr %env, i64 8
  %v4540 = load ptr, ptr %v4539, align 8, !tbaa !3
  %v4541 = getelementptr i8, ptr %env, i64 16
  %v4542 = load ptr, ptr %v4541, align 8, !tbaa !3
  %v4543 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4543, align 8, !tbaa !3
  %v4544 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v4544, align 8, !tbaa !3
  %v4551 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4545, i64 1)
  %v4552 = getelementptr i8, ptr %v4551, i64 16
  %v4553 = load ptr, ptr %v4552, align 8, !tbaa !3
  %v4554 = getelementptr i8, ptr %v4553, i64 8
  store ptr %v4542, ptr %v4554, align 8, !tbaa !3
  %v4555 = call ptr @mlf_prim2(i64 32, ptr %v4540, ptr %v4551)
  ret ptr %v4555
}

define private ptr @mlf.code.4587(ptr %env, ptr %arg) {
entry:
  %v4588 = getelementptr i8, ptr %env, i64 8
  %v4589 = load ptr, ptr %v4588, align 8, !tbaa !3
  %v4590 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4590, align 8, !tbaa !3
  %v4591 = call ptr @mlf.force(ptr %v4589)
  %v4592 = call ptr @mlf_prim2(i64 8, ptr %v4591, ptr inttoptr (i64 13 to ptr))
  ret ptr %v4592
}

define private ptr @mlf.code.4580(ptr %env, ptr %arg) {
entry:
  %v4581 = getelementptr i8, ptr %env, i64 8
  %v4582 = load ptr, ptr %v4581, align 8, !tbaa !3
  %v4583 = getelementptr i8, ptr %env, i64 16
  %v4584 = load ptr, ptr %v4583, align 8, !tbaa !3
  %v4585 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4585, align 8, !tbaa !3
  %v4586 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v4586, align 8, !tbaa !3
  %v4593 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4587, i64 1)
  %v4594 = getelementptr i8, ptr %v4593, i64 16
  %v4595 = load ptr, ptr %v4594, align 8, !tbaa !3
  %v4596 = getelementptr i8, ptr %v4595, i64 8
  store ptr %v4584, ptr %v4596, align 8, !tbaa !3
  %v4597 = call ptr @mlf_prim2(i64 32, ptr %v4582, ptr %v4593)
  ret ptr %v4597
}

define private ptr @mlf.code.4624(ptr %env, ptr %arg) {
entry:
  %v4625 = getelementptr i8, ptr %env, i64 8
  %v4626 = load ptr, ptr %v4625, align 8, !tbaa !3
  %v4627 = getelementptr i8, ptr %env, i64 16
  %v4628 = load ptr, ptr %v4627, align 8, !tbaa !3
  %v4629 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4629, align 8, !tbaa !3
  %v4630 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v4630, align 8, !tbaa !3
  %v4631 = call ptr @mlf.force(ptr %v4626)
  %v4632 = call ptr @mlf.force(ptr %v4628)
  %v4633 = call ptr @mlf_prim2(i64 19, ptr %v4631, ptr %v4632)
  ret ptr %v4633
}

define private ptr @mlf.code.4639(ptr %env, ptr %arg) {
entry:
  %v4640 = getelementptr i8, ptr %env, i64 8
  %v4641 = load ptr, ptr %v4640, align 8, !tbaa !3
  %v4642 = getelementptr i8, ptr %env, i64 16
  %v4643 = load ptr, ptr %v4642, align 8, !tbaa !3
  %v4644 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4644, align 8, !tbaa !3
  %v4645 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v4645, align 8, !tbaa !3
  %v4646 = call ptr @mlf.force(ptr %v4641)
  %v4647 = call ptr @mlf.force(ptr %v4643)
  %v4648 = call ptr @mlf_prim2(i64 19, ptr %v4646, ptr %v4647)
  ret ptr %v4648
}

define private ptr @mlf.code.4654(ptr %env, ptr %arg) {
entry:
  %v4655 = getelementptr i8, ptr %env, i64 8
  %v4656 = load ptr, ptr %v4655, align 8, !tbaa !3
  %v4657 = getelementptr i8, ptr %env, i64 16
  %v4658 = load ptr, ptr %v4657, align 8, !tbaa !3
  %v4659 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4659, align 8, !tbaa !3
  %v4660 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v4660, align 8, !tbaa !3
  %v4661 = call ptr @mlf.force(ptr %v4656)
  %v4662 = call ptr @mlf.force(ptr %v4658)
  %v4663 = call ptr @mlf_prim2(i64 19, ptr %v4661, ptr %v4662)
  ret ptr %v4663
}

define private ptr @mlf.code.4669(ptr %env, ptr %arg) {
entry:
  %v4670 = getelementptr i8, ptr %env, i64 8
  %v4671 = load ptr, ptr %v4670, align 8, !tbaa !3
  %v4672 = getelementptr i8, ptr %env, i64 16
  %v4673 = load ptr, ptr %v4672, align 8, !tbaa !3
  %v4674 = getelementptr i8, ptr %env, i64 24
  %v4675 = load ptr, ptr %v4674, align 8, !tbaa !3
  %v4676 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4676, align 8, !tbaa !3
  %v4677 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v4677, align 8, !tbaa !3
  %v4678 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v4678, align 8, !tbaa !3
  %v4679 = call ptr @mlf.force(ptr %v4671)
  %v4680 = call ptr @mlf_prim2(i64 20, ptr %v4679, ptr %v4679)
  %v4681 = call ptr @mlf.force(ptr %v4673)
  %v4682 = call ptr @mlf_prim2(i64 20, ptr %v4681, ptr %v4681)
  %v4683 = call ptr @mlf_prim2(i64 18, ptr %v4680, ptr %v4682)
  %v4684 = call ptr @mlf.force(ptr %v4675)
  %v4685 = call ptr @mlf_prim2(i64 20, ptr %v4684, ptr %v4684)
  %v4686 = call ptr @mlf_prim2(i64 18, ptr %v4683, ptr %v4685)
  %v4687 = call ptr @mlf_prim1(i64 22, ptr %v4686)
  ret ptr %v4687
}

define private ptr @mlf.code.4694(ptr %env, ptr %arg) {
entry:
  %v4695 = getelementptr i8, ptr %env, i64 8
  %v4696 = load ptr, ptr %v4695, align 8, !tbaa !3
  %v4697 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4697, align 8, !tbaa !3
  %v4698 = call ptr @mlf_double(double 0x3f847ae147ae147b)
  %v4699 = call ptr @mlf.force(ptr %v4696)
  %v4700 = call ptr @mlf_prim2(i64 20, ptr %v4699, ptr %v4699)
  %v4701 = call ptr @mlf_prim2(i64 20, ptr %v4700, ptr %v4699)
  %v4702 = call ptr @mlf_prim2(i64 21, ptr %v4698, ptr %v4701)
  ret ptr %v4702
}

define private ptr @mlf.code.4714(ptr %env, ptr %arg) {
entry:
  %v4715 = getelementptr i8, ptr %env, i64 8
  %v4716 = load ptr, ptr %v4715, align 8, !tbaa !3
  %v4717 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4717, align 8, !tbaa !3
  %v4718 = call ptr @mlf.force(ptr %v4716)
  %v4719 = call ptr @mlf_prim2(i64 8, ptr %v4718, ptr inttoptr (i64 7 to ptr))
  ret ptr %v4719
}

define private ptr @mlf.code.4707(ptr %env, ptr %arg) {
entry:
  %v4708 = getelementptr i8, ptr %env, i64 8
  %v4709 = load ptr, ptr %v4708, align 8, !tbaa !3
  %v4710 = getelementptr i8, ptr %env, i64 16
  %v4711 = load ptr, ptr %v4710, align 8, !tbaa !3
  %v4712 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4712, align 8, !tbaa !3
  %v4713 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v4713, align 8, !tbaa !3
  %v4720 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4714, i64 1)
  %v4721 = getelementptr i8, ptr %v4720, i64 16
  %v4722 = load ptr, ptr %v4721, align 8, !tbaa !3
  %v4723 = getelementptr i8, ptr %v4722, i64 8
  store ptr %v4711, ptr %v4723, align 8, !tbaa !3
  %v4724 = call ptr @mlf_prim2(i64 32, ptr %v4709, ptr %v4720)
  ret ptr %v4724
}

define private ptr @mlf.code.4756(ptr %env, ptr %arg) {
entry:
  %v4757 = getelementptr i8, ptr %env, i64 8
  %v4758 = load ptr, ptr %v4757, align 8, !tbaa !3
  %v4759 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4759, align 8, !tbaa !3
  %v4760 = call ptr @mlf.force(ptr %v4758)
  %v4761 = call ptr @mlf_prim2(i64 8, ptr %v4760, ptr inttoptr (i64 9 to ptr))
  ret ptr %v4761
}

define private ptr @mlf.code.4749(ptr %env, ptr %arg) {
entry:
  %v4750 = getelementptr i8, ptr %env, i64 8
  %v4751 = load ptr, ptr %v4750, align 8, !tbaa !3
  %v4752 = getelementptr i8, ptr %env, i64 16
  %v4753 = load ptr, ptr %v4752, align 8, !tbaa !3
  %v4754 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4754, align 8, !tbaa !3
  %v4755 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v4755, align 8, !tbaa !3
  %v4762 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4756, i64 1)
  %v4763 = getelementptr i8, ptr %v4762, i64 16
  %v4764 = load ptr, ptr %v4763, align 8, !tbaa !3
  %v4765 = getelementptr i8, ptr %v4764, i64 8
  store ptr %v4753, ptr %v4765, align 8, !tbaa !3
  %v4766 = call ptr @mlf_prim2(i64 32, ptr %v4751, ptr %v4762)
  ret ptr %v4766
}

define private ptr @mlf.code.4800(ptr %env, ptr %arg) {
entry:
  %v4801 = getelementptr i8, ptr %env, i64 8
  %v4802 = load ptr, ptr %v4801, align 8, !tbaa !3
  %v4803 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4803, align 8, !tbaa !3
  %v4804 = call ptr @mlf.force(ptr %v4802)
  %v4805 = call ptr @mlf_prim2(i64 8, ptr %v4804, ptr inttoptr (i64 11 to ptr))
  ret ptr %v4805
}

define private ptr @mlf.code.4793(ptr %env, ptr %arg) {
entry:
  %v4794 = getelementptr i8, ptr %env, i64 8
  %v4795 = load ptr, ptr %v4794, align 8, !tbaa !3
  %v4796 = getelementptr i8, ptr %env, i64 16
  %v4797 = load ptr, ptr %v4796, align 8, !tbaa !3
  %v4798 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4798, align 8, !tbaa !3
  %v4799 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v4799, align 8, !tbaa !3
  %v4806 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4800, i64 1)
  %v4807 = getelementptr i8, ptr %v4806, i64 16
  %v4808 = load ptr, ptr %v4807, align 8, !tbaa !3
  %v4809 = getelementptr i8, ptr %v4808, i64 8
  store ptr %v4797, ptr %v4809, align 8, !tbaa !3
  %v4810 = call ptr @mlf_prim2(i64 32, ptr %v4795, ptr %v4806)
  ret ptr %v4810
}

define private ptr @mlf.code.4846(ptr %env, ptr %arg) {
entry:
  %v4847 = getelementptr i8, ptr %env, i64 8
  %v4848 = load ptr, ptr %v4847, align 8, !tbaa !3
  %v4849 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4849, align 8, !tbaa !3
  %v4850 = call ptr @mlf.force(ptr %v4848)
  %v4851 = call ptr @mlf_prim2(i64 8, ptr %v4850, ptr inttoptr (i64 7 to ptr))
  ret ptr %v4851
}

define private ptr @mlf.code.4839(ptr %env, ptr %arg) {
entry:
  %v4840 = getelementptr i8, ptr %env, i64 8
  %v4841 = load ptr, ptr %v4840, align 8, !tbaa !3
  %v4842 = getelementptr i8, ptr %env, i64 16
  %v4843 = load ptr, ptr %v4842, align 8, !tbaa !3
  %v4844 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4844, align 8, !tbaa !3
  %v4845 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v4845, align 8, !tbaa !3
  %v4852 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4846, i64 1)
  %v4853 = getelementptr i8, ptr %v4852, i64 16
  %v4854 = load ptr, ptr %v4853, align 8, !tbaa !3
  %v4855 = getelementptr i8, ptr %v4854, i64 8
  store ptr %v4843, ptr %v4855, align 8, !tbaa !3
  %v4856 = call ptr @mlf_prim2(i64 32, ptr %v4841, ptr %v4852)
  ret ptr %v4856
}

define private ptr @mlf.code.4894(ptr %env, ptr %arg) {
entry:
  %v4895 = getelementptr i8, ptr %env, i64 8
  %v4896 = load ptr, ptr %v4895, align 8, !tbaa !3
  %v4897 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4897, align 8, !tbaa !3
  %v4898 = call ptr @mlf.force(ptr %v4896)
  %v4899 = call ptr @mlf_prim2(i64 8, ptr %v4898, ptr inttoptr (i64 9 to ptr))
  ret ptr %v4899
}

define private ptr @mlf.code.4887(ptr %env, ptr %arg) {
entry:
  %v4888 = getelementptr i8, ptr %env, i64 8
  %v4889 = load ptr, ptr %v4888, align 8, !tbaa !3
  %v4890 = getelementptr i8, ptr %env, i64 16
  %v4891 = load ptr, ptr %v4890, align 8, !tbaa !3
  %v4892 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4892, align 8, !tbaa !3
  %v4893 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v4893, align 8, !tbaa !3
  %v4900 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4894, i64 1)
  %v4901 = getelementptr i8, ptr %v4900, i64 16
  %v4902 = load ptr, ptr %v4901, align 8, !tbaa !3
  %v4903 = getelementptr i8, ptr %v4902, i64 8
  store ptr %v4891, ptr %v4903, align 8, !tbaa !3
  %v4904 = call ptr @mlf_prim2(i64 32, ptr %v4889, ptr %v4900)
  ret ptr %v4904
}

define private ptr @mlf.code.4944(ptr %env, ptr %arg) {
entry:
  %v4945 = getelementptr i8, ptr %env, i64 8
  %v4946 = load ptr, ptr %v4945, align 8, !tbaa !3
  %v4947 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4947, align 8, !tbaa !3
  %v4948 = call ptr @mlf.force(ptr %v4946)
  %v4949 = call ptr @mlf_prim2(i64 8, ptr %v4948, ptr inttoptr (i64 11 to ptr))
  ret ptr %v4949
}

define private ptr @mlf.code.4937(ptr %env, ptr %arg) {
entry:
  %v4938 = getelementptr i8, ptr %env, i64 8
  %v4939 = load ptr, ptr %v4938, align 8, !tbaa !3
  %v4940 = getelementptr i8, ptr %env, i64 16
  %v4941 = load ptr, ptr %v4940, align 8, !tbaa !3
  %v4942 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4942, align 8, !tbaa !3
  %v4943 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v4943, align 8, !tbaa !3
  %v4950 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4944, i64 1)
  %v4951 = getelementptr i8, ptr %v4950, i64 16
  %v4952 = load ptr, ptr %v4951, align 8, !tbaa !3
  %v4953 = getelementptr i8, ptr %v4952, i64 8
  store ptr %v4941, ptr %v4953, align 8, !tbaa !3
  %v4954 = call ptr @mlf_prim2(i64 32, ptr %v4939, ptr %v4950)
  ret ptr %v4954
}

define private ptr @mlf.code.5008(ptr %env, ptr %arg) {
entry:
  %v5009 = getelementptr i8, ptr %env, i64 8
  %v5010 = load ptr, ptr %v5009, align 8, !tbaa !3
  %v5011 = getelementptr i8, ptr %env, i64 16
  %v5012 = load ptr, ptr %v5011, align 8, !tbaa !3
  %v5013 = getelementptr i8, ptr %env, i64 24
  %v5014 = load ptr, ptr %v5013, align 8, !tbaa !3
  %v5015 = getelementptr i8, ptr %env, i64 32
  %v5016 = load ptr, ptr %v5015, align 8, !tbaa !3
  %v5017 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v5017, align 8, !tbaa !3
  %v5018 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v5018, align 8, !tbaa !3
  %v5019 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v5019, align 8, !tbaa !3
  %v5020 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v5020, align 8, !tbaa !3
  %v5021 = call ptr @mlf.force(ptr %v5016)
  %v5022 = call ptr @mlf.force(ptr %v5012)
  %v5023 = call ptr @mlf.force(ptr %v5010)
  %v5024 = call ptr @mlf_prim2(i64 20, ptr %v5022, ptr %v5023)
  %v5025 = call ptr @mlf.force(ptr %v5014)
  %v5026 = call ptr @mlf_prim2(i64 20, ptr %v5024, ptr %v5025)
  %v5027 = call ptr @mlf_prim2(i64 19, ptr %v5021, ptr %v5026)
  ret ptr %v5027
}

define private ptr @mlf.code.5035(ptr %env, ptr %arg) {
entry:
  %v5036 = getelementptr i8, ptr %env, i64 8
  %v5037 = load ptr, ptr %v5036, align 8, !tbaa !3
  %v5038 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v5038, align 8, !tbaa !3
  %v5039 = call ptr @mlf.force(ptr %v5037)
  %v5040 = call ptr @mlf_prim2(i64 8, ptr %v5039, ptr inttoptr (i64 7 to ptr))
  ret ptr %v5040
}

define private ptr @mlf.code.4989(ptr %env, ptr %arg) {
entry:
  %v4990 = getelementptr i8, ptr %env, i64 8
  %v4991 = load ptr, ptr %v4990, align 8, !tbaa !3
  %v4992 = getelementptr i8, ptr %env, i64 16
  %v4993 = load ptr, ptr %v4992, align 8, !tbaa !3
  %v4994 = getelementptr i8, ptr %env, i64 24
  %v4995 = load ptr, ptr %v4994, align 8, !tbaa !3
  %v4996 = getelementptr i8, ptr %env, i64 32
  %v4997 = load ptr, ptr %v4996, align 8, !tbaa !3
  %v4998 = getelementptr i8, ptr %env, i64 40
  %v4999 = load ptr, ptr %v4998, align 8, !tbaa !3
  %v5000 = getelementptr i8, ptr %env, i64 48
  %v5001 = load ptr, ptr %v5000, align 8, !tbaa !3
  %v5002 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v5002, align 8, !tbaa !3
  %v5003 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v5003, align 8, !tbaa !3
  %v5004 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v5004, align 8, !tbaa !3
  %v5005 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v5005, align 8, !tbaa !3
  %v5006 = getelementptr i8, ptr %env, i64 40
  store ptr null, ptr %v5006, align 8, !tbaa !3
  %v5007 = getelementptr i8, ptr %env, i64 48
  store ptr null, ptr %v5007, align 8, !tbaa !3
  %v5028 = call ptr @mlf.allocate.thunk(ptr @mlf.code.5008, i64 4)
  %v5029 = getelementptr i8, ptr %v5028, i64 16
  %v5030 = load ptr, ptr %v5029, align 8, !tbaa !3
  %v5031 = getelementptr i8, ptr %v5030, i64 8
  store ptr %v4995, ptr %v5031, align 8, !tbaa !3
  %v5032 = getelementptr i8, ptr %v5030, i64 16
  store ptr %v4997, ptr %v5032, align 8, !tbaa !3
  %v5033 = getelementptr i8, ptr %v5030, i64 24
  store ptr %v4999, ptr %v5033, align 8, !tbaa !3
  %v5034 = getelementptr i8, ptr %v5030, i64 32
  store ptr %v5001, ptr %v5034, align 8, !tbaa !3
  %v5041 = call ptr @mlf.allocate.thunk(ptr @mlf.code.5035, i64 1)
  %v5042 = getelementptr i8, ptr %v5041, i64 16
  %v5043 = load ptr, ptr %v5042, align 8, !tbaa !3
  %v5044 = getelementptr i8, ptr %v5043, i64 8
  store ptr %v4993, ptr %v5044, align 8, !tbaa !3
  %v5045 = call ptr @mlf_prim3(i64 33, ptr %v4991, ptr %v5041, ptr %v5028)
  ret ptr %v5045
}

define private ptr @mlf.code.5103(ptr %env, ptr %arg) {
entry:
  %v5104 = getelementptr i8, ptr %env, i64 8
  %v5105 = load ptr, ptr %v5104, align 8, !tbaa !3
  %v5106 = getelementptr i8, ptr %env, i64 16
  %v5107 = load ptr, ptr %v5106, align 8, !tbaa !3
  %v5108 = getelementptr i8, ptr %env, i64 24
  %v5109 = load ptr, ptr %v5108, align 8, !tbaa !3
  %v5110 = getelementptr i8, ptr %env, i64 32
  %v5111 = load ptr, ptr %v5110, align 8, !tbaa !3
  %v5112 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v5112, align 8, !tbaa !3
  %v5113 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v5113, align 8, !tbaa !3
  %v5114 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v5114, align 8, !tbaa !3
  %v5115 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v5115, align 8, !tbaa !3
  %v5116 = call ptr @mlf.force(ptr %v5111)
  %v5117 = call ptr @mlf.force(ptr %v5107)
  %v5118 = call ptr @mlf.force(ptr %v5105)
  %v5119 = call ptr @mlf_prim2(i64 20, ptr %v5117, ptr %v5118)
  %v5120 = call ptr @mlf.force(ptr %v5109)
  %v5121 = call ptr @mlf_prim2(i64 20, ptr %v5119, ptr %v5120)
  %v5122 = call ptr @mlf_prim2(i64 19, ptr %v5116, ptr %v5121)
  ret ptr %v5122
}

define private ptr @mlf.code.5130(ptr %env, ptr %arg) {
entry:
  %v5131 = getelementptr i8, ptr %env, i64 8
  %v5132 = load ptr, ptr %v5131, align 8, !tbaa !3
  %v5133 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v5133, align 8, !tbaa !3
  %v5134 = call ptr @mlf.force(ptr %v5132)
  %v5135 = call ptr @mlf_prim2(i64 8, ptr %v5134, ptr inttoptr (i64 9 to ptr))
  ret ptr %v5135
}

define private ptr @mlf.code.5084(ptr %env, ptr %arg) {
entry:
  %v5085 = getelementptr i8, ptr %env, i64 8
  %v5086 = load ptr, ptr %v5085, align 8, !tbaa !3
  %v5087 = getelementptr i8, ptr %env, i64 16
  %v5088 = load ptr, ptr %v5087, align 8, !tbaa !3
  %v5089 = getelementptr i8, ptr %env, i64 24
  %v5090 = load ptr, ptr %v5089, align 8, !tbaa !3
  %v5091 = getelementptr i8, ptr %env, i64 32
  %v5092 = load ptr, ptr %v5091, align 8, !tbaa !3
  %v5093 = getelementptr i8, ptr %env, i64 40
  %v5094 = load ptr, ptr %v5093, align 8, !tbaa !3
  %v5095 = getelementptr i8, ptr %env, i64 48
  %v5096 = load ptr, ptr %v5095, align 8, !tbaa !3
  %v5097 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v5097, align 8, !tbaa !3
  %v5098 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v5098, align 8, !tbaa !3
  %v5099 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v5099, align 8, !tbaa !3
  %v5100 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v5100, align 8, !tbaa !3
  %v5101 = getelementptr i8, ptr %env, i64 40
  store ptr null, ptr %v5101, align 8, !tbaa !3
  %v5102 = getelementptr i8, ptr %env, i64 48
  store ptr null, ptr %v5102, align 8, !tbaa !3
  %v5123 = call ptr @mlf.allocate.thunk(ptr @mlf.code.5103, i64 4)
  %v5124 = getelementptr i8, ptr %v5123, i64 16
  %v5125 = load ptr, ptr %v5124, align 8, !tbaa !3
  %v5126 = getelementptr i8, ptr %v5125, i64 8
  store ptr %v5090, ptr %v5126, align 8, !tbaa !3
  %v5127 = getelementptr i8, ptr %v5125, i64 16
  store ptr %v5092, ptr %v5127, align 8, !tbaa !3
  %v5128 = getelementptr i8, ptr %v5125, i64 24
  store ptr %v5094, ptr %v5128, align 8, !tbaa !3
  %v5129 = getelementptr i8, ptr %v5125, i64 32
  store ptr %v5096, ptr %v5129, align 8, !tbaa !3
  %v5136 = call ptr @mlf.allocate.thunk(ptr @mlf.code.5130, i64 1)
  %v5137 = getelementptr i8, ptr %v5136, i64 16
  %v5138 = load ptr, ptr %v5137, align 8, !tbaa !3
  %v5139 = getelementptr i8, ptr %v5138, i64 8
  store ptr %v5088, ptr %v5139, align 8, !tbaa !3
  %v5140 = call ptr @mlf_prim3(i64 33, ptr %v5086, ptr %v5136, ptr %v5123)
  ret ptr %v5140
}

define private ptr @mlf.code.5196(ptr %env, ptr %arg) {
entry:
  %v5197 = getelementptr i8, ptr %env, i64 8
  %v5198 = load ptr, ptr %v5197, align 8, !tbaa !3
  %v5199 = getelementptr i8, ptr %env, i64 16
  %v5200 = load ptr, ptr %v5199, align 8, !tbaa !3
  %v5201 = getelementptr i8, ptr %env, i64 24
  %v5202 = load ptr, ptr %v5201, align 8, !tbaa !3
  %v5203 = getelementptr i8, ptr %env, i64 32
  %v5204 = load ptr, ptr %v5203, align 8, !tbaa !3
  %v5205 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v5205, align 8, !tbaa !3
  %v5206 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v5206, align 8, !tbaa !3
  %v5207 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v5207, align 8, !tbaa !3
  %v5208 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v5208, align 8, !tbaa !3
  %v5209 = call ptr @mlf.force(ptr %v5204)
  %v5210 = call ptr @mlf.force(ptr %v5200)
  %v5211 = call ptr @mlf.force(ptr %v5198)
  %v5212 = call ptr @mlf_prim2(i64 20, ptr %v5210, ptr %v5211)
  %v5213 = call ptr @mlf.force(ptr %v5202)
  %v5214 = call ptr @mlf_prim2(i64 20, ptr %v5212, ptr %v5213)
  %v5215 = call ptr @mlf_prim2(i64 19, ptr %v5209, ptr %v5214)
  ret ptr %v5215
}

define private ptr @mlf.code.5223(ptr %env, ptr %arg) {
entry:
  %v5224 = getelementptr i8, ptr %env, i64 8
  %v5225 = load ptr, ptr %v5224, align 8, !tbaa !3
  %v5226 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v5226, align 8, !tbaa !3
  %v5227 = call ptr @mlf.force(ptr %v5225)
  %v5228 = call ptr @mlf_prim2(i64 8, ptr %v5227, ptr inttoptr (i64 11 to ptr))
  ret ptr %v5228
}

define private ptr @mlf.code.5177(ptr %env, ptr %arg) {
entry:
  %v5178 = getelementptr i8, ptr %env, i64 8
  %v5179 = load ptr, ptr %v5178, align 8, !tbaa !3
  %v5180 = getelementptr i8, ptr %env, i64 16
  %v5181 = load ptr, ptr %v5180, align 8, !tbaa !3
  %v5182 = getelementptr i8, ptr %env, i64 24
  %v5183 = load ptr, ptr %v5182, align 8, !tbaa !3
  %v5184 = getelementptr i8, ptr %env, i64 32
  %v5185 = load ptr, ptr %v5184, align 8, !tbaa !3
  %v5186 = getelementptr i8, ptr %env, i64 40
  %v5187 = load ptr, ptr %v5186, align 8, !tbaa !3
  %v5188 = getelementptr i8, ptr %env, i64 48
  %v5189 = load ptr, ptr %v5188, align 8, !tbaa !3
  %v5190 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v5190, align 8, !tbaa !3
  %v5191 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v5191, align 8, !tbaa !3
  %v5192 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v5192, align 8, !tbaa !3
  %v5193 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v5193, align 8, !tbaa !3
  %v5194 = getelementptr i8, ptr %env, i64 40
  store ptr null, ptr %v5194, align 8, !tbaa !3
  %v5195 = getelementptr i8, ptr %env, i64 48
  store ptr null, ptr %v5195, align 8, !tbaa !3
  %v5216 = call ptr @mlf.allocate.thunk(ptr @mlf.code.5196, i64 4)
  %v5217 = getelementptr i8, ptr %v5216, i64 16
  %v5218 = load ptr, ptr %v5217, align 8, !tbaa !3
  %v5219 = getelementptr i8, ptr %v5218, i64 8
  store ptr %v5183, ptr %v5219, align 8, !tbaa !3
  %v5220 = getelementptr i8, ptr %v5218, i64 16
  store ptr %v5185, ptr %v5220, align 8, !tbaa !3
  %v5221 = getelementptr i8, ptr %v5218, i64 24
  store ptr %v5187, ptr %v5221, align 8, !tbaa !3
  %v5222 = getelementptr i8, ptr %v5218, i64 32
  store ptr %v5189, ptr %v5222, align 8, !tbaa !3
  %v5229 = call ptr @mlf.allocate.thunk(ptr @mlf.code.5223, i64 1)
  %v5230 = getelementptr i8, ptr %v5229, i64 16
  %v5231 = load ptr, ptr %v5230, align 8, !tbaa !3
  %v5232 = getelementptr i8, ptr %v5231, i64 8
  store ptr %v5181, ptr %v5232, align 8, !tbaa !3
  %v5233 = call ptr @mlf_prim3(i64 33, ptr %v5179, ptr %v5229, ptr %v5216)
  ret ptr %v5233
}

define private ptr @mlf.code.5285(ptr %env, ptr %arg) {
entry:
  %v5286 = getelementptr i8, ptr %env, i64 8
  %v5287 = load ptr, ptr %v5286, align 8, !tbaa !3
  %v5288 = getelementptr i8, ptr %env, i64 16
  %v5289 = load ptr, ptr %v5288, align 8, !tbaa !3
  %v5290 = getelementptr i8, ptr %env, i64 24
  %v5291 = load ptr, ptr %v5290, align 8, !tbaa !3
  %v5292 = getelementptr i8, ptr %env, i64 32
  %v5293 = load ptr, ptr %v5292, align 8, !tbaa !3
  %v5294 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v5294, align 8, !tbaa !3
  %v5295 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v5295, align 8, !tbaa !3
  %v5296 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v5296, align 8, !tbaa !3
  %v5297 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v5297, align 8, !tbaa !3
  %v5298 = call ptr @mlf.force(ptr %v5293)
  %v5299 = call ptr @mlf.force(ptr %v5289)
  %v5300 = call ptr @mlf.force(ptr %v5287)
  %v5301 = call ptr @mlf_prim2(i64 20, ptr %v5299, ptr %v5300)
  %v5302 = call ptr @mlf.force(ptr %v5291)
  %v5303 = call ptr @mlf_prim2(i64 20, ptr %v5301, ptr %v5302)
  %v5304 = call ptr @mlf_prim2(i64 18, ptr %v5298, ptr %v5303)
  ret ptr %v5304
}

define private ptr @mlf.code.5312(ptr %env, ptr %arg) {
entry:
  %v5313 = getelementptr i8, ptr %env, i64 8
  %v5314 = load ptr, ptr %v5313, align 8, !tbaa !3
  %v5315 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v5315, align 8, !tbaa !3
  %v5316 = call ptr @mlf.force(ptr %v5314)
  %v5317 = call ptr @mlf_prim2(i64 8, ptr %v5316, ptr inttoptr (i64 7 to ptr))
  ret ptr %v5317
}

define private ptr @mlf.code.5266(ptr %env, ptr %arg) {
entry:
  %v5267 = getelementptr i8, ptr %env, i64 8
  %v5268 = load ptr, ptr %v5267, align 8, !tbaa !3
  %v5269 = getelementptr i8, ptr %env, i64 16
  %v5270 = load ptr, ptr %v5269, align 8, !tbaa !3
  %v5271 = getelementptr i8, ptr %env, i64 24
  %v5272 = load ptr, ptr %v5271, align 8, !tbaa !3
  %v5273 = getelementptr i8, ptr %env, i64 32
  %v5274 = load ptr, ptr %v5273, align 8, !tbaa !3
  %v5275 = getelementptr i8, ptr %env, i64 40
  %v5276 = load ptr, ptr %v5275, align 8, !tbaa !3
  %v5277 = getelementptr i8, ptr %env, i64 48
  %v5278 = load ptr, ptr %v5277, align 8, !tbaa !3
  %v5279 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v5279, align 8, !tbaa !3
  %v5280 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v5280, align 8, !tbaa !3
  %v5281 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v5281, align 8, !tbaa !3
  %v5282 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v5282, align 8, !tbaa !3
  %v5283 = getelementptr i8, ptr %env, i64 40
  store ptr null, ptr %v5283, align 8, !tbaa !3
  %v5284 = getelementptr i8, ptr %env, i64 48
  store ptr null, ptr %v5284, align 8, !tbaa !3
  %v5305 = call ptr @mlf.allocate.thunk(ptr @mlf.code.5285, i64 4)
  %v5306 = getelementptr i8, ptr %v5305, i64 16
  %v5307 = load ptr, ptr %v5306, align 8, !tbaa !3
  %v5308 = getelementptr i8, ptr %v5307, i64 8
  store ptr %v5272, ptr %v5308, align 8, !tbaa !3
  %v5309 = getelementptr i8, ptr %v5307, i64 16
  store ptr %v5274, ptr %v5309, align 8, !tbaa !3
  %v5310 = getelementptr i8, ptr %v5307, i64 24
  store ptr %v5276, ptr %v5310, align 8, !tbaa !3
  %v5311 = getelementptr i8, ptr %v5307, i64 32
  store ptr %v5278, ptr %v5311, align 8, !tbaa !3
  %v5318 = call ptr @mlf.allocate.thunk(ptr @mlf.code.5312, i64 1)
  %v5319 = getelementptr i8, ptr %v5318, i64 16
  %v5320 = load ptr, ptr %v5319, align 8, !tbaa !3
  %v5321 = getelementptr i8, ptr %v5320, i64 8
  store ptr %v5270, ptr %v5321, align 8, !tbaa !3
  %v5322 = call ptr @mlf_prim3(i64 33, ptr %v5268, ptr %v5318, ptr %v5305)
  ret ptr %v5322
}

define private ptr @mlf.code.5370(ptr %env, ptr %arg) {
entry:
  %v5371 = getelementptr i8, ptr %env, i64 8
  %v5372 = load ptr, ptr %v5371, align 8, !tbaa !3
  %v5373 = getelementptr i8, ptr %env, i64 16
  %v5374 = load ptr, ptr %v5373, align 8, !tbaa !3
  %v5375 = getelementptr i8, ptr %env, i64 24
  %v5376 = load ptr, ptr %v5375, align 8, !tbaa !3
  %v5377 = getelementptr i8, ptr %env, i64 32
  %v5378 = load ptr, ptr %v5377, align 8, !tbaa !3
  %v5379 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v5379, align 8, !tbaa !3
  %v5380 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v5380, align 8, !tbaa !3
  %v5381 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v5381, align 8, !tbaa !3
  %v5382 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v5382, align 8, !tbaa !3
  %v5383 = call ptr @mlf.force(ptr %v5378)
  %v5384 = call ptr @mlf.force(ptr %v5374)
  %v5385 = call ptr @mlf.force(ptr %v5372)
  %v5386 = call ptr @mlf_prim2(i64 20, ptr %v5384, ptr %v5385)
  %v5387 = call ptr @mlf.force(ptr %v5376)
  %v5388 = call ptr @mlf_prim2(i64 20, ptr %v5386, ptr %v5387)
  %v5389 = call ptr @mlf_prim2(i64 18, ptr %v5383, ptr %v5388)
  ret ptr %v5389
}

define private ptr @mlf.code.5397(ptr %env, ptr %arg) {
entry:
  %v5398 = getelementptr i8, ptr %env, i64 8
  %v5399 = load ptr, ptr %v5398, align 8, !tbaa !3
  %v5400 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v5400, align 8, !tbaa !3
  %v5401 = call ptr @mlf.force(ptr %v5399)
  %v5402 = call ptr @mlf_prim2(i64 8, ptr %v5401, ptr inttoptr (i64 9 to ptr))
  ret ptr %v5402
}

define private ptr @mlf.code.5351(ptr %env, ptr %arg) {
entry:
  %v5352 = getelementptr i8, ptr %env, i64 8
  %v5353 = load ptr, ptr %v5352, align 8, !tbaa !3
  %v5354 = getelementptr i8, ptr %env, i64 16
  %v5355 = load ptr, ptr %v5354, align 8, !tbaa !3
  %v5356 = getelementptr i8, ptr %env, i64 24
  %v5357 = load ptr, ptr %v5356, align 8, !tbaa !3
  %v5358 = getelementptr i8, ptr %env, i64 32
  %v5359 = load ptr, ptr %v5358, align 8, !tbaa !3
  %v5360 = getelementptr i8, ptr %env, i64 40
  %v5361 = load ptr, ptr %v5360, align 8, !tbaa !3
  %v5362 = getelementptr i8, ptr %env, i64 48
  %v5363 = load ptr, ptr %v5362, align 8, !tbaa !3
  %v5364 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v5364, align 8, !tbaa !3
  %v5365 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v5365, align 8, !tbaa !3
  %v5366 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v5366, align 8, !tbaa !3
  %v5367 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v5367, align 8, !tbaa !3
  %v5368 = getelementptr i8, ptr %env, i64 40
  store ptr null, ptr %v5368, align 8, !tbaa !3
  %v5369 = getelementptr i8, ptr %env, i64 48
  store ptr null, ptr %v5369, align 8, !tbaa !3
  %v5390 = call ptr @mlf.allocate.thunk(ptr @mlf.code.5370, i64 4)
  %v5391 = getelementptr i8, ptr %v5390, i64 16
  %v5392 = load ptr, ptr %v5391, align 8, !tbaa !3
  %v5393 = getelementptr i8, ptr %v5392, i64 8
  store ptr %v5357, ptr %v5393, align 8, !tbaa !3
  %v5394 = getelementptr i8, ptr %v5392, i64 16
  store ptr %v5359, ptr %v5394, align 8, !tbaa !3
  %v5395 = getelementptr i8, ptr %v5392, i64 24
  store ptr %v5361, ptr %v5395, align 8, !tbaa !3
  %v5396 = getelementptr i8, ptr %v5392, i64 32
  store ptr %v5363, ptr %v5396, align 8, !tbaa !3
  %v5403 = call ptr @mlf.allocate.thunk(ptr @mlf.code.5397, i64 1)
  %v5404 = getelementptr i8, ptr %v5403, i64 16
  %v5405 = load ptr, ptr %v5404, align 8, !tbaa !3
  %v5406 = getelementptr i8, ptr %v5405, i64 8
  store ptr %v5355, ptr %v5406, align 8, !tbaa !3
  %v5407 = call ptr @mlf_prim3(i64 33, ptr %v5353, ptr %v5403, ptr %v5390)
  ret ptr %v5407
}

define private ptr @mlf.code.5451(ptr %env, ptr %arg) {
entry:
  %v5452 = getelementptr i8, ptr %env, i64 8
  %v5453 = load ptr, ptr %v5452, align 8, !tbaa !3
  %v5454 = getelementptr i8, ptr %env, i64 16
  %v5455 = load ptr, ptr %v5454, align 8, !tbaa !3
  %v5456 = getelementptr i8, ptr %env, i64 24
  %v5457 = load ptr, ptr %v5456, align 8, !tbaa !3
  %v5458 = getelementptr i8, ptr %env, i64 32
  %v5459 = load ptr, ptr %v5458, align 8, !tbaa !3
  %v5460 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v5460, align 8, !tbaa !3
  %v5461 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v5461, align 8, !tbaa !3
  %v5462 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v5462, align 8, !tbaa !3
  %v5463 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v5463, align 8, !tbaa !3
  %v5464 = call ptr @mlf.force(ptr %v5459)
  %v5465 = call ptr @mlf.force(ptr %v5455)
  %v5466 = call ptr @mlf.force(ptr %v5453)
  %v5467 = call ptr @mlf_prim2(i64 20, ptr %v5465, ptr %v5466)
  %v5468 = call ptr @mlf.force(ptr %v5457)
  %v5469 = call ptr @mlf_prim2(i64 20, ptr %v5467, ptr %v5468)
  %v5470 = call ptr @mlf_prim2(i64 18, ptr %v5464, ptr %v5469)
  ret ptr %v5470
}

define private ptr @mlf.code.5478(ptr %env, ptr %arg) {
entry:
  %v5479 = getelementptr i8, ptr %env, i64 8
  %v5480 = load ptr, ptr %v5479, align 8, !tbaa !3
  %v5481 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v5481, align 8, !tbaa !3
  %v5482 = call ptr @mlf.force(ptr %v5480)
  %v5483 = call ptr @mlf_prim2(i64 8, ptr %v5482, ptr inttoptr (i64 11 to ptr))
  ret ptr %v5483
}

define private ptr @mlf.code.5432(ptr %env, ptr %arg) {
entry:
  %v5433 = getelementptr i8, ptr %env, i64 8
  %v5434 = load ptr, ptr %v5433, align 8, !tbaa !3
  %v5435 = getelementptr i8, ptr %env, i64 16
  %v5436 = load ptr, ptr %v5435, align 8, !tbaa !3
  %v5437 = getelementptr i8, ptr %env, i64 24
  %v5438 = load ptr, ptr %v5437, align 8, !tbaa !3
  %v5439 = getelementptr i8, ptr %env, i64 32
  %v5440 = load ptr, ptr %v5439, align 8, !tbaa !3
  %v5441 = getelementptr i8, ptr %env, i64 40
  %v5442 = load ptr, ptr %v5441, align 8, !tbaa !3
  %v5443 = getelementptr i8, ptr %env, i64 48
  %v5444 = load ptr, ptr %v5443, align 8, !tbaa !3
  %v5445 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v5445, align 8, !tbaa !3
  %v5446 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v5446, align 8, !tbaa !3
  %v5447 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v5447, align 8, !tbaa !3
  %v5448 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v5448, align 8, !tbaa !3
  %v5449 = getelementptr i8, ptr %env, i64 40
  store ptr null, ptr %v5449, align 8, !tbaa !3
  %v5450 = getelementptr i8, ptr %env, i64 48
  store ptr null, ptr %v5450, align 8, !tbaa !3
  %v5471 = call ptr @mlf.allocate.thunk(ptr @mlf.code.5451, i64 4)
  %v5472 = getelementptr i8, ptr %v5471, i64 16
  %v5473 = load ptr, ptr %v5472, align 8, !tbaa !3
  %v5474 = getelementptr i8, ptr %v5473, i64 8
  store ptr %v5438, ptr %v5474, align 8, !tbaa !3
  %v5475 = getelementptr i8, ptr %v5473, i64 16
  store ptr %v5440, ptr %v5475, align 8, !tbaa !3
  %v5476 = getelementptr i8, ptr %v5473, i64 24
  store ptr %v5442, ptr %v5476, align 8, !tbaa !3
  %v5477 = getelementptr i8, ptr %v5473, i64 32
  store ptr %v5444, ptr %v5477, align 8, !tbaa !3
  %v5484 = call ptr @mlf.allocate.thunk(ptr @mlf.code.5478, i64 1)
  %v5485 = getelementptr i8, ptr %v5484, i64 16
  %v5486 = load ptr, ptr %v5485, align 8, !tbaa !3
  %v5487 = getelementptr i8, ptr %v5486, i64 8
  store ptr %v5436, ptr %v5487, align 8, !tbaa !3
  %v5488 = call ptr @mlf_prim3(i64 33, ptr %v5434, ptr %v5484, ptr %v5471)
  ret ptr %v5488
}

define private ptr @mlf.code.5498(ptr %env, ptr %arg) {
entry:
  %v5499 = getelementptr i8, ptr %env, i64 8
  %v5500 = load ptr, ptr %v5499, align 8, !tbaa !3
  %v5501 = getelementptr i8, ptr %env, i64 16
  %v5502 = load ptr, ptr %v5501, align 8, !tbaa !3
  %v5503 = getelementptr i8, ptr %env, i64 24
  %v5504 = load ptr, ptr %v5503, align 8, !tbaa !3
  %v5505 = call ptr @mlf.force(ptr %v5504)
  %v5506 = call ptr @mlf_prim2(i64 8, ptr %v5505, ptr inttoptr (i64 15 to ptr))
  %v5507 = call ptr @mlf_env_new(i64 3)
  %v5508 = getelementptr i8, ptr %v5507, i64 8
  store ptr %v5500, ptr %v5508, align 8, !tbaa !3
  %v5509 = getelementptr i8, ptr %v5507, i64 16
  store ptr %v5502, ptr %v5509, align 8, !tbaa !3
  %v5510 = getelementptr i8, ptr %v5507, i64 24
  store ptr %v5506, ptr %v5510, align 8, !tbaa !3
  %v5511 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.4301, ptr %v5507)
  ret ptr %v5511
}

define private ptr @mlf.code.5417(ptr %env, ptr %arg) {
entry:
  %v5418 = getelementptr i8, ptr %env, i64 8
  %v5419 = load ptr, ptr %v5418, align 8, !tbaa !3
  %v5420 = getelementptr i8, ptr %env, i64 16
  %v5421 = load ptr, ptr %v5420, align 8, !tbaa !3
  %v5422 = getelementptr i8, ptr %env, i64 24
  %v5423 = load ptr, ptr %v5422, align 8, !tbaa !3
  %v5424 = getelementptr i8, ptr %env, i64 32
  %v5425 = load ptr, ptr %v5424, align 8, !tbaa !3
  %v5426 = getelementptr i8, ptr %env, i64 40
  %v5427 = load ptr, ptr %v5426, align 8, !tbaa !3
  %v5428 = getelementptr i8, ptr %env, i64 48
  %v5429 = load ptr, ptr %v5428, align 8, !tbaa !3
  %v5430 = getelementptr i8, ptr %env, i64 56
  %v5431 = load ptr, ptr %v5430, align 8, !tbaa !3
  %v5489 = call ptr @mlf.allocate.thunk(ptr @mlf.code.5432, i64 6)
  %v5490 = getelementptr i8, ptr %v5489, i64 16
  %v5491 = load ptr, ptr %v5490, align 8, !tbaa !3
  %v5492 = getelementptr i8, ptr %v5491, i64 8
  store ptr %v5419, ptr %v5492, align 8, !tbaa !3
  %v5493 = getelementptr i8, ptr %v5491, i64 16
  store ptr %v5423, ptr %v5493, align 8, !tbaa !3
  %v5494 = getelementptr i8, ptr %v5491, i64 24
  store ptr %v5425, ptr %v5494, align 8, !tbaa !3
  %v5495 = getelementptr i8, ptr %v5491, i64 32
  store ptr %v5427, ptr %v5495, align 8, !tbaa !3
  %v5496 = getelementptr i8, ptr %v5491, i64 40
  store ptr %v5429, ptr %v5496, align 8, !tbaa !3
  %v5497 = getelementptr i8, ptr %v5491, i64 48
  store ptr %v5431, ptr %v5497, align 8, !tbaa !3
  %v5512 = call ptr @mlf_env_new(i64 3)
  %v5513 = getelementptr i8, ptr %v5512, i64 8
  store ptr %v5419, ptr %v5513, align 8, !tbaa !3
  %v5514 = getelementptr i8, ptr %v5512, i64 16
  store ptr %v5421, ptr %v5514, align 8, !tbaa !3
  %v5515 = getelementptr i8, ptr %v5512, i64 24
  store ptr %v5423, ptr %v5515, align 8, !tbaa !3
  %v5516 = call ptr @mlf_closure(ptr @mlf.code.5498, ptr %v5512)
  %v5517 = call ptr @mlf_prim2(i64 1, ptr %v5489, ptr %v5516)
  ret ptr %v5517
}

define private ptr @mlf.code.5332(ptr %env, ptr %arg) {
entry:
  %v5333 = getelementptr i8, ptr %env, i64 8
  %v5334 = load ptr, ptr %v5333, align 8, !tbaa !3
  %v5335 = getelementptr i8, ptr %env, i64 16
  %v5336 = load ptr, ptr %v5335, align 8, !tbaa !3
  %v5337 = getelementptr i8, ptr %env, i64 24
  %v5338 = load ptr, ptr %v5337, align 8, !tbaa !3
  %v5339 = getelementptr i8, ptr %env, i64 32
  %v5340 = load ptr, ptr %v5339, align 8, !tbaa !3
  %v5341 = getelementptr i8, ptr %env, i64 40
  %v5342 = load ptr, ptr %v5341, align 8, !tbaa !3
  %v5343 = getelementptr i8, ptr %env, i64 48
  %v5344 = load ptr, ptr %v5343, align 8, !tbaa !3
  %v5345 = getelementptr i8, ptr %env, i64 56
  %v5346 = load ptr, ptr %v5345, align 8, !tbaa !3
  %v5347 = getelementptr i8, ptr %env, i64 64
  %v5348 = load ptr, ptr %v5347, align 8, !tbaa !3
  %v5349 = getelementptr i8, ptr %env, i64 72
  %v5350 = load ptr, ptr %v5349, align 8, !tbaa !3
  %v5408 = call ptr @mlf.allocate.thunk(ptr @mlf.code.5351, i64 6)
  %v5409 = getelementptr i8, ptr %v5408, i64 16
  %v5410 = load ptr, ptr %v5409, align 8, !tbaa !3
  %v5411 = getelementptr i8, ptr %v5410, i64 8
  store ptr %v5334, ptr %v5411, align 8, !tbaa !3
  %v5412 = getelementptr i8, ptr %v5410, i64 16
  store ptr %v5338, ptr %v5412, align 8, !tbaa !3
  %v5413 = getelementptr i8, ptr %v5410, i64 24
  store ptr %v5340, ptr %v5413, align 8, !tbaa !3
  %v5414 = getelementptr i8, ptr %v5410, i64 32
  store ptr %v5342, ptr %v5414, align 8, !tbaa !3
  %v5415 = getelementptr i8, ptr %v5410, i64 40
  store ptr %v5346, ptr %v5415, align 8, !tbaa !3
  %v5416 = getelementptr i8, ptr %v5410, i64 48
  store ptr %v5348, ptr %v5416, align 8, !tbaa !3
  %v5518 = call ptr @mlf_env_new(i64 7)
  %v5519 = getelementptr i8, ptr %v5518, i64 8
  store ptr %v5334, ptr %v5519, align 8, !tbaa !3
  %v5520 = getelementptr i8, ptr %v5518, i64 16
  store ptr %v5336, ptr %v5520, align 8, !tbaa !3
  %v5521 = getelementptr i8, ptr %v5518, i64 24
  store ptr %v5338, ptr %v5521, align 8, !tbaa !3
  %v5522 = getelementptr i8, ptr %v5518, i64 32
  store ptr %v5340, ptr %v5522, align 8, !tbaa !3
  %v5523 = getelementptr i8, ptr %v5518, i64 40
  store ptr %v5344, ptr %v5523, align 8, !tbaa !3
  %v5524 = getelementptr i8, ptr %v5518, i64 48
  store ptr %v5346, ptr %v5524, align 8, !tbaa !3
  %v5525 = getelementptr i8, ptr %v5518, i64 56
  store ptr %v5350, ptr %v5525, align 8, !tbaa !3
  %v5526 = call ptr @mlf_closure(ptr @mlf.code.5417, ptr %v5518)
  %v5527 = call ptr @mlf_prim2(i64 1, ptr %v5408, ptr %v5526)
  ret ptr %v5527
}

define private ptr @mlf.code.5243(ptr %env, ptr %arg) {
entry:
  %v5244 = getelementptr i8, ptr %env, i64 8
  %v5245 = load ptr, ptr %v5244, align 8, !tbaa !3
  %v5246 = getelementptr i8, ptr %env, i64 16
  %v5247 = load ptr, ptr %v5246, align 8, !tbaa !3
  %v5248 = getelementptr i8, ptr %env, i64 24
  %v5249 = load ptr, ptr %v5248, align 8, !tbaa !3
  %v5250 = getelementptr i8, ptr %env, i64 32
  %v5251 = load ptr, ptr %v5250, align 8, !tbaa !3
  %v5252 = getelementptr i8, ptr %env, i64 40
  %v5253 = load ptr, ptr %v5252, align 8, !tbaa !3
  %v5254 = getelementptr i8, ptr %env, i64 48
  %v5255 = load ptr, ptr %v5254, align 8, !tbaa !3
  %v5256 = getelementptr i8, ptr %env, i64 56
  %v5257 = load ptr, ptr %v5256, align 8, !tbaa !3
  %v5258 = getelementptr i8, ptr %env, i64 64
  %v5259 = load ptr, ptr %v5258, align 8, !tbaa !3
  %v5260 = getelementptr i8, ptr %env, i64 72
  %v5261 = load ptr, ptr %v5260, align 8, !tbaa !3
  %v5262 = getelementptr i8, ptr %env, i64 80
  %v5263 = load ptr, ptr %v5262, align 8, !tbaa !3
  %v5264 = getelementptr i8, ptr %env, i64 88
  %v5265 = load ptr, ptr %v5264, align 8, !tbaa !3
  %v5323 = call ptr @mlf.allocate.thunk(ptr @mlf.code.5266, i64 6)
  %v5324 = getelementptr i8, ptr %v5323, i64 16
  %v5325 = load ptr, ptr %v5324, align 8, !tbaa !3
  %v5326 = getelementptr i8, ptr %v5325, i64 8
  store ptr %v5245, ptr %v5326, align 8, !tbaa !3
  %v5327 = getelementptr i8, ptr %v5325, i64 16
  store ptr %v5249, ptr %v5327, align 8, !tbaa !3
  %v5328 = getelementptr i8, ptr %v5325, i64 24
  store ptr %v5251, ptr %v5328, align 8, !tbaa !3
  %v5329 = getelementptr i8, ptr %v5325, i64 32
  store ptr %v5253, ptr %v5329, align 8, !tbaa !3
  %v5330 = getelementptr i8, ptr %v5325, i64 40
  store ptr %v5259, ptr %v5330, align 8, !tbaa !3
  %v5331 = getelementptr i8, ptr %v5325, i64 48
  store ptr %v5261, ptr %v5331, align 8, !tbaa !3
  %v5528 = call ptr @mlf_env_new(i64 9)
  %v5529 = getelementptr i8, ptr %v5528, i64 8
  store ptr %v5245, ptr %v5529, align 8, !tbaa !3
  %v5530 = getelementptr i8, ptr %v5528, i64 16
  store ptr %v5247, ptr %v5530, align 8, !tbaa !3
  %v5531 = getelementptr i8, ptr %v5528, i64 24
  store ptr %v5249, ptr %v5531, align 8, !tbaa !3
  %v5532 = getelementptr i8, ptr %v5528, i64 32
  store ptr %v5251, ptr %v5532, align 8, !tbaa !3
  %v5533 = getelementptr i8, ptr %v5528, i64 40
  store ptr %v5255, ptr %v5533, align 8, !tbaa !3
  %v5534 = getelementptr i8, ptr %v5528, i64 48
  store ptr %v5257, ptr %v5534, align 8, !tbaa !3
  %v5535 = getelementptr i8, ptr %v5528, i64 56
  store ptr %v5259, ptr %v5535, align 8, !tbaa !3
  %v5536 = getelementptr i8, ptr %v5528, i64 64
  store ptr %v5263, ptr %v5536, align 8, !tbaa !3
  %v5537 = getelementptr i8, ptr %v5528, i64 72
  store ptr %v5265, ptr %v5537, align 8, !tbaa !3
  %v5538 = call ptr @mlf_closure(ptr @mlf.code.5332, ptr %v5528)
  %v5539 = call ptr @mlf_prim2(i64 1, ptr %v5323, ptr %v5538)
  ret ptr %v5539
}

define private ptr @mlf.code.5150(ptr %env, ptr %arg) {
entry:
  %v5151 = getelementptr i8, ptr %env, i64 8
  %v5152 = load ptr, ptr %v5151, align 8, !tbaa !3
  %v5153 = getelementptr i8, ptr %env, i64 16
  %v5154 = load ptr, ptr %v5153, align 8, !tbaa !3
  %v5155 = getelementptr i8, ptr %env, i64 24
  %v5156 = load ptr, ptr %v5155, align 8, !tbaa !3
  %v5157 = getelementptr i8, ptr %env, i64 32
  %v5158 = load ptr, ptr %v5157, align 8, !tbaa !3
  %v5159 = getelementptr i8, ptr %env, i64 40
  %v5160 = load ptr, ptr %v5159, align 8, !tbaa !3
  %v5161 = getelementptr i8, ptr %env, i64 48
  %v5162 = load ptr, ptr %v5161, align 8, !tbaa !3
  %v5163 = getelementptr i8, ptr %env, i64 56
  %v5164 = load ptr, ptr %v5163, align 8, !tbaa !3
  %v5165 = getelementptr i8, ptr %env, i64 64
  %v5166 = load ptr, ptr %v5165, align 8, !tbaa !3
  %v5167 = getelementptr i8, ptr %env, i64 72
  %v5168 = load ptr, ptr %v5167, align 8, !tbaa !3
  %v5169 = getelementptr i8, ptr %env, i64 80
  %v5170 = load ptr, ptr %v5169, align 8, !tbaa !3
  %v5171 = getelementptr i8, ptr %env, i64 88
  %v5172 = load ptr, ptr %v5171, align 8, !tbaa !3
  %v5173 = getelementptr i8, ptr %env, i64 96
  %v5174 = load ptr, ptr %v5173, align 8, !tbaa !3
  %v5175 = getelementptr i8, ptr %env, i64 104
  %v5176 = load ptr, ptr %v5175, align 8, !tbaa !3
  %v5234 = call ptr @mlf.allocate.thunk(ptr @mlf.code.5177, i64 6)
  %v5235 = getelementptr i8, ptr %v5234, i64 16
  %v5236 = load ptr, ptr %v5235, align 8, !tbaa !3
  %v5237 = getelementptr i8, ptr %v5236, i64 8
  store ptr %v5152, ptr %v5237, align 8, !tbaa !3
  %v5238 = getelementptr i8, ptr %v5236, i64 16
  store ptr %v5154, ptr %v5238, align 8, !tbaa !3
  %v5239 = getelementptr i8, ptr %v5236, i64 24
  store ptr %v5160, ptr %v5239, align 8, !tbaa !3
  %v5240 = getelementptr i8, ptr %v5236, i64 32
  store ptr %v5166, ptr %v5240, align 8, !tbaa !3
  %v5241 = getelementptr i8, ptr %v5236, i64 40
  store ptr %v5168, ptr %v5241, align 8, !tbaa !3
  %v5242 = getelementptr i8, ptr %v5236, i64 48
  store ptr %v5170, ptr %v5242, align 8, !tbaa !3
  %v5540 = call ptr @mlf_env_new(i64 11)
  %v5541 = getelementptr i8, ptr %v5540, i64 8
  store ptr %v5152, ptr %v5541, align 8, !tbaa !3
  %v5542 = getelementptr i8, ptr %v5540, i64 16
  store ptr %v5154, ptr %v5542, align 8, !tbaa !3
  %v5543 = getelementptr i8, ptr %v5540, i64 24
  store ptr %v5156, ptr %v5543, align 8, !tbaa !3
  %v5544 = getelementptr i8, ptr %v5540, i64 32
  store ptr %v5158, ptr %v5544, align 8, !tbaa !3
  %v5545 = getelementptr i8, ptr %v5540, i64 40
  store ptr %v5162, ptr %v5545, align 8, !tbaa !3
  %v5546 = getelementptr i8, ptr %v5540, i64 48
  store ptr %v5164, ptr %v5546, align 8, !tbaa !3
  %v5547 = getelementptr i8, ptr %v5540, i64 56
  store ptr %v5166, ptr %v5547, align 8, !tbaa !3
  %v5548 = getelementptr i8, ptr %v5540, i64 64
  store ptr %v5168, ptr %v5548, align 8, !tbaa !3
  %v5549 = getelementptr i8, ptr %v5540, i64 72
  store ptr %v5172, ptr %v5549, align 8, !tbaa !3
  %v5550 = getelementptr i8, ptr %v5540, i64 80
  store ptr %v5174, ptr %v5550, align 8, !tbaa !3
  %v5551 = getelementptr i8, ptr %v5540, i64 88
  store ptr %v5176, ptr %v5551, align 8, !tbaa !3
  %v5552 = call ptr @mlf_closure(ptr @mlf.code.5243, ptr %v5540)
  %v5553 = call ptr @mlf_prim2(i64 1, ptr %v5234, ptr %v5552)
  ret ptr %v5553
}

define private ptr @mlf.code.5055(ptr %env, ptr %arg) {
entry:
  %v5056 = getelementptr i8, ptr %env, i64 8
  %v5057 = load ptr, ptr %v5056, align 8, !tbaa !3
  %v5058 = getelementptr i8, ptr %env, i64 16
  %v5059 = load ptr, ptr %v5058, align 8, !tbaa !3
  %v5060 = getelementptr i8, ptr %env, i64 24
  %v5061 = load ptr, ptr %v5060, align 8, !tbaa !3
  %v5062 = getelementptr i8, ptr %env, i64 32
  %v5063 = load ptr, ptr %v5062, align 8, !tbaa !3
  %v5064 = getelementptr i8, ptr %env, i64 40
  %v5065 = load ptr, ptr %v5064, align 8, !tbaa !3
  %v5066 = getelementptr i8, ptr %env, i64 48
  %v5067 = load ptr, ptr %v5066, align 8, !tbaa !3
  %v5068 = getelementptr i8, ptr %env, i64 56
  %v5069 = load ptr, ptr %v5068, align 8, !tbaa !3
  %v5070 = getelementptr i8, ptr %env, i64 64
  %v5071 = load ptr, ptr %v5070, align 8, !tbaa !3
  %v5072 = getelementptr i8, ptr %env, i64 72
  %v5073 = load ptr, ptr %v5072, align 8, !tbaa !3
  %v5074 = getelementptr i8, ptr %env, i64 80
  %v5075 = load ptr, ptr %v5074, align 8, !tbaa !3
  %v5076 = getelementptr i8, ptr %env, i64 88
  %v5077 = load ptr, ptr %v5076, align 8, !tbaa !3
  %v5078 = getelementptr i8, ptr %env, i64 96
  %v5079 = load ptr, ptr %v5078, align 8, !tbaa !3
  %v5080 = getelementptr i8, ptr %env, i64 104
  %v5081 = load ptr, ptr %v5080, align 8, !tbaa !3
  %v5082 = getelementptr i8, ptr %env, i64 112
  %v5083 = load ptr, ptr %v5082, align 8, !tbaa !3
  %v5141 = call ptr @mlf.allocate.thunk(ptr @mlf.code.5084, i64 6)
  %v5142 = getelementptr i8, ptr %v5141, i64 16
  %v5143 = load ptr, ptr %v5142, align 8, !tbaa !3
  %v5144 = getelementptr i8, ptr %v5143, i64 8
  store ptr %v5057, ptr %v5144, align 8, !tbaa !3
  %v5145 = getelementptr i8, ptr %v5143, i64 16
  store ptr %v5059, ptr %v5145, align 8, !tbaa !3
  %v5146 = getelementptr i8, ptr %v5143, i64 24
  store ptr %v5065, ptr %v5146, align 8, !tbaa !3
  %v5147 = getelementptr i8, ptr %v5143, i64 32
  store ptr %v5069, ptr %v5147, align 8, !tbaa !3
  %v5148 = getelementptr i8, ptr %v5143, i64 40
  store ptr %v5073, ptr %v5148, align 8, !tbaa !3
  %v5149 = getelementptr i8, ptr %v5143, i64 48
  store ptr %v5075, ptr %v5149, align 8, !tbaa !3
  %v5554 = call ptr @mlf_env_new(i64 13)
  %v5555 = getelementptr i8, ptr %v5554, i64 8
  store ptr %v5057, ptr %v5555, align 8, !tbaa !3
  %v5556 = getelementptr i8, ptr %v5554, i64 16
  store ptr %v5059, ptr %v5556, align 8, !tbaa !3
  %v5557 = getelementptr i8, ptr %v5554, i64 24
  store ptr %v5061, ptr %v5557, align 8, !tbaa !3
  %v5558 = getelementptr i8, ptr %v5554, i64 32
  store ptr %v5063, ptr %v5558, align 8, !tbaa !3
  %v5559 = getelementptr i8, ptr %v5554, i64 40
  store ptr %v5065, ptr %v5559, align 8, !tbaa !3
  %v5560 = getelementptr i8, ptr %v5554, i64 48
  store ptr %v5067, ptr %v5560, align 8, !tbaa !3
  %v5561 = getelementptr i8, ptr %v5554, i64 56
  store ptr %v5069, ptr %v5561, align 8, !tbaa !3
  %v5562 = getelementptr i8, ptr %v5554, i64 64
  store ptr %v5071, ptr %v5562, align 8, !tbaa !3
  %v5563 = getelementptr i8, ptr %v5554, i64 72
  store ptr %v5073, ptr %v5563, align 8, !tbaa !3
  %v5564 = getelementptr i8, ptr %v5554, i64 80
  store ptr %v5077, ptr %v5564, align 8, !tbaa !3
  %v5565 = getelementptr i8, ptr %v5554, i64 88
  store ptr %v5079, ptr %v5565, align 8, !tbaa !3
  %v5566 = getelementptr i8, ptr %v5554, i64 96
  store ptr %v5081, ptr %v5566, align 8, !tbaa !3
  %v5567 = getelementptr i8, ptr %v5554, i64 104
  store ptr %v5083, ptr %v5567, align 8, !tbaa !3
  %v5568 = call ptr @mlf_closure(ptr @mlf.code.5150, ptr %v5554)
  %v5569 = call ptr @mlf_prim2(i64 1, ptr %v5141, ptr %v5568)
  ret ptr %v5569
}

define private ptr @mlf.code.4960(ptr %env, ptr %arg) {
entry:
  %v4961 = getelementptr i8, ptr %env, i64 8
  %v4962 = load ptr, ptr %v4961, align 8, !tbaa !3
  %v4963 = getelementptr i8, ptr %env, i64 16
  %v4964 = load ptr, ptr %v4963, align 8, !tbaa !3
  %v4965 = getelementptr i8, ptr %env, i64 24
  %v4966 = load ptr, ptr %v4965, align 8, !tbaa !3
  %v4967 = getelementptr i8, ptr %env, i64 32
  %v4968 = load ptr, ptr %v4967, align 8, !tbaa !3
  %v4969 = getelementptr i8, ptr %env, i64 40
  %v4970 = load ptr, ptr %v4969, align 8, !tbaa !3
  %v4971 = getelementptr i8, ptr %env, i64 48
  %v4972 = load ptr, ptr %v4971, align 8, !tbaa !3
  %v4973 = getelementptr i8, ptr %env, i64 56
  %v4974 = load ptr, ptr %v4973, align 8, !tbaa !3
  %v4975 = getelementptr i8, ptr %env, i64 64
  %v4976 = load ptr, ptr %v4975, align 8, !tbaa !3
  %v4977 = getelementptr i8, ptr %env, i64 72
  %v4978 = load ptr, ptr %v4977, align 8, !tbaa !3
  %v4979 = getelementptr i8, ptr %env, i64 80
  %v4980 = load ptr, ptr %v4979, align 8, !tbaa !3
  %v4981 = getelementptr i8, ptr %env, i64 88
  %v4982 = load ptr, ptr %v4981, align 8, !tbaa !3
  %v4983 = getelementptr i8, ptr %env, i64 96
  %v4984 = load ptr, ptr %v4983, align 8, !tbaa !3
  %v4985 = getelementptr i8, ptr %env, i64 104
  %v4986 = load ptr, ptr %v4985, align 8, !tbaa !3
  %v4987 = getelementptr i8, ptr %env, i64 112
  %v4988 = load ptr, ptr %v4987, align 8, !tbaa !3
  %v5046 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4989, i64 6)
  %v5047 = getelementptr i8, ptr %v5046, i64 16
  %v5048 = load ptr, ptr %v5047, align 8, !tbaa !3
  %v5049 = getelementptr i8, ptr %v5048, i64 8
  store ptr %v4962, ptr %v5049, align 8, !tbaa !3
  %v5050 = getelementptr i8, ptr %v5048, i64 16
  store ptr %v4964, ptr %v5050, align 8, !tbaa !3
  %v5051 = getelementptr i8, ptr %v5048, i64 24
  store ptr %v4970, ptr %v5051, align 8, !tbaa !3
  %v5052 = getelementptr i8, ptr %v5048, i64 32
  store ptr %v4972, ptr %v5052, align 8, !tbaa !3
  %v5053 = getelementptr i8, ptr %v5048, i64 40
  store ptr %v4978, ptr %v5053, align 8, !tbaa !3
  %v5054 = getelementptr i8, ptr %v5048, i64 48
  store ptr %v4980, ptr %v5054, align 8, !tbaa !3
  %v5570 = call ptr @mlf_env_new(i64 14)
  %v5571 = getelementptr i8, ptr %v5570, i64 8
  store ptr %v4962, ptr %v5571, align 8, !tbaa !3
  %v5572 = getelementptr i8, ptr %v5570, i64 16
  store ptr %v4964, ptr %v5572, align 8, !tbaa !3
  %v5573 = getelementptr i8, ptr %v5570, i64 24
  store ptr %v4966, ptr %v5573, align 8, !tbaa !3
  %v5574 = getelementptr i8, ptr %v5570, i64 32
  store ptr %v4968, ptr %v5574, align 8, !tbaa !3
  %v5575 = getelementptr i8, ptr %v5570, i64 40
  store ptr %v4970, ptr %v5575, align 8, !tbaa !3
  %v5576 = getelementptr i8, ptr %v5570, i64 48
  store ptr %v4972, ptr %v5576, align 8, !tbaa !3
  %v5577 = getelementptr i8, ptr %v5570, i64 56
  store ptr %v4974, ptr %v5577, align 8, !tbaa !3
  %v5578 = getelementptr i8, ptr %v5570, i64 64
  store ptr %v4976, ptr %v5578, align 8, !tbaa !3
  %v5579 = getelementptr i8, ptr %v5570, i64 72
  store ptr %v4978, ptr %v5579, align 8, !tbaa !3
  %v5580 = getelementptr i8, ptr %v5570, i64 80
  store ptr %v4982, ptr %v5580, align 8, !tbaa !3
  %v5581 = getelementptr i8, ptr %v5570, i64 88
  store ptr %v4984, ptr %v5581, align 8, !tbaa !3
  %v5582 = getelementptr i8, ptr %v5570, i64 96
  store ptr %v4986, ptr %v5582, align 8, !tbaa !3
  %v5583 = getelementptr i8, ptr %v5570, i64 104
  store ptr %v4988, ptr %v5583, align 8, !tbaa !3
  %v5584 = getelementptr i8, ptr %v5570, i64 112
  store ptr %arg, ptr %v5584, align 8, !tbaa !3
  %v5585 = call ptr @mlf_closure(ptr @mlf.code.5055, ptr %v5570)
  %v5586 = call ptr @mlf_prim2(i64 1, ptr %v5046, ptr %v5585)
  ret ptr %v5586
}

define private ptr @mlf.code.4910(ptr %env, ptr %arg) {
entry:
  %v4911 = getelementptr i8, ptr %env, i64 8
  %v4912 = load ptr, ptr %v4911, align 8, !tbaa !3
  %v4913 = getelementptr i8, ptr %env, i64 16
  %v4914 = load ptr, ptr %v4913, align 8, !tbaa !3
  %v4915 = getelementptr i8, ptr %env, i64 24
  %v4916 = load ptr, ptr %v4915, align 8, !tbaa !3
  %v4917 = getelementptr i8, ptr %env, i64 32
  %v4918 = load ptr, ptr %v4917, align 8, !tbaa !3
  %v4919 = getelementptr i8, ptr %env, i64 40
  %v4920 = load ptr, ptr %v4919, align 8, !tbaa !3
  %v4921 = getelementptr i8, ptr %env, i64 48
  %v4922 = load ptr, ptr %v4921, align 8, !tbaa !3
  %v4923 = getelementptr i8, ptr %env, i64 56
  %v4924 = load ptr, ptr %v4923, align 8, !tbaa !3
  %v4925 = getelementptr i8, ptr %env, i64 64
  %v4926 = load ptr, ptr %v4925, align 8, !tbaa !3
  %v4927 = getelementptr i8, ptr %env, i64 72
  %v4928 = load ptr, ptr %v4927, align 8, !tbaa !3
  %v4929 = getelementptr i8, ptr %env, i64 80
  %v4930 = load ptr, ptr %v4929, align 8, !tbaa !3
  %v4931 = getelementptr i8, ptr %env, i64 88
  %v4932 = load ptr, ptr %v4931, align 8, !tbaa !3
  %v4933 = getelementptr i8, ptr %env, i64 96
  %v4934 = load ptr, ptr %v4933, align 8, !tbaa !3
  %v4935 = getelementptr i8, ptr %env, i64 104
  %v4936 = load ptr, ptr %v4935, align 8, !tbaa !3
  %v4955 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4937, i64 2)
  %v4956 = getelementptr i8, ptr %v4955, i64 16
  %v4957 = load ptr, ptr %v4956, align 8, !tbaa !3
  %v4958 = getelementptr i8, ptr %v4957, i64 8
  store ptr %v4912, ptr %v4958, align 8, !tbaa !3
  %v4959 = getelementptr i8, ptr %v4957, i64 16
  store ptr %v4916, ptr %v4959, align 8, !tbaa !3
  %v5587 = call ptr @mlf_env_new(i64 14)
  %v5588 = getelementptr i8, ptr %v5587, i64 8
  store ptr %v4912, ptr %v5588, align 8, !tbaa !3
  %v5589 = getelementptr i8, ptr %v5587, i64 16
  store ptr %v4914, ptr %v5589, align 8, !tbaa !3
  %v5590 = getelementptr i8, ptr %v5587, i64 24
  store ptr %v4916, ptr %v5590, align 8, !tbaa !3
  %v5591 = getelementptr i8, ptr %v5587, i64 32
  store ptr %v4918, ptr %v5591, align 8, !tbaa !3
  %v5592 = getelementptr i8, ptr %v5587, i64 40
  store ptr %v4920, ptr %v5592, align 8, !tbaa !3
  %v5593 = getelementptr i8, ptr %v5587, i64 48
  store ptr %v4922, ptr %v5593, align 8, !tbaa !3
  %v5594 = getelementptr i8, ptr %v5587, i64 56
  store ptr %v4924, ptr %v5594, align 8, !tbaa !3
  %v5595 = getelementptr i8, ptr %v5587, i64 64
  store ptr %v4926, ptr %v5595, align 8, !tbaa !3
  %v5596 = getelementptr i8, ptr %v5587, i64 72
  store ptr %v4928, ptr %v5596, align 8, !tbaa !3
  %v5597 = getelementptr i8, ptr %v5587, i64 80
  store ptr %v4930, ptr %v5597, align 8, !tbaa !3
  %v5598 = getelementptr i8, ptr %v5587, i64 88
  store ptr %v4932, ptr %v5598, align 8, !tbaa !3
  %v5599 = getelementptr i8, ptr %v5587, i64 96
  store ptr %v4934, ptr %v5599, align 8, !tbaa !3
  %v5600 = getelementptr i8, ptr %v5587, i64 104
  store ptr %v4936, ptr %v5600, align 8, !tbaa !3
  %v5601 = getelementptr i8, ptr %v5587, i64 112
  store ptr %arg, ptr %v5601, align 8, !tbaa !3
  %v5602 = call ptr @mlf_closure(ptr @mlf.code.4960, ptr %v5587)
  %v5603 = call ptr @mlf_prim2(i64 1, ptr %v4955, ptr %v5602)
  ret ptr %v5603
}

define private ptr @mlf.code.4862(ptr %env, ptr %arg) {
entry:
  %v4863 = getelementptr i8, ptr %env, i64 8
  %v4864 = load ptr, ptr %v4863, align 8, !tbaa !3
  %v4865 = getelementptr i8, ptr %env, i64 16
  %v4866 = load ptr, ptr %v4865, align 8, !tbaa !3
  %v4867 = getelementptr i8, ptr %env, i64 24
  %v4868 = load ptr, ptr %v4867, align 8, !tbaa !3
  %v4869 = getelementptr i8, ptr %env, i64 32
  %v4870 = load ptr, ptr %v4869, align 8, !tbaa !3
  %v4871 = getelementptr i8, ptr %env, i64 40
  %v4872 = load ptr, ptr %v4871, align 8, !tbaa !3
  %v4873 = getelementptr i8, ptr %env, i64 48
  %v4874 = load ptr, ptr %v4873, align 8, !tbaa !3
  %v4875 = getelementptr i8, ptr %env, i64 56
  %v4876 = load ptr, ptr %v4875, align 8, !tbaa !3
  %v4877 = getelementptr i8, ptr %env, i64 64
  %v4878 = load ptr, ptr %v4877, align 8, !tbaa !3
  %v4879 = getelementptr i8, ptr %env, i64 72
  %v4880 = load ptr, ptr %v4879, align 8, !tbaa !3
  %v4881 = getelementptr i8, ptr %env, i64 80
  %v4882 = load ptr, ptr %v4881, align 8, !tbaa !3
  %v4883 = getelementptr i8, ptr %env, i64 88
  %v4884 = load ptr, ptr %v4883, align 8, !tbaa !3
  %v4885 = getelementptr i8, ptr %env, i64 96
  %v4886 = load ptr, ptr %v4885, align 8, !tbaa !3
  %v4905 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4887, i64 2)
  %v4906 = getelementptr i8, ptr %v4905, i64 16
  %v4907 = load ptr, ptr %v4906, align 8, !tbaa !3
  %v4908 = getelementptr i8, ptr %v4907, i64 8
  store ptr %v4864, ptr %v4908, align 8, !tbaa !3
  %v4909 = getelementptr i8, ptr %v4907, i64 16
  store ptr %v4868, ptr %v4909, align 8, !tbaa !3
  %v5604 = call ptr @mlf_env_new(i64 13)
  %v5605 = getelementptr i8, ptr %v5604, i64 8
  store ptr %v4864, ptr %v5605, align 8, !tbaa !3
  %v5606 = getelementptr i8, ptr %v5604, i64 16
  store ptr %v4866, ptr %v5606, align 8, !tbaa !3
  %v5607 = getelementptr i8, ptr %v5604, i64 24
  store ptr %v4868, ptr %v5607, align 8, !tbaa !3
  %v5608 = getelementptr i8, ptr %v5604, i64 32
  store ptr %v4870, ptr %v5608, align 8, !tbaa !3
  %v5609 = getelementptr i8, ptr %v5604, i64 40
  store ptr %v4872, ptr %v5609, align 8, !tbaa !3
  %v5610 = getelementptr i8, ptr %v5604, i64 48
  store ptr %v4874, ptr %v5610, align 8, !tbaa !3
  %v5611 = getelementptr i8, ptr %v5604, i64 56
  store ptr %v4876, ptr %v5611, align 8, !tbaa !3
  %v5612 = getelementptr i8, ptr %v5604, i64 64
  store ptr %v4878, ptr %v5612, align 8, !tbaa !3
  %v5613 = getelementptr i8, ptr %v5604, i64 72
  store ptr %v4880, ptr %v5613, align 8, !tbaa !3
  %v5614 = getelementptr i8, ptr %v5604, i64 80
  store ptr %v4882, ptr %v5614, align 8, !tbaa !3
  %v5615 = getelementptr i8, ptr %v5604, i64 88
  store ptr %v4884, ptr %v5615, align 8, !tbaa !3
  %v5616 = getelementptr i8, ptr %v5604, i64 96
  store ptr %v4886, ptr %v5616, align 8, !tbaa !3
  %v5617 = getelementptr i8, ptr %v5604, i64 104
  store ptr %arg, ptr %v5617, align 8, !tbaa !3
  %v5618 = call ptr @mlf_closure(ptr @mlf.code.4910, ptr %v5604)
  %v5619 = call ptr @mlf_prim2(i64 1, ptr %v4905, ptr %v5618)
  ret ptr %v5619
}

define private ptr @mlf.code.4816(ptr %env, ptr %arg) {
entry:
  %v4817 = getelementptr i8, ptr %env, i64 8
  %v4818 = load ptr, ptr %v4817, align 8, !tbaa !3
  %v4819 = getelementptr i8, ptr %env, i64 16
  %v4820 = load ptr, ptr %v4819, align 8, !tbaa !3
  %v4821 = getelementptr i8, ptr %env, i64 24
  %v4822 = load ptr, ptr %v4821, align 8, !tbaa !3
  %v4823 = getelementptr i8, ptr %env, i64 32
  %v4824 = load ptr, ptr %v4823, align 8, !tbaa !3
  %v4825 = getelementptr i8, ptr %env, i64 40
  %v4826 = load ptr, ptr %v4825, align 8, !tbaa !3
  %v4827 = getelementptr i8, ptr %env, i64 48
  %v4828 = load ptr, ptr %v4827, align 8, !tbaa !3
  %v4829 = getelementptr i8, ptr %env, i64 56
  %v4830 = load ptr, ptr %v4829, align 8, !tbaa !3
  %v4831 = getelementptr i8, ptr %env, i64 64
  %v4832 = load ptr, ptr %v4831, align 8, !tbaa !3
  %v4833 = getelementptr i8, ptr %env, i64 72
  %v4834 = load ptr, ptr %v4833, align 8, !tbaa !3
  %v4835 = getelementptr i8, ptr %env, i64 80
  %v4836 = load ptr, ptr %v4835, align 8, !tbaa !3
  %v4837 = getelementptr i8, ptr %env, i64 88
  %v4838 = load ptr, ptr %v4837, align 8, !tbaa !3
  %v4857 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4839, i64 2)
  %v4858 = getelementptr i8, ptr %v4857, i64 16
  %v4859 = load ptr, ptr %v4858, align 8, !tbaa !3
  %v4860 = getelementptr i8, ptr %v4859, i64 8
  store ptr %v4818, ptr %v4860, align 8, !tbaa !3
  %v4861 = getelementptr i8, ptr %v4859, i64 16
  store ptr %v4822, ptr %v4861, align 8, !tbaa !3
  %v5620 = call ptr @mlf_env_new(i64 12)
  %v5621 = getelementptr i8, ptr %v5620, i64 8
  store ptr %v4818, ptr %v5621, align 8, !tbaa !3
  %v5622 = getelementptr i8, ptr %v5620, i64 16
  store ptr %v4820, ptr %v5622, align 8, !tbaa !3
  %v5623 = getelementptr i8, ptr %v5620, i64 24
  store ptr %v4822, ptr %v5623, align 8, !tbaa !3
  %v5624 = getelementptr i8, ptr %v5620, i64 32
  store ptr %v4824, ptr %v5624, align 8, !tbaa !3
  %v5625 = getelementptr i8, ptr %v5620, i64 40
  store ptr %v4826, ptr %v5625, align 8, !tbaa !3
  %v5626 = getelementptr i8, ptr %v5620, i64 48
  store ptr %v4828, ptr %v5626, align 8, !tbaa !3
  %v5627 = getelementptr i8, ptr %v5620, i64 56
  store ptr %v4830, ptr %v5627, align 8, !tbaa !3
  %v5628 = getelementptr i8, ptr %v5620, i64 64
  store ptr %v4832, ptr %v5628, align 8, !tbaa !3
  %v5629 = getelementptr i8, ptr %v5620, i64 72
  store ptr %v4834, ptr %v5629, align 8, !tbaa !3
  %v5630 = getelementptr i8, ptr %v5620, i64 80
  store ptr %v4836, ptr %v5630, align 8, !tbaa !3
  %v5631 = getelementptr i8, ptr %v5620, i64 88
  store ptr %v4838, ptr %v5631, align 8, !tbaa !3
  %v5632 = getelementptr i8, ptr %v5620, i64 96
  store ptr %arg, ptr %v5632, align 8, !tbaa !3
  %v5633 = call ptr @mlf_closure(ptr @mlf.code.4862, ptr %v5620)
  %v5634 = call ptr @mlf_prim2(i64 1, ptr %v4857, ptr %v5633)
  ret ptr %v5634
}

define private ptr @mlf.code.4772(ptr %env, ptr %arg) {
entry:
  %v4773 = getelementptr i8, ptr %env, i64 8
  %v4774 = load ptr, ptr %v4773, align 8, !tbaa !3
  %v4775 = getelementptr i8, ptr %env, i64 16
  %v4776 = load ptr, ptr %v4775, align 8, !tbaa !3
  %v4777 = getelementptr i8, ptr %env, i64 24
  %v4778 = load ptr, ptr %v4777, align 8, !tbaa !3
  %v4779 = getelementptr i8, ptr %env, i64 32
  %v4780 = load ptr, ptr %v4779, align 8, !tbaa !3
  %v4781 = getelementptr i8, ptr %env, i64 40
  %v4782 = load ptr, ptr %v4781, align 8, !tbaa !3
  %v4783 = getelementptr i8, ptr %env, i64 48
  %v4784 = load ptr, ptr %v4783, align 8, !tbaa !3
  %v4785 = getelementptr i8, ptr %env, i64 56
  %v4786 = load ptr, ptr %v4785, align 8, !tbaa !3
  %v4787 = getelementptr i8, ptr %env, i64 64
  %v4788 = load ptr, ptr %v4787, align 8, !tbaa !3
  %v4789 = getelementptr i8, ptr %env, i64 72
  %v4790 = load ptr, ptr %v4789, align 8, !tbaa !3
  %v4791 = getelementptr i8, ptr %env, i64 80
  %v4792 = load ptr, ptr %v4791, align 8, !tbaa !3
  %v4811 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4793, i64 2)
  %v4812 = getelementptr i8, ptr %v4811, i64 16
  %v4813 = load ptr, ptr %v4812, align 8, !tbaa !3
  %v4814 = getelementptr i8, ptr %v4813, i64 8
  store ptr %v4774, ptr %v4814, align 8, !tbaa !3
  %v4815 = getelementptr i8, ptr %v4813, i64 16
  store ptr %v4776, ptr %v4815, align 8, !tbaa !3
  %v5635 = call ptr @mlf_env_new(i64 11)
  %v5636 = getelementptr i8, ptr %v5635, i64 8
  store ptr %v4774, ptr %v5636, align 8, !tbaa !3
  %v5637 = getelementptr i8, ptr %v5635, i64 16
  store ptr %v4776, ptr %v5637, align 8, !tbaa !3
  %v5638 = getelementptr i8, ptr %v5635, i64 24
  store ptr %v4778, ptr %v5638, align 8, !tbaa !3
  %v5639 = getelementptr i8, ptr %v5635, i64 32
  store ptr %v4780, ptr %v5639, align 8, !tbaa !3
  %v5640 = getelementptr i8, ptr %v5635, i64 40
  store ptr %v4782, ptr %v5640, align 8, !tbaa !3
  %v5641 = getelementptr i8, ptr %v5635, i64 48
  store ptr %v4784, ptr %v5641, align 8, !tbaa !3
  %v5642 = getelementptr i8, ptr %v5635, i64 56
  store ptr %v4786, ptr %v5642, align 8, !tbaa !3
  %v5643 = getelementptr i8, ptr %v5635, i64 64
  store ptr %v4788, ptr %v5643, align 8, !tbaa !3
  %v5644 = getelementptr i8, ptr %v5635, i64 72
  store ptr %v4790, ptr %v5644, align 8, !tbaa !3
  %v5645 = getelementptr i8, ptr %v5635, i64 80
  store ptr %v4792, ptr %v5645, align 8, !tbaa !3
  %v5646 = getelementptr i8, ptr %v5635, i64 88
  store ptr %arg, ptr %v5646, align 8, !tbaa !3
  %v5647 = call ptr @mlf_closure(ptr @mlf.code.4816, ptr %v5635)
  %v5648 = call ptr @mlf_prim2(i64 1, ptr %v4811, ptr %v5647)
  ret ptr %v5648
}

define private ptr @mlf.code.4730(ptr %env, ptr %arg) {
entry:
  %v4731 = getelementptr i8, ptr %env, i64 8
  %v4732 = load ptr, ptr %v4731, align 8, !tbaa !3
  %v4733 = getelementptr i8, ptr %env, i64 16
  %v4734 = load ptr, ptr %v4733, align 8, !tbaa !3
  %v4735 = getelementptr i8, ptr %env, i64 24
  %v4736 = load ptr, ptr %v4735, align 8, !tbaa !3
  %v4737 = getelementptr i8, ptr %env, i64 32
  %v4738 = load ptr, ptr %v4737, align 8, !tbaa !3
  %v4739 = getelementptr i8, ptr %env, i64 40
  %v4740 = load ptr, ptr %v4739, align 8, !tbaa !3
  %v4741 = getelementptr i8, ptr %env, i64 48
  %v4742 = load ptr, ptr %v4741, align 8, !tbaa !3
  %v4743 = getelementptr i8, ptr %env, i64 56
  %v4744 = load ptr, ptr %v4743, align 8, !tbaa !3
  %v4745 = getelementptr i8, ptr %env, i64 64
  %v4746 = load ptr, ptr %v4745, align 8, !tbaa !3
  %v4747 = getelementptr i8, ptr %env, i64 72
  %v4748 = load ptr, ptr %v4747, align 8, !tbaa !3
  %v4767 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4749, i64 2)
  %v4768 = getelementptr i8, ptr %v4767, i64 16
  %v4769 = load ptr, ptr %v4768, align 8, !tbaa !3
  %v4770 = getelementptr i8, ptr %v4769, i64 8
  store ptr %v4732, ptr %v4770, align 8, !tbaa !3
  %v4771 = getelementptr i8, ptr %v4769, i64 16
  store ptr %v4734, ptr %v4771, align 8, !tbaa !3
  %v5649 = call ptr @mlf_env_new(i64 10)
  %v5650 = getelementptr i8, ptr %v5649, i64 8
  store ptr %v4732, ptr %v5650, align 8, !tbaa !3
  %v5651 = getelementptr i8, ptr %v5649, i64 16
  store ptr %v4734, ptr %v5651, align 8, !tbaa !3
  %v5652 = getelementptr i8, ptr %v5649, i64 24
  store ptr %v4736, ptr %v5652, align 8, !tbaa !3
  %v5653 = getelementptr i8, ptr %v5649, i64 32
  store ptr %v4738, ptr %v5653, align 8, !tbaa !3
  %v5654 = getelementptr i8, ptr %v5649, i64 40
  store ptr %v4740, ptr %v5654, align 8, !tbaa !3
  %v5655 = getelementptr i8, ptr %v5649, i64 48
  store ptr %v4742, ptr %v5655, align 8, !tbaa !3
  %v5656 = getelementptr i8, ptr %v5649, i64 56
  store ptr %v4744, ptr %v5656, align 8, !tbaa !3
  %v5657 = getelementptr i8, ptr %v5649, i64 64
  store ptr %v4746, ptr %v5657, align 8, !tbaa !3
  %v5658 = getelementptr i8, ptr %v5649, i64 72
  store ptr %v4748, ptr %v5658, align 8, !tbaa !3
  %v5659 = getelementptr i8, ptr %v5649, i64 80
  store ptr %arg, ptr %v5659, align 8, !tbaa !3
  %v5660 = call ptr @mlf_closure(ptr @mlf.code.4772, ptr %v5649)
  %v5661 = call ptr @mlf_prim2(i64 1, ptr %v4767, ptr %v5660)
  ret ptr %v5661
}

define private ptr @mlf.code.4603(ptr %env, ptr %arg) {
entry:
  %v4604 = getelementptr i8, ptr %env, i64 8
  %v4605 = load ptr, ptr %v4604, align 8, !tbaa !3
  %v4606 = getelementptr i8, ptr %env, i64 16
  %v4607 = load ptr, ptr %v4606, align 8, !tbaa !3
  %v4608 = getelementptr i8, ptr %env, i64 24
  %v4609 = load ptr, ptr %v4608, align 8, !tbaa !3
  %v4610 = getelementptr i8, ptr %env, i64 32
  %v4611 = load ptr, ptr %v4610, align 8, !tbaa !3
  %v4612 = getelementptr i8, ptr %env, i64 40
  %v4613 = load ptr, ptr %v4612, align 8, !tbaa !3
  %v4614 = getelementptr i8, ptr %env, i64 48
  %v4615 = load ptr, ptr %v4614, align 8, !tbaa !3
  %v4616 = getelementptr i8, ptr %env, i64 56
  %v4617 = load ptr, ptr %v4616, align 8, !tbaa !3
  %v4618 = getelementptr i8, ptr %env, i64 64
  %v4619 = load ptr, ptr %v4618, align 8, !tbaa !3
  %v4620 = getelementptr i8, ptr %env, i64 72
  %v4621 = load ptr, ptr %v4620, align 8, !tbaa !3
  %v4622 = getelementptr i8, ptr %env, i64 80
  %v4623 = load ptr, ptr %v4622, align 8, !tbaa !3
  %v4634 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4624, i64 2)
  %v4635 = getelementptr i8, ptr %v4634, i64 16
  %v4636 = load ptr, ptr %v4635, align 8, !tbaa !3
  %v4637 = getelementptr i8, ptr %v4636, i64 8
  store ptr %v4611, ptr %v4637, align 8, !tbaa !3
  %v4638 = getelementptr i8, ptr %v4636, i64 16
  store ptr %v4619, ptr %v4638, align 8, !tbaa !3
  %v4649 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4639, i64 2)
  %v4650 = getelementptr i8, ptr %v4649, i64 16
  %v4651 = load ptr, ptr %v4650, align 8, !tbaa !3
  %v4652 = getelementptr i8, ptr %v4651, i64 8
  store ptr %v4613, ptr %v4652, align 8, !tbaa !3
  %v4653 = getelementptr i8, ptr %v4651, i64 16
  store ptr %v4621, ptr %v4653, align 8, !tbaa !3
  %v4664 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4654, i64 2)
  %v4665 = getelementptr i8, ptr %v4664, i64 16
  %v4666 = load ptr, ptr %v4665, align 8, !tbaa !3
  %v4667 = getelementptr i8, ptr %v4666, i64 8
  store ptr %v4615, ptr %v4667, align 8, !tbaa !3
  %v4668 = getelementptr i8, ptr %v4666, i64 16
  store ptr %v4623, ptr %v4668, align 8, !tbaa !3
  %v4688 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4669, i64 3)
  %v4689 = getelementptr i8, ptr %v4688, i64 16
  %v4690 = load ptr, ptr %v4689, align 8, !tbaa !3
  %v4691 = getelementptr i8, ptr %v4690, i64 8
  store ptr %v4634, ptr %v4691, align 8, !tbaa !3
  %v4692 = getelementptr i8, ptr %v4690, i64 16
  store ptr %v4649, ptr %v4692, align 8, !tbaa !3
  %v4693 = getelementptr i8, ptr %v4690, i64 24
  store ptr %v4664, ptr %v4693, align 8, !tbaa !3
  %v4703 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4694, i64 1)
  %v4704 = getelementptr i8, ptr %v4703, i64 16
  %v4705 = load ptr, ptr %v4704, align 8, !tbaa !3
  %v4706 = getelementptr i8, ptr %v4705, i64 8
  store ptr %v4688, ptr %v4706, align 8, !tbaa !3
  %v4725 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4707, i64 2)
  %v4726 = getelementptr i8, ptr %v4725, i64 16
  %v4727 = load ptr, ptr %v4726, align 8, !tbaa !3
  %v4728 = getelementptr i8, ptr %v4727, i64 8
  store ptr %v4605, ptr %v4728, align 8, !tbaa !3
  %v4729 = getelementptr i8, ptr %v4727, i64 16
  store ptr %v4607, ptr %v4729, align 8, !tbaa !3
  %v5662 = call ptr @mlf_env_new(i64 9)
  %v5663 = getelementptr i8, ptr %v5662, i64 8
  store ptr %v4605, ptr %v5663, align 8, !tbaa !3
  %v5664 = getelementptr i8, ptr %v5662, i64 16
  store ptr %v4607, ptr %v5664, align 8, !tbaa !3
  %v5665 = getelementptr i8, ptr %v5662, i64 24
  store ptr %v4609, ptr %v5665, align 8, !tbaa !3
  %v5666 = getelementptr i8, ptr %v5662, i64 32
  store ptr %v4617, ptr %v5666, align 8, !tbaa !3
  %v5667 = getelementptr i8, ptr %v5662, i64 40
  store ptr %arg, ptr %v5667, align 8, !tbaa !3
  %v5668 = getelementptr i8, ptr %v5662, i64 48
  store ptr %v4634, ptr %v5668, align 8, !tbaa !3
  %v5669 = getelementptr i8, ptr %v5662, i64 56
  store ptr %v4649, ptr %v5669, align 8, !tbaa !3
  %v5670 = getelementptr i8, ptr %v5662, i64 64
  store ptr %v4664, ptr %v5670, align 8, !tbaa !3
  %v5671 = getelementptr i8, ptr %v5662, i64 72
  store ptr %v4703, ptr %v5671, align 8, !tbaa !3
  %v5672 = call ptr @mlf_closure(ptr @mlf.code.4730, ptr %v5662)
  %v5673 = call ptr @mlf_prim2(i64 1, ptr %v4725, ptr %v5672)
  ret ptr %v5673
}

define private ptr @mlf.code.4561(ptr %env, ptr %arg) {
entry:
  %v4562 = getelementptr i8, ptr %env, i64 8
  %v4563 = load ptr, ptr %v4562, align 8, !tbaa !3
  %v4564 = getelementptr i8, ptr %env, i64 16
  %v4565 = load ptr, ptr %v4564, align 8, !tbaa !3
  %v4566 = getelementptr i8, ptr %env, i64 24
  %v4567 = load ptr, ptr %v4566, align 8, !tbaa !3
  %v4568 = getelementptr i8, ptr %env, i64 32
  %v4569 = load ptr, ptr %v4568, align 8, !tbaa !3
  %v4570 = getelementptr i8, ptr %env, i64 40
  %v4571 = load ptr, ptr %v4570, align 8, !tbaa !3
  %v4572 = getelementptr i8, ptr %env, i64 48
  %v4573 = load ptr, ptr %v4572, align 8, !tbaa !3
  %v4574 = getelementptr i8, ptr %env, i64 56
  %v4575 = load ptr, ptr %v4574, align 8, !tbaa !3
  %v4576 = getelementptr i8, ptr %env, i64 64
  %v4577 = load ptr, ptr %v4576, align 8, !tbaa !3
  %v4578 = getelementptr i8, ptr %env, i64 72
  %v4579 = load ptr, ptr %v4578, align 8, !tbaa !3
  %v4598 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4580, i64 2)
  %v4599 = getelementptr i8, ptr %v4598, i64 16
  %v4600 = load ptr, ptr %v4599, align 8, !tbaa !3
  %v4601 = getelementptr i8, ptr %v4600, i64 8
  store ptr %v4563, ptr %v4601, align 8, !tbaa !3
  %v4602 = getelementptr i8, ptr %v4600, i64 16
  store ptr %v4567, ptr %v4602, align 8, !tbaa !3
  %v5674 = call ptr @mlf_env_new(i64 10)
  %v5675 = getelementptr i8, ptr %v5674, i64 8
  store ptr %v4563, ptr %v5675, align 8, !tbaa !3
  %v5676 = getelementptr i8, ptr %v5674, i64 16
  store ptr %v4565, ptr %v5676, align 8, !tbaa !3
  %v5677 = getelementptr i8, ptr %v5674, i64 24
  store ptr %v4567, ptr %v5677, align 8, !tbaa !3
  %v5678 = getelementptr i8, ptr %v5674, i64 32
  store ptr %v4569, ptr %v5678, align 8, !tbaa !3
  %v5679 = getelementptr i8, ptr %v5674, i64 40
  store ptr %v4571, ptr %v5679, align 8, !tbaa !3
  %v5680 = getelementptr i8, ptr %v5674, i64 48
  store ptr %v4573, ptr %v5680, align 8, !tbaa !3
  %v5681 = getelementptr i8, ptr %v5674, i64 56
  store ptr %v4575, ptr %v5681, align 8, !tbaa !3
  %v5682 = getelementptr i8, ptr %v5674, i64 64
  store ptr %v4577, ptr %v5682, align 8, !tbaa !3
  %v5683 = getelementptr i8, ptr %v5674, i64 72
  store ptr %v4579, ptr %v5683, align 8, !tbaa !3
  %v5684 = getelementptr i8, ptr %v5674, i64 80
  store ptr %arg, ptr %v5684, align 8, !tbaa !3
  %v5685 = call ptr @mlf_closure(ptr @mlf.code.4603, ptr %v5674)
  %v5686 = call ptr @mlf_prim2(i64 1, ptr %v4598, ptr %v5685)
  ret ptr %v5686
}

define private ptr @mlf.code.4521(ptr %env, ptr %arg) {
entry:
  %v4522 = getelementptr i8, ptr %env, i64 8
  %v4523 = load ptr, ptr %v4522, align 8, !tbaa !3
  %v4524 = getelementptr i8, ptr %env, i64 16
  %v4525 = load ptr, ptr %v4524, align 8, !tbaa !3
  %v4526 = getelementptr i8, ptr %env, i64 24
  %v4527 = load ptr, ptr %v4526, align 8, !tbaa !3
  %v4528 = getelementptr i8, ptr %env, i64 32
  %v4529 = load ptr, ptr %v4528, align 8, !tbaa !3
  %v4530 = getelementptr i8, ptr %env, i64 40
  %v4531 = load ptr, ptr %v4530, align 8, !tbaa !3
  %v4532 = getelementptr i8, ptr %env, i64 48
  %v4533 = load ptr, ptr %v4532, align 8, !tbaa !3
  %v4534 = getelementptr i8, ptr %env, i64 56
  %v4535 = load ptr, ptr %v4534, align 8, !tbaa !3
  %v4536 = getelementptr i8, ptr %env, i64 64
  %v4537 = load ptr, ptr %v4536, align 8, !tbaa !3
  %v4556 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4538, i64 2)
  %v4557 = getelementptr i8, ptr %v4556, i64 16
  %v4558 = load ptr, ptr %v4557, align 8, !tbaa !3
  %v4559 = getelementptr i8, ptr %v4558, i64 8
  store ptr %v4523, ptr %v4559, align 8, !tbaa !3
  %v4560 = getelementptr i8, ptr %v4558, i64 16
  store ptr %v4527, ptr %v4560, align 8, !tbaa !3
  %v5687 = call ptr @mlf_env_new(i64 9)
  %v5688 = getelementptr i8, ptr %v5687, i64 8
  store ptr %v4523, ptr %v5688, align 8, !tbaa !3
  %v5689 = getelementptr i8, ptr %v5687, i64 16
  store ptr %v4525, ptr %v5689, align 8, !tbaa !3
  %v5690 = getelementptr i8, ptr %v5687, i64 24
  store ptr %v4527, ptr %v5690, align 8, !tbaa !3
  %v5691 = getelementptr i8, ptr %v5687, i64 32
  store ptr %v4529, ptr %v5691, align 8, !tbaa !3
  %v5692 = getelementptr i8, ptr %v5687, i64 40
  store ptr %v4531, ptr %v5692, align 8, !tbaa !3
  %v5693 = getelementptr i8, ptr %v5687, i64 48
  store ptr %v4533, ptr %v5693, align 8, !tbaa !3
  %v5694 = getelementptr i8, ptr %v5687, i64 56
  store ptr %v4535, ptr %v5694, align 8, !tbaa !3
  %v5695 = getelementptr i8, ptr %v5687, i64 64
  store ptr %v4537, ptr %v5695, align 8, !tbaa !3
  %v5696 = getelementptr i8, ptr %v5687, i64 72
  store ptr %arg, ptr %v5696, align 8, !tbaa !3
  %v5697 = call ptr @mlf_closure(ptr @mlf.code.4561, ptr %v5687)
  %v5698 = call ptr @mlf_prim2(i64 1, ptr %v4556, ptr %v5697)
  ret ptr %v5698
}

define private ptr @mlf.code.4483(ptr %env, ptr %arg) {
entry:
  %v4484 = getelementptr i8, ptr %env, i64 8
  %v4485 = load ptr, ptr %v4484, align 8, !tbaa !3
  %v4486 = getelementptr i8, ptr %env, i64 16
  %v4487 = load ptr, ptr %v4486, align 8, !tbaa !3
  %v4488 = getelementptr i8, ptr %env, i64 24
  %v4489 = load ptr, ptr %v4488, align 8, !tbaa !3
  %v4490 = getelementptr i8, ptr %env, i64 32
  %v4491 = load ptr, ptr %v4490, align 8, !tbaa !3
  %v4492 = getelementptr i8, ptr %env, i64 40
  %v4493 = load ptr, ptr %v4492, align 8, !tbaa !3
  %v4494 = getelementptr i8, ptr %env, i64 48
  %v4495 = load ptr, ptr %v4494, align 8, !tbaa !3
  %v4496 = getelementptr i8, ptr %env, i64 56
  %v4497 = load ptr, ptr %v4496, align 8, !tbaa !3
  %v4516 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4498, i64 2)
  %v4517 = getelementptr i8, ptr %v4516, i64 16
  %v4518 = load ptr, ptr %v4517, align 8, !tbaa !3
  %v4519 = getelementptr i8, ptr %v4518, i64 8
  store ptr %v4485, ptr %v4519, align 8, !tbaa !3
  %v4520 = getelementptr i8, ptr %v4518, i64 16
  store ptr %v4489, ptr %v4520, align 8, !tbaa !3
  %v5699 = call ptr @mlf_env_new(i64 8)
  %v5700 = getelementptr i8, ptr %v5699, i64 8
  store ptr %v4485, ptr %v5700, align 8, !tbaa !3
  %v5701 = getelementptr i8, ptr %v5699, i64 16
  store ptr %v4487, ptr %v5701, align 8, !tbaa !3
  %v5702 = getelementptr i8, ptr %v5699, i64 24
  store ptr %v4489, ptr %v5702, align 8, !tbaa !3
  %v5703 = getelementptr i8, ptr %v5699, i64 32
  store ptr %v4491, ptr %v5703, align 8, !tbaa !3
  %v5704 = getelementptr i8, ptr %v5699, i64 40
  store ptr %v4493, ptr %v5704, align 8, !tbaa !3
  %v5705 = getelementptr i8, ptr %v5699, i64 48
  store ptr %v4495, ptr %v5705, align 8, !tbaa !3
  %v5706 = getelementptr i8, ptr %v5699, i64 56
  store ptr %v4497, ptr %v5706, align 8, !tbaa !3
  %v5707 = getelementptr i8, ptr %v5699, i64 64
  store ptr %arg, ptr %v5707, align 8, !tbaa !3
  %v5708 = call ptr @mlf_closure(ptr @mlf.code.4521, ptr %v5699)
  %v5709 = call ptr @mlf_prim2(i64 1, ptr %v4516, ptr %v5708)
  ret ptr %v5709
}

define private ptr @mlf.code.4447(ptr %env, ptr %arg) {
entry:
  %v4448 = getelementptr i8, ptr %env, i64 8
  %v4449 = load ptr, ptr %v4448, align 8, !tbaa !3
  %v4450 = getelementptr i8, ptr %env, i64 16
  %v4451 = load ptr, ptr %v4450, align 8, !tbaa !3
  %v4452 = getelementptr i8, ptr %env, i64 24
  %v4453 = load ptr, ptr %v4452, align 8, !tbaa !3
  %v4454 = getelementptr i8, ptr %env, i64 32
  %v4455 = load ptr, ptr %v4454, align 8, !tbaa !3
  %v4456 = getelementptr i8, ptr %env, i64 40
  %v4457 = load ptr, ptr %v4456, align 8, !tbaa !3
  %v4458 = getelementptr i8, ptr %env, i64 48
  %v4459 = load ptr, ptr %v4458, align 8, !tbaa !3
  %v4478 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4460, i64 2)
  %v4479 = getelementptr i8, ptr %v4478, i64 16
  %v4480 = load ptr, ptr %v4479, align 8, !tbaa !3
  %v4481 = getelementptr i8, ptr %v4480, i64 8
  store ptr %v4449, ptr %v4481, align 8, !tbaa !3
  %v4482 = getelementptr i8, ptr %v4480, i64 16
  store ptr %v4453, ptr %v4482, align 8, !tbaa !3
  %v5710 = call ptr @mlf_env_new(i64 7)
  %v5711 = getelementptr i8, ptr %v5710, i64 8
  store ptr %v4449, ptr %v5711, align 8, !tbaa !3
  %v5712 = getelementptr i8, ptr %v5710, i64 16
  store ptr %v4451, ptr %v5712, align 8, !tbaa !3
  %v5713 = getelementptr i8, ptr %v5710, i64 24
  store ptr %v4453, ptr %v5713, align 8, !tbaa !3
  %v5714 = getelementptr i8, ptr %v5710, i64 32
  store ptr %v4455, ptr %v5714, align 8, !tbaa !3
  %v5715 = getelementptr i8, ptr %v5710, i64 40
  store ptr %v4457, ptr %v5715, align 8, !tbaa !3
  %v5716 = getelementptr i8, ptr %v5710, i64 48
  store ptr %v4459, ptr %v5716, align 8, !tbaa !3
  %v5717 = getelementptr i8, ptr %v5710, i64 56
  store ptr %arg, ptr %v5717, align 8, !tbaa !3
  %v5718 = call ptr @mlf_closure(ptr @mlf.code.4483, ptr %v5710)
  %v5719 = call ptr @mlf_prim2(i64 1, ptr %v4478, ptr %v5718)
  ret ptr %v5719
}

define private ptr @mlf.code.4413(ptr %env, ptr %arg) {
entry:
  %v4414 = getelementptr i8, ptr %env, i64 8
  %v4415 = load ptr, ptr %v4414, align 8, !tbaa !3
  %v4416 = getelementptr i8, ptr %env, i64 16
  %v4417 = load ptr, ptr %v4416, align 8, !tbaa !3
  %v4418 = getelementptr i8, ptr %env, i64 24
  %v4419 = load ptr, ptr %v4418, align 8, !tbaa !3
  %v4420 = getelementptr i8, ptr %env, i64 32
  %v4421 = load ptr, ptr %v4420, align 8, !tbaa !3
  %v4422 = getelementptr i8, ptr %env, i64 40
  %v4423 = load ptr, ptr %v4422, align 8, !tbaa !3
  %v4442 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4424, i64 2)
  %v4443 = getelementptr i8, ptr %v4442, i64 16
  %v4444 = load ptr, ptr %v4443, align 8, !tbaa !3
  %v4445 = getelementptr i8, ptr %v4444, i64 8
  store ptr %v4415, ptr %v4445, align 8, !tbaa !3
  %v4446 = getelementptr i8, ptr %v4444, i64 16
  store ptr %v4417, ptr %v4446, align 8, !tbaa !3
  %v5720 = call ptr @mlf_env_new(i64 6)
  %v5721 = getelementptr i8, ptr %v5720, i64 8
  store ptr %v4415, ptr %v5721, align 8, !tbaa !3
  %v5722 = getelementptr i8, ptr %v5720, i64 16
  store ptr %v4417, ptr %v5722, align 8, !tbaa !3
  %v5723 = getelementptr i8, ptr %v5720, i64 24
  store ptr %v4419, ptr %v5723, align 8, !tbaa !3
  %v5724 = getelementptr i8, ptr %v5720, i64 32
  store ptr %v4421, ptr %v5724, align 8, !tbaa !3
  %v5725 = getelementptr i8, ptr %v5720, i64 40
  store ptr %v4423, ptr %v5725, align 8, !tbaa !3
  %v5726 = getelementptr i8, ptr %v5720, i64 48
  store ptr %arg, ptr %v5726, align 8, !tbaa !3
  %v5727 = call ptr @mlf_closure(ptr @mlf.code.4447, ptr %v5720)
  %v5728 = call ptr @mlf_prim2(i64 1, ptr %v4442, ptr %v5727)
  ret ptr %v5728
}

define private ptr @mlf.code.4381(ptr %env, ptr %arg) {
entry:
  %v4382 = getelementptr i8, ptr %env, i64 8
  %v4383 = load ptr, ptr %v4382, align 8, !tbaa !3
  %v4384 = getelementptr i8, ptr %env, i64 16
  %v4385 = load ptr, ptr %v4384, align 8, !tbaa !3
  %v4386 = getelementptr i8, ptr %env, i64 24
  %v4387 = load ptr, ptr %v4386, align 8, !tbaa !3
  %v4388 = getelementptr i8, ptr %env, i64 32
  %v4389 = load ptr, ptr %v4388, align 8, !tbaa !3
  %v4408 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4390, i64 2)
  %v4409 = getelementptr i8, ptr %v4408, i64 16
  %v4410 = load ptr, ptr %v4409, align 8, !tbaa !3
  %v4411 = getelementptr i8, ptr %v4410, i64 8
  store ptr %v4383, ptr %v4411, align 8, !tbaa !3
  %v4412 = getelementptr i8, ptr %v4410, i64 16
  store ptr %v4385, ptr %v4412, align 8, !tbaa !3
  %v5729 = call ptr @mlf_env_new(i64 5)
  %v5730 = getelementptr i8, ptr %v5729, i64 8
  store ptr %v4383, ptr %v5730, align 8, !tbaa !3
  %v5731 = getelementptr i8, ptr %v5729, i64 16
  store ptr %v4385, ptr %v5731, align 8, !tbaa !3
  %v5732 = getelementptr i8, ptr %v5729, i64 24
  store ptr %v4387, ptr %v5732, align 8, !tbaa !3
  %v5733 = getelementptr i8, ptr %v5729, i64 32
  store ptr %v4389, ptr %v5733, align 8, !tbaa !3
  %v5734 = getelementptr i8, ptr %v5729, i64 40
  store ptr %arg, ptr %v5734, align 8, !tbaa !3
  %v5735 = call ptr @mlf_closure(ptr @mlf.code.4413, ptr %v5729)
  %v5736 = call ptr @mlf_prim2(i64 1, ptr %v4408, ptr %v5735)
  ret ptr %v5736
}

define private ptr @mlf.code.4351(ptr %env, ptr %arg) {
entry:
  %v4352 = getelementptr i8, ptr %env, i64 8
  %v4353 = load ptr, ptr %v4352, align 8, !tbaa !3
  %v4354 = getelementptr i8, ptr %env, i64 16
  %v4355 = load ptr, ptr %v4354, align 8, !tbaa !3
  %v4356 = getelementptr i8, ptr %env, i64 24
  %v4357 = load ptr, ptr %v4356, align 8, !tbaa !3
  %v4376 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4358, i64 2)
  %v4377 = getelementptr i8, ptr %v4376, i64 16
  %v4378 = load ptr, ptr %v4377, align 8, !tbaa !3
  %v4379 = getelementptr i8, ptr %v4378, i64 8
  store ptr %v4353, ptr %v4379, align 8, !tbaa !3
  %v4380 = getelementptr i8, ptr %v4378, i64 16
  store ptr %v4355, ptr %v4380, align 8, !tbaa !3
  %v5737 = call ptr @mlf_env_new(i64 4)
  %v5738 = getelementptr i8, ptr %v5737, i64 8
  store ptr %v4353, ptr %v5738, align 8, !tbaa !3
  %v5739 = getelementptr i8, ptr %v5737, i64 16
  store ptr %v4355, ptr %v5739, align 8, !tbaa !3
  %v5740 = getelementptr i8, ptr %v5737, i64 24
  store ptr %v4357, ptr %v5740, align 8, !tbaa !3
  %v5741 = getelementptr i8, ptr %v5737, i64 32
  store ptr %arg, ptr %v5741, align 8, !tbaa !3
  %v5742 = call ptr @mlf_closure(ptr @mlf.code.4381, ptr %v5737)
  %v5743 = call ptr @mlf_prim2(i64 1, ptr %v4376, ptr %v5742)
  ret ptr %v5743
}

define private ptr @mlf.worker.42(ptr %a0, ptr %a1, ptr %a2) {
entry:
  %v4322 = call ptr @mlf_prim2(i64 10, ptr %a2, ptr inttoptr (i64 71 to ptr))
  %v4323 = icmp eq ptr %v4322, inttoptr (i64 6 to ptr)
  br i1 %v4323, label %yes.4324, label %no.4325
yes.4324:
  %v4327 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.4326
no.4325:
  %v4346 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4328, i64 2)
  %v4347 = getelementptr i8, ptr %v4346, i64 16
  %v4348 = load ptr, ptr %v4347, align 8, !tbaa !3
  %v4349 = getelementptr i8, ptr %v4348, i64 8
  store ptr %a0, ptr %v4349, align 8, !tbaa !3
  %v4350 = getelementptr i8, ptr %v4348, i64 16
  store ptr %a1, ptr %v4350, align 8, !tbaa !3
  %v5744 = call ptr @mlf_env_new(i64 3)
  %v5745 = getelementptr i8, ptr %v5744, i64 8
  store ptr %a0, ptr %v5745, align 8, !tbaa !3
  %v5746 = getelementptr i8, ptr %v5744, i64 16
  store ptr %a1, ptr %v5746, align 8, !tbaa !3
  %v5747 = getelementptr i8, ptr %v5744, i64 24
  store ptr %a2, ptr %v5747, align 8, !tbaa !3
  %v5748 = call ptr @mlf_closure(ptr @mlf.code.4351, ptr %v5744)
  %v5749 = call ptr @mlf_prim2(i64 1, ptr %v4346, ptr %v5748)
  br label %join.4326
join.4326:
  %v5750 = phi ptr [ %v4327, %yes.4324 ], [ %v5749, %no.4325 ]
  ret ptr %v5750
}

define private ptr @mlf.numeric.entry.4301(ptr %env, ptr %arg) {
entry:
  %v4302 = getelementptr i8, ptr %env, i64 8
  %v4303 = load ptr, ptr %v4302, align 8, !tbaa !3
  %v4304 = getelementptr i8, ptr %env, i64 16
  %v4305 = load ptr, ptr %v4304, align 8, !tbaa !3
  %v4306 = getelementptr i8, ptr %env, i64 24
  %v4307 = load ptr, ptr %v4306, align 8, !tbaa !3
  %v4308 = call ptr @mlf_peek(ptr %v4303)
  %v4309 = call ptr @mlf_peek(ptr %v4305)
  %v4310 = call ptr @mlf_peek(ptr %v4307)
  %v4311 = icmp ne ptr %v4308, null
  %v4312 = icmp ne ptr %v4309, null
  %v4313 = icmp ne ptr %v4310, null
  %v4314 = and i1 true, %v4311
  %v4315 = and i1 %v4314, %v4312
  %v4316 = and i1 %v4315, %v4313
  br i1 %v4316, label %yes.4317, label %no.4318
yes.4317:
  %v4320 = call ptr @mlf.numeric.42(ptr %v4308, ptr %v4309, ptr %v4310)
  %v4321 = call ptr @mlf_prim1(i64 0, ptr %v4320)
  br label %join.4319
no.4318:
  %v5751 = call ptr @mlf.force(ptr %v4307)
  %v5752 = call ptr @mlf.worker.42(ptr %v4303, ptr %v4305, ptr %v5751)
  br label %join.4319
join.4319:
  %v5753 = phi ptr [ %v4321, %yes.4317 ], [ %v5752, %no.4318 ]
  ret ptr %v5753
}

define private ptr @mlf.code.4294(ptr %env, ptr %arg) {
entry:
  %v4295 = getelementptr i8, ptr %env, i64 8
  %v4296 = load ptr, ptr %v4295, align 8, !tbaa !3
  %v4297 = getelementptr i8, ptr %env, i64 16
  %v4298 = load ptr, ptr %v4297, align 8, !tbaa !3
  %v4299 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4299, align 8, !tbaa !3
  %v4300 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v4300, align 8, !tbaa !3
  %v5754 = call ptr @mlf.force(ptr %v4298)
  %v5755 = call ptr @mlf_prim2(i64 8, ptr %v5754, ptr inttoptr (i64 15 to ptr))
  %v5756 = call ptr @mlf_env_new(i64 3)
  %v5757 = getelementptr i8, ptr %v5756, i64 8
  store ptr %v4296, ptr %v5757, align 8, !tbaa !3
  %v5758 = getelementptr i8, ptr %v5756, i64 16
  store ptr %v4298, ptr %v5758, align 8, !tbaa !3
  %v5759 = getelementptr i8, ptr %v5756, i64 24
  store ptr %v5755, ptr %v5759, align 8, !tbaa !3
  %v5760 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.4301, ptr %v5756)
  ret ptr %v5760
}

define private ptr @mlf.code.5766(ptr %env, ptr %arg) {
entry:
  %v5767 = getelementptr i8, ptr %env, i64 8
  %v5768 = load ptr, ptr %v5767, align 8, !tbaa !3
  %v5769 = getelementptr i8, ptr %env, i64 16
  %v5770 = load ptr, ptr %v5769, align 8, !tbaa !3
  %v5771 = call ptr @mlf.force(ptr %v5770)
  %v5772 = call ptr @mlf_prim2(i64 8, ptr %v5771, ptr inttoptr (i64 15 to ptr))
  %v5773 = call ptr @mlf_env_new(i64 2)
  %v5774 = getelementptr i8, ptr %v5773, i64 8
  store ptr %v5768, ptr %v5774, align 8, !tbaa !3
  %v5775 = getelementptr i8, ptr %v5773, i64 16
  store ptr %v5772, ptr %v5775, align 8, !tbaa !3
  %v5776 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.4272, ptr %v5773)
  ret ptr %v5776
}

define private ptr @mlf.worker.77(ptr %a0, ptr %a1) {
entry:
  %v4288 = call ptr @mlf_prim2(i64 10, ptr %a1, ptr inttoptr (i64 71 to ptr))
  %v4289 = icmp eq ptr %v4288, inttoptr (i64 6 to ptr)
  br i1 %v4289, label %yes.4290, label %no.4291
yes.4290:
  %v4293 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.4292
no.4291:
  %v5761 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4294, i64 2)
  %v5762 = getelementptr i8, ptr %v5761, i64 16
  %v5763 = load ptr, ptr %v5762, align 8, !tbaa !3
  %v5764 = getelementptr i8, ptr %v5763, i64 8
  store ptr %a0, ptr %v5764, align 8, !tbaa !3
  %v5765 = getelementptr i8, ptr %v5763, i64 16
  store ptr %a1, ptr %v5765, align 8, !tbaa !3
  %v5777 = call ptr @mlf_env_new(i64 2)
  %v5778 = getelementptr i8, ptr %v5777, i64 8
  store ptr %a0, ptr %v5778, align 8, !tbaa !3
  %v5779 = getelementptr i8, ptr %v5777, i64 16
  store ptr %a1, ptr %v5779, align 8, !tbaa !3
  %v5780 = call ptr @mlf_closure(ptr @mlf.code.5766, ptr %v5777)
  %v5781 = call ptr @mlf_prim2(i64 1, ptr %v5761, ptr %v5780)
  br label %join.4292
join.4292:
  %v5782 = phi ptr [ %v4293, %yes.4290 ], [ %v5781, %no.4291 ]
  ret ptr %v5782
}

define private ptr @mlf.numeric.entry.4272(ptr %env, ptr %arg) {
entry:
  %v4273 = getelementptr i8, ptr %env, i64 8
  %v4274 = load ptr, ptr %v4273, align 8, !tbaa !3
  %v4275 = getelementptr i8, ptr %env, i64 16
  %v4276 = load ptr, ptr %v4275, align 8, !tbaa !3
  %v4277 = call ptr @mlf_peek(ptr %v4274)
  %v4278 = call ptr @mlf_peek(ptr %v4276)
  %v4279 = icmp ne ptr %v4277, null
  %v4280 = icmp ne ptr %v4278, null
  %v4281 = and i1 true, %v4279
  %v4282 = and i1 %v4281, %v4280
  br i1 %v4282, label %yes.4283, label %no.4284
yes.4283:
  %v4286 = call ptr @mlf.numeric.77(ptr %v4277, ptr %v4278)
  %v4287 = call ptr @mlf_prim1(i64 0, ptr %v4286)
  br label %join.4285
no.4284:
  %v5783 = call ptr @mlf.force(ptr %v4276)
  %v5784 = call ptr @mlf.worker.77(ptr %v4274, ptr %v5783)
  br label %join.4285
join.4285:
  %v5785 = phi ptr [ %v4287, %yes.4283 ], [ %v5784, %no.4284 ]
  ret ptr %v5785
}

define private ptr @mlf.code.4268(ptr %env, ptr %arg) {
entry:
  %v4269 = getelementptr i8, ptr %env, i64 8
  %v4270 = load ptr, ptr %v4269, align 8, !tbaa !3
  %v4271 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v4271, align 8, !tbaa !3
  %v5786 = call ptr @mlf_env_new(i64 2)
  %v5787 = getelementptr i8, ptr %v5786, i64 8
  store ptr %v4270, ptr %v5787, align 8, !tbaa !3
  %v5788 = getelementptr i8, ptr %v5786, i64 16
  store ptr inttoptr (i64 1 to ptr), ptr %v5788, align 8, !tbaa !3
  %v5789 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.4272, ptr %v5786)
  ret ptr %v5789
}

define private ptr @mlf.code.5832(ptr %env, ptr %arg) {
entry:
  %v5833 = getelementptr i8, ptr %env, i64 8
  %v5834 = load ptr, ptr %v5833, align 8, !tbaa !3
  %v5835 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v5835, align 8, !tbaa !3
  %v5836 = call ptr @mlf.force(ptr %v5834)
  %v5837 = call ptr @mlf_prim2(i64 8, ptr %v5836, ptr inttoptr (i64 1 to ptr))
  ret ptr %v5837
}

define private ptr @mlf.code.5825(ptr %env, ptr %arg) {
entry:
  %v5826 = getelementptr i8, ptr %env, i64 8
  %v5827 = load ptr, ptr %v5826, align 8, !tbaa !3
  %v5828 = getelementptr i8, ptr %env, i64 16
  %v5829 = load ptr, ptr %v5828, align 8, !tbaa !3
  %v5830 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v5830, align 8, !tbaa !3
  %v5831 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v5831, align 8, !tbaa !3
  %v5838 = call ptr @mlf.allocate.thunk(ptr @mlf.code.5832, i64 1)
  %v5839 = getelementptr i8, ptr %v5838, i64 16
  %v5840 = load ptr, ptr %v5839, align 8, !tbaa !3
  %v5841 = getelementptr i8, ptr %v5840, i64 8
  store ptr %v5829, ptr %v5841, align 8, !tbaa !3
  %v5842 = call ptr @mlf_prim2(i64 32, ptr %v5827, ptr %v5838)
  ret ptr %v5842
}

define private ptr @mlf.code.5860(ptr %env, ptr %arg) {
entry:
  %v5861 = getelementptr i8, ptr %env, i64 8
  %v5862 = load ptr, ptr %v5861, align 8, !tbaa !3
  %v5863 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v5863, align 8, !tbaa !3
  %v5864 = call ptr @mlf.force(ptr %v5862)
  %v5865 = call ptr @mlf_prim2(i64 8, ptr %v5864, ptr inttoptr (i64 3 to ptr))
  ret ptr %v5865
}

define private ptr @mlf.code.5853(ptr %env, ptr %arg) {
entry:
  %v5854 = getelementptr i8, ptr %env, i64 8
  %v5855 = load ptr, ptr %v5854, align 8, !tbaa !3
  %v5856 = getelementptr i8, ptr %env, i64 16
  %v5857 = load ptr, ptr %v5856, align 8, !tbaa !3
  %v5858 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v5858, align 8, !tbaa !3
  %v5859 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v5859, align 8, !tbaa !3
  %v5866 = call ptr @mlf.allocate.thunk(ptr @mlf.code.5860, i64 1)
  %v5867 = getelementptr i8, ptr %v5866, i64 16
  %v5868 = load ptr, ptr %v5867, align 8, !tbaa !3
  %v5869 = getelementptr i8, ptr %v5868, i64 8
  store ptr %v5857, ptr %v5869, align 8, !tbaa !3
  %v5870 = call ptr @mlf_prim2(i64 32, ptr %v5855, ptr %v5866)
  ret ptr %v5870
}

define private ptr @mlf.code.5890(ptr %env, ptr %arg) {
entry:
  %v5891 = getelementptr i8, ptr %env, i64 8
  %v5892 = load ptr, ptr %v5891, align 8, !tbaa !3
  %v5893 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v5893, align 8, !tbaa !3
  %v5894 = call ptr @mlf.force(ptr %v5892)
  %v5895 = call ptr @mlf_prim2(i64 8, ptr %v5894, ptr inttoptr (i64 5 to ptr))
  ret ptr %v5895
}

define private ptr @mlf.code.5883(ptr %env, ptr %arg) {
entry:
  %v5884 = getelementptr i8, ptr %env, i64 8
  %v5885 = load ptr, ptr %v5884, align 8, !tbaa !3
  %v5886 = getelementptr i8, ptr %env, i64 16
  %v5887 = load ptr, ptr %v5886, align 8, !tbaa !3
  %v5888 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v5888, align 8, !tbaa !3
  %v5889 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v5889, align 8, !tbaa !3
  %v5896 = call ptr @mlf.allocate.thunk(ptr @mlf.code.5890, i64 1)
  %v5897 = getelementptr i8, ptr %v5896, i64 16
  %v5898 = load ptr, ptr %v5897, align 8, !tbaa !3
  %v5899 = getelementptr i8, ptr %v5898, i64 8
  store ptr %v5887, ptr %v5899, align 8, !tbaa !3
  %v5900 = call ptr @mlf_prim2(i64 32, ptr %v5885, ptr %v5896)
  ret ptr %v5900
}

define private ptr @mlf.code.5922(ptr %env, ptr %arg) {
entry:
  %v5923 = getelementptr i8, ptr %env, i64 8
  %v5924 = load ptr, ptr %v5923, align 8, !tbaa !3
  %v5925 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v5925, align 8, !tbaa !3
  %v5926 = call ptr @mlf.force(ptr %v5924)
  %v5927 = call ptr @mlf_prim2(i64 8, ptr %v5926, ptr inttoptr (i64 7 to ptr))
  ret ptr %v5927
}

define private ptr @mlf.code.5915(ptr %env, ptr %arg) {
entry:
  %v5916 = getelementptr i8, ptr %env, i64 8
  %v5917 = load ptr, ptr %v5916, align 8, !tbaa !3
  %v5918 = getelementptr i8, ptr %env, i64 16
  %v5919 = load ptr, ptr %v5918, align 8, !tbaa !3
  %v5920 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v5920, align 8, !tbaa !3
  %v5921 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v5921, align 8, !tbaa !3
  %v5928 = call ptr @mlf.allocate.thunk(ptr @mlf.code.5922, i64 1)
  %v5929 = getelementptr i8, ptr %v5928, i64 16
  %v5930 = load ptr, ptr %v5929, align 8, !tbaa !3
  %v5931 = getelementptr i8, ptr %v5930, i64 8
  store ptr %v5919, ptr %v5931, align 8, !tbaa !3
  %v5932 = call ptr @mlf_prim2(i64 32, ptr %v5917, ptr %v5928)
  ret ptr %v5932
}

define private ptr @mlf.code.5956(ptr %env, ptr %arg) {
entry:
  %v5957 = getelementptr i8, ptr %env, i64 8
  %v5958 = load ptr, ptr %v5957, align 8, !tbaa !3
  %v5959 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v5959, align 8, !tbaa !3
  %v5960 = call ptr @mlf.force(ptr %v5958)
  %v5961 = call ptr @mlf_prim2(i64 8, ptr %v5960, ptr inttoptr (i64 9 to ptr))
  ret ptr %v5961
}

define private ptr @mlf.code.5949(ptr %env, ptr %arg) {
entry:
  %v5950 = getelementptr i8, ptr %env, i64 8
  %v5951 = load ptr, ptr %v5950, align 8, !tbaa !3
  %v5952 = getelementptr i8, ptr %env, i64 16
  %v5953 = load ptr, ptr %v5952, align 8, !tbaa !3
  %v5954 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v5954, align 8, !tbaa !3
  %v5955 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v5955, align 8, !tbaa !3
  %v5962 = call ptr @mlf.allocate.thunk(ptr @mlf.code.5956, i64 1)
  %v5963 = getelementptr i8, ptr %v5962, i64 16
  %v5964 = load ptr, ptr %v5963, align 8, !tbaa !3
  %v5965 = getelementptr i8, ptr %v5964, i64 8
  store ptr %v5953, ptr %v5965, align 8, !tbaa !3
  %v5966 = call ptr @mlf_prim2(i64 32, ptr %v5951, ptr %v5962)
  ret ptr %v5966
}

define private ptr @mlf.code.5992(ptr %env, ptr %arg) {
entry:
  %v5993 = getelementptr i8, ptr %env, i64 8
  %v5994 = load ptr, ptr %v5993, align 8, !tbaa !3
  %v5995 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v5995, align 8, !tbaa !3
  %v5996 = call ptr @mlf.force(ptr %v5994)
  %v5997 = call ptr @mlf_prim2(i64 8, ptr %v5996, ptr inttoptr (i64 11 to ptr))
  ret ptr %v5997
}

define private ptr @mlf.code.5985(ptr %env, ptr %arg) {
entry:
  %v5986 = getelementptr i8, ptr %env, i64 8
  %v5987 = load ptr, ptr %v5986, align 8, !tbaa !3
  %v5988 = getelementptr i8, ptr %env, i64 16
  %v5989 = load ptr, ptr %v5988, align 8, !tbaa !3
  %v5990 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v5990, align 8, !tbaa !3
  %v5991 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v5991, align 8, !tbaa !3
  %v5998 = call ptr @mlf.allocate.thunk(ptr @mlf.code.5992, i64 1)
  %v5999 = getelementptr i8, ptr %v5998, i64 16
  %v6000 = load ptr, ptr %v5999, align 8, !tbaa !3
  %v6001 = getelementptr i8, ptr %v6000, i64 8
  store ptr %v5989, ptr %v6001, align 8, !tbaa !3
  %v6002 = call ptr @mlf_prim2(i64 32, ptr %v5987, ptr %v5998)
  ret ptr %v6002
}

define private ptr @mlf.code.6036(ptr %env, ptr %arg) {
entry:
  %v6037 = getelementptr i8, ptr %env, i64 8
  %v6038 = load ptr, ptr %v6037, align 8, !tbaa !3
  %v6039 = getelementptr i8, ptr %env, i64 16
  %v6040 = load ptr, ptr %v6039, align 8, !tbaa !3
  %v6041 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v6041, align 8, !tbaa !3
  %v6042 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v6042, align 8, !tbaa !3
  %v6043 = call ptr @mlf.force(ptr %v6038)
  %v6044 = call ptr @mlf_double(double 0x3f847ae147ae147b)
  %v6045 = call ptr @mlf.force(ptr %v6040)
  %v6046 = call ptr @mlf_prim2(i64 20, ptr %v6044, ptr %v6045)
  %v6047 = call ptr @mlf_prim2(i64 18, ptr %v6043, ptr %v6046)
  ret ptr %v6047
}

define private ptr @mlf.code.6053(ptr %env, ptr %arg) {
entry:
  %v6054 = getelementptr i8, ptr %env, i64 8
  %v6055 = load ptr, ptr %v6054, align 8, !tbaa !3
  %v6056 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v6056, align 8, !tbaa !3
  %v6057 = call ptr @mlf.force(ptr %v6055)
  %v6058 = call ptr @mlf_prim2(i64 8, ptr %v6057, ptr inttoptr (i64 1 to ptr))
  ret ptr %v6058
}

define private ptr @mlf.code.6023(ptr %env, ptr %arg) {
entry:
  %v6024 = getelementptr i8, ptr %env, i64 8
  %v6025 = load ptr, ptr %v6024, align 8, !tbaa !3
  %v6026 = getelementptr i8, ptr %env, i64 16
  %v6027 = load ptr, ptr %v6026, align 8, !tbaa !3
  %v6028 = getelementptr i8, ptr %env, i64 24
  %v6029 = load ptr, ptr %v6028, align 8, !tbaa !3
  %v6030 = getelementptr i8, ptr %env, i64 32
  %v6031 = load ptr, ptr %v6030, align 8, !tbaa !3
  %v6032 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v6032, align 8, !tbaa !3
  %v6033 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v6033, align 8, !tbaa !3
  %v6034 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v6034, align 8, !tbaa !3
  %v6035 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v6035, align 8, !tbaa !3
  %v6048 = call ptr @mlf.allocate.thunk(ptr @mlf.code.6036, i64 2)
  %v6049 = getelementptr i8, ptr %v6048, i64 16
  %v6050 = load ptr, ptr %v6049, align 8, !tbaa !3
  %v6051 = getelementptr i8, ptr %v6050, i64 8
  store ptr %v6029, ptr %v6051, align 8, !tbaa !3
  %v6052 = getelementptr i8, ptr %v6050, i64 16
  store ptr %v6031, ptr %v6052, align 8, !tbaa !3
  %v6059 = call ptr @mlf.allocate.thunk(ptr @mlf.code.6053, i64 1)
  %v6060 = getelementptr i8, ptr %v6059, i64 16
  %v6061 = load ptr, ptr %v6060, align 8, !tbaa !3
  %v6062 = getelementptr i8, ptr %v6061, i64 8
  store ptr %v6027, ptr %v6062, align 8, !tbaa !3
  %v6063 = call ptr @mlf_prim3(i64 33, ptr %v6025, ptr %v6059, ptr %v6048)
  ret ptr %v6063
}

define private ptr @mlf.code.6097(ptr %env, ptr %arg) {
entry:
  %v6098 = getelementptr i8, ptr %env, i64 8
  %v6099 = load ptr, ptr %v6098, align 8, !tbaa !3
  %v6100 = getelementptr i8, ptr %env, i64 16
  %v6101 = load ptr, ptr %v6100, align 8, !tbaa !3
  %v6102 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v6102, align 8, !tbaa !3
  %v6103 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v6103, align 8, !tbaa !3
  %v6104 = call ptr @mlf.force(ptr %v6099)
  %v6105 = call ptr @mlf_double(double 0x3f847ae147ae147b)
  %v6106 = call ptr @mlf.force(ptr %v6101)
  %v6107 = call ptr @mlf_prim2(i64 20, ptr %v6105, ptr %v6106)
  %v6108 = call ptr @mlf_prim2(i64 18, ptr %v6104, ptr %v6107)
  ret ptr %v6108
}

define private ptr @mlf.code.6114(ptr %env, ptr %arg) {
entry:
  %v6115 = getelementptr i8, ptr %env, i64 8
  %v6116 = load ptr, ptr %v6115, align 8, !tbaa !3
  %v6117 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v6117, align 8, !tbaa !3
  %v6118 = call ptr @mlf.force(ptr %v6116)
  %v6119 = call ptr @mlf_prim2(i64 8, ptr %v6118, ptr inttoptr (i64 3 to ptr))
  ret ptr %v6119
}

define private ptr @mlf.code.6084(ptr %env, ptr %arg) {
entry:
  %v6085 = getelementptr i8, ptr %env, i64 8
  %v6086 = load ptr, ptr %v6085, align 8, !tbaa !3
  %v6087 = getelementptr i8, ptr %env, i64 16
  %v6088 = load ptr, ptr %v6087, align 8, !tbaa !3
  %v6089 = getelementptr i8, ptr %env, i64 24
  %v6090 = load ptr, ptr %v6089, align 8, !tbaa !3
  %v6091 = getelementptr i8, ptr %env, i64 32
  %v6092 = load ptr, ptr %v6091, align 8, !tbaa !3
  %v6093 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v6093, align 8, !tbaa !3
  %v6094 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v6094, align 8, !tbaa !3
  %v6095 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v6095, align 8, !tbaa !3
  %v6096 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v6096, align 8, !tbaa !3
  %v6109 = call ptr @mlf.allocate.thunk(ptr @mlf.code.6097, i64 2)
  %v6110 = getelementptr i8, ptr %v6109, i64 16
  %v6111 = load ptr, ptr %v6110, align 8, !tbaa !3
  %v6112 = getelementptr i8, ptr %v6111, i64 8
  store ptr %v6090, ptr %v6112, align 8, !tbaa !3
  %v6113 = getelementptr i8, ptr %v6111, i64 16
  store ptr %v6092, ptr %v6113, align 8, !tbaa !3
  %v6120 = call ptr @mlf.allocate.thunk(ptr @mlf.code.6114, i64 1)
  %v6121 = getelementptr i8, ptr %v6120, i64 16
  %v6122 = load ptr, ptr %v6121, align 8, !tbaa !3
  %v6123 = getelementptr i8, ptr %v6122, i64 8
  store ptr %v6088, ptr %v6123, align 8, !tbaa !3
  %v6124 = call ptr @mlf_prim3(i64 33, ptr %v6086, ptr %v6120, ptr %v6109)
  ret ptr %v6124
}

define private ptr @mlf.code.6154(ptr %env, ptr %arg) {
entry:
  %v6155 = getelementptr i8, ptr %env, i64 8
  %v6156 = load ptr, ptr %v6155, align 8, !tbaa !3
  %v6157 = getelementptr i8, ptr %env, i64 16
  %v6158 = load ptr, ptr %v6157, align 8, !tbaa !3
  %v6159 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v6159, align 8, !tbaa !3
  %v6160 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v6160, align 8, !tbaa !3
  %v6161 = call ptr @mlf.force(ptr %v6156)
  %v6162 = call ptr @mlf_double(double 0x3f847ae147ae147b)
  %v6163 = call ptr @mlf.force(ptr %v6158)
  %v6164 = call ptr @mlf_prim2(i64 20, ptr %v6162, ptr %v6163)
  %v6165 = call ptr @mlf_prim2(i64 18, ptr %v6161, ptr %v6164)
  ret ptr %v6165
}

define private ptr @mlf.code.6171(ptr %env, ptr %arg) {
entry:
  %v6172 = getelementptr i8, ptr %env, i64 8
  %v6173 = load ptr, ptr %v6172, align 8, !tbaa !3
  %v6174 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v6174, align 8, !tbaa !3
  %v6175 = call ptr @mlf.force(ptr %v6173)
  %v6176 = call ptr @mlf_prim2(i64 8, ptr %v6175, ptr inttoptr (i64 5 to ptr))
  ret ptr %v6176
}

define private ptr @mlf.code.6141(ptr %env, ptr %arg) {
entry:
  %v6142 = getelementptr i8, ptr %env, i64 8
  %v6143 = load ptr, ptr %v6142, align 8, !tbaa !3
  %v6144 = getelementptr i8, ptr %env, i64 16
  %v6145 = load ptr, ptr %v6144, align 8, !tbaa !3
  %v6146 = getelementptr i8, ptr %env, i64 24
  %v6147 = load ptr, ptr %v6146, align 8, !tbaa !3
  %v6148 = getelementptr i8, ptr %env, i64 32
  %v6149 = load ptr, ptr %v6148, align 8, !tbaa !3
  %v6150 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v6150, align 8, !tbaa !3
  %v6151 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v6151, align 8, !tbaa !3
  %v6152 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v6152, align 8, !tbaa !3
  %v6153 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v6153, align 8, !tbaa !3
  %v6166 = call ptr @mlf.allocate.thunk(ptr @mlf.code.6154, i64 2)
  %v6167 = getelementptr i8, ptr %v6166, i64 16
  %v6168 = load ptr, ptr %v6167, align 8, !tbaa !3
  %v6169 = getelementptr i8, ptr %v6168, i64 8
  store ptr %v6147, ptr %v6169, align 8, !tbaa !3
  %v6170 = getelementptr i8, ptr %v6168, i64 16
  store ptr %v6149, ptr %v6170, align 8, !tbaa !3
  %v6177 = call ptr @mlf.allocate.thunk(ptr @mlf.code.6171, i64 1)
  %v6178 = getelementptr i8, ptr %v6177, i64 16
  %v6179 = load ptr, ptr %v6178, align 8, !tbaa !3
  %v6180 = getelementptr i8, ptr %v6179, i64 8
  store ptr %v6145, ptr %v6180, align 8, !tbaa !3
  %v6181 = call ptr @mlf_prim3(i64 33, ptr %v6143, ptr %v6177, ptr %v6166)
  ret ptr %v6181
}

define private ptr @mlf.code.6189(ptr %env, ptr %arg) {
entry:
  %v6190 = getelementptr i8, ptr %env, i64 8
  %v6191 = load ptr, ptr %v6190, align 8, !tbaa !3
  %v6192 = getelementptr i8, ptr %env, i64 16
  %v6193 = load ptr, ptr %v6192, align 8, !tbaa !3
  %v6194 = call ptr @mlf.force(ptr %v6193)
  %v6195 = call ptr @mlf_prim2(i64 8, ptr %v6194, ptr inttoptr (i64 15 to ptr))
  %v6196 = call ptr @mlf_env_new(i64 2)
  %v6197 = getelementptr i8, ptr %v6196, i64 8
  store ptr %v6191, ptr %v6197, align 8, !tbaa !3
  %v6198 = getelementptr i8, ptr %v6196, i64 16
  store ptr %v6195, ptr %v6198, align 8, !tbaa !3
  %v6199 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.5803, ptr %v6196)
  ret ptr %v6199
}

define private ptr @mlf.code.6132(ptr %env, ptr %arg) {
entry:
  %v6133 = getelementptr i8, ptr %env, i64 8
  %v6134 = load ptr, ptr %v6133, align 8, !tbaa !3
  %v6135 = getelementptr i8, ptr %env, i64 16
  %v6136 = load ptr, ptr %v6135, align 8, !tbaa !3
  %v6137 = getelementptr i8, ptr %env, i64 24
  %v6138 = load ptr, ptr %v6137, align 8, !tbaa !3
  %v6139 = getelementptr i8, ptr %env, i64 32
  %v6140 = load ptr, ptr %v6139, align 8, !tbaa !3
  %v6182 = call ptr @mlf.allocate.thunk(ptr @mlf.code.6141, i64 4)
  %v6183 = getelementptr i8, ptr %v6182, i64 16
  %v6184 = load ptr, ptr %v6183, align 8, !tbaa !3
  %v6185 = getelementptr i8, ptr %v6184, i64 8
  store ptr %v6134, ptr %v6185, align 8, !tbaa !3
  %v6186 = getelementptr i8, ptr %v6184, i64 16
  store ptr %v6136, ptr %v6186, align 8, !tbaa !3
  %v6187 = getelementptr i8, ptr %v6184, i64 24
  store ptr %v6138, ptr %v6187, align 8, !tbaa !3
  %v6188 = getelementptr i8, ptr %v6184, i64 32
  store ptr %v6140, ptr %v6188, align 8, !tbaa !3
  %v6200 = call ptr @mlf_env_new(i64 2)
  %v6201 = getelementptr i8, ptr %v6200, i64 8
  store ptr %v6134, ptr %v6201, align 8, !tbaa !3
  %v6202 = getelementptr i8, ptr %v6200, i64 16
  store ptr %v6136, ptr %v6202, align 8, !tbaa !3
  %v6203 = call ptr @mlf_closure(ptr @mlf.code.6189, ptr %v6200)
  %v6204 = call ptr @mlf_prim2(i64 1, ptr %v6182, ptr %v6203)
  ret ptr %v6204
}

define private ptr @mlf.code.6071(ptr %env, ptr %arg) {
entry:
  %v6072 = getelementptr i8, ptr %env, i64 8
  %v6073 = load ptr, ptr %v6072, align 8, !tbaa !3
  %v6074 = getelementptr i8, ptr %env, i64 16
  %v6075 = load ptr, ptr %v6074, align 8, !tbaa !3
  %v6076 = getelementptr i8, ptr %env, i64 24
  %v6077 = load ptr, ptr %v6076, align 8, !tbaa !3
  %v6078 = getelementptr i8, ptr %env, i64 32
  %v6079 = load ptr, ptr %v6078, align 8, !tbaa !3
  %v6080 = getelementptr i8, ptr %env, i64 40
  %v6081 = load ptr, ptr %v6080, align 8, !tbaa !3
  %v6082 = getelementptr i8, ptr %env, i64 48
  %v6083 = load ptr, ptr %v6082, align 8, !tbaa !3
  %v6125 = call ptr @mlf.allocate.thunk(ptr @mlf.code.6084, i64 4)
  %v6126 = getelementptr i8, ptr %v6125, i64 16
  %v6127 = load ptr, ptr %v6126, align 8, !tbaa !3
  %v6128 = getelementptr i8, ptr %v6127, i64 8
  store ptr %v6073, ptr %v6128, align 8, !tbaa !3
  %v6129 = getelementptr i8, ptr %v6127, i64 16
  store ptr %v6075, ptr %v6129, align 8, !tbaa !3
  %v6130 = getelementptr i8, ptr %v6127, i64 24
  store ptr %v6077, ptr %v6130, align 8, !tbaa !3
  %v6131 = getelementptr i8, ptr %v6127, i64 32
  store ptr %v6081, ptr %v6131, align 8, !tbaa !3
  %v6205 = call ptr @mlf_env_new(i64 4)
  %v6206 = getelementptr i8, ptr %v6205, i64 8
  store ptr %v6073, ptr %v6206, align 8, !tbaa !3
  %v6207 = getelementptr i8, ptr %v6205, i64 16
  store ptr %v6075, ptr %v6207, align 8, !tbaa !3
  %v6208 = getelementptr i8, ptr %v6205, i64 24
  store ptr %v6079, ptr %v6208, align 8, !tbaa !3
  %v6209 = getelementptr i8, ptr %v6205, i64 32
  store ptr %v6083, ptr %v6209, align 8, !tbaa !3
  %v6210 = call ptr @mlf_closure(ptr @mlf.code.6132, ptr %v6205)
  %v6211 = call ptr @mlf_prim2(i64 1, ptr %v6125, ptr %v6210)
  ret ptr %v6211
}

define private ptr @mlf.code.6008(ptr %env, ptr %arg) {
entry:
  %v6009 = getelementptr i8, ptr %env, i64 8
  %v6010 = load ptr, ptr %v6009, align 8, !tbaa !3
  %v6011 = getelementptr i8, ptr %env, i64 16
  %v6012 = load ptr, ptr %v6011, align 8, !tbaa !3
  %v6013 = getelementptr i8, ptr %env, i64 24
  %v6014 = load ptr, ptr %v6013, align 8, !tbaa !3
  %v6015 = getelementptr i8, ptr %env, i64 32
  %v6016 = load ptr, ptr %v6015, align 8, !tbaa !3
  %v6017 = getelementptr i8, ptr %env, i64 40
  %v6018 = load ptr, ptr %v6017, align 8, !tbaa !3
  %v6019 = getelementptr i8, ptr %env, i64 48
  %v6020 = load ptr, ptr %v6019, align 8, !tbaa !3
  %v6021 = getelementptr i8, ptr %env, i64 56
  %v6022 = load ptr, ptr %v6021, align 8, !tbaa !3
  %v6064 = call ptr @mlf.allocate.thunk(ptr @mlf.code.6023, i64 4)
  %v6065 = getelementptr i8, ptr %v6064, i64 16
  %v6066 = load ptr, ptr %v6065, align 8, !tbaa !3
  %v6067 = getelementptr i8, ptr %v6066, i64 8
  store ptr %v6010, ptr %v6067, align 8, !tbaa !3
  %v6068 = getelementptr i8, ptr %v6066, i64 16
  store ptr %v6012, ptr %v6068, align 8, !tbaa !3
  %v6069 = getelementptr i8, ptr %v6066, i64 24
  store ptr %v6014, ptr %v6069, align 8, !tbaa !3
  %v6070 = getelementptr i8, ptr %v6066, i64 32
  store ptr %v6020, ptr %v6070, align 8, !tbaa !3
  %v6212 = call ptr @mlf_env_new(i64 6)
  %v6213 = getelementptr i8, ptr %v6212, i64 8
  store ptr %v6010, ptr %v6213, align 8, !tbaa !3
  %v6214 = getelementptr i8, ptr %v6212, i64 16
  store ptr %v6012, ptr %v6214, align 8, !tbaa !3
  %v6215 = getelementptr i8, ptr %v6212, i64 24
  store ptr %v6016, ptr %v6215, align 8, !tbaa !3
  %v6216 = getelementptr i8, ptr %v6212, i64 32
  store ptr %v6018, ptr %v6216, align 8, !tbaa !3
  %v6217 = getelementptr i8, ptr %v6212, i64 40
  store ptr %v6022, ptr %v6217, align 8, !tbaa !3
  %v6218 = getelementptr i8, ptr %v6212, i64 48
  store ptr %arg, ptr %v6218, align 8, !tbaa !3
  %v6219 = call ptr @mlf_closure(ptr @mlf.code.6071, ptr %v6212)
  %v6220 = call ptr @mlf_prim2(i64 1, ptr %v6064, ptr %v6219)
  ret ptr %v6220
}

define private ptr @mlf.code.5972(ptr %env, ptr %arg) {
entry:
  %v5973 = getelementptr i8, ptr %env, i64 8
  %v5974 = load ptr, ptr %v5973, align 8, !tbaa !3
  %v5975 = getelementptr i8, ptr %env, i64 16
  %v5976 = load ptr, ptr %v5975, align 8, !tbaa !3
  %v5977 = getelementptr i8, ptr %env, i64 24
  %v5978 = load ptr, ptr %v5977, align 8, !tbaa !3
  %v5979 = getelementptr i8, ptr %env, i64 32
  %v5980 = load ptr, ptr %v5979, align 8, !tbaa !3
  %v5981 = getelementptr i8, ptr %env, i64 40
  %v5982 = load ptr, ptr %v5981, align 8, !tbaa !3
  %v5983 = getelementptr i8, ptr %env, i64 48
  %v5984 = load ptr, ptr %v5983, align 8, !tbaa !3
  %v6003 = call ptr @mlf.allocate.thunk(ptr @mlf.code.5985, i64 2)
  %v6004 = getelementptr i8, ptr %v6003, i64 16
  %v6005 = load ptr, ptr %v6004, align 8, !tbaa !3
  %v6006 = getelementptr i8, ptr %v6005, i64 8
  store ptr %v5974, ptr %v6006, align 8, !tbaa !3
  %v6007 = getelementptr i8, ptr %v6005, i64 16
  store ptr %v5976, ptr %v6007, align 8, !tbaa !3
  %v6221 = call ptr @mlf_env_new(i64 7)
  %v6222 = getelementptr i8, ptr %v6221, i64 8
  store ptr %v5974, ptr %v6222, align 8, !tbaa !3
  %v6223 = getelementptr i8, ptr %v6221, i64 16
  store ptr %v5976, ptr %v6223, align 8, !tbaa !3
  %v6224 = getelementptr i8, ptr %v6221, i64 24
  store ptr %v5978, ptr %v6224, align 8, !tbaa !3
  %v6225 = getelementptr i8, ptr %v6221, i64 32
  store ptr %v5980, ptr %v6225, align 8, !tbaa !3
  %v6226 = getelementptr i8, ptr %v6221, i64 40
  store ptr %v5982, ptr %v6226, align 8, !tbaa !3
  %v6227 = getelementptr i8, ptr %v6221, i64 48
  store ptr %v5984, ptr %v6227, align 8, !tbaa !3
  %v6228 = getelementptr i8, ptr %v6221, i64 56
  store ptr %arg, ptr %v6228, align 8, !tbaa !3
  %v6229 = call ptr @mlf_closure(ptr @mlf.code.6008, ptr %v6221)
  %v6230 = call ptr @mlf_prim2(i64 1, ptr %v6003, ptr %v6229)
  ret ptr %v6230
}

define private ptr @mlf.code.5938(ptr %env, ptr %arg) {
entry:
  %v5939 = getelementptr i8, ptr %env, i64 8
  %v5940 = load ptr, ptr %v5939, align 8, !tbaa !3
  %v5941 = getelementptr i8, ptr %env, i64 16
  %v5942 = load ptr, ptr %v5941, align 8, !tbaa !3
  %v5943 = getelementptr i8, ptr %env, i64 24
  %v5944 = load ptr, ptr %v5943, align 8, !tbaa !3
  %v5945 = getelementptr i8, ptr %env, i64 32
  %v5946 = load ptr, ptr %v5945, align 8, !tbaa !3
  %v5947 = getelementptr i8, ptr %env, i64 40
  %v5948 = load ptr, ptr %v5947, align 8, !tbaa !3
  %v5967 = call ptr @mlf.allocate.thunk(ptr @mlf.code.5949, i64 2)
  %v5968 = getelementptr i8, ptr %v5967, i64 16
  %v5969 = load ptr, ptr %v5968, align 8, !tbaa !3
  %v5970 = getelementptr i8, ptr %v5969, i64 8
  store ptr %v5940, ptr %v5970, align 8, !tbaa !3
  %v5971 = getelementptr i8, ptr %v5969, i64 16
  store ptr %v5942, ptr %v5971, align 8, !tbaa !3
  %v6231 = call ptr @mlf_env_new(i64 6)
  %v6232 = getelementptr i8, ptr %v6231, i64 8
  store ptr %v5940, ptr %v6232, align 8, !tbaa !3
  %v6233 = getelementptr i8, ptr %v6231, i64 16
  store ptr %v5942, ptr %v6233, align 8, !tbaa !3
  %v6234 = getelementptr i8, ptr %v6231, i64 24
  store ptr %v5944, ptr %v6234, align 8, !tbaa !3
  %v6235 = getelementptr i8, ptr %v6231, i64 32
  store ptr %v5946, ptr %v6235, align 8, !tbaa !3
  %v6236 = getelementptr i8, ptr %v6231, i64 40
  store ptr %v5948, ptr %v6236, align 8, !tbaa !3
  %v6237 = getelementptr i8, ptr %v6231, i64 48
  store ptr %arg, ptr %v6237, align 8, !tbaa !3
  %v6238 = call ptr @mlf_closure(ptr @mlf.code.5972, ptr %v6231)
  %v6239 = call ptr @mlf_prim2(i64 1, ptr %v5967, ptr %v6238)
  ret ptr %v6239
}

define private ptr @mlf.code.5906(ptr %env, ptr %arg) {
entry:
  %v5907 = getelementptr i8, ptr %env, i64 8
  %v5908 = load ptr, ptr %v5907, align 8, !tbaa !3
  %v5909 = getelementptr i8, ptr %env, i64 16
  %v5910 = load ptr, ptr %v5909, align 8, !tbaa !3
  %v5911 = getelementptr i8, ptr %env, i64 24
  %v5912 = load ptr, ptr %v5911, align 8, !tbaa !3
  %v5913 = getelementptr i8, ptr %env, i64 32
  %v5914 = load ptr, ptr %v5913, align 8, !tbaa !3
  %v5933 = call ptr @mlf.allocate.thunk(ptr @mlf.code.5915, i64 2)
  %v5934 = getelementptr i8, ptr %v5933, i64 16
  %v5935 = load ptr, ptr %v5934, align 8, !tbaa !3
  %v5936 = getelementptr i8, ptr %v5935, i64 8
  store ptr %v5908, ptr %v5936, align 8, !tbaa !3
  %v5937 = getelementptr i8, ptr %v5935, i64 16
  store ptr %v5910, ptr %v5937, align 8, !tbaa !3
  %v6240 = call ptr @mlf_env_new(i64 5)
  %v6241 = getelementptr i8, ptr %v6240, i64 8
  store ptr %v5908, ptr %v6241, align 8, !tbaa !3
  %v6242 = getelementptr i8, ptr %v6240, i64 16
  store ptr %v5910, ptr %v6242, align 8, !tbaa !3
  %v6243 = getelementptr i8, ptr %v6240, i64 24
  store ptr %v5912, ptr %v6243, align 8, !tbaa !3
  %v6244 = getelementptr i8, ptr %v6240, i64 32
  store ptr %v5914, ptr %v6244, align 8, !tbaa !3
  %v6245 = getelementptr i8, ptr %v6240, i64 40
  store ptr %arg, ptr %v6245, align 8, !tbaa !3
  %v6246 = call ptr @mlf_closure(ptr @mlf.code.5938, ptr %v6240)
  %v6247 = call ptr @mlf_prim2(i64 1, ptr %v5933, ptr %v6246)
  ret ptr %v6247
}

define private ptr @mlf.code.5876(ptr %env, ptr %arg) {
entry:
  %v5877 = getelementptr i8, ptr %env, i64 8
  %v5878 = load ptr, ptr %v5877, align 8, !tbaa !3
  %v5879 = getelementptr i8, ptr %env, i64 16
  %v5880 = load ptr, ptr %v5879, align 8, !tbaa !3
  %v5881 = getelementptr i8, ptr %env, i64 24
  %v5882 = load ptr, ptr %v5881, align 8, !tbaa !3
  %v5901 = call ptr @mlf.allocate.thunk(ptr @mlf.code.5883, i64 2)
  %v5902 = getelementptr i8, ptr %v5901, i64 16
  %v5903 = load ptr, ptr %v5902, align 8, !tbaa !3
  %v5904 = getelementptr i8, ptr %v5903, i64 8
  store ptr %v5878, ptr %v5904, align 8, !tbaa !3
  %v5905 = getelementptr i8, ptr %v5903, i64 16
  store ptr %v5880, ptr %v5905, align 8, !tbaa !3
  %v6248 = call ptr @mlf_env_new(i64 4)
  %v6249 = getelementptr i8, ptr %v6248, i64 8
  store ptr %v5878, ptr %v6249, align 8, !tbaa !3
  %v6250 = getelementptr i8, ptr %v6248, i64 16
  store ptr %v5880, ptr %v6250, align 8, !tbaa !3
  %v6251 = getelementptr i8, ptr %v6248, i64 24
  store ptr %v5882, ptr %v6251, align 8, !tbaa !3
  %v6252 = getelementptr i8, ptr %v6248, i64 32
  store ptr %arg, ptr %v6252, align 8, !tbaa !3
  %v6253 = call ptr @mlf_closure(ptr @mlf.code.5906, ptr %v6248)
  %v6254 = call ptr @mlf_prim2(i64 1, ptr %v5901, ptr %v6253)
  ret ptr %v6254
}

define private ptr @mlf.code.5848(ptr %env, ptr %arg) {
entry:
  %v5849 = getelementptr i8, ptr %env, i64 8
  %v5850 = load ptr, ptr %v5849, align 8, !tbaa !3
  %v5851 = getelementptr i8, ptr %env, i64 16
  %v5852 = load ptr, ptr %v5851, align 8, !tbaa !3
  %v5871 = call ptr @mlf.allocate.thunk(ptr @mlf.code.5853, i64 2)
  %v5872 = getelementptr i8, ptr %v5871, i64 16
  %v5873 = load ptr, ptr %v5872, align 8, !tbaa !3
  %v5874 = getelementptr i8, ptr %v5873, i64 8
  store ptr %v5850, ptr %v5874, align 8, !tbaa !3
  %v5875 = getelementptr i8, ptr %v5873, i64 16
  store ptr %v5852, ptr %v5875, align 8, !tbaa !3
  %v6255 = call ptr @mlf_env_new(i64 3)
  %v6256 = getelementptr i8, ptr %v6255, i64 8
  store ptr %v5850, ptr %v6256, align 8, !tbaa !3
  %v6257 = getelementptr i8, ptr %v6255, i64 16
  store ptr %v5852, ptr %v6257, align 8, !tbaa !3
  %v6258 = getelementptr i8, ptr %v6255, i64 24
  store ptr %arg, ptr %v6258, align 8, !tbaa !3
  %v6259 = call ptr @mlf_closure(ptr @mlf.code.5876, ptr %v6255)
  %v6260 = call ptr @mlf_prim2(i64 1, ptr %v5871, ptr %v6259)
  ret ptr %v6260
}

define private ptr @mlf.worker.81(ptr %a0, ptr %a1) {
entry:
  %v5819 = call ptr @mlf_prim2(i64 10, ptr %a1, ptr inttoptr (i64 71 to ptr))
  %v5820 = icmp eq ptr %v5819, inttoptr (i64 6 to ptr)
  br i1 %v5820, label %yes.5821, label %no.5822
yes.5821:
  %v5824 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.5823
no.5822:
  %v5843 = call ptr @mlf.allocate.thunk(ptr @mlf.code.5825, i64 2)
  %v5844 = getelementptr i8, ptr %v5843, i64 16
  %v5845 = load ptr, ptr %v5844, align 8, !tbaa !3
  %v5846 = getelementptr i8, ptr %v5845, i64 8
  store ptr %a0, ptr %v5846, align 8, !tbaa !3
  %v5847 = getelementptr i8, ptr %v5845, i64 16
  store ptr %a1, ptr %v5847, align 8, !tbaa !3
  %v6261 = call ptr @mlf_env_new(i64 2)
  %v6262 = getelementptr i8, ptr %v6261, i64 8
  store ptr %a0, ptr %v6262, align 8, !tbaa !3
  %v6263 = getelementptr i8, ptr %v6261, i64 16
  store ptr %a1, ptr %v6263, align 8, !tbaa !3
  %v6264 = call ptr @mlf_closure(ptr @mlf.code.5848, ptr %v6261)
  %v6265 = call ptr @mlf_prim2(i64 1, ptr %v5843, ptr %v6264)
  br label %join.5823
join.5823:
  %v6266 = phi ptr [ %v5824, %yes.5821 ], [ %v6265, %no.5822 ]
  ret ptr %v6266
}

define private ptr @mlf.numeric.entry.5803(ptr %env, ptr %arg) {
entry:
  %v5804 = getelementptr i8, ptr %env, i64 8
  %v5805 = load ptr, ptr %v5804, align 8, !tbaa !3
  %v5806 = getelementptr i8, ptr %env, i64 16
  %v5807 = load ptr, ptr %v5806, align 8, !tbaa !3
  %v5808 = call ptr @mlf_peek(ptr %v5805)
  %v5809 = call ptr @mlf_peek(ptr %v5807)
  %v5810 = icmp ne ptr %v5808, null
  %v5811 = icmp ne ptr %v5809, null
  %v5812 = and i1 true, %v5810
  %v5813 = and i1 %v5812, %v5811
  br i1 %v5813, label %yes.5814, label %no.5815
yes.5814:
  %v5817 = call ptr @mlf.numeric.81(ptr %v5808, ptr %v5809)
  %v5818 = call ptr @mlf_prim1(i64 0, ptr %v5817)
  br label %join.5816
no.5815:
  %v6267 = call ptr @mlf.force(ptr %v5807)
  %v6268 = call ptr @mlf.worker.81(ptr %v5805, ptr %v6267)
  br label %join.5816
join.5816:
  %v6269 = phi ptr [ %v5818, %yes.5814 ], [ %v6268, %no.5815 ]
  ret ptr %v6269
}

define private ptr @mlf.code.5799(ptr %env, ptr %arg) {
entry:
  %v5800 = getelementptr i8, ptr %env, i64 8
  %v5801 = load ptr, ptr %v5800, align 8, !tbaa !3
  %v5802 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v5802, align 8, !tbaa !3
  %v6270 = call ptr @mlf_env_new(i64 2)
  %v6271 = getelementptr i8, ptr %v6270, i64 8
  store ptr %v5801, ptr %v6271, align 8, !tbaa !3
  %v6272 = getelementptr i8, ptr %v6270, i64 16
  store ptr inttoptr (i64 1 to ptr), ptr %v6272, align 8, !tbaa !3
  %v6273 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.5803, ptr %v6270)
  ret ptr %v6273
}

define private ptr @mlf.code.6278(ptr %env, ptr %arg) {
entry:
  %v6279 = getelementptr i8, ptr %env, i64 8
  %v6280 = load ptr, ptr %v6279, align 8, !tbaa !3
  %v6281 = getelementptr i8, ptr %env, i64 16
  %v6282 = load ptr, ptr %v6281, align 8, !tbaa !3
  %v6283 = call ptr @mlf.force(ptr %v6282)
  %v6284 = call ptr @mlf_prim2(i64 9, ptr %v6283, ptr inttoptr (i64 3 to ptr))
  %v6285 = call ptr @mlf_env_new(i64 2)
  %v6286 = getelementptr i8, ptr %v6285, i64 8
  store ptr %v6280, ptr %v6286, align 8, !tbaa !3
  %v6287 = getelementptr i8, ptr %v6285, i64 16
  store ptr %v6284, ptr %v6287, align 8, !tbaa !3
  %v6288 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.3659, ptr %v6285)
  ret ptr %v6288
}

define private ptr @mlf.code.5794(ptr %env, ptr %arg) {
entry:
  %v5795 = getelementptr i8, ptr %env, i64 8
  %v5796 = load ptr, ptr %v5795, align 8, !tbaa !3
  %v5797 = getelementptr i8, ptr %env, i64 16
  %v5798 = load ptr, ptr %v5797, align 8, !tbaa !3
  %v6274 = call ptr @mlf.allocate.thunk(ptr @mlf.code.5799, i64 1)
  %v6275 = getelementptr i8, ptr %v6274, i64 16
  %v6276 = load ptr, ptr %v6275, align 8, !tbaa !3
  %v6277 = getelementptr i8, ptr %v6276, i64 8
  store ptr %v5796, ptr %v6277, align 8, !tbaa !3
  %v6289 = call ptr @mlf_env_new(i64 2)
  %v6290 = getelementptr i8, ptr %v6289, i64 8
  store ptr %v5796, ptr %v6290, align 8, !tbaa !3
  %v6291 = getelementptr i8, ptr %v6289, i64 16
  store ptr %v5798, ptr %v6291, align 8, !tbaa !3
  %v6292 = call ptr @mlf_closure(ptr @mlf.code.6278, ptr %v6289)
  %v6293 = call ptr @mlf_prim2(i64 1, ptr %v6274, ptr %v6292)
  ret ptr %v6293
}

define private ptr @mlf.worker.96(ptr %a0, ptr %a1) {
entry:
  %v4262 = call ptr @mlf_prim2(i64 10, ptr %a1, ptr inttoptr (i64 1 to ptr))
  %v4263 = icmp eq ptr %v4262, inttoptr (i64 6 to ptr)
  br i1 %v4263, label %yes.4264, label %no.4265
yes.4264:
  %v4267 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.4266
no.4265:
  %v5790 = call ptr @mlf.allocate.thunk(ptr @mlf.code.4268, i64 1)
  %v5791 = getelementptr i8, ptr %v5790, i64 16
  %v5792 = load ptr, ptr %v5791, align 8, !tbaa !3
  %v5793 = getelementptr i8, ptr %v5792, i64 8
  store ptr %a0, ptr %v5793, align 8, !tbaa !3
  %v6294 = call ptr @mlf_env_new(i64 2)
  %v6295 = getelementptr i8, ptr %v6294, i64 8
  store ptr %a0, ptr %v6295, align 8, !tbaa !3
  %v6296 = getelementptr i8, ptr %v6294, i64 16
  store ptr %a1, ptr %v6296, align 8, !tbaa !3
  %v6297 = call ptr @mlf_closure(ptr @mlf.code.5794, ptr %v6294)
  %v6298 = call ptr @mlf_prim2(i64 1, ptr %v5790, ptr %v6297)
  br label %join.4266
join.4266:
  %v6299 = phi ptr [ %v4267, %yes.4264 ], [ %v6298, %no.4265 ]
  ret ptr %v6299
}

define private ptr @mlf.numeric.entry.3659(ptr %env, ptr %arg) {
entry:
  %v3660 = getelementptr i8, ptr %env, i64 8
  %v3661 = load ptr, ptr %v3660, align 8, !tbaa !3
  %v3662 = getelementptr i8, ptr %env, i64 16
  %v3663 = load ptr, ptr %v3662, align 8, !tbaa !3
  %v3664 = call ptr @mlf_peek(ptr %v3661)
  %v3665 = call ptr @mlf_peek(ptr %v3663)
  %v3666 = icmp ne ptr %v3664, null
  %v3667 = icmp ne ptr %v3665, null
  %v3668 = and i1 true, %v3666
  %v3669 = and i1 %v3668, %v3667
  br i1 %v3669, label %yes.3670, label %no.3671
yes.3670:
  %v4260 = call ptr @mlf.numeric.96(ptr %v3664, ptr %v3665)
  %v4261 = call ptr @mlf_prim1(i64 0, ptr %v4260)
  br label %join.3672
no.3671:
  %v6300 = call ptr @mlf.force(ptr %v3663)
  %v6301 = call ptr @mlf.worker.96(ptr %v3661, ptr %v6300)
  br label %join.3672
join.3672:
  %v6302 = phi ptr [ %v4261, %yes.3670 ], [ %v6301, %no.3671 ]
  ret ptr %v6302
}

define private ptr @mlf.code.3652(ptr %env, ptr %arg) {
entry:
  %v3653 = getelementptr i8, ptr %env, i64 8
  %v3654 = load ptr, ptr %v3653, align 8, !tbaa !3
  %v3655 = getelementptr i8, ptr %env, i64 16
  %v3656 = load ptr, ptr %v3655, align 8, !tbaa !3
  %v3657 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3657, align 8, !tbaa !3
  %v3658 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v3658, align 8, !tbaa !3
  %v6303 = call ptr @mlf.force(ptr %v3654)
  %v6304 = call ptr @mlf_prim1(i64 17, ptr %v6303)
  %v6305 = call ptr @mlf_env_new(i64 2)
  %v6306 = getelementptr i8, ptr %v6305, i64 8
  store ptr %v3656, ptr %v6306, align 8, !tbaa !3
  %v6307 = getelementptr i8, ptr %v6305, i64 16
  store ptr %v6304, ptr %v6307, align 8, !tbaa !3
  %v6308 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.3659, ptr %v6305)
  ret ptr %v6308
}

define private ptr @mlf.code.6317(ptr %env, ptr %arg) {
entry:
  %v6318 = getelementptr i8, ptr %env, i64 8
  %v6319 = load ptr, ptr %v6318, align 8, !tbaa !3
  %v6320 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v6320, align 8, !tbaa !3
  %v6321 = call ptr @mlf_double(double 0x0000000000000000)
  %v6322 = call ptr @mlf_env_new(i64 3)
  %v6323 = getelementptr i8, ptr %v6322, i64 8
  store ptr %v6319, ptr %v6323, align 8, !tbaa !3
  %v6324 = getelementptr i8, ptr %v6322, i64 16
  store ptr inttoptr (i64 1 to ptr), ptr %v6324, align 8, !tbaa !3
  %v6325 = getelementptr i8, ptr %v6322, i64 24
  store ptr %v6321, ptr %v6325, align 8, !tbaa !3
  %v6326 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2327, ptr %v6322)
  ret ptr %v6326
}

define private ptr @mlf.code.6332(ptr %env, ptr %arg) {
entry:
  %v6333 = getelementptr i8, ptr %env, i64 8
  %v6334 = load ptr, ptr %v6333, align 8, !tbaa !3
  %v6335 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v6335, align 8, !tbaa !3
  %v6336 = call ptr @mlf.force(ptr %v6334)
  %v6337 = call ptr @mlf_prim2(i64 26, ptr inttoptr (i64 19 to ptr), ptr %v6336)
  ret ptr %v6337
}

define private ptr @mlf.code.6331(ptr %env, ptr %arg) {
entry:
  %v6338 = call ptr @mlf.allocate.thunk(ptr @mlf.code.6332, i64 1)
  %v6339 = getelementptr i8, ptr %v6338, i64 16
  %v6340 = load ptr, ptr %v6339, align 8, !tbaa !3
  %v6341 = getelementptr i8, ptr %v6340, i64 8
  store ptr %arg, ptr %v6341, align 8, !tbaa !3
  %v6342 = call ptr @mlf_prim1(i64 3, ptr %v6338)
  ret ptr %v6342
}

define private ptr @mlf.code.6314(ptr %env, ptr %arg) {
entry:
  %v6315 = getelementptr i8, ptr %env, i64 8
  %v6316 = load ptr, ptr %v6315, align 8, !tbaa !3
  %v6327 = call ptr @mlf.allocate.thunk(ptr @mlf.code.6317, i64 1)
  %v6328 = getelementptr i8, ptr %v6327, i64 16
  %v6329 = load ptr, ptr %v6328, align 8, !tbaa !3
  %v6330 = getelementptr i8, ptr %v6329, i64 8
  store ptr %v6316, ptr %v6330, align 8, !tbaa !3
  %v6343 = call ptr @mlf_closure(ptr @mlf.code.6331, ptr null)
  %v6344 = call ptr @mlf_prim2(i64 1, ptr %v6327, ptr %v6343)
  ret ptr %v6344
}

define private ptr @mlf.code.3647(ptr %env, ptr %arg) {
entry:
  %v3648 = getelementptr i8, ptr %env, i64 8
  %v3649 = load ptr, ptr %v3648, align 8, !tbaa !3
  %v3650 = getelementptr i8, ptr %env, i64 16
  %v3651 = load ptr, ptr %v3650, align 8, !tbaa !3
  %v6309 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3652, i64 2)
  %v6310 = getelementptr i8, ptr %v6309, i64 16
  %v6311 = load ptr, ptr %v6310, align 8, !tbaa !3
  %v6312 = getelementptr i8, ptr %v6311, i64 8
  store ptr %v3649, ptr %v6312, align 8, !tbaa !3
  %v6313 = getelementptr i8, ptr %v6311, i64 16
  store ptr %v3651, ptr %v6313, align 8, !tbaa !3
  %v6345 = call ptr @mlf_env_new(i64 1)
  %v6346 = getelementptr i8, ptr %v6345, i64 8
  store ptr %v3651, ptr %v6346, align 8, !tbaa !3
  %v6347 = call ptr @mlf_closure(ptr @mlf.code.6314, ptr %v6345)
  %v6348 = call ptr @mlf_prim2(i64 1, ptr %v6309, ptr %v6347)
  ret ptr %v6348
}

define private ptr @mlf.code.3623(ptr %env, ptr %arg) {
entry:
  %v3624 = getelementptr i8, ptr %env, i64 8
  %v3625 = load ptr, ptr %v3624, align 8, !tbaa !3
  %v3626 = getelementptr i8, ptr %env, i64 16
  %v3627 = load ptr, ptr %v3626, align 8, !tbaa !3
  %v3643 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3628, i64 1)
  %v3644 = getelementptr i8, ptr %v3643, i64 16
  %v3645 = load ptr, ptr %v3644, align 8, !tbaa !3
  %v3646 = getelementptr i8, ptr %v3645, i64 8
  store ptr %arg, ptr %v3646, align 8, !tbaa !3
  %v6349 = call ptr @mlf_env_new(i64 2)
  %v6350 = getelementptr i8, ptr %v6349, i64 8
  store ptr %v3625, ptr %v6350, align 8, !tbaa !3
  %v6351 = getelementptr i8, ptr %v6349, i64 16
  store ptr %v3627, ptr %v6351, align 8, !tbaa !3
  %v6352 = call ptr @mlf_closure(ptr @mlf.code.3647, ptr %v6349)
  %v6353 = call ptr @mlf_prim2(i64 1, ptr %v3643, ptr %v6352)
  ret ptr %v6353
}

define private ptr @mlf.code.2318(ptr %env, ptr %arg) {
entry:
  %v2319 = getelementptr i8, ptr %env, i64 8
  %v2320 = load ptr, ptr %v2319, align 8, !tbaa !3
  %v2321 = getelementptr i8, ptr %env, i64 16
  %v2322 = load ptr, ptr %v2321, align 8, !tbaa !3
  %v3619 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2323, i64 1)
  %v3620 = getelementptr i8, ptr %v3619, i64 16
  %v3621 = load ptr, ptr %v3620, align 8, !tbaa !3
  %v3622 = getelementptr i8, ptr %v3621, i64 8
  store ptr %v2322, ptr %v3622, align 8, !tbaa !3
  %v6354 = call ptr @mlf_env_new(i64 2)
  %v6355 = getelementptr i8, ptr %v6354, i64 8
  store ptr %v2320, ptr %v6355, align 8, !tbaa !3
  %v6356 = getelementptr i8, ptr %v6354, i64 16
  store ptr %v2322, ptr %v6356, align 8, !tbaa !3
  %v6357 = call ptr @mlf_closure(ptr @mlf.code.3623, ptr %v6354)
  %v6358 = call ptr @mlf_prim2(i64 1, ptr %v3619, ptr %v6357)
  ret ptr %v6358
}

define private ptr @mlf.code.1426(ptr %env, ptr %arg) {
entry:
  %v1427 = getelementptr i8, ptr %env, i64 8
  %v1428 = load ptr, ptr %v1427, align 8, !tbaa !3
  %v1429 = getelementptr i8, ptr %env, i64 16
  %v1430 = load ptr, ptr %v1429, align 8, !tbaa !3
  %v1431 = getelementptr i8, ptr %env, i64 24
  %v1432 = load ptr, ptr %v1431, align 8, !tbaa !3
  %v2313 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1433, i64 2)
  %v2314 = getelementptr i8, ptr %v2313, i64 16
  %v2315 = load ptr, ptr %v2314, align 8, !tbaa !3
  %v2316 = getelementptr i8, ptr %v2315, i64 8
  store ptr %v1428, ptr %v2316, align 8, !tbaa !3
  %v2317 = getelementptr i8, ptr %v2315, i64 16
  store ptr %v1432, ptr %v2317, align 8, !tbaa !3
  %v6359 = call ptr @mlf_env_new(i64 2)
  %v6360 = getelementptr i8, ptr %v6359, i64 8
  store ptr %v1430, ptr %v6360, align 8, !tbaa !3
  %v6361 = getelementptr i8, ptr %v6359, i64 16
  store ptr %v1432, ptr %v6361, align 8, !tbaa !3
  %v6362 = call ptr @mlf_closure(ptr @mlf.code.2318, ptr %v6359)
  %v6363 = call ptr @mlf_prim2(i64 1, ptr %v2313, ptr %v6362)
  ret ptr %v6363
}

define private ptr @mlf.code.26(ptr %env, ptr %arg) {
entry:
  %v27 = getelementptr i8, ptr %env, i64 8
  %v28 = load ptr, ptr %v27, align 8, !tbaa !3
  %v29 = getelementptr i8, ptr %env, i64 16
  %v30 = load ptr, ptr %v29, align 8, !tbaa !3
  %v1421 = call ptr @mlf.allocate.thunk(ptr @mlf.code.31, i64 2)
  %v1422 = getelementptr i8, ptr %v1421, i64 16
  %v1423 = load ptr, ptr %v1422, align 8, !tbaa !3
  %v1424 = getelementptr i8, ptr %v1423, i64 8
  store ptr %v28, ptr %v1424, align 8, !tbaa !3
  %v1425 = getelementptr i8, ptr %v1423, i64 16
  store ptr %arg, ptr %v1425, align 8, !tbaa !3
  %v6364 = call ptr @mlf_env_new(i64 3)
  %v6365 = getelementptr i8, ptr %v6364, i64 8
  store ptr %v28, ptr %v6365, align 8, !tbaa !3
  %v6366 = getelementptr i8, ptr %v6364, i64 16
  store ptr %v30, ptr %v6366, align 8, !tbaa !3
  %v6367 = getelementptr i8, ptr %v6364, i64 24
  store ptr %arg, ptr %v6367, align 8, !tbaa !3
  %v6368 = call ptr @mlf_closure(ptr @mlf.code.1426, ptr %v6364)
  %v6369 = call ptr @mlf_prim2(i64 1, ptr %v1421, ptr %v6368)
  ret ptr %v6369
}

define private ptr @mlf.code.19(ptr %env, ptr %arg) {
entry:
  %v20 = getelementptr i8, ptr %env, i64 8
  %v21 = load ptr, ptr %v20, align 8, !tbaa !3
  %v25 = call ptr @mlf_thunk(ptr @mlf.code.22, ptr null)
  %v6370 = call ptr @mlf_env_new(i64 2)
  %v6371 = getelementptr i8, ptr %v6370, i64 8
  store ptr %v21, ptr %v6371, align 8, !tbaa !3
  %v6372 = getelementptr i8, ptr %v6370, i64 16
  store ptr %arg, ptr %v6372, align 8, !tbaa !3
  %v6373 = call ptr @mlf_closure(ptr @mlf.code.26, ptr %v6370)
  %v6374 = call ptr @mlf_prim2(i64 1, ptr %v25, ptr %v6373)
  ret ptr %v6374
}

define private ptr @mlf.code.0(ptr %env, ptr %arg) {
entry:
  %v17 = call ptr @mlf_thunk(ptr @mlf.code.1, ptr null)
  %v18 = call ptr @mlf_primitive(i64 4)
  %v6375 = call ptr @mlf_env_new(i64 1)
  %v6376 = getelementptr i8, ptr %v6375, i64 8
  store ptr %v17, ptr %v6376, align 8, !tbaa !3
  %v6377 = call ptr @mlf_closure(ptr @mlf.code.19, ptr %v6375)
  %v6378 = call ptr @mlf_prim2(i64 1, ptr %v18, ptr %v6377)
  ret ptr %v6378
}

declare void @mlf_require_compact_gc_abi()
define ptr @mlf_entry() {
  call void @mlf_require_compact_gc_abi()
  %root = call ptr @mlf.code.0(ptr null, ptr null)
  ret ptr %root
}
define i32 @main(i32 %argc, ptr %argv) {
  call void @mlf_set_args(i32 %argc, ptr %argv)
  %root = call ptr @mlf_entry()
  %status = call i32 @mlf_run(ptr %root, i64 1)
  ret i32 %status
}
