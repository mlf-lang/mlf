; Generated from independently checked xMLF.
source_filename = "emlf"

declare ptr @mlf_thunk_new(ptr, i64)
declare ptr @mlf_execute_st_lazy(ptr)
declare ptr @mlf_st_new_array(ptr, ptr)
declare ptr @mlf_st_read_array(ptr, ptr)
declare ptr @mlf_st_write_array(ptr, ptr, ptr)
declare ptr @mlf_st_length_array(ptr)
declare void @mlf_set_args(i32, ptr)
declare ptr @mlf_env_new(i64)
declare void @mlf_env_set(ptr, i64, ptr)
declare ptr @mlf_env_get(ptr, i64)
declare ptr @mlf_thunk(ptr, ptr)
declare ptr @mlf_closure(ptr, ptr)
declare ptr @mlf_application(ptr, ptr)
declare ptr @mlf_hole()
declare void @mlf_fill(ptr, ptr)
declare ptr @mlf_integer(ptr)
declare ptr @mlf_string(ptr, i64)
declare ptr @mlf_double(double)
declare double @llvm.sqrt.f64(double)
declare double @mlf_int_to_double(ptr)
declare ptr @mlf_read_int_table(ptr, ptr)
declare ptr @mlf_write_int_table(ptr, ptr, ptr)
declare ptr @mlf_add_int_table(ptr, ptr, ptr)
declare void @mlf_roots_enter(ptr, i64, ptr)
declare void @mlf_roots_leave(ptr)
declare void @mlf_gc_check(i64, ptr)
declare ptr @mlf_get_byte_line()
declare ptr @mlf_new_array(i64, ptr, ptr)
declare ptr @mlf_bytes_from_string(ptr)
declare ptr @mlf_put_bytes(ptr, ptr, ptr)
declare ptr @mlf_new_int_table()
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare i8 @mlf_byte(ptr)
declare ptr @mlf_peek(ptr)
declare ptr @mlf_native_io(ptr, ptr)
declare void @mlf_bounds_failure() noreturn
declare ptr @mlf_primitive(i64)
declare ptr @mlf_prim1(i64, ptr)
declare ptr @mlf_prim2(i64, ptr, ptr)
declare i64 @mlf_truth(ptr)
declare ptr @mlf_prim3(i64, ptr, ptr, ptr)
declare ptr @mlf_force(ptr)
declare ptr @mlf_add_int(ptr, ptr)
declare ptr @mlf_sub_int(ptr, ptr)
declare ptr @mlf_eq_int(ptr, ptr)
declare ptr @mlf_lt_int(ptr, ptr)
declare ptr @mlf_constructor(i64, i64)
declare ptr @mlf_constructor1(i64, ptr)
declare ptr @mlf_constructor2(i64, ptr, ptr)
declare ptr @mlf_constructor_fields(i64, ptr)
declare ptr @mlf_constructor_new(i64, i64)
declare ptr @mlf_field(ptr, i64)
declare void @mlf_match_failure() noreturn
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare i32 @mlf_run(ptr, i64)

@mlf_constructor_pending = external global [33 x ptr]
declare ptr @mlf_constructor_allocate(i64, i64)
define private ptr @mlf.allocate.constructor(i64 %identity, i64 %count, i64 %size) alwaysinline {
entry:
  %small = icmp ule i64 %size, 256
  br i1 %small, label %batch, label %slow
batch:
  %index = lshr i64 %size, 3
  %slot = getelementptr [33 x ptr], ptr @mlf_constructor_pending, i64 0, i64 %index
  %value = load ptr, ptr %slot, align 8
  %empty = icmp eq ptr %value, null
  br i1 %empty, label %slow, label %ready
ready:
  %next = load ptr, ptr %value, align 8
  store ptr %next, ptr %slot, align 8
  store i64 0, ptr %value, align 8
  ret ptr %value
slow:
  %allocated = call ptr @mlf_constructor_allocate(i64 %identity, i64 %count)
  ret ptr %allocated
}
define private ptr @mlf.construct.1(i64 %identity, ptr %a) alwaysinline {
entry:
  %value = call ptr @mlf.allocate.constructor(i64 %identity, i64 1, i64 24)
  store i32 12, ptr %value, align 4
  %id = getelementptr i8, ptr %value, i64 8
  store i64 %identity, ptr %id, align 8
  %first = getelementptr i8, ptr %value, i64 16
  store ptr %a, ptr %first, align 8
  ret ptr %value
}
define private ptr @mlf.construct.2(i64 %identity, ptr %a, ptr %b) alwaysinline {
entry:
  %value = call ptr @mlf.allocate.constructor(i64 %identity, i64 2, i64 32)
  store i32 13, ptr %value, align 4
  %id = getelementptr i8, ptr %value, i64 8
  store i64 %identity, ptr %id, align 8
  %first = getelementptr i8, ptr %value, i64 16
  store ptr %a, ptr %first, align 8
  %second = getelementptr i8, ptr %value, i64 24
  store ptr %b, ptr %second, align 8
  ret ptr %value
}
define private ptr @mlf.construct.wide(i64 %identity, i64 %count) alwaysinline {
entry:
  %fields = mul i64 %count, 8
  %size = add i64 %fields, 24
  %value = call ptr @mlf.allocate.constructor(i64 %identity, i64 %count, i64 %size)
  store i32 28, ptr %value, align 4
  %id = getelementptr i8, ptr %value, i64 8
  store i64 %identity, ptr %id, align 8
  %arity = getelementptr i8, ptr %value, i64 16
  store i64 %count, ptr %arity, align 8
  ret ptr %value
}
@mlf_compact_pending = external global [17 x ptr]
define private ptr @mlf.allocate.thunk(ptr %code, i64 %count) alwaysinline {
entry:
  %words = add i64 %count, 4
  %index = lshr i64 %words, 1
  %slot = getelementptr [17 x ptr], ptr @mlf_compact_pending, i64 0, i64 %index
  %value = load ptr, ptr %slot, align 8
  %empty = icmp eq ptr %value, null
  br i1 %empty, label %slow, label %ready
ready:
  %next = load ptr, ptr %value, align 8
  store ptr %next, ptr %slot, align 8
  store i64 3, ptr %value, align 8
  %function = getelementptr i8, ptr %value, i64 8
  store ptr %code, ptr %function, align 8
  %environment = getelementptr i8, ptr %value, i64 24
  %capture = getelementptr i8, ptr %value, i64 16
  store ptr %environment, ptr %capture, align 8
  store i64 %count, ptr %environment, align 8
  ret ptr %value
slow:
  %allocated = call ptr @mlf_thunk_new(ptr %code, i64 %count)
  ret ptr %allocated
}
define private ptr @mlf.force(ptr %value) alwaysinline {
entry:
  %null = icmp eq ptr %value, null
  br i1 %null, label %slow, label %test
test:
  %bits = ptrtoint ptr %value to i64
  %kind = and i64 %bits, 7
  %immediate = icmp ne i64 %kind, 0
  br i1 %immediate, label %done, label %tagged
tagged:
  %tag = load i32, ptr %value, align 4
  %ready = icmp uge i32 %tag, 5
  br i1 %ready, label %done, label %deferred
deferred:
  %isthunk = icmp eq i32 %tag, 3
  br i1 %isthunk, label %enter, label %indirect
indirect:
  %forwarded = icmp eq i32 %tag, 2
  br i1 %forwarded, label %next, label %slow
next:
  %slot = getelementptr i8, ptr %value, i64 8
  %p = load ptr, ptr %slot, align 8
  %missing = icmp eq ptr %p, null
  br i1 %missing, label %slow, label %nexttest
nexttest:
  %pbits = ptrtoint ptr %p to i64
  %pkind = and i64 %pbits, 7
  %pimm = icmp ne i64 %pkind, 0
  br i1 %pimm, label %forward, label %ptagged
ptagged:
  %ptag = load i32, ptr %p, align 4
  %pready = icmp uge i32 %ptag, 5
  br i1 %pready, label %forward, label %slow
forward:
  ret ptr %p
done:
  ret ptr %value
enter:
  %code.slot = getelementptr i8, ptr %value, i64 8
  %env.slot = getelementptr i8, ptr %value, i64 16
  %code = load ptr, ptr %code.slot, align 8
  %env = load ptr, ptr %env.slot, align 8
  store i32 1, ptr %value, align 4
  store ptr null, ptr %code.slot, align 8
  store ptr null, ptr %env.slot, align 8
  %returned = call ptr %code(ptr %env, ptr null)
  %canonical = call ptr @mlf_force(ptr %returned)
  store i32 2, ptr %value, align 4
  store ptr %canonical, ptr %code.slot, align 8
  ret ptr %canonical
slow:
  %result = tail call ptr @mlf_force(ptr %value)
  ret ptr %result
}
!0 = !{!"MLF storage"}
!1 = !{!"managed object", !0}
!2 = !{!"array cells", !0}
!3 = !{!1, !1, i64 0}
!4 = !{!2, !2, i64 0}
@mlf.bytes.14 = private unnamed_addr constant [288 x i8] c"\47\47\43\43\47\47\47\43\47\43\47\47\54\47\47\43\54\43\41\43\47\43\43\54\47\54\41\41\54\43\43\43\41\47\43\41\43\54\54\54\47\47\47\41\47\47\43\43\47\41\47\47\43\47\47\47\43\47\47\41\54\43\41\43\43\54\47\41\47\47\54\43\41\47\47\41\47\54\54\43\47\41\47\41\43\43\41\47\43\43\54\47\47\43\43\41\41\43\41\54\47\47\54\47\41\41\41\43\43\43\43\47\54\43\54\43\54\41\43\54\41\41\41\41\41\54\41\43\41\41\41\41\41\54\54\41\47\43\43\47\47\47\43\47\54\47\47\54\47\47\43\47\43\47\43\47\43\43\54\47\54\41\41\54\43\43\43\41\47\43\54\41\43\54\43\47\47\47\41\47\47\43\54\47\41\47\47\43\41\47\47\41\47\41\41\54\43\47\43\54\54\47\41\41\43\43\43\47\47\47\41\47\47\43\47\47\41\47\47\54\54\47\43\41\47\54\47\41\47\43\43\47\41\47\41\54\43\47\43\47\43\43\41\43\54\47\43\41\43\54\43\43\41\47\43\43\54\47\47\47\43\47\41\43\41\47\41\47\43\47\41\47\41\43\54\43\43\47\54\43\54\43\41\41\41\41\41\00", align 1
@mlf.bytes.14.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 287, ptr @mlf.bytes.14, ptr null }, align 8
@mlf.bytes.21 = private unnamed_addr constant [16 x i8] c"\61\63\67\74\42\44\48\4b\4d\4e\52\53\56\57\59\00", align 1
@mlf.bytes.21.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 15, ptr @mlf.bytes.21, ptr null }, align 8
@mlf.bytes.30 = private unnamed_addr constant [5 x i8] c"\61\63\67\74\00", align 1
@mlf.bytes.30.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 4, ptr @mlf.bytes.30, ptr null }, align 8
@mlf.bytes.609 = private unnamed_addr constant [22 x i8] c"\3e\4f\4e\45\20\48\6f\6d\6f\20\73\61\70\69\65\6e\73\20\61\6c\75\00", align 1
@mlf.bytes.609.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 21, ptr @mlf.bytes.609, ptr null }, align 8
@mlf.bytes.1977 = private unnamed_addr constant [25 x i8] c"\3e\54\57\4f\20\49\55\42\20\61\6d\62\69\67\75\69\74\79\20\63\6f\64\65\73\00", align 1
@mlf.bytes.1977.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 24, ptr @mlf.bytes.1977, ptr null }, align 8
@mlf.bytes.3961 = private unnamed_addr constant [30 x i8] c"\3e\54\48\52\45\45\20\48\6f\6d\6f\20\73\61\70\69\65\6e\73\20\66\72\65\71\75\65\6e\63\79\00", align 1
@mlf.bytes.3961.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 29, ptr @mlf.bytes.3961, ptr null }, align 8
define private ptr @mlf.code.3(ptr %env, ptr %arg) {
entry:
  %v4 = getelementptr i8, ptr %env, i64 8
  %v5 = load ptr, ptr %v4, align 8, !tbaa !3
  %v6 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v6, align 8, !tbaa !3
  %v7 = call ptr @mlf.force(ptr %v5)
  %v8 = call ptr @mlf_prim1(i64 17, ptr %v7)
  ret ptr %v8
}

define private ptr @mlf.code.13(ptr %env, ptr %arg) {
entry:
  %v15 = call ptr @mlf_prim1(i64 39, ptr @mlf.bytes.14.value)
  ret ptr %v15
}

define private ptr @mlf.code.20(ptr %env, ptr %arg) {
entry:
  %v22 = call ptr @mlf_prim1(i64 39, ptr @mlf.bytes.21.value)
  ret ptr %v22
}

define private ptr @mlf.code.29(ptr %env, ptr %arg) {
entry:
  %v31 = call ptr @mlf_prim1(i64 39, ptr @mlf.bytes.30.value)
  ret ptr %v31
}

define private ptr @mlf.code.40(ptr %env, ptr %arg) {
entry:
  %v41 = call ptr @mlf_double(double 0x3f947ae147ae147b)
  %v42 = call ptr @mlf_prim2(i64 31, ptr inttoptr (i64 31 to ptr), ptr %v41)
  ret ptr %v42
}

define private ptr @mlf.code.53(ptr %env, ptr %arg) {
entry:
  %v54 = getelementptr i8, ptr %env, i64 8
  %v55 = load ptr, ptr %v54, align 8, !tbaa !3
  %v56 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v56, align 8, !tbaa !3
  %v57 = call ptr @mlf_double(double 0x3fd147ae147ae148)
  %v58 = call ptr @mlf_prim3(i64 33, ptr %v55, ptr inttoptr (i64 1 to ptr), ptr %v57)
  ret ptr %v58
}

define private ptr @mlf.code.74(ptr %env, ptr %arg) {
entry:
  %v75 = getelementptr i8, ptr %env, i64 8
  %v76 = load ptr, ptr %v75, align 8, !tbaa !3
  %v77 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v77, align 8, !tbaa !3
  %v78 = call ptr @mlf_double(double 0x3fbeb851eb851eb8)
  %v79 = call ptr @mlf_prim3(i64 33, ptr %v76, ptr inttoptr (i64 3 to ptr), ptr %v78)
  ret ptr %v79
}

define private ptr @mlf.code.95(ptr %env, ptr %arg) {
entry:
  %v96 = getelementptr i8, ptr %env, i64 8
  %v97 = load ptr, ptr %v96, align 8, !tbaa !3
  %v98 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v98, align 8, !tbaa !3
  %v99 = call ptr @mlf_double(double 0x3fbeb851eb851eb8)
  %v100 = call ptr @mlf_prim3(i64 33, ptr %v97, ptr inttoptr (i64 5 to ptr), ptr %v99)
  ret ptr %v100
}

define private ptr @mlf.code.116(ptr %env, ptr %arg) {
entry:
  %v117 = getelementptr i8, ptr %env, i64 8
  %v118 = load ptr, ptr %v117, align 8, !tbaa !3
  %v119 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v119, align 8, !tbaa !3
  %v120 = call ptr @mlf_double(double 0x3fd147ae147ae148)
  %v121 = call ptr @mlf_prim3(i64 33, ptr %v118, ptr inttoptr (i64 7 to ptr), ptr %v120)
  ret ptr %v121
}

define private ptr @mlf.code.137(ptr %env, ptr %arg) {
entry:
  %v138 = call ptr @mlf_double(double 0x0000000000000000)
  %v139 = call ptr @mlf_prim2(i64 31, ptr inttoptr (i64 9 to ptr), ptr %v138)
  ret ptr %v139
}

define private ptr @mlf.code.152(ptr %env, ptr %arg) {
entry:
  %v153 = getelementptr i8, ptr %env, i64 8
  %v154 = load ptr, ptr %v153, align 8, !tbaa !3
  %v155 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v155, align 8, !tbaa !3
  %v156 = call ptr @mlf_double(double 0x3fd3639d20baeb5b)
  %v157 = call ptr @mlf_prim3(i64 33, ptr %v154, ptr inttoptr (i64 1 to ptr), ptr %v156)
  ret ptr %v157
}

define private ptr @mlf.code.175(ptr %env, ptr %arg) {
entry:
  %v176 = getelementptr i8, ptr %env, i64 8
  %v177 = load ptr, ptr %v176, align 8, !tbaa !3
  %v178 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v178, align 8, !tbaa !3
  %v179 = call ptr @mlf_double(double 0x3fc957ae3dcd561b)
  %v180 = call ptr @mlf_prim3(i64 33, ptr %v177, ptr inttoptr (i64 3 to ptr), ptr %v179)
  ret ptr %v180
}

define private ptr @mlf.code.198(ptr %env, ptr %arg) {
entry:
  %v199 = getelementptr i8, ptr %env, i64 8
  %v200 = load ptr, ptr %v199, align 8, !tbaa !3
  %v201 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v201, align 8, !tbaa !3
  %v202 = call ptr @mlf_double(double 0x3fc9493aeab6c2bf)
  %v203 = call ptr @mlf_prim3(i64 33, ptr %v200, ptr inttoptr (i64 5 to ptr), ptr %v202)
  ret ptr %v203
}

define private ptr @mlf.code.221(ptr %env, ptr %arg) {
entry:
  %v222 = getelementptr i8, ptr %env, i64 8
  %v223 = load ptr, ptr %v222, align 8, !tbaa !3
  %v224 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v224, align 8, !tbaa !3
  %v225 = call ptr @mlf_double(double 0x3fd34bee4b030838)
  %v226 = call ptr @mlf_prim3(i64 33, ptr %v223, ptr inttoptr (i64 7 to ptr), ptr %v225)
  ret ptr %v226
}

define private ptr @mlf.numeric.0(ptr %a0, ptr %a1, ptr %a2) alwaysinline {
entry:
  %v267 = ptrtoint ptr %a2 to i64
  %v268 = ptrtoint ptr %a1 to i64
  %v269 = and i64 %v267, %v268
  %v270 = and i64 %v269, 1
  %v271 = icmp ne i64 %v270, 0
  br i1 %v271, label %yes.272, label %no.273
yes.272:
  %v275 = icmp slt i64 %v267, %v268
  %v276 = select i1 %v275, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.274
no.273:
  %v277 = call ptr @mlf_lt_int(ptr %a2, ptr %a1)
  br label %join.274
join.274:
  %v278 = phi ptr [ %v276, %yes.272 ], [ %v277, %no.273 ]
  %v279 = icmp eq ptr %v278, inttoptr (i64 6 to ptr)
  br i1 %v279, label %tail.yes.280, label %tail.no.281
tail.yes.280:
  %v282 = ptrtoint ptr %a2 to i64
  %v283 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v284 = and i64 %v282, %v283
  %v285 = and i64 %v284, 1
  %v286 = icmp ne i64 %v285, 0
  br i1 %v286, label %yes.287, label %no.288
yes.287:
  %v290 = sub i64 %v283, 1
  %v291 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v282, i64 %v290)
  %v292 = extractvalue { i64, i1 } %v291, 0
  %v293 = extractvalue { i64, i1 } %v291, 1
  br i1 %v293, label %yes.294, label %no.295
yes.294:
  %v297 = call ptr @mlf_sub_int(ptr %a2, ptr inttoptr (i64 3 to ptr))
  br label %join.296
no.295:
  %v298 = inttoptr i64 %v292 to ptr
  br label %join.296
join.296:
  %v299 = phi ptr [ %v297, %yes.294 ], [ %v298, %no.295 ]
  br label %join.289
no.288:
  %v300 = call ptr @mlf_sub_int(ptr %a2, ptr inttoptr (i64 3 to ptr))
  br label %join.289
join.289:
  %v301 = phi ptr [ %v299, %join.296 ], [ %v300, %no.288 ]
  %v302 = getelementptr i8, ptr %a0, i64 8
  %v303 = load i64, ptr %v302, align 8, !tbaa !3
  %v304 = getelementptr i8, ptr %a0, i64 16
  %v305 = load ptr, ptr %v304, align 8, !tbaa !3
  %v306 = ptrtoint ptr %v301 to i64
  %v307 = ashr i64 %v306, 1
  %v308 = and i64 %v306, 1
  %v309 = icmp ne i64 %v308, 0
  %v310 = icmp ult i64 %v307, %v303
  %v311 = and i1 %v309, %v310
  br i1 %v311, label %array.valid.312, label %array.invalid.313
array.invalid.313:
  call void @mlf_bounds_failure()
  unreachable
array.valid.312:
  %v314 = getelementptr i64, ptr %v305, i64 %v307
  %v315 = load double, ptr %v314, align 8, !tbaa !4
  %v316 = ptrtoint ptr %a2 to i64
  %v317 = ashr i64 %v316, 1
  %v318 = and i64 %v316, 1
  %v319 = icmp ne i64 %v318, 0
  %v320 = icmp ult i64 %v317, %v303
  %v321 = and i1 %v319, %v320
  br i1 %v321, label %array.valid.322, label %array.invalid.323
array.invalid.323:
  call void @mlf_bounds_failure()
  unreachable
array.valid.322:
  %v324 = getelementptr i64, ptr %v305, i64 %v317
  %v325 = load double, ptr %v324, align 8, !tbaa !4
  %v326 = fadd double %v315, %v325
  %v327 = ptrtoint ptr %a2 to i64
  %v328 = ashr i64 %v327, 1
  %v329 = and i64 %v327, 1
  %v330 = icmp ne i64 %v329, 0
  %v331 = icmp ult i64 %v328, %v303
  %v332 = and i1 %v330, %v331
  br i1 %v332, label %array.valid.333, label %array.invalid.334
array.invalid.334:
  call void @mlf_bounds_failure()
  unreachable
array.valid.333:
  %v335 = getelementptr i64, ptr %v305, i64 %v328
  store double %v326, ptr %v335, align 8, !tbaa !4
  %v336 = ptrtoint ptr %a2 to i64
  %v337 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v338 = sub i64 %v337, 1
  %v339 = add nsw i64 %v336, %v338
  %v340 = inttoptr i64 %v339 to ptr
  %v341 = musttail call ptr @mlf.numeric.0(ptr %a0, ptr %a1, ptr %v340)
  ret ptr %v341
tail.no.281:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.code.356(ptr %env, ptr %arg) {
entry:
  %v357 = getelementptr i8, ptr %env, i64 8
  %v358 = load ptr, ptr %v357, align 8, !tbaa !3
  %v359 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v359, align 8, !tbaa !3
  %v360 = call ptr @mlf.force(ptr %v358)
  %v361 = call ptr @mlf_prim2(i64 9, ptr %v360, ptr inttoptr (i64 3 to ptr))
  ret ptr %v361
}

define private ptr @mlf.code.349(ptr %env, ptr %arg) {
entry:
  %v350 = getelementptr i8, ptr %env, i64 8
  %v351 = load ptr, ptr %v350, align 8, !tbaa !3
  %v352 = getelementptr i8, ptr %env, i64 16
  %v353 = load ptr, ptr %v352, align 8, !tbaa !3
  %v354 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v354, align 8, !tbaa !3
  %v355 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v355, align 8, !tbaa !3
  %v362 = call ptr @mlf.allocate.thunk(ptr @mlf.code.356, i64 1)
  %v363 = getelementptr i8, ptr %v362, i64 16
  %v364 = load ptr, ptr %v363, align 8, !tbaa !3
  %v365 = getelementptr i8, ptr %v364, i64 8
  store ptr %v353, ptr %v365, align 8, !tbaa !3
  %v366 = call ptr @mlf_prim2(i64 32, ptr %v351, ptr %v362)
  ret ptr %v366
}

define private ptr @mlf.code.379(ptr %env, ptr %arg) {
entry:
  %v380 = getelementptr i8, ptr %env, i64 8
  %v381 = load ptr, ptr %v380, align 8, !tbaa !3
  %v382 = getelementptr i8, ptr %env, i64 16
  %v383 = load ptr, ptr %v382, align 8, !tbaa !3
  %v384 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v384, align 8, !tbaa !3
  %v385 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v385, align 8, !tbaa !3
  %v386 = call ptr @mlf_prim2(i64 32, ptr %v381, ptr %v383)
  ret ptr %v386
}

define private ptr @mlf.code.414(ptr %env, ptr %arg) {
entry:
  %v415 = getelementptr i8, ptr %env, i64 8
  %v416 = load ptr, ptr %v415, align 8, !tbaa !3
  %v417 = getelementptr i8, ptr %env, i64 16
  %v418 = load ptr, ptr %v417, align 8, !tbaa !3
  %v419 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v419, align 8, !tbaa !3
  %v420 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v420, align 8, !tbaa !3
  %v421 = call ptr @mlf.force(ptr %v416)
  %v422 = call ptr @mlf.force(ptr %v418)
  %v423 = call ptr @mlf_prim2(i64 18, ptr %v421, ptr %v422)
  ret ptr %v423
}

define private ptr @mlf.code.401(ptr %env, ptr %arg) {
entry:
  %v402 = getelementptr i8, ptr %env, i64 8
  %v403 = load ptr, ptr %v402, align 8, !tbaa !3
  %v404 = getelementptr i8, ptr %env, i64 16
  %v405 = load ptr, ptr %v404, align 8, !tbaa !3
  %v406 = getelementptr i8, ptr %env, i64 24
  %v407 = load ptr, ptr %v406, align 8, !tbaa !3
  %v408 = getelementptr i8, ptr %env, i64 32
  %v409 = load ptr, ptr %v408, align 8, !tbaa !3
  %v410 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v410, align 8, !tbaa !3
  %v411 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v411, align 8, !tbaa !3
  %v412 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v412, align 8, !tbaa !3
  %v413 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v413, align 8, !tbaa !3
  %v424 = call ptr @mlf.allocate.thunk(ptr @mlf.code.414, i64 2)
  %v425 = getelementptr i8, ptr %v424, i64 16
  %v426 = load ptr, ptr %v425, align 8, !tbaa !3
  %v427 = getelementptr i8, ptr %v426, i64 8
  store ptr %v407, ptr %v427, align 8, !tbaa !3
  %v428 = getelementptr i8, ptr %v426, i64 16
  store ptr %v409, ptr %v428, align 8, !tbaa !3
  %v429 = call ptr @mlf_prim3(i64 33, ptr %v403, ptr %v405, ptr %v424)
  ret ptr %v429
}

define private ptr @mlf.code.437(ptr %env, ptr %arg) {
entry:
  %v438 = getelementptr i8, ptr %env, i64 8
  %v439 = load ptr, ptr %v438, align 8, !tbaa !3
  %v440 = getelementptr i8, ptr %env, i64 16
  %v441 = load ptr, ptr %v440, align 8, !tbaa !3
  %v442 = getelementptr i8, ptr %env, i64 24
  %v443 = load ptr, ptr %v442, align 8, !tbaa !3
  %v444 = call ptr @mlf.force(ptr %v441)
  %v445 = call ptr @mlf.force(ptr %v443)
  %v446 = call ptr @mlf_prim2(i64 8, ptr %v445, ptr inttoptr (i64 3 to ptr))
  %v447 = call ptr @mlf_env_new(i64 3)
  %v448 = getelementptr i8, ptr %v447, i64 8
  store ptr %v439, ptr %v448, align 8, !tbaa !3
  %v449 = getelementptr i8, ptr %v447, i64 16
  store ptr %v444, ptr %v449, align 8, !tbaa !3
  %v450 = getelementptr i8, ptr %v447, i64 24
  store ptr %v446, ptr %v450, align 8, !tbaa !3
  %v451 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.248, ptr %v447)
  ret ptr %v451
}

define private ptr @mlf.code.392(ptr %env, ptr %arg) {
entry:
  %v393 = getelementptr i8, ptr %env, i64 8
  %v394 = load ptr, ptr %v393, align 8, !tbaa !3
  %v395 = getelementptr i8, ptr %env, i64 16
  %v396 = load ptr, ptr %v395, align 8, !tbaa !3
  %v397 = getelementptr i8, ptr %env, i64 24
  %v398 = load ptr, ptr %v397, align 8, !tbaa !3
  %v399 = getelementptr i8, ptr %env, i64 32
  %v400 = load ptr, ptr %v399, align 8, !tbaa !3
  %v430 = call ptr @mlf.allocate.thunk(ptr @mlf.code.401, i64 4)
  %v431 = getelementptr i8, ptr %v430, i64 16
  %v432 = load ptr, ptr %v431, align 8, !tbaa !3
  %v433 = getelementptr i8, ptr %v432, i64 8
  store ptr %v394, ptr %v433, align 8, !tbaa !3
  %v434 = getelementptr i8, ptr %v432, i64 16
  store ptr %v398, ptr %v434, align 8, !tbaa !3
  %v435 = getelementptr i8, ptr %v432, i64 24
  store ptr %v400, ptr %v435, align 8, !tbaa !3
  %v436 = getelementptr i8, ptr %v432, i64 32
  store ptr %arg, ptr %v436, align 8, !tbaa !3
  %v452 = call ptr @mlf_env_new(i64 3)
  %v453 = getelementptr i8, ptr %v452, i64 8
  store ptr %v394, ptr %v453, align 8, !tbaa !3
  %v454 = getelementptr i8, ptr %v452, i64 16
  store ptr %v396, ptr %v454, align 8, !tbaa !3
  %v455 = getelementptr i8, ptr %v452, i64 24
  store ptr %v398, ptr %v455, align 8, !tbaa !3
  %v456 = call ptr @mlf_closure(ptr @mlf.code.437, ptr %v452)
  %v457 = call ptr @mlf_prim2(i64 1, ptr %v430, ptr %v456)
  ret ptr %v457
}

define private ptr @mlf.code.372(ptr %env, ptr %arg) {
entry:
  %v373 = getelementptr i8, ptr %env, i64 8
  %v374 = load ptr, ptr %v373, align 8, !tbaa !3
  %v375 = getelementptr i8, ptr %env, i64 16
  %v376 = load ptr, ptr %v375, align 8, !tbaa !3
  %v377 = getelementptr i8, ptr %env, i64 24
  %v378 = load ptr, ptr %v377, align 8, !tbaa !3
  %v387 = call ptr @mlf.allocate.thunk(ptr @mlf.code.379, i64 2)
  %v388 = getelementptr i8, ptr %v387, i64 16
  %v389 = load ptr, ptr %v388, align 8, !tbaa !3
  %v390 = getelementptr i8, ptr %v389, i64 8
  store ptr %v374, ptr %v390, align 8, !tbaa !3
  %v391 = getelementptr i8, ptr %v389, i64 16
  store ptr %v378, ptr %v391, align 8, !tbaa !3
  %v458 = call ptr @mlf_env_new(i64 4)
  %v459 = getelementptr i8, ptr %v458, i64 8
  store ptr %v374, ptr %v459, align 8, !tbaa !3
  %v460 = getelementptr i8, ptr %v458, i64 16
  store ptr %v376, ptr %v460, align 8, !tbaa !3
  %v461 = getelementptr i8, ptr %v458, i64 24
  store ptr %v378, ptr %v461, align 8, !tbaa !3
  %v462 = getelementptr i8, ptr %v458, i64 32
  store ptr %arg, ptr %v462, align 8, !tbaa !3
  %v463 = call ptr @mlf_closure(ptr @mlf.code.392, ptr %v458)
  %v464 = call ptr @mlf_prim2(i64 1, ptr %v387, ptr %v463)
  ret ptr %v464
}

define private ptr @mlf.worker.0(ptr %a0, ptr %a1, ptr %a2) {
entry:
  %v344 = call ptr @mlf_prim2(i64 11, ptr %a2, ptr %a1)
  %v345 = icmp eq ptr %v344, inttoptr (i64 6 to ptr)
  br i1 %v345, label %yes.346, label %no.347
yes.346:
  %v367 = call ptr @mlf.allocate.thunk(ptr @mlf.code.349, i64 2)
  %v368 = getelementptr i8, ptr %v367, i64 16
  %v369 = load ptr, ptr %v368, align 8, !tbaa !3
  %v370 = getelementptr i8, ptr %v369, i64 8
  store ptr %a0, ptr %v370, align 8, !tbaa !3
  %v371 = getelementptr i8, ptr %v369, i64 16
  store ptr %a2, ptr %v371, align 8, !tbaa !3
  %v465 = call ptr @mlf_env_new(i64 3)
  %v466 = getelementptr i8, ptr %v465, i64 8
  store ptr %a0, ptr %v466, align 8, !tbaa !3
  %v467 = getelementptr i8, ptr %v465, i64 16
  store ptr %a1, ptr %v467, align 8, !tbaa !3
  %v468 = getelementptr i8, ptr %v465, i64 24
  store ptr %a2, ptr %v468, align 8, !tbaa !3
  %v469 = call ptr @mlf_closure(ptr @mlf.code.372, ptr %v465)
  %v470 = call ptr @mlf_prim2(i64 1, ptr %v367, ptr %v469)
  br label %join.348
no.347:
  %v471 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.348
join.348:
  %v472 = phi ptr [ %v470, %yes.346 ], [ %v471, %no.347 ]
  ret ptr %v472
}

define private ptr @mlf.numeric.entry.248(ptr %env, ptr %arg) {
entry:
  %v249 = getelementptr i8, ptr %env, i64 8
  %v250 = load ptr, ptr %v249, align 8, !tbaa !3
  %v251 = getelementptr i8, ptr %env, i64 16
  %v252 = load ptr, ptr %v251, align 8, !tbaa !3
  %v253 = getelementptr i8, ptr %env, i64 24
  %v254 = load ptr, ptr %v253, align 8, !tbaa !3
  %v255 = call ptr @mlf_peek(ptr %v250)
  %v256 = call ptr @mlf_peek(ptr %v252)
  %v257 = call ptr @mlf_peek(ptr %v254)
  %v258 = icmp ne ptr %v255, null
  %v259 = icmp ne ptr %v256, null
  %v260 = icmp ne ptr %v257, null
  %v261 = and i1 true, %v258
  %v262 = and i1 %v261, %v259
  %v263 = and i1 %v262, %v260
  br i1 %v263, label %yes.264, label %no.265
yes.264:
  %v342 = call ptr @mlf.numeric.0(ptr %v255, ptr %v256, ptr %v257)
  %v343 = call ptr @mlf_prim1(i64 0, ptr %v342)
  br label %join.266
no.265:
  %v473 = call ptr @mlf.force(ptr %v252)
  %v474 = call ptr @mlf.force(ptr %v254)
  %v475 = call ptr @mlf.worker.0(ptr %v250, ptr %v473, ptr %v474)
  br label %join.266
join.266:
  %v476 = phi ptr [ %v343, %yes.264 ], [ %v475, %no.265 ]
  ret ptr %v476
}

define private ptr @mlf.code.244(ptr %env, ptr %arg) {
entry:
  %v245 = getelementptr i8, ptr %env, i64 8
  %v246 = load ptr, ptr %v245, align 8, !tbaa !3
  %v247 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v247, align 8, !tbaa !3
  %v477 = call ptr @mlf_env_new(i64 3)
  %v478 = getelementptr i8, ptr %v477, i64 8
  store ptr %v246, ptr %v478, align 8, !tbaa !3
  %v479 = getelementptr i8, ptr %v477, i64 16
  store ptr inttoptr (i64 31 to ptr), ptr %v479, align 8, !tbaa !3
  %v480 = getelementptr i8, ptr %v477, i64 24
  store ptr inttoptr (i64 3 to ptr), ptr %v480, align 8, !tbaa !3
  %v481 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.248, ptr %v477)
  ret ptr %v481
}

define private ptr @mlf.code.499(ptr %env, ptr %arg) {
entry:
  %v500 = getelementptr i8, ptr %env, i64 8
  %v501 = load ptr, ptr %v500, align 8, !tbaa !3
  %v502 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v502, align 8, !tbaa !3
  %v503 = call ptr @mlf_env_new(i64 3)
  %v504 = getelementptr i8, ptr %v503, i64 8
  store ptr %v501, ptr %v504, align 8, !tbaa !3
  %v505 = getelementptr i8, ptr %v503, i64 16
  store ptr inttoptr (i64 9 to ptr), ptr %v505, align 8, !tbaa !3
  %v506 = getelementptr i8, ptr %v503, i64 24
  store ptr inttoptr (i64 3 to ptr), ptr %v506, align 8, !tbaa !3
  %v507 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.248, ptr %v503)
  ret ptr %v507
}

define private ptr @mlf.code.525(ptr %env, ptr %arg) {
entry:
  %v526 = call ptr @mlf_prim2(i64 35, ptr inttoptr (i64 124929 to ptr), ptr inttoptr (i64 1 to ptr))
  ret ptr %v526
}

define private ptr @mlf.code.541(ptr %env, ptr %arg) {
entry:
  %v542 = call ptr @mlf_prim2(i64 27, ptr inttoptr (i64 3 to ptr), ptr inttoptr (i64 85 to ptr))
  ret ptr %v542
}

define private ptr @mlf.code.559(ptr %env, ptr %arg) {
entry:
  %v560 = call ptr @mlf_double(double 0x0000000000000000)
  %v561 = call ptr @mlf_prim2(i64 31, ptr inttoptr (i64 3 to ptr), ptr %v560)
  ret ptr %v561
}

define private ptr @mlf.code.580(ptr %env, ptr %arg) {
entry:
  %v581 = getelementptr i8, ptr %env, i64 8
  %v582 = load ptr, ptr %v581, align 8, !tbaa !3
  %v583 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v583, align 8, !tbaa !3
  %v584 = call ptr @mlf_prim1(i64 38, ptr %v582)
  ret ptr %v584
}

define private ptr @mlf.code.608(ptr %env, ptr %arg) {
entry:
  %v610 = call ptr @mlf_prim1(i64 3, ptr @mlf.bytes.609.value)
  ret ptr %v610
}

define private ptr @mlf.numeric.16.ppiiiiii(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6, ptr %a7) alwaysinline {
entry:
  %v745 = ptrtoint ptr %a6 to i64
  %v746 = ptrtoint ptr %a7 to i64
  %v747 = sub i64 %v746, 1
  %v748 = add nsw i64 %v745, %v747
  %v749 = inttoptr i64 %v748 to ptr
  %v750 = ptrtoint ptr %a5 to i64
  %v751 = ptrtoint ptr %v749 to i64
  %v752 = sub i64 %v751, 1
  %v753 = add nsw i64 %v750, %v752
  %v754 = inttoptr i64 %v753 to ptr
  %v755 = ptrtoint ptr %a4 to i64
  %v756 = ptrtoint ptr %v754 to i64
  %v757 = sub i64 %v756, 1
  %v758 = add nsw i64 %v755, %v757
  %v759 = inttoptr i64 %v758 to ptr
  %v760 = icmp eq ptr inttoptr (i64 6 to ptr), inttoptr (i64 6 to ptr)
  br i1 %v760, label %tail.yes.761, label %tail.no.762
tail.yes.761:
  %v763 = ptrtoint ptr %a6 to i64
  %v764 = ptrtoint ptr inttoptr (i64 121 to ptr) to i64
  %v765 = icmp eq i64 %v763, %v764
  %v766 = select i1 %v765, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v767 = icmp eq ptr %v766, inttoptr (i64 6 to ptr)
  br i1 %v767, label %tail.yes.768, label %tail.no.769
tail.yes.768:
  %v770 = getelementptr i8, ptr %a1, i64 8
  %v771 = load i64, ptr %v770, align 8, !tbaa !3
  %v772 = getelementptr i8, ptr %a1, i64 16
  %v773 = load ptr, ptr %v772, align 8, !tbaa !3
  %v774 = ptrtoint ptr %a7 to i64
  %v775 = ashr i64 %v774, 1
  %v776 = and i64 %v774, 1
  %v777 = icmp ne i64 %v776, 0
  %v778 = icmp ult i64 %v775, %v771
  %v779 = and i1 %v777, %v778
  br i1 %v779, label %array.valid.780, label %array.invalid.781
array.invalid.781:
  call void @mlf_bounds_failure()
  unreachable
array.valid.780:
  %v782 = getelementptr i8, ptr %v773, i64 %v775
  %v783 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v784 = ashr i64 %v783, 1
  %v785 = trunc i64 %v784 to i8
  store i8 %v785, ptr %v782, align 1, !tbaa !4
  %v786 = ptrtoint ptr %a7 to i64
  %v787 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v788 = sub i64 %v787, 1
  %v789 = add nsw i64 %v786, %v788
  %v790 = inttoptr i64 %v789 to ptr
  %v791 = musttail call ptr @mlf.numeric.16.ppppppnp(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr inttoptr (i64 1 to ptr), ptr %v790)
  ret ptr %v791
tail.no.769:
  %v792 = ptrtoint ptr %a4 to i64
  %v793 = ptrtoint ptr %a3 to i64
  %v794 = icmp eq i64 %v792, %v793
  %v795 = select i1 %v794, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v796 = icmp eq ptr %v795, inttoptr (i64 6 to ptr)
  br i1 %v796, label %tail.yes.797, label %tail.no.798
tail.yes.797:
  %v799 = ptrtoint ptr %a6 to i64
  %v800 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v801 = icmp eq i64 %v799, %v800
  %v802 = select i1 %v801, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v803 = icmp eq ptr %v802, inttoptr (i64 6 to ptr)
  br i1 %v803, label %tail.yes.804, label %tail.no.805
tail.yes.804:
  ret ptr %a5
tail.no.805:
  %v806 = getelementptr i8, ptr %a1, i64 8
  %v807 = load i64, ptr %v806, align 8, !tbaa !3
  %v808 = getelementptr i8, ptr %a1, i64 16
  %v809 = load ptr, ptr %v808, align 8, !tbaa !3
  %v810 = ptrtoint ptr %a7 to i64
  %v811 = ashr i64 %v810, 1
  %v812 = and i64 %v810, 1
  %v813 = icmp ne i64 %v812, 0
  %v814 = icmp ult i64 %v811, %v807
  %v815 = and i1 %v813, %v814
  br i1 %v815, label %array.valid.816, label %array.invalid.817
array.invalid.817:
  call void @mlf_bounds_failure()
  unreachable
array.valid.816:
  %v818 = getelementptr i8, ptr %v809, i64 %v811
  %v819 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v820 = ashr i64 %v819, 1
  %v821 = trunc i64 %v820 to i8
  store i8 %v821, ptr %v818, align 1, !tbaa !4
  ret ptr %a5
tail.no.798:
  %v822 = getelementptr i8, ptr %a0, i64 8
  %v823 = load i64, ptr %v822, align 8, !tbaa !3
  %v824 = getelementptr i8, ptr %a0, i64 16
  %v825 = load ptr, ptr %v824, align 8, !tbaa !3
  %v826 = ptrtoint ptr %a5 to i64
  %v827 = ashr i64 %v826, 1
  %v828 = and i64 %v826, 1
  %v829 = icmp ne i64 %v828, 0
  %v830 = icmp ult i64 %v827, %v823
  %v831 = and i1 %v829, %v830
  br i1 %v831, label %array.valid.832, label %array.invalid.833
array.invalid.833:
  call void @mlf_bounds_failure()
  unreachable
array.valid.832:
  %v834 = getelementptr i8, ptr %v825, i64 %v827
  %v835 = load i8, ptr %v834, align 1, !tbaa !4
  %v836 = zext i8 %v835 to i64
  %v837 = shl i64 %v836, 1
  %v838 = or i64 %v837, 1
  %v839 = inttoptr i64 %v838 to ptr
  %v840 = getelementptr i8, ptr %a1, i64 8
  %v841 = load i64, ptr %v840, align 8, !tbaa !3
  %v842 = getelementptr i8, ptr %a1, i64 16
  %v843 = load ptr, ptr %v842, align 8, !tbaa !3
  %v844 = ptrtoint ptr %a7 to i64
  %v845 = ashr i64 %v844, 1
  %v846 = and i64 %v844, 1
  %v847 = icmp ne i64 %v846, 0
  %v848 = icmp ult i64 %v845, %v841
  %v849 = and i1 %v847, %v848
  br i1 %v849, label %array.valid.850, label %array.invalid.851
array.invalid.851:
  call void @mlf_bounds_failure()
  unreachable
array.valid.850:
  %v852 = getelementptr i8, ptr %v843, i64 %v845
  %v853 = ptrtoint ptr %v839 to i64
  %v854 = ashr i64 %v853, 1
  %v855 = trunc i64 %v854 to i8
  store i8 %v855, ptr %v852, align 1, !tbaa !4
  %v856 = ptrtoint ptr %a5 to i64
  %v857 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v858 = sub i64 %v857, 1
  %v859 = add nsw i64 %v856, %v858
  %v860 = inttoptr i64 %v859 to ptr
  %v861 = ptrtoint ptr %v860 to i64
  %v862 = ptrtoint ptr %a2 to i64
  %v863 = icmp slt i64 %v861, %v862
  %v864 = select i1 %v863, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v865 = icmp eq ptr %v864, inttoptr (i64 6 to ptr)
  br i1 %v865, label %yes.866, label %no.867
yes.866:
  %v869 = ptrtoint ptr %a5 to i64
  %v870 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v871 = sub i64 %v870, 1
  %v872 = add nsw i64 %v869, %v871
  %v873 = inttoptr i64 %v872 to ptr
  br label %join.868
no.867:
  br label %join.868
join.868:
  %v874 = phi ptr [ %v873, %yes.866 ], [ inttoptr (i64 1 to ptr), %no.867 ]
  %v875 = ptrtoint ptr %a4 to i64
  %v876 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v877 = sub i64 %v876, 1
  %v878 = add nsw i64 %v875, %v877
  %v879 = inttoptr i64 %v878 to ptr
  %v880 = ptrtoint ptr %a6 to i64
  %v881 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v882 = sub i64 %v881, 1
  %v883 = add nsw i64 %v880, %v882
  %v884 = inttoptr i64 %v883 to ptr
  %v885 = ptrtoint ptr %a7 to i64
  %v886 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v887 = sub i64 %v886, 1
  %v888 = add nsw i64 %v885, %v887
  %v889 = inttoptr i64 %v888 to ptr
  %v890 = musttail call ptr @mlf.numeric.16.ppppppnp(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %v879, ptr %v874, ptr %v884, ptr %v889)
  ret ptr %v890
tail.no.762:
  ret ptr inttoptr (i64 1 to ptr)
}

define private ptr @mlf.numeric.16(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6, ptr %a7) alwaysinline {
entry:
  %v1128 = ptrtoint ptr %a2 to i64
  %v1129 = and i64 %v1128, 1
  %v1130 = icmp ne i64 %v1129, 0
  %v1131 = icmp ult i64 %v1128, 4294967296
  %v1132 = and i1 %v1130, %v1131
  %v1133 = ptrtoint ptr %a3 to i64
  %v1134 = and i64 %v1133, 1
  %v1135 = icmp ne i64 %v1134, 0
  %v1136 = icmp ult i64 %v1133, 4294967296
  %v1137 = and i1 %v1135, %v1136
  %v1138 = ptrtoint ptr %a4 to i64
  %v1139 = and i64 %v1138, 1
  %v1140 = icmp ne i64 %v1139, 0
  %v1141 = icmp ult i64 %v1138, 4294967296
  %v1142 = and i1 %v1140, %v1141
  %v1143 = ptrtoint ptr %a5 to i64
  %v1144 = and i64 %v1143, 1
  %v1145 = icmp ne i64 %v1144, 0
  %v1146 = icmp ult i64 %v1143, 4294967296
  %v1147 = and i1 %v1145, %v1146
  %v1148 = ptrtoint ptr %a6 to i64
  %v1149 = and i64 %v1148, 1
  %v1150 = icmp ne i64 %v1149, 0
  %v1151 = icmp ult i64 %v1148, 4294967296
  %v1152 = and i1 %v1150, %v1151
  %v1153 = ptrtoint ptr %a7 to i64
  %v1154 = and i64 %v1153, 1
  %v1155 = icmp ne i64 %v1154, 0
  %v1156 = icmp ult i64 %v1153, 4294967296
  %v1157 = and i1 %v1155, %v1156
  %v1158 = and i1 true, %v1132
  %v1159 = and i1 %v1158, %v1137
  %v1160 = and i1 %v1159, %v1142
  %v1161 = and i1 %v1160, %v1147
  %v1162 = and i1 %v1161, %v1152
  %v1163 = and i1 %v1162, %v1157
  br i1 %v1163, label %range.fast.1164, label %range.general.1165
range.fast.1164:
  %v1166 = musttail call ptr @mlf.numeric.16.ppiiiiii(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6, ptr %a7)
  ret ptr %v1166
range.general.1165:
  %v1167 = ptrtoint ptr %a6 to i64
  %v1168 = ptrtoint ptr %a7 to i64
  %v1169 = and i64 %v1167, %v1168
  %v1170 = and i64 %v1169, 1
  %v1171 = icmp ne i64 %v1170, 0
  br i1 %v1171, label %yes.1172, label %no.1173
yes.1172:
  %v1175 = sub i64 %v1168, 1
  %v1176 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1167, i64 %v1175)
  %v1177 = extractvalue { i64, i1 } %v1176, 0
  %v1178 = extractvalue { i64, i1 } %v1176, 1
  br i1 %v1178, label %yes.1179, label %no.1180
yes.1179:
  %v1182 = call ptr @mlf_add_int(ptr %a6, ptr %a7)
  br label %join.1181
no.1180:
  %v1183 = inttoptr i64 %v1177 to ptr
  br label %join.1181
join.1181:
  %v1184 = phi ptr [ %v1182, %yes.1179 ], [ %v1183, %no.1180 ]
  br label %join.1174
no.1173:
  %v1185 = call ptr @mlf_add_int(ptr %a6, ptr %a7)
  br label %join.1174
join.1174:
  %v1186 = phi ptr [ %v1184, %join.1181 ], [ %v1185, %no.1173 ]
  %v1187 = ptrtoint ptr %a5 to i64
  %v1188 = ptrtoint ptr %v1186 to i64
  %v1189 = and i64 %v1187, %v1188
  %v1190 = and i64 %v1189, 1
  %v1191 = icmp ne i64 %v1190, 0
  br i1 %v1191, label %yes.1192, label %no.1193
yes.1192:
  %v1195 = sub i64 %v1188, 1
  %v1196 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1187, i64 %v1195)
  %v1197 = extractvalue { i64, i1 } %v1196, 0
  %v1198 = extractvalue { i64, i1 } %v1196, 1
  br i1 %v1198, label %yes.1199, label %no.1200
yes.1199:
  %v1202 = call ptr @mlf_add_int(ptr %a5, ptr %v1186)
  br label %join.1201
no.1200:
  %v1203 = inttoptr i64 %v1197 to ptr
  br label %join.1201
join.1201:
  %v1204 = phi ptr [ %v1202, %yes.1199 ], [ %v1203, %no.1200 ]
  br label %join.1194
no.1193:
  %v1205 = call ptr @mlf_add_int(ptr %a5, ptr %v1186)
  br label %join.1194
join.1194:
  %v1206 = phi ptr [ %v1204, %join.1201 ], [ %v1205, %no.1193 ]
  %v1207 = ptrtoint ptr %a4 to i64
  %v1208 = ptrtoint ptr %v1206 to i64
  %v1209 = and i64 %v1207, %v1208
  %v1210 = and i64 %v1209, 1
  %v1211 = icmp ne i64 %v1210, 0
  br i1 %v1211, label %yes.1212, label %no.1213
yes.1212:
  %v1215 = sub i64 %v1208, 1
  %v1216 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1207, i64 %v1215)
  %v1217 = extractvalue { i64, i1 } %v1216, 0
  %v1218 = extractvalue { i64, i1 } %v1216, 1
  br i1 %v1218, label %yes.1219, label %no.1220
yes.1219:
  %v1222 = call ptr @mlf_add_int(ptr %a4, ptr %v1206)
  br label %join.1221
no.1220:
  %v1223 = inttoptr i64 %v1217 to ptr
  br label %join.1221
join.1221:
  %v1224 = phi ptr [ %v1222, %yes.1219 ], [ %v1223, %no.1220 ]
  br label %join.1214
no.1213:
  %v1225 = call ptr @mlf_add_int(ptr %a4, ptr %v1206)
  br label %join.1214
join.1214:
  %v1226 = phi ptr [ %v1224, %join.1221 ], [ %v1225, %no.1213 ]
  %v1227 = icmp eq ptr inttoptr (i64 6 to ptr), inttoptr (i64 6 to ptr)
  br i1 %v1227, label %tail.yes.1228, label %tail.no.1229
tail.yes.1228:
  %v1230 = ptrtoint ptr %a6 to i64
  %v1231 = ptrtoint ptr inttoptr (i64 121 to ptr) to i64
  %v1232 = and i64 %v1230, %v1231
  %v1233 = and i64 %v1232, 1
  %v1234 = icmp ne i64 %v1233, 0
  br i1 %v1234, label %yes.1235, label %no.1236
yes.1235:
  %v1238 = icmp eq i64 %v1230, %v1231
  %v1239 = select i1 %v1238, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1237
no.1236:
  %v1240 = call ptr @mlf_eq_int(ptr %a6, ptr inttoptr (i64 121 to ptr))
  br label %join.1237
join.1237:
  %v1241 = phi ptr [ %v1239, %yes.1235 ], [ %v1240, %no.1236 ]
  %v1242 = icmp eq ptr %v1241, inttoptr (i64 6 to ptr)
  br i1 %v1242, label %tail.yes.1243, label %tail.no.1244
tail.yes.1243:
  %v1245 = getelementptr i8, ptr %a1, i64 8
  %v1246 = load i64, ptr %v1245, align 8, !tbaa !3
  %v1247 = getelementptr i8, ptr %a1, i64 16
  %v1248 = load ptr, ptr %v1247, align 8, !tbaa !3
  %v1249 = ptrtoint ptr %a7 to i64
  %v1250 = ashr i64 %v1249, 1
  %v1251 = and i64 %v1249, 1
  %v1252 = icmp ne i64 %v1251, 0
  %v1253 = icmp ult i64 %v1250, %v1246
  %v1254 = and i1 %v1252, %v1253
  br i1 %v1254, label %array.valid.1255, label %array.invalid.1256
array.invalid.1256:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1255:
  %v1257 = getelementptr i8, ptr %v1248, i64 %v1250
  %v1258 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v1259 = ashr i64 %v1258, 1
  %v1260 = trunc i64 %v1259 to i8
  store i8 %v1260, ptr %v1257, align 1, !tbaa !4
  %v1261 = ptrtoint ptr %a7 to i64
  %v1262 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1263 = sub i64 %v1262, 1
  %v1264 = add nsw i64 %v1261, %v1263
  %v1265 = inttoptr i64 %v1264 to ptr
  %v1266 = musttail call ptr @mlf.numeric.16.ppppppnp(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr inttoptr (i64 1 to ptr), ptr %v1265)
  ret ptr %v1266
tail.no.1244:
  %v1267 = ptrtoint ptr %a4 to i64
  %v1268 = ptrtoint ptr %a3 to i64
  %v1269 = and i64 %v1267, %v1268
  %v1270 = and i64 %v1269, 1
  %v1271 = icmp ne i64 %v1270, 0
  br i1 %v1271, label %yes.1272, label %no.1273
yes.1272:
  %v1275 = icmp eq i64 %v1267, %v1268
  %v1276 = select i1 %v1275, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1274
no.1273:
  %v1277 = call ptr @mlf_eq_int(ptr %a4, ptr %a3)
  br label %join.1274
join.1274:
  %v1278 = phi ptr [ %v1276, %yes.1272 ], [ %v1277, %no.1273 ]
  %v1279 = icmp eq ptr %v1278, inttoptr (i64 6 to ptr)
  br i1 %v1279, label %tail.yes.1280, label %tail.no.1281
tail.yes.1280:
  %v1282 = ptrtoint ptr %a6 to i64
  %v1283 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v1284 = and i64 %v1282, %v1283
  %v1285 = and i64 %v1284, 1
  %v1286 = icmp ne i64 %v1285, 0
  br i1 %v1286, label %yes.1287, label %no.1288
yes.1287:
  %v1290 = icmp eq i64 %v1282, %v1283
  %v1291 = select i1 %v1290, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1289
no.1288:
  %v1292 = call ptr @mlf_eq_int(ptr %a6, ptr inttoptr (i64 1 to ptr))
  br label %join.1289
join.1289:
  %v1293 = phi ptr [ %v1291, %yes.1287 ], [ %v1292, %no.1288 ]
  %v1294 = icmp eq ptr %v1293, inttoptr (i64 6 to ptr)
  br i1 %v1294, label %tail.yes.1295, label %tail.no.1296
tail.yes.1295:
  ret ptr %a5
tail.no.1296:
  %v1297 = getelementptr i8, ptr %a1, i64 8
  %v1298 = load i64, ptr %v1297, align 8, !tbaa !3
  %v1299 = getelementptr i8, ptr %a1, i64 16
  %v1300 = load ptr, ptr %v1299, align 8, !tbaa !3
  %v1301 = ptrtoint ptr %a7 to i64
  %v1302 = ashr i64 %v1301, 1
  %v1303 = and i64 %v1301, 1
  %v1304 = icmp ne i64 %v1303, 0
  %v1305 = icmp ult i64 %v1302, %v1298
  %v1306 = and i1 %v1304, %v1305
  br i1 %v1306, label %array.valid.1307, label %array.invalid.1308
array.invalid.1308:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1307:
  %v1309 = getelementptr i8, ptr %v1300, i64 %v1302
  %v1310 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v1311 = ashr i64 %v1310, 1
  %v1312 = trunc i64 %v1311 to i8
  store i8 %v1312, ptr %v1309, align 1, !tbaa !4
  ret ptr %a5
tail.no.1281:
  %v1313 = getelementptr i8, ptr %a0, i64 8
  %v1314 = load i64, ptr %v1313, align 8, !tbaa !3
  %v1315 = getelementptr i8, ptr %a0, i64 16
  %v1316 = load ptr, ptr %v1315, align 8, !tbaa !3
  %v1317 = ptrtoint ptr %a5 to i64
  %v1318 = ashr i64 %v1317, 1
  %v1319 = and i64 %v1317, 1
  %v1320 = icmp ne i64 %v1319, 0
  %v1321 = icmp ult i64 %v1318, %v1314
  %v1322 = and i1 %v1320, %v1321
  br i1 %v1322, label %array.valid.1323, label %array.invalid.1324
array.invalid.1324:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1323:
  %v1325 = getelementptr i8, ptr %v1316, i64 %v1318
  %v1326 = load i8, ptr %v1325, align 1, !tbaa !4
  %v1327 = zext i8 %v1326 to i64
  %v1328 = shl i64 %v1327, 1
  %v1329 = or i64 %v1328, 1
  %v1330 = inttoptr i64 %v1329 to ptr
  %v1331 = getelementptr i8, ptr %a1, i64 8
  %v1332 = load i64, ptr %v1331, align 8, !tbaa !3
  %v1333 = getelementptr i8, ptr %a1, i64 16
  %v1334 = load ptr, ptr %v1333, align 8, !tbaa !3
  %v1335 = ptrtoint ptr %a7 to i64
  %v1336 = ashr i64 %v1335, 1
  %v1337 = and i64 %v1335, 1
  %v1338 = icmp ne i64 %v1337, 0
  %v1339 = icmp ult i64 %v1336, %v1332
  %v1340 = and i1 %v1338, %v1339
  br i1 %v1340, label %array.valid.1341, label %array.invalid.1342
array.invalid.1342:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1341:
  %v1343 = getelementptr i8, ptr %v1334, i64 %v1336
  %v1344 = ptrtoint ptr %v1330 to i64
  %v1345 = ashr i64 %v1344, 1
  %v1346 = trunc i64 %v1345 to i8
  store i8 %v1346, ptr %v1343, align 1, !tbaa !4
  %v1347 = ptrtoint ptr %a5 to i64
  %v1348 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1349 = sub i64 %v1348, 1
  %v1350 = add nsw i64 %v1347, %v1349
  %v1351 = inttoptr i64 %v1350 to ptr
  %v1352 = ptrtoint ptr %v1351 to i64
  %v1353 = ptrtoint ptr %a2 to i64
  %v1354 = and i64 %v1352, %v1353
  %v1355 = and i64 %v1354, 1
  %v1356 = icmp ne i64 %v1355, 0
  br i1 %v1356, label %yes.1357, label %no.1358
yes.1357:
  %v1360 = icmp slt i64 %v1352, %v1353
  %v1361 = select i1 %v1360, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1359
no.1358:
  %v1362 = call ptr @mlf_lt_int(ptr %v1351, ptr %a2)
  br label %join.1359
join.1359:
  %v1363 = phi ptr [ %v1361, %yes.1357 ], [ %v1362, %no.1358 ]
  %v1364 = icmp eq ptr %v1363, inttoptr (i64 6 to ptr)
  br i1 %v1364, label %yes.1365, label %no.1366
yes.1365:
  %v1368 = ptrtoint ptr %a5 to i64
  %v1369 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1370 = sub i64 %v1369, 1
  %v1371 = add nsw i64 %v1368, %v1370
  %v1372 = inttoptr i64 %v1371 to ptr
  br label %join.1367
no.1366:
  br label %join.1367
join.1367:
  %v1373 = phi ptr [ %v1372, %yes.1365 ], [ inttoptr (i64 1 to ptr), %no.1366 ]
  %v1374 = ptrtoint ptr %a4 to i64
  %v1375 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1376 = and i64 %v1374, %v1375
  %v1377 = and i64 %v1376, 1
  %v1378 = icmp ne i64 %v1377, 0
  br i1 %v1378, label %yes.1379, label %no.1380
yes.1379:
  %v1382 = sub i64 %v1375, 1
  %v1383 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1374, i64 %v1382)
  %v1384 = extractvalue { i64, i1 } %v1383, 0
  %v1385 = extractvalue { i64, i1 } %v1383, 1
  br i1 %v1385, label %yes.1386, label %no.1387
yes.1386:
  %v1389 = call ptr @mlf_add_int(ptr %a4, ptr inttoptr (i64 3 to ptr))
  br label %join.1388
no.1387:
  %v1390 = inttoptr i64 %v1384 to ptr
  br label %join.1388
join.1388:
  %v1391 = phi ptr [ %v1389, %yes.1386 ], [ %v1390, %no.1387 ]
  br label %join.1381
no.1380:
  %v1392 = call ptr @mlf_add_int(ptr %a4, ptr inttoptr (i64 3 to ptr))
  br label %join.1381
join.1381:
  %v1393 = phi ptr [ %v1391, %join.1388 ], [ %v1392, %no.1380 ]
  %v1394 = ptrtoint ptr %a6 to i64
  %v1395 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1396 = and i64 %v1394, %v1395
  %v1397 = and i64 %v1396, 1
  %v1398 = icmp ne i64 %v1397, 0
  br i1 %v1398, label %yes.1399, label %no.1400
yes.1399:
  %v1402 = sub i64 %v1395, 1
  %v1403 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1394, i64 %v1402)
  %v1404 = extractvalue { i64, i1 } %v1403, 0
  %v1405 = extractvalue { i64, i1 } %v1403, 1
  br i1 %v1405, label %yes.1406, label %no.1407
yes.1406:
  %v1409 = call ptr @mlf_add_int(ptr %a6, ptr inttoptr (i64 3 to ptr))
  br label %join.1408
no.1407:
  %v1410 = inttoptr i64 %v1404 to ptr
  br label %join.1408
join.1408:
  %v1411 = phi ptr [ %v1409, %yes.1406 ], [ %v1410, %no.1407 ]
  br label %join.1401
no.1400:
  %v1412 = call ptr @mlf_add_int(ptr %a6, ptr inttoptr (i64 3 to ptr))
  br label %join.1401
join.1401:
  %v1413 = phi ptr [ %v1411, %join.1408 ], [ %v1412, %no.1400 ]
  %v1414 = ptrtoint ptr %a7 to i64
  %v1415 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1416 = sub i64 %v1415, 1
  %v1417 = add nsw i64 %v1414, %v1416
  %v1418 = inttoptr i64 %v1417 to ptr
  %v1419 = musttail call ptr @mlf.numeric.16(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %v1393, ptr %v1373, ptr %v1413, ptr %v1418)
  ret ptr %v1419
tail.no.1229:
  ret ptr inttoptr (i64 1 to ptr)
}

define private ptr @mlf.numeric.16.ppppppnp(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6, ptr %a7) alwaysinline {
entry:
  %v707 = ptrtoint ptr %a2 to i64
  %v708 = and i64 %v707, 1
  %v709 = icmp ne i64 %v708, 0
  %v710 = icmp ult i64 %v707, 4294967296
  %v711 = and i1 %v709, %v710
  %v712 = ptrtoint ptr %a3 to i64
  %v713 = and i64 %v712, 1
  %v714 = icmp ne i64 %v713, 0
  %v715 = icmp ult i64 %v712, 4294967296
  %v716 = and i1 %v714, %v715
  %v717 = ptrtoint ptr %a4 to i64
  %v718 = and i64 %v717, 1
  %v719 = icmp ne i64 %v718, 0
  %v720 = icmp ult i64 %v717, 4294967296
  %v721 = and i1 %v719, %v720
  %v722 = ptrtoint ptr %a5 to i64
  %v723 = and i64 %v722, 1
  %v724 = icmp ne i64 %v723, 0
  %v725 = icmp ult i64 %v722, 4294967296
  %v726 = and i1 %v724, %v725
  %v727 = ptrtoint ptr %a6 to i64
  %v728 = and i64 %v727, 1
  %v729 = icmp ne i64 %v728, 0
  %v730 = icmp ult i64 %v727, 4294967296
  %v731 = and i1 %v729, %v730
  %v732 = ptrtoint ptr %a7 to i64
  %v733 = and i64 %v732, 1
  %v734 = icmp ne i64 %v733, 0
  %v735 = icmp ult i64 %v732, 4294967296
  %v736 = and i1 %v734, %v735
  %v737 = and i1 true, %v711
  %v738 = and i1 %v737, %v716
  %v739 = and i1 %v738, %v721
  %v740 = and i1 %v739, %v726
  %v741 = and i1 %v740, %v731
  %v742 = and i1 %v741, %v736
  br i1 %v742, label %range.fast.743, label %range.general.744
range.fast.743:
  %v891 = musttail call ptr @mlf.numeric.16.ppiiiiii(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6, ptr %a7)
  ret ptr %v891
range.general.744:
  %v892 = ptrtoint ptr %a6 to i64
  %v893 = ptrtoint ptr %a7 to i64
  %v894 = and i64 %v892, %v893
  %v895 = and i64 %v894, 1
  %v896 = icmp ne i64 %v895, 0
  br i1 %v896, label %yes.897, label %no.898
yes.897:
  %v900 = sub i64 %v893, 1
  %v901 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v892, i64 %v900)
  %v902 = extractvalue { i64, i1 } %v901, 0
  %v903 = extractvalue { i64, i1 } %v901, 1
  br i1 %v903, label %yes.904, label %no.905
yes.904:
  %v907 = call ptr @mlf_add_int(ptr %a6, ptr %a7)
  br label %join.906
no.905:
  %v908 = inttoptr i64 %v902 to ptr
  br label %join.906
join.906:
  %v909 = phi ptr [ %v907, %yes.904 ], [ %v908, %no.905 ]
  br label %join.899
no.898:
  %v910 = call ptr @mlf_add_int(ptr %a6, ptr %a7)
  br label %join.899
join.899:
  %v911 = phi ptr [ %v909, %join.906 ], [ %v910, %no.898 ]
  %v912 = ptrtoint ptr %a5 to i64
  %v913 = ptrtoint ptr %v911 to i64
  %v914 = and i64 %v912, %v913
  %v915 = and i64 %v914, 1
  %v916 = icmp ne i64 %v915, 0
  br i1 %v916, label %yes.917, label %no.918
yes.917:
  %v920 = sub i64 %v913, 1
  %v921 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v912, i64 %v920)
  %v922 = extractvalue { i64, i1 } %v921, 0
  %v923 = extractvalue { i64, i1 } %v921, 1
  br i1 %v923, label %yes.924, label %no.925
yes.924:
  %v927 = call ptr @mlf_add_int(ptr %a5, ptr %v911)
  br label %join.926
no.925:
  %v928 = inttoptr i64 %v922 to ptr
  br label %join.926
join.926:
  %v929 = phi ptr [ %v927, %yes.924 ], [ %v928, %no.925 ]
  br label %join.919
no.918:
  %v930 = call ptr @mlf_add_int(ptr %a5, ptr %v911)
  br label %join.919
join.919:
  %v931 = phi ptr [ %v929, %join.926 ], [ %v930, %no.918 ]
  %v932 = ptrtoint ptr %a4 to i64
  %v933 = ptrtoint ptr %v931 to i64
  %v934 = and i64 %v932, %v933
  %v935 = and i64 %v934, 1
  %v936 = icmp ne i64 %v935, 0
  br i1 %v936, label %yes.937, label %no.938
yes.937:
  %v940 = sub i64 %v933, 1
  %v941 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v932, i64 %v940)
  %v942 = extractvalue { i64, i1 } %v941, 0
  %v943 = extractvalue { i64, i1 } %v941, 1
  br i1 %v943, label %yes.944, label %no.945
yes.944:
  %v947 = call ptr @mlf_add_int(ptr %a4, ptr %v931)
  br label %join.946
no.945:
  %v948 = inttoptr i64 %v942 to ptr
  br label %join.946
join.946:
  %v949 = phi ptr [ %v947, %yes.944 ], [ %v948, %no.945 ]
  br label %join.939
no.938:
  %v950 = call ptr @mlf_add_int(ptr %a4, ptr %v931)
  br label %join.939
join.939:
  %v951 = phi ptr [ %v949, %join.946 ], [ %v950, %no.938 ]
  %v952 = icmp eq ptr inttoptr (i64 6 to ptr), inttoptr (i64 6 to ptr)
  br i1 %v952, label %tail.yes.953, label %tail.no.954
tail.yes.953:
  %v955 = ptrtoint ptr %a6 to i64
  %v956 = ptrtoint ptr inttoptr (i64 121 to ptr) to i64
  %v957 = icmp eq i64 %v955, %v956
  %v958 = select i1 %v957, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v959 = icmp eq ptr %v958, inttoptr (i64 6 to ptr)
  br i1 %v959, label %tail.yes.960, label %tail.no.961
tail.yes.960:
  %v962 = getelementptr i8, ptr %a1, i64 8
  %v963 = load i64, ptr %v962, align 8, !tbaa !3
  %v964 = getelementptr i8, ptr %a1, i64 16
  %v965 = load ptr, ptr %v964, align 8, !tbaa !3
  %v966 = ptrtoint ptr %a7 to i64
  %v967 = ashr i64 %v966, 1
  %v968 = and i64 %v966, 1
  %v969 = icmp ne i64 %v968, 0
  %v970 = icmp ult i64 %v967, %v963
  %v971 = and i1 %v969, %v970
  br i1 %v971, label %array.valid.972, label %array.invalid.973
array.invalid.973:
  call void @mlf_bounds_failure()
  unreachable
array.valid.972:
  %v974 = getelementptr i8, ptr %v965, i64 %v967
  %v975 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v976 = ashr i64 %v975, 1
  %v977 = trunc i64 %v976 to i8
  store i8 %v977, ptr %v974, align 1, !tbaa !4
  %v978 = ptrtoint ptr %a7 to i64
  %v979 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v980 = sub i64 %v979, 1
  %v981 = add nsw i64 %v978, %v980
  %v982 = inttoptr i64 %v981 to ptr
  %v983 = musttail call ptr @mlf.numeric.16.ppppppnp(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr inttoptr (i64 1 to ptr), ptr %v982)
  ret ptr %v983
tail.no.961:
  %v984 = ptrtoint ptr %a4 to i64
  %v985 = ptrtoint ptr %a3 to i64
  %v986 = and i64 %v984, %v985
  %v987 = and i64 %v986, 1
  %v988 = icmp ne i64 %v987, 0
  br i1 %v988, label %yes.989, label %no.990
yes.989:
  %v992 = icmp eq i64 %v984, %v985
  %v993 = select i1 %v992, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.991
no.990:
  %v994 = call ptr @mlf_eq_int(ptr %a4, ptr %a3)
  br label %join.991
join.991:
  %v995 = phi ptr [ %v993, %yes.989 ], [ %v994, %no.990 ]
  %v996 = icmp eq ptr %v995, inttoptr (i64 6 to ptr)
  br i1 %v996, label %tail.yes.997, label %tail.no.998
tail.yes.997:
  %v999 = ptrtoint ptr %a6 to i64
  %v1000 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v1001 = icmp eq i64 %v999, %v1000
  %v1002 = select i1 %v1001, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1003 = icmp eq ptr %v1002, inttoptr (i64 6 to ptr)
  br i1 %v1003, label %tail.yes.1004, label %tail.no.1005
tail.yes.1004:
  ret ptr %a5
tail.no.1005:
  %v1006 = getelementptr i8, ptr %a1, i64 8
  %v1007 = load i64, ptr %v1006, align 8, !tbaa !3
  %v1008 = getelementptr i8, ptr %a1, i64 16
  %v1009 = load ptr, ptr %v1008, align 8, !tbaa !3
  %v1010 = ptrtoint ptr %a7 to i64
  %v1011 = ashr i64 %v1010, 1
  %v1012 = and i64 %v1010, 1
  %v1013 = icmp ne i64 %v1012, 0
  %v1014 = icmp ult i64 %v1011, %v1007
  %v1015 = and i1 %v1013, %v1014
  br i1 %v1015, label %array.valid.1016, label %array.invalid.1017
array.invalid.1017:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1016:
  %v1018 = getelementptr i8, ptr %v1009, i64 %v1011
  %v1019 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v1020 = ashr i64 %v1019, 1
  %v1021 = trunc i64 %v1020 to i8
  store i8 %v1021, ptr %v1018, align 1, !tbaa !4
  ret ptr %a5
tail.no.998:
  %v1022 = getelementptr i8, ptr %a0, i64 8
  %v1023 = load i64, ptr %v1022, align 8, !tbaa !3
  %v1024 = getelementptr i8, ptr %a0, i64 16
  %v1025 = load ptr, ptr %v1024, align 8, !tbaa !3
  %v1026 = ptrtoint ptr %a5 to i64
  %v1027 = ashr i64 %v1026, 1
  %v1028 = and i64 %v1026, 1
  %v1029 = icmp ne i64 %v1028, 0
  %v1030 = icmp ult i64 %v1027, %v1023
  %v1031 = and i1 %v1029, %v1030
  br i1 %v1031, label %array.valid.1032, label %array.invalid.1033
array.invalid.1033:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1032:
  %v1034 = getelementptr i8, ptr %v1025, i64 %v1027
  %v1035 = load i8, ptr %v1034, align 1, !tbaa !4
  %v1036 = zext i8 %v1035 to i64
  %v1037 = shl i64 %v1036, 1
  %v1038 = or i64 %v1037, 1
  %v1039 = inttoptr i64 %v1038 to ptr
  %v1040 = getelementptr i8, ptr %a1, i64 8
  %v1041 = load i64, ptr %v1040, align 8, !tbaa !3
  %v1042 = getelementptr i8, ptr %a1, i64 16
  %v1043 = load ptr, ptr %v1042, align 8, !tbaa !3
  %v1044 = ptrtoint ptr %a7 to i64
  %v1045 = ashr i64 %v1044, 1
  %v1046 = and i64 %v1044, 1
  %v1047 = icmp ne i64 %v1046, 0
  %v1048 = icmp ult i64 %v1045, %v1041
  %v1049 = and i1 %v1047, %v1048
  br i1 %v1049, label %array.valid.1050, label %array.invalid.1051
array.invalid.1051:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1050:
  %v1052 = getelementptr i8, ptr %v1043, i64 %v1045
  %v1053 = ptrtoint ptr %v1039 to i64
  %v1054 = ashr i64 %v1053, 1
  %v1055 = trunc i64 %v1054 to i8
  store i8 %v1055, ptr %v1052, align 1, !tbaa !4
  %v1056 = ptrtoint ptr %a5 to i64
  %v1057 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1058 = sub i64 %v1057, 1
  %v1059 = add nsw i64 %v1056, %v1058
  %v1060 = inttoptr i64 %v1059 to ptr
  %v1061 = ptrtoint ptr %v1060 to i64
  %v1062 = ptrtoint ptr %a2 to i64
  %v1063 = and i64 %v1061, %v1062
  %v1064 = and i64 %v1063, 1
  %v1065 = icmp ne i64 %v1064, 0
  br i1 %v1065, label %yes.1066, label %no.1067
yes.1066:
  %v1069 = icmp slt i64 %v1061, %v1062
  %v1070 = select i1 %v1069, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1068
no.1067:
  %v1071 = call ptr @mlf_lt_int(ptr %v1060, ptr %a2)
  br label %join.1068
join.1068:
  %v1072 = phi ptr [ %v1070, %yes.1066 ], [ %v1071, %no.1067 ]
  %v1073 = icmp eq ptr %v1072, inttoptr (i64 6 to ptr)
  br i1 %v1073, label %yes.1074, label %no.1075
yes.1074:
  %v1077 = ptrtoint ptr %a5 to i64
  %v1078 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1079 = sub i64 %v1078, 1
  %v1080 = add nsw i64 %v1077, %v1079
  %v1081 = inttoptr i64 %v1080 to ptr
  br label %join.1076
no.1075:
  br label %join.1076
join.1076:
  %v1082 = phi ptr [ %v1081, %yes.1074 ], [ inttoptr (i64 1 to ptr), %no.1075 ]
  %v1083 = ptrtoint ptr %a4 to i64
  %v1084 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1085 = and i64 %v1083, %v1084
  %v1086 = and i64 %v1085, 1
  %v1087 = icmp ne i64 %v1086, 0
  br i1 %v1087, label %yes.1088, label %no.1089
yes.1088:
  %v1091 = sub i64 %v1084, 1
  %v1092 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1083, i64 %v1091)
  %v1093 = extractvalue { i64, i1 } %v1092, 0
  %v1094 = extractvalue { i64, i1 } %v1092, 1
  br i1 %v1094, label %yes.1095, label %no.1096
yes.1095:
  %v1098 = call ptr @mlf_add_int(ptr %a4, ptr inttoptr (i64 3 to ptr))
  br label %join.1097
no.1096:
  %v1099 = inttoptr i64 %v1093 to ptr
  br label %join.1097
join.1097:
  %v1100 = phi ptr [ %v1098, %yes.1095 ], [ %v1099, %no.1096 ]
  br label %join.1090
no.1089:
  %v1101 = call ptr @mlf_add_int(ptr %a4, ptr inttoptr (i64 3 to ptr))
  br label %join.1090
join.1090:
  %v1102 = phi ptr [ %v1100, %join.1097 ], [ %v1101, %no.1089 ]
  %v1103 = ptrtoint ptr %a6 to i64
  %v1104 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1105 = and i64 %v1103, %v1104
  %v1106 = and i64 %v1105, 1
  %v1107 = icmp ne i64 %v1106, 0
  br i1 %v1107, label %yes.1108, label %no.1109
yes.1108:
  %v1111 = sub i64 %v1104, 1
  %v1112 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1103, i64 %v1111)
  %v1113 = extractvalue { i64, i1 } %v1112, 0
  %v1114 = extractvalue { i64, i1 } %v1112, 1
  br i1 %v1114, label %yes.1115, label %no.1116
yes.1115:
  %v1118 = call ptr @mlf_add_int(ptr %a6, ptr inttoptr (i64 3 to ptr))
  br label %join.1117
no.1116:
  %v1119 = inttoptr i64 %v1113 to ptr
  br label %join.1117
join.1117:
  %v1120 = phi ptr [ %v1118, %yes.1115 ], [ %v1119, %no.1116 ]
  br label %join.1110
no.1109:
  %v1121 = call ptr @mlf_add_int(ptr %a6, ptr inttoptr (i64 3 to ptr))
  br label %join.1110
join.1110:
  %v1122 = phi ptr [ %v1120, %join.1117 ], [ %v1121, %no.1109 ]
  %v1123 = ptrtoint ptr %a7 to i64
  %v1124 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1125 = sub i64 %v1124, 1
  %v1126 = add nsw i64 %v1123, %v1125
  %v1127 = inttoptr i64 %v1126 to ptr
  %v1420 = musttail call ptr @mlf.numeric.16(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %v1102, ptr %v1082, ptr %v1122, ptr %v1127)
  ret ptr %v1420
tail.no.954:
  ret ptr inttoptr (i64 1 to ptr)
}

define private ptr @mlf.numeric.31(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) alwaysinline {
entry:
  %v675 = ptrtoint ptr %a3 to i64
  %v676 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v677 = and i64 %v675, %v676
  %v678 = and i64 %v677, 1
  %v679 = icmp ne i64 %v678, 0
  br i1 %v679, label %yes.680, label %no.681
yes.680:
  %v683 = icmp eq i64 %v675, %v676
  %v684 = select i1 %v683, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.682
no.681:
  %v685 = call ptr @mlf_eq_int(ptr %a3, ptr inttoptr (i64 1 to ptr))
  br label %join.682
join.682:
  %v686 = phi ptr [ %v684, %yes.680 ], [ %v685, %no.681 ]
  %v687 = icmp eq ptr %v686, inttoptr (i64 6 to ptr)
  br i1 %v687, label %tail.yes.688, label %tail.no.689
tail.yes.688:
  ret ptr inttoptr (i64 4 to ptr)
tail.no.689:
  %v690 = ptrtoint ptr %a3 to i64
  %v691 = ptrtoint ptr inttoptr (i64 122881 to ptr) to i64
  %v692 = and i64 %v690, %v691
  %v693 = and i64 %v692, 1
  %v694 = icmp ne i64 %v693, 0
  br i1 %v694, label %yes.695, label %no.696
yes.695:
  %v698 = icmp slt i64 %v690, %v691
  %v699 = select i1 %v698, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.697
no.696:
  %v700 = call ptr @mlf_lt_int(ptr %a3, ptr inttoptr (i64 122881 to ptr))
  br label %join.697
join.697:
  %v701 = phi ptr [ %v699, %yes.695 ], [ %v700, %no.696 ]
  %v702 = icmp eq ptr %v701, inttoptr (i64 6 to ptr)
  br i1 %v702, label %yes.703, label %no.704
yes.703:
  br label %join.705
no.704:
  br label %join.705
join.705:
  %v706 = phi ptr [ %a3, %yes.703 ], [ inttoptr (i64 122881 to ptr), %no.704 ]
  %v1421 = call ptr @mlf.numeric.16.ppppppnp(ptr %a0, ptr %a1, ptr %a2, ptr %v706, ptr inttoptr (i64 1 to ptr), ptr %a4, ptr inttoptr (i64 1 to ptr), ptr inttoptr (i64 1 to ptr))
  %v1422 = ptrtoint ptr %v706 to i64
  %v1423 = ptrtoint ptr inttoptr (i64 119 to ptr) to i64
  %v1424 = and i64 %v1422, %v1423
  %v1425 = and i64 %v1424, 1
  %v1426 = icmp ne i64 %v1425, 0
  br i1 %v1426, label %yes.1427, label %no.1428
yes.1427:
  %v1430 = sub i64 %v1423, 1
  %v1431 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1422, i64 %v1430)
  %v1432 = extractvalue { i64, i1 } %v1431, 0
  %v1433 = extractvalue { i64, i1 } %v1431, 1
  br i1 %v1433, label %yes.1434, label %no.1435
yes.1434:
  %v1437 = call ptr @mlf_add_int(ptr %v706, ptr inttoptr (i64 119 to ptr))
  br label %join.1436
no.1435:
  %v1438 = inttoptr i64 %v1432 to ptr
  br label %join.1436
join.1436:
  %v1439 = phi ptr [ %v1437, %yes.1434 ], [ %v1438, %no.1435 ]
  br label %join.1429
no.1428:
  %v1440 = call ptr @mlf_add_int(ptr %v706, ptr inttoptr (i64 119 to ptr))
  br label %join.1429
join.1429:
  %v1441 = phi ptr [ %v1439, %join.1436 ], [ %v1440, %no.1428 ]
  %v1442 = ptrtoint ptr %v1441 to i64
  %v1443 = ptrtoint ptr inttoptr (i64 121 to ptr) to i64
  %v1444 = and i64 %v1442, %v1443
  %v1445 = and i64 %v1444, 1
  %v1446 = icmp ne i64 %v1445, 0
  br i1 %v1446, label %yes.1447, label %no.1448
yes.1447:
  %v1450 = ashr i64 %v1442, 1
  %v1451 = ashr i64 %v1443, 1
  %v1452 = icmp ne i64 %v1451, 0
  %v1453 = icmp eq i64 %v1450, -4611686018427387904
  %v1454 = icmp eq i64 %v1451, -1
  %v1455 = and i1 %v1453, %v1454
  %v1456 = xor i1 %v1455, true
  %v1457 = and i1 %v1452, %v1456
  br i1 %v1457, label %yes.1458, label %no.1459
yes.1458:
  %v1461 = sdiv i64 %v1450, %v1451
  %v1462 = shl i64 %v1461, 1
  %v1463 = or i64 %v1462, 1
  %v1464 = inttoptr i64 %v1463 to ptr
  br label %join.1460
no.1459:
  %v1465 = call ptr @mlf_prim2(i64 15, ptr %v1441, ptr inttoptr (i64 121 to ptr))
  br label %join.1460
join.1460:
  %v1466 = phi ptr [ %v1464, %yes.1458 ], [ %v1465, %no.1459 ]
  br label %join.1449
no.1448:
  %v1467 = call ptr @mlf_prim2(i64 15, ptr %v1441, ptr inttoptr (i64 121 to ptr))
  br label %join.1449
join.1449:
  %v1468 = phi ptr [ %v1466, %join.1460 ], [ %v1467, %no.1448 ]
  %v1469 = ptrtoint ptr %v706 to i64
  %v1470 = ptrtoint ptr %v1468 to i64
  %v1471 = and i64 %v1469, %v1470
  %v1472 = and i64 %v1471, 1
  %v1473 = icmp ne i64 %v1472, 0
  br i1 %v1473, label %yes.1474, label %no.1475
yes.1474:
  %v1477 = sub i64 %v1470, 1
  %v1478 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1469, i64 %v1477)
  %v1479 = extractvalue { i64, i1 } %v1478, 0
  %v1480 = extractvalue { i64, i1 } %v1478, 1
  br i1 %v1480, label %yes.1481, label %no.1482
yes.1481:
  %v1484 = call ptr @mlf_add_int(ptr %v706, ptr %v1468)
  br label %join.1483
no.1482:
  %v1485 = inttoptr i64 %v1479 to ptr
  br label %join.1483
join.1483:
  %v1486 = phi ptr [ %v1484, %yes.1481 ], [ %v1485, %no.1482 ]
  br label %join.1476
no.1475:
  %v1487 = call ptr @mlf_add_int(ptr %v706, ptr %v1468)
  br label %join.1476
join.1476:
  %v1488 = phi ptr [ %v1486, %join.1483 ], [ %v1487, %no.1475 ]
  %v1489 = call ptr @mlf_put_bytes(ptr %a1, ptr inttoptr (i64 1 to ptr), ptr %v1488)
  %v1490 = ptrtoint ptr %a3 to i64
  %v1491 = ptrtoint ptr %v706 to i64
  %v1492 = and i64 %v1490, %v1491
  %v1493 = and i64 %v1492, 1
  %v1494 = icmp ne i64 %v1493, 0
  br i1 %v1494, label %yes.1495, label %no.1496
yes.1495:
  %v1498 = sub i64 %v1491, 1
  %v1499 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v1490, i64 %v1498)
  %v1500 = extractvalue { i64, i1 } %v1499, 0
  %v1501 = extractvalue { i64, i1 } %v1499, 1
  br i1 %v1501, label %yes.1502, label %no.1503
yes.1502:
  %v1505 = call ptr @mlf_sub_int(ptr %a3, ptr %v706)
  br label %join.1504
no.1503:
  %v1506 = inttoptr i64 %v1500 to ptr
  br label %join.1504
join.1504:
  %v1507 = phi ptr [ %v1505, %yes.1502 ], [ %v1506, %no.1503 ]
  br label %join.1497
no.1496:
  %v1508 = call ptr @mlf_sub_int(ptr %a3, ptr %v706)
  br label %join.1497
join.1497:
  %v1509 = phi ptr [ %v1507, %join.1504 ], [ %v1508, %no.1496 ]
  %v1510 = musttail call ptr @mlf.numeric.31(ptr %a0, ptr %a1, ptr %a2, ptr %v1509, ptr %v1421)
  ret ptr %v1510
}

define private ptr @mlf.code.1519(ptr %env, ptr %arg) {
entry:
  %v1520 = getelementptr i8, ptr %env, i64 8
  %v1521 = load ptr, ptr %v1520, align 8, !tbaa !3
  %v1522 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1522, align 8, !tbaa !3
  %v1523 = call ptr @mlf.force(ptr %v1521)
  %v1524 = call ptr @mlf_prim2(i64 11, ptr %v1523, ptr inttoptr (i64 122881 to ptr))
  %v1525 = icmp eq ptr %v1524, inttoptr (i64 6 to ptr)
  br i1 %v1525, label %yes.1526, label %no.1527
yes.1526:
  br label %join.1528
no.1527:
  br label %join.1528
join.1528:
  %v1529 = phi ptr [ %v1523, %yes.1526 ], [ inttoptr (i64 122881 to ptr), %no.1527 ]
  ret ptr %v1529
}

define private ptr @mlf.code.1609(ptr %env, ptr %arg) {
entry:
  %v1610 = getelementptr i8, ptr %env, i64 8
  %v1611 = load ptr, ptr %v1610, align 8, !tbaa !3
  %v1612 = getelementptr i8, ptr %env, i64 16
  %v1613 = load ptr, ptr %v1612, align 8, !tbaa !3
  %v1614 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1614, align 8, !tbaa !3
  %v1615 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1615, align 8, !tbaa !3
  %v1616 = call ptr @mlf_prim3(i64 37, ptr %v1611, ptr %v1613, ptr inttoptr (i64 21 to ptr))
  ret ptr %v1616
}

define private ptr @mlf.code.1622(ptr %env, ptr %arg) {
entry:
  %v1623 = getelementptr i8, ptr %env, i64 8
  %v1624 = load ptr, ptr %v1623, align 8, !tbaa !3
  %v1625 = getelementptr i8, ptr %env, i64 16
  %v1626 = load ptr, ptr %v1625, align 8, !tbaa !3
  %v1627 = getelementptr i8, ptr %env, i64 24
  %v1628 = load ptr, ptr %v1627, align 8, !tbaa !3
  %v1629 = getelementptr i8, ptr %env, i64 32
  %v1630 = load ptr, ptr %v1629, align 8, !tbaa !3
  %v1631 = getelementptr i8, ptr %env, i64 40
  %v1632 = load ptr, ptr %v1631, align 8, !tbaa !3
  %v1633 = getelementptr i8, ptr %env, i64 48
  %v1634 = load ptr, ptr %v1633, align 8, !tbaa !3
  %v1635 = getelementptr i8, ptr %env, i64 56
  %v1636 = load ptr, ptr %v1635, align 8, !tbaa !3
  %v1637 = call ptr @mlf.force(ptr %v1632)
  %v1638 = call ptr @mlf.force(ptr %v1634)
  %v1639 = call ptr @mlf.force(ptr %v1636)
  %v1640 = call ptr @mlf_prim2(i64 8, ptr %v1639, ptr inttoptr (i64 3 to ptr))
  %v1641 = call ptr @mlf_env_new(i64 8)
  %v1642 = getelementptr i8, ptr %v1641, i64 8
  store ptr %v1624, ptr %v1642, align 8, !tbaa !3
  %v1643 = getelementptr i8, ptr %v1641, i64 16
  store ptr %v1626, ptr %v1643, align 8, !tbaa !3
  %v1644 = getelementptr i8, ptr %v1641, i64 24
  store ptr %v1628, ptr %v1644, align 8, !tbaa !3
  %v1645 = getelementptr i8, ptr %v1641, i64 32
  store ptr %v1630, ptr %v1645, align 8, !tbaa !3
  %v1646 = getelementptr i8, ptr %v1641, i64 40
  store ptr %v1637, ptr %v1646, align 8, !tbaa !3
  %v1647 = getelementptr i8, ptr %v1641, i64 48
  store ptr %v1638, ptr %v1647, align 8, !tbaa !3
  %v1648 = getelementptr i8, ptr %v1641, i64 56
  store ptr inttoptr (i64 1 to ptr), ptr %v1648, align 8, !tbaa !3
  %v1649 = getelementptr i8, ptr %v1641, i64 64
  store ptr %v1640, ptr %v1649, align 8, !tbaa !3
  %v1650 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1550, ptr %v1641)
  ret ptr %v1650
}

define private ptr @mlf.code.1673(ptr %env, ptr %arg) {
entry:
  %v1674 = getelementptr i8, ptr %env, i64 8
  %v1675 = load ptr, ptr %v1674, align 8, !tbaa !3
  %v1676 = getelementptr i8, ptr %env, i64 16
  %v1677 = load ptr, ptr %v1676, align 8, !tbaa !3
  %v1678 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1678, align 8, !tbaa !3
  %v1679 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1679, align 8, !tbaa !3
  %v1680 = call ptr @mlf_prim3(i64 37, ptr %v1675, ptr %v1677, ptr inttoptr (i64 21 to ptr))
  ret ptr %v1680
}

define private ptr @mlf.code.1686(ptr %env, ptr %arg) {
entry:
  %v1687 = getelementptr i8, ptr %env, i64 8
  %v1688 = load ptr, ptr %v1687, align 8, !tbaa !3
  %v1689 = call ptr @mlf_prim1(i64 0, ptr %v1688)
  ret ptr %v1689
}

define private ptr @mlf.code.1695(ptr %env, ptr %arg) {
entry:
  %v1696 = getelementptr i8, ptr %env, i64 8
  %v1697 = load ptr, ptr %v1696, align 8, !tbaa !3
  %v1698 = getelementptr i8, ptr %env, i64 16
  %v1699 = load ptr, ptr %v1698, align 8, !tbaa !3
  %v1700 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1700, align 8, !tbaa !3
  %v1701 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1701, align 8, !tbaa !3
  %v1702 = call ptr @mlf_prim2(i64 36, ptr %v1697, ptr %v1699)
  ret ptr %v1702
}

define private ptr @mlf.code.1725(ptr %env, ptr %arg) {
entry:
  %v1726 = getelementptr i8, ptr %env, i64 8
  %v1727 = load ptr, ptr %v1726, align 8, !tbaa !3
  %v1728 = getelementptr i8, ptr %env, i64 16
  %v1729 = load ptr, ptr %v1728, align 8, !tbaa !3
  %v1730 = getelementptr i8, ptr %env, i64 24
  %v1731 = load ptr, ptr %v1730, align 8, !tbaa !3
  %v1732 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1732, align 8, !tbaa !3
  %v1733 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1733, align 8, !tbaa !3
  %v1734 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v1734, align 8, !tbaa !3
  %v1735 = call ptr @mlf_prim3(i64 37, ptr %v1727, ptr %v1729, ptr %v1731)
  ret ptr %v1735
}

define private ptr @mlf.code.1742(ptr %env, ptr %arg) {
entry:
  %v1743 = getelementptr i8, ptr %env, i64 8
  %v1744 = load ptr, ptr %v1743, align 8, !tbaa !3
  %v1745 = getelementptr i8, ptr %env, i64 16
  %v1746 = load ptr, ptr %v1745, align 8, !tbaa !3
  %v1747 = getelementptr i8, ptr %env, i64 24
  %v1748 = load ptr, ptr %v1747, align 8, !tbaa !3
  %v1749 = getelementptr i8, ptr %env, i64 32
  %v1750 = load ptr, ptr %v1749, align 8, !tbaa !3
  %v1751 = getelementptr i8, ptr %env, i64 40
  %v1752 = load ptr, ptr %v1751, align 8, !tbaa !3
  %v1753 = getelementptr i8, ptr %env, i64 48
  %v1754 = load ptr, ptr %v1753, align 8, !tbaa !3
  %v1755 = getelementptr i8, ptr %env, i64 56
  %v1756 = load ptr, ptr %v1755, align 8, !tbaa !3
  %v1757 = getelementptr i8, ptr %env, i64 64
  %v1758 = load ptr, ptr %v1757, align 8, !tbaa !3
  %v1759 = call ptr @mlf.force(ptr %v1754)
  %v1760 = call ptr @mlf_prim2(i64 8, ptr %v1759, ptr inttoptr (i64 3 to ptr))
  %v1761 = call ptr @mlf.force(ptr %v1748)
  %v1762 = call ptr @mlf_prim2(i64 11, ptr %v1760, ptr %v1761)
  %v1763 = icmp eq ptr %v1762, inttoptr (i64 6 to ptr)
  br i1 %v1763, label %yes.1764, label %no.1765
yes.1764:
  %v1767 = call ptr @mlf_prim2(i64 8, ptr %v1759, ptr inttoptr (i64 3 to ptr))
  br label %join.1766
no.1765:
  br label %join.1766
join.1766:
  %v1768 = phi ptr [ %v1767, %yes.1764 ], [ inttoptr (i64 1 to ptr), %no.1765 ]
  %v1769 = call ptr @mlf.force(ptr %v1752)
  %v1770 = call ptr @mlf_prim2(i64 8, ptr %v1769, ptr inttoptr (i64 3 to ptr))
  %v1771 = call ptr @mlf.force(ptr %v1756)
  %v1772 = call ptr @mlf_prim2(i64 8, ptr %v1771, ptr inttoptr (i64 3 to ptr))
  %v1773 = call ptr @mlf.force(ptr %v1758)
  %v1774 = call ptr @mlf_prim2(i64 8, ptr %v1773, ptr inttoptr (i64 3 to ptr))
  %v1775 = call ptr @mlf_env_new(i64 8)
  %v1776 = getelementptr i8, ptr %v1775, i64 8
  store ptr %v1744, ptr %v1776, align 8, !tbaa !3
  %v1777 = getelementptr i8, ptr %v1775, i64 16
  store ptr %v1746, ptr %v1777, align 8, !tbaa !3
  %v1778 = getelementptr i8, ptr %v1775, i64 24
  store ptr %v1761, ptr %v1778, align 8, !tbaa !3
  %v1779 = getelementptr i8, ptr %v1775, i64 32
  store ptr %v1750, ptr %v1779, align 8, !tbaa !3
  %v1780 = getelementptr i8, ptr %v1775, i64 40
  store ptr %v1770, ptr %v1780, align 8, !tbaa !3
  %v1781 = getelementptr i8, ptr %v1775, i64 48
  store ptr %v1768, ptr %v1781, align 8, !tbaa !3
  %v1782 = getelementptr i8, ptr %v1775, i64 56
  store ptr %v1772, ptr %v1782, align 8, !tbaa !3
  %v1783 = getelementptr i8, ptr %v1775, i64 64
  store ptr %v1774, ptr %v1783, align 8, !tbaa !3
  %v1784 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1550, ptr %v1775)
  ret ptr %v1784
}

define private ptr @mlf.code.1708(ptr %env, ptr %arg) {
entry:
  %v1709 = getelementptr i8, ptr %env, i64 8
  %v1710 = load ptr, ptr %v1709, align 8, !tbaa !3
  %v1711 = getelementptr i8, ptr %env, i64 16
  %v1712 = load ptr, ptr %v1711, align 8, !tbaa !3
  %v1713 = getelementptr i8, ptr %env, i64 24
  %v1714 = load ptr, ptr %v1713, align 8, !tbaa !3
  %v1715 = getelementptr i8, ptr %env, i64 32
  %v1716 = load ptr, ptr %v1715, align 8, !tbaa !3
  %v1717 = getelementptr i8, ptr %env, i64 40
  %v1718 = load ptr, ptr %v1717, align 8, !tbaa !3
  %v1719 = getelementptr i8, ptr %env, i64 48
  %v1720 = load ptr, ptr %v1719, align 8, !tbaa !3
  %v1721 = getelementptr i8, ptr %env, i64 56
  %v1722 = load ptr, ptr %v1721, align 8, !tbaa !3
  %v1723 = getelementptr i8, ptr %env, i64 64
  %v1724 = load ptr, ptr %v1723, align 8, !tbaa !3
  %v1736 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1725, i64 3)
  %v1737 = getelementptr i8, ptr %v1736, i64 16
  %v1738 = load ptr, ptr %v1737, align 8, !tbaa !3
  %v1739 = getelementptr i8, ptr %v1738, i64 8
  store ptr %v1712, ptr %v1739, align 8, !tbaa !3
  %v1740 = getelementptr i8, ptr %v1738, i64 16
  store ptr %v1724, ptr %v1740, align 8, !tbaa !3
  %v1741 = getelementptr i8, ptr %v1738, i64 24
  store ptr %arg, ptr %v1741, align 8, !tbaa !3
  %v1785 = call ptr @mlf_env_new(i64 8)
  %v1786 = getelementptr i8, ptr %v1785, i64 8
  store ptr %v1710, ptr %v1786, align 8, !tbaa !3
  %v1787 = getelementptr i8, ptr %v1785, i64 16
  store ptr %v1712, ptr %v1787, align 8, !tbaa !3
  %v1788 = getelementptr i8, ptr %v1785, i64 24
  store ptr %v1714, ptr %v1788, align 8, !tbaa !3
  %v1789 = getelementptr i8, ptr %v1785, i64 32
  store ptr %v1716, ptr %v1789, align 8, !tbaa !3
  %v1790 = getelementptr i8, ptr %v1785, i64 40
  store ptr %v1718, ptr %v1790, align 8, !tbaa !3
  %v1791 = getelementptr i8, ptr %v1785, i64 48
  store ptr %v1720, ptr %v1791, align 8, !tbaa !3
  %v1792 = getelementptr i8, ptr %v1785, i64 56
  store ptr %v1722, ptr %v1792, align 8, !tbaa !3
  %v1793 = getelementptr i8, ptr %v1785, i64 64
  store ptr %v1724, ptr %v1793, align 8, !tbaa !3
  %v1794 = call ptr @mlf_closure(ptr @mlf.code.1742, ptr %v1785)
  %v1795 = call ptr @mlf_prim2(i64 1, ptr %v1736, ptr %v1794)
  ret ptr %v1795
}

define private ptr @mlf.worker.16(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6, ptr %a7) {
entry:
  %v1596 = call ptr @mlf_prim2(i64 8, ptr %a6, ptr %a7)
  %v1597 = call ptr @mlf_prim2(i64 8, ptr %a5, ptr %v1596)
  %v1598 = call ptr @mlf_prim2(i64 8, ptr %a4, ptr %v1597)
  %v1599 = call ptr @mlf_prim2(i64 10, ptr %v1598, ptr %v1598)
  %v1600 = icmp eq ptr %v1599, inttoptr (i64 6 to ptr)
  br i1 %v1600, label %yes.1601, label %no.1602
yes.1601:
  %v1604 = call ptr @mlf_prim2(i64 10, ptr %a6, ptr inttoptr (i64 121 to ptr))
  %v1605 = icmp eq ptr %v1604, inttoptr (i64 6 to ptr)
  br i1 %v1605, label %yes.1606, label %no.1607
yes.1606:
  %v1617 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1609, i64 2)
  %v1618 = getelementptr i8, ptr %v1617, i64 16
  %v1619 = load ptr, ptr %v1618, align 8, !tbaa !3
  %v1620 = getelementptr i8, ptr %v1619, i64 8
  store ptr %a1, ptr %v1620, align 8, !tbaa !3
  %v1621 = getelementptr i8, ptr %v1619, i64 16
  store ptr %a7, ptr %v1621, align 8, !tbaa !3
  %v1651 = call ptr @mlf_env_new(i64 7)
  %v1652 = getelementptr i8, ptr %v1651, i64 8
  store ptr %a0, ptr %v1652, align 8, !tbaa !3
  %v1653 = getelementptr i8, ptr %v1651, i64 16
  store ptr %a1, ptr %v1653, align 8, !tbaa !3
  %v1654 = getelementptr i8, ptr %v1651, i64 24
  store ptr %a2, ptr %v1654, align 8, !tbaa !3
  %v1655 = getelementptr i8, ptr %v1651, i64 32
  store ptr %a3, ptr %v1655, align 8, !tbaa !3
  %v1656 = getelementptr i8, ptr %v1651, i64 40
  store ptr %a4, ptr %v1656, align 8, !tbaa !3
  %v1657 = getelementptr i8, ptr %v1651, i64 48
  store ptr %a5, ptr %v1657, align 8, !tbaa !3
  %v1658 = getelementptr i8, ptr %v1651, i64 56
  store ptr %a7, ptr %v1658, align 8, !tbaa !3
  %v1659 = call ptr @mlf_closure(ptr @mlf.code.1622, ptr %v1651)
  %v1660 = call ptr @mlf_prim2(i64 1, ptr %v1617, ptr %v1659)
  br label %join.1608
no.1607:
  %v1661 = call ptr @mlf.force(ptr %a3)
  %v1662 = call ptr @mlf_prim2(i64 10, ptr %a4, ptr %v1661)
  %v1663 = icmp eq ptr %v1662, inttoptr (i64 6 to ptr)
  br i1 %v1663, label %yes.1664, label %no.1665
yes.1664:
  %v1667 = call ptr @mlf_prim2(i64 10, ptr %a6, ptr inttoptr (i64 1 to ptr))
  %v1668 = icmp eq ptr %v1667, inttoptr (i64 6 to ptr)
  br i1 %v1668, label %yes.1669, label %no.1670
yes.1669:
  %v1672 = call ptr @mlf_prim1(i64 0, ptr %a5)
  br label %join.1671
no.1670:
  %v1681 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1673, i64 2)
  %v1682 = getelementptr i8, ptr %v1681, i64 16
  %v1683 = load ptr, ptr %v1682, align 8, !tbaa !3
  %v1684 = getelementptr i8, ptr %v1683, i64 8
  store ptr %a1, ptr %v1684, align 8, !tbaa !3
  %v1685 = getelementptr i8, ptr %v1683, i64 16
  store ptr %a7, ptr %v1685, align 8, !tbaa !3
  %v1690 = call ptr @mlf_env_new(i64 1)
  %v1691 = getelementptr i8, ptr %v1690, i64 8
  store ptr %a5, ptr %v1691, align 8, !tbaa !3
  %v1692 = call ptr @mlf_closure(ptr @mlf.code.1686, ptr %v1690)
  %v1693 = call ptr @mlf_prim2(i64 1, ptr %v1681, ptr %v1692)
  br label %join.1671
join.1671:
  %v1694 = phi ptr [ %v1672, %yes.1669 ], [ %v1693, %no.1670 ]
  br label %join.1666
no.1665:
  %v1703 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1695, i64 2)
  %v1704 = getelementptr i8, ptr %v1703, i64 16
  %v1705 = load ptr, ptr %v1704, align 8, !tbaa !3
  %v1706 = getelementptr i8, ptr %v1705, i64 8
  store ptr %a0, ptr %v1706, align 8, !tbaa !3
  %v1707 = getelementptr i8, ptr %v1705, i64 16
  store ptr %a5, ptr %v1707, align 8, !tbaa !3
  %v1796 = call ptr @mlf_env_new(i64 8)
  %v1797 = getelementptr i8, ptr %v1796, i64 8
  store ptr %a0, ptr %v1797, align 8, !tbaa !3
  %v1798 = getelementptr i8, ptr %v1796, i64 16
  store ptr %a1, ptr %v1798, align 8, !tbaa !3
  %v1799 = getelementptr i8, ptr %v1796, i64 24
  store ptr %a2, ptr %v1799, align 8, !tbaa !3
  %v1800 = getelementptr i8, ptr %v1796, i64 32
  store ptr %v1661, ptr %v1800, align 8, !tbaa !3
  %v1801 = getelementptr i8, ptr %v1796, i64 40
  store ptr %a4, ptr %v1801, align 8, !tbaa !3
  %v1802 = getelementptr i8, ptr %v1796, i64 48
  store ptr %a5, ptr %v1802, align 8, !tbaa !3
  %v1803 = getelementptr i8, ptr %v1796, i64 56
  store ptr %a6, ptr %v1803, align 8, !tbaa !3
  %v1804 = getelementptr i8, ptr %v1796, i64 64
  store ptr %a7, ptr %v1804, align 8, !tbaa !3
  %v1805 = call ptr @mlf_closure(ptr @mlf.code.1708, ptr %v1796)
  %v1806 = call ptr @mlf_prim2(i64 1, ptr %v1703, ptr %v1805)
  br label %join.1666
join.1666:
  %v1807 = phi ptr [ %v1694, %join.1671 ], [ %v1806, %no.1665 ]
  br label %join.1608
join.1608:
  %v1808 = phi ptr [ %v1660, %yes.1606 ], [ %v1807, %join.1666 ]
  br label %join.1603
no.1602:
  %v1809 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 1 to ptr))
  br label %join.1603
join.1603:
  %v1810 = phi ptr [ %v1808, %join.1608 ], [ %v1809, %no.1602 ]
  ret ptr %v1810
}

define private ptr @mlf.numeric.entry.1550(ptr %env, ptr %arg) {
entry:
  %v1551 = getelementptr i8, ptr %env, i64 8
  %v1552 = load ptr, ptr %v1551, align 8, !tbaa !3
  %v1553 = getelementptr i8, ptr %env, i64 16
  %v1554 = load ptr, ptr %v1553, align 8, !tbaa !3
  %v1555 = getelementptr i8, ptr %env, i64 24
  %v1556 = load ptr, ptr %v1555, align 8, !tbaa !3
  %v1557 = getelementptr i8, ptr %env, i64 32
  %v1558 = load ptr, ptr %v1557, align 8, !tbaa !3
  %v1559 = getelementptr i8, ptr %env, i64 40
  %v1560 = load ptr, ptr %v1559, align 8, !tbaa !3
  %v1561 = getelementptr i8, ptr %env, i64 48
  %v1562 = load ptr, ptr %v1561, align 8, !tbaa !3
  %v1563 = getelementptr i8, ptr %env, i64 56
  %v1564 = load ptr, ptr %v1563, align 8, !tbaa !3
  %v1565 = getelementptr i8, ptr %env, i64 64
  %v1566 = load ptr, ptr %v1565, align 8, !tbaa !3
  %v1567 = call ptr @mlf_peek(ptr %v1552)
  %v1568 = call ptr @mlf_peek(ptr %v1554)
  %v1569 = call ptr @mlf_peek(ptr %v1556)
  %v1570 = call ptr @mlf_peek(ptr %v1558)
  %v1571 = call ptr @mlf_peek(ptr %v1560)
  %v1572 = call ptr @mlf_peek(ptr %v1562)
  %v1573 = call ptr @mlf_peek(ptr %v1564)
  %v1574 = call ptr @mlf_peek(ptr %v1566)
  %v1575 = icmp ne ptr %v1567, null
  %v1576 = icmp ne ptr %v1568, null
  %v1577 = icmp ne ptr %v1569, null
  %v1578 = icmp ne ptr %v1570, null
  %v1579 = icmp ne ptr %v1571, null
  %v1580 = icmp ne ptr %v1572, null
  %v1581 = icmp ne ptr %v1573, null
  %v1582 = icmp ne ptr %v1574, null
  %v1583 = and i1 true, %v1575
  %v1584 = and i1 %v1583, %v1576
  %v1585 = and i1 %v1584, %v1577
  %v1586 = and i1 %v1585, %v1578
  %v1587 = and i1 %v1586, %v1579
  %v1588 = and i1 %v1587, %v1580
  %v1589 = and i1 %v1588, %v1581
  %v1590 = and i1 %v1589, %v1582
  br i1 %v1590, label %yes.1591, label %no.1592
yes.1591:
  %v1594 = call ptr @mlf.numeric.16(ptr %v1567, ptr %v1568, ptr %v1569, ptr %v1570, ptr %v1571, ptr %v1572, ptr %v1573, ptr %v1574)
  %v1595 = call ptr @mlf_prim1(i64 0, ptr %v1594)
  br label %join.1593
no.1592:
  %v1811 = call ptr @mlf.force(ptr %v1560)
  %v1812 = call ptr @mlf.force(ptr %v1562)
  %v1813 = call ptr @mlf.force(ptr %v1564)
  %v1814 = call ptr @mlf.force(ptr %v1566)
  %v1815 = call ptr @mlf.worker.16(ptr %v1552, ptr %v1554, ptr %v1556, ptr %v1558, ptr %v1811, ptr %v1812, ptr %v1813, ptr %v1814)
  br label %join.1593
join.1593:
  %v1816 = phi ptr [ %v1595, %yes.1591 ], [ %v1815, %no.1592 ]
  ret ptr %v1816
}

define private ptr @mlf.code.1534(ptr %env, ptr %arg) {
entry:
  %v1535 = getelementptr i8, ptr %env, i64 8
  %v1536 = load ptr, ptr %v1535, align 8, !tbaa !3
  %v1537 = getelementptr i8, ptr %env, i64 16
  %v1538 = load ptr, ptr %v1537, align 8, !tbaa !3
  %v1539 = getelementptr i8, ptr %env, i64 24
  %v1540 = load ptr, ptr %v1539, align 8, !tbaa !3
  %v1541 = getelementptr i8, ptr %env, i64 32
  %v1542 = load ptr, ptr %v1541, align 8, !tbaa !3
  %v1543 = getelementptr i8, ptr %env, i64 40
  %v1544 = load ptr, ptr %v1543, align 8, !tbaa !3
  %v1545 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1545, align 8, !tbaa !3
  %v1546 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1546, align 8, !tbaa !3
  %v1547 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v1547, align 8, !tbaa !3
  %v1548 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v1548, align 8, !tbaa !3
  %v1549 = getelementptr i8, ptr %env, i64 40
  store ptr null, ptr %v1549, align 8, !tbaa !3
  %v1817 = call ptr @mlf.force(ptr %v1542)
  %v1818 = call ptr @mlf_env_new(i64 8)
  %v1819 = getelementptr i8, ptr %v1818, i64 8
  store ptr %v1536, ptr %v1819, align 8, !tbaa !3
  %v1820 = getelementptr i8, ptr %v1818, i64 16
  store ptr %v1538, ptr %v1820, align 8, !tbaa !3
  %v1821 = getelementptr i8, ptr %v1818, i64 24
  store ptr %v1540, ptr %v1821, align 8, !tbaa !3
  %v1822 = getelementptr i8, ptr %v1818, i64 32
  store ptr %v1544, ptr %v1822, align 8, !tbaa !3
  %v1823 = getelementptr i8, ptr %v1818, i64 40
  store ptr inttoptr (i64 1 to ptr), ptr %v1823, align 8, !tbaa !3
  %v1824 = getelementptr i8, ptr %v1818, i64 48
  store ptr %v1817, ptr %v1824, align 8, !tbaa !3
  %v1825 = getelementptr i8, ptr %v1818, i64 56
  store ptr inttoptr (i64 1 to ptr), ptr %v1825, align 8, !tbaa !3
  %v1826 = getelementptr i8, ptr %v1818, i64 64
  store ptr inttoptr (i64 1 to ptr), ptr %v1826, align 8, !tbaa !3
  %v1827 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1550, ptr %v1818)
  ret ptr %v1827
}

define private ptr @mlf.code.1854(ptr %env, ptr %arg) {
entry:
  %v1855 = getelementptr i8, ptr %env, i64 8
  %v1856 = load ptr, ptr %v1855, align 8, !tbaa !3
  %v1857 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1857, align 8, !tbaa !3
  %v1858 = call ptr @mlf.force(ptr %v1856)
  %v1859 = call ptr @mlf_prim2(i64 8, ptr %v1858, ptr inttoptr (i64 119 to ptr))
  %v1860 = call ptr @mlf_prim2(i64 15, ptr %v1859, ptr inttoptr (i64 121 to ptr))
  %v1861 = call ptr @mlf_prim2(i64 8, ptr %v1858, ptr %v1860)
  ret ptr %v1861
}

define private ptr @mlf.code.1847(ptr %env, ptr %arg) {
entry:
  %v1848 = getelementptr i8, ptr %env, i64 8
  %v1849 = load ptr, ptr %v1848, align 8, !tbaa !3
  %v1850 = getelementptr i8, ptr %env, i64 16
  %v1851 = load ptr, ptr %v1850, align 8, !tbaa !3
  %v1852 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1852, align 8, !tbaa !3
  %v1853 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1853, align 8, !tbaa !3
  %v1862 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1854, i64 1)
  %v1863 = getelementptr i8, ptr %v1862, i64 16
  %v1864 = load ptr, ptr %v1863, align 8, !tbaa !3
  %v1865 = getelementptr i8, ptr %v1864, i64 8
  store ptr %v1851, ptr %v1865, align 8, !tbaa !3
  %v1866 = call ptr @mlf_prim3(i64 40, ptr %v1849, ptr inttoptr (i64 1 to ptr), ptr %v1862)
  ret ptr %v1866
}

define private ptr @mlf.code.1872(ptr %env, ptr %arg) {
entry:
  %v1873 = getelementptr i8, ptr %env, i64 8
  %v1874 = load ptr, ptr %v1873, align 8, !tbaa !3
  %v1875 = getelementptr i8, ptr %env, i64 16
  %v1876 = load ptr, ptr %v1875, align 8, !tbaa !3
  %v1877 = getelementptr i8, ptr %env, i64 24
  %v1878 = load ptr, ptr %v1877, align 8, !tbaa !3
  %v1879 = getelementptr i8, ptr %env, i64 32
  %v1880 = load ptr, ptr %v1879, align 8, !tbaa !3
  %v1881 = getelementptr i8, ptr %env, i64 40
  %v1882 = load ptr, ptr %v1881, align 8, !tbaa !3
  %v1883 = getelementptr i8, ptr %env, i64 48
  %v1884 = load ptr, ptr %v1883, align 8, !tbaa !3
  %v1885 = call ptr @mlf.force(ptr %v1880)
  %v1886 = call ptr @mlf.force(ptr %v1882)
  %v1887 = call ptr @mlf_prim2(i64 9, ptr %v1885, ptr %v1886)
  %v1888 = call ptr @mlf_env_new(i64 5)
  %v1889 = getelementptr i8, ptr %v1888, i64 8
  store ptr %v1874, ptr %v1889, align 8, !tbaa !3
  %v1890 = getelementptr i8, ptr %v1888, i64 16
  store ptr %v1876, ptr %v1890, align 8, !tbaa !3
  %v1891 = getelementptr i8, ptr %v1888, i64 24
  store ptr %v1878, ptr %v1891, align 8, !tbaa !3
  %v1892 = getelementptr i8, ptr %v1888, i64 32
  store ptr %v1887, ptr %v1892, align 8, !tbaa !3
  %v1893 = getelementptr i8, ptr %v1888, i64 40
  store ptr %v1884, ptr %v1893, align 8, !tbaa !3
  %v1894 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.646, ptr %v1888)
  ret ptr %v1894
}

define private ptr @mlf.code.1836(ptr %env, ptr %arg) {
entry:
  %v1837 = getelementptr i8, ptr %env, i64 8
  %v1838 = load ptr, ptr %v1837, align 8, !tbaa !3
  %v1839 = getelementptr i8, ptr %env, i64 16
  %v1840 = load ptr, ptr %v1839, align 8, !tbaa !3
  %v1841 = getelementptr i8, ptr %env, i64 24
  %v1842 = load ptr, ptr %v1841, align 8, !tbaa !3
  %v1843 = getelementptr i8, ptr %env, i64 32
  %v1844 = load ptr, ptr %v1843, align 8, !tbaa !3
  %v1845 = getelementptr i8, ptr %env, i64 40
  %v1846 = load ptr, ptr %v1845, align 8, !tbaa !3
  %v1867 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1847, i64 2)
  %v1868 = getelementptr i8, ptr %v1867, i64 16
  %v1869 = load ptr, ptr %v1868, align 8, !tbaa !3
  %v1870 = getelementptr i8, ptr %v1869, i64 8
  store ptr %v1840, ptr %v1870, align 8, !tbaa !3
  %v1871 = getelementptr i8, ptr %v1869, i64 16
  store ptr %v1846, ptr %v1871, align 8, !tbaa !3
  %v1895 = call ptr @mlf_env_new(i64 6)
  %v1896 = getelementptr i8, ptr %v1895, i64 8
  store ptr %v1838, ptr %v1896, align 8, !tbaa !3
  %v1897 = getelementptr i8, ptr %v1895, i64 16
  store ptr %v1840, ptr %v1897, align 8, !tbaa !3
  %v1898 = getelementptr i8, ptr %v1895, i64 24
  store ptr %v1842, ptr %v1898, align 8, !tbaa !3
  %v1899 = getelementptr i8, ptr %v1895, i64 32
  store ptr %v1844, ptr %v1899, align 8, !tbaa !3
  %v1900 = getelementptr i8, ptr %v1895, i64 40
  store ptr %v1846, ptr %v1900, align 8, !tbaa !3
  %v1901 = getelementptr i8, ptr %v1895, i64 48
  store ptr %arg, ptr %v1901, align 8, !tbaa !3
  %v1902 = call ptr @mlf_closure(ptr @mlf.code.1872, ptr %v1895)
  %v1903 = call ptr @mlf_prim2(i64 1, ptr %v1867, ptr %v1902)
  ret ptr %v1903
}

define private ptr @mlf.worker.31(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) {
entry:
  %v1513 = call ptr @mlf_prim2(i64 10, ptr %a3, ptr inttoptr (i64 1 to ptr))
  %v1514 = icmp eq ptr %v1513, inttoptr (i64 6 to ptr)
  br i1 %v1514, label %yes.1515, label %no.1516
yes.1515:
  %v1518 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.1517
no.1516:
  %v1530 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1519, i64 1)
  %v1531 = getelementptr i8, ptr %v1530, i64 16
  %v1532 = load ptr, ptr %v1531, align 8, !tbaa !3
  %v1533 = getelementptr i8, ptr %v1532, i64 8
  store ptr %a3, ptr %v1533, align 8, !tbaa !3
  %v1828 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1534, i64 5)
  %v1829 = getelementptr i8, ptr %v1828, i64 16
  %v1830 = load ptr, ptr %v1829, align 8, !tbaa !3
  %v1831 = getelementptr i8, ptr %v1830, i64 8
  store ptr %a0, ptr %v1831, align 8, !tbaa !3
  %v1832 = getelementptr i8, ptr %v1830, i64 16
  store ptr %a1, ptr %v1832, align 8, !tbaa !3
  %v1833 = getelementptr i8, ptr %v1830, i64 24
  store ptr %a2, ptr %v1833, align 8, !tbaa !3
  %v1834 = getelementptr i8, ptr %v1830, i64 32
  store ptr %a4, ptr %v1834, align 8, !tbaa !3
  %v1835 = getelementptr i8, ptr %v1830, i64 40
  store ptr %v1530, ptr %v1835, align 8, !tbaa !3
  %v1904 = call ptr @mlf_env_new(i64 5)
  %v1905 = getelementptr i8, ptr %v1904, i64 8
  store ptr %a0, ptr %v1905, align 8, !tbaa !3
  %v1906 = getelementptr i8, ptr %v1904, i64 16
  store ptr %a1, ptr %v1906, align 8, !tbaa !3
  %v1907 = getelementptr i8, ptr %v1904, i64 24
  store ptr %a2, ptr %v1907, align 8, !tbaa !3
  %v1908 = getelementptr i8, ptr %v1904, i64 32
  store ptr %a3, ptr %v1908, align 8, !tbaa !3
  %v1909 = getelementptr i8, ptr %v1904, i64 40
  store ptr %v1530, ptr %v1909, align 8, !tbaa !3
  %v1910 = call ptr @mlf_closure(ptr @mlf.code.1836, ptr %v1904)
  %v1911 = call ptr @mlf_prim2(i64 1, ptr %v1828, ptr %v1910)
  br label %join.1517
join.1517:
  %v1912 = phi ptr [ %v1518, %yes.1515 ], [ %v1911, %no.1516 ]
  ret ptr %v1912
}

define private ptr @mlf.numeric.entry.646(ptr %env, ptr %arg) {
entry:
  %v647 = getelementptr i8, ptr %env, i64 8
  %v648 = load ptr, ptr %v647, align 8, !tbaa !3
  %v649 = getelementptr i8, ptr %env, i64 16
  %v650 = load ptr, ptr %v649, align 8, !tbaa !3
  %v651 = getelementptr i8, ptr %env, i64 24
  %v652 = load ptr, ptr %v651, align 8, !tbaa !3
  %v653 = getelementptr i8, ptr %env, i64 32
  %v654 = load ptr, ptr %v653, align 8, !tbaa !3
  %v655 = getelementptr i8, ptr %env, i64 40
  %v656 = load ptr, ptr %v655, align 8, !tbaa !3
  %v657 = call ptr @mlf_peek(ptr %v648)
  %v658 = call ptr @mlf_peek(ptr %v650)
  %v659 = call ptr @mlf_peek(ptr %v652)
  %v660 = call ptr @mlf_peek(ptr %v654)
  %v661 = call ptr @mlf_peek(ptr %v656)
  %v662 = icmp ne ptr %v657, null
  %v663 = icmp ne ptr %v658, null
  %v664 = icmp ne ptr %v659, null
  %v665 = icmp ne ptr %v660, null
  %v666 = icmp ne ptr %v661, null
  %v667 = and i1 true, %v662
  %v668 = and i1 %v667, %v663
  %v669 = and i1 %v668, %v664
  %v670 = and i1 %v669, %v665
  %v671 = and i1 %v670, %v666
  br i1 %v671, label %yes.672, label %no.673
yes.672:
  %v1511 = call ptr @mlf.numeric.31(ptr %v657, ptr %v658, ptr %v659, ptr %v660, ptr %v661)
  %v1512 = call ptr @mlf_prim1(i64 0, ptr %v1511)
  br label %join.674
no.673:
  %v1913 = call ptr @mlf.force(ptr %v654)
  %v1914 = call ptr @mlf.worker.31(ptr %v648, ptr %v650, ptr %v652, ptr %v1913, ptr %v656)
  br label %join.674
join.674:
  %v1915 = phi ptr [ %v1512, %yes.672 ], [ %v1914, %no.673 ]
  ret ptr %v1915
}

define private ptr @mlf.code.633(ptr %env, ptr %arg) {
entry:
  %v634 = getelementptr i8, ptr %env, i64 8
  %v635 = load ptr, ptr %v634, align 8, !tbaa !3
  %v636 = getelementptr i8, ptr %env, i64 16
  %v637 = load ptr, ptr %v636, align 8, !tbaa !3
  %v638 = getelementptr i8, ptr %env, i64 24
  %v639 = load ptr, ptr %v638, align 8, !tbaa !3
  %v640 = getelementptr i8, ptr %env, i64 32
  %v641 = load ptr, ptr %v640, align 8, !tbaa !3
  %v642 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v642, align 8, !tbaa !3
  %v643 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v643, align 8, !tbaa !3
  %v644 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v644, align 8, !tbaa !3
  %v645 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v645, align 8, !tbaa !3
  %v1916 = call ptr @mlf.force(ptr %v635)
  %v1917 = ptrtoint ptr %v1916 to i64
  %v1918 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v1919 = and i64 %v1917, %v1918
  %v1920 = and i64 %v1919, 1
  %v1921 = icmp ne i64 %v1920, 0
  br i1 %v1921, label %yes.1922, label %no.1923
yes.1922:
  %v1925 = ashr i64 %v1917, 1
  %v1926 = ashr i64 %v1918, 1
  %v1927 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v1925, i64 %v1926)
  %v1928 = extractvalue { i64, i1 } %v1927, 0
  %v1929 = extractvalue { i64, i1 } %v1927, 1
  %v1930 = xor i1 %v1929, true
  %v1931 = icmp sge i64 %v1928, -4611686018427387904
  %v1932 = icmp sle i64 %v1928, 4611686018427387903
  %v1933 = and i1 %v1931, %v1932
  %v1934 = and i1 %v1933, %v1930
  br i1 %v1934, label %yes.1935, label %no.1936
yes.1935:
  %v1938 = shl i64 %v1928, 1
  %v1939 = or i64 %v1938, 1
  %v1940 = inttoptr i64 %v1939 to ptr
  br label %join.1937
no.1936:
  %v1941 = call ptr @mlf_prim2(i64 14, ptr %v1916, ptr inttoptr (i64 5 to ptr))
  br label %join.1937
join.1937:
  %v1942 = phi ptr [ %v1940, %yes.1935 ], [ %v1941, %no.1936 ]
  br label %join.1924
no.1923:
  %v1943 = call ptr @mlf_prim2(i64 14, ptr %v1916, ptr inttoptr (i64 5 to ptr))
  br label %join.1924
join.1924:
  %v1944 = phi ptr [ %v1942, %join.1937 ], [ %v1943, %no.1923 ]
  %v1945 = call ptr @mlf_env_new(i64 5)
  %v1946 = getelementptr i8, ptr %v1945, i64 8
  store ptr %v637, ptr %v1946, align 8, !tbaa !3
  %v1947 = getelementptr i8, ptr %v1945, i64 16
  store ptr %v639, ptr %v1947, align 8, !tbaa !3
  %v1948 = getelementptr i8, ptr %v1945, i64 24
  store ptr %v641, ptr %v1948, align 8, !tbaa !3
  %v1949 = getelementptr i8, ptr %v1945, i64 32
  store ptr %v1944, ptr %v1949, align 8, !tbaa !3
  %v1950 = getelementptr i8, ptr %v1945, i64 40
  store ptr inttoptr (i64 1 to ptr), ptr %v1950, align 8, !tbaa !3
  %v1951 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.646, ptr %v1945)
  ret ptr %v1951
}

define private ptr @mlf.code.1976(ptr %env, ptr %arg) {
entry:
  %v1978 = call ptr @mlf_prim1(i64 3, ptr @mlf.bytes.1977.value)
  ret ptr %v1978
}

define private ptr @mlf.numeric.7(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) alwaysinline {
entry:
  %v2387 = ptrtoint ptr %a3 to i64
  %v2388 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2389 = and i64 %v2387, %v2388
  %v2390 = and i64 %v2389, 1
  %v2391 = icmp ne i64 %v2390, 0
  br i1 %v2391, label %yes.2392, label %no.2393
yes.2392:
  %v2395 = sub i64 %v2388, 1
  %v2396 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2387, i64 %v2395)
  %v2397 = extractvalue { i64, i1 } %v2396, 0
  %v2398 = extractvalue { i64, i1 } %v2396, 1
  br i1 %v2398, label %yes.2399, label %no.2400
yes.2399:
  %v2402 = call ptr @mlf_add_int(ptr %a3, ptr inttoptr (i64 3 to ptr))
  br label %join.2401
no.2400:
  %v2403 = inttoptr i64 %v2397 to ptr
  br label %join.2401
join.2401:
  %v2404 = phi ptr [ %v2402, %yes.2399 ], [ %v2403, %no.2400 ]
  br label %join.2394
no.2393:
  %v2405 = call ptr @mlf_add_int(ptr %a3, ptr inttoptr (i64 3 to ptr))
  br label %join.2394
join.2394:
  %v2406 = phi ptr [ %v2404, %join.2401 ], [ %v2405, %no.2393 ]
  %v2407 = ptrtoint ptr %v2406 to i64
  %v2408 = ptrtoint ptr %a4 to i64
  %v2409 = and i64 %v2407, %v2408
  %v2410 = and i64 %v2409, 1
  %v2411 = icmp ne i64 %v2410, 0
  br i1 %v2411, label %yes.2412, label %no.2413
yes.2412:
  %v2415 = icmp slt i64 %v2407, %v2408
  %v2416 = select i1 %v2415, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.2414
no.2413:
  %v2417 = call ptr @mlf_lt_int(ptr %v2406, ptr %a4)
  br label %join.2414
join.2414:
  %v2418 = phi ptr [ %v2416, %yes.2412 ], [ %v2417, %no.2413 ]
  %v2419 = icmp eq ptr %v2418, inttoptr (i64 6 to ptr)
  br i1 %v2419, label %tail.yes.2420, label %tail.no.2421
tail.yes.2420:
  %v2422 = ptrtoint ptr %a3 to i64
  %v2423 = ptrtoint ptr %a4 to i64
  %v2424 = and i64 %v2422, %v2423
  %v2425 = and i64 %v2424, 1
  %v2426 = icmp ne i64 %v2425, 0
  br i1 %v2426, label %yes.2427, label %no.2428
yes.2427:
  %v2430 = sub i64 %v2423, 1
  %v2431 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2422, i64 %v2430)
  %v2432 = extractvalue { i64, i1 } %v2431, 0
  %v2433 = extractvalue { i64, i1 } %v2431, 1
  br i1 %v2433, label %yes.2434, label %no.2435
yes.2434:
  %v2437 = call ptr @mlf_add_int(ptr %a3, ptr %a4)
  br label %join.2436
no.2435:
  %v2438 = inttoptr i64 %v2432 to ptr
  br label %join.2436
join.2436:
  %v2439 = phi ptr [ %v2437, %yes.2434 ], [ %v2438, %no.2435 ]
  br label %join.2429
no.2428:
  %v2440 = call ptr @mlf_add_int(ptr %a3, ptr %a4)
  br label %join.2429
join.2429:
  %v2441 = phi ptr [ %v2439, %join.2436 ], [ %v2440, %no.2428 ]
  %v2442 = ptrtoint ptr %v2441 to i64
  %v2443 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v2444 = and i64 %v2442, %v2443
  %v2445 = and i64 %v2444, 1
  %v2446 = icmp ne i64 %v2445, 0
  br i1 %v2446, label %yes.2447, label %no.2448
yes.2447:
  %v2450 = ashr i64 %v2442, 1
  %v2451 = ashr i64 %v2443, 1
  %v2452 = icmp ne i64 %v2451, 0
  %v2453 = icmp eq i64 %v2450, -4611686018427387904
  %v2454 = icmp eq i64 %v2451, -1
  %v2455 = and i1 %v2453, %v2454
  %v2456 = xor i1 %v2455, true
  %v2457 = and i1 %v2452, %v2456
  br i1 %v2457, label %yes.2458, label %no.2459
yes.2458:
  %v2461 = sdiv i64 %v2450, %v2451
  %v2462 = shl i64 %v2461, 1
  %v2463 = or i64 %v2462, 1
  %v2464 = inttoptr i64 %v2463 to ptr
  br label %join.2460
no.2459:
  %v2465 = call ptr @mlf_prim2(i64 15, ptr %v2441, ptr inttoptr (i64 5 to ptr))
  br label %join.2460
join.2460:
  %v2466 = phi ptr [ %v2464, %yes.2458 ], [ %v2465, %no.2459 ]
  br label %join.2449
no.2448:
  %v2467 = call ptr @mlf_prim2(i64 15, ptr %v2441, ptr inttoptr (i64 5 to ptr))
  br label %join.2449
join.2449:
  %v2468 = phi ptr [ %v2466, %join.2460 ], [ %v2467, %no.2448 ]
  %v2469 = getelementptr i8, ptr %a1, i64 8
  %v2470 = load i64, ptr %v2469, align 8, !tbaa !3
  %v2471 = getelementptr i8, ptr %a1, i64 16
  %v2472 = load ptr, ptr %v2471, align 8, !tbaa !3
  %v2473 = ptrtoint ptr %v2468 to i64
  %v2474 = ashr i64 %v2473, 1
  %v2475 = and i64 %v2473, 1
  %v2476 = icmp ne i64 %v2475, 0
  %v2477 = icmp ult i64 %v2474, %v2470
  %v2478 = and i1 %v2476, %v2477
  br i1 %v2478, label %array.valid.2479, label %array.invalid.2480
array.invalid.2480:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2479:
  %v2481 = getelementptr i64, ptr %v2472, i64 %v2474
  %v2482 = load double, ptr %v2481, align 8, !tbaa !4
  %v2483 = getelementptr i8, ptr %a2, i64 8
  %v2484 = load i64, ptr %v2483, align 8, !tbaa !3
  %v2485 = getelementptr i8, ptr %a2, i64 16
  %v2486 = load ptr, ptr %v2485, align 8, !tbaa !3
  %v2487 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v2488 = ashr i64 %v2487, 1
  %v2489 = and i64 %v2487, 1
  %v2490 = icmp ne i64 %v2489, 0
  %v2491 = icmp ult i64 %v2488, %v2484
  %v2492 = and i1 %v2490, %v2491
  br i1 %v2492, label %array.valid.2493, label %array.invalid.2494
array.invalid.2494:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2493:
  %v2495 = getelementptr i64, ptr %v2486, i64 %v2488
  %v2496 = load double, ptr %v2495, align 8, !tbaa !4
  %v2497 = fcmp olt double %v2496, %v2482
  %v2498 = select i1 %v2497, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v2499 = icmp eq ptr %v2498, inttoptr (i64 6 to ptr)
  br i1 %v2499, label %tail.yes.2500, label %tail.no.2501
tail.yes.2500:
  %v2502 = musttail call ptr @mlf.numeric.7(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %v2468)
  ret ptr %v2502
tail.no.2501:
  %v2503 = musttail call ptr @mlf.numeric.7(ptr %a0, ptr %a1, ptr %a2, ptr %v2468, ptr %a4)
  ret ptr %v2503
tail.no.2421:
  %v2504 = getelementptr i8, ptr %a0, i64 8
  %v2505 = load i64, ptr %v2504, align 8, !tbaa !3
  %v2506 = getelementptr i8, ptr %a0, i64 16
  %v2507 = load ptr, ptr %v2506, align 8, !tbaa !3
  %v2508 = ptrtoint ptr %a4 to i64
  %v2509 = ashr i64 %v2508, 1
  %v2510 = and i64 %v2508, 1
  %v2511 = icmp ne i64 %v2510, 0
  %v2512 = icmp ult i64 %v2509, %v2505
  %v2513 = and i1 %v2511, %v2512
  br i1 %v2513, label %array.valid.2514, label %array.invalid.2515
array.invalid.2515:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2514:
  %v2516 = getelementptr i8, ptr %v2507, i64 %v2509
  %v2517 = load i8, ptr %v2516, align 1, !tbaa !4
  %v2518 = zext i8 %v2517 to i64
  %v2519 = shl i64 %v2518, 1
  %v2520 = or i64 %v2519, 1
  %v2521 = inttoptr i64 %v2520 to ptr
  ret ptr %v2521
}

define private ptr @mlf.numeric.40(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6, ptr %a7, ptr %a8, ptr %a9) alwaysinline {
entry:
  %v2594 = ptrtoint ptr %a8 to i64
  %v2595 = ptrtoint ptr %a9 to i64
  %v2596 = and i64 %v2594, %v2595
  %v2597 = and i64 %v2596, 1
  %v2598 = icmp ne i64 %v2597, 0
  br i1 %v2598, label %yes.2599, label %no.2600
yes.2599:
  %v2602 = sub i64 %v2595, 1
  %v2603 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2594, i64 %v2602)
  %v2604 = extractvalue { i64, i1 } %v2603, 0
  %v2605 = extractvalue { i64, i1 } %v2603, 1
  br i1 %v2605, label %yes.2606, label %no.2607
yes.2606:
  %v2609 = call ptr @mlf_add_int(ptr %a8, ptr %a9)
  br label %join.2608
no.2607:
  %v2610 = inttoptr i64 %v2604 to ptr
  br label %join.2608
join.2608:
  %v2611 = phi ptr [ %v2609, %yes.2606 ], [ %v2610, %no.2607 ]
  br label %join.2601
no.2600:
  %v2612 = call ptr @mlf_add_int(ptr %a8, ptr %a9)
  br label %join.2601
join.2601:
  %v2613 = phi ptr [ %v2611, %join.2608 ], [ %v2612, %no.2600 ]
  %v2614 = ptrtoint ptr %a7 to i64
  %v2615 = ptrtoint ptr %v2613 to i64
  %v2616 = and i64 %v2614, %v2615
  %v2617 = and i64 %v2616, 1
  %v2618 = icmp ne i64 %v2617, 0
  br i1 %v2618, label %yes.2619, label %no.2620
yes.2619:
  %v2622 = sub i64 %v2615, 1
  %v2623 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2614, i64 %v2622)
  %v2624 = extractvalue { i64, i1 } %v2623, 0
  %v2625 = extractvalue { i64, i1 } %v2623, 1
  br i1 %v2625, label %yes.2626, label %no.2627
yes.2626:
  %v2629 = call ptr @mlf_add_int(ptr %a7, ptr %v2613)
  br label %join.2628
no.2627:
  %v2630 = inttoptr i64 %v2624 to ptr
  br label %join.2628
join.2628:
  %v2631 = phi ptr [ %v2629, %yes.2626 ], [ %v2630, %no.2627 ]
  br label %join.2621
no.2620:
  %v2632 = call ptr @mlf_add_int(ptr %a7, ptr %v2613)
  br label %join.2621
join.2621:
  %v2633 = phi ptr [ %v2631, %join.2628 ], [ %v2632, %no.2620 ]
  %v2634 = icmp eq ptr inttoptr (i64 6 to ptr), inttoptr (i64 6 to ptr)
  br i1 %v2634, label %tail.yes.2635, label %tail.no.2636
tail.yes.2635:
  %v2637 = ptrtoint ptr %a8 to i64
  %v2638 = ptrtoint ptr inttoptr (i64 121 to ptr) to i64
  %v2639 = and i64 %v2637, %v2638
  %v2640 = and i64 %v2639, 1
  %v2641 = icmp ne i64 %v2640, 0
  br i1 %v2641, label %yes.2642, label %no.2643
yes.2642:
  %v2645 = icmp eq i64 %v2637, %v2638
  %v2646 = select i1 %v2645, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.2644
no.2643:
  %v2647 = call ptr @mlf_eq_int(ptr %a8, ptr inttoptr (i64 121 to ptr))
  br label %join.2644
join.2644:
  %v2648 = phi ptr [ %v2646, %yes.2642 ], [ %v2647, %no.2643 ]
  %v2649 = icmp eq ptr %v2648, inttoptr (i64 6 to ptr)
  br i1 %v2649, label %tail.yes.2650, label %tail.no.2651
tail.yes.2650:
  %v2652 = getelementptr i8, ptr %a4, i64 8
  %v2653 = load i64, ptr %v2652, align 8, !tbaa !3
  %v2654 = getelementptr i8, ptr %a4, i64 16
  %v2655 = load ptr, ptr %v2654, align 8, !tbaa !3
  %v2656 = ptrtoint ptr %a9 to i64
  %v2657 = ashr i64 %v2656, 1
  %v2658 = and i64 %v2656, 1
  %v2659 = icmp ne i64 %v2658, 0
  %v2660 = icmp ult i64 %v2657, %v2653
  %v2661 = and i1 %v2659, %v2660
  br i1 %v2661, label %array.valid.2662, label %array.invalid.2663
array.invalid.2663:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2662:
  %v2664 = getelementptr i8, ptr %v2655, i64 %v2657
  %v2665 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v2666 = ashr i64 %v2665, 1
  %v2667 = trunc i64 %v2666 to i8
  store i8 %v2667, ptr %v2664, align 1, !tbaa !4
  %v2668 = ptrtoint ptr %a9 to i64
  %v2669 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2670 = sub i64 %v2669, 1
  %v2671 = add nsw i64 %v2668, %v2670
  %v2672 = inttoptr i64 %v2671 to ptr
  %v2673 = musttail call ptr @mlf.numeric.40.ppppppppnp(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6, ptr %a7, ptr inttoptr (i64 1 to ptr), ptr %v2672)
  ret ptr %v2673
tail.no.2651:
  %v2674 = ptrtoint ptr %a7 to i64
  %v2675 = ptrtoint ptr %a6 to i64
  %v2676 = and i64 %v2674, %v2675
  %v2677 = and i64 %v2676, 1
  %v2678 = icmp ne i64 %v2677, 0
  br i1 %v2678, label %yes.2679, label %no.2680
yes.2679:
  %v2682 = icmp eq i64 %v2674, %v2675
  %v2683 = select i1 %v2682, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.2681
no.2680:
  %v2684 = call ptr @mlf_eq_int(ptr %a7, ptr %a6)
  br label %join.2681
join.2681:
  %v2685 = phi ptr [ %v2683, %yes.2679 ], [ %v2684, %no.2680 ]
  %v2686 = icmp eq ptr %v2685, inttoptr (i64 6 to ptr)
  br i1 %v2686, label %tail.yes.2687, label %tail.no.2688
tail.yes.2687:
  %v2689 = ptrtoint ptr %a8 to i64
  %v2690 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v2691 = and i64 %v2689, %v2690
  %v2692 = and i64 %v2691, 1
  %v2693 = icmp ne i64 %v2692, 0
  br i1 %v2693, label %yes.2694, label %no.2695
yes.2694:
  %v2697 = icmp eq i64 %v2689, %v2690
  %v2698 = select i1 %v2697, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.2696
no.2695:
  %v2699 = call ptr @mlf_eq_int(ptr %a8, ptr inttoptr (i64 1 to ptr))
  br label %join.2696
join.2696:
  %v2700 = phi ptr [ %v2698, %yes.2694 ], [ %v2699, %no.2695 ]
  %v2701 = icmp eq ptr %v2700, inttoptr (i64 6 to ptr)
  br i1 %v2701, label %tail.yes.2702, label %tail.no.2703
tail.yes.2702:
  ret ptr inttoptr (i64 4 to ptr)
tail.no.2703:
  %v2704 = getelementptr i8, ptr %a4, i64 8
  %v2705 = load i64, ptr %v2704, align 8, !tbaa !3
  %v2706 = getelementptr i8, ptr %a4, i64 16
  %v2707 = load ptr, ptr %v2706, align 8, !tbaa !3
  %v2708 = ptrtoint ptr %a9 to i64
  %v2709 = ashr i64 %v2708, 1
  %v2710 = and i64 %v2708, 1
  %v2711 = icmp ne i64 %v2710, 0
  %v2712 = icmp ult i64 %v2709, %v2705
  %v2713 = and i1 %v2711, %v2712
  br i1 %v2713, label %array.valid.2714, label %array.invalid.2715
array.invalid.2715:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2714:
  %v2716 = getelementptr i8, ptr %v2707, i64 %v2709
  %v2717 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v2718 = ashr i64 %v2717, 1
  %v2719 = trunc i64 %v2718 to i8
  store i8 %v2719, ptr %v2716, align 1, !tbaa !4
  ret ptr inttoptr (i64 4 to ptr)
tail.no.2688:
  %v2720 = getelementptr i8, ptr %a2, i64 8
  %v2721 = load i64, ptr %v2720, align 8, !tbaa !3
  %v2722 = getelementptr i8, ptr %a2, i64 16
  %v2723 = load ptr, ptr %v2722, align 8, !tbaa !3
  %v2724 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v2725 = ashr i64 %v2724, 1
  %v2726 = and i64 %v2724, 1
  %v2727 = icmp ne i64 %v2726, 0
  %v2728 = icmp ult i64 %v2725, %v2721
  %v2729 = and i1 %v2727, %v2728
  br i1 %v2729, label %array.valid.2730, label %array.invalid.2731
array.invalid.2731:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2730:
  %v2732 = getelementptr i64, ptr %v2723, i64 %v2725
  %v2733 = load ptr, ptr %v2732, align 8, !tbaa !4
  %v2734 = ptrtoint ptr %v2733 to i64
  %v2735 = ptrtoint ptr inttoptr (i64 7755 to ptr) to i64
  %v2736 = and i64 %v2734, %v2735
  %v2737 = and i64 %v2736, 1
  %v2738 = icmp ne i64 %v2737, 0
  br i1 %v2738, label %yes.2739, label %no.2740
yes.2739:
  %v2742 = ashr i64 %v2734, 1
  %v2743 = ashr i64 %v2735, 1
  %v2744 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v2742, i64 %v2743)
  %v2745 = extractvalue { i64, i1 } %v2744, 0
  %v2746 = extractvalue { i64, i1 } %v2744, 1
  %v2747 = xor i1 %v2746, true
  %v2748 = icmp sge i64 %v2745, -4611686018427387904
  %v2749 = icmp sle i64 %v2745, 4611686018427387903
  %v2750 = and i1 %v2748, %v2749
  %v2751 = and i1 %v2750, %v2747
  br i1 %v2751, label %yes.2752, label %no.2753
yes.2752:
  %v2755 = shl i64 %v2745, 1
  %v2756 = or i64 %v2755, 1
  %v2757 = inttoptr i64 %v2756 to ptr
  br label %join.2754
no.2753:
  %v2758 = call ptr @mlf_prim2(i64 14, ptr %v2733, ptr inttoptr (i64 7755 to ptr))
  br label %join.2754
join.2754:
  %v2759 = phi ptr [ %v2757, %yes.2752 ], [ %v2758, %no.2753 ]
  br label %join.2741
no.2740:
  %v2760 = call ptr @mlf_prim2(i64 14, ptr %v2733, ptr inttoptr (i64 7755 to ptr))
  br label %join.2741
join.2741:
  %v2761 = phi ptr [ %v2759, %join.2754 ], [ %v2760, %no.2740 ]
  %v2762 = ptrtoint ptr %v2761 to i64
  %v2763 = ptrtoint ptr inttoptr (i64 59147 to ptr) to i64
  %v2764 = and i64 %v2762, %v2763
  %v2765 = and i64 %v2764, 1
  %v2766 = icmp ne i64 %v2765, 0
  br i1 %v2766, label %yes.2767, label %no.2768
yes.2767:
  %v2770 = sub i64 %v2763, 1
  %v2771 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2762, i64 %v2770)
  %v2772 = extractvalue { i64, i1 } %v2771, 0
  %v2773 = extractvalue { i64, i1 } %v2771, 1
  br i1 %v2773, label %yes.2774, label %no.2775
yes.2774:
  %v2777 = call ptr @mlf_add_int(ptr %v2761, ptr inttoptr (i64 59147 to ptr))
  br label %join.2776
no.2775:
  %v2778 = inttoptr i64 %v2772 to ptr
  br label %join.2776
join.2776:
  %v2779 = phi ptr [ %v2777, %yes.2774 ], [ %v2778, %no.2775 ]
  br label %join.2769
no.2768:
  %v2780 = call ptr @mlf_add_int(ptr %v2761, ptr inttoptr (i64 59147 to ptr))
  br label %join.2769
join.2769:
  %v2781 = phi ptr [ %v2779, %join.2776 ], [ %v2780, %no.2768 ]
  %v2782 = ptrtoint ptr %v2781 to i64
  %v2783 = ptrtoint ptr inttoptr (i64 279937 to ptr) to i64
  %v2784 = and i64 %v2782, %v2783
  %v2785 = and i64 %v2784, 1
  %v2786 = icmp ne i64 %v2785, 0
  br i1 %v2786, label %yes.2787, label %no.2788
yes.2787:
  %v2790 = ashr i64 %v2782, 1
  %v2791 = ashr i64 %v2783, 1
  %v2792 = icmp ne i64 %v2791, 0
  %v2793 = icmp eq i64 %v2790, -4611686018427387904
  %v2794 = icmp eq i64 %v2791, -1
  %v2795 = and i1 %v2793, %v2794
  %v2796 = xor i1 %v2795, true
  %v2797 = and i1 %v2792, %v2796
  br i1 %v2797, label %yes.2798, label %no.2799
yes.2798:
  %v2801 = srem i64 %v2790, %v2791
  %v2802 = shl i64 %v2801, 1
  %v2803 = or i64 %v2802, 1
  %v2804 = inttoptr i64 %v2803 to ptr
  br label %join.2800
no.2799:
  %v2805 = call ptr @mlf_prim2(i64 16, ptr %v2781, ptr inttoptr (i64 279937 to ptr))
  br label %join.2800
join.2800:
  %v2806 = phi ptr [ %v2804, %yes.2798 ], [ %v2805, %no.2799 ]
  br label %join.2789
no.2788:
  %v2807 = call ptr @mlf_prim2(i64 16, ptr %v2781, ptr inttoptr (i64 279937 to ptr))
  br label %join.2789
join.2789:
  %v2808 = phi ptr [ %v2806, %join.2800 ], [ %v2807, %no.2788 ]
  %v2809 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v2810 = ashr i64 %v2809, 1
  %v2811 = and i64 %v2809, 1
  %v2812 = icmp ne i64 %v2811, 0
  %v2813 = icmp ult i64 %v2810, %v2721
  %v2814 = and i1 %v2812, %v2813
  br i1 %v2814, label %array.valid.2815, label %array.invalid.2816
array.invalid.2816:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2815:
  %v2817 = getelementptr i64, ptr %v2723, i64 %v2810
  store ptr %v2808, ptr %v2817, align 8, !tbaa !4
  %v2818 = ptrtoint ptr %v2808 to i64
  %v2819 = and i64 %v2818, 1
  %v2820 = icmp ne i64 %v2819, 0
  br i1 %v2820, label %yes.2821, label %no.2822
yes.2821:
  %v2824 = ashr i64 %v2818, 1
  %v2825 = sitofp i64 %v2824 to double
  br label %join.2823
no.2822:
  %v2826 = call double @mlf_int_to_double(ptr %v2808)
  br label %join.2823
join.2823:
  %v2827 = phi double [ %v2825, %yes.2821 ], [ %v2826, %no.2822 ]
  %v2828 = fdiv double %v2827, 0x4101160000000000
  %v2829 = getelementptr i8, ptr %a3, i64 8
  %v2830 = load i64, ptr %v2829, align 8, !tbaa !3
  %v2831 = getelementptr i8, ptr %a3, i64 16
  %v2832 = load ptr, ptr %v2831, align 8, !tbaa !3
  %v2833 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v2834 = ashr i64 %v2833, 1
  %v2835 = and i64 %v2833, 1
  %v2836 = icmp ne i64 %v2835, 0
  %v2837 = icmp ult i64 %v2834, %v2830
  %v2838 = and i1 %v2836, %v2837
  br i1 %v2838, label %array.valid.2839, label %array.invalid.2840
array.invalid.2840:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2839:
  %v2841 = getelementptr i64, ptr %v2832, i64 %v2834
  store double %v2828, ptr %v2841, align 8, !tbaa !4
  %v2842 = getelementptr i8, ptr %a1, i64 8
  %v2843 = load i64, ptr %v2842, align 8, !tbaa !3
  %v2844 = getelementptr i8, ptr %a1, i64 16
  %v2845 = load ptr, ptr %v2844, align 8, !tbaa !3
  %v2846 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v2847 = ashr i64 %v2846, 1
  %v2848 = and i64 %v2846, 1
  %v2849 = icmp ne i64 %v2848, 0
  %v2850 = icmp ult i64 %v2847, %v2843
  %v2851 = and i1 %v2849, %v2850
  br i1 %v2851, label %array.valid.2852, label %array.invalid.2853
array.invalid.2853:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2852:
  %v2854 = getelementptr i64, ptr %v2845, i64 %v2847
  %v2855 = load double, ptr %v2854, align 8, !tbaa !4
  %v2856 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v2857 = ashr i64 %v2856, 1
  %v2858 = and i64 %v2856, 1
  %v2859 = icmp ne i64 %v2858, 0
  %v2860 = icmp ult i64 %v2857, %v2830
  %v2861 = and i1 %v2859, %v2860
  br i1 %v2861, label %array.valid.2862, label %array.invalid.2863
array.invalid.2863:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2862:
  %v2864 = getelementptr i64, ptr %v2832, i64 %v2857
  %v2865 = load double, ptr %v2864, align 8, !tbaa !4
  %v2866 = fcmp olt double %v2865, %v2855
  %v2867 = select i1 %v2866, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v2868 = icmp eq ptr %v2867, inttoptr (i64 6 to ptr)
  br i1 %v2868, label %yes.2869, label %no.2870
yes.2869:
  %v2872 = getelementptr i8, ptr %a0, i64 8
  %v2873 = load i64, ptr %v2872, align 8, !tbaa !3
  %v2874 = getelementptr i8, ptr %a0, i64 16
  %v2875 = load ptr, ptr %v2874, align 8, !tbaa !3
  %v2876 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v2877 = ashr i64 %v2876, 1
  %v2878 = and i64 %v2876, 1
  %v2879 = icmp ne i64 %v2878, 0
  %v2880 = icmp ult i64 %v2877, %v2873
  %v2881 = and i1 %v2879, %v2880
  br i1 %v2881, label %array.valid.2882, label %array.invalid.2883
array.invalid.2883:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2882:
  %v2884 = getelementptr i8, ptr %v2875, i64 %v2877
  %v2885 = load i8, ptr %v2884, align 1, !tbaa !4
  %v2886 = zext i8 %v2885 to i64
  %v2887 = shl i64 %v2886, 1
  %v2888 = or i64 %v2887, 1
  %v2889 = inttoptr i64 %v2888 to ptr
  br label %join.2871
no.2870:
  %v2890 = ptrtoint ptr %a5 to i64
  %v2891 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2892 = and i64 %v2890, %v2891
  %v2893 = and i64 %v2892, 1
  %v2894 = icmp ne i64 %v2893, 0
  br i1 %v2894, label %yes.2895, label %no.2896
yes.2895:
  %v2898 = sub i64 %v2891, 1
  %v2899 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v2890, i64 %v2898)
  %v2900 = extractvalue { i64, i1 } %v2899, 0
  %v2901 = extractvalue { i64, i1 } %v2899, 1
  br i1 %v2901, label %yes.2902, label %no.2903
yes.2902:
  %v2905 = call ptr @mlf_sub_int(ptr %a5, ptr inttoptr (i64 3 to ptr))
  br label %join.2904
no.2903:
  %v2906 = inttoptr i64 %v2900 to ptr
  br label %join.2904
join.2904:
  %v2907 = phi ptr [ %v2905, %yes.2902 ], [ %v2906, %no.2903 ]
  br label %join.2897
no.2896:
  %v2908 = call ptr @mlf_sub_int(ptr %a5, ptr inttoptr (i64 3 to ptr))
  br label %join.2897
join.2897:
  %v2909 = phi ptr [ %v2907, %join.2904 ], [ %v2908, %no.2896 ]
  %v2910 = call ptr @mlf.numeric.7(ptr %a0, ptr %a1, ptr %a3, ptr inttoptr (i64 1 to ptr), ptr %v2909)
  br label %join.2871
join.2871:
  %v2911 = phi ptr [ %v2889, %array.valid.2882 ], [ %v2910, %join.2897 ]
  %v2912 = getelementptr i8, ptr %a4, i64 8
  %v2913 = load i64, ptr %v2912, align 8, !tbaa !3
  %v2914 = getelementptr i8, ptr %a4, i64 16
  %v2915 = load ptr, ptr %v2914, align 8, !tbaa !3
  %v2916 = ptrtoint ptr %a9 to i64
  %v2917 = ashr i64 %v2916, 1
  %v2918 = and i64 %v2916, 1
  %v2919 = icmp ne i64 %v2918, 0
  %v2920 = icmp ult i64 %v2917, %v2913
  %v2921 = and i1 %v2919, %v2920
  br i1 %v2921, label %array.valid.2922, label %array.invalid.2923
array.invalid.2923:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2922:
  %v2924 = getelementptr i8, ptr %v2915, i64 %v2917
  %v2925 = ptrtoint ptr %v2911 to i64
  %v2926 = ashr i64 %v2925, 1
  %v2927 = and i64 %v2925, 1
  %v2928 = icmp ne i64 %v2927, 0
  %v2929 = icmp ult i64 %v2926, 256
  %v2930 = and i1 %v2928, %v2929
  br i1 %v2930, label %yes.2931, label %no.2932
yes.2931:
  %v2934 = trunc i64 %v2926 to i8
  br label %join.2933
no.2932:
  %v2935 = call i8 @mlf_byte(ptr %v2911)
  br label %join.2933
join.2933:
  %v2936 = phi i8 [ %v2934, %yes.2931 ], [ %v2935, %no.2932 ]
  store i8 %v2936, ptr %v2924, align 1, !tbaa !4
  %v2937 = ptrtoint ptr %a7 to i64
  %v2938 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2939 = and i64 %v2937, %v2938
  %v2940 = and i64 %v2939, 1
  %v2941 = icmp ne i64 %v2940, 0
  br i1 %v2941, label %yes.2942, label %no.2943
yes.2942:
  %v2945 = sub i64 %v2938, 1
  %v2946 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2937, i64 %v2945)
  %v2947 = extractvalue { i64, i1 } %v2946, 0
  %v2948 = extractvalue { i64, i1 } %v2946, 1
  br i1 %v2948, label %yes.2949, label %no.2950
yes.2949:
  %v2952 = call ptr @mlf_add_int(ptr %a7, ptr inttoptr (i64 3 to ptr))
  br label %join.2951
no.2950:
  %v2953 = inttoptr i64 %v2947 to ptr
  br label %join.2951
join.2951:
  %v2954 = phi ptr [ %v2952, %yes.2949 ], [ %v2953, %no.2950 ]
  br label %join.2944
no.2943:
  %v2955 = call ptr @mlf_add_int(ptr %a7, ptr inttoptr (i64 3 to ptr))
  br label %join.2944
join.2944:
  %v2956 = phi ptr [ %v2954, %join.2951 ], [ %v2955, %no.2943 ]
  %v2957 = ptrtoint ptr %a8 to i64
  %v2958 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2959 = and i64 %v2957, %v2958
  %v2960 = and i64 %v2959, 1
  %v2961 = icmp ne i64 %v2960, 0
  br i1 %v2961, label %yes.2962, label %no.2963
yes.2962:
  %v2965 = sub i64 %v2958, 1
  %v2966 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2957, i64 %v2965)
  %v2967 = extractvalue { i64, i1 } %v2966, 0
  %v2968 = extractvalue { i64, i1 } %v2966, 1
  br i1 %v2968, label %yes.2969, label %no.2970
yes.2969:
  %v2972 = call ptr @mlf_add_int(ptr %a8, ptr inttoptr (i64 3 to ptr))
  br label %join.2971
no.2970:
  %v2973 = inttoptr i64 %v2967 to ptr
  br label %join.2971
join.2971:
  %v2974 = phi ptr [ %v2972, %yes.2969 ], [ %v2973, %no.2970 ]
  br label %join.2964
no.2963:
  %v2975 = call ptr @mlf_add_int(ptr %a8, ptr inttoptr (i64 3 to ptr))
  br label %join.2964
join.2964:
  %v2976 = phi ptr [ %v2974, %join.2971 ], [ %v2975, %no.2963 ]
  %v2977 = ptrtoint ptr %a9 to i64
  %v2978 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2979 = sub i64 %v2978, 1
  %v2980 = add nsw i64 %v2977, %v2979
  %v2981 = inttoptr i64 %v2980 to ptr
  %v2982 = musttail call ptr @mlf.numeric.40(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6, ptr %v2956, ptr %v2976, ptr %v2981)
  ret ptr %v2982
tail.no.2636:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.numeric.40.ppppppppnp(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6, ptr %a7, ptr %a8, ptr %a9) alwaysinline {
entry:
  %v2087 = ptrtoint ptr %a8 to i64
  %v2088 = ptrtoint ptr %a9 to i64
  %v2089 = and i64 %v2087, %v2088
  %v2090 = and i64 %v2089, 1
  %v2091 = icmp ne i64 %v2090, 0
  br i1 %v2091, label %yes.2092, label %no.2093
yes.2092:
  %v2095 = sub i64 %v2088, 1
  %v2096 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2087, i64 %v2095)
  %v2097 = extractvalue { i64, i1 } %v2096, 0
  %v2098 = extractvalue { i64, i1 } %v2096, 1
  br i1 %v2098, label %yes.2099, label %no.2100
yes.2099:
  %v2102 = call ptr @mlf_add_int(ptr %a8, ptr %a9)
  br label %join.2101
no.2100:
  %v2103 = inttoptr i64 %v2097 to ptr
  br label %join.2101
join.2101:
  %v2104 = phi ptr [ %v2102, %yes.2099 ], [ %v2103, %no.2100 ]
  br label %join.2094
no.2093:
  %v2105 = call ptr @mlf_add_int(ptr %a8, ptr %a9)
  br label %join.2094
join.2094:
  %v2106 = phi ptr [ %v2104, %join.2101 ], [ %v2105, %no.2093 ]
  %v2107 = ptrtoint ptr %a7 to i64
  %v2108 = ptrtoint ptr %v2106 to i64
  %v2109 = and i64 %v2107, %v2108
  %v2110 = and i64 %v2109, 1
  %v2111 = icmp ne i64 %v2110, 0
  br i1 %v2111, label %yes.2112, label %no.2113
yes.2112:
  %v2115 = sub i64 %v2108, 1
  %v2116 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2107, i64 %v2115)
  %v2117 = extractvalue { i64, i1 } %v2116, 0
  %v2118 = extractvalue { i64, i1 } %v2116, 1
  br i1 %v2118, label %yes.2119, label %no.2120
yes.2119:
  %v2122 = call ptr @mlf_add_int(ptr %a7, ptr %v2106)
  br label %join.2121
no.2120:
  %v2123 = inttoptr i64 %v2117 to ptr
  br label %join.2121
join.2121:
  %v2124 = phi ptr [ %v2122, %yes.2119 ], [ %v2123, %no.2120 ]
  br label %join.2114
no.2113:
  %v2125 = call ptr @mlf_add_int(ptr %a7, ptr %v2106)
  br label %join.2114
join.2114:
  %v2126 = phi ptr [ %v2124, %join.2121 ], [ %v2125, %no.2113 ]
  %v2127 = icmp eq ptr inttoptr (i64 6 to ptr), inttoptr (i64 6 to ptr)
  br i1 %v2127, label %tail.yes.2128, label %tail.no.2129
tail.yes.2128:
  %v2130 = ptrtoint ptr %a8 to i64
  %v2131 = ptrtoint ptr inttoptr (i64 121 to ptr) to i64
  %v2132 = icmp eq i64 %v2130, %v2131
  %v2133 = select i1 %v2132, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v2134 = icmp eq ptr %v2133, inttoptr (i64 6 to ptr)
  br i1 %v2134, label %tail.yes.2135, label %tail.no.2136
tail.yes.2135:
  %v2137 = getelementptr i8, ptr %a4, i64 8
  %v2138 = load i64, ptr %v2137, align 8, !tbaa !3
  %v2139 = getelementptr i8, ptr %a4, i64 16
  %v2140 = load ptr, ptr %v2139, align 8, !tbaa !3
  %v2141 = ptrtoint ptr %a9 to i64
  %v2142 = ashr i64 %v2141, 1
  %v2143 = and i64 %v2141, 1
  %v2144 = icmp ne i64 %v2143, 0
  %v2145 = icmp ult i64 %v2142, %v2138
  %v2146 = and i1 %v2144, %v2145
  br i1 %v2146, label %array.valid.2147, label %array.invalid.2148
array.invalid.2148:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2147:
  %v2149 = getelementptr i8, ptr %v2140, i64 %v2142
  %v2150 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v2151 = ashr i64 %v2150, 1
  %v2152 = trunc i64 %v2151 to i8
  store i8 %v2152, ptr %v2149, align 1, !tbaa !4
  %v2153 = ptrtoint ptr %a9 to i64
  %v2154 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2155 = sub i64 %v2154, 1
  %v2156 = add nsw i64 %v2153, %v2155
  %v2157 = inttoptr i64 %v2156 to ptr
  %v2158 = musttail call ptr @mlf.numeric.40.ppppppppnp(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6, ptr %a7, ptr inttoptr (i64 1 to ptr), ptr %v2157)
  ret ptr %v2158
tail.no.2136:
  %v2159 = ptrtoint ptr %a7 to i64
  %v2160 = ptrtoint ptr %a6 to i64
  %v2161 = and i64 %v2159, %v2160
  %v2162 = and i64 %v2161, 1
  %v2163 = icmp ne i64 %v2162, 0
  br i1 %v2163, label %yes.2164, label %no.2165
yes.2164:
  %v2167 = icmp eq i64 %v2159, %v2160
  %v2168 = select i1 %v2167, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.2166
no.2165:
  %v2169 = call ptr @mlf_eq_int(ptr %a7, ptr %a6)
  br label %join.2166
join.2166:
  %v2170 = phi ptr [ %v2168, %yes.2164 ], [ %v2169, %no.2165 ]
  %v2171 = icmp eq ptr %v2170, inttoptr (i64 6 to ptr)
  br i1 %v2171, label %tail.yes.2172, label %tail.no.2173
tail.yes.2172:
  %v2174 = ptrtoint ptr %a8 to i64
  %v2175 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v2176 = icmp eq i64 %v2174, %v2175
  %v2177 = select i1 %v2176, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v2178 = icmp eq ptr %v2177, inttoptr (i64 6 to ptr)
  br i1 %v2178, label %tail.yes.2179, label %tail.no.2180
tail.yes.2179:
  ret ptr inttoptr (i64 4 to ptr)
tail.no.2180:
  %v2181 = getelementptr i8, ptr %a4, i64 8
  %v2182 = load i64, ptr %v2181, align 8, !tbaa !3
  %v2183 = getelementptr i8, ptr %a4, i64 16
  %v2184 = load ptr, ptr %v2183, align 8, !tbaa !3
  %v2185 = ptrtoint ptr %a9 to i64
  %v2186 = ashr i64 %v2185, 1
  %v2187 = and i64 %v2185, 1
  %v2188 = icmp ne i64 %v2187, 0
  %v2189 = icmp ult i64 %v2186, %v2182
  %v2190 = and i1 %v2188, %v2189
  br i1 %v2190, label %array.valid.2191, label %array.invalid.2192
array.invalid.2192:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2191:
  %v2193 = getelementptr i8, ptr %v2184, i64 %v2186
  %v2194 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v2195 = ashr i64 %v2194, 1
  %v2196 = trunc i64 %v2195 to i8
  store i8 %v2196, ptr %v2193, align 1, !tbaa !4
  ret ptr inttoptr (i64 4 to ptr)
tail.no.2173:
  %v2197 = getelementptr i8, ptr %a2, i64 8
  %v2198 = load i64, ptr %v2197, align 8, !tbaa !3
  %v2199 = getelementptr i8, ptr %a2, i64 16
  %v2200 = load ptr, ptr %v2199, align 8, !tbaa !3
  %v2201 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v2202 = ashr i64 %v2201, 1
  %v2203 = and i64 %v2201, 1
  %v2204 = icmp ne i64 %v2203, 0
  %v2205 = icmp ult i64 %v2202, %v2198
  %v2206 = and i1 %v2204, %v2205
  br i1 %v2206, label %array.valid.2207, label %array.invalid.2208
array.invalid.2208:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2207:
  %v2209 = getelementptr i64, ptr %v2200, i64 %v2202
  %v2210 = load ptr, ptr %v2209, align 8, !tbaa !4
  %v2211 = ptrtoint ptr %v2210 to i64
  %v2212 = ptrtoint ptr inttoptr (i64 7755 to ptr) to i64
  %v2213 = and i64 %v2211, %v2212
  %v2214 = and i64 %v2213, 1
  %v2215 = icmp ne i64 %v2214, 0
  br i1 %v2215, label %yes.2216, label %no.2217
yes.2216:
  %v2219 = ashr i64 %v2211, 1
  %v2220 = ashr i64 %v2212, 1
  %v2221 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v2219, i64 %v2220)
  %v2222 = extractvalue { i64, i1 } %v2221, 0
  %v2223 = extractvalue { i64, i1 } %v2221, 1
  %v2224 = xor i1 %v2223, true
  %v2225 = icmp sge i64 %v2222, -4611686018427387904
  %v2226 = icmp sle i64 %v2222, 4611686018427387903
  %v2227 = and i1 %v2225, %v2226
  %v2228 = and i1 %v2227, %v2224
  br i1 %v2228, label %yes.2229, label %no.2230
yes.2229:
  %v2232 = shl i64 %v2222, 1
  %v2233 = or i64 %v2232, 1
  %v2234 = inttoptr i64 %v2233 to ptr
  br label %join.2231
no.2230:
  %v2235 = call ptr @mlf_prim2(i64 14, ptr %v2210, ptr inttoptr (i64 7755 to ptr))
  br label %join.2231
join.2231:
  %v2236 = phi ptr [ %v2234, %yes.2229 ], [ %v2235, %no.2230 ]
  br label %join.2218
no.2217:
  %v2237 = call ptr @mlf_prim2(i64 14, ptr %v2210, ptr inttoptr (i64 7755 to ptr))
  br label %join.2218
join.2218:
  %v2238 = phi ptr [ %v2236, %join.2231 ], [ %v2237, %no.2217 ]
  %v2239 = ptrtoint ptr %v2238 to i64
  %v2240 = ptrtoint ptr inttoptr (i64 59147 to ptr) to i64
  %v2241 = and i64 %v2239, %v2240
  %v2242 = and i64 %v2241, 1
  %v2243 = icmp ne i64 %v2242, 0
  br i1 %v2243, label %yes.2244, label %no.2245
yes.2244:
  %v2247 = sub i64 %v2240, 1
  %v2248 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2239, i64 %v2247)
  %v2249 = extractvalue { i64, i1 } %v2248, 0
  %v2250 = extractvalue { i64, i1 } %v2248, 1
  br i1 %v2250, label %yes.2251, label %no.2252
yes.2251:
  %v2254 = call ptr @mlf_add_int(ptr %v2238, ptr inttoptr (i64 59147 to ptr))
  br label %join.2253
no.2252:
  %v2255 = inttoptr i64 %v2249 to ptr
  br label %join.2253
join.2253:
  %v2256 = phi ptr [ %v2254, %yes.2251 ], [ %v2255, %no.2252 ]
  br label %join.2246
no.2245:
  %v2257 = call ptr @mlf_add_int(ptr %v2238, ptr inttoptr (i64 59147 to ptr))
  br label %join.2246
join.2246:
  %v2258 = phi ptr [ %v2256, %join.2253 ], [ %v2257, %no.2245 ]
  %v2259 = ptrtoint ptr %v2258 to i64
  %v2260 = ptrtoint ptr inttoptr (i64 279937 to ptr) to i64
  %v2261 = and i64 %v2259, %v2260
  %v2262 = and i64 %v2261, 1
  %v2263 = icmp ne i64 %v2262, 0
  br i1 %v2263, label %yes.2264, label %no.2265
yes.2264:
  %v2267 = ashr i64 %v2259, 1
  %v2268 = ashr i64 %v2260, 1
  %v2269 = icmp ne i64 %v2268, 0
  %v2270 = icmp eq i64 %v2267, -4611686018427387904
  %v2271 = icmp eq i64 %v2268, -1
  %v2272 = and i1 %v2270, %v2271
  %v2273 = xor i1 %v2272, true
  %v2274 = and i1 %v2269, %v2273
  br i1 %v2274, label %yes.2275, label %no.2276
yes.2275:
  %v2278 = srem i64 %v2267, %v2268
  %v2279 = shl i64 %v2278, 1
  %v2280 = or i64 %v2279, 1
  %v2281 = inttoptr i64 %v2280 to ptr
  br label %join.2277
no.2276:
  %v2282 = call ptr @mlf_prim2(i64 16, ptr %v2258, ptr inttoptr (i64 279937 to ptr))
  br label %join.2277
join.2277:
  %v2283 = phi ptr [ %v2281, %yes.2275 ], [ %v2282, %no.2276 ]
  br label %join.2266
no.2265:
  %v2284 = call ptr @mlf_prim2(i64 16, ptr %v2258, ptr inttoptr (i64 279937 to ptr))
  br label %join.2266
join.2266:
  %v2285 = phi ptr [ %v2283, %join.2277 ], [ %v2284, %no.2265 ]
  %v2286 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v2287 = ashr i64 %v2286, 1
  %v2288 = and i64 %v2286, 1
  %v2289 = icmp ne i64 %v2288, 0
  %v2290 = icmp ult i64 %v2287, %v2198
  %v2291 = and i1 %v2289, %v2290
  br i1 %v2291, label %array.valid.2292, label %array.invalid.2293
array.invalid.2293:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2292:
  %v2294 = getelementptr i64, ptr %v2200, i64 %v2287
  store ptr %v2285, ptr %v2294, align 8, !tbaa !4
  %v2295 = ptrtoint ptr %v2285 to i64
  %v2296 = and i64 %v2295, 1
  %v2297 = icmp ne i64 %v2296, 0
  br i1 %v2297, label %yes.2298, label %no.2299
yes.2298:
  %v2301 = ashr i64 %v2295, 1
  %v2302 = sitofp i64 %v2301 to double
  br label %join.2300
no.2299:
  %v2303 = call double @mlf_int_to_double(ptr %v2285)
  br label %join.2300
join.2300:
  %v2304 = phi double [ %v2302, %yes.2298 ], [ %v2303, %no.2299 ]
  %v2305 = fdiv double %v2304, 0x4101160000000000
  %v2306 = getelementptr i8, ptr %a3, i64 8
  %v2307 = load i64, ptr %v2306, align 8, !tbaa !3
  %v2308 = getelementptr i8, ptr %a3, i64 16
  %v2309 = load ptr, ptr %v2308, align 8, !tbaa !3
  %v2310 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v2311 = ashr i64 %v2310, 1
  %v2312 = and i64 %v2310, 1
  %v2313 = icmp ne i64 %v2312, 0
  %v2314 = icmp ult i64 %v2311, %v2307
  %v2315 = and i1 %v2313, %v2314
  br i1 %v2315, label %array.valid.2316, label %array.invalid.2317
array.invalid.2317:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2316:
  %v2318 = getelementptr i64, ptr %v2309, i64 %v2311
  store double %v2305, ptr %v2318, align 8, !tbaa !4
  %v2319 = getelementptr i8, ptr %a1, i64 8
  %v2320 = load i64, ptr %v2319, align 8, !tbaa !3
  %v2321 = getelementptr i8, ptr %a1, i64 16
  %v2322 = load ptr, ptr %v2321, align 8, !tbaa !3
  %v2323 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v2324 = ashr i64 %v2323, 1
  %v2325 = and i64 %v2323, 1
  %v2326 = icmp ne i64 %v2325, 0
  %v2327 = icmp ult i64 %v2324, %v2320
  %v2328 = and i1 %v2326, %v2327
  br i1 %v2328, label %array.valid.2329, label %array.invalid.2330
array.invalid.2330:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2329:
  %v2331 = getelementptr i64, ptr %v2322, i64 %v2324
  %v2332 = load double, ptr %v2331, align 8, !tbaa !4
  %v2333 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v2334 = ashr i64 %v2333, 1
  %v2335 = and i64 %v2333, 1
  %v2336 = icmp ne i64 %v2335, 0
  %v2337 = icmp ult i64 %v2334, %v2307
  %v2338 = and i1 %v2336, %v2337
  br i1 %v2338, label %array.valid.2339, label %array.invalid.2340
array.invalid.2340:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2339:
  %v2341 = getelementptr i64, ptr %v2309, i64 %v2334
  %v2342 = load double, ptr %v2341, align 8, !tbaa !4
  %v2343 = fcmp olt double %v2342, %v2332
  %v2344 = select i1 %v2343, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v2345 = icmp eq ptr %v2344, inttoptr (i64 6 to ptr)
  br i1 %v2345, label %yes.2346, label %no.2347
yes.2346:
  %v2349 = getelementptr i8, ptr %a0, i64 8
  %v2350 = load i64, ptr %v2349, align 8, !tbaa !3
  %v2351 = getelementptr i8, ptr %a0, i64 16
  %v2352 = load ptr, ptr %v2351, align 8, !tbaa !3
  %v2353 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v2354 = ashr i64 %v2353, 1
  %v2355 = and i64 %v2353, 1
  %v2356 = icmp ne i64 %v2355, 0
  %v2357 = icmp ult i64 %v2354, %v2350
  %v2358 = and i1 %v2356, %v2357
  br i1 %v2358, label %array.valid.2359, label %array.invalid.2360
array.invalid.2360:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2359:
  %v2361 = getelementptr i8, ptr %v2352, i64 %v2354
  %v2362 = load i8, ptr %v2361, align 1, !tbaa !4
  %v2363 = zext i8 %v2362 to i64
  %v2364 = shl i64 %v2363, 1
  %v2365 = or i64 %v2364, 1
  %v2366 = inttoptr i64 %v2365 to ptr
  br label %join.2348
no.2347:
  %v2367 = ptrtoint ptr %a5 to i64
  %v2368 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2369 = and i64 %v2367, %v2368
  %v2370 = and i64 %v2369, 1
  %v2371 = icmp ne i64 %v2370, 0
  br i1 %v2371, label %yes.2372, label %no.2373
yes.2372:
  %v2375 = sub i64 %v2368, 1
  %v2376 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v2367, i64 %v2375)
  %v2377 = extractvalue { i64, i1 } %v2376, 0
  %v2378 = extractvalue { i64, i1 } %v2376, 1
  br i1 %v2378, label %yes.2379, label %no.2380
yes.2379:
  %v2382 = call ptr @mlf_sub_int(ptr %a5, ptr inttoptr (i64 3 to ptr))
  br label %join.2381
no.2380:
  %v2383 = inttoptr i64 %v2377 to ptr
  br label %join.2381
join.2381:
  %v2384 = phi ptr [ %v2382, %yes.2379 ], [ %v2383, %no.2380 ]
  br label %join.2374
no.2373:
  %v2385 = call ptr @mlf_sub_int(ptr %a5, ptr inttoptr (i64 3 to ptr))
  br label %join.2374
join.2374:
  %v2386 = phi ptr [ %v2384, %join.2381 ], [ %v2385, %no.2373 ]
  %v2522 = call ptr @mlf.numeric.7(ptr %a0, ptr %a1, ptr %a3, ptr inttoptr (i64 1 to ptr), ptr %v2386)
  br label %join.2348
join.2348:
  %v2523 = phi ptr [ %v2366, %array.valid.2359 ], [ %v2522, %join.2374 ]
  %v2524 = getelementptr i8, ptr %a4, i64 8
  %v2525 = load i64, ptr %v2524, align 8, !tbaa !3
  %v2526 = getelementptr i8, ptr %a4, i64 16
  %v2527 = load ptr, ptr %v2526, align 8, !tbaa !3
  %v2528 = ptrtoint ptr %a9 to i64
  %v2529 = ashr i64 %v2528, 1
  %v2530 = and i64 %v2528, 1
  %v2531 = icmp ne i64 %v2530, 0
  %v2532 = icmp ult i64 %v2529, %v2525
  %v2533 = and i1 %v2531, %v2532
  br i1 %v2533, label %array.valid.2534, label %array.invalid.2535
array.invalid.2535:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2534:
  %v2536 = getelementptr i8, ptr %v2527, i64 %v2529
  %v2537 = ptrtoint ptr %v2523 to i64
  %v2538 = ashr i64 %v2537, 1
  %v2539 = and i64 %v2537, 1
  %v2540 = icmp ne i64 %v2539, 0
  %v2541 = icmp ult i64 %v2538, 256
  %v2542 = and i1 %v2540, %v2541
  br i1 %v2542, label %yes.2543, label %no.2544
yes.2543:
  %v2546 = trunc i64 %v2538 to i8
  br label %join.2545
no.2544:
  %v2547 = call i8 @mlf_byte(ptr %v2523)
  br label %join.2545
join.2545:
  %v2548 = phi i8 [ %v2546, %yes.2543 ], [ %v2547, %no.2544 ]
  store i8 %v2548, ptr %v2536, align 1, !tbaa !4
  %v2549 = ptrtoint ptr %a7 to i64
  %v2550 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2551 = and i64 %v2549, %v2550
  %v2552 = and i64 %v2551, 1
  %v2553 = icmp ne i64 %v2552, 0
  br i1 %v2553, label %yes.2554, label %no.2555
yes.2554:
  %v2557 = sub i64 %v2550, 1
  %v2558 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2549, i64 %v2557)
  %v2559 = extractvalue { i64, i1 } %v2558, 0
  %v2560 = extractvalue { i64, i1 } %v2558, 1
  br i1 %v2560, label %yes.2561, label %no.2562
yes.2561:
  %v2564 = call ptr @mlf_add_int(ptr %a7, ptr inttoptr (i64 3 to ptr))
  br label %join.2563
no.2562:
  %v2565 = inttoptr i64 %v2559 to ptr
  br label %join.2563
join.2563:
  %v2566 = phi ptr [ %v2564, %yes.2561 ], [ %v2565, %no.2562 ]
  br label %join.2556
no.2555:
  %v2567 = call ptr @mlf_add_int(ptr %a7, ptr inttoptr (i64 3 to ptr))
  br label %join.2556
join.2556:
  %v2568 = phi ptr [ %v2566, %join.2563 ], [ %v2567, %no.2555 ]
  %v2569 = ptrtoint ptr %a8 to i64
  %v2570 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2571 = and i64 %v2569, %v2570
  %v2572 = and i64 %v2571, 1
  %v2573 = icmp ne i64 %v2572, 0
  br i1 %v2573, label %yes.2574, label %no.2575
yes.2574:
  %v2577 = sub i64 %v2570, 1
  %v2578 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2569, i64 %v2577)
  %v2579 = extractvalue { i64, i1 } %v2578, 0
  %v2580 = extractvalue { i64, i1 } %v2578, 1
  br i1 %v2580, label %yes.2581, label %no.2582
yes.2581:
  %v2584 = call ptr @mlf_add_int(ptr %a8, ptr inttoptr (i64 3 to ptr))
  br label %join.2583
no.2582:
  %v2585 = inttoptr i64 %v2579 to ptr
  br label %join.2583
join.2583:
  %v2586 = phi ptr [ %v2584, %yes.2581 ], [ %v2585, %no.2582 ]
  br label %join.2576
no.2575:
  %v2587 = call ptr @mlf_add_int(ptr %a8, ptr inttoptr (i64 3 to ptr))
  br label %join.2576
join.2576:
  %v2588 = phi ptr [ %v2586, %join.2583 ], [ %v2587, %no.2575 ]
  %v2589 = ptrtoint ptr %a9 to i64
  %v2590 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2591 = sub i64 %v2590, 1
  %v2592 = add nsw i64 %v2589, %v2591
  %v2593 = inttoptr i64 %v2592 to ptr
  %v2983 = musttail call ptr @mlf.numeric.40(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6, ptr %v2568, ptr %v2588, ptr %v2593)
  ret ptr %v2983
tail.no.2129:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.numeric.61(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6) alwaysinline {
entry:
  %v2055 = ptrtoint ptr %a6 to i64
  %v2056 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v2057 = and i64 %v2055, %v2056
  %v2058 = and i64 %v2057, 1
  %v2059 = icmp ne i64 %v2058, 0
  br i1 %v2059, label %yes.2060, label %no.2061
yes.2060:
  %v2063 = icmp eq i64 %v2055, %v2056
  %v2064 = select i1 %v2063, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.2062
no.2061:
  %v2065 = call ptr @mlf_eq_int(ptr %a6, ptr inttoptr (i64 1 to ptr))
  br label %join.2062
join.2062:
  %v2066 = phi ptr [ %v2064, %yes.2060 ], [ %v2065, %no.2061 ]
  %v2067 = icmp eq ptr %v2066, inttoptr (i64 6 to ptr)
  br i1 %v2067, label %tail.yes.2068, label %tail.no.2069
tail.yes.2068:
  ret ptr inttoptr (i64 4 to ptr)
tail.no.2069:
  %v2070 = ptrtoint ptr %a6 to i64
  %v2071 = ptrtoint ptr inttoptr (i64 122881 to ptr) to i64
  %v2072 = and i64 %v2070, %v2071
  %v2073 = and i64 %v2072, 1
  %v2074 = icmp ne i64 %v2073, 0
  br i1 %v2074, label %yes.2075, label %no.2076
yes.2075:
  %v2078 = icmp slt i64 %v2070, %v2071
  %v2079 = select i1 %v2078, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.2077
no.2076:
  %v2080 = call ptr @mlf_lt_int(ptr %a6, ptr inttoptr (i64 122881 to ptr))
  br label %join.2077
join.2077:
  %v2081 = phi ptr [ %v2079, %yes.2075 ], [ %v2080, %no.2076 ]
  %v2082 = icmp eq ptr %v2081, inttoptr (i64 6 to ptr)
  br i1 %v2082, label %yes.2083, label %no.2084
yes.2083:
  br label %join.2085
no.2084:
  br label %join.2085
join.2085:
  %v2086 = phi ptr [ %a6, %yes.2083 ], [ inttoptr (i64 122881 to ptr), %no.2084 ]
  %v2984 = call ptr @mlf.numeric.40.ppppppppnp(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %v2086, ptr inttoptr (i64 1 to ptr), ptr inttoptr (i64 1 to ptr), ptr inttoptr (i64 1 to ptr))
  %v2985 = ptrtoint ptr %v2086 to i64
  %v2986 = ptrtoint ptr inttoptr (i64 119 to ptr) to i64
  %v2987 = and i64 %v2985, %v2986
  %v2988 = and i64 %v2987, 1
  %v2989 = icmp ne i64 %v2988, 0
  br i1 %v2989, label %yes.2990, label %no.2991
yes.2990:
  %v2993 = sub i64 %v2986, 1
  %v2994 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2985, i64 %v2993)
  %v2995 = extractvalue { i64, i1 } %v2994, 0
  %v2996 = extractvalue { i64, i1 } %v2994, 1
  br i1 %v2996, label %yes.2997, label %no.2998
yes.2997:
  %v3000 = call ptr @mlf_add_int(ptr %v2086, ptr inttoptr (i64 119 to ptr))
  br label %join.2999
no.2998:
  %v3001 = inttoptr i64 %v2995 to ptr
  br label %join.2999
join.2999:
  %v3002 = phi ptr [ %v3000, %yes.2997 ], [ %v3001, %no.2998 ]
  br label %join.2992
no.2991:
  %v3003 = call ptr @mlf_add_int(ptr %v2086, ptr inttoptr (i64 119 to ptr))
  br label %join.2992
join.2992:
  %v3004 = phi ptr [ %v3002, %join.2999 ], [ %v3003, %no.2991 ]
  %v3005 = ptrtoint ptr %v3004 to i64
  %v3006 = ptrtoint ptr inttoptr (i64 121 to ptr) to i64
  %v3007 = and i64 %v3005, %v3006
  %v3008 = and i64 %v3007, 1
  %v3009 = icmp ne i64 %v3008, 0
  br i1 %v3009, label %yes.3010, label %no.3011
yes.3010:
  %v3013 = ashr i64 %v3005, 1
  %v3014 = ashr i64 %v3006, 1
  %v3015 = icmp ne i64 %v3014, 0
  %v3016 = icmp eq i64 %v3013, -4611686018427387904
  %v3017 = icmp eq i64 %v3014, -1
  %v3018 = and i1 %v3016, %v3017
  %v3019 = xor i1 %v3018, true
  %v3020 = and i1 %v3015, %v3019
  br i1 %v3020, label %yes.3021, label %no.3022
yes.3021:
  %v3024 = sdiv i64 %v3013, %v3014
  %v3025 = shl i64 %v3024, 1
  %v3026 = or i64 %v3025, 1
  %v3027 = inttoptr i64 %v3026 to ptr
  br label %join.3023
no.3022:
  %v3028 = call ptr @mlf_prim2(i64 15, ptr %v3004, ptr inttoptr (i64 121 to ptr))
  br label %join.3023
join.3023:
  %v3029 = phi ptr [ %v3027, %yes.3021 ], [ %v3028, %no.3022 ]
  br label %join.3012
no.3011:
  %v3030 = call ptr @mlf_prim2(i64 15, ptr %v3004, ptr inttoptr (i64 121 to ptr))
  br label %join.3012
join.3012:
  %v3031 = phi ptr [ %v3029, %join.3023 ], [ %v3030, %no.3011 ]
  %v3032 = ptrtoint ptr %v2086 to i64
  %v3033 = ptrtoint ptr %v3031 to i64
  %v3034 = and i64 %v3032, %v3033
  %v3035 = and i64 %v3034, 1
  %v3036 = icmp ne i64 %v3035, 0
  br i1 %v3036, label %yes.3037, label %no.3038
yes.3037:
  %v3040 = sub i64 %v3033, 1
  %v3041 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v3032, i64 %v3040)
  %v3042 = extractvalue { i64, i1 } %v3041, 0
  %v3043 = extractvalue { i64, i1 } %v3041, 1
  br i1 %v3043, label %yes.3044, label %no.3045
yes.3044:
  %v3047 = call ptr @mlf_add_int(ptr %v2086, ptr %v3031)
  br label %join.3046
no.3045:
  %v3048 = inttoptr i64 %v3042 to ptr
  br label %join.3046
join.3046:
  %v3049 = phi ptr [ %v3047, %yes.3044 ], [ %v3048, %no.3045 ]
  br label %join.3039
no.3038:
  %v3050 = call ptr @mlf_add_int(ptr %v2086, ptr %v3031)
  br label %join.3039
join.3039:
  %v3051 = phi ptr [ %v3049, %join.3046 ], [ %v3050, %no.3038 ]
  %v3052 = call ptr @mlf_put_bytes(ptr %a4, ptr inttoptr (i64 1 to ptr), ptr %v3051)
  %v3053 = ptrtoint ptr %a6 to i64
  %v3054 = ptrtoint ptr %v2086 to i64
  %v3055 = and i64 %v3053, %v3054
  %v3056 = and i64 %v3055, 1
  %v3057 = icmp ne i64 %v3056, 0
  br i1 %v3057, label %yes.3058, label %no.3059
yes.3058:
  %v3061 = sub i64 %v3054, 1
  %v3062 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v3053, i64 %v3061)
  %v3063 = extractvalue { i64, i1 } %v3062, 0
  %v3064 = extractvalue { i64, i1 } %v3062, 1
  br i1 %v3064, label %yes.3065, label %no.3066
yes.3065:
  %v3068 = call ptr @mlf_sub_int(ptr %a6, ptr %v2086)
  br label %join.3067
no.3066:
  %v3069 = inttoptr i64 %v3063 to ptr
  br label %join.3067
join.3067:
  %v3070 = phi ptr [ %v3068, %yes.3065 ], [ %v3069, %no.3066 ]
  br label %join.3060
no.3059:
  %v3071 = call ptr @mlf_sub_int(ptr %a6, ptr %v2086)
  br label %join.3060
join.3060:
  %v3072 = phi ptr [ %v3070, %join.3067 ], [ %v3071, %no.3059 ]
  %v3073 = musttail call ptr @mlf.numeric.61(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %v3072)
  ret ptr %v3073
}

define private ptr @mlf.code.3082(ptr %env, ptr %arg) {
entry:
  %v3083 = getelementptr i8, ptr %env, i64 8
  %v3084 = load ptr, ptr %v3083, align 8, !tbaa !3
  %v3085 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3085, align 8, !tbaa !3
  %v3086 = call ptr @mlf.force(ptr %v3084)
  %v3087 = call ptr @mlf_prim2(i64 11, ptr %v3086, ptr inttoptr (i64 122881 to ptr))
  %v3088 = icmp eq ptr %v3087, inttoptr (i64 6 to ptr)
  br i1 %v3088, label %yes.3089, label %no.3090
yes.3089:
  br label %join.3091
no.3090:
  br label %join.3091
join.3091:
  %v3092 = phi ptr [ %v3086, %yes.3089 ], [ inttoptr (i64 122881 to ptr), %no.3090 ]
  ret ptr %v3092
}

define private ptr @mlf.code.3187(ptr %env, ptr %arg) {
entry:
  %v3188 = getelementptr i8, ptr %env, i64 8
  %v3189 = load ptr, ptr %v3188, align 8, !tbaa !3
  %v3190 = getelementptr i8, ptr %env, i64 16
  %v3191 = load ptr, ptr %v3190, align 8, !tbaa !3
  %v3192 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3192, align 8, !tbaa !3
  %v3193 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v3193, align 8, !tbaa !3
  %v3194 = call ptr @mlf_prim3(i64 37, ptr %v3189, ptr %v3191, ptr inttoptr (i64 21 to ptr))
  ret ptr %v3194
}

define private ptr @mlf.code.3200(ptr %env, ptr %arg) {
entry:
  %v3201 = getelementptr i8, ptr %env, i64 8
  %v3202 = load ptr, ptr %v3201, align 8, !tbaa !3
  %v3203 = getelementptr i8, ptr %env, i64 16
  %v3204 = load ptr, ptr %v3203, align 8, !tbaa !3
  %v3205 = getelementptr i8, ptr %env, i64 24
  %v3206 = load ptr, ptr %v3205, align 8, !tbaa !3
  %v3207 = getelementptr i8, ptr %env, i64 32
  %v3208 = load ptr, ptr %v3207, align 8, !tbaa !3
  %v3209 = getelementptr i8, ptr %env, i64 40
  %v3210 = load ptr, ptr %v3209, align 8, !tbaa !3
  %v3211 = getelementptr i8, ptr %env, i64 48
  %v3212 = load ptr, ptr %v3211, align 8, !tbaa !3
  %v3213 = getelementptr i8, ptr %env, i64 56
  %v3214 = load ptr, ptr %v3213, align 8, !tbaa !3
  %v3215 = getelementptr i8, ptr %env, i64 64
  %v3216 = load ptr, ptr %v3215, align 8, !tbaa !3
  %v3217 = getelementptr i8, ptr %env, i64 72
  %v3218 = load ptr, ptr %v3217, align 8, !tbaa !3
  %v3219 = call ptr @mlf.force(ptr %v3216)
  %v3220 = call ptr @mlf.force(ptr %v3218)
  %v3221 = call ptr @mlf_prim2(i64 8, ptr %v3220, ptr inttoptr (i64 3 to ptr))
  %v3222 = call ptr @mlf_env_new(i64 10)
  %v3223 = getelementptr i8, ptr %v3222, i64 8
  store ptr %v3202, ptr %v3223, align 8, !tbaa !3
  %v3224 = getelementptr i8, ptr %v3222, i64 16
  store ptr %v3204, ptr %v3224, align 8, !tbaa !3
  %v3225 = getelementptr i8, ptr %v3222, i64 24
  store ptr %v3206, ptr %v3225, align 8, !tbaa !3
  %v3226 = getelementptr i8, ptr %v3222, i64 32
  store ptr %v3208, ptr %v3226, align 8, !tbaa !3
  %v3227 = getelementptr i8, ptr %v3222, i64 40
  store ptr %v3210, ptr %v3227, align 8, !tbaa !3
  %v3228 = getelementptr i8, ptr %v3222, i64 48
  store ptr %v3212, ptr %v3228, align 8, !tbaa !3
  %v3229 = getelementptr i8, ptr %v3222, i64 56
  store ptr %v3214, ptr %v3229, align 8, !tbaa !3
  %v3230 = getelementptr i8, ptr %v3222, i64 64
  store ptr %v3219, ptr %v3230, align 8, !tbaa !3
  %v3231 = getelementptr i8, ptr %v3222, i64 72
  store ptr inttoptr (i64 1 to ptr), ptr %v3231, align 8, !tbaa !3
  %v3232 = getelementptr i8, ptr %v3222, i64 80
  store ptr %v3221, ptr %v3232, align 8, !tbaa !3
  %v3233 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.3119, ptr %v3222)
  ret ptr %v3233
}

define private ptr @mlf.code.3260(ptr %env, ptr %arg) {
entry:
  %v3261 = getelementptr i8, ptr %env, i64 8
  %v3262 = load ptr, ptr %v3261, align 8, !tbaa !3
  %v3263 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3263, align 8, !tbaa !3
  %v3264 = call ptr @mlf_prim2(i64 28, ptr %v3262, ptr inttoptr (i64 1 to ptr))
  ret ptr %v3264
}

define private ptr @mlf.code.3290(ptr %env, ptr %arg) {
entry:
  %v3291 = getelementptr i8, ptr %env, i64 8
  %v3292 = load ptr, ptr %v3291, align 8, !tbaa !3
  %v3293 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3293, align 8, !tbaa !3
  %v3294 = call ptr @mlf.force(ptr %v3292)
  %v3295 = call ptr @mlf_prim2(i64 14, ptr %v3294, ptr inttoptr (i64 7755 to ptr))
  %v3296 = call ptr @mlf_prim2(i64 8, ptr %v3295, ptr inttoptr (i64 59147 to ptr))
  %v3297 = call ptr @mlf_prim2(i64 16, ptr %v3296, ptr inttoptr (i64 279937 to ptr))
  ret ptr %v3297
}

define private ptr @mlf.code.3302(ptr %env, ptr %arg) {
entry:
  %v3303 = getelementptr i8, ptr %env, i64 8
  %v3304 = load ptr, ptr %v3303, align 8, !tbaa !3
  %v3305 = getelementptr i8, ptr %env, i64 16
  %v3306 = load ptr, ptr %v3305, align 8, !tbaa !3
  %v3307 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3307, align 8, !tbaa !3
  %v3308 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v3308, align 8, !tbaa !3
  %v3309 = call ptr @mlf_prim3(i64 29, ptr %v3304, ptr inttoptr (i64 1 to ptr), ptr %v3306)
  ret ptr %v3309
}

define private ptr @mlf.code.3345(ptr %env, ptr %arg) {
entry:
  %v3346 = getelementptr i8, ptr %env, i64 8
  %v3347 = load ptr, ptr %v3346, align 8, !tbaa !3
  %v3348 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3348, align 8, !tbaa !3
  %v3349 = call ptr @mlf.force(ptr %v3347)
  %v3350 = call ptr @mlf_prim1(i64 25, ptr %v3349)
  %v3351 = call ptr @mlf_double(double 0x4101160000000000)
  %v3352 = call ptr @mlf_prim2(i64 21, ptr %v3350, ptr %v3351)
  ret ptr %v3352
}

define private ptr @mlf.code.3338(ptr %env, ptr %arg) {
entry:
  %v3339 = getelementptr i8, ptr %env, i64 8
  %v3340 = load ptr, ptr %v3339, align 8, !tbaa !3
  %v3341 = getelementptr i8, ptr %env, i64 16
  %v3342 = load ptr, ptr %v3341, align 8, !tbaa !3
  %v3343 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3343, align 8, !tbaa !3
  %v3344 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v3344, align 8, !tbaa !3
  %v3353 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3345, i64 1)
  %v3354 = getelementptr i8, ptr %v3353, i64 16
  %v3355 = load ptr, ptr %v3354, align 8, !tbaa !3
  %v3356 = getelementptr i8, ptr %v3355, i64 8
  store ptr %v3342, ptr %v3356, align 8, !tbaa !3
  %v3357 = call ptr @mlf_prim3(i64 33, ptr %v3340, ptr inttoptr (i64 1 to ptr), ptr %v3353)
  ret ptr %v3357
}

define private ptr @mlf.code.3397(ptr %env, ptr %arg) {
entry:
  %v3398 = getelementptr i8, ptr %env, i64 8
  %v3399 = load ptr, ptr %v3398, align 8, !tbaa !3
  %v3400 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3400, align 8, !tbaa !3
  %v3401 = call ptr @mlf_prim2(i64 32, ptr %v3399, ptr inttoptr (i64 1 to ptr))
  ret ptr %v3401
}

define private ptr @mlf.code.3415(ptr %env, ptr %arg) {
entry:
  %v3416 = getelementptr i8, ptr %env, i64 8
  %v3417 = load ptr, ptr %v3416, align 8, !tbaa !3
  %v3418 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3418, align 8, !tbaa !3
  %v3419 = call ptr @mlf_prim2(i64 32, ptr %v3417, ptr inttoptr (i64 1 to ptr))
  ret ptr %v3419
}

define private ptr @mlf.code.3480(ptr %env, ptr %arg) {
entry:
  %v3481 = getelementptr i8, ptr %env, i64 8
  %v3482 = load ptr, ptr %v3481, align 8, !tbaa !3
  %v3483 = getelementptr i8, ptr %env, i64 16
  %v3484 = load ptr, ptr %v3483, align 8, !tbaa !3
  %v3485 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3485, align 8, !tbaa !3
  %v3486 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v3486, align 8, !tbaa !3
  %v3487 = call ptr @mlf.force(ptr %v3482)
  %v3488 = call ptr @mlf.force(ptr %v3484)
  %v3489 = call ptr @mlf_prim2(i64 8, ptr %v3487, ptr %v3488)
  %v3490 = call ptr @mlf_prim2(i64 15, ptr %v3489, ptr inttoptr (i64 5 to ptr))
  ret ptr %v3490
}

define private ptr @mlf.code.3496(ptr %env, ptr %arg) {
entry:
  %v3497 = getelementptr i8, ptr %env, i64 8
  %v3498 = load ptr, ptr %v3497, align 8, !tbaa !3
  %v3499 = getelementptr i8, ptr %env, i64 16
  %v3500 = load ptr, ptr %v3499, align 8, !tbaa !3
  %v3501 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3501, align 8, !tbaa !3
  %v3502 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v3502, align 8, !tbaa !3
  %v3503 = call ptr @mlf_prim2(i64 32, ptr %v3498, ptr %v3500)
  ret ptr %v3503
}

define private ptr @mlf.code.3522(ptr %env, ptr %arg) {
entry:
  %v3523 = getelementptr i8, ptr %env, i64 8
  %v3524 = load ptr, ptr %v3523, align 8, !tbaa !3
  %v3525 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3525, align 8, !tbaa !3
  %v3526 = call ptr @mlf_prim2(i64 32, ptr %v3524, ptr inttoptr (i64 1 to ptr))
  ret ptr %v3526
}

define private ptr @mlf.code.3531(ptr %env, ptr %arg) {
entry:
  %v3532 = getelementptr i8, ptr %env, i64 8
  %v3533 = load ptr, ptr %v3532, align 8, !tbaa !3
  %v3534 = getelementptr i8, ptr %env, i64 16
  %v3535 = load ptr, ptr %v3534, align 8, !tbaa !3
  %v3536 = getelementptr i8, ptr %env, i64 24
  %v3537 = load ptr, ptr %v3536, align 8, !tbaa !3
  %v3538 = getelementptr i8, ptr %env, i64 32
  %v3539 = load ptr, ptr %v3538, align 8, !tbaa !3
  %v3540 = getelementptr i8, ptr %env, i64 40
  %v3541 = load ptr, ptr %v3540, align 8, !tbaa !3
  %v3542 = getelementptr i8, ptr %env, i64 48
  %v3543 = load ptr, ptr %v3542, align 8, !tbaa !3
  %v3544 = getelementptr i8, ptr %env, i64 56
  %v3545 = load ptr, ptr %v3544, align 8, !tbaa !3
  %v3546 = call ptr @mlf.force(ptr %arg)
  %v3547 = call ptr @mlf.force(ptr %v3545)
  %v3548 = call ptr @mlf_prim2(i64 24, ptr %v3546, ptr %v3547)
  %v3549 = icmp eq ptr %v3548, inttoptr (i64 6 to ptr)
  br i1 %v3549, label %yes.3550, label %no.3551
yes.3550:
  %v3553 = call ptr @mlf.force(ptr %v3539)
  %v3554 = call ptr @mlf.force(ptr %v3543)
  %v3555 = call ptr @mlf_env_new(i64 5)
  %v3556 = getelementptr i8, ptr %v3555, i64 8
  store ptr %v3533, ptr %v3556, align 8, !tbaa !3
  %v3557 = getelementptr i8, ptr %v3555, i64 16
  store ptr %v3535, ptr %v3557, align 8, !tbaa !3
  %v3558 = getelementptr i8, ptr %v3555, i64 24
  store ptr %v3537, ptr %v3558, align 8, !tbaa !3
  %v3559 = getelementptr i8, ptr %v3555, i64 32
  store ptr %v3553, ptr %v3559, align 8, !tbaa !3
  %v3560 = getelementptr i8, ptr %v3555, i64 40
  store ptr %v3554, ptr %v3560, align 8, !tbaa !3
  %v3561 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.3443, ptr %v3555)
  br label %join.3552
no.3551:
  %v3562 = call ptr @mlf.force(ptr %v3543)
  %v3563 = call ptr @mlf.force(ptr %v3541)
  %v3564 = call ptr @mlf_env_new(i64 5)
  %v3565 = getelementptr i8, ptr %v3564, i64 8
  store ptr %v3533, ptr %v3565, align 8, !tbaa !3
  %v3566 = getelementptr i8, ptr %v3564, i64 16
  store ptr %v3535, ptr %v3566, align 8, !tbaa !3
  %v3567 = getelementptr i8, ptr %v3564, i64 24
  store ptr %v3537, ptr %v3567, align 8, !tbaa !3
  %v3568 = getelementptr i8, ptr %v3564, i64 32
  store ptr %v3562, ptr %v3568, align 8, !tbaa !3
  %v3569 = getelementptr i8, ptr %v3564, i64 40
  store ptr %v3563, ptr %v3569, align 8, !tbaa !3
  %v3570 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.3443, ptr %v3564)
  br label %join.3552
join.3552:
  %v3571 = phi ptr [ %v3561, %yes.3550 ], [ %v3570, %no.3551 ]
  ret ptr %v3571
}

define private ptr @mlf.code.3509(ptr %env, ptr %arg) {
entry:
  %v3510 = getelementptr i8, ptr %env, i64 8
  %v3511 = load ptr, ptr %v3510, align 8, !tbaa !3
  %v3512 = getelementptr i8, ptr %env, i64 16
  %v3513 = load ptr, ptr %v3512, align 8, !tbaa !3
  %v3514 = getelementptr i8, ptr %env, i64 24
  %v3515 = load ptr, ptr %v3514, align 8, !tbaa !3
  %v3516 = getelementptr i8, ptr %env, i64 32
  %v3517 = load ptr, ptr %v3516, align 8, !tbaa !3
  %v3518 = getelementptr i8, ptr %env, i64 40
  %v3519 = load ptr, ptr %v3518, align 8, !tbaa !3
  %v3520 = getelementptr i8, ptr %env, i64 48
  %v3521 = load ptr, ptr %v3520, align 8, !tbaa !3
  %v3527 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3522, i64 1)
  %v3528 = getelementptr i8, ptr %v3527, i64 16
  %v3529 = load ptr, ptr %v3528, align 8, !tbaa !3
  %v3530 = getelementptr i8, ptr %v3529, i64 8
  store ptr %v3515, ptr %v3530, align 8, !tbaa !3
  %v3572 = call ptr @mlf_env_new(i64 7)
  %v3573 = getelementptr i8, ptr %v3572, i64 8
  store ptr %v3511, ptr %v3573, align 8, !tbaa !3
  %v3574 = getelementptr i8, ptr %v3572, i64 16
  store ptr %v3513, ptr %v3574, align 8, !tbaa !3
  %v3575 = getelementptr i8, ptr %v3572, i64 24
  store ptr %v3515, ptr %v3575, align 8, !tbaa !3
  %v3576 = getelementptr i8, ptr %v3572, i64 32
  store ptr %v3517, ptr %v3576, align 8, !tbaa !3
  %v3577 = getelementptr i8, ptr %v3572, i64 40
  store ptr %v3519, ptr %v3577, align 8, !tbaa !3
  %v3578 = getelementptr i8, ptr %v3572, i64 48
  store ptr %v3521, ptr %v3578, align 8, !tbaa !3
  %v3579 = getelementptr i8, ptr %v3572, i64 56
  store ptr %arg, ptr %v3579, align 8, !tbaa !3
  %v3580 = call ptr @mlf_closure(ptr @mlf.code.3531, ptr %v3572)
  %v3581 = call ptr @mlf_prim2(i64 1, ptr %v3527, ptr %v3580)
  ret ptr %v3581
}

define private ptr @mlf.worker.7(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) {
entry:
  %v3474 = call ptr @mlf_prim2(i64 8, ptr %a3, ptr inttoptr (i64 3 to ptr))
  %v3475 = call ptr @mlf_prim2(i64 11, ptr %v3474, ptr %a4)
  %v3476 = icmp eq ptr %v3475, inttoptr (i64 6 to ptr)
  br i1 %v3476, label %yes.3477, label %no.3478
yes.3477:
  %v3491 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3480, i64 2)
  %v3492 = getelementptr i8, ptr %v3491, i64 16
  %v3493 = load ptr, ptr %v3492, align 8, !tbaa !3
  %v3494 = getelementptr i8, ptr %v3493, i64 8
  store ptr %a3, ptr %v3494, align 8, !tbaa !3
  %v3495 = getelementptr i8, ptr %v3493, i64 16
  store ptr %a4, ptr %v3495, align 8, !tbaa !3
  %v3504 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3496, i64 2)
  %v3505 = getelementptr i8, ptr %v3504, i64 16
  %v3506 = load ptr, ptr %v3505, align 8, !tbaa !3
  %v3507 = getelementptr i8, ptr %v3506, i64 8
  store ptr %a1, ptr %v3507, align 8, !tbaa !3
  %v3508 = getelementptr i8, ptr %v3506, i64 16
  store ptr %v3491, ptr %v3508, align 8, !tbaa !3
  %v3582 = call ptr @mlf_env_new(i64 6)
  %v3583 = getelementptr i8, ptr %v3582, i64 8
  store ptr %a0, ptr %v3583, align 8, !tbaa !3
  %v3584 = getelementptr i8, ptr %v3582, i64 16
  store ptr %a1, ptr %v3584, align 8, !tbaa !3
  %v3585 = getelementptr i8, ptr %v3582, i64 24
  store ptr %a2, ptr %v3585, align 8, !tbaa !3
  %v3586 = getelementptr i8, ptr %v3582, i64 32
  store ptr %a3, ptr %v3586, align 8, !tbaa !3
  %v3587 = getelementptr i8, ptr %v3582, i64 40
  store ptr %a4, ptr %v3587, align 8, !tbaa !3
  %v3588 = getelementptr i8, ptr %v3582, i64 48
  store ptr %v3491, ptr %v3588, align 8, !tbaa !3
  %v3589 = call ptr @mlf_closure(ptr @mlf.code.3509, ptr %v3582)
  %v3590 = call ptr @mlf_prim2(i64 1, ptr %v3504, ptr %v3589)
  br label %join.3479
no.3478:
  %v3591 = call ptr @mlf_prim2(i64 36, ptr %a0, ptr %a4)
  br label %join.3479
join.3479:
  %v3592 = phi ptr [ %v3590, %yes.3477 ], [ %v3591, %no.3478 ]
  ret ptr %v3592
}

define private ptr @mlf.numeric.entry.3443(ptr %env, ptr %arg) {
entry:
  %v3444 = getelementptr i8, ptr %env, i64 8
  %v3445 = load ptr, ptr %v3444, align 8, !tbaa !3
  %v3446 = getelementptr i8, ptr %env, i64 16
  %v3447 = load ptr, ptr %v3446, align 8, !tbaa !3
  %v3448 = getelementptr i8, ptr %env, i64 24
  %v3449 = load ptr, ptr %v3448, align 8, !tbaa !3
  %v3450 = getelementptr i8, ptr %env, i64 32
  %v3451 = load ptr, ptr %v3450, align 8, !tbaa !3
  %v3452 = getelementptr i8, ptr %env, i64 40
  %v3453 = load ptr, ptr %v3452, align 8, !tbaa !3
  %v3454 = call ptr @mlf_peek(ptr %v3445)
  %v3455 = call ptr @mlf_peek(ptr %v3447)
  %v3456 = call ptr @mlf_peek(ptr %v3449)
  %v3457 = call ptr @mlf_peek(ptr %v3451)
  %v3458 = call ptr @mlf_peek(ptr %v3453)
  %v3459 = icmp ne ptr %v3454, null
  %v3460 = icmp ne ptr %v3455, null
  %v3461 = icmp ne ptr %v3456, null
  %v3462 = icmp ne ptr %v3457, null
  %v3463 = icmp ne ptr %v3458, null
  %v3464 = and i1 true, %v3459
  %v3465 = and i1 %v3464, %v3460
  %v3466 = and i1 %v3465, %v3461
  %v3467 = and i1 %v3466, %v3462
  %v3468 = and i1 %v3467, %v3463
  br i1 %v3468, label %yes.3469, label %no.3470
yes.3469:
  %v3472 = call ptr @mlf.numeric.7(ptr %v3454, ptr %v3455, ptr %v3456, ptr %v3457, ptr %v3458)
  %v3473 = call ptr @mlf_prim1(i64 0, ptr %v3472)
  br label %join.3471
no.3470:
  %v3593 = call ptr @mlf.force(ptr %v3451)
  %v3594 = call ptr @mlf.force(ptr %v3453)
  %v3595 = call ptr @mlf.worker.7(ptr %v3445, ptr %v3447, ptr %v3449, ptr %v3593, ptr %v3594)
  br label %join.3471
join.3471:
  %v3596 = phi ptr [ %v3473, %yes.3469 ], [ %v3595, %no.3470 ]
  ret ptr %v3596
}

define private ptr @mlf.code.3424(ptr %env, ptr %arg) {
entry:
  %v3425 = getelementptr i8, ptr %env, i64 8
  %v3426 = load ptr, ptr %v3425, align 8, !tbaa !3
  %v3427 = getelementptr i8, ptr %env, i64 16
  %v3428 = load ptr, ptr %v3427, align 8, !tbaa !3
  %v3429 = getelementptr i8, ptr %env, i64 24
  %v3430 = load ptr, ptr %v3429, align 8, !tbaa !3
  %v3431 = getelementptr i8, ptr %env, i64 32
  %v3432 = load ptr, ptr %v3431, align 8, !tbaa !3
  %v3433 = getelementptr i8, ptr %env, i64 40
  %v3434 = load ptr, ptr %v3433, align 8, !tbaa !3
  %v3435 = call ptr @mlf.force(ptr %arg)
  %v3436 = call ptr @mlf.force(ptr %v3434)
  %v3437 = call ptr @mlf_prim2(i64 24, ptr %v3435, ptr %v3436)
  %v3438 = icmp eq ptr %v3437, inttoptr (i64 6 to ptr)
  br i1 %v3438, label %yes.3439, label %no.3440
yes.3439:
  %v3442 = call ptr @mlf_prim2(i64 36, ptr %v3426, ptr inttoptr (i64 1 to ptr))
  br label %join.3441
no.3440:
  %v3597 = call ptr @mlf.force(ptr %v3432)
  %v3598 = call ptr @mlf_prim2(i64 9, ptr %v3597, ptr inttoptr (i64 3 to ptr))
  %v3599 = call ptr @mlf_env_new(i64 5)
  %v3600 = getelementptr i8, ptr %v3599, i64 8
  store ptr %v3426, ptr %v3600, align 8, !tbaa !3
  %v3601 = getelementptr i8, ptr %v3599, i64 16
  store ptr %v3428, ptr %v3601, align 8, !tbaa !3
  %v3602 = getelementptr i8, ptr %v3599, i64 24
  store ptr %v3430, ptr %v3602, align 8, !tbaa !3
  %v3603 = getelementptr i8, ptr %v3599, i64 32
  store ptr inttoptr (i64 1 to ptr), ptr %v3603, align 8, !tbaa !3
  %v3604 = getelementptr i8, ptr %v3599, i64 40
  store ptr %v3598, ptr %v3604, align 8, !tbaa !3
  %v3605 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.3443, ptr %v3599)
  br label %join.3441
join.3441:
  %v3606 = phi ptr [ %v3442, %yes.3439 ], [ %v3605, %no.3440 ]
  ret ptr %v3606
}

define private ptr @mlf.code.3406(ptr %env, ptr %arg) {
entry:
  %v3407 = getelementptr i8, ptr %env, i64 8
  %v3408 = load ptr, ptr %v3407, align 8, !tbaa !3
  %v3409 = getelementptr i8, ptr %env, i64 16
  %v3410 = load ptr, ptr %v3409, align 8, !tbaa !3
  %v3411 = getelementptr i8, ptr %env, i64 24
  %v3412 = load ptr, ptr %v3411, align 8, !tbaa !3
  %v3413 = getelementptr i8, ptr %env, i64 32
  %v3414 = load ptr, ptr %v3413, align 8, !tbaa !3
  %v3420 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3415, i64 1)
  %v3421 = getelementptr i8, ptr %v3420, i64 16
  %v3422 = load ptr, ptr %v3421, align 8, !tbaa !3
  %v3423 = getelementptr i8, ptr %v3422, i64 8
  store ptr %v3412, ptr %v3423, align 8, !tbaa !3
  %v3607 = call ptr @mlf_env_new(i64 5)
  %v3608 = getelementptr i8, ptr %v3607, i64 8
  store ptr %v3408, ptr %v3608, align 8, !tbaa !3
  %v3609 = getelementptr i8, ptr %v3607, i64 16
  store ptr %v3410, ptr %v3609, align 8, !tbaa !3
  %v3610 = getelementptr i8, ptr %v3607, i64 24
  store ptr %v3412, ptr %v3610, align 8, !tbaa !3
  %v3611 = getelementptr i8, ptr %v3607, i64 32
  store ptr %v3414, ptr %v3611, align 8, !tbaa !3
  %v3612 = getelementptr i8, ptr %v3607, i64 40
  store ptr %arg, ptr %v3612, align 8, !tbaa !3
  %v3613 = call ptr @mlf_closure(ptr @mlf.code.3424, ptr %v3607)
  %v3614 = call ptr @mlf_prim2(i64 1, ptr %v3420, ptr %v3613)
  ret ptr %v3614
}

define private ptr @mlf.code.3384(ptr %env, ptr %arg) {
entry:
  %v3385 = getelementptr i8, ptr %env, i64 8
  %v3386 = load ptr, ptr %v3385, align 8, !tbaa !3
  %v3387 = getelementptr i8, ptr %env, i64 16
  %v3388 = load ptr, ptr %v3387, align 8, !tbaa !3
  %v3389 = getelementptr i8, ptr %env, i64 24
  %v3390 = load ptr, ptr %v3389, align 8, !tbaa !3
  %v3391 = getelementptr i8, ptr %env, i64 32
  %v3392 = load ptr, ptr %v3391, align 8, !tbaa !3
  %v3393 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3393, align 8, !tbaa !3
  %v3394 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v3394, align 8, !tbaa !3
  %v3395 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v3395, align 8, !tbaa !3
  %v3396 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v3396, align 8, !tbaa !3
  %v3402 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3397, i64 1)
  %v3403 = getelementptr i8, ptr %v3402, i64 16
  %v3404 = load ptr, ptr %v3403, align 8, !tbaa !3
  %v3405 = getelementptr i8, ptr %v3404, i64 8
  store ptr %v3388, ptr %v3405, align 8, !tbaa !3
  %v3615 = call ptr @mlf_env_new(i64 4)
  %v3616 = getelementptr i8, ptr %v3615, i64 8
  store ptr %v3386, ptr %v3616, align 8, !tbaa !3
  %v3617 = getelementptr i8, ptr %v3615, i64 16
  store ptr %v3388, ptr %v3617, align 8, !tbaa !3
  %v3618 = getelementptr i8, ptr %v3615, i64 24
  store ptr %v3390, ptr %v3618, align 8, !tbaa !3
  %v3619 = getelementptr i8, ptr %v3615, i64 32
  store ptr %v3392, ptr %v3619, align 8, !tbaa !3
  %v3620 = call ptr @mlf_closure(ptr @mlf.code.3406, ptr %v3615)
  %v3621 = call ptr @mlf_prim2(i64 1, ptr %v3402, ptr %v3620)
  ret ptr %v3621
}

define private ptr @mlf.code.3650(ptr %env, ptr %arg) {
entry:
  %v3651 = getelementptr i8, ptr %env, i64 8
  %v3652 = load ptr, ptr %v3651, align 8, !tbaa !3
  %v3653 = getelementptr i8, ptr %env, i64 16
  %v3654 = load ptr, ptr %v3653, align 8, !tbaa !3
  %v3655 = getelementptr i8, ptr %env, i64 24
  %v3656 = load ptr, ptr %v3655, align 8, !tbaa !3
  %v3657 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3657, align 8, !tbaa !3
  %v3658 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v3658, align 8, !tbaa !3
  %v3659 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v3659, align 8, !tbaa !3
  %v3660 = call ptr @mlf_prim3(i64 37, ptr %v3652, ptr %v3654, ptr %v3656)
  ret ptr %v3660
}

define private ptr @mlf.code.3667(ptr %env, ptr %arg) {
entry:
  %v3668 = getelementptr i8, ptr %env, i64 8
  %v3669 = load ptr, ptr %v3668, align 8, !tbaa !3
  %v3670 = getelementptr i8, ptr %env, i64 16
  %v3671 = load ptr, ptr %v3670, align 8, !tbaa !3
  %v3672 = getelementptr i8, ptr %env, i64 24
  %v3673 = load ptr, ptr %v3672, align 8, !tbaa !3
  %v3674 = getelementptr i8, ptr %env, i64 32
  %v3675 = load ptr, ptr %v3674, align 8, !tbaa !3
  %v3676 = getelementptr i8, ptr %env, i64 40
  %v3677 = load ptr, ptr %v3676, align 8, !tbaa !3
  %v3678 = getelementptr i8, ptr %env, i64 48
  %v3679 = load ptr, ptr %v3678, align 8, !tbaa !3
  %v3680 = getelementptr i8, ptr %env, i64 56
  %v3681 = load ptr, ptr %v3680, align 8, !tbaa !3
  %v3682 = getelementptr i8, ptr %env, i64 64
  %v3683 = load ptr, ptr %v3682, align 8, !tbaa !3
  %v3684 = getelementptr i8, ptr %env, i64 72
  %v3685 = load ptr, ptr %v3684, align 8, !tbaa !3
  %v3686 = getelementptr i8, ptr %env, i64 80
  %v3687 = load ptr, ptr %v3686, align 8, !tbaa !3
  %v3688 = call ptr @mlf.force(ptr %v3683)
  %v3689 = call ptr @mlf_prim2(i64 8, ptr %v3688, ptr inttoptr (i64 3 to ptr))
  %v3690 = call ptr @mlf.force(ptr %v3685)
  %v3691 = call ptr @mlf_prim2(i64 8, ptr %v3690, ptr inttoptr (i64 3 to ptr))
  %v3692 = call ptr @mlf.force(ptr %v3687)
  %v3693 = call ptr @mlf_prim2(i64 8, ptr %v3692, ptr inttoptr (i64 3 to ptr))
  %v3694 = call ptr @mlf_env_new(i64 10)
  %v3695 = getelementptr i8, ptr %v3694, i64 8
  store ptr %v3669, ptr %v3695, align 8, !tbaa !3
  %v3696 = getelementptr i8, ptr %v3694, i64 16
  store ptr %v3671, ptr %v3696, align 8, !tbaa !3
  %v3697 = getelementptr i8, ptr %v3694, i64 24
  store ptr %v3673, ptr %v3697, align 8, !tbaa !3
  %v3698 = getelementptr i8, ptr %v3694, i64 32
  store ptr %v3675, ptr %v3698, align 8, !tbaa !3
  %v3699 = getelementptr i8, ptr %v3694, i64 40
  store ptr %v3677, ptr %v3699, align 8, !tbaa !3
  %v3700 = getelementptr i8, ptr %v3694, i64 48
  store ptr %v3679, ptr %v3700, align 8, !tbaa !3
  %v3701 = getelementptr i8, ptr %v3694, i64 56
  store ptr %v3681, ptr %v3701, align 8, !tbaa !3
  %v3702 = getelementptr i8, ptr %v3694, i64 64
  store ptr %v3689, ptr %v3702, align 8, !tbaa !3
  %v3703 = getelementptr i8, ptr %v3694, i64 72
  store ptr %v3691, ptr %v3703, align 8, !tbaa !3
  %v3704 = getelementptr i8, ptr %v3694, i64 80
  store ptr %v3693, ptr %v3704, align 8, !tbaa !3
  %v3705 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.3119, ptr %v3694)
  ret ptr %v3705
}

define private ptr @mlf.code.3629(ptr %env, ptr %arg) {
entry:
  %v3630 = getelementptr i8, ptr %env, i64 8
  %v3631 = load ptr, ptr %v3630, align 8, !tbaa !3
  %v3632 = getelementptr i8, ptr %env, i64 16
  %v3633 = load ptr, ptr %v3632, align 8, !tbaa !3
  %v3634 = getelementptr i8, ptr %env, i64 24
  %v3635 = load ptr, ptr %v3634, align 8, !tbaa !3
  %v3636 = getelementptr i8, ptr %env, i64 32
  %v3637 = load ptr, ptr %v3636, align 8, !tbaa !3
  %v3638 = getelementptr i8, ptr %env, i64 40
  %v3639 = load ptr, ptr %v3638, align 8, !tbaa !3
  %v3640 = getelementptr i8, ptr %env, i64 48
  %v3641 = load ptr, ptr %v3640, align 8, !tbaa !3
  %v3642 = getelementptr i8, ptr %env, i64 56
  %v3643 = load ptr, ptr %v3642, align 8, !tbaa !3
  %v3644 = getelementptr i8, ptr %env, i64 64
  %v3645 = load ptr, ptr %v3644, align 8, !tbaa !3
  %v3646 = getelementptr i8, ptr %env, i64 72
  %v3647 = load ptr, ptr %v3646, align 8, !tbaa !3
  %v3648 = getelementptr i8, ptr %env, i64 80
  %v3649 = load ptr, ptr %v3648, align 8, !tbaa !3
  %v3661 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3650, i64 3)
  %v3662 = getelementptr i8, ptr %v3661, i64 16
  %v3663 = load ptr, ptr %v3662, align 8, !tbaa !3
  %v3664 = getelementptr i8, ptr %v3663, i64 8
  store ptr %v3639, ptr %v3664, align 8, !tbaa !3
  %v3665 = getelementptr i8, ptr %v3663, i64 16
  store ptr %v3649, ptr %v3665, align 8, !tbaa !3
  %v3666 = getelementptr i8, ptr %v3663, i64 24
  store ptr %arg, ptr %v3666, align 8, !tbaa !3
  %v3706 = call ptr @mlf_env_new(i64 10)
  %v3707 = getelementptr i8, ptr %v3706, i64 8
  store ptr %v3631, ptr %v3707, align 8, !tbaa !3
  %v3708 = getelementptr i8, ptr %v3706, i64 16
  store ptr %v3633, ptr %v3708, align 8, !tbaa !3
  %v3709 = getelementptr i8, ptr %v3706, i64 24
  store ptr %v3635, ptr %v3709, align 8, !tbaa !3
  %v3710 = getelementptr i8, ptr %v3706, i64 32
  store ptr %v3637, ptr %v3710, align 8, !tbaa !3
  %v3711 = getelementptr i8, ptr %v3706, i64 40
  store ptr %v3639, ptr %v3711, align 8, !tbaa !3
  %v3712 = getelementptr i8, ptr %v3706, i64 48
  store ptr %v3641, ptr %v3712, align 8, !tbaa !3
  %v3713 = getelementptr i8, ptr %v3706, i64 56
  store ptr %v3643, ptr %v3713, align 8, !tbaa !3
  %v3714 = getelementptr i8, ptr %v3706, i64 64
  store ptr %v3645, ptr %v3714, align 8, !tbaa !3
  %v3715 = getelementptr i8, ptr %v3706, i64 72
  store ptr %v3647, ptr %v3715, align 8, !tbaa !3
  %v3716 = getelementptr i8, ptr %v3706, i64 80
  store ptr %v3649, ptr %v3716, align 8, !tbaa !3
  %v3717 = call ptr @mlf_closure(ptr @mlf.code.3667, ptr %v3706)
  %v3718 = call ptr @mlf_prim2(i64 1, ptr %v3661, ptr %v3717)
  ret ptr %v3718
}

define private ptr @mlf.code.3363(ptr %env, ptr %arg) {
entry:
  %v3364 = getelementptr i8, ptr %env, i64 8
  %v3365 = load ptr, ptr %v3364, align 8, !tbaa !3
  %v3366 = getelementptr i8, ptr %env, i64 16
  %v3367 = load ptr, ptr %v3366, align 8, !tbaa !3
  %v3368 = getelementptr i8, ptr %env, i64 24
  %v3369 = load ptr, ptr %v3368, align 8, !tbaa !3
  %v3370 = getelementptr i8, ptr %env, i64 32
  %v3371 = load ptr, ptr %v3370, align 8, !tbaa !3
  %v3372 = getelementptr i8, ptr %env, i64 40
  %v3373 = load ptr, ptr %v3372, align 8, !tbaa !3
  %v3374 = getelementptr i8, ptr %env, i64 48
  %v3375 = load ptr, ptr %v3374, align 8, !tbaa !3
  %v3376 = getelementptr i8, ptr %env, i64 56
  %v3377 = load ptr, ptr %v3376, align 8, !tbaa !3
  %v3378 = getelementptr i8, ptr %env, i64 64
  %v3379 = load ptr, ptr %v3378, align 8, !tbaa !3
  %v3380 = getelementptr i8, ptr %env, i64 72
  %v3381 = load ptr, ptr %v3380, align 8, !tbaa !3
  %v3382 = getelementptr i8, ptr %env, i64 80
  %v3383 = load ptr, ptr %v3382, align 8, !tbaa !3
  %v3622 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3384, i64 4)
  %v3623 = getelementptr i8, ptr %v3622, i64 16
  %v3624 = load ptr, ptr %v3623, align 8, !tbaa !3
  %v3625 = getelementptr i8, ptr %v3624, i64 8
  store ptr %v3365, ptr %v3625, align 8, !tbaa !3
  %v3626 = getelementptr i8, ptr %v3624, i64 16
  store ptr %v3367, ptr %v3626, align 8, !tbaa !3
  %v3627 = getelementptr i8, ptr %v3624, i64 24
  store ptr %v3371, ptr %v3627, align 8, !tbaa !3
  %v3628 = getelementptr i8, ptr %v3624, i64 32
  store ptr %v3375, ptr %v3628, align 8, !tbaa !3
  %v3719 = call ptr @mlf_env_new(i64 10)
  %v3720 = getelementptr i8, ptr %v3719, i64 8
  store ptr %v3365, ptr %v3720, align 8, !tbaa !3
  %v3721 = getelementptr i8, ptr %v3719, i64 16
  store ptr %v3367, ptr %v3721, align 8, !tbaa !3
  %v3722 = getelementptr i8, ptr %v3719, i64 24
  store ptr %v3369, ptr %v3722, align 8, !tbaa !3
  %v3723 = getelementptr i8, ptr %v3719, i64 32
  store ptr %v3371, ptr %v3723, align 8, !tbaa !3
  %v3724 = getelementptr i8, ptr %v3719, i64 40
  store ptr %v3373, ptr %v3724, align 8, !tbaa !3
  %v3725 = getelementptr i8, ptr %v3719, i64 48
  store ptr %v3375, ptr %v3725, align 8, !tbaa !3
  %v3726 = getelementptr i8, ptr %v3719, i64 56
  store ptr %v3377, ptr %v3726, align 8, !tbaa !3
  %v3727 = getelementptr i8, ptr %v3719, i64 64
  store ptr %v3379, ptr %v3727, align 8, !tbaa !3
  %v3728 = getelementptr i8, ptr %v3719, i64 72
  store ptr %v3381, ptr %v3728, align 8, !tbaa !3
  %v3729 = getelementptr i8, ptr %v3719, i64 80
  store ptr %v3383, ptr %v3729, align 8, !tbaa !3
  %v3730 = call ptr @mlf_closure(ptr @mlf.code.3629, ptr %v3719)
  %v3731 = call ptr @mlf_prim2(i64 1, ptr %v3622, ptr %v3730)
  ret ptr %v3731
}

define private ptr @mlf.code.3315(ptr %env, ptr %arg) {
entry:
  %v3316 = getelementptr i8, ptr %env, i64 8
  %v3317 = load ptr, ptr %v3316, align 8, !tbaa !3
  %v3318 = getelementptr i8, ptr %env, i64 16
  %v3319 = load ptr, ptr %v3318, align 8, !tbaa !3
  %v3320 = getelementptr i8, ptr %env, i64 24
  %v3321 = load ptr, ptr %v3320, align 8, !tbaa !3
  %v3322 = getelementptr i8, ptr %env, i64 32
  %v3323 = load ptr, ptr %v3322, align 8, !tbaa !3
  %v3324 = getelementptr i8, ptr %env, i64 40
  %v3325 = load ptr, ptr %v3324, align 8, !tbaa !3
  %v3326 = getelementptr i8, ptr %env, i64 48
  %v3327 = load ptr, ptr %v3326, align 8, !tbaa !3
  %v3328 = getelementptr i8, ptr %env, i64 56
  %v3329 = load ptr, ptr %v3328, align 8, !tbaa !3
  %v3330 = getelementptr i8, ptr %env, i64 64
  %v3331 = load ptr, ptr %v3330, align 8, !tbaa !3
  %v3332 = getelementptr i8, ptr %env, i64 72
  %v3333 = load ptr, ptr %v3332, align 8, !tbaa !3
  %v3334 = getelementptr i8, ptr %env, i64 80
  %v3335 = load ptr, ptr %v3334, align 8, !tbaa !3
  %v3336 = getelementptr i8, ptr %env, i64 88
  %v3337 = load ptr, ptr %v3336, align 8, !tbaa !3
  %v3358 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3338, i64 2)
  %v3359 = getelementptr i8, ptr %v3358, i64 16
  %v3360 = load ptr, ptr %v3359, align 8, !tbaa !3
  %v3361 = getelementptr i8, ptr %v3360, i64 8
  store ptr %v3323, ptr %v3361, align 8, !tbaa !3
  %v3362 = getelementptr i8, ptr %v3360, i64 16
  store ptr %v3337, ptr %v3362, align 8, !tbaa !3
  %v3732 = call ptr @mlf_env_new(i64 10)
  %v3733 = getelementptr i8, ptr %v3732, i64 8
  store ptr %v3317, ptr %v3733, align 8, !tbaa !3
  %v3734 = getelementptr i8, ptr %v3732, i64 16
  store ptr %v3319, ptr %v3734, align 8, !tbaa !3
  %v3735 = getelementptr i8, ptr %v3732, i64 24
  store ptr %v3321, ptr %v3735, align 8, !tbaa !3
  %v3736 = getelementptr i8, ptr %v3732, i64 32
  store ptr %v3323, ptr %v3736, align 8, !tbaa !3
  %v3737 = getelementptr i8, ptr %v3732, i64 40
  store ptr %v3325, ptr %v3737, align 8, !tbaa !3
  %v3738 = getelementptr i8, ptr %v3732, i64 48
  store ptr %v3327, ptr %v3738, align 8, !tbaa !3
  %v3739 = getelementptr i8, ptr %v3732, i64 56
  store ptr %v3329, ptr %v3739, align 8, !tbaa !3
  %v3740 = getelementptr i8, ptr %v3732, i64 64
  store ptr %v3331, ptr %v3740, align 8, !tbaa !3
  %v3741 = getelementptr i8, ptr %v3732, i64 72
  store ptr %v3333, ptr %v3741, align 8, !tbaa !3
  %v3742 = getelementptr i8, ptr %v3732, i64 80
  store ptr %v3335, ptr %v3742, align 8, !tbaa !3
  %v3743 = call ptr @mlf_closure(ptr @mlf.code.3363, ptr %v3732)
  %v3744 = call ptr @mlf_prim2(i64 1, ptr %v3358, ptr %v3743)
  ret ptr %v3744
}

define private ptr @mlf.code.3269(ptr %env, ptr %arg) {
entry:
  %v3270 = getelementptr i8, ptr %env, i64 8
  %v3271 = load ptr, ptr %v3270, align 8, !tbaa !3
  %v3272 = getelementptr i8, ptr %env, i64 16
  %v3273 = load ptr, ptr %v3272, align 8, !tbaa !3
  %v3274 = getelementptr i8, ptr %env, i64 24
  %v3275 = load ptr, ptr %v3274, align 8, !tbaa !3
  %v3276 = getelementptr i8, ptr %env, i64 32
  %v3277 = load ptr, ptr %v3276, align 8, !tbaa !3
  %v3278 = getelementptr i8, ptr %env, i64 40
  %v3279 = load ptr, ptr %v3278, align 8, !tbaa !3
  %v3280 = getelementptr i8, ptr %env, i64 48
  %v3281 = load ptr, ptr %v3280, align 8, !tbaa !3
  %v3282 = getelementptr i8, ptr %env, i64 56
  %v3283 = load ptr, ptr %v3282, align 8, !tbaa !3
  %v3284 = getelementptr i8, ptr %env, i64 64
  %v3285 = load ptr, ptr %v3284, align 8, !tbaa !3
  %v3286 = getelementptr i8, ptr %env, i64 72
  %v3287 = load ptr, ptr %v3286, align 8, !tbaa !3
  %v3288 = getelementptr i8, ptr %env, i64 80
  %v3289 = load ptr, ptr %v3288, align 8, !tbaa !3
  %v3298 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3290, i64 1)
  %v3299 = getelementptr i8, ptr %v3298, i64 16
  %v3300 = load ptr, ptr %v3299, align 8, !tbaa !3
  %v3301 = getelementptr i8, ptr %v3300, i64 8
  store ptr %arg, ptr %v3301, align 8, !tbaa !3
  %v3310 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3302, i64 2)
  %v3311 = getelementptr i8, ptr %v3310, i64 16
  %v3312 = load ptr, ptr %v3311, align 8, !tbaa !3
  %v3313 = getelementptr i8, ptr %v3312, i64 8
  store ptr %v3275, ptr %v3313, align 8, !tbaa !3
  %v3314 = getelementptr i8, ptr %v3312, i64 16
  store ptr %v3298, ptr %v3314, align 8, !tbaa !3
  %v3745 = call ptr @mlf_env_new(i64 11)
  %v3746 = getelementptr i8, ptr %v3745, i64 8
  store ptr %v3271, ptr %v3746, align 8, !tbaa !3
  %v3747 = getelementptr i8, ptr %v3745, i64 16
  store ptr %v3273, ptr %v3747, align 8, !tbaa !3
  %v3748 = getelementptr i8, ptr %v3745, i64 24
  store ptr %v3275, ptr %v3748, align 8, !tbaa !3
  %v3749 = getelementptr i8, ptr %v3745, i64 32
  store ptr %v3277, ptr %v3749, align 8, !tbaa !3
  %v3750 = getelementptr i8, ptr %v3745, i64 40
  store ptr %v3279, ptr %v3750, align 8, !tbaa !3
  %v3751 = getelementptr i8, ptr %v3745, i64 48
  store ptr %v3281, ptr %v3751, align 8, !tbaa !3
  %v3752 = getelementptr i8, ptr %v3745, i64 56
  store ptr %v3283, ptr %v3752, align 8, !tbaa !3
  %v3753 = getelementptr i8, ptr %v3745, i64 64
  store ptr %v3285, ptr %v3753, align 8, !tbaa !3
  %v3754 = getelementptr i8, ptr %v3745, i64 72
  store ptr %v3287, ptr %v3754, align 8, !tbaa !3
  %v3755 = getelementptr i8, ptr %v3745, i64 80
  store ptr %v3289, ptr %v3755, align 8, !tbaa !3
  %v3756 = getelementptr i8, ptr %v3745, i64 88
  store ptr %v3298, ptr %v3756, align 8, !tbaa !3
  %v3757 = call ptr @mlf_closure(ptr @mlf.code.3315, ptr %v3745)
  %v3758 = call ptr @mlf_prim2(i64 1, ptr %v3310, ptr %v3757)
  ret ptr %v3758
}

define private ptr @mlf.worker.40(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6, ptr %a7, ptr %a8, ptr %a9) {
entry:
  %v3175 = call ptr @mlf_prim2(i64 8, ptr %a8, ptr %a9)
  %v3176 = call ptr @mlf_prim2(i64 8, ptr %a7, ptr %v3175)
  %v3177 = call ptr @mlf_prim2(i64 10, ptr %v3176, ptr %v3176)
  %v3178 = icmp eq ptr %v3177, inttoptr (i64 6 to ptr)
  br i1 %v3178, label %yes.3179, label %no.3180
yes.3179:
  %v3182 = call ptr @mlf_prim2(i64 10, ptr %a8, ptr inttoptr (i64 121 to ptr))
  %v3183 = icmp eq ptr %v3182, inttoptr (i64 6 to ptr)
  br i1 %v3183, label %yes.3184, label %no.3185
yes.3184:
  %v3195 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3187, i64 2)
  %v3196 = getelementptr i8, ptr %v3195, i64 16
  %v3197 = load ptr, ptr %v3196, align 8, !tbaa !3
  %v3198 = getelementptr i8, ptr %v3197, i64 8
  store ptr %a4, ptr %v3198, align 8, !tbaa !3
  %v3199 = getelementptr i8, ptr %v3197, i64 16
  store ptr %a9, ptr %v3199, align 8, !tbaa !3
  %v3234 = call ptr @mlf_env_new(i64 9)
  %v3235 = getelementptr i8, ptr %v3234, i64 8
  store ptr %a0, ptr %v3235, align 8, !tbaa !3
  %v3236 = getelementptr i8, ptr %v3234, i64 16
  store ptr %a1, ptr %v3236, align 8, !tbaa !3
  %v3237 = getelementptr i8, ptr %v3234, i64 24
  store ptr %a2, ptr %v3237, align 8, !tbaa !3
  %v3238 = getelementptr i8, ptr %v3234, i64 32
  store ptr %a3, ptr %v3238, align 8, !tbaa !3
  %v3239 = getelementptr i8, ptr %v3234, i64 40
  store ptr %a4, ptr %v3239, align 8, !tbaa !3
  %v3240 = getelementptr i8, ptr %v3234, i64 48
  store ptr %a5, ptr %v3240, align 8, !tbaa !3
  %v3241 = getelementptr i8, ptr %v3234, i64 56
  store ptr %a6, ptr %v3241, align 8, !tbaa !3
  %v3242 = getelementptr i8, ptr %v3234, i64 64
  store ptr %a7, ptr %v3242, align 8, !tbaa !3
  %v3243 = getelementptr i8, ptr %v3234, i64 72
  store ptr %a9, ptr %v3243, align 8, !tbaa !3
  %v3244 = call ptr @mlf_closure(ptr @mlf.code.3200, ptr %v3234)
  %v3245 = call ptr @mlf_prim2(i64 1, ptr %v3195, ptr %v3244)
  br label %join.3186
no.3185:
  %v3246 = call ptr @mlf.force(ptr %a6)
  %v3247 = call ptr @mlf_prim2(i64 10, ptr %a7, ptr %v3246)
  %v3248 = icmp eq ptr %v3247, inttoptr (i64 6 to ptr)
  br i1 %v3248, label %yes.3249, label %no.3250
yes.3249:
  %v3252 = call ptr @mlf_prim2(i64 10, ptr %a8, ptr inttoptr (i64 1 to ptr))
  %v3253 = icmp eq ptr %v3252, inttoptr (i64 6 to ptr)
  br i1 %v3253, label %yes.3254, label %no.3255
yes.3254:
  %v3257 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.3256
no.3255:
  %v3258 = call ptr @mlf_prim3(i64 37, ptr %a4, ptr %a9, ptr inttoptr (i64 21 to ptr))
  br label %join.3256
join.3256:
  %v3259 = phi ptr [ %v3257, %yes.3254 ], [ %v3258, %no.3255 ]
  br label %join.3251
no.3250:
  %v3265 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3260, i64 1)
  %v3266 = getelementptr i8, ptr %v3265, i64 16
  %v3267 = load ptr, ptr %v3266, align 8, !tbaa !3
  %v3268 = getelementptr i8, ptr %v3267, i64 8
  store ptr %a2, ptr %v3268, align 8, !tbaa !3
  %v3759 = call ptr @mlf_env_new(i64 10)
  %v3760 = getelementptr i8, ptr %v3759, i64 8
  store ptr %a0, ptr %v3760, align 8, !tbaa !3
  %v3761 = getelementptr i8, ptr %v3759, i64 16
  store ptr %a1, ptr %v3761, align 8, !tbaa !3
  %v3762 = getelementptr i8, ptr %v3759, i64 24
  store ptr %a2, ptr %v3762, align 8, !tbaa !3
  %v3763 = getelementptr i8, ptr %v3759, i64 32
  store ptr %a3, ptr %v3763, align 8, !tbaa !3
  %v3764 = getelementptr i8, ptr %v3759, i64 40
  store ptr %a4, ptr %v3764, align 8, !tbaa !3
  %v3765 = getelementptr i8, ptr %v3759, i64 48
  store ptr %a5, ptr %v3765, align 8, !tbaa !3
  %v3766 = getelementptr i8, ptr %v3759, i64 56
  store ptr %v3246, ptr %v3766, align 8, !tbaa !3
  %v3767 = getelementptr i8, ptr %v3759, i64 64
  store ptr %a7, ptr %v3767, align 8, !tbaa !3
  %v3768 = getelementptr i8, ptr %v3759, i64 72
  store ptr %a8, ptr %v3768, align 8, !tbaa !3
  %v3769 = getelementptr i8, ptr %v3759, i64 80
  store ptr %a9, ptr %v3769, align 8, !tbaa !3
  %v3770 = call ptr @mlf_closure(ptr @mlf.code.3269, ptr %v3759)
  %v3771 = call ptr @mlf_prim2(i64 1, ptr %v3265, ptr %v3770)
  br label %join.3251
join.3251:
  %v3772 = phi ptr [ %v3259, %join.3256 ], [ %v3771, %no.3250 ]
  br label %join.3186
join.3186:
  %v3773 = phi ptr [ %v3245, %yes.3184 ], [ %v3772, %join.3251 ]
  br label %join.3181
no.3180:
  %v3774 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.3181
join.3181:
  %v3775 = phi ptr [ %v3773, %join.3186 ], [ %v3774, %no.3180 ]
  ret ptr %v3775
}

define private ptr @mlf.numeric.entry.3119(ptr %env, ptr %arg) {
entry:
  %v3120 = getelementptr i8, ptr %env, i64 8
  %v3121 = load ptr, ptr %v3120, align 8, !tbaa !3
  %v3122 = getelementptr i8, ptr %env, i64 16
  %v3123 = load ptr, ptr %v3122, align 8, !tbaa !3
  %v3124 = getelementptr i8, ptr %env, i64 24
  %v3125 = load ptr, ptr %v3124, align 8, !tbaa !3
  %v3126 = getelementptr i8, ptr %env, i64 32
  %v3127 = load ptr, ptr %v3126, align 8, !tbaa !3
  %v3128 = getelementptr i8, ptr %env, i64 40
  %v3129 = load ptr, ptr %v3128, align 8, !tbaa !3
  %v3130 = getelementptr i8, ptr %env, i64 48
  %v3131 = load ptr, ptr %v3130, align 8, !tbaa !3
  %v3132 = getelementptr i8, ptr %env, i64 56
  %v3133 = load ptr, ptr %v3132, align 8, !tbaa !3
  %v3134 = getelementptr i8, ptr %env, i64 64
  %v3135 = load ptr, ptr %v3134, align 8, !tbaa !3
  %v3136 = getelementptr i8, ptr %env, i64 72
  %v3137 = load ptr, ptr %v3136, align 8, !tbaa !3
  %v3138 = getelementptr i8, ptr %env, i64 80
  %v3139 = load ptr, ptr %v3138, align 8, !tbaa !3
  %v3140 = call ptr @mlf_peek(ptr %v3121)
  %v3141 = call ptr @mlf_peek(ptr %v3123)
  %v3142 = call ptr @mlf_peek(ptr %v3125)
  %v3143 = call ptr @mlf_peek(ptr %v3127)
  %v3144 = call ptr @mlf_peek(ptr %v3129)
  %v3145 = call ptr @mlf_peek(ptr %v3131)
  %v3146 = call ptr @mlf_peek(ptr %v3133)
  %v3147 = call ptr @mlf_peek(ptr %v3135)
  %v3148 = call ptr @mlf_peek(ptr %v3137)
  %v3149 = call ptr @mlf_peek(ptr %v3139)
  %v3150 = icmp ne ptr %v3140, null
  %v3151 = icmp ne ptr %v3141, null
  %v3152 = icmp ne ptr %v3142, null
  %v3153 = icmp ne ptr %v3143, null
  %v3154 = icmp ne ptr %v3144, null
  %v3155 = icmp ne ptr %v3145, null
  %v3156 = icmp ne ptr %v3146, null
  %v3157 = icmp ne ptr %v3147, null
  %v3158 = icmp ne ptr %v3148, null
  %v3159 = icmp ne ptr %v3149, null
  %v3160 = and i1 true, %v3150
  %v3161 = and i1 %v3160, %v3151
  %v3162 = and i1 %v3161, %v3152
  %v3163 = and i1 %v3162, %v3153
  %v3164 = and i1 %v3163, %v3154
  %v3165 = and i1 %v3164, %v3155
  %v3166 = and i1 %v3165, %v3156
  %v3167 = and i1 %v3166, %v3157
  %v3168 = and i1 %v3167, %v3158
  %v3169 = and i1 %v3168, %v3159
  br i1 %v3169, label %yes.3170, label %no.3171
yes.3170:
  %v3173 = call ptr @mlf.numeric.40(ptr %v3140, ptr %v3141, ptr %v3142, ptr %v3143, ptr %v3144, ptr %v3145, ptr %v3146, ptr %v3147, ptr %v3148, ptr %v3149)
  %v3174 = call ptr @mlf_prim1(i64 0, ptr %v3173)
  br label %join.3172
no.3171:
  %v3776 = call ptr @mlf.force(ptr %v3135)
  %v3777 = call ptr @mlf.force(ptr %v3137)
  %v3778 = call ptr @mlf.force(ptr %v3139)
  %v3779 = call ptr @mlf.worker.40(ptr %v3121, ptr %v3123, ptr %v3125, ptr %v3127, ptr %v3129, ptr %v3131, ptr %v3133, ptr %v3776, ptr %v3777, ptr %v3778)
  br label %join.3172
join.3172:
  %v3780 = phi ptr [ %v3174, %yes.3170 ], [ %v3779, %no.3171 ]
  ret ptr %v3780
}

define private ptr @mlf.code.3097(ptr %env, ptr %arg) {
entry:
  %v3098 = getelementptr i8, ptr %env, i64 8
  %v3099 = load ptr, ptr %v3098, align 8, !tbaa !3
  %v3100 = getelementptr i8, ptr %env, i64 16
  %v3101 = load ptr, ptr %v3100, align 8, !tbaa !3
  %v3102 = getelementptr i8, ptr %env, i64 24
  %v3103 = load ptr, ptr %v3102, align 8, !tbaa !3
  %v3104 = getelementptr i8, ptr %env, i64 32
  %v3105 = load ptr, ptr %v3104, align 8, !tbaa !3
  %v3106 = getelementptr i8, ptr %env, i64 40
  %v3107 = load ptr, ptr %v3106, align 8, !tbaa !3
  %v3108 = getelementptr i8, ptr %env, i64 48
  %v3109 = load ptr, ptr %v3108, align 8, !tbaa !3
  %v3110 = getelementptr i8, ptr %env, i64 56
  %v3111 = load ptr, ptr %v3110, align 8, !tbaa !3
  %v3112 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3112, align 8, !tbaa !3
  %v3113 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v3113, align 8, !tbaa !3
  %v3114 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v3114, align 8, !tbaa !3
  %v3115 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v3115, align 8, !tbaa !3
  %v3116 = getelementptr i8, ptr %env, i64 40
  store ptr null, ptr %v3116, align 8, !tbaa !3
  %v3117 = getelementptr i8, ptr %env, i64 48
  store ptr null, ptr %v3117, align 8, !tbaa !3
  %v3118 = getelementptr i8, ptr %env, i64 56
  store ptr null, ptr %v3118, align 8, !tbaa !3
  %v3781 = call ptr @mlf_env_new(i64 10)
  %v3782 = getelementptr i8, ptr %v3781, i64 8
  store ptr %v3099, ptr %v3782, align 8, !tbaa !3
  %v3783 = getelementptr i8, ptr %v3781, i64 16
  store ptr %v3101, ptr %v3783, align 8, !tbaa !3
  %v3784 = getelementptr i8, ptr %v3781, i64 24
  store ptr %v3103, ptr %v3784, align 8, !tbaa !3
  %v3785 = getelementptr i8, ptr %v3781, i64 32
  store ptr %v3105, ptr %v3785, align 8, !tbaa !3
  %v3786 = getelementptr i8, ptr %v3781, i64 40
  store ptr %v3107, ptr %v3786, align 8, !tbaa !3
  %v3787 = getelementptr i8, ptr %v3781, i64 48
  store ptr %v3109, ptr %v3787, align 8, !tbaa !3
  %v3788 = getelementptr i8, ptr %v3781, i64 56
  store ptr %v3111, ptr %v3788, align 8, !tbaa !3
  %v3789 = getelementptr i8, ptr %v3781, i64 64
  store ptr inttoptr (i64 1 to ptr), ptr %v3789, align 8, !tbaa !3
  %v3790 = getelementptr i8, ptr %v3781, i64 72
  store ptr inttoptr (i64 1 to ptr), ptr %v3790, align 8, !tbaa !3
  %v3791 = getelementptr i8, ptr %v3781, i64 80
  store ptr inttoptr (i64 1 to ptr), ptr %v3791, align 8, !tbaa !3
  %v3792 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.3119, ptr %v3781)
  ret ptr %v3792
}

define private ptr @mlf.code.3827(ptr %env, ptr %arg) {
entry:
  %v3828 = getelementptr i8, ptr %env, i64 8
  %v3829 = load ptr, ptr %v3828, align 8, !tbaa !3
  %v3830 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3830, align 8, !tbaa !3
  %v3831 = call ptr @mlf.force(ptr %v3829)
  %v3832 = call ptr @mlf_prim2(i64 8, ptr %v3831, ptr inttoptr (i64 119 to ptr))
  %v3833 = call ptr @mlf_prim2(i64 15, ptr %v3832, ptr inttoptr (i64 121 to ptr))
  %v3834 = call ptr @mlf_prim2(i64 8, ptr %v3831, ptr %v3833)
  ret ptr %v3834
}

define private ptr @mlf.code.3820(ptr %env, ptr %arg) {
entry:
  %v3821 = getelementptr i8, ptr %env, i64 8
  %v3822 = load ptr, ptr %v3821, align 8, !tbaa !3
  %v3823 = getelementptr i8, ptr %env, i64 16
  %v3824 = load ptr, ptr %v3823, align 8, !tbaa !3
  %v3825 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v3825, align 8, !tbaa !3
  %v3826 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v3826, align 8, !tbaa !3
  %v3835 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3827, i64 1)
  %v3836 = getelementptr i8, ptr %v3835, i64 16
  %v3837 = load ptr, ptr %v3836, align 8, !tbaa !3
  %v3838 = getelementptr i8, ptr %v3837, i64 8
  store ptr %v3824, ptr %v3838, align 8, !tbaa !3
  %v3839 = call ptr @mlf_prim3(i64 40, ptr %v3822, ptr inttoptr (i64 1 to ptr), ptr %v3835)
  ret ptr %v3839
}

define private ptr @mlf.code.3845(ptr %env, ptr %arg) {
entry:
  %v3846 = getelementptr i8, ptr %env, i64 8
  %v3847 = load ptr, ptr %v3846, align 8, !tbaa !3
  %v3848 = getelementptr i8, ptr %env, i64 16
  %v3849 = load ptr, ptr %v3848, align 8, !tbaa !3
  %v3850 = getelementptr i8, ptr %env, i64 24
  %v3851 = load ptr, ptr %v3850, align 8, !tbaa !3
  %v3852 = getelementptr i8, ptr %env, i64 32
  %v3853 = load ptr, ptr %v3852, align 8, !tbaa !3
  %v3854 = getelementptr i8, ptr %env, i64 40
  %v3855 = load ptr, ptr %v3854, align 8, !tbaa !3
  %v3856 = getelementptr i8, ptr %env, i64 48
  %v3857 = load ptr, ptr %v3856, align 8, !tbaa !3
  %v3858 = getelementptr i8, ptr %env, i64 56
  %v3859 = load ptr, ptr %v3858, align 8, !tbaa !3
  %v3860 = getelementptr i8, ptr %env, i64 64
  %v3861 = load ptr, ptr %v3860, align 8, !tbaa !3
  %v3862 = call ptr @mlf.force(ptr %v3859)
  %v3863 = call ptr @mlf.force(ptr %v3861)
  %v3864 = call ptr @mlf_prim2(i64 9, ptr %v3862, ptr %v3863)
  %v3865 = call ptr @mlf_env_new(i64 7)
  %v3866 = getelementptr i8, ptr %v3865, i64 8
  store ptr %v3847, ptr %v3866, align 8, !tbaa !3
  %v3867 = getelementptr i8, ptr %v3865, i64 16
  store ptr %v3849, ptr %v3867, align 8, !tbaa !3
  %v3868 = getelementptr i8, ptr %v3865, i64 24
  store ptr %v3851, ptr %v3868, align 8, !tbaa !3
  %v3869 = getelementptr i8, ptr %v3865, i64 32
  store ptr %v3853, ptr %v3869, align 8, !tbaa !3
  %v3870 = getelementptr i8, ptr %v3865, i64 40
  store ptr %v3855, ptr %v3870, align 8, !tbaa !3
  %v3871 = getelementptr i8, ptr %v3865, i64 48
  store ptr %v3857, ptr %v3871, align 8, !tbaa !3
  %v3872 = getelementptr i8, ptr %v3865, i64 56
  store ptr %v3864, ptr %v3872, align 8, !tbaa !3
  %v3873 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2016, ptr %v3865)
  ret ptr %v3873
}

define private ptr @mlf.code.3803(ptr %env, ptr %arg) {
entry:
  %v3804 = getelementptr i8, ptr %env, i64 8
  %v3805 = load ptr, ptr %v3804, align 8, !tbaa !3
  %v3806 = getelementptr i8, ptr %env, i64 16
  %v3807 = load ptr, ptr %v3806, align 8, !tbaa !3
  %v3808 = getelementptr i8, ptr %env, i64 24
  %v3809 = load ptr, ptr %v3808, align 8, !tbaa !3
  %v3810 = getelementptr i8, ptr %env, i64 32
  %v3811 = load ptr, ptr %v3810, align 8, !tbaa !3
  %v3812 = getelementptr i8, ptr %env, i64 40
  %v3813 = load ptr, ptr %v3812, align 8, !tbaa !3
  %v3814 = getelementptr i8, ptr %env, i64 48
  %v3815 = load ptr, ptr %v3814, align 8, !tbaa !3
  %v3816 = getelementptr i8, ptr %env, i64 56
  %v3817 = load ptr, ptr %v3816, align 8, !tbaa !3
  %v3818 = getelementptr i8, ptr %env, i64 64
  %v3819 = load ptr, ptr %v3818, align 8, !tbaa !3
  %v3840 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3820, i64 2)
  %v3841 = getelementptr i8, ptr %v3840, i64 16
  %v3842 = load ptr, ptr %v3841, align 8, !tbaa !3
  %v3843 = getelementptr i8, ptr %v3842, i64 8
  store ptr %v3813, ptr %v3843, align 8, !tbaa !3
  %v3844 = getelementptr i8, ptr %v3842, i64 16
  store ptr %v3819, ptr %v3844, align 8, !tbaa !3
  %v3874 = call ptr @mlf_env_new(i64 8)
  %v3875 = getelementptr i8, ptr %v3874, i64 8
  store ptr %v3805, ptr %v3875, align 8, !tbaa !3
  %v3876 = getelementptr i8, ptr %v3874, i64 16
  store ptr %v3807, ptr %v3876, align 8, !tbaa !3
  %v3877 = getelementptr i8, ptr %v3874, i64 24
  store ptr %v3809, ptr %v3877, align 8, !tbaa !3
  %v3878 = getelementptr i8, ptr %v3874, i64 32
  store ptr %v3811, ptr %v3878, align 8, !tbaa !3
  %v3879 = getelementptr i8, ptr %v3874, i64 40
  store ptr %v3813, ptr %v3879, align 8, !tbaa !3
  %v3880 = getelementptr i8, ptr %v3874, i64 48
  store ptr %v3815, ptr %v3880, align 8, !tbaa !3
  %v3881 = getelementptr i8, ptr %v3874, i64 56
  store ptr %v3817, ptr %v3881, align 8, !tbaa !3
  %v3882 = getelementptr i8, ptr %v3874, i64 64
  store ptr %v3819, ptr %v3882, align 8, !tbaa !3
  %v3883 = call ptr @mlf_closure(ptr @mlf.code.3845, ptr %v3874)
  %v3884 = call ptr @mlf_prim2(i64 1, ptr %v3840, ptr %v3883)
  ret ptr %v3884
}

define private ptr @mlf.worker.61(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6) {
entry:
  %v3076 = call ptr @mlf_prim2(i64 10, ptr %a6, ptr inttoptr (i64 1 to ptr))
  %v3077 = icmp eq ptr %v3076, inttoptr (i64 6 to ptr)
  br i1 %v3077, label %yes.3078, label %no.3079
yes.3078:
  %v3081 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.3080
no.3079:
  %v3093 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3082, i64 1)
  %v3094 = getelementptr i8, ptr %v3093, i64 16
  %v3095 = load ptr, ptr %v3094, align 8, !tbaa !3
  %v3096 = getelementptr i8, ptr %v3095, i64 8
  store ptr %a6, ptr %v3096, align 8, !tbaa !3
  %v3793 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3097, i64 7)
  %v3794 = getelementptr i8, ptr %v3793, i64 16
  %v3795 = load ptr, ptr %v3794, align 8, !tbaa !3
  %v3796 = getelementptr i8, ptr %v3795, i64 8
  store ptr %a0, ptr %v3796, align 8, !tbaa !3
  %v3797 = getelementptr i8, ptr %v3795, i64 16
  store ptr %a1, ptr %v3797, align 8, !tbaa !3
  %v3798 = getelementptr i8, ptr %v3795, i64 24
  store ptr %a2, ptr %v3798, align 8, !tbaa !3
  %v3799 = getelementptr i8, ptr %v3795, i64 32
  store ptr %a3, ptr %v3799, align 8, !tbaa !3
  %v3800 = getelementptr i8, ptr %v3795, i64 40
  store ptr %a4, ptr %v3800, align 8, !tbaa !3
  %v3801 = getelementptr i8, ptr %v3795, i64 48
  store ptr %a5, ptr %v3801, align 8, !tbaa !3
  %v3802 = getelementptr i8, ptr %v3795, i64 56
  store ptr %v3093, ptr %v3802, align 8, !tbaa !3
  %v3885 = call ptr @mlf_env_new(i64 8)
  %v3886 = getelementptr i8, ptr %v3885, i64 8
  store ptr %a0, ptr %v3886, align 8, !tbaa !3
  %v3887 = getelementptr i8, ptr %v3885, i64 16
  store ptr %a1, ptr %v3887, align 8, !tbaa !3
  %v3888 = getelementptr i8, ptr %v3885, i64 24
  store ptr %a2, ptr %v3888, align 8, !tbaa !3
  %v3889 = getelementptr i8, ptr %v3885, i64 32
  store ptr %a3, ptr %v3889, align 8, !tbaa !3
  %v3890 = getelementptr i8, ptr %v3885, i64 40
  store ptr %a4, ptr %v3890, align 8, !tbaa !3
  %v3891 = getelementptr i8, ptr %v3885, i64 48
  store ptr %a5, ptr %v3891, align 8, !tbaa !3
  %v3892 = getelementptr i8, ptr %v3885, i64 56
  store ptr %a6, ptr %v3892, align 8, !tbaa !3
  %v3893 = getelementptr i8, ptr %v3885, i64 64
  store ptr %v3093, ptr %v3893, align 8, !tbaa !3
  %v3894 = call ptr @mlf_closure(ptr @mlf.code.3803, ptr %v3885)
  %v3895 = call ptr @mlf_prim2(i64 1, ptr %v3793, ptr %v3894)
  br label %join.3080
join.3080:
  %v3896 = phi ptr [ %v3081, %yes.3078 ], [ %v3895, %no.3079 ]
  ret ptr %v3896
}

define private ptr @mlf.numeric.entry.2016(ptr %env, ptr %arg) {
entry:
  %v2017 = getelementptr i8, ptr %env, i64 8
  %v2018 = load ptr, ptr %v2017, align 8, !tbaa !3
  %v2019 = getelementptr i8, ptr %env, i64 16
  %v2020 = load ptr, ptr %v2019, align 8, !tbaa !3
  %v2021 = getelementptr i8, ptr %env, i64 24
  %v2022 = load ptr, ptr %v2021, align 8, !tbaa !3
  %v2023 = getelementptr i8, ptr %env, i64 32
  %v2024 = load ptr, ptr %v2023, align 8, !tbaa !3
  %v2025 = getelementptr i8, ptr %env, i64 40
  %v2026 = load ptr, ptr %v2025, align 8, !tbaa !3
  %v2027 = getelementptr i8, ptr %env, i64 48
  %v2028 = load ptr, ptr %v2027, align 8, !tbaa !3
  %v2029 = getelementptr i8, ptr %env, i64 56
  %v2030 = load ptr, ptr %v2029, align 8, !tbaa !3
  %v2031 = call ptr @mlf_peek(ptr %v2018)
  %v2032 = call ptr @mlf_peek(ptr %v2020)
  %v2033 = call ptr @mlf_peek(ptr %v2022)
  %v2034 = call ptr @mlf_peek(ptr %v2024)
  %v2035 = call ptr @mlf_peek(ptr %v2026)
  %v2036 = call ptr @mlf_peek(ptr %v2028)
  %v2037 = call ptr @mlf_peek(ptr %v2030)
  %v2038 = icmp ne ptr %v2031, null
  %v2039 = icmp ne ptr %v2032, null
  %v2040 = icmp ne ptr %v2033, null
  %v2041 = icmp ne ptr %v2034, null
  %v2042 = icmp ne ptr %v2035, null
  %v2043 = icmp ne ptr %v2036, null
  %v2044 = icmp ne ptr %v2037, null
  %v2045 = and i1 true, %v2038
  %v2046 = and i1 %v2045, %v2039
  %v2047 = and i1 %v2046, %v2040
  %v2048 = and i1 %v2047, %v2041
  %v2049 = and i1 %v2048, %v2042
  %v2050 = and i1 %v2049, %v2043
  %v2051 = and i1 %v2050, %v2044
  br i1 %v2051, label %yes.2052, label %no.2053
yes.2052:
  %v3074 = call ptr @mlf.numeric.61(ptr %v2031, ptr %v2032, ptr %v2033, ptr %v2034, ptr %v2035, ptr %v2036, ptr %v2037)
  %v3075 = call ptr @mlf_prim1(i64 0, ptr %v3074)
  br label %join.2054
no.2053:
  %v3897 = call ptr @mlf.force(ptr %v2030)
  %v3898 = call ptr @mlf.worker.61(ptr %v2018, ptr %v2020, ptr %v2022, ptr %v2024, ptr %v2026, ptr %v2028, ptr %v3897)
  br label %join.2054
join.2054:
  %v3899 = phi ptr [ %v3075, %yes.2052 ], [ %v3898, %no.2053 ]
  ret ptr %v3899
}

define private ptr @mlf.code.1997(ptr %env, ptr %arg) {
entry:
  %v1998 = getelementptr i8, ptr %env, i64 8
  %v1999 = load ptr, ptr %v1998, align 8, !tbaa !3
  %v2000 = getelementptr i8, ptr %env, i64 16
  %v2001 = load ptr, ptr %v2000, align 8, !tbaa !3
  %v2002 = getelementptr i8, ptr %env, i64 24
  %v2003 = load ptr, ptr %v2002, align 8, !tbaa !3
  %v2004 = getelementptr i8, ptr %env, i64 32
  %v2005 = load ptr, ptr %v2004, align 8, !tbaa !3
  %v2006 = getelementptr i8, ptr %env, i64 40
  %v2007 = load ptr, ptr %v2006, align 8, !tbaa !3
  %v2008 = getelementptr i8, ptr %env, i64 48
  %v2009 = load ptr, ptr %v2008, align 8, !tbaa !3
  %v2010 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2010, align 8, !tbaa !3
  %v2011 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2011, align 8, !tbaa !3
  %v2012 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v2012, align 8, !tbaa !3
  %v2013 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v2013, align 8, !tbaa !3
  %v2014 = getelementptr i8, ptr %env, i64 40
  store ptr null, ptr %v2014, align 8, !tbaa !3
  %v2015 = getelementptr i8, ptr %env, i64 48
  store ptr null, ptr %v2015, align 8, !tbaa !3
  %v3900 = call ptr @mlf.force(ptr %v1999)
  %v3901 = ptrtoint ptr %v3900 to i64
  %v3902 = ptrtoint ptr inttoptr (i64 7 to ptr) to i64
  %v3903 = and i64 %v3901, %v3902
  %v3904 = and i64 %v3903, 1
  %v3905 = icmp ne i64 %v3904, 0
  br i1 %v3905, label %yes.3906, label %no.3907
yes.3906:
  %v3909 = ashr i64 %v3901, 1
  %v3910 = ashr i64 %v3902, 1
  %v3911 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v3909, i64 %v3910)
  %v3912 = extractvalue { i64, i1 } %v3911, 0
  %v3913 = extractvalue { i64, i1 } %v3911, 1
  %v3914 = xor i1 %v3913, true
  %v3915 = icmp sge i64 %v3912, -4611686018427387904
  %v3916 = icmp sle i64 %v3912, 4611686018427387903
  %v3917 = and i1 %v3915, %v3916
  %v3918 = and i1 %v3917, %v3914
  br i1 %v3918, label %yes.3919, label %no.3920
yes.3919:
  %v3922 = shl i64 %v3912, 1
  %v3923 = or i64 %v3922, 1
  %v3924 = inttoptr i64 %v3923 to ptr
  br label %join.3921
no.3920:
  %v3925 = call ptr @mlf_prim2(i64 14, ptr %v3900, ptr inttoptr (i64 7 to ptr))
  br label %join.3921
join.3921:
  %v3926 = phi ptr [ %v3924, %yes.3919 ], [ %v3925, %no.3920 ]
  br label %join.3908
no.3907:
  %v3927 = call ptr @mlf_prim2(i64 14, ptr %v3900, ptr inttoptr (i64 7 to ptr))
  br label %join.3908
join.3908:
  %v3928 = phi ptr [ %v3926, %join.3921 ], [ %v3927, %no.3907 ]
  %v3929 = call ptr @mlf_env_new(i64 7)
  %v3930 = getelementptr i8, ptr %v3929, i64 8
  store ptr %v2001, ptr %v3930, align 8, !tbaa !3
  %v3931 = getelementptr i8, ptr %v3929, i64 16
  store ptr %v2003, ptr %v3931, align 8, !tbaa !3
  %v3932 = getelementptr i8, ptr %v3929, i64 24
  store ptr %v2007, ptr %v3932, align 8, !tbaa !3
  %v3933 = getelementptr i8, ptr %v3929, i64 32
  store ptr %v2009, ptr %v3933, align 8, !tbaa !3
  %v3934 = getelementptr i8, ptr %v3929, i64 40
  store ptr %v2005, ptr %v3934, align 8, !tbaa !3
  %v3935 = getelementptr i8, ptr %v3929, i64 48
  store ptr inttoptr (i64 31 to ptr), ptr %v3935, align 8, !tbaa !3
  %v3936 = getelementptr i8, ptr %v3929, i64 56
  store ptr %v3928, ptr %v3936, align 8, !tbaa !3
  %v3937 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2016, ptr %v3929)
  ret ptr %v3937
}

define private ptr @mlf.code.3960(ptr %env, ptr %arg) {
entry:
  %v3962 = call ptr @mlf_prim1(i64 3, ptr @mlf.bytes.3961.value)
  ret ptr %v3962
}

define private ptr @mlf.code.3964(ptr %env, ptr %arg) {
entry:
  %v3965 = getelementptr i8, ptr %env, i64 8
  %v3966 = load ptr, ptr %v3965, align 8, !tbaa !3
  %v3967 = getelementptr i8, ptr %env, i64 16
  %v3968 = load ptr, ptr %v3967, align 8, !tbaa !3
  %v3969 = getelementptr i8, ptr %env, i64 24
  %v3970 = load ptr, ptr %v3969, align 8, !tbaa !3
  %v3971 = getelementptr i8, ptr %env, i64 32
  %v3972 = load ptr, ptr %v3971, align 8, !tbaa !3
  %v3973 = getelementptr i8, ptr %env, i64 40
  %v3974 = load ptr, ptr %v3973, align 8, !tbaa !3
  %v3975 = getelementptr i8, ptr %env, i64 48
  %v3976 = load ptr, ptr %v3975, align 8, !tbaa !3
  %v3977 = call ptr @mlf.force(ptr %v3966)
  %v3978 = ptrtoint ptr %v3977 to i64
  %v3979 = ptrtoint ptr inttoptr (i64 11 to ptr) to i64
  %v3980 = and i64 %v3978, %v3979
  %v3981 = and i64 %v3980, 1
  %v3982 = icmp ne i64 %v3981, 0
  br i1 %v3982, label %yes.3983, label %no.3984
yes.3983:
  %v3986 = ashr i64 %v3978, 1
  %v3987 = ashr i64 %v3979, 1
  %v3988 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v3986, i64 %v3987)
  %v3989 = extractvalue { i64, i1 } %v3988, 0
  %v3990 = extractvalue { i64, i1 } %v3988, 1
  %v3991 = xor i1 %v3990, true
  %v3992 = icmp sge i64 %v3989, -4611686018427387904
  %v3993 = icmp sle i64 %v3989, 4611686018427387903
  %v3994 = and i1 %v3992, %v3993
  %v3995 = and i1 %v3994, %v3991
  br i1 %v3995, label %yes.3996, label %no.3997
yes.3996:
  %v3999 = shl i64 %v3989, 1
  %v4000 = or i64 %v3999, 1
  %v4001 = inttoptr i64 %v4000 to ptr
  br label %join.3998
no.3997:
  %v4002 = call ptr @mlf_prim2(i64 14, ptr %v3977, ptr inttoptr (i64 11 to ptr))
  br label %join.3998
join.3998:
  %v4003 = phi ptr [ %v4001, %yes.3996 ], [ %v4002, %no.3997 ]
  br label %join.3985
no.3984:
  %v4004 = call ptr @mlf_prim2(i64 14, ptr %v3977, ptr inttoptr (i64 11 to ptr))
  br label %join.3985
join.3985:
  %v4005 = phi ptr [ %v4003, %join.3998 ], [ %v4004, %no.3984 ]
  %v4006 = call ptr @mlf_env_new(i64 7)
  %v4007 = getelementptr i8, ptr %v4006, i64 8
  store ptr %v3968, ptr %v4007, align 8, !tbaa !3
  %v4008 = getelementptr i8, ptr %v4006, i64 16
  store ptr %v3970, ptr %v4008, align 8, !tbaa !3
  %v4009 = getelementptr i8, ptr %v4006, i64 24
  store ptr %v3974, ptr %v4009, align 8, !tbaa !3
  %v4010 = getelementptr i8, ptr %v4006, i64 32
  store ptr %v3976, ptr %v4010, align 8, !tbaa !3
  %v4011 = getelementptr i8, ptr %v4006, i64 40
  store ptr %v3972, ptr %v4011, align 8, !tbaa !3
  %v4012 = getelementptr i8, ptr %v4006, i64 48
  store ptr inttoptr (i64 9 to ptr), ptr %v4012, align 8, !tbaa !3
  %v4013 = getelementptr i8, ptr %v4006, i64 56
  store ptr %v4005, ptr %v4013, align 8, !tbaa !3
  %v4014 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2016, ptr %v4006)
  ret ptr %v4014
}

define private ptr @mlf.code.3947(ptr %env, ptr %arg) {
entry:
  %v3948 = getelementptr i8, ptr %env, i64 8
  %v3949 = load ptr, ptr %v3948, align 8, !tbaa !3
  %v3950 = getelementptr i8, ptr %env, i64 16
  %v3951 = load ptr, ptr %v3950, align 8, !tbaa !3
  %v3952 = getelementptr i8, ptr %env, i64 24
  %v3953 = load ptr, ptr %v3952, align 8, !tbaa !3
  %v3954 = getelementptr i8, ptr %env, i64 32
  %v3955 = load ptr, ptr %v3954, align 8, !tbaa !3
  %v3956 = getelementptr i8, ptr %env, i64 40
  %v3957 = load ptr, ptr %v3956, align 8, !tbaa !3
  %v3958 = getelementptr i8, ptr %env, i64 48
  %v3959 = load ptr, ptr %v3958, align 8, !tbaa !3
  %v3963 = call ptr @mlf_thunk(ptr @mlf.code.3960, ptr null)
  %v4015 = call ptr @mlf_env_new(i64 6)
  %v4016 = getelementptr i8, ptr %v4015, i64 8
  store ptr %v3949, ptr %v4016, align 8, !tbaa !3
  %v4017 = getelementptr i8, ptr %v4015, i64 16
  store ptr %v3951, ptr %v4017, align 8, !tbaa !3
  %v4018 = getelementptr i8, ptr %v4015, i64 24
  store ptr %v3953, ptr %v4018, align 8, !tbaa !3
  %v4019 = getelementptr i8, ptr %v4015, i64 32
  store ptr %v3955, ptr %v4019, align 8, !tbaa !3
  %v4020 = getelementptr i8, ptr %v4015, i64 40
  store ptr %v3957, ptr %v4020, align 8, !tbaa !3
  %v4021 = getelementptr i8, ptr %v4015, i64 48
  store ptr %v3959, ptr %v4021, align 8, !tbaa !3
  %v4022 = call ptr @mlf_closure(ptr @mlf.code.3964, ptr %v4015)
  %v4023 = call ptr @mlf_prim2(i64 1, ptr %v3963, ptr %v4022)
  ret ptr %v4023
}

define private ptr @mlf.code.1980(ptr %env, ptr %arg) {
entry:
  %v1981 = getelementptr i8, ptr %env, i64 8
  %v1982 = load ptr, ptr %v1981, align 8, !tbaa !3
  %v1983 = getelementptr i8, ptr %env, i64 16
  %v1984 = load ptr, ptr %v1983, align 8, !tbaa !3
  %v1985 = getelementptr i8, ptr %env, i64 24
  %v1986 = load ptr, ptr %v1985, align 8, !tbaa !3
  %v1987 = getelementptr i8, ptr %env, i64 32
  %v1988 = load ptr, ptr %v1987, align 8, !tbaa !3
  %v1989 = getelementptr i8, ptr %env, i64 40
  %v1990 = load ptr, ptr %v1989, align 8, !tbaa !3
  %v1991 = getelementptr i8, ptr %env, i64 48
  %v1992 = load ptr, ptr %v1991, align 8, !tbaa !3
  %v1993 = getelementptr i8, ptr %env, i64 56
  %v1994 = load ptr, ptr %v1993, align 8, !tbaa !3
  %v1995 = getelementptr i8, ptr %env, i64 64
  %v1996 = load ptr, ptr %v1995, align 8, !tbaa !3
  %v3938 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1997, i64 6)
  %v3939 = getelementptr i8, ptr %v3938, i64 16
  %v3940 = load ptr, ptr %v3939, align 8, !tbaa !3
  %v3941 = getelementptr i8, ptr %v3940, i64 8
  store ptr %v1982, ptr %v3941, align 8, !tbaa !3
  %v3942 = getelementptr i8, ptr %v3940, i64 16
  store ptr %v1984, ptr %v3942, align 8, !tbaa !3
  %v3943 = getelementptr i8, ptr %v3940, i64 24
  store ptr %v1988, ptr %v3943, align 8, !tbaa !3
  %v3944 = getelementptr i8, ptr %v3940, i64 32
  store ptr %v1992, ptr %v3944, align 8, !tbaa !3
  %v3945 = getelementptr i8, ptr %v3940, i64 40
  store ptr %v1994, ptr %v3945, align 8, !tbaa !3
  %v3946 = getelementptr i8, ptr %v3940, i64 48
  store ptr %v1996, ptr %v3946, align 8, !tbaa !3
  %v4024 = call ptr @mlf_env_new(i64 6)
  %v4025 = getelementptr i8, ptr %v4024, i64 8
  store ptr %v1982, ptr %v4025, align 8, !tbaa !3
  %v4026 = getelementptr i8, ptr %v4024, i64 16
  store ptr %v1986, ptr %v4026, align 8, !tbaa !3
  %v4027 = getelementptr i8, ptr %v4024, i64 24
  store ptr %v1990, ptr %v4027, align 8, !tbaa !3
  %v4028 = getelementptr i8, ptr %v4024, i64 32
  store ptr %v1992, ptr %v4028, align 8, !tbaa !3
  %v4029 = getelementptr i8, ptr %v4024, i64 40
  store ptr %v1994, ptr %v4029, align 8, !tbaa !3
  %v4030 = getelementptr i8, ptr %v4024, i64 48
  store ptr %v1996, ptr %v4030, align 8, !tbaa !3
  %v4031 = call ptr @mlf_closure(ptr @mlf.code.3947, ptr %v4024)
  %v4032 = call ptr @mlf_prim2(i64 1, ptr %v3938, ptr %v4031)
  ret ptr %v4032
}

define private ptr @mlf.code.1959(ptr %env, ptr %arg) {
entry:
  %v1960 = getelementptr i8, ptr %env, i64 8
  %v1961 = load ptr, ptr %v1960, align 8, !tbaa !3
  %v1962 = getelementptr i8, ptr %env, i64 16
  %v1963 = load ptr, ptr %v1962, align 8, !tbaa !3
  %v1964 = getelementptr i8, ptr %env, i64 24
  %v1965 = load ptr, ptr %v1964, align 8, !tbaa !3
  %v1966 = getelementptr i8, ptr %env, i64 32
  %v1967 = load ptr, ptr %v1966, align 8, !tbaa !3
  %v1968 = getelementptr i8, ptr %env, i64 40
  %v1969 = load ptr, ptr %v1968, align 8, !tbaa !3
  %v1970 = getelementptr i8, ptr %env, i64 48
  %v1971 = load ptr, ptr %v1970, align 8, !tbaa !3
  %v1972 = getelementptr i8, ptr %env, i64 56
  %v1973 = load ptr, ptr %v1972, align 8, !tbaa !3
  %v1974 = getelementptr i8, ptr %env, i64 64
  %v1975 = load ptr, ptr %v1974, align 8, !tbaa !3
  %v1979 = call ptr @mlf_thunk(ptr @mlf.code.1976, ptr null)
  %v4033 = call ptr @mlf_env_new(i64 8)
  %v4034 = getelementptr i8, ptr %v4033, i64 8
  store ptr %v1961, ptr %v4034, align 8, !tbaa !3
  %v4035 = getelementptr i8, ptr %v4033, i64 16
  store ptr %v1963, ptr %v4035, align 8, !tbaa !3
  %v4036 = getelementptr i8, ptr %v4033, i64 24
  store ptr %v1965, ptr %v4036, align 8, !tbaa !3
  %v4037 = getelementptr i8, ptr %v4033, i64 32
  store ptr %v1967, ptr %v4037, align 8, !tbaa !3
  %v4038 = getelementptr i8, ptr %v4033, i64 40
  store ptr %v1969, ptr %v4038, align 8, !tbaa !3
  %v4039 = getelementptr i8, ptr %v4033, i64 48
  store ptr %v1971, ptr %v4039, align 8, !tbaa !3
  %v4040 = getelementptr i8, ptr %v4033, i64 56
  store ptr %v1973, ptr %v4040, align 8, !tbaa !3
  %v4041 = getelementptr i8, ptr %v4033, i64 64
  store ptr %v1975, ptr %v4041, align 8, !tbaa !3
  %v4042 = call ptr @mlf_closure(ptr @mlf.code.1980, ptr %v4033)
  %v4043 = call ptr @mlf_prim2(i64 1, ptr %v1979, ptr %v4042)
  ret ptr %v4043
}

define private ptr @mlf.code.612(ptr %env, ptr %arg) {
entry:
  %v613 = getelementptr i8, ptr %env, i64 8
  %v614 = load ptr, ptr %v613, align 8, !tbaa !3
  %v615 = getelementptr i8, ptr %env, i64 16
  %v616 = load ptr, ptr %v615, align 8, !tbaa !3
  %v617 = getelementptr i8, ptr %env, i64 24
  %v618 = load ptr, ptr %v617, align 8, !tbaa !3
  %v619 = getelementptr i8, ptr %env, i64 32
  %v620 = load ptr, ptr %v619, align 8, !tbaa !3
  %v621 = getelementptr i8, ptr %env, i64 40
  %v622 = load ptr, ptr %v621, align 8, !tbaa !3
  %v623 = getelementptr i8, ptr %env, i64 48
  %v624 = load ptr, ptr %v623, align 8, !tbaa !3
  %v625 = getelementptr i8, ptr %env, i64 56
  %v626 = load ptr, ptr %v625, align 8, !tbaa !3
  %v627 = getelementptr i8, ptr %env, i64 64
  %v628 = load ptr, ptr %v627, align 8, !tbaa !3
  %v629 = getelementptr i8, ptr %env, i64 72
  %v630 = load ptr, ptr %v629, align 8, !tbaa !3
  %v631 = getelementptr i8, ptr %env, i64 80
  %v632 = load ptr, ptr %v631, align 8, !tbaa !3
  %v1952 = call ptr @mlf.allocate.thunk(ptr @mlf.code.633, i64 4)
  %v1953 = getelementptr i8, ptr %v1952, i64 16
  %v1954 = load ptr, ptr %v1953, align 8, !tbaa !3
  %v1955 = getelementptr i8, ptr %v1954, i64 8
  store ptr %v614, ptr %v1955, align 8, !tbaa !3
  %v1956 = getelementptr i8, ptr %v1954, i64 16
  store ptr %v616, ptr %v1956, align 8, !tbaa !3
  %v1957 = getelementptr i8, ptr %v1954, i64 24
  store ptr %v626, ptr %v1957, align 8, !tbaa !3
  %v1958 = getelementptr i8, ptr %v1954, i64 32
  store ptr %v632, ptr %v1958, align 8, !tbaa !3
  %v4044 = call ptr @mlf_env_new(i64 8)
  %v4045 = getelementptr i8, ptr %v4044, i64 8
  store ptr %v614, ptr %v4045, align 8, !tbaa !3
  %v4046 = getelementptr i8, ptr %v4044, i64 16
  store ptr %v618, ptr %v4046, align 8, !tbaa !3
  %v4047 = getelementptr i8, ptr %v4044, i64 24
  store ptr %v620, ptr %v4047, align 8, !tbaa !3
  %v4048 = getelementptr i8, ptr %v4044, i64 32
  store ptr %v622, ptr %v4048, align 8, !tbaa !3
  %v4049 = getelementptr i8, ptr %v4044, i64 40
  store ptr %v624, ptr %v4049, align 8, !tbaa !3
  %v4050 = getelementptr i8, ptr %v4044, i64 48
  store ptr %v626, ptr %v4050, align 8, !tbaa !3
  %v4051 = getelementptr i8, ptr %v4044, i64 56
  store ptr %v628, ptr %v4051, align 8, !tbaa !3
  %v4052 = getelementptr i8, ptr %v4044, i64 64
  store ptr %v630, ptr %v4052, align 8, !tbaa !3
  %v4053 = call ptr @mlf_closure(ptr @mlf.code.1959, ptr %v4044)
  %v4054 = call ptr @mlf_prim2(i64 1, ptr %v1952, ptr %v4053)
  ret ptr %v4054
}

define private ptr @mlf.code.589(ptr %env, ptr %arg) {
entry:
  %v590 = getelementptr i8, ptr %env, i64 8
  %v591 = load ptr, ptr %v590, align 8, !tbaa !3
  %v592 = getelementptr i8, ptr %env, i64 16
  %v593 = load ptr, ptr %v592, align 8, !tbaa !3
  %v594 = getelementptr i8, ptr %env, i64 24
  %v595 = load ptr, ptr %v594, align 8, !tbaa !3
  %v596 = getelementptr i8, ptr %env, i64 32
  %v597 = load ptr, ptr %v596, align 8, !tbaa !3
  %v598 = getelementptr i8, ptr %env, i64 40
  %v599 = load ptr, ptr %v598, align 8, !tbaa !3
  %v600 = getelementptr i8, ptr %env, i64 48
  %v601 = load ptr, ptr %v600, align 8, !tbaa !3
  %v602 = getelementptr i8, ptr %env, i64 56
  %v603 = load ptr, ptr %v602, align 8, !tbaa !3
  %v604 = getelementptr i8, ptr %env, i64 64
  %v605 = load ptr, ptr %v604, align 8, !tbaa !3
  %v606 = getelementptr i8, ptr %env, i64 72
  %v607 = load ptr, ptr %v606, align 8, !tbaa !3
  %v611 = call ptr @mlf_thunk(ptr @mlf.code.608, ptr null)
  %v4055 = call ptr @mlf_env_new(i64 10)
  %v4056 = getelementptr i8, ptr %v4055, i64 8
  store ptr %v591, ptr %v4056, align 8, !tbaa !3
  %v4057 = getelementptr i8, ptr %v4055, i64 16
  store ptr %v593, ptr %v4057, align 8, !tbaa !3
  %v4058 = getelementptr i8, ptr %v4055, i64 24
  store ptr %v595, ptr %v4058, align 8, !tbaa !3
  %v4059 = getelementptr i8, ptr %v4055, i64 32
  store ptr %v597, ptr %v4059, align 8, !tbaa !3
  %v4060 = getelementptr i8, ptr %v4055, i64 40
  store ptr %v599, ptr %v4060, align 8, !tbaa !3
  %v4061 = getelementptr i8, ptr %v4055, i64 48
  store ptr %v601, ptr %v4061, align 8, !tbaa !3
  %v4062 = getelementptr i8, ptr %v4055, i64 56
  store ptr %v603, ptr %v4062, align 8, !tbaa !3
  %v4063 = getelementptr i8, ptr %v4055, i64 64
  store ptr %v605, ptr %v4063, align 8, !tbaa !3
  %v4064 = getelementptr i8, ptr %v4055, i64 72
  store ptr %v607, ptr %v4064, align 8, !tbaa !3
  %v4065 = getelementptr i8, ptr %v4055, i64 80
  store ptr %arg, ptr %v4065, align 8, !tbaa !3
  %v4066 = call ptr @mlf_closure(ptr @mlf.code.612, ptr %v4055)
  %v4067 = call ptr @mlf_prim2(i64 1, ptr %v611, ptr %v4066)
  ret ptr %v4067
}

define private ptr @mlf.code.563(ptr %env, ptr %arg) {
entry:
  %v564 = getelementptr i8, ptr %env, i64 8
  %v565 = load ptr, ptr %v564, align 8, !tbaa !3
  %v566 = getelementptr i8, ptr %env, i64 16
  %v567 = load ptr, ptr %v566, align 8, !tbaa !3
  %v568 = getelementptr i8, ptr %env, i64 24
  %v569 = load ptr, ptr %v568, align 8, !tbaa !3
  %v570 = getelementptr i8, ptr %env, i64 32
  %v571 = load ptr, ptr %v570, align 8, !tbaa !3
  %v572 = getelementptr i8, ptr %env, i64 40
  %v573 = load ptr, ptr %v572, align 8, !tbaa !3
  %v574 = getelementptr i8, ptr %env, i64 48
  %v575 = load ptr, ptr %v574, align 8, !tbaa !3
  %v576 = getelementptr i8, ptr %env, i64 56
  %v577 = load ptr, ptr %v576, align 8, !tbaa !3
  %v578 = getelementptr i8, ptr %env, i64 64
  %v579 = load ptr, ptr %v578, align 8, !tbaa !3
  %v585 = call ptr @mlf.allocate.thunk(ptr @mlf.code.580, i64 1)
  %v586 = getelementptr i8, ptr %v585, i64 16
  %v587 = load ptr, ptr %v586, align 8, !tbaa !3
  %v588 = getelementptr i8, ptr %v587, i64 8
  store ptr %v567, ptr %v588, align 8, !tbaa !3
  %v4068 = call ptr @mlf_env_new(i64 9)
  %v4069 = getelementptr i8, ptr %v4068, i64 8
  store ptr %v565, ptr %v4069, align 8, !tbaa !3
  %v4070 = getelementptr i8, ptr %v4068, i64 16
  store ptr %v567, ptr %v4070, align 8, !tbaa !3
  %v4071 = getelementptr i8, ptr %v4068, i64 24
  store ptr %v569, ptr %v4071, align 8, !tbaa !3
  %v4072 = getelementptr i8, ptr %v4068, i64 32
  store ptr %v571, ptr %v4072, align 8, !tbaa !3
  %v4073 = getelementptr i8, ptr %v4068, i64 40
  store ptr %v573, ptr %v4073, align 8, !tbaa !3
  %v4074 = getelementptr i8, ptr %v4068, i64 48
  store ptr %v575, ptr %v4074, align 8, !tbaa !3
  %v4075 = getelementptr i8, ptr %v4068, i64 56
  store ptr %v577, ptr %v4075, align 8, !tbaa !3
  %v4076 = getelementptr i8, ptr %v4068, i64 64
  store ptr %v579, ptr %v4076, align 8, !tbaa !3
  %v4077 = getelementptr i8, ptr %v4068, i64 72
  store ptr %arg, ptr %v4077, align 8, !tbaa !3
  %v4078 = call ptr @mlf_closure(ptr @mlf.code.589, ptr %v4068)
  %v4079 = call ptr @mlf_prim2(i64 1, ptr %v585, ptr %v4078)
  ret ptr %v4079
}

define private ptr @mlf.code.544(ptr %env, ptr %arg) {
entry:
  %v545 = getelementptr i8, ptr %env, i64 8
  %v546 = load ptr, ptr %v545, align 8, !tbaa !3
  %v547 = getelementptr i8, ptr %env, i64 16
  %v548 = load ptr, ptr %v547, align 8, !tbaa !3
  %v549 = getelementptr i8, ptr %env, i64 24
  %v550 = load ptr, ptr %v549, align 8, !tbaa !3
  %v551 = getelementptr i8, ptr %env, i64 32
  %v552 = load ptr, ptr %v551, align 8, !tbaa !3
  %v553 = getelementptr i8, ptr %env, i64 40
  %v554 = load ptr, ptr %v553, align 8, !tbaa !3
  %v555 = getelementptr i8, ptr %env, i64 48
  %v556 = load ptr, ptr %v555, align 8, !tbaa !3
  %v557 = getelementptr i8, ptr %env, i64 56
  %v558 = load ptr, ptr %v557, align 8, !tbaa !3
  %v562 = call ptr @mlf_thunk(ptr @mlf.code.559, ptr null)
  %v4080 = call ptr @mlf_env_new(i64 8)
  %v4081 = getelementptr i8, ptr %v4080, i64 8
  store ptr %v546, ptr %v4081, align 8, !tbaa !3
  %v4082 = getelementptr i8, ptr %v4080, i64 16
  store ptr %v548, ptr %v4082, align 8, !tbaa !3
  %v4083 = getelementptr i8, ptr %v4080, i64 24
  store ptr %v550, ptr %v4083, align 8, !tbaa !3
  %v4084 = getelementptr i8, ptr %v4080, i64 32
  store ptr %v552, ptr %v4084, align 8, !tbaa !3
  %v4085 = getelementptr i8, ptr %v4080, i64 40
  store ptr %v554, ptr %v4085, align 8, !tbaa !3
  %v4086 = getelementptr i8, ptr %v4080, i64 48
  store ptr %v556, ptr %v4086, align 8, !tbaa !3
  %v4087 = getelementptr i8, ptr %v4080, i64 56
  store ptr %v558, ptr %v4087, align 8, !tbaa !3
  %v4088 = getelementptr i8, ptr %v4080, i64 64
  store ptr %arg, ptr %v4088, align 8, !tbaa !3
  %v4089 = call ptr @mlf_closure(ptr @mlf.code.563, ptr %v4080)
  %v4090 = call ptr @mlf_prim2(i64 1, ptr %v562, ptr %v4089)
  ret ptr %v4090
}

define private ptr @mlf.code.528(ptr %env, ptr %arg) {
entry:
  %v529 = getelementptr i8, ptr %env, i64 8
  %v530 = load ptr, ptr %v529, align 8, !tbaa !3
  %v531 = getelementptr i8, ptr %env, i64 16
  %v532 = load ptr, ptr %v531, align 8, !tbaa !3
  %v533 = getelementptr i8, ptr %env, i64 24
  %v534 = load ptr, ptr %v533, align 8, !tbaa !3
  %v535 = getelementptr i8, ptr %env, i64 32
  %v536 = load ptr, ptr %v535, align 8, !tbaa !3
  %v537 = getelementptr i8, ptr %env, i64 40
  %v538 = load ptr, ptr %v537, align 8, !tbaa !3
  %v539 = getelementptr i8, ptr %env, i64 48
  %v540 = load ptr, ptr %v539, align 8, !tbaa !3
  %v543 = call ptr @mlf_thunk(ptr @mlf.code.541, ptr null)
  %v4091 = call ptr @mlf_env_new(i64 7)
  %v4092 = getelementptr i8, ptr %v4091, i64 8
  store ptr %v530, ptr %v4092, align 8, !tbaa !3
  %v4093 = getelementptr i8, ptr %v4091, i64 16
  store ptr %v532, ptr %v4093, align 8, !tbaa !3
  %v4094 = getelementptr i8, ptr %v4091, i64 24
  store ptr %v534, ptr %v4094, align 8, !tbaa !3
  %v4095 = getelementptr i8, ptr %v4091, i64 32
  store ptr %v536, ptr %v4095, align 8, !tbaa !3
  %v4096 = getelementptr i8, ptr %v4091, i64 40
  store ptr %v538, ptr %v4096, align 8, !tbaa !3
  %v4097 = getelementptr i8, ptr %v4091, i64 48
  store ptr %v540, ptr %v4097, align 8, !tbaa !3
  %v4098 = getelementptr i8, ptr %v4091, i64 56
  store ptr %arg, ptr %v4098, align 8, !tbaa !3
  %v4099 = call ptr @mlf_closure(ptr @mlf.code.544, ptr %v4091)
  %v4100 = call ptr @mlf_prim2(i64 1, ptr %v543, ptr %v4099)
  ret ptr %v4100
}

define private ptr @mlf.code.512(ptr %env, ptr %arg) {
entry:
  %v513 = getelementptr i8, ptr %env, i64 8
  %v514 = load ptr, ptr %v513, align 8, !tbaa !3
  %v515 = getelementptr i8, ptr %env, i64 16
  %v516 = load ptr, ptr %v515, align 8, !tbaa !3
  %v517 = getelementptr i8, ptr %env, i64 24
  %v518 = load ptr, ptr %v517, align 8, !tbaa !3
  %v519 = getelementptr i8, ptr %env, i64 32
  %v520 = load ptr, ptr %v519, align 8, !tbaa !3
  %v521 = getelementptr i8, ptr %env, i64 40
  %v522 = load ptr, ptr %v521, align 8, !tbaa !3
  %v523 = getelementptr i8, ptr %env, i64 48
  %v524 = load ptr, ptr %v523, align 8, !tbaa !3
  %v527 = call ptr @mlf_thunk(ptr @mlf.code.525, ptr null)
  %v4101 = call ptr @mlf_env_new(i64 6)
  %v4102 = getelementptr i8, ptr %v4101, i64 8
  store ptr %v514, ptr %v4102, align 8, !tbaa !3
  %v4103 = getelementptr i8, ptr %v4101, i64 16
  store ptr %v516, ptr %v4103, align 8, !tbaa !3
  %v4104 = getelementptr i8, ptr %v4101, i64 24
  store ptr %v518, ptr %v4104, align 8, !tbaa !3
  %v4105 = getelementptr i8, ptr %v4101, i64 32
  store ptr %v520, ptr %v4105, align 8, !tbaa !3
  %v4106 = getelementptr i8, ptr %v4101, i64 40
  store ptr %v522, ptr %v4106, align 8, !tbaa !3
  %v4107 = getelementptr i8, ptr %v4101, i64 48
  store ptr %v524, ptr %v4107, align 8, !tbaa !3
  %v4108 = call ptr @mlf_closure(ptr @mlf.code.528, ptr %v4101)
  %v4109 = call ptr @mlf_prim2(i64 1, ptr %v527, ptr %v4108)
  ret ptr %v4109
}

define private ptr @mlf.code.486(ptr %env, ptr %arg) {
entry:
  %v487 = getelementptr i8, ptr %env, i64 8
  %v488 = load ptr, ptr %v487, align 8, !tbaa !3
  %v489 = getelementptr i8, ptr %env, i64 16
  %v490 = load ptr, ptr %v489, align 8, !tbaa !3
  %v491 = getelementptr i8, ptr %env, i64 24
  %v492 = load ptr, ptr %v491, align 8, !tbaa !3
  %v493 = getelementptr i8, ptr %env, i64 32
  %v494 = load ptr, ptr %v493, align 8, !tbaa !3
  %v495 = getelementptr i8, ptr %env, i64 40
  %v496 = load ptr, ptr %v495, align 8, !tbaa !3
  %v497 = getelementptr i8, ptr %env, i64 48
  %v498 = load ptr, ptr %v497, align 8, !tbaa !3
  %v508 = call ptr @mlf.allocate.thunk(ptr @mlf.code.499, i64 1)
  %v509 = getelementptr i8, ptr %v508, i64 16
  %v510 = load ptr, ptr %v509, align 8, !tbaa !3
  %v511 = getelementptr i8, ptr %v510, i64 8
  store ptr %v498, ptr %v511, align 8, !tbaa !3
  %v4110 = call ptr @mlf_env_new(i64 6)
  %v4111 = getelementptr i8, ptr %v4110, i64 8
  store ptr %v488, ptr %v4111, align 8, !tbaa !3
  %v4112 = getelementptr i8, ptr %v4110, i64 16
  store ptr %v490, ptr %v4112, align 8, !tbaa !3
  %v4113 = getelementptr i8, ptr %v4110, i64 24
  store ptr %v492, ptr %v4113, align 8, !tbaa !3
  %v4114 = getelementptr i8, ptr %v4110, i64 32
  store ptr %v494, ptr %v4114, align 8, !tbaa !3
  %v4115 = getelementptr i8, ptr %v4110, i64 40
  store ptr %v496, ptr %v4115, align 8, !tbaa !3
  %v4116 = getelementptr i8, ptr %v4110, i64 48
  store ptr %v498, ptr %v4116, align 8, !tbaa !3
  %v4117 = call ptr @mlf_closure(ptr @mlf.code.512, ptr %v4110)
  %v4118 = call ptr @mlf_prim2(i64 1, ptr %v508, ptr %v4117)
  ret ptr %v4118
}

define private ptr @mlf.code.231(ptr %env, ptr %arg) {
entry:
  %v232 = getelementptr i8, ptr %env, i64 8
  %v233 = load ptr, ptr %v232, align 8, !tbaa !3
  %v234 = getelementptr i8, ptr %env, i64 16
  %v235 = load ptr, ptr %v234, align 8, !tbaa !3
  %v236 = getelementptr i8, ptr %env, i64 24
  %v237 = load ptr, ptr %v236, align 8, !tbaa !3
  %v238 = getelementptr i8, ptr %env, i64 32
  %v239 = load ptr, ptr %v238, align 8, !tbaa !3
  %v240 = getelementptr i8, ptr %env, i64 40
  %v241 = load ptr, ptr %v240, align 8, !tbaa !3
  %v242 = getelementptr i8, ptr %env, i64 48
  %v243 = load ptr, ptr %v242, align 8, !tbaa !3
  %v482 = call ptr @mlf.allocate.thunk(ptr @mlf.code.244, i64 1)
  %v483 = getelementptr i8, ptr %v482, i64 16
  %v484 = load ptr, ptr %v483, align 8, !tbaa !3
  %v485 = getelementptr i8, ptr %v484, i64 8
  store ptr %v241, ptr %v485, align 8, !tbaa !3
  %v4119 = call ptr @mlf_env_new(i64 6)
  %v4120 = getelementptr i8, ptr %v4119, i64 8
  store ptr %v233, ptr %v4120, align 8, !tbaa !3
  %v4121 = getelementptr i8, ptr %v4119, i64 16
  store ptr %v235, ptr %v4121, align 8, !tbaa !3
  %v4122 = getelementptr i8, ptr %v4119, i64 24
  store ptr %v237, ptr %v4122, align 8, !tbaa !3
  %v4123 = getelementptr i8, ptr %v4119, i64 32
  store ptr %v239, ptr %v4123, align 8, !tbaa !3
  %v4124 = getelementptr i8, ptr %v4119, i64 40
  store ptr %v241, ptr %v4124, align 8, !tbaa !3
  %v4125 = getelementptr i8, ptr %v4119, i64 48
  store ptr %v243, ptr %v4125, align 8, !tbaa !3
  %v4126 = call ptr @mlf_closure(ptr @mlf.code.486, ptr %v4119)
  %v4127 = call ptr @mlf_prim2(i64 1, ptr %v482, ptr %v4126)
  ret ptr %v4127
}

define private ptr @mlf.code.208(ptr %env, ptr %arg) {
entry:
  %v209 = getelementptr i8, ptr %env, i64 8
  %v210 = load ptr, ptr %v209, align 8, !tbaa !3
  %v211 = getelementptr i8, ptr %env, i64 16
  %v212 = load ptr, ptr %v211, align 8, !tbaa !3
  %v213 = getelementptr i8, ptr %env, i64 24
  %v214 = load ptr, ptr %v213, align 8, !tbaa !3
  %v215 = getelementptr i8, ptr %env, i64 32
  %v216 = load ptr, ptr %v215, align 8, !tbaa !3
  %v217 = getelementptr i8, ptr %env, i64 40
  %v218 = load ptr, ptr %v217, align 8, !tbaa !3
  %v219 = getelementptr i8, ptr %env, i64 48
  %v220 = load ptr, ptr %v219, align 8, !tbaa !3
  %v227 = call ptr @mlf.allocate.thunk(ptr @mlf.code.221, i64 1)
  %v228 = getelementptr i8, ptr %v227, i64 16
  %v229 = load ptr, ptr %v228, align 8, !tbaa !3
  %v230 = getelementptr i8, ptr %v229, i64 8
  store ptr %v220, ptr %v230, align 8, !tbaa !3
  %v4128 = call ptr @mlf_env_new(i64 6)
  %v4129 = getelementptr i8, ptr %v4128, i64 8
  store ptr %v210, ptr %v4129, align 8, !tbaa !3
  %v4130 = getelementptr i8, ptr %v4128, i64 16
  store ptr %v212, ptr %v4130, align 8, !tbaa !3
  %v4131 = getelementptr i8, ptr %v4128, i64 24
  store ptr %v214, ptr %v4131, align 8, !tbaa !3
  %v4132 = getelementptr i8, ptr %v4128, i64 32
  store ptr %v216, ptr %v4132, align 8, !tbaa !3
  %v4133 = getelementptr i8, ptr %v4128, i64 40
  store ptr %v218, ptr %v4133, align 8, !tbaa !3
  %v4134 = getelementptr i8, ptr %v4128, i64 48
  store ptr %v220, ptr %v4134, align 8, !tbaa !3
  %v4135 = call ptr @mlf_closure(ptr @mlf.code.231, ptr %v4128)
  %v4136 = call ptr @mlf_prim2(i64 1, ptr %v227, ptr %v4135)
  ret ptr %v4136
}

define private ptr @mlf.code.185(ptr %env, ptr %arg) {
entry:
  %v186 = getelementptr i8, ptr %env, i64 8
  %v187 = load ptr, ptr %v186, align 8, !tbaa !3
  %v188 = getelementptr i8, ptr %env, i64 16
  %v189 = load ptr, ptr %v188, align 8, !tbaa !3
  %v190 = getelementptr i8, ptr %env, i64 24
  %v191 = load ptr, ptr %v190, align 8, !tbaa !3
  %v192 = getelementptr i8, ptr %env, i64 32
  %v193 = load ptr, ptr %v192, align 8, !tbaa !3
  %v194 = getelementptr i8, ptr %env, i64 40
  %v195 = load ptr, ptr %v194, align 8, !tbaa !3
  %v196 = getelementptr i8, ptr %env, i64 48
  %v197 = load ptr, ptr %v196, align 8, !tbaa !3
  %v204 = call ptr @mlf.allocate.thunk(ptr @mlf.code.198, i64 1)
  %v205 = getelementptr i8, ptr %v204, i64 16
  %v206 = load ptr, ptr %v205, align 8, !tbaa !3
  %v207 = getelementptr i8, ptr %v206, i64 8
  store ptr %v197, ptr %v207, align 8, !tbaa !3
  %v4137 = call ptr @mlf_env_new(i64 6)
  %v4138 = getelementptr i8, ptr %v4137, i64 8
  store ptr %v187, ptr %v4138, align 8, !tbaa !3
  %v4139 = getelementptr i8, ptr %v4137, i64 16
  store ptr %v189, ptr %v4139, align 8, !tbaa !3
  %v4140 = getelementptr i8, ptr %v4137, i64 24
  store ptr %v191, ptr %v4140, align 8, !tbaa !3
  %v4141 = getelementptr i8, ptr %v4137, i64 32
  store ptr %v193, ptr %v4141, align 8, !tbaa !3
  %v4142 = getelementptr i8, ptr %v4137, i64 40
  store ptr %v195, ptr %v4142, align 8, !tbaa !3
  %v4143 = getelementptr i8, ptr %v4137, i64 48
  store ptr %v197, ptr %v4143, align 8, !tbaa !3
  %v4144 = call ptr @mlf_closure(ptr @mlf.code.208, ptr %v4137)
  %v4145 = call ptr @mlf_prim2(i64 1, ptr %v204, ptr %v4144)
  ret ptr %v4145
}

define private ptr @mlf.code.162(ptr %env, ptr %arg) {
entry:
  %v163 = getelementptr i8, ptr %env, i64 8
  %v164 = load ptr, ptr %v163, align 8, !tbaa !3
  %v165 = getelementptr i8, ptr %env, i64 16
  %v166 = load ptr, ptr %v165, align 8, !tbaa !3
  %v167 = getelementptr i8, ptr %env, i64 24
  %v168 = load ptr, ptr %v167, align 8, !tbaa !3
  %v169 = getelementptr i8, ptr %env, i64 32
  %v170 = load ptr, ptr %v169, align 8, !tbaa !3
  %v171 = getelementptr i8, ptr %env, i64 40
  %v172 = load ptr, ptr %v171, align 8, !tbaa !3
  %v173 = getelementptr i8, ptr %env, i64 48
  %v174 = load ptr, ptr %v173, align 8, !tbaa !3
  %v181 = call ptr @mlf.allocate.thunk(ptr @mlf.code.175, i64 1)
  %v182 = getelementptr i8, ptr %v181, i64 16
  %v183 = load ptr, ptr %v182, align 8, !tbaa !3
  %v184 = getelementptr i8, ptr %v183, i64 8
  store ptr %v174, ptr %v184, align 8, !tbaa !3
  %v4146 = call ptr @mlf_env_new(i64 6)
  %v4147 = getelementptr i8, ptr %v4146, i64 8
  store ptr %v164, ptr %v4147, align 8, !tbaa !3
  %v4148 = getelementptr i8, ptr %v4146, i64 16
  store ptr %v166, ptr %v4148, align 8, !tbaa !3
  %v4149 = getelementptr i8, ptr %v4146, i64 24
  store ptr %v168, ptr %v4149, align 8, !tbaa !3
  %v4150 = getelementptr i8, ptr %v4146, i64 32
  store ptr %v170, ptr %v4150, align 8, !tbaa !3
  %v4151 = getelementptr i8, ptr %v4146, i64 40
  store ptr %v172, ptr %v4151, align 8, !tbaa !3
  %v4152 = getelementptr i8, ptr %v4146, i64 48
  store ptr %v174, ptr %v4152, align 8, !tbaa !3
  %v4153 = call ptr @mlf_closure(ptr @mlf.code.185, ptr %v4146)
  %v4154 = call ptr @mlf_prim2(i64 1, ptr %v181, ptr %v4153)
  ret ptr %v4154
}

define private ptr @mlf.code.141(ptr %env, ptr %arg) {
entry:
  %v142 = getelementptr i8, ptr %env, i64 8
  %v143 = load ptr, ptr %v142, align 8, !tbaa !3
  %v144 = getelementptr i8, ptr %env, i64 16
  %v145 = load ptr, ptr %v144, align 8, !tbaa !3
  %v146 = getelementptr i8, ptr %env, i64 24
  %v147 = load ptr, ptr %v146, align 8, !tbaa !3
  %v148 = getelementptr i8, ptr %env, i64 32
  %v149 = load ptr, ptr %v148, align 8, !tbaa !3
  %v150 = getelementptr i8, ptr %env, i64 40
  %v151 = load ptr, ptr %v150, align 8, !tbaa !3
  %v158 = call ptr @mlf.allocate.thunk(ptr @mlf.code.152, i64 1)
  %v159 = getelementptr i8, ptr %v158, i64 16
  %v160 = load ptr, ptr %v159, align 8, !tbaa !3
  %v161 = getelementptr i8, ptr %v160, i64 8
  store ptr %arg, ptr %v161, align 8, !tbaa !3
  %v4155 = call ptr @mlf_env_new(i64 6)
  %v4156 = getelementptr i8, ptr %v4155, i64 8
  store ptr %v143, ptr %v4156, align 8, !tbaa !3
  %v4157 = getelementptr i8, ptr %v4155, i64 16
  store ptr %v145, ptr %v4157, align 8, !tbaa !3
  %v4158 = getelementptr i8, ptr %v4155, i64 24
  store ptr %v147, ptr %v4158, align 8, !tbaa !3
  %v4159 = getelementptr i8, ptr %v4155, i64 32
  store ptr %v149, ptr %v4159, align 8, !tbaa !3
  %v4160 = getelementptr i8, ptr %v4155, i64 40
  store ptr %v151, ptr %v4160, align 8, !tbaa !3
  %v4161 = getelementptr i8, ptr %v4155, i64 48
  store ptr %arg, ptr %v4161, align 8, !tbaa !3
  %v4162 = call ptr @mlf_closure(ptr @mlf.code.162, ptr %v4155)
  %v4163 = call ptr @mlf_prim2(i64 1, ptr %v158, ptr %v4162)
  ret ptr %v4163
}

define private ptr @mlf.code.126(ptr %env, ptr %arg) {
entry:
  %v127 = getelementptr i8, ptr %env, i64 8
  %v128 = load ptr, ptr %v127, align 8, !tbaa !3
  %v129 = getelementptr i8, ptr %env, i64 16
  %v130 = load ptr, ptr %v129, align 8, !tbaa !3
  %v131 = getelementptr i8, ptr %env, i64 24
  %v132 = load ptr, ptr %v131, align 8, !tbaa !3
  %v133 = getelementptr i8, ptr %env, i64 32
  %v134 = load ptr, ptr %v133, align 8, !tbaa !3
  %v135 = getelementptr i8, ptr %env, i64 40
  %v136 = load ptr, ptr %v135, align 8, !tbaa !3
  %v140 = call ptr @mlf_thunk(ptr @mlf.code.137, ptr null)
  %v4164 = call ptr @mlf_env_new(i64 5)
  %v4165 = getelementptr i8, ptr %v4164, i64 8
  store ptr %v128, ptr %v4165, align 8, !tbaa !3
  %v4166 = getelementptr i8, ptr %v4164, i64 16
  store ptr %v130, ptr %v4166, align 8, !tbaa !3
  %v4167 = getelementptr i8, ptr %v4164, i64 24
  store ptr %v132, ptr %v4167, align 8, !tbaa !3
  %v4168 = getelementptr i8, ptr %v4164, i64 32
  store ptr %v134, ptr %v4168, align 8, !tbaa !3
  %v4169 = getelementptr i8, ptr %v4164, i64 40
  store ptr %v136, ptr %v4169, align 8, !tbaa !3
  %v4170 = call ptr @mlf_closure(ptr @mlf.code.141, ptr %v4164)
  %v4171 = call ptr @mlf_prim2(i64 1, ptr %v140, ptr %v4170)
  ret ptr %v4171
}

define private ptr @mlf.code.105(ptr %env, ptr %arg) {
entry:
  %v106 = getelementptr i8, ptr %env, i64 8
  %v107 = load ptr, ptr %v106, align 8, !tbaa !3
  %v108 = getelementptr i8, ptr %env, i64 16
  %v109 = load ptr, ptr %v108, align 8, !tbaa !3
  %v110 = getelementptr i8, ptr %env, i64 24
  %v111 = load ptr, ptr %v110, align 8, !tbaa !3
  %v112 = getelementptr i8, ptr %env, i64 32
  %v113 = load ptr, ptr %v112, align 8, !tbaa !3
  %v114 = getelementptr i8, ptr %env, i64 40
  %v115 = load ptr, ptr %v114, align 8, !tbaa !3
  %v122 = call ptr @mlf.allocate.thunk(ptr @mlf.code.116, i64 1)
  %v123 = getelementptr i8, ptr %v122, i64 16
  %v124 = load ptr, ptr %v123, align 8, !tbaa !3
  %v125 = getelementptr i8, ptr %v124, i64 8
  store ptr %v115, ptr %v125, align 8, !tbaa !3
  %v4172 = call ptr @mlf_env_new(i64 5)
  %v4173 = getelementptr i8, ptr %v4172, i64 8
  store ptr %v107, ptr %v4173, align 8, !tbaa !3
  %v4174 = getelementptr i8, ptr %v4172, i64 16
  store ptr %v109, ptr %v4174, align 8, !tbaa !3
  %v4175 = getelementptr i8, ptr %v4172, i64 24
  store ptr %v111, ptr %v4175, align 8, !tbaa !3
  %v4176 = getelementptr i8, ptr %v4172, i64 32
  store ptr %v113, ptr %v4176, align 8, !tbaa !3
  %v4177 = getelementptr i8, ptr %v4172, i64 40
  store ptr %v115, ptr %v4177, align 8, !tbaa !3
  %v4178 = call ptr @mlf_closure(ptr @mlf.code.126, ptr %v4172)
  %v4179 = call ptr @mlf_prim2(i64 1, ptr %v122, ptr %v4178)
  ret ptr %v4179
}

define private ptr @mlf.code.84(ptr %env, ptr %arg) {
entry:
  %v85 = getelementptr i8, ptr %env, i64 8
  %v86 = load ptr, ptr %v85, align 8, !tbaa !3
  %v87 = getelementptr i8, ptr %env, i64 16
  %v88 = load ptr, ptr %v87, align 8, !tbaa !3
  %v89 = getelementptr i8, ptr %env, i64 24
  %v90 = load ptr, ptr %v89, align 8, !tbaa !3
  %v91 = getelementptr i8, ptr %env, i64 32
  %v92 = load ptr, ptr %v91, align 8, !tbaa !3
  %v93 = getelementptr i8, ptr %env, i64 40
  %v94 = load ptr, ptr %v93, align 8, !tbaa !3
  %v101 = call ptr @mlf.allocate.thunk(ptr @mlf.code.95, i64 1)
  %v102 = getelementptr i8, ptr %v101, i64 16
  %v103 = load ptr, ptr %v102, align 8, !tbaa !3
  %v104 = getelementptr i8, ptr %v103, i64 8
  store ptr %v94, ptr %v104, align 8, !tbaa !3
  %v4180 = call ptr @mlf_env_new(i64 5)
  %v4181 = getelementptr i8, ptr %v4180, i64 8
  store ptr %v86, ptr %v4181, align 8, !tbaa !3
  %v4182 = getelementptr i8, ptr %v4180, i64 16
  store ptr %v88, ptr %v4182, align 8, !tbaa !3
  %v4183 = getelementptr i8, ptr %v4180, i64 24
  store ptr %v90, ptr %v4183, align 8, !tbaa !3
  %v4184 = getelementptr i8, ptr %v4180, i64 32
  store ptr %v92, ptr %v4184, align 8, !tbaa !3
  %v4185 = getelementptr i8, ptr %v4180, i64 40
  store ptr %v94, ptr %v4185, align 8, !tbaa !3
  %v4186 = call ptr @mlf_closure(ptr @mlf.code.105, ptr %v4180)
  %v4187 = call ptr @mlf_prim2(i64 1, ptr %v101, ptr %v4186)
  ret ptr %v4187
}

define private ptr @mlf.code.63(ptr %env, ptr %arg) {
entry:
  %v64 = getelementptr i8, ptr %env, i64 8
  %v65 = load ptr, ptr %v64, align 8, !tbaa !3
  %v66 = getelementptr i8, ptr %env, i64 16
  %v67 = load ptr, ptr %v66, align 8, !tbaa !3
  %v68 = getelementptr i8, ptr %env, i64 24
  %v69 = load ptr, ptr %v68, align 8, !tbaa !3
  %v70 = getelementptr i8, ptr %env, i64 32
  %v71 = load ptr, ptr %v70, align 8, !tbaa !3
  %v72 = getelementptr i8, ptr %env, i64 40
  %v73 = load ptr, ptr %v72, align 8, !tbaa !3
  %v80 = call ptr @mlf.allocate.thunk(ptr @mlf.code.74, i64 1)
  %v81 = getelementptr i8, ptr %v80, i64 16
  %v82 = load ptr, ptr %v81, align 8, !tbaa !3
  %v83 = getelementptr i8, ptr %v82, i64 8
  store ptr %v73, ptr %v83, align 8, !tbaa !3
  %v4188 = call ptr @mlf_env_new(i64 5)
  %v4189 = getelementptr i8, ptr %v4188, i64 8
  store ptr %v65, ptr %v4189, align 8, !tbaa !3
  %v4190 = getelementptr i8, ptr %v4188, i64 16
  store ptr %v67, ptr %v4190, align 8, !tbaa !3
  %v4191 = getelementptr i8, ptr %v4188, i64 24
  store ptr %v69, ptr %v4191, align 8, !tbaa !3
  %v4192 = getelementptr i8, ptr %v4188, i64 32
  store ptr %v71, ptr %v4192, align 8, !tbaa !3
  %v4193 = getelementptr i8, ptr %v4188, i64 40
  store ptr %v73, ptr %v4193, align 8, !tbaa !3
  %v4194 = call ptr @mlf_closure(ptr @mlf.code.84, ptr %v4188)
  %v4195 = call ptr @mlf_prim2(i64 1, ptr %v80, ptr %v4194)
  ret ptr %v4195
}

define private ptr @mlf.code.44(ptr %env, ptr %arg) {
entry:
  %v45 = getelementptr i8, ptr %env, i64 8
  %v46 = load ptr, ptr %v45, align 8, !tbaa !3
  %v47 = getelementptr i8, ptr %env, i64 16
  %v48 = load ptr, ptr %v47, align 8, !tbaa !3
  %v49 = getelementptr i8, ptr %env, i64 24
  %v50 = load ptr, ptr %v49, align 8, !tbaa !3
  %v51 = getelementptr i8, ptr %env, i64 32
  %v52 = load ptr, ptr %v51, align 8, !tbaa !3
  %v59 = call ptr @mlf.allocate.thunk(ptr @mlf.code.53, i64 1)
  %v60 = getelementptr i8, ptr %v59, i64 16
  %v61 = load ptr, ptr %v60, align 8, !tbaa !3
  %v62 = getelementptr i8, ptr %v61, i64 8
  store ptr %arg, ptr %v62, align 8, !tbaa !3
  %v4196 = call ptr @mlf_env_new(i64 5)
  %v4197 = getelementptr i8, ptr %v4196, i64 8
  store ptr %v46, ptr %v4197, align 8, !tbaa !3
  %v4198 = getelementptr i8, ptr %v4196, i64 16
  store ptr %v48, ptr %v4198, align 8, !tbaa !3
  %v4199 = getelementptr i8, ptr %v4196, i64 24
  store ptr %v50, ptr %v4199, align 8, !tbaa !3
  %v4200 = getelementptr i8, ptr %v4196, i64 32
  store ptr %v52, ptr %v4200, align 8, !tbaa !3
  %v4201 = getelementptr i8, ptr %v4196, i64 40
  store ptr %arg, ptr %v4201, align 8, !tbaa !3
  %v4202 = call ptr @mlf_closure(ptr @mlf.code.63, ptr %v4196)
  %v4203 = call ptr @mlf_prim2(i64 1, ptr %v59, ptr %v4202)
  ret ptr %v4203
}

define private ptr @mlf.code.33(ptr %env, ptr %arg) {
entry:
  %v34 = getelementptr i8, ptr %env, i64 8
  %v35 = load ptr, ptr %v34, align 8, !tbaa !3
  %v36 = getelementptr i8, ptr %env, i64 16
  %v37 = load ptr, ptr %v36, align 8, !tbaa !3
  %v38 = getelementptr i8, ptr %env, i64 24
  %v39 = load ptr, ptr %v38, align 8, !tbaa !3
  %v43 = call ptr @mlf_thunk(ptr @mlf.code.40, ptr null)
  %v4204 = call ptr @mlf_env_new(i64 4)
  %v4205 = getelementptr i8, ptr %v4204, i64 8
  store ptr %v35, ptr %v4205, align 8, !tbaa !3
  %v4206 = getelementptr i8, ptr %v4204, i64 16
  store ptr %v37, ptr %v4206, align 8, !tbaa !3
  %v4207 = getelementptr i8, ptr %v4204, i64 24
  store ptr %v39, ptr %v4207, align 8, !tbaa !3
  %v4208 = getelementptr i8, ptr %v4204, i64 32
  store ptr %arg, ptr %v4208, align 8, !tbaa !3
  %v4209 = call ptr @mlf_closure(ptr @mlf.code.44, ptr %v4204)
  %v4210 = call ptr @mlf_prim2(i64 1, ptr %v43, ptr %v4209)
  ret ptr %v4210
}

define private ptr @mlf.code.24(ptr %env, ptr %arg) {
entry:
  %v25 = getelementptr i8, ptr %env, i64 8
  %v26 = load ptr, ptr %v25, align 8, !tbaa !3
  %v27 = getelementptr i8, ptr %env, i64 16
  %v28 = load ptr, ptr %v27, align 8, !tbaa !3
  %v32 = call ptr @mlf_thunk(ptr @mlf.code.29, ptr null)
  %v4211 = call ptr @mlf_env_new(i64 3)
  %v4212 = getelementptr i8, ptr %v4211, i64 8
  store ptr %v26, ptr %v4212, align 8, !tbaa !3
  %v4213 = getelementptr i8, ptr %v4211, i64 16
  store ptr %v28, ptr %v4213, align 8, !tbaa !3
  %v4214 = getelementptr i8, ptr %v4211, i64 24
  store ptr %arg, ptr %v4214, align 8, !tbaa !3
  %v4215 = call ptr @mlf_closure(ptr @mlf.code.33, ptr %v4211)
  %v4216 = call ptr @mlf_prim2(i64 1, ptr %v32, ptr %v4215)
  ret ptr %v4216
}

define private ptr @mlf.code.17(ptr %env, ptr %arg) {
entry:
  %v18 = getelementptr i8, ptr %env, i64 8
  %v19 = load ptr, ptr %v18, align 8, !tbaa !3
  %v23 = call ptr @mlf_thunk(ptr @mlf.code.20, ptr null)
  %v4217 = call ptr @mlf_env_new(i64 2)
  %v4218 = getelementptr i8, ptr %v4217, i64 8
  store ptr %v19, ptr %v4218, align 8, !tbaa !3
  %v4219 = getelementptr i8, ptr %v4217, i64 16
  store ptr %arg, ptr %v4219, align 8, !tbaa !3
  %v4220 = call ptr @mlf_closure(ptr @mlf.code.24, ptr %v4217)
  %v4221 = call ptr @mlf_prim2(i64 1, ptr %v23, ptr %v4220)
  ret ptr %v4221
}

define private ptr @mlf.code.2(ptr %env, ptr %arg) {
entry:
  %v9 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3, i64 1)
  %v10 = getelementptr i8, ptr %v9, i64 16
  %v11 = load ptr, ptr %v10, align 8, !tbaa !3
  %v12 = getelementptr i8, ptr %v11, i64 8
  store ptr %arg, ptr %v12, align 8, !tbaa !3
  %v16 = call ptr @mlf_thunk(ptr @mlf.code.13, ptr null)
  %v4222 = call ptr @mlf_env_new(i64 1)
  %v4223 = getelementptr i8, ptr %v4222, i64 8
  store ptr %v9, ptr %v4223, align 8, !tbaa !3
  %v4224 = call ptr @mlf_closure(ptr @mlf.code.17, ptr %v4222)
  %v4225 = call ptr @mlf_prim2(i64 1, ptr %v16, ptr %v4224)
  ret ptr %v4225
}

define private ptr @mlf.code.0(ptr %env, ptr %arg) {
entry:
  %v1 = call ptr @mlf_primitive(i64 4)
  %v4226 = call ptr @mlf_closure(ptr @mlf.code.2, ptr null)
  %v4227 = call ptr @mlf_prim2(i64 1, ptr %v1, ptr %v4226)
  ret ptr %v4227
}

declare void @mlf_require_compact_gc_abi()
define ptr @mlf_entry() {
  call void @mlf_require_compact_gc_abi()
  %root = call ptr @mlf.code.0(ptr null, ptr null)
  ret ptr %root
}
define i32 @main(i32 %argc, ptr %argv) {
  call void @mlf_set_args(i32 %argc, ptr %argv)
  %root = call ptr @mlf_entry()
  %status = call i32 @mlf_run(ptr %root, i64 1)
  ret i32 %status
}
