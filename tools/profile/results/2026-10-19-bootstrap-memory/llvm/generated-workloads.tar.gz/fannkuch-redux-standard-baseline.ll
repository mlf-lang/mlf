; Generated from independently checked xMLF.
source_filename = "emlf"

declare ptr @mlf_execute_st_lazy(ptr)
declare ptr @mlf_st_new_array(ptr, ptr)
declare ptr @mlf_st_read_array(ptr, ptr)
declare ptr @mlf_st_write_array(ptr, ptr, ptr)
declare ptr @mlf_st_length_array(ptr)
declare void @mlf_set_args(i32, ptr)
declare ptr @mlf_env_new(i64)
declare void @mlf_env_set(ptr, i64, ptr)
declare ptr @mlf_env_get(ptr, i64)
declare ptr @mlf_thunk(ptr, ptr)
declare ptr @mlf_closure(ptr, ptr)
declare ptr @mlf_application(ptr, ptr)
declare ptr @mlf_hole()
declare void @mlf_fill(ptr, ptr)
declare ptr @mlf_integer(ptr)
declare ptr @mlf_string(ptr, i64)
declare ptr @mlf_double(double)
declare double @llvm.sqrt.f64(double)
declare double @mlf_int_to_double(ptr)
declare ptr @mlf_read_int_table(ptr, ptr)
declare ptr @mlf_write_int_table(ptr, ptr, ptr)
declare ptr @mlf_add_int_table(ptr, ptr, ptr)
declare void @mlf_roots_enter(ptr, i64, ptr)
declare void @mlf_roots_leave(ptr)
declare void @mlf_gc_check(i64, ptr)
declare ptr @mlf_get_byte_line()
declare ptr @mlf_new_array(i64, ptr, ptr)
declare ptr @mlf_bytes_from_string(ptr)
declare ptr @mlf_put_bytes(ptr, ptr, ptr)
declare ptr @mlf_new_int_table()
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare i8 @mlf_byte(ptr)
declare ptr @mlf_peek(ptr)
declare ptr @mlf_native_io(ptr, ptr)
declare void @mlf_bounds_failure() noreturn
declare ptr @mlf_primitive(i64)
declare ptr @mlf_prim1(i64, ptr)
declare ptr @mlf_prim2(i64, ptr, ptr)
declare i64 @mlf_truth(ptr)
declare ptr @mlf_prim3(i64, ptr, ptr, ptr)
declare ptr @mlf_force(ptr)
declare ptr @mlf_add_int(ptr, ptr)
declare ptr @mlf_sub_int(ptr, ptr)
declare ptr @mlf_eq_int(ptr, ptr)
declare ptr @mlf_lt_int(ptr, ptr)
declare ptr @mlf_constructor(i64, i64)
declare ptr @mlf_constructor1(i64, ptr)
declare ptr @mlf_constructor2(i64, ptr, ptr)
declare ptr @mlf_constructor_fields(i64, ptr)
declare ptr @mlf_constructor_new(i64, i64)
declare ptr @mlf_field(ptr, i64)
declare void @mlf_match_failure() noreturn
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare i32 @mlf_run(ptr, i64)

!0 = !{!"MLF storage"}
!1 = !{!"managed object", !0}
!2 = !{!"array cells", !0}
!3 = !{!1, !1, i64 0}
!4 = !{!2, !2, i64 0}
@mlf.bytes.2052 = private unnamed_addr constant [13 x i8] c"\50\66\61\6e\6e\6b\75\63\68\65\6e\28\00", align 1
@mlf.bytes.2056 = private unnamed_addr constant [5 x i8] c"\29\20\3d\20\00", align 1
define private ptr @mlf.code.3(ptr %env, ptr %arg) {
entry:
  %v4 = getelementptr i8, ptr %env, i64 24
  %v5 = load ptr, ptr %v4, align 8, !tbaa !3
  %v6 = call ptr @mlf_force(ptr %v5)
  %v7 = call ptr @mlf_prim1(i64 17, ptr %v6)
  ret ptr %v7
}

define private ptr @mlf.code.11(ptr %env, ptr %arg) {
entry:
  %v12 = getelementptr i8, ptr %env, i64 24
  %v13 = load ptr, ptr %v12, align 8, !tbaa !3
  %v14 = call ptr @mlf_prim2(i64 27, ptr %v13, ptr inttoptr (i64 1 to ptr))
  ret ptr %v14
}

define private ptr @mlf.code.21(ptr %env, ptr %arg) {
entry:
  %v22 = getelementptr i8, ptr %env, i64 24
  %v23 = load ptr, ptr %v22, align 8, !tbaa !3
  %v24 = call ptr @mlf_prim2(i64 27, ptr %v23, ptr inttoptr (i64 1 to ptr))
  ret ptr %v24
}

define private ptr @mlf.code.33(ptr %env, ptr %arg) {
entry:
  %v34 = getelementptr i8, ptr %env, i64 24
  %v35 = load ptr, ptr %v34, align 8, !tbaa !3
  %v36 = call ptr @mlf_prim2(i64 27, ptr %v35, ptr inttoptr (i64 1 to ptr))
  ret ptr %v36
}

define private ptr @mlf.numeric.0.pii(ptr %a0, ptr %a1, ptr %a2) alwaysinline {
entry:
  %v85 = ptrtoint ptr %a2 to i64
  %v86 = ptrtoint ptr %a1 to i64
  %v87 = icmp eq i64 %v85, %v86
  %v88 = select i1 %v87, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v89 = icmp eq ptr %v88, inttoptr (i64 6 to ptr)
  br i1 %v89, label %tail.yes.90, label %tail.no.91
tail.yes.90:
  ret ptr inttoptr (i64 4 to ptr)
tail.no.91:
  %v92 = ptrtoint ptr %a2 to i64
  %v93 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v94 = sub i64 %v93, 1
  %v95 = add nsw i64 %v92, %v94
  %v96 = inttoptr i64 %v95 to ptr
  %v97 = getelementptr i8, ptr %a0, i64 24
  %v98 = load i64, ptr %v97, align 8, !tbaa !3
  %v99 = getelementptr i8, ptr %a0, i64 32
  %v100 = load ptr, ptr %v99, align 8, !tbaa !3
  %v101 = ptrtoint ptr %a2 to i64
  %v102 = ashr i64 %v101, 1
  %v103 = and i64 %v101, 1
  %v104 = icmp ne i64 %v103, 0
  %v105 = icmp ult i64 %v102, %v98
  %v106 = and i1 %v104, %v105
  br i1 %v106, label %array.valid.107, label %array.invalid.108
array.invalid.108:
  call void @mlf_bounds_failure()
  unreachable
array.valid.107:
  %v109 = getelementptr i64, ptr %v100, i64 %v102
  store ptr %v96, ptr %v109, align 8, !tbaa !4
  %v110 = ptrtoint ptr %a2 to i64
  %v111 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v112 = sub i64 %v111, 1
  %v113 = add nsw i64 %v110, %v112
  %v114 = inttoptr i64 %v113 to ptr
  %v115 = musttail call ptr @mlf.numeric.0(ptr %a0, ptr %a1, ptr %v114)
  ret ptr %v115
}

define private ptr @mlf.numeric.0(ptr %a0, ptr %a1, ptr %a2) alwaysinline {
entry:
  %v71 = ptrtoint ptr %a1 to i64
  %v72 = and i64 %v71, 1
  %v73 = icmp ne i64 %v72, 0
  %v74 = icmp ult i64 %v71, 4294967296
  %v75 = and i1 %v73, %v74
  %v76 = ptrtoint ptr %a2 to i64
  %v77 = and i64 %v76, 1
  %v78 = icmp ne i64 %v77, 0
  %v79 = icmp ult i64 %v76, 4294967296
  %v80 = and i1 %v78, %v79
  %v81 = and i1 true, %v75
  %v82 = and i1 %v81, %v80
  br i1 %v82, label %range.fast.83, label %range.general.84
range.fast.83:
  %v116 = musttail call ptr @mlf.numeric.0.pii(ptr %a0, ptr %a1, ptr %a2)
  ret ptr %v116
range.general.84:
  %v117 = ptrtoint ptr %a2 to i64
  %v118 = ptrtoint ptr %a1 to i64
  %v119 = and i64 %v117, %v118
  %v120 = and i64 %v119, 1
  %v121 = icmp ne i64 %v120, 0
  br i1 %v121, label %yes.122, label %no.123
yes.122:
  %v125 = icmp eq i64 %v117, %v118
  %v126 = select i1 %v125, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.124
no.123:
  %v127 = call ptr @mlf_eq_int(ptr %a2, ptr %a1)
  br label %join.124
join.124:
  %v128 = phi ptr [ %v126, %yes.122 ], [ %v127, %no.123 ]
  %v129 = icmp eq ptr %v128, inttoptr (i64 6 to ptr)
  br i1 %v129, label %tail.yes.130, label %tail.no.131
tail.yes.130:
  ret ptr inttoptr (i64 4 to ptr)
tail.no.131:
  %v132 = ptrtoint ptr %a2 to i64
  %v133 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v134 = and i64 %v132, %v133
  %v135 = and i64 %v134, 1
  %v136 = icmp ne i64 %v135, 0
  br i1 %v136, label %yes.137, label %no.138
yes.137:
  %v140 = sub i64 %v133, 1
  %v141 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v132, i64 %v140)
  %v142 = extractvalue { i64, i1 } %v141, 0
  %v143 = extractvalue { i64, i1 } %v141, 1
  br i1 %v143, label %yes.144, label %no.145
yes.144:
  %v147 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 3 to ptr))
  br label %join.146
no.145:
  %v148 = inttoptr i64 %v142 to ptr
  br label %join.146
join.146:
  %v149 = phi ptr [ %v147, %yes.144 ], [ %v148, %no.145 ]
  br label %join.139
no.138:
  %v150 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 3 to ptr))
  br label %join.139
join.139:
  %v151 = phi ptr [ %v149, %join.146 ], [ %v150, %no.138 ]
  %v152 = getelementptr i8, ptr %a0, i64 24
  %v153 = load i64, ptr %v152, align 8, !tbaa !3
  %v154 = getelementptr i8, ptr %a0, i64 32
  %v155 = load ptr, ptr %v154, align 8, !tbaa !3
  %v156 = ptrtoint ptr %a2 to i64
  %v157 = ashr i64 %v156, 1
  %v158 = and i64 %v156, 1
  %v159 = icmp ne i64 %v158, 0
  %v160 = icmp ult i64 %v157, %v153
  %v161 = and i1 %v159, %v160
  br i1 %v161, label %array.valid.162, label %array.invalid.163
array.invalid.163:
  call void @mlf_bounds_failure()
  unreachable
array.valid.162:
  %v164 = getelementptr i64, ptr %v155, i64 %v157
  store ptr %v151, ptr %v164, align 8, !tbaa !4
  %v165 = ptrtoint ptr %a2 to i64
  %v166 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v167 = sub i64 %v166, 1
  %v168 = add nsw i64 %v165, %v167
  %v169 = inttoptr i64 %v168 to ptr
  %v170 = musttail call ptr @mlf.numeric.0(ptr %a0, ptr %a1, ptr %v169)
  ret ptr %v170
}

define private ptr @mlf.code.184(ptr %env, ptr %arg) {
entry:
  %v185 = getelementptr i8, ptr %env, i64 24
  %v186 = load ptr, ptr %v185, align 8, !tbaa !3
  %v187 = call ptr @mlf_force(ptr %v186)
  %v188 = call ptr @mlf_prim2(i64 8, ptr %v187, ptr inttoptr (i64 3 to ptr))
  ret ptr %v188
}

define private ptr @mlf.code.179(ptr %env, ptr %arg) {
entry:
  %v180 = getelementptr i8, ptr %env, i64 24
  %v181 = load ptr, ptr %v180, align 8, !tbaa !3
  %v182 = getelementptr i8, ptr %env, i64 32
  %v183 = load ptr, ptr %v182, align 8, !tbaa !3
  %v189 = call ptr @mlf_env_new(i64 1)
  %v190 = getelementptr i8, ptr %v189, i64 24
  store ptr %v183, ptr %v190, align 8, !tbaa !3
  %v191 = call ptr @mlf_thunk(ptr @mlf.code.184, ptr %v189)
  %v192 = call ptr @mlf_prim3(i64 29, ptr %v181, ptr %v183, ptr %v191)
  ret ptr %v192
}

define private ptr @mlf.code.197(ptr %env, ptr %arg) {
entry:
  %v198 = getelementptr i8, ptr %env, i64 24
  %v199 = load ptr, ptr %v198, align 8, !tbaa !3
  %v200 = getelementptr i8, ptr %env, i64 32
  %v201 = load ptr, ptr %v200, align 8, !tbaa !3
  %v202 = getelementptr i8, ptr %env, i64 40
  %v203 = load ptr, ptr %v202, align 8, !tbaa !3
  %v204 = call ptr @mlf_force(ptr %v201)
  %v205 = call ptr @mlf_force(ptr %v203)
  %v206 = call ptr @mlf_prim2(i64 8, ptr %v205, ptr inttoptr (i64 3 to ptr))
  %v207 = call ptr @mlf_env_new(i64 3)
  %v208 = getelementptr i8, ptr %v207, i64 24
  store ptr %v199, ptr %v208, align 8, !tbaa !3
  %v209 = getelementptr i8, ptr %v207, i64 32
  store ptr %v204, ptr %v209, align 8, !tbaa !3
  %v210 = getelementptr i8, ptr %v207, i64 40
  store ptr %v206, ptr %v210, align 8, !tbaa !3
  %v211 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.52, ptr %v207)
  ret ptr %v211
}

define private ptr @mlf.worker.0(ptr %a0, ptr %a1, ptr %a2) {
entry:
  %v173 = call ptr @mlf_prim2(i64 10, ptr %a2, ptr %a1)
  %v174 = icmp eq ptr %v173, inttoptr (i64 6 to ptr)
  br i1 %v174, label %yes.175, label %no.176
yes.175:
  %v178 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.177
no.176:
  %v193 = call ptr @mlf_env_new(i64 2)
  %v194 = getelementptr i8, ptr %v193, i64 24
  store ptr %a0, ptr %v194, align 8, !tbaa !3
  %v195 = getelementptr i8, ptr %v193, i64 32
  store ptr %a2, ptr %v195, align 8, !tbaa !3
  %v196 = call ptr @mlf_thunk(ptr @mlf.code.179, ptr %v193)
  %v212 = call ptr @mlf_env_new(i64 3)
  %v213 = getelementptr i8, ptr %v212, i64 24
  store ptr %a0, ptr %v213, align 8, !tbaa !3
  %v214 = getelementptr i8, ptr %v212, i64 32
  store ptr %a1, ptr %v214, align 8, !tbaa !3
  %v215 = getelementptr i8, ptr %v212, i64 40
  store ptr %a2, ptr %v215, align 8, !tbaa !3
  %v216 = call ptr @mlf_closure(ptr @mlf.code.197, ptr %v212)
  %v217 = call ptr @mlf_prim2(i64 1, ptr %v196, ptr %v216)
  br label %join.177
join.177:
  %v218 = phi ptr [ %v178, %yes.175 ], [ %v217, %no.176 ]
  ret ptr %v218
}

define private ptr @mlf.numeric.entry.52(ptr %env, ptr %arg) {
entry:
  %v53 = getelementptr i8, ptr %env, i64 24
  %v54 = load ptr, ptr %v53, align 8, !tbaa !3
  %v55 = getelementptr i8, ptr %env, i64 32
  %v56 = load ptr, ptr %v55, align 8, !tbaa !3
  %v57 = getelementptr i8, ptr %env, i64 40
  %v58 = load ptr, ptr %v57, align 8, !tbaa !3
  %v59 = call ptr @mlf_peek(ptr %v54)
  %v60 = call ptr @mlf_peek(ptr %v56)
  %v61 = call ptr @mlf_peek(ptr %v58)
  %v62 = icmp ne ptr %v59, null
  %v63 = icmp ne ptr %v60, null
  %v64 = icmp ne ptr %v61, null
  %v65 = and i1 true, %v62
  %v66 = and i1 %v65, %v63
  %v67 = and i1 %v66, %v64
  br i1 %v67, label %yes.68, label %no.69
yes.68:
  %v171 = call ptr @mlf.numeric.0(ptr %v59, ptr %v60, ptr %v61)
  %v172 = call ptr @mlf_prim1(i64 0, ptr %v171)
  br label %join.70
no.69:
  %v219 = call ptr @mlf_force(ptr %v56)
  %v220 = call ptr @mlf_force(ptr %v58)
  %v221 = call ptr @mlf.worker.0(ptr %v54, ptr %v219, ptr %v220)
  br label %join.70
join.70:
  %v222 = phi ptr [ %v172, %yes.68 ], [ %v221, %no.69 ]
  ret ptr %v222
}

define private ptr @mlf.code.47(ptr %env, ptr %arg) {
entry:
  %v48 = getelementptr i8, ptr %env, i64 24
  %v49 = load ptr, ptr %v48, align 8, !tbaa !3
  %v50 = getelementptr i8, ptr %env, i64 32
  %v51 = load ptr, ptr %v50, align 8, !tbaa !3
  %v223 = call ptr @mlf_force(ptr %v49)
  %v224 = call ptr @mlf_env_new(i64 3)
  %v225 = getelementptr i8, ptr %v224, i64 24
  store ptr %v51, ptr %v225, align 8, !tbaa !3
  %v226 = getelementptr i8, ptr %v224, i64 32
  store ptr %v223, ptr %v226, align 8, !tbaa !3
  %v227 = getelementptr i8, ptr %v224, i64 40
  store ptr inttoptr (i64 1 to ptr), ptr %v227, align 8, !tbaa !3
  %v228 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.52, ptr %v224)
  ret ptr %v228
}

define private ptr @mlf.numeric.5.ppii(ptr %a0, ptr %a1, ptr %a2, ptr %a3) alwaysinline {
entry:
  %v304 = ptrtoint ptr %a3 to i64
  %v305 = ptrtoint ptr %a2 to i64
  %v306 = icmp eq i64 %v304, %v305
  %v307 = select i1 %v306, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v308 = icmp eq ptr %v307, inttoptr (i64 6 to ptr)
  br i1 %v308, label %tail.yes.309, label %tail.no.310
tail.yes.309:
  ret ptr inttoptr (i64 4 to ptr)
tail.no.310:
  %v311 = getelementptr i8, ptr %a0, i64 24
  %v312 = load i64, ptr %v311, align 8, !tbaa !3
  %v313 = getelementptr i8, ptr %a0, i64 32
  %v314 = load ptr, ptr %v313, align 8, !tbaa !3
  %v315 = ptrtoint ptr %a3 to i64
  %v316 = ashr i64 %v315, 1
  %v317 = and i64 %v315, 1
  %v318 = icmp ne i64 %v317, 0
  %v319 = icmp ult i64 %v316, %v312
  %v320 = and i1 %v318, %v319
  br i1 %v320, label %array.valid.321, label %array.invalid.322
array.invalid.322:
  call void @mlf_bounds_failure()
  unreachable
array.valid.321:
  %v323 = getelementptr i64, ptr %v314, i64 %v316
  %v324 = load ptr, ptr %v323, align 8, !tbaa !4
  %v325 = getelementptr i8, ptr %a1, i64 24
  %v326 = load i64, ptr %v325, align 8, !tbaa !3
  %v327 = getelementptr i8, ptr %a1, i64 32
  %v328 = load ptr, ptr %v327, align 8, !tbaa !3
  %v329 = ptrtoint ptr %a3 to i64
  %v330 = ashr i64 %v329, 1
  %v331 = and i64 %v329, 1
  %v332 = icmp ne i64 %v331, 0
  %v333 = icmp ult i64 %v330, %v326
  %v334 = and i1 %v332, %v333
  br i1 %v334, label %array.valid.335, label %array.invalid.336
array.invalid.336:
  call void @mlf_bounds_failure()
  unreachable
array.valid.335:
  %v337 = getelementptr i64, ptr %v328, i64 %v330
  store ptr %v324, ptr %v337, align 8, !tbaa !4
  %v338 = ptrtoint ptr %a3 to i64
  %v339 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v340 = sub i64 %v339, 1
  %v341 = add nsw i64 %v338, %v340
  %v342 = inttoptr i64 %v341 to ptr
  %v343 = musttail call ptr @mlf.numeric.5(ptr %a0, ptr %a1, ptr %a2, ptr %v342)
  ret ptr %v343
}

define private ptr @mlf.numeric.5(ptr %a0, ptr %a1, ptr %a2, ptr %a3) alwaysinline {
entry:
  %v290 = ptrtoint ptr %a2 to i64
  %v291 = and i64 %v290, 1
  %v292 = icmp ne i64 %v291, 0
  %v293 = icmp ult i64 %v290, 4294967296
  %v294 = and i1 %v292, %v293
  %v295 = ptrtoint ptr %a3 to i64
  %v296 = and i64 %v295, 1
  %v297 = icmp ne i64 %v296, 0
  %v298 = icmp ult i64 %v295, 4294967296
  %v299 = and i1 %v297, %v298
  %v300 = and i1 true, %v294
  %v301 = and i1 %v300, %v299
  br i1 %v301, label %range.fast.302, label %range.general.303
range.fast.302:
  %v344 = musttail call ptr @mlf.numeric.5.ppii(ptr %a0, ptr %a1, ptr %a2, ptr %a3)
  ret ptr %v344
range.general.303:
  %v345 = ptrtoint ptr %a3 to i64
  %v346 = ptrtoint ptr %a2 to i64
  %v347 = and i64 %v345, %v346
  %v348 = and i64 %v347, 1
  %v349 = icmp ne i64 %v348, 0
  br i1 %v349, label %yes.350, label %no.351
yes.350:
  %v353 = icmp eq i64 %v345, %v346
  %v354 = select i1 %v353, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.352
no.351:
  %v355 = call ptr @mlf_eq_int(ptr %a3, ptr %a2)
  br label %join.352
join.352:
  %v356 = phi ptr [ %v354, %yes.350 ], [ %v355, %no.351 ]
  %v357 = icmp eq ptr %v356, inttoptr (i64 6 to ptr)
  br i1 %v357, label %tail.yes.358, label %tail.no.359
tail.yes.358:
  ret ptr inttoptr (i64 4 to ptr)
tail.no.359:
  %v360 = getelementptr i8, ptr %a0, i64 24
  %v361 = load i64, ptr %v360, align 8, !tbaa !3
  %v362 = getelementptr i8, ptr %a0, i64 32
  %v363 = load ptr, ptr %v362, align 8, !tbaa !3
  %v364 = ptrtoint ptr %a3 to i64
  %v365 = ashr i64 %v364, 1
  %v366 = and i64 %v364, 1
  %v367 = icmp ne i64 %v366, 0
  %v368 = icmp ult i64 %v365, %v361
  %v369 = and i1 %v367, %v368
  br i1 %v369, label %array.valid.370, label %array.invalid.371
array.invalid.371:
  call void @mlf_bounds_failure()
  unreachable
array.valid.370:
  %v372 = getelementptr i64, ptr %v363, i64 %v365
  %v373 = load ptr, ptr %v372, align 8, !tbaa !4
  %v374 = getelementptr i8, ptr %a1, i64 24
  %v375 = load i64, ptr %v374, align 8, !tbaa !3
  %v376 = getelementptr i8, ptr %a1, i64 32
  %v377 = load ptr, ptr %v376, align 8, !tbaa !3
  %v378 = ptrtoint ptr %a3 to i64
  %v379 = ashr i64 %v378, 1
  %v380 = and i64 %v378, 1
  %v381 = icmp ne i64 %v380, 0
  %v382 = icmp ult i64 %v379, %v375
  %v383 = and i1 %v381, %v382
  br i1 %v383, label %array.valid.384, label %array.invalid.385
array.invalid.385:
  call void @mlf_bounds_failure()
  unreachable
array.valid.384:
  %v386 = getelementptr i64, ptr %v377, i64 %v379
  store ptr %v373, ptr %v386, align 8, !tbaa !4
  %v387 = ptrtoint ptr %a3 to i64
  %v388 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v389 = sub i64 %v388, 1
  %v390 = add nsw i64 %v387, %v389
  %v391 = inttoptr i64 %v390 to ptr
  %v392 = musttail call ptr @mlf.numeric.5(ptr %a0, ptr %a1, ptr %a2, ptr %v391)
  ret ptr %v392
}

define private ptr @mlf.numeric.12.pii(ptr %a0, ptr %a1, ptr %a2) alwaysinline {
entry:
  %v457 = ptrtoint ptr %a1 to i64
  %v458 = ptrtoint ptr %a2 to i64
  %v459 = icmp slt i64 %v457, %v458
  %v460 = select i1 %v459, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v461 = icmp eq ptr %v460, inttoptr (i64 6 to ptr)
  br i1 %v461, label %tail.yes.462, label %tail.no.463
tail.yes.462:
  %v464 = getelementptr i8, ptr %a0, i64 24
  %v465 = load i64, ptr %v464, align 8, !tbaa !3
  %v466 = getelementptr i8, ptr %a0, i64 32
  %v467 = load ptr, ptr %v466, align 8, !tbaa !3
  %v468 = ptrtoint ptr %a1 to i64
  %v469 = ashr i64 %v468, 1
  %v470 = and i64 %v468, 1
  %v471 = icmp ne i64 %v470, 0
  %v472 = icmp ult i64 %v469, %v465
  %v473 = and i1 %v471, %v472
  br i1 %v473, label %array.valid.474, label %array.invalid.475
array.invalid.475:
  call void @mlf_bounds_failure()
  unreachable
array.valid.474:
  %v476 = getelementptr i64, ptr %v467, i64 %v469
  %v477 = load ptr, ptr %v476, align 8, !tbaa !4
  %v478 = ptrtoint ptr %a2 to i64
  %v479 = ashr i64 %v478, 1
  %v480 = and i64 %v478, 1
  %v481 = icmp ne i64 %v480, 0
  %v482 = icmp ult i64 %v479, %v465
  %v483 = and i1 %v481, %v482
  br i1 %v483, label %array.valid.484, label %array.invalid.485
array.invalid.485:
  call void @mlf_bounds_failure()
  unreachable
array.valid.484:
  %v486 = getelementptr i64, ptr %v467, i64 %v479
  %v487 = load ptr, ptr %v486, align 8, !tbaa !4
  %v488 = ptrtoint ptr %a1 to i64
  %v489 = ashr i64 %v488, 1
  %v490 = and i64 %v488, 1
  %v491 = icmp ne i64 %v490, 0
  %v492 = icmp ult i64 %v489, %v465
  %v493 = and i1 %v491, %v492
  br i1 %v493, label %array.valid.494, label %array.invalid.495
array.invalid.495:
  call void @mlf_bounds_failure()
  unreachable
array.valid.494:
  %v496 = getelementptr i64, ptr %v467, i64 %v489
  store ptr %v487, ptr %v496, align 8, !tbaa !4
  %v497 = ptrtoint ptr %a2 to i64
  %v498 = ashr i64 %v497, 1
  %v499 = and i64 %v497, 1
  %v500 = icmp ne i64 %v499, 0
  %v501 = icmp ult i64 %v498, %v465
  %v502 = and i1 %v500, %v501
  br i1 %v502, label %array.valid.503, label %array.invalid.504
array.invalid.504:
  call void @mlf_bounds_failure()
  unreachable
array.valid.503:
  %v505 = getelementptr i64, ptr %v467, i64 %v498
  store ptr %v477, ptr %v505, align 8, !tbaa !4
  %v506 = ptrtoint ptr %a1 to i64
  %v507 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v508 = sub i64 %v507, 1
  %v509 = add nsw i64 %v506, %v508
  %v510 = inttoptr i64 %v509 to ptr
  %v511 = ptrtoint ptr %a2 to i64
  %v512 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v513 = sub i64 %v512, 1
  %v514 = sub nsw i64 %v511, %v513
  %v515 = inttoptr i64 %v514 to ptr
  %v516 = musttail call ptr @mlf.numeric.12.pii(ptr %a0, ptr %v510, ptr %v515)
  ret ptr %v516
tail.no.463:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.numeric.12(ptr %a0, ptr %a1, ptr %a2) alwaysinline {
entry:
  %v443 = ptrtoint ptr %a1 to i64
  %v444 = and i64 %v443, 1
  %v445 = icmp ne i64 %v444, 0
  %v446 = icmp ult i64 %v443, 4294967296
  %v447 = and i1 %v445, %v446
  %v448 = ptrtoint ptr %a2 to i64
  %v449 = and i64 %v448, 1
  %v450 = icmp ne i64 %v449, 0
  %v451 = icmp ult i64 %v448, 4294967296
  %v452 = and i1 %v450, %v451
  %v453 = and i1 true, %v447
  %v454 = and i1 %v453, %v452
  br i1 %v454, label %range.fast.455, label %range.general.456
range.fast.455:
  %v517 = musttail call ptr @mlf.numeric.12.pii(ptr %a0, ptr %a1, ptr %a2)
  ret ptr %v517
range.general.456:
  %v518 = ptrtoint ptr %a1 to i64
  %v519 = ptrtoint ptr %a2 to i64
  %v520 = and i64 %v518, %v519
  %v521 = and i64 %v520, 1
  %v522 = icmp ne i64 %v521, 0
  br i1 %v522, label %yes.523, label %no.524
yes.523:
  %v526 = icmp slt i64 %v518, %v519
  %v527 = select i1 %v526, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.525
no.524:
  %v528 = call ptr @mlf_lt_int(ptr %a1, ptr %a2)
  br label %join.525
join.525:
  %v529 = phi ptr [ %v527, %yes.523 ], [ %v528, %no.524 ]
  %v530 = icmp eq ptr %v529, inttoptr (i64 6 to ptr)
  br i1 %v530, label %tail.yes.531, label %tail.no.532
tail.yes.531:
  %v533 = getelementptr i8, ptr %a0, i64 24
  %v534 = load i64, ptr %v533, align 8, !tbaa !3
  %v535 = getelementptr i8, ptr %a0, i64 32
  %v536 = load ptr, ptr %v535, align 8, !tbaa !3
  %v537 = ptrtoint ptr %a1 to i64
  %v538 = ashr i64 %v537, 1
  %v539 = and i64 %v537, 1
  %v540 = icmp ne i64 %v539, 0
  %v541 = icmp ult i64 %v538, %v534
  %v542 = and i1 %v540, %v541
  br i1 %v542, label %array.valid.543, label %array.invalid.544
array.invalid.544:
  call void @mlf_bounds_failure()
  unreachable
array.valid.543:
  %v545 = getelementptr i64, ptr %v536, i64 %v538
  %v546 = load ptr, ptr %v545, align 8, !tbaa !4
  %v547 = ptrtoint ptr %a2 to i64
  %v548 = ashr i64 %v547, 1
  %v549 = and i64 %v547, 1
  %v550 = icmp ne i64 %v549, 0
  %v551 = icmp ult i64 %v548, %v534
  %v552 = and i1 %v550, %v551
  br i1 %v552, label %array.valid.553, label %array.invalid.554
array.invalid.554:
  call void @mlf_bounds_failure()
  unreachable
array.valid.553:
  %v555 = getelementptr i64, ptr %v536, i64 %v548
  %v556 = load ptr, ptr %v555, align 8, !tbaa !4
  %v557 = ptrtoint ptr %a1 to i64
  %v558 = ashr i64 %v557, 1
  %v559 = and i64 %v557, 1
  %v560 = icmp ne i64 %v559, 0
  %v561 = icmp ult i64 %v558, %v534
  %v562 = and i1 %v560, %v561
  br i1 %v562, label %array.valid.563, label %array.invalid.564
array.invalid.564:
  call void @mlf_bounds_failure()
  unreachable
array.valid.563:
  %v565 = getelementptr i64, ptr %v536, i64 %v558
  store ptr %v556, ptr %v565, align 8, !tbaa !4
  %v566 = ptrtoint ptr %a2 to i64
  %v567 = ashr i64 %v566, 1
  %v568 = and i64 %v566, 1
  %v569 = icmp ne i64 %v568, 0
  %v570 = icmp ult i64 %v567, %v534
  %v571 = and i1 %v569, %v570
  br i1 %v571, label %array.valid.572, label %array.invalid.573
array.invalid.573:
  call void @mlf_bounds_failure()
  unreachable
array.valid.572:
  %v574 = getelementptr i64, ptr %v536, i64 %v567
  store ptr %v546, ptr %v574, align 8, !tbaa !4
  %v575 = ptrtoint ptr %a1 to i64
  %v576 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v577 = sub i64 %v576, 1
  %v578 = add nsw i64 %v575, %v577
  %v579 = inttoptr i64 %v578 to ptr
  %v580 = ptrtoint ptr %a2 to i64
  %v581 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v582 = sub i64 %v581, 1
  %v583 = sub nsw i64 %v580, %v582
  %v584 = inttoptr i64 %v583 to ptr
  %v585 = musttail call ptr @mlf.numeric.12(ptr %a0, ptr %v579, ptr %v584)
  ret ptr %v585
tail.no.532:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.numeric.20(ptr %a0, ptr %a1) alwaysinline {
entry:
  %v592 = ptrtoint ptr %a1 to i64
  %v593 = and i64 %v592, 1
  %v594 = icmp ne i64 %v593, 0
  %v595 = icmp ult i64 %v592, 4294967296
  %v596 = and i1 %v594, %v595
  %v597 = and i1 true, %v596
  br i1 %v597, label %range.fast.598, label %range.general.599
range.fast.598:
  %v600 = musttail call ptr @mlf.numeric.20.pi(ptr %a0, ptr %a1)
  ret ptr %v600
range.general.599:
  %v601 = getelementptr i8, ptr %a0, i64 24
  %v602 = load i64, ptr %v601, align 8, !tbaa !3
  %v603 = getelementptr i8, ptr %a0, i64 32
  %v604 = load ptr, ptr %v603, align 8, !tbaa !3
  %v605 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v606 = ashr i64 %v605, 1
  %v607 = and i64 %v605, 1
  %v608 = icmp ne i64 %v607, 0
  %v609 = icmp ult i64 %v606, %v602
  %v610 = and i1 %v608, %v609
  br i1 %v610, label %array.valid.611, label %array.invalid.612
array.invalid.612:
  call void @mlf_bounds_failure()
  unreachable
array.valid.611:
  %v613 = getelementptr i64, ptr %v604, i64 %v606
  %v614 = load ptr, ptr %v613, align 8, !tbaa !4
  %v615 = ptrtoint ptr %v614 to i64
  %v616 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v617 = and i64 %v615, %v616
  %v618 = and i64 %v617, 1
  %v619 = icmp ne i64 %v618, 0
  br i1 %v619, label %yes.620, label %no.621
yes.620:
  %v623 = icmp eq i64 %v615, %v616
  %v624 = select i1 %v623, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.622
no.621:
  %v625 = call ptr @mlf_eq_int(ptr %v614, ptr inttoptr (i64 3 to ptr))
  br label %join.622
join.622:
  %v626 = phi ptr [ %v624, %yes.620 ], [ %v625, %no.621 ]
  %v627 = icmp eq ptr %v626, inttoptr (i64 6 to ptr)
  br i1 %v627, label %tail.yes.628, label %tail.no.629
tail.yes.628:
  ret ptr %a1
tail.no.629:
  %v630 = ptrtoint ptr %v614 to i64
  %v631 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v632 = and i64 %v630, %v631
  %v633 = and i64 %v632, 1
  %v634 = icmp ne i64 %v633, 0
  br i1 %v634, label %yes.635, label %no.636
yes.635:
  %v638 = sub i64 %v631, 1
  %v639 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v630, i64 %v638)
  %v640 = extractvalue { i64, i1 } %v639, 0
  %v641 = extractvalue { i64, i1 } %v639, 1
  br i1 %v641, label %yes.642, label %no.643
yes.642:
  %v645 = call ptr @mlf_sub_int(ptr %v614, ptr inttoptr (i64 3 to ptr))
  br label %join.644
no.643:
  %v646 = inttoptr i64 %v640 to ptr
  br label %join.644
join.644:
  %v647 = phi ptr [ %v645, %yes.642 ], [ %v646, %no.643 ]
  br label %join.637
no.636:
  %v648 = call ptr @mlf_sub_int(ptr %v614, ptr inttoptr (i64 3 to ptr))
  br label %join.637
join.637:
  %v649 = phi ptr [ %v647, %join.644 ], [ %v648, %no.636 ]
  %v650 = call ptr @mlf.numeric.12(ptr %a0, ptr inttoptr (i64 1 to ptr), ptr %v649)
  %v651 = ptrtoint ptr %a1 to i64
  %v652 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v653 = and i64 %v651, %v652
  %v654 = and i64 %v653, 1
  %v655 = icmp ne i64 %v654, 0
  br i1 %v655, label %yes.656, label %no.657
yes.656:
  %v659 = sub i64 %v652, 1
  %v660 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v651, i64 %v659)
  %v661 = extractvalue { i64, i1 } %v660, 0
  %v662 = extractvalue { i64, i1 } %v660, 1
  br i1 %v662, label %yes.663, label %no.664
yes.663:
  %v666 = call ptr @mlf_add_int(ptr %a1, ptr inttoptr (i64 3 to ptr))
  br label %join.665
no.664:
  %v667 = inttoptr i64 %v661 to ptr
  br label %join.665
join.665:
  %v668 = phi ptr [ %v666, %yes.663 ], [ %v667, %no.664 ]
  br label %join.658
no.657:
  %v669 = call ptr @mlf_add_int(ptr %a1, ptr inttoptr (i64 3 to ptr))
  br label %join.658
join.658:
  %v670 = phi ptr [ %v668, %join.665 ], [ %v669, %no.657 ]
  %v671 = musttail call ptr @mlf.numeric.20(ptr %a0, ptr %v670)
  ret ptr %v671
}

define private ptr @mlf.numeric.20.pi(ptr %a0, ptr %a1) alwaysinline {
entry:
  %v394 = getelementptr i8, ptr %a0, i64 24
  %v395 = load i64, ptr %v394, align 8, !tbaa !3
  %v396 = getelementptr i8, ptr %a0, i64 32
  %v397 = load ptr, ptr %v396, align 8, !tbaa !3
  %v398 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v399 = ashr i64 %v398, 1
  %v400 = and i64 %v398, 1
  %v401 = icmp ne i64 %v400, 0
  %v402 = icmp ult i64 %v399, %v395
  %v403 = and i1 %v401, %v402
  br i1 %v403, label %array.valid.404, label %array.invalid.405
array.invalid.405:
  call void @mlf_bounds_failure()
  unreachable
array.valid.404:
  %v406 = getelementptr i64, ptr %v397, i64 %v399
  %v407 = load ptr, ptr %v406, align 8, !tbaa !4
  %v408 = ptrtoint ptr %v407 to i64
  %v409 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v410 = and i64 %v408, %v409
  %v411 = and i64 %v410, 1
  %v412 = icmp ne i64 %v411, 0
  br i1 %v412, label %yes.413, label %no.414
yes.413:
  %v416 = icmp eq i64 %v408, %v409
  %v417 = select i1 %v416, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.415
no.414:
  %v418 = call ptr @mlf_eq_int(ptr %v407, ptr inttoptr (i64 3 to ptr))
  br label %join.415
join.415:
  %v419 = phi ptr [ %v417, %yes.413 ], [ %v418, %no.414 ]
  %v420 = icmp eq ptr %v419, inttoptr (i64 6 to ptr)
  br i1 %v420, label %tail.yes.421, label %tail.no.422
tail.yes.421:
  ret ptr %a1
tail.no.422:
  %v423 = ptrtoint ptr %v407 to i64
  %v424 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v425 = and i64 %v423, %v424
  %v426 = and i64 %v425, 1
  %v427 = icmp ne i64 %v426, 0
  br i1 %v427, label %yes.428, label %no.429
yes.428:
  %v431 = sub i64 %v424, 1
  %v432 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v423, i64 %v431)
  %v433 = extractvalue { i64, i1 } %v432, 0
  %v434 = extractvalue { i64, i1 } %v432, 1
  br i1 %v434, label %yes.435, label %no.436
yes.435:
  %v438 = call ptr @mlf_sub_int(ptr %v407, ptr inttoptr (i64 3 to ptr))
  br label %join.437
no.436:
  %v439 = inttoptr i64 %v433 to ptr
  br label %join.437
join.437:
  %v440 = phi ptr [ %v438, %yes.435 ], [ %v439, %no.436 ]
  br label %join.430
no.429:
  %v441 = call ptr @mlf_sub_int(ptr %v407, ptr inttoptr (i64 3 to ptr))
  br label %join.430
join.430:
  %v442 = phi ptr [ %v440, %join.437 ], [ %v441, %no.429 ]
  %v586 = call ptr @mlf.numeric.12(ptr %a0, ptr inttoptr (i64 1 to ptr), ptr %v442)
  %v587 = ptrtoint ptr %a1 to i64
  %v588 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v589 = sub i64 %v588, 1
  %v590 = add nsw i64 %v587, %v589
  %v591 = inttoptr i64 %v590 to ptr
  %v672 = musttail call ptr @mlf.numeric.20(ptr %a0, ptr %v591)
  ret ptr %v672
}

define private ptr @mlf.numeric.25.piii(ptr %a0, ptr %a1, ptr %a2, ptr %a3) alwaysinline {
entry:
  %v836 = ptrtoint ptr %a3 to i64
  %v837 = ptrtoint ptr %a1 to i64
  %v838 = icmp eq i64 %v836, %v837
  %v839 = select i1 %v838, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v840 = icmp eq ptr %v839, inttoptr (i64 6 to ptr)
  br i1 %v840, label %tail.yes.841, label %tail.no.842
tail.yes.841:
  %v843 = getelementptr i8, ptr %a0, i64 24
  %v844 = load i64, ptr %v843, align 8, !tbaa !3
  %v845 = getelementptr i8, ptr %a0, i64 32
  %v846 = load ptr, ptr %v845, align 8, !tbaa !3
  %v847 = ptrtoint ptr %a1 to i64
  %v848 = ashr i64 %v847, 1
  %v849 = and i64 %v847, 1
  %v850 = icmp ne i64 %v849, 0
  %v851 = icmp ult i64 %v848, %v844
  %v852 = and i1 %v850, %v851
  br i1 %v852, label %array.valid.853, label %array.invalid.854
array.invalid.854:
  call void @mlf_bounds_failure()
  unreachable
array.valid.853:
  %v855 = getelementptr i64, ptr %v846, i64 %v848
  store ptr %a2, ptr %v855, align 8, !tbaa !4
  ret ptr inttoptr (i64 4 to ptr)
tail.no.842:
  %v856 = ptrtoint ptr %a3 to i64
  %v857 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v858 = sub i64 %v857, 1
  %v859 = add nsw i64 %v856, %v858
  %v860 = inttoptr i64 %v859 to ptr
  %v861 = getelementptr i8, ptr %a0, i64 24
  %v862 = load i64, ptr %v861, align 8, !tbaa !3
  %v863 = getelementptr i8, ptr %a0, i64 32
  %v864 = load ptr, ptr %v863, align 8, !tbaa !3
  %v865 = ptrtoint ptr %v860 to i64
  %v866 = ashr i64 %v865, 1
  %v867 = and i64 %v865, 1
  %v868 = icmp ne i64 %v867, 0
  %v869 = icmp ult i64 %v866, %v862
  %v870 = and i1 %v868, %v869
  br i1 %v870, label %array.valid.871, label %array.invalid.872
array.invalid.872:
  call void @mlf_bounds_failure()
  unreachable
array.valid.871:
  %v873 = getelementptr i64, ptr %v864, i64 %v866
  %v874 = load ptr, ptr %v873, align 8, !tbaa !4
  %v875 = ptrtoint ptr %a3 to i64
  %v876 = ashr i64 %v875, 1
  %v877 = and i64 %v875, 1
  %v878 = icmp ne i64 %v877, 0
  %v879 = icmp ult i64 %v876, %v862
  %v880 = and i1 %v878, %v879
  br i1 %v880, label %array.valid.881, label %array.invalid.882
array.invalid.882:
  call void @mlf_bounds_failure()
  unreachable
array.valid.881:
  %v883 = getelementptr i64, ptr %v864, i64 %v876
  store ptr %v874, ptr %v883, align 8, !tbaa !4
  %v884 = ptrtoint ptr %a3 to i64
  %v885 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v886 = sub i64 %v885, 1
  %v887 = add nsw i64 %v884, %v886
  %v888 = inttoptr i64 %v887 to ptr
  %v889 = musttail call ptr @mlf.numeric.25(ptr %a0, ptr %a1, ptr %a2, ptr %v888)
  ret ptr %v889
}

define private ptr @mlf.numeric.25(ptr %a0, ptr %a1, ptr %a2, ptr %a3) alwaysinline {
entry:
  %v816 = ptrtoint ptr %a1 to i64
  %v817 = and i64 %v816, 1
  %v818 = icmp ne i64 %v817, 0
  %v819 = icmp ult i64 %v816, 4294967296
  %v820 = and i1 %v818, %v819
  %v821 = ptrtoint ptr %a2 to i64
  %v822 = and i64 %v821, 1
  %v823 = icmp ne i64 %v822, 0
  %v824 = icmp ult i64 %v821, 4294967296
  %v825 = and i1 %v823, %v824
  %v826 = ptrtoint ptr %a3 to i64
  %v827 = and i64 %v826, 1
  %v828 = icmp ne i64 %v827, 0
  %v829 = icmp ult i64 %v826, 4294967296
  %v830 = and i1 %v828, %v829
  %v831 = and i1 true, %v820
  %v832 = and i1 %v831, %v825
  %v833 = and i1 %v832, %v830
  br i1 %v833, label %range.fast.834, label %range.general.835
range.fast.834:
  %v890 = musttail call ptr @mlf.numeric.25.piii(ptr %a0, ptr %a1, ptr %a2, ptr %a3)
  ret ptr %v890
range.general.835:
  %v891 = ptrtoint ptr %a3 to i64
  %v892 = ptrtoint ptr %a1 to i64
  %v893 = and i64 %v891, %v892
  %v894 = and i64 %v893, 1
  %v895 = icmp ne i64 %v894, 0
  br i1 %v895, label %yes.896, label %no.897
yes.896:
  %v899 = icmp eq i64 %v891, %v892
  %v900 = select i1 %v899, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.898
no.897:
  %v901 = call ptr @mlf_eq_int(ptr %a3, ptr %a1)
  br label %join.898
join.898:
  %v902 = phi ptr [ %v900, %yes.896 ], [ %v901, %no.897 ]
  %v903 = icmp eq ptr %v902, inttoptr (i64 6 to ptr)
  br i1 %v903, label %tail.yes.904, label %tail.no.905
tail.yes.904:
  %v906 = getelementptr i8, ptr %a0, i64 24
  %v907 = load i64, ptr %v906, align 8, !tbaa !3
  %v908 = getelementptr i8, ptr %a0, i64 32
  %v909 = load ptr, ptr %v908, align 8, !tbaa !3
  %v910 = ptrtoint ptr %a1 to i64
  %v911 = ashr i64 %v910, 1
  %v912 = and i64 %v910, 1
  %v913 = icmp ne i64 %v912, 0
  %v914 = icmp ult i64 %v911, %v907
  %v915 = and i1 %v913, %v914
  br i1 %v915, label %array.valid.916, label %array.invalid.917
array.invalid.917:
  call void @mlf_bounds_failure()
  unreachable
array.valid.916:
  %v918 = getelementptr i64, ptr %v909, i64 %v911
  store ptr %a2, ptr %v918, align 8, !tbaa !4
  ret ptr inttoptr (i64 4 to ptr)
tail.no.905:
  %v919 = ptrtoint ptr %a3 to i64
  %v920 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v921 = and i64 %v919, %v920
  %v922 = and i64 %v921, 1
  %v923 = icmp ne i64 %v922, 0
  br i1 %v923, label %yes.924, label %no.925
yes.924:
  %v927 = sub i64 %v920, 1
  %v928 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v919, i64 %v927)
  %v929 = extractvalue { i64, i1 } %v928, 0
  %v930 = extractvalue { i64, i1 } %v928, 1
  br i1 %v930, label %yes.931, label %no.932
yes.931:
  %v934 = call ptr @mlf_add_int(ptr %a3, ptr inttoptr (i64 3 to ptr))
  br label %join.933
no.932:
  %v935 = inttoptr i64 %v929 to ptr
  br label %join.933
join.933:
  %v936 = phi ptr [ %v934, %yes.931 ], [ %v935, %no.932 ]
  br label %join.926
no.925:
  %v937 = call ptr @mlf_add_int(ptr %a3, ptr inttoptr (i64 3 to ptr))
  br label %join.926
join.926:
  %v938 = phi ptr [ %v936, %join.933 ], [ %v937, %no.925 ]
  %v939 = getelementptr i8, ptr %a0, i64 24
  %v940 = load i64, ptr %v939, align 8, !tbaa !3
  %v941 = getelementptr i8, ptr %a0, i64 32
  %v942 = load ptr, ptr %v941, align 8, !tbaa !3
  %v943 = ptrtoint ptr %v938 to i64
  %v944 = ashr i64 %v943, 1
  %v945 = and i64 %v943, 1
  %v946 = icmp ne i64 %v945, 0
  %v947 = icmp ult i64 %v944, %v940
  %v948 = and i1 %v946, %v947
  br i1 %v948, label %array.valid.949, label %array.invalid.950
array.invalid.950:
  call void @mlf_bounds_failure()
  unreachable
array.valid.949:
  %v951 = getelementptr i64, ptr %v942, i64 %v944
  %v952 = load ptr, ptr %v951, align 8, !tbaa !4
  %v953 = ptrtoint ptr %a3 to i64
  %v954 = ashr i64 %v953, 1
  %v955 = and i64 %v953, 1
  %v956 = icmp ne i64 %v955, 0
  %v957 = icmp ult i64 %v954, %v940
  %v958 = and i1 %v956, %v957
  br i1 %v958, label %array.valid.959, label %array.invalid.960
array.invalid.960:
  call void @mlf_bounds_failure()
  unreachable
array.valid.959:
  %v961 = getelementptr i64, ptr %v942, i64 %v954
  store ptr %v952, ptr %v961, align 8, !tbaa !4
  %v962 = ptrtoint ptr %a3 to i64
  %v963 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v964 = sub i64 %v963, 1
  %v965 = add nsw i64 %v962, %v964
  %v966 = inttoptr i64 %v965 to ptr
  %v967 = musttail call ptr @mlf.numeric.25(ptr %a0, ptr %a1, ptr %a2, ptr %v966)
  ret ptr %v967
}

define private ptr @mlf.numeric.32.ppii(ptr %a0, ptr %a1, ptr %a2, ptr %a3) alwaysinline {
entry:
  %v795 = ptrtoint ptr %a3 to i64
  %v796 = ptrtoint ptr %a2 to i64
  %v797 = icmp eq i64 %v795, %v796
  %v798 = select i1 %v797, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v799 = icmp eq ptr %v798, inttoptr (i64 6 to ptr)
  br i1 %v799, label %tail.yes.800, label %tail.no.801
tail.yes.800:
  ret ptr inttoptr (i64 2 to ptr)
tail.no.801:
  %v802 = getelementptr i8, ptr %a0, i64 24
  %v803 = load i64, ptr %v802, align 8, !tbaa !3
  %v804 = getelementptr i8, ptr %a0, i64 32
  %v805 = load ptr, ptr %v804, align 8, !tbaa !3
  %v806 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v807 = ashr i64 %v806, 1
  %v808 = and i64 %v806, 1
  %v809 = icmp ne i64 %v808, 0
  %v810 = icmp ult i64 %v807, %v803
  %v811 = and i1 %v809, %v810
  br i1 %v811, label %array.valid.812, label %array.invalid.813
array.invalid.813:
  call void @mlf_bounds_failure()
  unreachable
array.valid.812:
  %v814 = getelementptr i64, ptr %v805, i64 %v807
  %v815 = load ptr, ptr %v814, align 8, !tbaa !4
  %v968 = call ptr @mlf.numeric.25(ptr %a0, ptr %a3, ptr %v815, ptr inttoptr (i64 1 to ptr))
  %v969 = getelementptr i8, ptr %a1, i64 24
  %v970 = load i64, ptr %v969, align 8, !tbaa !3
  %v971 = getelementptr i8, ptr %a1, i64 32
  %v972 = load ptr, ptr %v971, align 8, !tbaa !3
  %v973 = ptrtoint ptr %a3 to i64
  %v974 = ashr i64 %v973, 1
  %v975 = and i64 %v973, 1
  %v976 = icmp ne i64 %v975, 0
  %v977 = icmp ult i64 %v974, %v970
  %v978 = and i1 %v976, %v977
  br i1 %v978, label %array.valid.979, label %array.invalid.980
array.invalid.980:
  call void @mlf_bounds_failure()
  unreachable
array.valid.979:
  %v981 = getelementptr i64, ptr %v972, i64 %v974
  %v982 = load ptr, ptr %v981, align 8, !tbaa !4
  %v983 = ptrtoint ptr %v982 to i64
  %v984 = ptrtoint ptr %a3 to i64
  %v985 = and i64 %v983, %v984
  %v986 = and i64 %v985, 1
  %v987 = icmp ne i64 %v986, 0
  br i1 %v987, label %yes.988, label %no.989
yes.988:
  %v991 = icmp slt i64 %v983, %v984
  %v992 = select i1 %v991, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.990
no.989:
  %v993 = call ptr @mlf_lt_int(ptr %v982, ptr %a3)
  br label %join.990
join.990:
  %v994 = phi ptr [ %v992, %yes.988 ], [ %v993, %no.989 ]
  %v995 = icmp eq ptr %v994, inttoptr (i64 6 to ptr)
  br i1 %v995, label %tail.yes.996, label %tail.no.997
tail.yes.996:
  %v998 = ptrtoint ptr %v982 to i64
  %v999 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1000 = and i64 %v998, %v999
  %v1001 = and i64 %v1000, 1
  %v1002 = icmp ne i64 %v1001, 0
  br i1 %v1002, label %yes.1003, label %no.1004
yes.1003:
  %v1006 = sub i64 %v999, 1
  %v1007 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v998, i64 %v1006)
  %v1008 = extractvalue { i64, i1 } %v1007, 0
  %v1009 = extractvalue { i64, i1 } %v1007, 1
  br i1 %v1009, label %yes.1010, label %no.1011
yes.1010:
  %v1013 = call ptr @mlf_add_int(ptr %v982, ptr inttoptr (i64 3 to ptr))
  br label %join.1012
no.1011:
  %v1014 = inttoptr i64 %v1008 to ptr
  br label %join.1012
join.1012:
  %v1015 = phi ptr [ %v1013, %yes.1010 ], [ %v1014, %no.1011 ]
  br label %join.1005
no.1004:
  %v1016 = call ptr @mlf_add_int(ptr %v982, ptr inttoptr (i64 3 to ptr))
  br label %join.1005
join.1005:
  %v1017 = phi ptr [ %v1015, %join.1012 ], [ %v1016, %no.1004 ]
  %v1018 = ptrtoint ptr %a3 to i64
  %v1019 = ashr i64 %v1018, 1
  %v1020 = and i64 %v1018, 1
  %v1021 = icmp ne i64 %v1020, 0
  %v1022 = icmp ult i64 %v1019, %v970
  %v1023 = and i1 %v1021, %v1022
  br i1 %v1023, label %array.valid.1024, label %array.invalid.1025
array.invalid.1025:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1024:
  %v1026 = getelementptr i64, ptr %v972, i64 %v1019
  store ptr %v1017, ptr %v1026, align 8, !tbaa !4
  ret ptr inttoptr (i64 6 to ptr)
tail.no.997:
  %v1027 = ptrtoint ptr %a3 to i64
  %v1028 = ashr i64 %v1027, 1
  %v1029 = and i64 %v1027, 1
  %v1030 = icmp ne i64 %v1029, 0
  %v1031 = icmp ult i64 %v1028, %v970
  %v1032 = and i1 %v1030, %v1031
  br i1 %v1032, label %array.valid.1033, label %array.invalid.1034
array.invalid.1034:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1033:
  %v1035 = getelementptr i64, ptr %v972, i64 %v1028
  store ptr inttoptr (i64 1 to ptr), ptr %v1035, align 8, !tbaa !4
  %v1036 = ptrtoint ptr %a3 to i64
  %v1037 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1038 = sub i64 %v1037, 1
  %v1039 = add nsw i64 %v1036, %v1038
  %v1040 = inttoptr i64 %v1039 to ptr
  %v1041 = musttail call ptr @mlf.numeric.32(ptr %a0, ptr %a1, ptr %a2, ptr %v1040)
  ret ptr %v1041
}

define private ptr @mlf.numeric.32(ptr %a0, ptr %a1, ptr %a2, ptr %a3) alwaysinline {
entry:
  %v781 = ptrtoint ptr %a2 to i64
  %v782 = and i64 %v781, 1
  %v783 = icmp ne i64 %v782, 0
  %v784 = icmp ult i64 %v781, 4294967296
  %v785 = and i1 %v783, %v784
  %v786 = ptrtoint ptr %a3 to i64
  %v787 = and i64 %v786, 1
  %v788 = icmp ne i64 %v787, 0
  %v789 = icmp ult i64 %v786, 4294967296
  %v790 = and i1 %v788, %v789
  %v791 = and i1 true, %v785
  %v792 = and i1 %v791, %v790
  br i1 %v792, label %range.fast.793, label %range.general.794
range.fast.793:
  %v1042 = musttail call ptr @mlf.numeric.32.ppii(ptr %a0, ptr %a1, ptr %a2, ptr %a3)
  ret ptr %v1042
range.general.794:
  %v1043 = ptrtoint ptr %a3 to i64
  %v1044 = ptrtoint ptr %a2 to i64
  %v1045 = and i64 %v1043, %v1044
  %v1046 = and i64 %v1045, 1
  %v1047 = icmp ne i64 %v1046, 0
  br i1 %v1047, label %yes.1048, label %no.1049
yes.1048:
  %v1051 = icmp eq i64 %v1043, %v1044
  %v1052 = select i1 %v1051, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1050
no.1049:
  %v1053 = call ptr @mlf_eq_int(ptr %a3, ptr %a2)
  br label %join.1050
join.1050:
  %v1054 = phi ptr [ %v1052, %yes.1048 ], [ %v1053, %no.1049 ]
  %v1055 = icmp eq ptr %v1054, inttoptr (i64 6 to ptr)
  br i1 %v1055, label %tail.yes.1056, label %tail.no.1057
tail.yes.1056:
  ret ptr inttoptr (i64 2 to ptr)
tail.no.1057:
  %v1058 = getelementptr i8, ptr %a0, i64 24
  %v1059 = load i64, ptr %v1058, align 8, !tbaa !3
  %v1060 = getelementptr i8, ptr %a0, i64 32
  %v1061 = load ptr, ptr %v1060, align 8, !tbaa !3
  %v1062 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v1063 = ashr i64 %v1062, 1
  %v1064 = and i64 %v1062, 1
  %v1065 = icmp ne i64 %v1064, 0
  %v1066 = icmp ult i64 %v1063, %v1059
  %v1067 = and i1 %v1065, %v1066
  br i1 %v1067, label %array.valid.1068, label %array.invalid.1069
array.invalid.1069:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1068:
  %v1070 = getelementptr i64, ptr %v1061, i64 %v1063
  %v1071 = load ptr, ptr %v1070, align 8, !tbaa !4
  %v1072 = call ptr @mlf.numeric.25(ptr %a0, ptr %a3, ptr %v1071, ptr inttoptr (i64 1 to ptr))
  %v1073 = getelementptr i8, ptr %a1, i64 24
  %v1074 = load i64, ptr %v1073, align 8, !tbaa !3
  %v1075 = getelementptr i8, ptr %a1, i64 32
  %v1076 = load ptr, ptr %v1075, align 8, !tbaa !3
  %v1077 = ptrtoint ptr %a3 to i64
  %v1078 = ashr i64 %v1077, 1
  %v1079 = and i64 %v1077, 1
  %v1080 = icmp ne i64 %v1079, 0
  %v1081 = icmp ult i64 %v1078, %v1074
  %v1082 = and i1 %v1080, %v1081
  br i1 %v1082, label %array.valid.1083, label %array.invalid.1084
array.invalid.1084:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1083:
  %v1085 = getelementptr i64, ptr %v1076, i64 %v1078
  %v1086 = load ptr, ptr %v1085, align 8, !tbaa !4
  %v1087 = ptrtoint ptr %v1086 to i64
  %v1088 = ptrtoint ptr %a3 to i64
  %v1089 = and i64 %v1087, %v1088
  %v1090 = and i64 %v1089, 1
  %v1091 = icmp ne i64 %v1090, 0
  br i1 %v1091, label %yes.1092, label %no.1093
yes.1092:
  %v1095 = icmp slt i64 %v1087, %v1088
  %v1096 = select i1 %v1095, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1094
no.1093:
  %v1097 = call ptr @mlf_lt_int(ptr %v1086, ptr %a3)
  br label %join.1094
join.1094:
  %v1098 = phi ptr [ %v1096, %yes.1092 ], [ %v1097, %no.1093 ]
  %v1099 = icmp eq ptr %v1098, inttoptr (i64 6 to ptr)
  br i1 %v1099, label %tail.yes.1100, label %tail.no.1101
tail.yes.1100:
  %v1102 = ptrtoint ptr %v1086 to i64
  %v1103 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1104 = and i64 %v1102, %v1103
  %v1105 = and i64 %v1104, 1
  %v1106 = icmp ne i64 %v1105, 0
  br i1 %v1106, label %yes.1107, label %no.1108
yes.1107:
  %v1110 = sub i64 %v1103, 1
  %v1111 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1102, i64 %v1110)
  %v1112 = extractvalue { i64, i1 } %v1111, 0
  %v1113 = extractvalue { i64, i1 } %v1111, 1
  br i1 %v1113, label %yes.1114, label %no.1115
yes.1114:
  %v1117 = call ptr @mlf_add_int(ptr %v1086, ptr inttoptr (i64 3 to ptr))
  br label %join.1116
no.1115:
  %v1118 = inttoptr i64 %v1112 to ptr
  br label %join.1116
join.1116:
  %v1119 = phi ptr [ %v1117, %yes.1114 ], [ %v1118, %no.1115 ]
  br label %join.1109
no.1108:
  %v1120 = call ptr @mlf_add_int(ptr %v1086, ptr inttoptr (i64 3 to ptr))
  br label %join.1109
join.1109:
  %v1121 = phi ptr [ %v1119, %join.1116 ], [ %v1120, %no.1108 ]
  %v1122 = ptrtoint ptr %a3 to i64
  %v1123 = ashr i64 %v1122, 1
  %v1124 = and i64 %v1122, 1
  %v1125 = icmp ne i64 %v1124, 0
  %v1126 = icmp ult i64 %v1123, %v1074
  %v1127 = and i1 %v1125, %v1126
  br i1 %v1127, label %array.valid.1128, label %array.invalid.1129
array.invalid.1129:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1128:
  %v1130 = getelementptr i64, ptr %v1076, i64 %v1123
  store ptr %v1121, ptr %v1130, align 8, !tbaa !4
  ret ptr inttoptr (i64 6 to ptr)
tail.no.1101:
  %v1131 = ptrtoint ptr %a3 to i64
  %v1132 = ashr i64 %v1131, 1
  %v1133 = and i64 %v1131, 1
  %v1134 = icmp ne i64 %v1133, 0
  %v1135 = icmp ult i64 %v1132, %v1074
  %v1136 = and i1 %v1134, %v1135
  br i1 %v1136, label %array.valid.1137, label %array.invalid.1138
array.invalid.1138:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1137:
  %v1139 = getelementptr i64, ptr %v1076, i64 %v1132
  store ptr inttoptr (i64 1 to ptr), ptr %v1139, align 8, !tbaa !4
  %v1140 = ptrtoint ptr %a3 to i64
  %v1141 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1142 = sub i64 %v1141, 1
  %v1143 = add nsw i64 %v1140, %v1142
  %v1144 = inttoptr i64 %v1143 to ptr
  %v1145 = musttail call ptr @mlf.numeric.32(ptr %a0, ptr %a1, ptr %a2, ptr %v1144)
  ret ptr %v1145
}

define private ptr @mlf.numeric.42(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6) alwaysinline {
entry:
  %v393 = call ptr @mlf.numeric.5(ptr %a0, ptr %a1, ptr %a3, ptr inttoptr (i64 1 to ptr))
  %v673 = call ptr @mlf.numeric.20.pi(ptr %a1, ptr inttoptr (i64 1 to ptr))
  %v674 = ptrtoint ptr %a4 to i64
  %v675 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v676 = and i64 %v674, %v675
  %v677 = and i64 %v676, 1
  %v678 = icmp ne i64 %v677, 0
  br i1 %v678, label %yes.679, label %no.680
yes.679:
  %v682 = ashr i64 %v674, 1
  %v683 = ashr i64 %v675, 1
  %v684 = icmp ne i64 %v683, 0
  %v685 = icmp eq i64 %v682, -4611686018427387904
  %v686 = icmp eq i64 %v683, -1
  %v687 = and i1 %v685, %v686
  %v688 = xor i1 %v687, true
  %v689 = and i1 %v684, %v688
  br i1 %v689, label %yes.690, label %no.691
yes.690:
  %v693 = srem i64 %v682, %v683
  %v694 = shl i64 %v693, 1
  %v695 = or i64 %v694, 1
  %v696 = inttoptr i64 %v695 to ptr
  br label %join.692
no.691:
  %v697 = call ptr @mlf_prim2(i64 16, ptr %a4, ptr inttoptr (i64 5 to ptr))
  br label %join.692
join.692:
  %v698 = phi ptr [ %v696, %yes.690 ], [ %v697, %no.691 ]
  br label %join.681
no.680:
  %v699 = call ptr @mlf_prim2(i64 16, ptr %a4, ptr inttoptr (i64 5 to ptr))
  br label %join.681
join.681:
  %v700 = phi ptr [ %v698, %join.692 ], [ %v699, %no.680 ]
  %v701 = ptrtoint ptr %v700 to i64
  %v702 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v703 = and i64 %v701, %v702
  %v704 = and i64 %v703, 1
  %v705 = icmp ne i64 %v704, 0
  br i1 %v705, label %yes.706, label %no.707
yes.706:
  %v709 = icmp eq i64 %v701, %v702
  %v710 = select i1 %v709, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.708
no.707:
  %v711 = call ptr @mlf_eq_int(ptr %v700, ptr inttoptr (i64 1 to ptr))
  br label %join.708
join.708:
  %v712 = phi ptr [ %v710, %yes.706 ], [ %v711, %no.707 ]
  %v713 = icmp eq ptr %v712, inttoptr (i64 6 to ptr)
  br i1 %v713, label %yes.714, label %no.715
yes.714:
  %v717 = ptrtoint ptr %a5 to i64
  %v718 = ptrtoint ptr %v673 to i64
  %v719 = and i64 %v717, %v718
  %v720 = and i64 %v719, 1
  %v721 = icmp ne i64 %v720, 0
  br i1 %v721, label %yes.722, label %no.723
yes.722:
  %v725 = sub i64 %v718, 1
  %v726 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v717, i64 %v725)
  %v727 = extractvalue { i64, i1 } %v726, 0
  %v728 = extractvalue { i64, i1 } %v726, 1
  br i1 %v728, label %yes.729, label %no.730
yes.729:
  %v732 = call ptr @mlf_add_int(ptr %a5, ptr %v673)
  br label %join.731
no.730:
  %v733 = inttoptr i64 %v727 to ptr
  br label %join.731
join.731:
  %v734 = phi ptr [ %v732, %yes.729 ], [ %v733, %no.730 ]
  br label %join.724
no.723:
  %v735 = call ptr @mlf_add_int(ptr %a5, ptr %v673)
  br label %join.724
join.724:
  %v736 = phi ptr [ %v734, %join.731 ], [ %v735, %no.723 ]
  br label %join.716
no.715:
  %v737 = ptrtoint ptr %a5 to i64
  %v738 = ptrtoint ptr %v673 to i64
  %v739 = and i64 %v737, %v738
  %v740 = and i64 %v739, 1
  %v741 = icmp ne i64 %v740, 0
  br i1 %v741, label %yes.742, label %no.743
yes.742:
  %v745 = sub i64 %v738, 1
  %v746 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v737, i64 %v745)
  %v747 = extractvalue { i64, i1 } %v746, 0
  %v748 = extractvalue { i64, i1 } %v746, 1
  br i1 %v748, label %yes.749, label %no.750
yes.749:
  %v752 = call ptr @mlf_sub_int(ptr %a5, ptr %v673)
  br label %join.751
no.750:
  %v753 = inttoptr i64 %v747 to ptr
  br label %join.751
join.751:
  %v754 = phi ptr [ %v752, %yes.749 ], [ %v753, %no.750 ]
  br label %join.744
no.743:
  %v755 = call ptr @mlf_sub_int(ptr %a5, ptr %v673)
  br label %join.744
join.744:
  %v756 = phi ptr [ %v754, %join.751 ], [ %v755, %no.743 ]
  br label %join.716
join.716:
  %v757 = phi ptr [ %v736, %join.724 ], [ %v756, %join.744 ]
  %v758 = ptrtoint ptr %a6 to i64
  %v759 = ptrtoint ptr %v673 to i64
  %v760 = and i64 %v758, %v759
  %v761 = and i64 %v760, 1
  %v762 = icmp ne i64 %v761, 0
  br i1 %v762, label %yes.763, label %no.764
yes.763:
  %v766 = icmp slt i64 %v758, %v759
  %v767 = select i1 %v766, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.765
no.764:
  %v768 = call ptr @mlf_lt_int(ptr %a6, ptr %v673)
  br label %join.765
join.765:
  %v769 = phi ptr [ %v767, %yes.763 ], [ %v768, %no.764 ]
  %v770 = icmp eq ptr %v769, inttoptr (i64 6 to ptr)
  br i1 %v770, label %yes.771, label %no.772
yes.771:
  br label %join.773
no.772:
  br label %join.773
join.773:
  %v774 = phi ptr [ %v673, %yes.771 ], [ %a6, %no.772 ]
  %v775 = icmp eq ptr inttoptr (i64 6 to ptr), inttoptr (i64 6 to ptr)
  br i1 %v775, label %tail.yes.776, label %tail.no.777
tail.yes.776:
  %v778 = icmp eq ptr inttoptr (i64 6 to ptr), inttoptr (i64 6 to ptr)
  br i1 %v778, label %tail.yes.779, label %tail.no.780
tail.yes.779:
  %v1146 = call ptr @mlf.numeric.32(ptr %a0, ptr %a2, ptr %a3, ptr inttoptr (i64 3 to ptr))
  %v1147 = icmp eq ptr %v1146, inttoptr (i64 6 to ptr)
  br i1 %v1147, label %tail.yes.1148, label %tail.no.1149
tail.yes.1148:
  %v1150 = ptrtoint ptr %a4 to i64
  %v1151 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1152 = and i64 %v1150, %v1151
  %v1153 = and i64 %v1152, 1
  %v1154 = icmp ne i64 %v1153, 0
  br i1 %v1154, label %yes.1155, label %no.1156
yes.1155:
  %v1158 = sub i64 %v1151, 1
  %v1159 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1150, i64 %v1158)
  %v1160 = extractvalue { i64, i1 } %v1159, 0
  %v1161 = extractvalue { i64, i1 } %v1159, 1
  br i1 %v1161, label %yes.1162, label %no.1163
yes.1162:
  %v1165 = call ptr @mlf_add_int(ptr %a4, ptr inttoptr (i64 3 to ptr))
  br label %join.1164
no.1163:
  %v1166 = inttoptr i64 %v1160 to ptr
  br label %join.1164
join.1164:
  %v1167 = phi ptr [ %v1165, %yes.1162 ], [ %v1166, %no.1163 ]
  br label %join.1157
no.1156:
  %v1168 = call ptr @mlf_add_int(ptr %a4, ptr inttoptr (i64 3 to ptr))
  br label %join.1157
join.1157:
  %v1169 = phi ptr [ %v1167, %join.1164 ], [ %v1168, %no.1156 ]
  %v1170 = musttail call ptr @mlf.numeric.42(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %v1169, ptr %v757, ptr %v774)
  ret ptr %v1170
tail.no.1149:
  %v1171 = call ptr @mlf_constructor2(i64 1, ptr %v757, ptr %v774)
  ret ptr %v1171
tail.no.780:
  %v1172 = call ptr @mlf_constructor2(i64 1, ptr inttoptr (i64 1 to ptr), ptr inttoptr (i64 1 to ptr))
  ret ptr %v1172
tail.no.777:
  %v1173 = call ptr @mlf_constructor2(i64 1, ptr inttoptr (i64 1 to ptr), ptr inttoptr (i64 1 to ptr))
  ret ptr %v1173
}

define private ptr @mlf.code.1215(ptr %env, ptr %arg) {
entry:
  %v1216 = getelementptr i8, ptr %env, i64 24
  %v1217 = load ptr, ptr %v1216, align 8, !tbaa !3
  %v1218 = getelementptr i8, ptr %env, i64 32
  %v1219 = load ptr, ptr %v1218, align 8, !tbaa !3
  %v1220 = call ptr @mlf_prim2(i64 28, ptr %v1217, ptr %v1219)
  ret ptr %v1220
}

define private ptr @mlf.code.1234(ptr %env, ptr %arg) {
entry:
  %v1235 = getelementptr i8, ptr %env, i64 24
  %v1236 = load ptr, ptr %v1235, align 8, !tbaa !3
  %v1237 = getelementptr i8, ptr %env, i64 32
  %v1238 = load ptr, ptr %v1237, align 8, !tbaa !3
  %v1239 = getelementptr i8, ptr %env, i64 40
  %v1240 = load ptr, ptr %v1239, align 8, !tbaa !3
  %v1241 = call ptr @mlf_prim3(i64 29, ptr %v1236, ptr %v1238, ptr %v1240)
  ret ptr %v1241
}

define private ptr @mlf.code.1247(ptr %env, ptr %arg) {
entry:
  %v1248 = getelementptr i8, ptr %env, i64 24
  %v1249 = load ptr, ptr %v1248, align 8, !tbaa !3
  %v1250 = getelementptr i8, ptr %env, i64 32
  %v1251 = load ptr, ptr %v1250, align 8, !tbaa !3
  %v1252 = getelementptr i8, ptr %env, i64 40
  %v1253 = load ptr, ptr %v1252, align 8, !tbaa !3
  %v1254 = getelementptr i8, ptr %env, i64 48
  %v1255 = load ptr, ptr %v1254, align 8, !tbaa !3
  %v1256 = call ptr @mlf_force(ptr %v1253)
  %v1257 = call ptr @mlf_force(ptr %v1255)
  %v1258 = call ptr @mlf_prim2(i64 8, ptr %v1257, ptr inttoptr (i64 3 to ptr))
  %v1259 = call ptr @mlf_env_new(i64 4)
  %v1260 = getelementptr i8, ptr %v1259, i64 24
  store ptr %v1249, ptr %v1260, align 8, !tbaa !3
  %v1261 = getelementptr i8, ptr %v1259, i64 32
  store ptr %v1251, ptr %v1261, align 8, !tbaa !3
  %v1262 = getelementptr i8, ptr %v1259, i64 40
  store ptr %v1256, ptr %v1262, align 8, !tbaa !3
  %v1263 = getelementptr i8, ptr %v1259, i64 48
  store ptr %v1258, ptr %v1263, align 8, !tbaa !3
  %v1264 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1183, ptr %v1259)
  ret ptr %v1264
}

define private ptr @mlf.code.1225(ptr %env, ptr %arg) {
entry:
  %v1226 = getelementptr i8, ptr %env, i64 24
  %v1227 = load ptr, ptr %v1226, align 8, !tbaa !3
  %v1228 = getelementptr i8, ptr %env, i64 32
  %v1229 = load ptr, ptr %v1228, align 8, !tbaa !3
  %v1230 = getelementptr i8, ptr %env, i64 40
  %v1231 = load ptr, ptr %v1230, align 8, !tbaa !3
  %v1232 = getelementptr i8, ptr %env, i64 48
  %v1233 = load ptr, ptr %v1232, align 8, !tbaa !3
  %v1242 = call ptr @mlf_env_new(i64 3)
  %v1243 = getelementptr i8, ptr %v1242, i64 24
  store ptr %v1229, ptr %v1243, align 8, !tbaa !3
  %v1244 = getelementptr i8, ptr %v1242, i64 32
  store ptr %v1233, ptr %v1244, align 8, !tbaa !3
  %v1245 = getelementptr i8, ptr %v1242, i64 40
  store ptr %arg, ptr %v1245, align 8, !tbaa !3
  %v1246 = call ptr @mlf_thunk(ptr @mlf.code.1234, ptr %v1242)
  %v1265 = call ptr @mlf_env_new(i64 4)
  %v1266 = getelementptr i8, ptr %v1265, i64 24
  store ptr %v1227, ptr %v1266, align 8, !tbaa !3
  %v1267 = getelementptr i8, ptr %v1265, i64 32
  store ptr %v1229, ptr %v1267, align 8, !tbaa !3
  %v1268 = getelementptr i8, ptr %v1265, i64 40
  store ptr %v1231, ptr %v1268, align 8, !tbaa !3
  %v1269 = getelementptr i8, ptr %v1265, i64 48
  store ptr %v1233, ptr %v1269, align 8, !tbaa !3
  %v1270 = call ptr @mlf_closure(ptr @mlf.code.1247, ptr %v1265)
  %v1271 = call ptr @mlf_prim2(i64 1, ptr %v1246, ptr %v1270)
  ret ptr %v1271
}

define private ptr @mlf.worker.5(ptr %a0, ptr %a1, ptr %a2, ptr %a3) {
entry:
  %v1209 = call ptr @mlf_prim2(i64 10, ptr %a3, ptr %a2)
  %v1210 = icmp eq ptr %v1209, inttoptr (i64 6 to ptr)
  br i1 %v1210, label %yes.1211, label %no.1212
yes.1211:
  %v1214 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.1213
no.1212:
  %v1221 = call ptr @mlf_env_new(i64 2)
  %v1222 = getelementptr i8, ptr %v1221, i64 24
  store ptr %a0, ptr %v1222, align 8, !tbaa !3
  %v1223 = getelementptr i8, ptr %v1221, i64 32
  store ptr %a3, ptr %v1223, align 8, !tbaa !3
  %v1224 = call ptr @mlf_thunk(ptr @mlf.code.1215, ptr %v1221)
  %v1272 = call ptr @mlf_env_new(i64 4)
  %v1273 = getelementptr i8, ptr %v1272, i64 24
  store ptr %a0, ptr %v1273, align 8, !tbaa !3
  %v1274 = getelementptr i8, ptr %v1272, i64 32
  store ptr %a1, ptr %v1274, align 8, !tbaa !3
  %v1275 = getelementptr i8, ptr %v1272, i64 40
  store ptr %a2, ptr %v1275, align 8, !tbaa !3
  %v1276 = getelementptr i8, ptr %v1272, i64 48
  store ptr %a3, ptr %v1276, align 8, !tbaa !3
  %v1277 = call ptr @mlf_closure(ptr @mlf.code.1225, ptr %v1272)
  %v1278 = call ptr @mlf_prim2(i64 1, ptr %v1224, ptr %v1277)
  br label %join.1213
join.1213:
  %v1279 = phi ptr [ %v1214, %yes.1211 ], [ %v1278, %no.1212 ]
  ret ptr %v1279
}

define private ptr @mlf.numeric.entry.1183(ptr %env, ptr %arg) {
entry:
  %v1184 = getelementptr i8, ptr %env, i64 24
  %v1185 = load ptr, ptr %v1184, align 8, !tbaa !3
  %v1186 = getelementptr i8, ptr %env, i64 32
  %v1187 = load ptr, ptr %v1186, align 8, !tbaa !3
  %v1188 = getelementptr i8, ptr %env, i64 40
  %v1189 = load ptr, ptr %v1188, align 8, !tbaa !3
  %v1190 = getelementptr i8, ptr %env, i64 48
  %v1191 = load ptr, ptr %v1190, align 8, !tbaa !3
  %v1192 = call ptr @mlf_peek(ptr %v1185)
  %v1193 = call ptr @mlf_peek(ptr %v1187)
  %v1194 = call ptr @mlf_peek(ptr %v1189)
  %v1195 = call ptr @mlf_peek(ptr %v1191)
  %v1196 = icmp ne ptr %v1192, null
  %v1197 = icmp ne ptr %v1193, null
  %v1198 = icmp ne ptr %v1194, null
  %v1199 = icmp ne ptr %v1195, null
  %v1200 = and i1 true, %v1196
  %v1201 = and i1 %v1200, %v1197
  %v1202 = and i1 %v1201, %v1198
  %v1203 = and i1 %v1202, %v1199
  br i1 %v1203, label %yes.1204, label %no.1205
yes.1204:
  %v1207 = call ptr @mlf.numeric.5(ptr %v1192, ptr %v1193, ptr %v1194, ptr %v1195)
  %v1208 = call ptr @mlf_prim1(i64 0, ptr %v1207)
  br label %join.1206
no.1205:
  %v1280 = call ptr @mlf_force(ptr %v1189)
  %v1281 = call ptr @mlf_force(ptr %v1191)
  %v1282 = call ptr @mlf.worker.5(ptr %v1185, ptr %v1187, ptr %v1280, ptr %v1281)
  br label %join.1206
join.1206:
  %v1283 = phi ptr [ %v1208, %yes.1204 ], [ %v1282, %no.1205 ]
  ret ptr %v1283
}

define private ptr @mlf.code.1176(ptr %env, ptr %arg) {
entry:
  %v1177 = getelementptr i8, ptr %env, i64 24
  %v1178 = load ptr, ptr %v1177, align 8, !tbaa !3
  %v1179 = getelementptr i8, ptr %env, i64 32
  %v1180 = load ptr, ptr %v1179, align 8, !tbaa !3
  %v1181 = getelementptr i8, ptr %env, i64 40
  %v1182 = load ptr, ptr %v1181, align 8, !tbaa !3
  %v1284 = call ptr @mlf_force(ptr %v1182)
  %v1285 = call ptr @mlf_env_new(i64 4)
  %v1286 = getelementptr i8, ptr %v1285, i64 24
  store ptr %v1178, ptr %v1286, align 8, !tbaa !3
  %v1287 = getelementptr i8, ptr %v1285, i64 32
  store ptr %v1180, ptr %v1287, align 8, !tbaa !3
  %v1288 = getelementptr i8, ptr %v1285, i64 40
  store ptr %v1284, ptr %v1288, align 8, !tbaa !3
  %v1289 = getelementptr i8, ptr %v1285, i64 48
  store ptr inttoptr (i64 1 to ptr), ptr %v1289, align 8, !tbaa !3
  %v1290 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1183, ptr %v1285)
  ret ptr %v1290
}

define private ptr @mlf.code.1330(ptr %env, ptr %arg) {
entry:
  %v1331 = getelementptr i8, ptr %env, i64 24
  %v1332 = load ptr, ptr %v1331, align 8, !tbaa !3
  %v1333 = call ptr @mlf_prim2(i64 28, ptr %v1332, ptr inttoptr (i64 1 to ptr))
  ret ptr %v1333
}

define private ptr @mlf.code.1380(ptr %env, ptr %arg) {
entry:
  %v1381 = getelementptr i8, ptr %env, i64 24
  %v1382 = load ptr, ptr %v1381, align 8, !tbaa !3
  %v1383 = getelementptr i8, ptr %env, i64 32
  %v1384 = load ptr, ptr %v1383, align 8, !tbaa !3
  %v1385 = call ptr @mlf_prim2(i64 28, ptr %v1382, ptr %v1384)
  ret ptr %v1385
}

define private ptr @mlf.code.1397(ptr %env, ptr %arg) {
entry:
  %v1398 = getelementptr i8, ptr %env, i64 24
  %v1399 = load ptr, ptr %v1398, align 8, !tbaa !3
  %v1400 = getelementptr i8, ptr %env, i64 32
  %v1401 = load ptr, ptr %v1400, align 8, !tbaa !3
  %v1402 = call ptr @mlf_prim2(i64 28, ptr %v1399, ptr %v1401)
  ret ptr %v1402
}

define private ptr @mlf.code.1416(ptr %env, ptr %arg) {
entry:
  %v1417 = getelementptr i8, ptr %env, i64 24
  %v1418 = load ptr, ptr %v1417, align 8, !tbaa !3
  %v1419 = getelementptr i8, ptr %env, i64 32
  %v1420 = load ptr, ptr %v1419, align 8, !tbaa !3
  %v1421 = getelementptr i8, ptr %env, i64 40
  %v1422 = load ptr, ptr %v1421, align 8, !tbaa !3
  %v1423 = call ptr @mlf_prim3(i64 29, ptr %v1418, ptr %v1420, ptr %v1422)
  ret ptr %v1423
}

define private ptr @mlf.code.1438(ptr %env, ptr %arg) {
entry:
  %v1439 = getelementptr i8, ptr %env, i64 24
  %v1440 = load ptr, ptr %v1439, align 8, !tbaa !3
  %v1441 = getelementptr i8, ptr %env, i64 32
  %v1442 = load ptr, ptr %v1441, align 8, !tbaa !3
  %v1443 = getelementptr i8, ptr %env, i64 40
  %v1444 = load ptr, ptr %v1443, align 8, !tbaa !3
  %v1445 = call ptr @mlf_prim3(i64 29, ptr %v1440, ptr %v1442, ptr %v1444)
  ret ptr %v1445
}

define private ptr @mlf.code.1451(ptr %env, ptr %arg) {
entry:
  %v1452 = getelementptr i8, ptr %env, i64 24
  %v1453 = load ptr, ptr %v1452, align 8, !tbaa !3
  %v1454 = getelementptr i8, ptr %env, i64 32
  %v1455 = load ptr, ptr %v1454, align 8, !tbaa !3
  %v1456 = getelementptr i8, ptr %env, i64 40
  %v1457 = load ptr, ptr %v1456, align 8, !tbaa !3
  %v1458 = call ptr @mlf_force(ptr %v1455)
  %v1459 = call ptr @mlf_prim2(i64 8, ptr %v1458, ptr inttoptr (i64 3 to ptr))
  %v1460 = call ptr @mlf_force(ptr %v1457)
  %v1461 = call ptr @mlf_prim2(i64 9, ptr %v1460, ptr inttoptr (i64 3 to ptr))
  %v1462 = call ptr @mlf_env_new(i64 3)
  %v1463 = getelementptr i8, ptr %v1462, i64 24
  store ptr %v1453, ptr %v1463, align 8, !tbaa !3
  %v1464 = getelementptr i8, ptr %v1462, i64 32
  store ptr %v1459, ptr %v1464, align 8, !tbaa !3
  %v1465 = getelementptr i8, ptr %v1462, i64 40
  store ptr %v1461, ptr %v1465, align 8, !tbaa !3
  %v1466 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1354, ptr %v1462)
  ret ptr %v1466
}

define private ptr @mlf.code.1429(ptr %env, ptr %arg) {
entry:
  %v1430 = getelementptr i8, ptr %env, i64 24
  %v1431 = load ptr, ptr %v1430, align 8, !tbaa !3
  %v1432 = getelementptr i8, ptr %env, i64 32
  %v1433 = load ptr, ptr %v1432, align 8, !tbaa !3
  %v1434 = getelementptr i8, ptr %env, i64 40
  %v1435 = load ptr, ptr %v1434, align 8, !tbaa !3
  %v1436 = getelementptr i8, ptr %env, i64 48
  %v1437 = load ptr, ptr %v1436, align 8, !tbaa !3
  %v1446 = call ptr @mlf_env_new(i64 3)
  %v1447 = getelementptr i8, ptr %v1446, i64 24
  store ptr %v1431, ptr %v1447, align 8, !tbaa !3
  %v1448 = getelementptr i8, ptr %v1446, i64 32
  store ptr %v1435, ptr %v1448, align 8, !tbaa !3
  %v1449 = getelementptr i8, ptr %v1446, i64 40
  store ptr %v1437, ptr %v1449, align 8, !tbaa !3
  %v1450 = call ptr @mlf_thunk(ptr @mlf.code.1438, ptr %v1446)
  %v1467 = call ptr @mlf_env_new(i64 3)
  %v1468 = getelementptr i8, ptr %v1467, i64 24
  store ptr %v1431, ptr %v1468, align 8, !tbaa !3
  %v1469 = getelementptr i8, ptr %v1467, i64 32
  store ptr %v1433, ptr %v1469, align 8, !tbaa !3
  %v1470 = getelementptr i8, ptr %v1467, i64 40
  store ptr %v1435, ptr %v1470, align 8, !tbaa !3
  %v1471 = call ptr @mlf_closure(ptr @mlf.code.1451, ptr %v1467)
  %v1472 = call ptr @mlf_prim2(i64 1, ptr %v1450, ptr %v1471)
  ret ptr %v1472
}

define private ptr @mlf.code.1407(ptr %env, ptr %arg) {
entry:
  %v1408 = getelementptr i8, ptr %env, i64 24
  %v1409 = load ptr, ptr %v1408, align 8, !tbaa !3
  %v1410 = getelementptr i8, ptr %env, i64 32
  %v1411 = load ptr, ptr %v1410, align 8, !tbaa !3
  %v1412 = getelementptr i8, ptr %env, i64 40
  %v1413 = load ptr, ptr %v1412, align 8, !tbaa !3
  %v1414 = getelementptr i8, ptr %env, i64 48
  %v1415 = load ptr, ptr %v1414, align 8, !tbaa !3
  %v1424 = call ptr @mlf_env_new(i64 3)
  %v1425 = getelementptr i8, ptr %v1424, i64 24
  store ptr %v1409, ptr %v1425, align 8, !tbaa !3
  %v1426 = getelementptr i8, ptr %v1424, i64 32
  store ptr %v1411, ptr %v1426, align 8, !tbaa !3
  %v1427 = getelementptr i8, ptr %v1424, i64 40
  store ptr %arg, ptr %v1427, align 8, !tbaa !3
  %v1428 = call ptr @mlf_thunk(ptr @mlf.code.1416, ptr %v1424)
  %v1473 = call ptr @mlf_env_new(i64 4)
  %v1474 = getelementptr i8, ptr %v1473, i64 24
  store ptr %v1409, ptr %v1474, align 8, !tbaa !3
  %v1475 = getelementptr i8, ptr %v1473, i64 32
  store ptr %v1411, ptr %v1475, align 8, !tbaa !3
  %v1476 = getelementptr i8, ptr %v1473, i64 40
  store ptr %v1413, ptr %v1476, align 8, !tbaa !3
  %v1477 = getelementptr i8, ptr %v1473, i64 48
  store ptr %v1415, ptr %v1477, align 8, !tbaa !3
  %v1478 = call ptr @mlf_closure(ptr @mlf.code.1429, ptr %v1473)
  %v1479 = call ptr @mlf_prim2(i64 1, ptr %v1428, ptr %v1478)
  ret ptr %v1479
}

define private ptr @mlf.code.1390(ptr %env, ptr %arg) {
entry:
  %v1391 = getelementptr i8, ptr %env, i64 24
  %v1392 = load ptr, ptr %v1391, align 8, !tbaa !3
  %v1393 = getelementptr i8, ptr %env, i64 32
  %v1394 = load ptr, ptr %v1393, align 8, !tbaa !3
  %v1395 = getelementptr i8, ptr %env, i64 40
  %v1396 = load ptr, ptr %v1395, align 8, !tbaa !3
  %v1403 = call ptr @mlf_env_new(i64 2)
  %v1404 = getelementptr i8, ptr %v1403, i64 24
  store ptr %v1392, ptr %v1404, align 8, !tbaa !3
  %v1405 = getelementptr i8, ptr %v1403, i64 32
  store ptr %v1396, ptr %v1405, align 8, !tbaa !3
  %v1406 = call ptr @mlf_thunk(ptr @mlf.code.1397, ptr %v1403)
  %v1480 = call ptr @mlf_env_new(i64 4)
  %v1481 = getelementptr i8, ptr %v1480, i64 24
  store ptr %v1392, ptr %v1481, align 8, !tbaa !3
  %v1482 = getelementptr i8, ptr %v1480, i64 32
  store ptr %v1394, ptr %v1482, align 8, !tbaa !3
  %v1483 = getelementptr i8, ptr %v1480, i64 40
  store ptr %v1396, ptr %v1483, align 8, !tbaa !3
  %v1484 = getelementptr i8, ptr %v1480, i64 48
  store ptr %arg, ptr %v1484, align 8, !tbaa !3
  %v1485 = call ptr @mlf_closure(ptr @mlf.code.1407, ptr %v1480)
  %v1486 = call ptr @mlf_prim2(i64 1, ptr %v1406, ptr %v1485)
  ret ptr %v1486
}

define private ptr @mlf.worker.12(ptr %a0, ptr %a1, ptr %a2) {
entry:
  %v1375 = call ptr @mlf_prim2(i64 11, ptr %a1, ptr %a2)
  %v1376 = icmp eq ptr %v1375, inttoptr (i64 6 to ptr)
  br i1 %v1376, label %yes.1377, label %no.1378
yes.1377:
  %v1386 = call ptr @mlf_env_new(i64 2)
  %v1387 = getelementptr i8, ptr %v1386, i64 24
  store ptr %a0, ptr %v1387, align 8, !tbaa !3
  %v1388 = getelementptr i8, ptr %v1386, i64 32
  store ptr %a1, ptr %v1388, align 8, !tbaa !3
  %v1389 = call ptr @mlf_thunk(ptr @mlf.code.1380, ptr %v1386)
  %v1487 = call ptr @mlf_env_new(i64 3)
  %v1488 = getelementptr i8, ptr %v1487, i64 24
  store ptr %a0, ptr %v1488, align 8, !tbaa !3
  %v1489 = getelementptr i8, ptr %v1487, i64 32
  store ptr %a1, ptr %v1489, align 8, !tbaa !3
  %v1490 = getelementptr i8, ptr %v1487, i64 40
  store ptr %a2, ptr %v1490, align 8, !tbaa !3
  %v1491 = call ptr @mlf_closure(ptr @mlf.code.1390, ptr %v1487)
  %v1492 = call ptr @mlf_prim2(i64 1, ptr %v1389, ptr %v1491)
  br label %join.1379
no.1378:
  %v1493 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.1379
join.1379:
  %v1494 = phi ptr [ %v1492, %yes.1377 ], [ %v1493, %no.1378 ]
  ret ptr %v1494
}

define private ptr @mlf.numeric.entry.1354(ptr %env, ptr %arg) {
entry:
  %v1355 = getelementptr i8, ptr %env, i64 24
  %v1356 = load ptr, ptr %v1355, align 8, !tbaa !3
  %v1357 = getelementptr i8, ptr %env, i64 32
  %v1358 = load ptr, ptr %v1357, align 8, !tbaa !3
  %v1359 = getelementptr i8, ptr %env, i64 40
  %v1360 = load ptr, ptr %v1359, align 8, !tbaa !3
  %v1361 = call ptr @mlf_peek(ptr %v1356)
  %v1362 = call ptr @mlf_peek(ptr %v1358)
  %v1363 = call ptr @mlf_peek(ptr %v1360)
  %v1364 = icmp ne ptr %v1361, null
  %v1365 = icmp ne ptr %v1362, null
  %v1366 = icmp ne ptr %v1363, null
  %v1367 = and i1 true, %v1364
  %v1368 = and i1 %v1367, %v1365
  %v1369 = and i1 %v1368, %v1366
  br i1 %v1369, label %yes.1370, label %no.1371
yes.1370:
  %v1373 = call ptr @mlf.numeric.12(ptr %v1361, ptr %v1362, ptr %v1363)
  %v1374 = call ptr @mlf_prim1(i64 0, ptr %v1373)
  br label %join.1372
no.1371:
  %v1495 = call ptr @mlf_force(ptr %v1358)
  %v1496 = call ptr @mlf_force(ptr %v1360)
  %v1497 = call ptr @mlf.worker.12(ptr %v1356, ptr %v1495, ptr %v1496)
  br label %join.1372
join.1372:
  %v1498 = phi ptr [ %v1374, %yes.1370 ], [ %v1497, %no.1371 ]
  ret ptr %v1498
}

define private ptr @mlf.code.1349(ptr %env, ptr %arg) {
entry:
  %v1350 = getelementptr i8, ptr %env, i64 24
  %v1351 = load ptr, ptr %v1350, align 8, !tbaa !3
  %v1352 = getelementptr i8, ptr %env, i64 32
  %v1353 = load ptr, ptr %v1352, align 8, !tbaa !3
  %v1499 = call ptr @mlf_force(ptr %v1353)
  %v1500 = call ptr @mlf_prim2(i64 9, ptr %v1499, ptr inttoptr (i64 3 to ptr))
  %v1501 = call ptr @mlf_env_new(i64 3)
  %v1502 = getelementptr i8, ptr %v1501, i64 24
  store ptr %v1351, ptr %v1502, align 8, !tbaa !3
  %v1503 = getelementptr i8, ptr %v1501, i64 32
  store ptr inttoptr (i64 1 to ptr), ptr %v1503, align 8, !tbaa !3
  %v1504 = getelementptr i8, ptr %v1501, i64 40
  store ptr %v1500, ptr %v1504, align 8, !tbaa !3
  %v1505 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1354, ptr %v1501)
  ret ptr %v1505
}

define private ptr @mlf.code.1515(ptr %env, ptr %arg) {
entry:
  %v1516 = getelementptr i8, ptr %env, i64 24
  %v1517 = load ptr, ptr %v1516, align 8, !tbaa !3
  %v1518 = call ptr @mlf_force(ptr %v1517)
  %v1519 = call ptr @mlf_prim2(i64 8, ptr %v1518, ptr inttoptr (i64 3 to ptr))
  ret ptr %v1519
}

define private ptr @mlf.code.1510(ptr %env, ptr %arg) {
entry:
  %v1511 = getelementptr i8, ptr %env, i64 24
  %v1512 = load ptr, ptr %v1511, align 8, !tbaa !3
  %v1513 = getelementptr i8, ptr %env, i64 32
  %v1514 = load ptr, ptr %v1513, align 8, !tbaa !3
  %v1520 = call ptr @mlf_env_new(i64 1)
  %v1521 = getelementptr i8, ptr %v1520, i64 24
  store ptr %v1514, ptr %v1521, align 8, !tbaa !3
  %v1522 = call ptr @mlf_thunk(ptr @mlf.code.1515, ptr %v1520)
  %v1523 = call ptr @mlf_env_new(i64 2)
  %v1524 = getelementptr i8, ptr %v1523, i64 24
  store ptr %v1512, ptr %v1524, align 8, !tbaa !3
  %v1525 = getelementptr i8, ptr %v1523, i64 32
  store ptr %v1522, ptr %v1525, align 8, !tbaa !3
  %v1526 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1314, ptr %v1523)
  ret ptr %v1526
}

define private ptr @mlf.code.1337(ptr %env, ptr %arg) {
entry:
  %v1338 = getelementptr i8, ptr %env, i64 24
  %v1339 = load ptr, ptr %v1338, align 8, !tbaa !3
  %v1340 = getelementptr i8, ptr %env, i64 32
  %v1341 = load ptr, ptr %v1340, align 8, !tbaa !3
  %v1342 = call ptr @mlf_force(ptr %arg)
  %v1343 = call ptr @mlf_prim2(i64 10, ptr %v1342, ptr inttoptr (i64 3 to ptr))
  %v1344 = icmp eq ptr %v1343, inttoptr (i64 6 to ptr)
  br i1 %v1344, label %yes.1345, label %no.1346
yes.1345:
  %v1348 = call ptr @mlf_prim1(i64 0, ptr %v1341)
  br label %join.1347
no.1346:
  %v1506 = call ptr @mlf_env_new(i64 2)
  %v1507 = getelementptr i8, ptr %v1506, i64 24
  store ptr %v1339, ptr %v1507, align 8, !tbaa !3
  %v1508 = getelementptr i8, ptr %v1506, i64 32
  store ptr %v1342, ptr %v1508, align 8, !tbaa !3
  %v1509 = call ptr @mlf_thunk(ptr @mlf.code.1349, ptr %v1506)
  %v1527 = call ptr @mlf_env_new(i64 2)
  %v1528 = getelementptr i8, ptr %v1527, i64 24
  store ptr %v1339, ptr %v1528, align 8, !tbaa !3
  %v1529 = getelementptr i8, ptr %v1527, i64 32
  store ptr %v1341, ptr %v1529, align 8, !tbaa !3
  %v1530 = call ptr @mlf_closure(ptr @mlf.code.1510, ptr %v1527)
  %v1531 = call ptr @mlf_prim2(i64 1, ptr %v1509, ptr %v1530)
  br label %join.1347
join.1347:
  %v1532 = phi ptr [ %v1348, %yes.1345 ], [ %v1531, %no.1346 ]
  ret ptr %v1532
}

define private ptr @mlf.worker.20(ptr %a0, ptr %a1) {
entry:
  %v1334 = call ptr @mlf_env_new(i64 1)
  %v1335 = getelementptr i8, ptr %v1334, i64 24
  store ptr %a0, ptr %v1335, align 8, !tbaa !3
  %v1336 = call ptr @mlf_thunk(ptr @mlf.code.1330, ptr %v1334)
  %v1533 = call ptr @mlf_env_new(i64 2)
  %v1534 = getelementptr i8, ptr %v1533, i64 24
  store ptr %a0, ptr %v1534, align 8, !tbaa !3
  %v1535 = getelementptr i8, ptr %v1533, i64 32
  store ptr %a1, ptr %v1535, align 8, !tbaa !3
  %v1536 = call ptr @mlf_closure(ptr @mlf.code.1337, ptr %v1533)
  %v1537 = call ptr @mlf_prim2(i64 1, ptr %v1336, ptr %v1536)
  ret ptr %v1537
}

define private ptr @mlf.numeric.entry.1314(ptr %env, ptr %arg) {
entry:
  %v1315 = getelementptr i8, ptr %env, i64 24
  %v1316 = load ptr, ptr %v1315, align 8, !tbaa !3
  %v1317 = getelementptr i8, ptr %env, i64 32
  %v1318 = load ptr, ptr %v1317, align 8, !tbaa !3
  %v1319 = call ptr @mlf_peek(ptr %v1316)
  %v1320 = call ptr @mlf_peek(ptr %v1318)
  %v1321 = icmp ne ptr %v1319, null
  %v1322 = icmp ne ptr %v1320, null
  %v1323 = and i1 true, %v1321
  %v1324 = and i1 %v1323, %v1322
  br i1 %v1324, label %yes.1325, label %no.1326
yes.1325:
  %v1328 = call ptr @mlf.numeric.20(ptr %v1319, ptr %v1320)
  %v1329 = call ptr @mlf_prim1(i64 0, ptr %v1328)
  br label %join.1327
no.1326:
  %v1538 = call ptr @mlf.worker.20(ptr %v1316, ptr %v1318)
  br label %join.1327
join.1327:
  %v1539 = phi ptr [ %v1329, %yes.1325 ], [ %v1538, %no.1326 ]
  ret ptr %v1539
}

define private ptr @mlf.code.1311(ptr %env, ptr %arg) {
entry:
  %v1312 = getelementptr i8, ptr %env, i64 24
  %v1313 = load ptr, ptr %v1312, align 8, !tbaa !3
  %v1540 = call ptr @mlf_env_new(i64 2)
  %v1541 = getelementptr i8, ptr %v1540, i64 24
  store ptr %v1313, ptr %v1541, align 8, !tbaa !3
  %v1542 = getelementptr i8, ptr %v1540, i64 32
  store ptr inttoptr (i64 1 to ptr), ptr %v1542, align 8, !tbaa !3
  %v1543 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1314, ptr %v1540)
  ret ptr %v1543
}

define private ptr @mlf.code.1576(ptr %env, ptr %arg) {
entry:
  %v1577 = getelementptr i8, ptr %env, i64 24
  %v1578 = load ptr, ptr %v1577, align 8, !tbaa !3
  %v1579 = getelementptr i8, ptr %env, i64 32
  %v1580 = load ptr, ptr %v1579, align 8, !tbaa !3
  %v1581 = call ptr @mlf_force(ptr %v1578)
  %v1582 = call ptr @mlf_force(ptr %v1580)
  %v1583 = call ptr @mlf_prim2(i64 11, ptr %v1581, ptr %v1582)
  %v1584 = icmp eq ptr %v1583, inttoptr (i64 6 to ptr)
  br i1 %v1584, label %yes.1585, label %no.1586
yes.1585:
  br label %join.1587
no.1586:
  br label %join.1587
join.1587:
  %v1588 = phi ptr [ %v1582, %yes.1585 ], [ %v1581, %no.1586 ]
  ret ptr %v1588
}

define private ptr @mlf.code.1643(ptr %env, ptr %arg) {
entry:
  %v1644 = getelementptr i8, ptr %env, i64 24
  %v1645 = load ptr, ptr %v1644, align 8, !tbaa !3
  %v1646 = call ptr @mlf_prim2(i64 28, ptr %v1645, ptr inttoptr (i64 1 to ptr))
  ret ptr %v1646
}

define private ptr @mlf.code.1703(ptr %env, ptr %arg) {
entry:
  %v1704 = getelementptr i8, ptr %env, i64 24
  %v1705 = load ptr, ptr %v1704, align 8, !tbaa !3
  %v1706 = call ptr @mlf_force(ptr %v1705)
  %v1707 = call ptr @mlf_prim2(i64 8, ptr %v1706, ptr inttoptr (i64 3 to ptr))
  ret ptr %v1707
}

define private ptr @mlf.code.1698(ptr %env, ptr %arg) {
entry:
  %v1699 = getelementptr i8, ptr %env, i64 24
  %v1700 = load ptr, ptr %v1699, align 8, !tbaa !3
  %v1701 = getelementptr i8, ptr %env, i64 32
  %v1702 = load ptr, ptr %v1701, align 8, !tbaa !3
  %v1708 = call ptr @mlf_env_new(i64 1)
  %v1709 = getelementptr i8, ptr %v1708, i64 24
  store ptr %v1702, ptr %v1709, align 8, !tbaa !3
  %v1710 = call ptr @mlf_thunk(ptr @mlf.code.1703, ptr %v1708)
  %v1711 = call ptr @mlf_prim2(i64 28, ptr %v1700, ptr %v1710)
  ret ptr %v1711
}

define private ptr @mlf.code.1725(ptr %env, ptr %arg) {
entry:
  %v1726 = getelementptr i8, ptr %env, i64 24
  %v1727 = load ptr, ptr %v1726, align 8, !tbaa !3
  %v1728 = getelementptr i8, ptr %env, i64 32
  %v1729 = load ptr, ptr %v1728, align 8, !tbaa !3
  %v1730 = getelementptr i8, ptr %env, i64 40
  %v1731 = load ptr, ptr %v1730, align 8, !tbaa !3
  %v1732 = call ptr @mlf_prim3(i64 29, ptr %v1727, ptr %v1729, ptr %v1731)
  ret ptr %v1732
}

define private ptr @mlf.code.1738(ptr %env, ptr %arg) {
entry:
  %v1739 = getelementptr i8, ptr %env, i64 24
  %v1740 = load ptr, ptr %v1739, align 8, !tbaa !3
  %v1741 = getelementptr i8, ptr %env, i64 32
  %v1742 = load ptr, ptr %v1741, align 8, !tbaa !3
  %v1743 = getelementptr i8, ptr %env, i64 40
  %v1744 = load ptr, ptr %v1743, align 8, !tbaa !3
  %v1745 = getelementptr i8, ptr %env, i64 48
  %v1746 = load ptr, ptr %v1745, align 8, !tbaa !3
  %v1747 = call ptr @mlf_force(ptr %v1742)
  %v1748 = call ptr @mlf_force(ptr %v1746)
  %v1749 = call ptr @mlf_prim2(i64 8, ptr %v1748, ptr inttoptr (i64 3 to ptr))
  %v1750 = call ptr @mlf_env_new(i64 4)
  %v1751 = getelementptr i8, ptr %v1750, i64 24
  store ptr %v1740, ptr %v1751, align 8, !tbaa !3
  %v1752 = getelementptr i8, ptr %v1750, i64 32
  store ptr %v1747, ptr %v1752, align 8, !tbaa !3
  %v1753 = getelementptr i8, ptr %v1750, i64 40
  store ptr %v1744, ptr %v1753, align 8, !tbaa !3
  %v1754 = getelementptr i8, ptr %v1750, i64 48
  store ptr %v1749, ptr %v1754, align 8, !tbaa !3
  %v1755 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1666, ptr %v1750)
  ret ptr %v1755
}

define private ptr @mlf.code.1716(ptr %env, ptr %arg) {
entry:
  %v1717 = getelementptr i8, ptr %env, i64 24
  %v1718 = load ptr, ptr %v1717, align 8, !tbaa !3
  %v1719 = getelementptr i8, ptr %env, i64 32
  %v1720 = load ptr, ptr %v1719, align 8, !tbaa !3
  %v1721 = getelementptr i8, ptr %env, i64 40
  %v1722 = load ptr, ptr %v1721, align 8, !tbaa !3
  %v1723 = getelementptr i8, ptr %env, i64 48
  %v1724 = load ptr, ptr %v1723, align 8, !tbaa !3
  %v1733 = call ptr @mlf_env_new(i64 3)
  %v1734 = getelementptr i8, ptr %v1733, i64 24
  store ptr %v1718, ptr %v1734, align 8, !tbaa !3
  %v1735 = getelementptr i8, ptr %v1733, i64 32
  store ptr %v1724, ptr %v1735, align 8, !tbaa !3
  %v1736 = getelementptr i8, ptr %v1733, i64 40
  store ptr %arg, ptr %v1736, align 8, !tbaa !3
  %v1737 = call ptr @mlf_thunk(ptr @mlf.code.1725, ptr %v1733)
  %v1756 = call ptr @mlf_env_new(i64 4)
  %v1757 = getelementptr i8, ptr %v1756, i64 24
  store ptr %v1718, ptr %v1757, align 8, !tbaa !3
  %v1758 = getelementptr i8, ptr %v1756, i64 32
  store ptr %v1720, ptr %v1758, align 8, !tbaa !3
  %v1759 = getelementptr i8, ptr %v1756, i64 40
  store ptr %v1722, ptr %v1759, align 8, !tbaa !3
  %v1760 = getelementptr i8, ptr %v1756, i64 48
  store ptr %v1724, ptr %v1760, align 8, !tbaa !3
  %v1761 = call ptr @mlf_closure(ptr @mlf.code.1738, ptr %v1756)
  %v1762 = call ptr @mlf_prim2(i64 1, ptr %v1737, ptr %v1761)
  ret ptr %v1762
}

define private ptr @mlf.worker.25(ptr %a0, ptr %a1, ptr %a2, ptr %a3) {
entry:
  %v1692 = call ptr @mlf_prim2(i64 10, ptr %a3, ptr %a1)
  %v1693 = icmp eq ptr %v1692, inttoptr (i64 6 to ptr)
  br i1 %v1693, label %yes.1694, label %no.1695
yes.1694:
  %v1697 = call ptr @mlf_prim3(i64 29, ptr %a0, ptr %a1, ptr %a2)
  br label %join.1696
no.1695:
  %v1712 = call ptr @mlf_env_new(i64 2)
  %v1713 = getelementptr i8, ptr %v1712, i64 24
  store ptr %a0, ptr %v1713, align 8, !tbaa !3
  %v1714 = getelementptr i8, ptr %v1712, i64 32
  store ptr %a3, ptr %v1714, align 8, !tbaa !3
  %v1715 = call ptr @mlf_thunk(ptr @mlf.code.1698, ptr %v1712)
  %v1763 = call ptr @mlf_env_new(i64 4)
  %v1764 = getelementptr i8, ptr %v1763, i64 24
  store ptr %a0, ptr %v1764, align 8, !tbaa !3
  %v1765 = getelementptr i8, ptr %v1763, i64 32
  store ptr %a1, ptr %v1765, align 8, !tbaa !3
  %v1766 = getelementptr i8, ptr %v1763, i64 40
  store ptr %a2, ptr %v1766, align 8, !tbaa !3
  %v1767 = getelementptr i8, ptr %v1763, i64 48
  store ptr %a3, ptr %v1767, align 8, !tbaa !3
  %v1768 = call ptr @mlf_closure(ptr @mlf.code.1716, ptr %v1763)
  %v1769 = call ptr @mlf_prim2(i64 1, ptr %v1715, ptr %v1768)
  br label %join.1696
join.1696:
  %v1770 = phi ptr [ %v1697, %yes.1694 ], [ %v1769, %no.1695 ]
  ret ptr %v1770
}

define private ptr @mlf.numeric.entry.1666(ptr %env, ptr %arg) {
entry:
  %v1667 = getelementptr i8, ptr %env, i64 24
  %v1668 = load ptr, ptr %v1667, align 8, !tbaa !3
  %v1669 = getelementptr i8, ptr %env, i64 32
  %v1670 = load ptr, ptr %v1669, align 8, !tbaa !3
  %v1671 = getelementptr i8, ptr %env, i64 40
  %v1672 = load ptr, ptr %v1671, align 8, !tbaa !3
  %v1673 = getelementptr i8, ptr %env, i64 48
  %v1674 = load ptr, ptr %v1673, align 8, !tbaa !3
  %v1675 = call ptr @mlf_peek(ptr %v1668)
  %v1676 = call ptr @mlf_peek(ptr %v1670)
  %v1677 = call ptr @mlf_peek(ptr %v1672)
  %v1678 = call ptr @mlf_peek(ptr %v1674)
  %v1679 = icmp ne ptr %v1675, null
  %v1680 = icmp ne ptr %v1676, null
  %v1681 = icmp ne ptr %v1677, null
  %v1682 = icmp ne ptr %v1678, null
  %v1683 = and i1 true, %v1679
  %v1684 = and i1 %v1683, %v1680
  %v1685 = and i1 %v1684, %v1681
  %v1686 = and i1 %v1685, %v1682
  br i1 %v1686, label %yes.1687, label %no.1688
yes.1687:
  %v1690 = call ptr @mlf.numeric.25(ptr %v1675, ptr %v1676, ptr %v1677, ptr %v1678)
  %v1691 = call ptr @mlf_prim1(i64 0, ptr %v1690)
  br label %join.1689
no.1688:
  %v1771 = call ptr @mlf_force(ptr %v1670)
  %v1772 = call ptr @mlf_force(ptr %v1674)
  %v1773 = call ptr @mlf.worker.25(ptr %v1668, ptr %v1771, ptr %v1672, ptr %v1772)
  br label %join.1689
join.1689:
  %v1774 = phi ptr [ %v1691, %yes.1687 ], [ %v1773, %no.1688 ]
  ret ptr %v1774
}

define private ptr @mlf.code.1659(ptr %env, ptr %arg) {
entry:
  %v1660 = getelementptr i8, ptr %env, i64 24
  %v1661 = load ptr, ptr %v1660, align 8, !tbaa !3
  %v1662 = getelementptr i8, ptr %env, i64 32
  %v1663 = load ptr, ptr %v1662, align 8, !tbaa !3
  %v1664 = getelementptr i8, ptr %env, i64 40
  %v1665 = load ptr, ptr %v1664, align 8, !tbaa !3
  %v1775 = call ptr @mlf_force(ptr %v1663)
  %v1776 = call ptr @mlf_env_new(i64 4)
  %v1777 = getelementptr i8, ptr %v1776, i64 24
  store ptr %v1661, ptr %v1777, align 8, !tbaa !3
  %v1778 = getelementptr i8, ptr %v1776, i64 32
  store ptr %v1775, ptr %v1778, align 8, !tbaa !3
  %v1779 = getelementptr i8, ptr %v1776, i64 40
  store ptr %v1665, ptr %v1779, align 8, !tbaa !3
  %v1780 = getelementptr i8, ptr %v1776, i64 48
  store ptr inttoptr (i64 1 to ptr), ptr %v1780, align 8, !tbaa !3
  %v1781 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1666, ptr %v1776)
  ret ptr %v1781
}

define private ptr @mlf.code.1796(ptr %env, ptr %arg) {
entry:
  %v1797 = getelementptr i8, ptr %env, i64 24
  %v1798 = load ptr, ptr %v1797, align 8, !tbaa !3
  %v1799 = getelementptr i8, ptr %env, i64 32
  %v1800 = load ptr, ptr %v1799, align 8, !tbaa !3
  %v1801 = call ptr @mlf_prim2(i64 28, ptr %v1798, ptr %v1800)
  ret ptr %v1801
}

define private ptr @mlf.code.1829(ptr %env, ptr %arg) {
entry:
  %v1830 = getelementptr i8, ptr %env, i64 24
  %v1831 = load ptr, ptr %v1830, align 8, !tbaa !3
  %v1832 = call ptr @mlf_force(ptr %v1831)
  %v1833 = call ptr @mlf_prim2(i64 8, ptr %v1832, ptr inttoptr (i64 3 to ptr))
  ret ptr %v1833
}

define private ptr @mlf.code.1822(ptr %env, ptr %arg) {
entry:
  %v1823 = getelementptr i8, ptr %env, i64 24
  %v1824 = load ptr, ptr %v1823, align 8, !tbaa !3
  %v1825 = getelementptr i8, ptr %env, i64 32
  %v1826 = load ptr, ptr %v1825, align 8, !tbaa !3
  %v1827 = getelementptr i8, ptr %env, i64 40
  %v1828 = load ptr, ptr %v1827, align 8, !tbaa !3
  %v1834 = call ptr @mlf_env_new(i64 1)
  %v1835 = getelementptr i8, ptr %v1834, i64 24
  store ptr %v1828, ptr %v1835, align 8, !tbaa !3
  %v1836 = call ptr @mlf_thunk(ptr @mlf.code.1829, ptr %v1834)
  %v1837 = call ptr @mlf_prim3(i64 29, ptr %v1824, ptr %v1826, ptr %v1836)
  ret ptr %v1837
}

define private ptr @mlf.code.1843(ptr %env, ptr %arg) {
entry:
  %v1844 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 6 to ptr))
  ret ptr %v1844
}

define private ptr @mlf.code.1847(ptr %env, ptr %arg) {
entry:
  %v1848 = getelementptr i8, ptr %env, i64 24
  %v1849 = load ptr, ptr %v1848, align 8, !tbaa !3
  %v1850 = getelementptr i8, ptr %env, i64 32
  %v1851 = load ptr, ptr %v1850, align 8, !tbaa !3
  %v1852 = call ptr @mlf_prim3(i64 29, ptr %v1849, ptr %v1851, ptr inttoptr (i64 1 to ptr))
  ret ptr %v1852
}

define private ptr @mlf.code.1857(ptr %env, ptr %arg) {
entry:
  %v1858 = getelementptr i8, ptr %env, i64 24
  %v1859 = load ptr, ptr %v1858, align 8, !tbaa !3
  %v1860 = getelementptr i8, ptr %env, i64 32
  %v1861 = load ptr, ptr %v1860, align 8, !tbaa !3
  %v1862 = getelementptr i8, ptr %env, i64 40
  %v1863 = load ptr, ptr %v1862, align 8, !tbaa !3
  %v1864 = getelementptr i8, ptr %env, i64 48
  %v1865 = load ptr, ptr %v1864, align 8, !tbaa !3
  %v1866 = call ptr @mlf_force(ptr %v1863)
  %v1867 = call ptr @mlf_force(ptr %v1865)
  %v1868 = call ptr @mlf_prim2(i64 8, ptr %v1867, ptr inttoptr (i64 3 to ptr))
  %v1869 = call ptr @mlf_env_new(i64 4)
  %v1870 = getelementptr i8, ptr %v1869, i64 24
  store ptr %v1859, ptr %v1870, align 8, !tbaa !3
  %v1871 = getelementptr i8, ptr %v1869, i64 32
  store ptr %v1861, ptr %v1871, align 8, !tbaa !3
  %v1872 = getelementptr i8, ptr %v1869, i64 40
  store ptr %v1866, ptr %v1872, align 8, !tbaa !3
  %v1873 = getelementptr i8, ptr %v1869, i64 48
  store ptr %v1868, ptr %v1873, align 8, !tbaa !3
  %v1874 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1611, ptr %v1869)
  ret ptr %v1874
}

define private ptr @mlf.code.1806(ptr %env, ptr %arg) {
entry:
  %v1807 = getelementptr i8, ptr %env, i64 24
  %v1808 = load ptr, ptr %v1807, align 8, !tbaa !3
  %v1809 = getelementptr i8, ptr %env, i64 32
  %v1810 = load ptr, ptr %v1809, align 8, !tbaa !3
  %v1811 = getelementptr i8, ptr %env, i64 40
  %v1812 = load ptr, ptr %v1811, align 8, !tbaa !3
  %v1813 = getelementptr i8, ptr %env, i64 48
  %v1814 = load ptr, ptr %v1813, align 8, !tbaa !3
  %v1815 = call ptr @mlf_force(ptr %arg)
  %v1816 = call ptr @mlf_force(ptr %v1814)
  %v1817 = call ptr @mlf_prim2(i64 11, ptr %v1815, ptr %v1816)
  %v1818 = icmp eq ptr %v1817, inttoptr (i64 6 to ptr)
  br i1 %v1818, label %yes.1819, label %no.1820
yes.1819:
  %v1838 = call ptr @mlf_env_new(i64 3)
  %v1839 = getelementptr i8, ptr %v1838, i64 24
  store ptr %v1810, ptr %v1839, align 8, !tbaa !3
  %v1840 = getelementptr i8, ptr %v1838, i64 32
  store ptr %v1816, ptr %v1840, align 8, !tbaa !3
  %v1841 = getelementptr i8, ptr %v1838, i64 40
  store ptr %v1815, ptr %v1841, align 8, !tbaa !3
  %v1842 = call ptr @mlf_thunk(ptr @mlf.code.1822, ptr %v1838)
  %v1845 = call ptr @mlf_closure(ptr @mlf.code.1843, ptr null)
  %v1846 = call ptr @mlf_prim2(i64 1, ptr %v1842, ptr %v1845)
  br label %join.1821
no.1820:
  %v1853 = call ptr @mlf_env_new(i64 2)
  %v1854 = getelementptr i8, ptr %v1853, i64 24
  store ptr %v1810, ptr %v1854, align 8, !tbaa !3
  %v1855 = getelementptr i8, ptr %v1853, i64 32
  store ptr %v1816, ptr %v1855, align 8, !tbaa !3
  %v1856 = call ptr @mlf_thunk(ptr @mlf.code.1847, ptr %v1853)
  %v1875 = call ptr @mlf_env_new(i64 4)
  %v1876 = getelementptr i8, ptr %v1875, i64 24
  store ptr %v1808, ptr %v1876, align 8, !tbaa !3
  %v1877 = getelementptr i8, ptr %v1875, i64 32
  store ptr %v1810, ptr %v1877, align 8, !tbaa !3
  %v1878 = getelementptr i8, ptr %v1875, i64 40
  store ptr %v1812, ptr %v1878, align 8, !tbaa !3
  %v1879 = getelementptr i8, ptr %v1875, i64 48
  store ptr %v1816, ptr %v1879, align 8, !tbaa !3
  %v1880 = call ptr @mlf_closure(ptr @mlf.code.1857, ptr %v1875)
  %v1881 = call ptr @mlf_prim2(i64 1, ptr %v1856, ptr %v1880)
  br label %join.1821
join.1821:
  %v1882 = phi ptr [ %v1846, %yes.1819 ], [ %v1881, %no.1820 ]
  ret ptr %v1882
}

define private ptr @mlf.code.1787(ptr %env, ptr %arg) {
entry:
  %v1788 = getelementptr i8, ptr %env, i64 24
  %v1789 = load ptr, ptr %v1788, align 8, !tbaa !3
  %v1790 = getelementptr i8, ptr %env, i64 32
  %v1791 = load ptr, ptr %v1790, align 8, !tbaa !3
  %v1792 = getelementptr i8, ptr %env, i64 40
  %v1793 = load ptr, ptr %v1792, align 8, !tbaa !3
  %v1794 = getelementptr i8, ptr %env, i64 48
  %v1795 = load ptr, ptr %v1794, align 8, !tbaa !3
  %v1802 = call ptr @mlf_env_new(i64 2)
  %v1803 = getelementptr i8, ptr %v1802, i64 24
  store ptr %v1791, ptr %v1803, align 8, !tbaa !3
  %v1804 = getelementptr i8, ptr %v1802, i64 32
  store ptr %v1795, ptr %v1804, align 8, !tbaa !3
  %v1805 = call ptr @mlf_thunk(ptr @mlf.code.1796, ptr %v1802)
  %v1883 = call ptr @mlf_env_new(i64 4)
  %v1884 = getelementptr i8, ptr %v1883, i64 24
  store ptr %v1789, ptr %v1884, align 8, !tbaa !3
  %v1885 = getelementptr i8, ptr %v1883, i64 32
  store ptr %v1791, ptr %v1885, align 8, !tbaa !3
  %v1886 = getelementptr i8, ptr %v1883, i64 40
  store ptr %v1793, ptr %v1886, align 8, !tbaa !3
  %v1887 = getelementptr i8, ptr %v1883, i64 48
  store ptr %v1795, ptr %v1887, align 8, !tbaa !3
  %v1888 = call ptr @mlf_closure(ptr @mlf.code.1806, ptr %v1883)
  %v1889 = call ptr @mlf_prim2(i64 1, ptr %v1805, ptr %v1888)
  ret ptr %v1889
}

define private ptr @mlf.code.1650(ptr %env, ptr %arg) {
entry:
  %v1651 = getelementptr i8, ptr %env, i64 24
  %v1652 = load ptr, ptr %v1651, align 8, !tbaa !3
  %v1653 = getelementptr i8, ptr %env, i64 32
  %v1654 = load ptr, ptr %v1653, align 8, !tbaa !3
  %v1655 = getelementptr i8, ptr %env, i64 40
  %v1656 = load ptr, ptr %v1655, align 8, !tbaa !3
  %v1657 = getelementptr i8, ptr %env, i64 48
  %v1658 = load ptr, ptr %v1657, align 8, !tbaa !3
  %v1782 = call ptr @mlf_env_new(i64 3)
  %v1783 = getelementptr i8, ptr %v1782, i64 24
  store ptr %v1652, ptr %v1783, align 8, !tbaa !3
  %v1784 = getelementptr i8, ptr %v1782, i64 32
  store ptr %v1658, ptr %v1784, align 8, !tbaa !3
  %v1785 = getelementptr i8, ptr %v1782, i64 40
  store ptr %arg, ptr %v1785, align 8, !tbaa !3
  %v1786 = call ptr @mlf_thunk(ptr @mlf.code.1659, ptr %v1782)
  %v1890 = call ptr @mlf_env_new(i64 4)
  %v1891 = getelementptr i8, ptr %v1890, i64 24
  store ptr %v1652, ptr %v1891, align 8, !tbaa !3
  %v1892 = getelementptr i8, ptr %v1890, i64 32
  store ptr %v1654, ptr %v1892, align 8, !tbaa !3
  %v1893 = getelementptr i8, ptr %v1890, i64 40
  store ptr %v1656, ptr %v1893, align 8, !tbaa !3
  %v1894 = getelementptr i8, ptr %v1890, i64 48
  store ptr %v1658, ptr %v1894, align 8, !tbaa !3
  %v1895 = call ptr @mlf_closure(ptr @mlf.code.1787, ptr %v1890)
  %v1896 = call ptr @mlf_prim2(i64 1, ptr %v1786, ptr %v1895)
  ret ptr %v1896
}

define private ptr @mlf.worker.32(ptr %a0, ptr %a1, ptr %a2, ptr %a3) {
entry:
  %v1637 = call ptr @mlf_prim2(i64 10, ptr %a3, ptr %a2)
  %v1638 = icmp eq ptr %v1637, inttoptr (i64 6 to ptr)
  br i1 %v1638, label %yes.1639, label %no.1640
yes.1639:
  %v1642 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 2 to ptr))
  br label %join.1641
no.1640:
  %v1647 = call ptr @mlf_env_new(i64 1)
  %v1648 = getelementptr i8, ptr %v1647, i64 24
  store ptr %a0, ptr %v1648, align 8, !tbaa !3
  %v1649 = call ptr @mlf_thunk(ptr @mlf.code.1643, ptr %v1647)
  %v1897 = call ptr @mlf_env_new(i64 4)
  %v1898 = getelementptr i8, ptr %v1897, i64 24
  store ptr %a0, ptr %v1898, align 8, !tbaa !3
  %v1899 = getelementptr i8, ptr %v1897, i64 32
  store ptr %a1, ptr %v1899, align 8, !tbaa !3
  %v1900 = getelementptr i8, ptr %v1897, i64 40
  store ptr %a2, ptr %v1900, align 8, !tbaa !3
  %v1901 = getelementptr i8, ptr %v1897, i64 48
  store ptr %a3, ptr %v1901, align 8, !tbaa !3
  %v1902 = call ptr @mlf_closure(ptr @mlf.code.1650, ptr %v1897)
  %v1903 = call ptr @mlf_prim2(i64 1, ptr %v1649, ptr %v1902)
  br label %join.1641
join.1641:
  %v1904 = phi ptr [ %v1642, %yes.1639 ], [ %v1903, %no.1640 ]
  ret ptr %v1904
}

define private ptr @mlf.numeric.entry.1611(ptr %env, ptr %arg) {
entry:
  %v1612 = getelementptr i8, ptr %env, i64 24
  %v1613 = load ptr, ptr %v1612, align 8, !tbaa !3
  %v1614 = getelementptr i8, ptr %env, i64 32
  %v1615 = load ptr, ptr %v1614, align 8, !tbaa !3
  %v1616 = getelementptr i8, ptr %env, i64 40
  %v1617 = load ptr, ptr %v1616, align 8, !tbaa !3
  %v1618 = getelementptr i8, ptr %env, i64 48
  %v1619 = load ptr, ptr %v1618, align 8, !tbaa !3
  %v1620 = call ptr @mlf_peek(ptr %v1613)
  %v1621 = call ptr @mlf_peek(ptr %v1615)
  %v1622 = call ptr @mlf_peek(ptr %v1617)
  %v1623 = call ptr @mlf_peek(ptr %v1619)
  %v1624 = icmp ne ptr %v1620, null
  %v1625 = icmp ne ptr %v1621, null
  %v1626 = icmp ne ptr %v1622, null
  %v1627 = icmp ne ptr %v1623, null
  %v1628 = and i1 true, %v1624
  %v1629 = and i1 %v1628, %v1625
  %v1630 = and i1 %v1629, %v1626
  %v1631 = and i1 %v1630, %v1627
  br i1 %v1631, label %yes.1632, label %no.1633
yes.1632:
  %v1635 = call ptr @mlf.numeric.32(ptr %v1620, ptr %v1621, ptr %v1622, ptr %v1623)
  %v1636 = call ptr @mlf_prim1(i64 0, ptr %v1635)
  br label %join.1634
no.1633:
  %v1905 = call ptr @mlf_force(ptr %v1617)
  %v1906 = call ptr @mlf_force(ptr %v1619)
  %v1907 = call ptr @mlf.worker.32(ptr %v1613, ptr %v1615, ptr %v1905, ptr %v1906)
  br label %join.1634
join.1634:
  %v1908 = phi ptr [ %v1636, %yes.1632 ], [ %v1907, %no.1633 ]
  ret ptr %v1908
}

define private ptr @mlf.code.1604(ptr %env, ptr %arg) {
entry:
  %v1605 = getelementptr i8, ptr %env, i64 24
  %v1606 = load ptr, ptr %v1605, align 8, !tbaa !3
  %v1607 = getelementptr i8, ptr %env, i64 32
  %v1608 = load ptr, ptr %v1607, align 8, !tbaa !3
  %v1609 = getelementptr i8, ptr %env, i64 40
  %v1610 = load ptr, ptr %v1609, align 8, !tbaa !3
  %v1909 = call ptr @mlf_force(ptr %v1610)
  %v1910 = call ptr @mlf_env_new(i64 4)
  %v1911 = getelementptr i8, ptr %v1910, i64 24
  store ptr %v1606, ptr %v1911, align 8, !tbaa !3
  %v1912 = getelementptr i8, ptr %v1910, i64 32
  store ptr %v1608, ptr %v1912, align 8, !tbaa !3
  %v1913 = getelementptr i8, ptr %v1910, i64 40
  store ptr %v1909, ptr %v1913, align 8, !tbaa !3
  %v1914 = getelementptr i8, ptr %v1910, i64 48
  store ptr inttoptr (i64 3 to ptr), ptr %v1914, align 8, !tbaa !3
  %v1915 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1611, ptr %v1910)
  ret ptr %v1915
}

define private ptr @mlf.code.1941(ptr %env, ptr %arg) {
entry:
  %v1942 = getelementptr i8, ptr %env, i64 24
  %v1943 = load ptr, ptr %v1942, align 8, !tbaa !3
  %v1944 = call ptr @mlf_force(ptr %v1943)
  %v1945 = call ptr @mlf_prim2(i64 8, ptr %v1944, ptr inttoptr (i64 3 to ptr))
  ret ptr %v1945
}

define private ptr @mlf.code.1921(ptr %env, ptr %arg) {
entry:
  %v1922 = getelementptr i8, ptr %env, i64 24
  %v1923 = load ptr, ptr %v1922, align 8, !tbaa !3
  %v1924 = getelementptr i8, ptr %env, i64 32
  %v1925 = load ptr, ptr %v1924, align 8, !tbaa !3
  %v1926 = getelementptr i8, ptr %env, i64 40
  %v1927 = load ptr, ptr %v1926, align 8, !tbaa !3
  %v1928 = getelementptr i8, ptr %env, i64 48
  %v1929 = load ptr, ptr %v1928, align 8, !tbaa !3
  %v1930 = getelementptr i8, ptr %env, i64 56
  %v1931 = load ptr, ptr %v1930, align 8, !tbaa !3
  %v1932 = getelementptr i8, ptr %env, i64 64
  %v1933 = load ptr, ptr %v1932, align 8, !tbaa !3
  %v1934 = getelementptr i8, ptr %env, i64 72
  %v1935 = load ptr, ptr %v1934, align 8, !tbaa !3
  %v1936 = call ptr @mlf_force(ptr %arg)
  %v1937 = icmp eq ptr %v1936, inttoptr (i64 6 to ptr)
  br i1 %v1937, label %yes.1938, label %no.1939
yes.1938:
  %v1946 = call ptr @mlf_env_new(i64 1)
  %v1947 = getelementptr i8, ptr %v1946, i64 24
  store ptr %v1931, ptr %v1947, align 8, !tbaa !3
  %v1948 = call ptr @mlf_thunk(ptr @mlf.code.1941, ptr %v1946)
  %v1949 = call ptr @mlf_env_new(i64 7)
  %v1950 = getelementptr i8, ptr %v1949, i64 24
  store ptr %v1923, ptr %v1950, align 8, !tbaa !3
  %v1951 = getelementptr i8, ptr %v1949, i64 32
  store ptr %v1925, ptr %v1951, align 8, !tbaa !3
  %v1952 = getelementptr i8, ptr %v1949, i64 40
  store ptr %v1927, ptr %v1952, align 8, !tbaa !3
  %v1953 = getelementptr i8, ptr %v1949, i64 48
  store ptr %v1929, ptr %v1953, align 8, !tbaa !3
  %v1954 = getelementptr i8, ptr %v1949, i64 56
  store ptr %v1948, ptr %v1954, align 8, !tbaa !3
  %v1955 = getelementptr i8, ptr %v1949, i64 64
  store ptr %v1933, ptr %v1955, align 8, !tbaa !3
  %v1956 = getelementptr i8, ptr %v1949, i64 72
  store ptr %v1935, ptr %v1956, align 8, !tbaa !3
  %v1957 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.251, ptr %v1949)
  br label %join.1940
no.1939:
  %v1958 = call ptr @mlf_constructor2(i64 1, ptr %v1933, ptr %v1935)
  %v1959 = call ptr @mlf_prim1(i64 0, ptr %v1958)
  br label %join.1940
join.1940:
  %v1960 = phi ptr [ %v1957, %yes.1938 ], [ %v1959, %no.1939 ]
  ret ptr %v1960
}

define private ptr @mlf.code.1547(ptr %env, ptr %arg) {
entry:
  %v1548 = getelementptr i8, ptr %env, i64 24
  %v1549 = load ptr, ptr %v1548, align 8, !tbaa !3
  %v1550 = getelementptr i8, ptr %env, i64 32
  %v1551 = load ptr, ptr %v1550, align 8, !tbaa !3
  %v1552 = getelementptr i8, ptr %env, i64 40
  %v1553 = load ptr, ptr %v1552, align 8, !tbaa !3
  %v1554 = getelementptr i8, ptr %env, i64 48
  %v1555 = load ptr, ptr %v1554, align 8, !tbaa !3
  %v1556 = getelementptr i8, ptr %env, i64 56
  %v1557 = load ptr, ptr %v1556, align 8, !tbaa !3
  %v1558 = getelementptr i8, ptr %env, i64 64
  %v1559 = load ptr, ptr %v1558, align 8, !tbaa !3
  %v1560 = getelementptr i8, ptr %env, i64 72
  %v1561 = load ptr, ptr %v1560, align 8, !tbaa !3
  %v1562 = call ptr @mlf_force(ptr %v1557)
  %v1563 = call ptr @mlf_prim2(i64 16, ptr %v1562, ptr inttoptr (i64 5 to ptr))
  %v1564 = call ptr @mlf_prim2(i64 10, ptr %v1563, ptr inttoptr (i64 1 to ptr))
  %v1565 = icmp eq ptr %v1564, inttoptr (i64 6 to ptr)
  br i1 %v1565, label %yes.1566, label %no.1567
yes.1566:
  %v1569 = call ptr @mlf_force(ptr %v1559)
  %v1570 = call ptr @mlf_force(ptr %arg)
  %v1571 = call ptr @mlf_prim2(i64 8, ptr %v1569, ptr %v1570)
  br label %join.1568
no.1567:
  %v1572 = call ptr @mlf_force(ptr %v1559)
  %v1573 = call ptr @mlf_force(ptr %arg)
  %v1574 = call ptr @mlf_prim2(i64 9, ptr %v1572, ptr %v1573)
  br label %join.1568
join.1568:
  %v1575 = phi ptr [ %v1571, %yes.1566 ], [ %v1574, %no.1567 ]
  %v1589 = call ptr @mlf_env_new(i64 2)
  %v1590 = getelementptr i8, ptr %v1589, i64 24
  store ptr %v1561, ptr %v1590, align 8, !tbaa !3
  %v1591 = getelementptr i8, ptr %v1589, i64 32
  store ptr %arg, ptr %v1591, align 8, !tbaa !3
  %v1592 = call ptr @mlf_thunk(ptr @mlf.code.1576, ptr %v1589)
  %v1593 = call ptr @mlf_prim2(i64 10, ptr %v1575, ptr %v1575)
  %v1594 = icmp eq ptr %v1593, inttoptr (i64 6 to ptr)
  br i1 %v1594, label %yes.1595, label %no.1596
yes.1595:
  %v1598 = call ptr @mlf_force(ptr %v1592)
  %v1599 = call ptr @mlf_prim2(i64 10, ptr %v1598, ptr %v1598)
  %v1600 = icmp eq ptr %v1599, inttoptr (i64 6 to ptr)
  br i1 %v1600, label %yes.1601, label %no.1602
yes.1601:
  %v1916 = call ptr @mlf_env_new(i64 3)
  %v1917 = getelementptr i8, ptr %v1916, i64 24
  store ptr %v1549, ptr %v1917, align 8, !tbaa !3
  %v1918 = getelementptr i8, ptr %v1916, i64 32
  store ptr %v1553, ptr %v1918, align 8, !tbaa !3
  %v1919 = getelementptr i8, ptr %v1916, i64 40
  store ptr %v1555, ptr %v1919, align 8, !tbaa !3
  %v1920 = call ptr @mlf_thunk(ptr @mlf.code.1604, ptr %v1916)
  %v1961 = call ptr @mlf_env_new(i64 7)
  %v1962 = getelementptr i8, ptr %v1961, i64 24
  store ptr %v1549, ptr %v1962, align 8, !tbaa !3
  %v1963 = getelementptr i8, ptr %v1961, i64 32
  store ptr %v1551, ptr %v1963, align 8, !tbaa !3
  %v1964 = getelementptr i8, ptr %v1961, i64 40
  store ptr %v1553, ptr %v1964, align 8, !tbaa !3
  %v1965 = getelementptr i8, ptr %v1961, i64 48
  store ptr %v1555, ptr %v1965, align 8, !tbaa !3
  %v1966 = getelementptr i8, ptr %v1961, i64 56
  store ptr %v1562, ptr %v1966, align 8, !tbaa !3
  %v1967 = getelementptr i8, ptr %v1961, i64 64
  store ptr %v1575, ptr %v1967, align 8, !tbaa !3
  %v1968 = getelementptr i8, ptr %v1961, i64 72
  store ptr %v1598, ptr %v1968, align 8, !tbaa !3
  %v1969 = call ptr @mlf_closure(ptr @mlf.code.1921, ptr %v1961)
  %v1970 = call ptr @mlf_prim2(i64 1, ptr %v1920, ptr %v1969)
  br label %join.1603
no.1602:
  %v1971 = call ptr @mlf_constructor2(i64 1, ptr inttoptr (i64 1 to ptr), ptr inttoptr (i64 1 to ptr))
  %v1972 = call ptr @mlf_prim1(i64 0, ptr %v1971)
  br label %join.1603
join.1603:
  %v1973 = phi ptr [ %v1970, %yes.1601 ], [ %v1972, %no.1602 ]
  br label %join.1597
no.1596:
  %v1974 = call ptr @mlf_constructor2(i64 1, ptr inttoptr (i64 1 to ptr), ptr inttoptr (i64 1 to ptr))
  %v1975 = call ptr @mlf_prim1(i64 0, ptr %v1974)
  br label %join.1597
join.1597:
  %v1976 = phi ptr [ %v1973, %join.1603 ], [ %v1975, %no.1596 ]
  ret ptr %v1976
}

define private ptr @mlf.code.1296(ptr %env, ptr %arg) {
entry:
  %v1297 = getelementptr i8, ptr %env, i64 24
  %v1298 = load ptr, ptr %v1297, align 8, !tbaa !3
  %v1299 = getelementptr i8, ptr %env, i64 32
  %v1300 = load ptr, ptr %v1299, align 8, !tbaa !3
  %v1301 = getelementptr i8, ptr %env, i64 40
  %v1302 = load ptr, ptr %v1301, align 8, !tbaa !3
  %v1303 = getelementptr i8, ptr %env, i64 48
  %v1304 = load ptr, ptr %v1303, align 8, !tbaa !3
  %v1305 = getelementptr i8, ptr %env, i64 56
  %v1306 = load ptr, ptr %v1305, align 8, !tbaa !3
  %v1307 = getelementptr i8, ptr %env, i64 64
  %v1308 = load ptr, ptr %v1307, align 8, !tbaa !3
  %v1309 = getelementptr i8, ptr %env, i64 72
  %v1310 = load ptr, ptr %v1309, align 8, !tbaa !3
  %v1544 = call ptr @mlf_env_new(i64 1)
  %v1545 = getelementptr i8, ptr %v1544, i64 24
  store ptr %v1300, ptr %v1545, align 8, !tbaa !3
  %v1546 = call ptr @mlf_thunk(ptr @mlf.code.1311, ptr %v1544)
  %v1977 = call ptr @mlf_env_new(i64 7)
  %v1978 = getelementptr i8, ptr %v1977, i64 24
  store ptr %v1298, ptr %v1978, align 8, !tbaa !3
  %v1979 = getelementptr i8, ptr %v1977, i64 32
  store ptr %v1300, ptr %v1979, align 8, !tbaa !3
  %v1980 = getelementptr i8, ptr %v1977, i64 40
  store ptr %v1302, ptr %v1980, align 8, !tbaa !3
  %v1981 = getelementptr i8, ptr %v1977, i64 48
  store ptr %v1304, ptr %v1981, align 8, !tbaa !3
  %v1982 = getelementptr i8, ptr %v1977, i64 56
  store ptr %v1306, ptr %v1982, align 8, !tbaa !3
  %v1983 = getelementptr i8, ptr %v1977, i64 64
  store ptr %v1308, ptr %v1983, align 8, !tbaa !3
  %v1984 = getelementptr i8, ptr %v1977, i64 72
  store ptr %v1310, ptr %v1984, align 8, !tbaa !3
  %v1985 = call ptr @mlf_closure(ptr @mlf.code.1547, ptr %v1977)
  %v1986 = call ptr @mlf_prim2(i64 1, ptr %v1546, ptr %v1985)
  ret ptr %v1986
}

define private ptr @mlf.worker.42(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6) {
entry:
  %v1291 = call ptr @mlf_env_new(i64 3)
  %v1292 = getelementptr i8, ptr %v1291, i64 24
  store ptr %a0, ptr %v1292, align 8, !tbaa !3
  %v1293 = getelementptr i8, ptr %v1291, i64 32
  store ptr %a1, ptr %v1293, align 8, !tbaa !3
  %v1294 = getelementptr i8, ptr %v1291, i64 40
  store ptr %a3, ptr %v1294, align 8, !tbaa !3
  %v1295 = call ptr @mlf_thunk(ptr @mlf.code.1176, ptr %v1291)
  %v1987 = call ptr @mlf_env_new(i64 7)
  %v1988 = getelementptr i8, ptr %v1987, i64 24
  store ptr %a0, ptr %v1988, align 8, !tbaa !3
  %v1989 = getelementptr i8, ptr %v1987, i64 32
  store ptr %a1, ptr %v1989, align 8, !tbaa !3
  %v1990 = getelementptr i8, ptr %v1987, i64 40
  store ptr %a2, ptr %v1990, align 8, !tbaa !3
  %v1991 = getelementptr i8, ptr %v1987, i64 48
  store ptr %a3, ptr %v1991, align 8, !tbaa !3
  %v1992 = getelementptr i8, ptr %v1987, i64 56
  store ptr %a4, ptr %v1992, align 8, !tbaa !3
  %v1993 = getelementptr i8, ptr %v1987, i64 64
  store ptr %a5, ptr %v1993, align 8, !tbaa !3
  %v1994 = getelementptr i8, ptr %v1987, i64 72
  store ptr %a6, ptr %v1994, align 8, !tbaa !3
  %v1995 = call ptr @mlf_closure(ptr @mlf.code.1296, ptr %v1987)
  %v1996 = call ptr @mlf_prim2(i64 1, ptr %v1295, ptr %v1995)
  ret ptr %v1996
}

define private ptr @mlf.numeric.entry.251(ptr %env, ptr %arg) {
entry:
  %v252 = getelementptr i8, ptr %env, i64 24
  %v253 = load ptr, ptr %v252, align 8, !tbaa !3
  %v254 = getelementptr i8, ptr %env, i64 32
  %v255 = load ptr, ptr %v254, align 8, !tbaa !3
  %v256 = getelementptr i8, ptr %env, i64 40
  %v257 = load ptr, ptr %v256, align 8, !tbaa !3
  %v258 = getelementptr i8, ptr %env, i64 48
  %v259 = load ptr, ptr %v258, align 8, !tbaa !3
  %v260 = getelementptr i8, ptr %env, i64 56
  %v261 = load ptr, ptr %v260, align 8, !tbaa !3
  %v262 = getelementptr i8, ptr %env, i64 64
  %v263 = load ptr, ptr %v262, align 8, !tbaa !3
  %v264 = getelementptr i8, ptr %env, i64 72
  %v265 = load ptr, ptr %v264, align 8, !tbaa !3
  %v266 = call ptr @mlf_peek(ptr %v253)
  %v267 = call ptr @mlf_peek(ptr %v255)
  %v268 = call ptr @mlf_peek(ptr %v257)
  %v269 = call ptr @mlf_peek(ptr %v259)
  %v270 = call ptr @mlf_peek(ptr %v261)
  %v271 = call ptr @mlf_peek(ptr %v263)
  %v272 = call ptr @mlf_peek(ptr %v265)
  %v273 = icmp ne ptr %v266, null
  %v274 = icmp ne ptr %v267, null
  %v275 = icmp ne ptr %v268, null
  %v276 = icmp ne ptr %v269, null
  %v277 = icmp ne ptr %v270, null
  %v278 = icmp ne ptr %v271, null
  %v279 = icmp ne ptr %v272, null
  %v280 = and i1 true, %v273
  %v281 = and i1 %v280, %v274
  %v282 = and i1 %v281, %v275
  %v283 = and i1 %v282, %v276
  %v284 = and i1 %v283, %v277
  %v285 = and i1 %v284, %v278
  %v286 = and i1 %v285, %v279
  br i1 %v286, label %yes.287, label %no.288
yes.287:
  %v1174 = call ptr @mlf.numeric.42(ptr %v266, ptr %v267, ptr %v268, ptr %v269, ptr %v270, ptr %v271, ptr %v272)
  %v1175 = call ptr @mlf_prim1(i64 0, ptr %v1174)
  br label %join.289
no.288:
  %v1997 = call ptr @mlf.worker.42(ptr %v253, ptr %v255, ptr %v257, ptr %v259, ptr %v261, ptr %v263, ptr %v265)
  br label %join.289
join.289:
  %v1998 = phi ptr [ %v1175, %yes.287 ], [ %v1997, %no.288 ]
  ret ptr %v1998
}

define private ptr @mlf.code.242(ptr %env, ptr %arg) {
entry:
  %v243 = getelementptr i8, ptr %env, i64 24
  %v244 = load ptr, ptr %v243, align 8, !tbaa !3
  %v245 = getelementptr i8, ptr %env, i64 32
  %v246 = load ptr, ptr %v245, align 8, !tbaa !3
  %v247 = getelementptr i8, ptr %env, i64 40
  %v248 = load ptr, ptr %v247, align 8, !tbaa !3
  %v249 = getelementptr i8, ptr %env, i64 48
  %v250 = load ptr, ptr %v249, align 8, !tbaa !3
  %v1999 = call ptr @mlf_env_new(i64 7)
  %v2000 = getelementptr i8, ptr %v1999, i64 24
  store ptr %v246, ptr %v2000, align 8, !tbaa !3
  %v2001 = getelementptr i8, ptr %v1999, i64 32
  store ptr %v248, ptr %v2001, align 8, !tbaa !3
  %v2002 = getelementptr i8, ptr %v1999, i64 40
  store ptr %v250, ptr %v2002, align 8, !tbaa !3
  %v2003 = getelementptr i8, ptr %v1999, i64 48
  store ptr %v244, ptr %v2003, align 8, !tbaa !3
  %v2004 = getelementptr i8, ptr %v1999, i64 56
  store ptr inttoptr (i64 1 to ptr), ptr %v2004, align 8, !tbaa !3
  %v2005 = getelementptr i8, ptr %v1999, i64 64
  store ptr inttoptr (i64 1 to ptr), ptr %v2005, align 8, !tbaa !3
  %v2006 = getelementptr i8, ptr %v1999, i64 72
  store ptr inttoptr (i64 1 to ptr), ptr %v2006, align 8, !tbaa !3
  %v2007 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.251, ptr %v1999)
  ret ptr %v2007
}

define private ptr @mlf.code.2035(ptr %env, ptr %arg) {
entry:
  %v2036 = getelementptr i8, ptr %env, i64 24
  %v2037 = load ptr, ptr %v2036, align 8, !tbaa !3
  %v2038 = call ptr @mlf_prim1(i64 5, ptr %v2037)
  ret ptr %v2038
}

define private ptr @mlf.code.2047(ptr %env, ptr %arg) {
entry:
  %v2048 = getelementptr i8, ptr %env, i64 24
  %v2049 = load ptr, ptr %v2048, align 8, !tbaa !3
  %v2050 = getelementptr i8, ptr %env, i64 32
  %v2051 = load ptr, ptr %v2050, align 8, !tbaa !3
  %v2053 = call ptr @mlf_string(ptr @mlf.bytes.2052, i64 12)
  %v2054 = call ptr @mlf_force(ptr %v2049)
  %v2055 = call ptr @mlf_prim1(i64 7, ptr %v2054)
  %v2057 = call ptr @mlf_string(ptr @mlf.bytes.2056, i64 4)
  %v2058 = call ptr @mlf_force(ptr %v2051)
  %v2059 = call ptr @mlf_prim1(i64 7, ptr %v2058)
  %v2060 = call ptr @mlf_prim2(i64 6, ptr %v2057, ptr %v2059)
  %v2061 = call ptr @mlf_prim2(i64 6, ptr %v2055, ptr %v2060)
  %v2062 = call ptr @mlf_prim2(i64 6, ptr %v2053, ptr %v2061)
  ret ptr %v2062
}

define private ptr @mlf.code.2042(ptr %env, ptr %arg) {
entry:
  %v2043 = getelementptr i8, ptr %env, i64 24
  %v2044 = load ptr, ptr %v2043, align 8, !tbaa !3
  %v2045 = getelementptr i8, ptr %env, i64 32
  %v2046 = load ptr, ptr %v2045, align 8, !tbaa !3
  %v2063 = call ptr @mlf_env_new(i64 2)
  %v2064 = getelementptr i8, ptr %v2063, i64 24
  store ptr %v2044, ptr %v2064, align 8, !tbaa !3
  %v2065 = getelementptr i8, ptr %v2063, i64 32
  store ptr %v2046, ptr %v2065, align 8, !tbaa !3
  %v2066 = call ptr @mlf_thunk(ptr @mlf.code.2047, ptr %v2063)
  %v2067 = call ptr @mlf_prim1(i64 3, ptr %v2066)
  ret ptr %v2067
}

define private ptr @mlf.code.2014(ptr %env, ptr %arg) {
entry:
  %v2015 = getelementptr i8, ptr %env, i64 24
  %v2016 = load ptr, ptr %v2015, align 8, !tbaa !3
  %v2017 = call ptr @mlf_force(ptr %arg)
  %v2018 = ptrtoint ptr %v2017 to i64
  %v2019 = and i64 %v2018, 7
  %v2020 = icmp eq i64 %v2019, 4
  br i1 %v2020, label %yes.2021, label %no.2022
yes.2021:
  %v2024 = lshr i64 %v2018, 3
  br label %join.2023
no.2022:
  %v2025 = getelementptr i8, ptr %v2017, i64 24
  %v2026 = load i64, ptr %v2025, align 8, !tbaa !3
  br label %join.2023
join.2023:
  %v2027 = phi i64 [ %v2024, %yes.2021 ], [ %v2026, %no.2022 ]
  switch i64 %v2027, label %case.missing.2029 [
    i64 1, label %case.2028
  ]
case.2028:
  %v2031 = getelementptr i8, ptr %v2017, i64 32
  %v2032 = load ptr, ptr %v2031, align 8, !tbaa !3
  %v2033 = getelementptr i8, ptr %v2017, i64 40
  %v2034 = load ptr, ptr %v2033, align 8, !tbaa !3
  %v2039 = call ptr @mlf_env_new(i64 1)
  %v2040 = getelementptr i8, ptr %v2039, i64 24
  store ptr %v2032, ptr %v2040, align 8, !tbaa !3
  %v2041 = call ptr @mlf_thunk(ptr @mlf.code.2035, ptr %v2039)
  %v2068 = call ptr @mlf_env_new(i64 2)
  %v2069 = getelementptr i8, ptr %v2068, i64 24
  store ptr %v2016, ptr %v2069, align 8, !tbaa !3
  %v2070 = getelementptr i8, ptr %v2068, i64 32
  store ptr %v2034, ptr %v2070, align 8, !tbaa !3
  %v2071 = call ptr @mlf_closure(ptr @mlf.code.2042, ptr %v2068)
  %v2072 = call ptr @mlf_prim2(i64 1, ptr %v2041, ptr %v2071)
  br label %case.join.2030
case.missing.2029:
  call void @mlf_match_failure()
  unreachable
case.join.2030:
  %v2073 = phi ptr [ %v2072, %case.2028 ]
  ret ptr %v2073
}

define private ptr @mlf.code.233(ptr %env, ptr %arg) {
entry:
  %v234 = getelementptr i8, ptr %env, i64 24
  %v235 = load ptr, ptr %v234, align 8, !tbaa !3
  %v236 = getelementptr i8, ptr %env, i64 32
  %v237 = load ptr, ptr %v236, align 8, !tbaa !3
  %v238 = getelementptr i8, ptr %env, i64 40
  %v239 = load ptr, ptr %v238, align 8, !tbaa !3
  %v240 = getelementptr i8, ptr %env, i64 48
  %v241 = load ptr, ptr %v240, align 8, !tbaa !3
  %v2008 = call ptr @mlf_env_new(i64 4)
  %v2009 = getelementptr i8, ptr %v2008, i64 24
  store ptr %v235, ptr %v2009, align 8, !tbaa !3
  %v2010 = getelementptr i8, ptr %v2008, i64 32
  store ptr %v237, ptr %v2010, align 8, !tbaa !3
  %v2011 = getelementptr i8, ptr %v2008, i64 40
  store ptr %v239, ptr %v2011, align 8, !tbaa !3
  %v2012 = getelementptr i8, ptr %v2008, i64 48
  store ptr %v241, ptr %v2012, align 8, !tbaa !3
  %v2013 = call ptr @mlf_thunk(ptr @mlf.code.242, ptr %v2008)
  %v2074 = call ptr @mlf_env_new(i64 1)
  %v2075 = getelementptr i8, ptr %v2074, i64 24
  store ptr %v235, ptr %v2075, align 8, !tbaa !3
  %v2076 = call ptr @mlf_closure(ptr @mlf.code.2014, ptr %v2074)
  %v2077 = call ptr @mlf_prim2(i64 1, ptr %v2013, ptr %v2076)
  ret ptr %v2077
}

define private ptr @mlf.code.40(ptr %env, ptr %arg) {
entry:
  %v41 = getelementptr i8, ptr %env, i64 24
  %v42 = load ptr, ptr %v41, align 8, !tbaa !3
  %v43 = getelementptr i8, ptr %env, i64 32
  %v44 = load ptr, ptr %v43, align 8, !tbaa !3
  %v45 = getelementptr i8, ptr %env, i64 40
  %v46 = load ptr, ptr %v45, align 8, !tbaa !3
  %v229 = call ptr @mlf_env_new(i64 2)
  %v230 = getelementptr i8, ptr %v229, i64 24
  store ptr %v42, ptr %v230, align 8, !tbaa !3
  %v231 = getelementptr i8, ptr %v229, i64 32
  store ptr %v44, ptr %v231, align 8, !tbaa !3
  %v232 = call ptr @mlf_thunk(ptr @mlf.code.47, ptr %v229)
  %v2078 = call ptr @mlf_env_new(i64 4)
  %v2079 = getelementptr i8, ptr %v2078, i64 24
  store ptr %v42, ptr %v2079, align 8, !tbaa !3
  %v2080 = getelementptr i8, ptr %v2078, i64 32
  store ptr %v44, ptr %v2080, align 8, !tbaa !3
  %v2081 = getelementptr i8, ptr %v2078, i64 40
  store ptr %v46, ptr %v2081, align 8, !tbaa !3
  %v2082 = getelementptr i8, ptr %v2078, i64 48
  store ptr %arg, ptr %v2082, align 8, !tbaa !3
  %v2083 = call ptr @mlf_closure(ptr @mlf.code.233, ptr %v2078)
  %v2084 = call ptr @mlf_prim2(i64 1, ptr %v232, ptr %v2083)
  ret ptr %v2084
}

define private ptr @mlf.code.28(ptr %env, ptr %arg) {
entry:
  %v29 = getelementptr i8, ptr %env, i64 24
  %v30 = load ptr, ptr %v29, align 8, !tbaa !3
  %v31 = getelementptr i8, ptr %env, i64 32
  %v32 = load ptr, ptr %v31, align 8, !tbaa !3
  %v37 = call ptr @mlf_env_new(i64 1)
  %v38 = getelementptr i8, ptr %v37, i64 24
  store ptr %v30, ptr %v38, align 8, !tbaa !3
  %v39 = call ptr @mlf_thunk(ptr @mlf.code.33, ptr %v37)
  %v2085 = call ptr @mlf_env_new(i64 3)
  %v2086 = getelementptr i8, ptr %v2085, i64 24
  store ptr %v30, ptr %v2086, align 8, !tbaa !3
  %v2087 = getelementptr i8, ptr %v2085, i64 32
  store ptr %v32, ptr %v2087, align 8, !tbaa !3
  %v2088 = getelementptr i8, ptr %v2085, i64 40
  store ptr %arg, ptr %v2088, align 8, !tbaa !3
  %v2089 = call ptr @mlf_closure(ptr @mlf.code.40, ptr %v2085)
  %v2090 = call ptr @mlf_prim2(i64 1, ptr %v39, ptr %v2089)
  ret ptr %v2090
}

define private ptr @mlf.code.18(ptr %env, ptr %arg) {
entry:
  %v19 = getelementptr i8, ptr %env, i64 24
  %v20 = load ptr, ptr %v19, align 8, !tbaa !3
  %v25 = call ptr @mlf_env_new(i64 1)
  %v26 = getelementptr i8, ptr %v25, i64 24
  store ptr %v20, ptr %v26, align 8, !tbaa !3
  %v27 = call ptr @mlf_thunk(ptr @mlf.code.21, ptr %v25)
  %v2091 = call ptr @mlf_env_new(i64 2)
  %v2092 = getelementptr i8, ptr %v2091, i64 24
  store ptr %v20, ptr %v2092, align 8, !tbaa !3
  %v2093 = getelementptr i8, ptr %v2091, i64 32
  store ptr %arg, ptr %v2093, align 8, !tbaa !3
  %v2094 = call ptr @mlf_closure(ptr @mlf.code.28, ptr %v2091)
  %v2095 = call ptr @mlf_prim2(i64 1, ptr %v27, ptr %v2094)
  ret ptr %v2095
}

define private ptr @mlf.code.2(ptr %env, ptr %arg) {
entry:
  %v8 = call ptr @mlf_env_new(i64 1)
  %v9 = getelementptr i8, ptr %v8, i64 24
  store ptr %arg, ptr %v9, align 8, !tbaa !3
  %v10 = call ptr @mlf_thunk(ptr @mlf.code.3, ptr %v8)
  %v15 = call ptr @mlf_env_new(i64 1)
  %v16 = getelementptr i8, ptr %v15, i64 24
  store ptr %v10, ptr %v16, align 8, !tbaa !3
  %v17 = call ptr @mlf_thunk(ptr @mlf.code.11, ptr %v15)
  %v2096 = call ptr @mlf_env_new(i64 1)
  %v2097 = getelementptr i8, ptr %v2096, i64 24
  store ptr %v10, ptr %v2097, align 8, !tbaa !3
  %v2098 = call ptr @mlf_closure(ptr @mlf.code.18, ptr %v2096)
  %v2099 = call ptr @mlf_prim2(i64 1, ptr %v17, ptr %v2098)
  ret ptr %v2099
}

define private ptr @mlf.code.0(ptr %env, ptr %arg) {
entry:
  %v1 = call ptr @mlf_primitive(i64 4)
  %v2100 = call ptr @mlf_closure(ptr @mlf.code.2, ptr null)
  %v2101 = call ptr @mlf_prim2(i64 1, ptr %v1, ptr %v2100)
  ret ptr %v2101
}

declare void @mlf_require_standard_abi()
define ptr @mlf_entry() {
  call void @mlf_require_standard_abi()
  %root = call ptr @mlf.code.0(ptr null, ptr null)
  ret ptr %root
}
define i32 @main(i32 %argc, ptr %argv) {
  call void @mlf_set_args(i32 %argc, ptr %argv)
  %root = call ptr @mlf_entry()
  %status = call i32 @mlf_run(ptr %root, i64 1)
  ret i32 %status
}
