; Generated from independently checked xMLF.
source_filename = "emlf"

declare ptr @mlf_execute_st_lazy(ptr)
declare ptr @mlf_st_new_array(ptr, ptr)
declare ptr @mlf_st_read_array(ptr, ptr)
declare ptr @mlf_st_write_array(ptr, ptr, ptr)
declare ptr @mlf_st_length_array(ptr)
declare void @mlf_set_args(i32, ptr)
declare ptr @mlf_env_new(i64)
declare void @mlf_env_set(ptr, i64, ptr)
declare ptr @mlf_env_get(ptr, i64)
declare ptr @mlf_thunk(ptr, ptr)
declare ptr @mlf_closure(ptr, ptr)
declare ptr @mlf_application(ptr, ptr)
declare ptr @mlf_hole()
declare void @mlf_fill(ptr, ptr)
declare ptr @mlf_integer(ptr)
declare ptr @mlf_string(ptr, i64)
declare ptr @mlf_double(double)
declare double @llvm.sqrt.f64(double)
declare double @mlf_int_to_double(ptr)
declare ptr @mlf_read_int_table(ptr, ptr)
declare ptr @mlf_write_int_table(ptr, ptr, ptr)
declare ptr @mlf_add_int_table(ptr, ptr, ptr)
declare void @mlf_roots_enter(ptr, i64, ptr)
declare void @mlf_roots_leave(ptr)
declare void @mlf_gc_check(i64, ptr)
declare ptr @mlf_get_byte_line()
declare ptr @mlf_new_array(i64, ptr, ptr)
declare ptr @mlf_bytes_from_string(ptr)
declare ptr @mlf_put_bytes(ptr, ptr, ptr)
declare ptr @mlf_new_int_table()
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare i8 @mlf_byte(ptr)
declare ptr @mlf_peek(ptr)
declare ptr @mlf_native_io(ptr, ptr)
declare void @mlf_bounds_failure() noreturn
declare ptr @mlf_primitive(i64)
declare ptr @mlf_prim1(i64, ptr)
declare ptr @mlf_prim2(i64, ptr, ptr)
declare i64 @mlf_truth(ptr)
declare ptr @mlf_prim3(i64, ptr, ptr, ptr)
declare ptr @mlf_force(ptr)
declare ptr @mlf_add_int(ptr, ptr)
declare ptr @mlf_sub_int(ptr, ptr)
declare ptr @mlf_eq_int(ptr, ptr)
declare ptr @mlf_lt_int(ptr, ptr)
declare ptr @mlf_constructor(i64, i64)
declare ptr @mlf_constructor1(i64, ptr)
declare ptr @mlf_constructor2(i64, ptr, ptr)
declare ptr @mlf_constructor_fields(i64, ptr)
declare ptr @mlf_constructor_new(i64, i64)
declare ptr @mlf_field(ptr, i64)
declare void @mlf_match_failure() noreturn
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare i32 @mlf_run(ptr, i64)

!0 = !{!"MLF storage"}
!1 = !{!"managed object", !0}
!2 = !{!"array cells", !0}
!3 = !{!1, !1, i64 0}
!4 = !{!2, !2, i64 0}
@mlf.bytes.81 = private unnamed_addr constant [4 x i8] c"\50\34\0a\00", align 1
@mlf.bytes.85 = private unnamed_addr constant [2 x i8] c"\20\00", align 1
define private ptr @mlf.code.3(ptr %env, ptr %arg) {
entry:
  %v4 = getelementptr i8, ptr %env, i64 24
  %v5 = load ptr, ptr %v4, align 8, !tbaa !3
  %v6 = call ptr @mlf_force(ptr %v5)
  %v7 = call ptr @mlf_prim1(i64 17, ptr %v6)
  ret ptr %v7
}

define private ptr @mlf.code.14(ptr %env, ptr %arg) {
entry:
  %v15 = getelementptr i8, ptr %env, i64 24
  %v16 = load ptr, ptr %v15, align 8, !tbaa !3
  %v17 = call ptr @mlf_force(ptr %v16)
  %v18 = ptrtoint ptr %v17 to i64
  %v19 = ptrtoint ptr inttoptr (i64 15 to ptr) to i64
  %v20 = and i64 %v18, %v19
  %v21 = and i64 %v20, 1
  %v22 = icmp ne i64 %v21, 0
  br i1 %v22, label %yes.23, label %no.24
yes.23:
  %v26 = sub i64 %v19, 1
  %v27 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v18, i64 %v26)
  %v28 = extractvalue { i64, i1 } %v27, 0
  %v29 = extractvalue { i64, i1 } %v27, 1
  br i1 %v29, label %yes.30, label %no.31
yes.30:
  %v33 = call ptr @mlf_add_int(ptr %v17, ptr inttoptr (i64 15 to ptr))
  br label %join.32
no.31:
  %v34 = inttoptr i64 %v28 to ptr
  br label %join.32
join.32:
  %v35 = phi ptr [ %v33, %yes.30 ], [ %v34, %no.31 ]
  br label %join.25
no.24:
  %v36 = call ptr @mlf_add_int(ptr %v17, ptr inttoptr (i64 15 to ptr))
  br label %join.25
join.25:
  %v37 = phi ptr [ %v35, %join.32 ], [ %v36, %no.24 ]
  %v38 = ptrtoint ptr %v37 to i64
  %v39 = ptrtoint ptr inttoptr (i64 17 to ptr) to i64
  %v40 = and i64 %v38, %v39
  %v41 = and i64 %v40, 1
  %v42 = icmp ne i64 %v41, 0
  br i1 %v42, label %yes.43, label %no.44
yes.43:
  %v46 = ashr i64 %v38, 1
  %v47 = ashr i64 %v39, 1
  %v48 = icmp ne i64 %v47, 0
  %v49 = icmp eq i64 %v46, -4611686018427387904
  %v50 = icmp eq i64 %v47, -1
  %v51 = and i1 %v49, %v50
  %v52 = xor i1 %v51, true
  %v53 = and i1 %v48, %v52
  br i1 %v53, label %yes.54, label %no.55
yes.54:
  %v57 = sdiv i64 %v46, %v47
  %v58 = shl i64 %v57, 1
  %v59 = or i64 %v58, 1
  %v60 = inttoptr i64 %v59 to ptr
  br label %join.56
no.55:
  %v61 = call ptr @mlf_prim2(i64 15, ptr %v37, ptr inttoptr (i64 17 to ptr))
  br label %join.56
join.56:
  %v62 = phi ptr [ %v60, %yes.54 ], [ %v61, %no.55 ]
  br label %join.45
no.44:
  %v63 = call ptr @mlf_prim2(i64 15, ptr %v37, ptr inttoptr (i64 17 to ptr))
  br label %join.45
join.45:
  %v64 = phi ptr [ %v62, %join.56 ], [ %v63, %no.44 ]
  ret ptr %v64
}

define private ptr @mlf.code.11(ptr %env, ptr %arg) {
entry:
  %v12 = getelementptr i8, ptr %env, i64 24
  %v13 = load ptr, ptr %v12, align 8, !tbaa !3
  %v65 = call ptr @mlf_env_new(i64 1)
  %v66 = getelementptr i8, ptr %v65, i64 24
  store ptr %v13, ptr %v66, align 8, !tbaa !3
  %v67 = call ptr @mlf_thunk(ptr @mlf.code.14, ptr %v65)
  %v68 = call ptr @mlf_prim2(i64 35, ptr %v67, ptr inttoptr (i64 1 to ptr))
  ret ptr %v68
}

define private ptr @mlf.code.78(ptr %env, ptr %arg) {
entry:
  %v79 = getelementptr i8, ptr %env, i64 24
  %v80 = load ptr, ptr %v79, align 8, !tbaa !3
  %v82 = call ptr @mlf_string(ptr @mlf.bytes.81, i64 3)
  %v83 = call ptr @mlf_force(ptr %v80)
  %v84 = call ptr @mlf_prim1(i64 7, ptr %v83)
  %v86 = call ptr @mlf_string(ptr @mlf.bytes.85, i64 1)
  %v87 = call ptr @mlf_prim1(i64 7, ptr %v83)
  %v88 = call ptr @mlf_prim2(i64 6, ptr %v86, ptr %v87)
  %v89 = call ptr @mlf_prim2(i64 6, ptr %v84, ptr %v88)
  %v90 = call ptr @mlf_prim2(i64 6, ptr %v82, ptr %v89)
  ret ptr %v90
}

define private ptr @mlf.code.75(ptr %env, ptr %arg) {
entry:
  %v76 = getelementptr i8, ptr %env, i64 24
  %v77 = load ptr, ptr %v76, align 8, !tbaa !3
  %v91 = call ptr @mlf_env_new(i64 1)
  %v92 = getelementptr i8, ptr %v91, i64 24
  store ptr %v77, ptr %v92, align 8, !tbaa !3
  %v93 = call ptr @mlf_thunk(ptr @mlf.code.78, ptr %v91)
  %v94 = call ptr @mlf_prim1(i64 3, ptr %v93)
  ret ptr %v94
}

define private ptr @mlf.numeric.10.dddddddddddppn(double %a0, double %a1, double %a2, double %a3, double %a4, double %a5, double %a6, double %a7, double %a8, double %a9, double %a10, ptr %a11, ptr %a12, ptr %a13) alwaysinline {
entry:
  %v381 = fadd double %a2, %a3
  %v382 = fcmp olt double 0x4010000000000000, %v381
  %v383 = select i1 %v382, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v384 = icmp eq ptr %v383, inttoptr (i64 6 to ptr)
  br i1 %v384, label %yes.385, label %no.386
yes.385:
  br label %join.387
no.386:
  br label %join.387
join.387:
  %v388 = phi ptr [ inttoptr (i64 2 to ptr), %yes.385 ], [ %a11, %no.386 ]
  %v389 = fadd double %a7, %a8
  %v390 = fcmp olt double 0x4010000000000000, %v389
  %v391 = select i1 %v390, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v392 = icmp eq ptr %v391, inttoptr (i64 6 to ptr)
  br i1 %v392, label %yes.393, label %no.394
yes.393:
  br label %join.395
no.394:
  br label %join.395
join.395:
  %v396 = phi ptr [ inttoptr (i64 2 to ptr), %yes.393 ], [ %a12, %no.394 ]
  %v397 = icmp eq ptr %v388, inttoptr (i64 6 to ptr)
  br i1 %v397, label %yes.398, label %no.399
yes.398:
  br label %join.400
no.399:
  br label %join.400
join.400:
  %v401 = phi ptr [ inttoptr (i64 6 to ptr), %yes.398 ], [ %v396, %no.399 ]
  %v402 = icmp eq ptr %v401, inttoptr (i64 6 to ptr)
  br i1 %v402, label %tail.yes.403, label %tail.no.404
tail.yes.403:
  %v405 = ptrtoint ptr %a13 to i64
  %v406 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v407 = icmp eq i64 %v405, %v406
  %v408 = select i1 %v407, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v409 = icmp eq ptr %v408, inttoptr (i64 6 to ptr)
  br i1 %v409, label %tail.yes.410, label %tail.no.411
tail.yes.410:
  %v412 = icmp eq ptr %v388, inttoptr (i64 6 to ptr)
  br i1 %v412, label %yes.413, label %no.414
yes.413:
  br label %join.415
no.414:
  br label %join.415
join.415:
  %v416 = phi ptr [ inttoptr (i64 5 to ptr), %yes.413 ], [ inttoptr (i64 1 to ptr), %no.414 ]
  %v417 = icmp eq ptr %v396, inttoptr (i64 6 to ptr)
  br i1 %v417, label %yes.418, label %no.419
yes.418:
  br label %join.420
no.419:
  br label %join.420
join.420:
  %v421 = phi ptr [ inttoptr (i64 3 to ptr), %yes.418 ], [ inttoptr (i64 1 to ptr), %no.419 ]
  %v422 = ptrtoint ptr %v416 to i64
  %v423 = ptrtoint ptr %v421 to i64
  %v424 = sub i64 %v423, 1
  %v425 = add nsw i64 %v422, %v424
  %v426 = inttoptr i64 %v425 to ptr
  ret ptr %v426
tail.no.411:
  %v427 = fmul double 0x4000000000000000, %a0
  %v428 = fmul double %v427, %a1
  %v429 = fadd double %v428, %a10
  %v430 = fsub double %a2, %a3
  %v431 = fadd double %v430, %a4
  %v432 = fmul double 0x4000000000000000, %a5
  %v433 = fmul double %v432, %a6
  %v434 = fadd double %v433, %a10
  %v435 = fsub double %a7, %a8
  %v436 = fadd double %v435, %a9
  %v437 = fmul double %v431, %v431
  %v438 = fmul double %v429, %v429
  %v439 = fmul double %v436, %v436
  %v440 = fmul double %v434, %v434
  %v441 = ptrtoint ptr %a13 to i64
  %v442 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v443 = sub i64 %v442, 1
  %v444 = sub nsw i64 %v441, %v443
  %v445 = inttoptr i64 %v444 to ptr
  %v446 = musttail call ptr @mlf.numeric.10.dddddddddddppn(double %v431, double %v429, double %v437, double %v438, double %a4, double %v436, double %v434, double %v439, double %v440, double %a9, double %a10, ptr %v388, ptr %v396, ptr %v445)
  ret ptr %v446
tail.no.404:
  ret ptr inttoptr (i64 1 to ptr)
}

define private ptr @mlf.numeric.0.ddddddn(double %a0, double %a1, double %a2, double %a3, double %a4, double %a5, ptr %a6) alwaysinline {
entry:
  %v518 = fadd double %a2, %a3
  %v519 = fcmp olt double 0x4010000000000000, %v518
  %v520 = select i1 %v519, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v521 = icmp eq ptr %v520, inttoptr (i64 6 to ptr)
  br i1 %v521, label %tail.yes.522, label %tail.no.523
tail.yes.522:
  ret ptr inttoptr (i64 1 to ptr)
tail.no.523:
  %v524 = ptrtoint ptr %a6 to i64
  %v525 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v526 = icmp eq i64 %v524, %v525
  %v527 = select i1 %v526, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v528 = icmp eq ptr %v527, inttoptr (i64 6 to ptr)
  br i1 %v528, label %tail.yes.529, label %tail.no.530
tail.yes.529:
  ret ptr inttoptr (i64 3 to ptr)
tail.no.530:
  %v531 = fmul double 0x4000000000000000, %a0
  %v532 = fmul double %v531, %a1
  %v533 = fadd double %v532, %a5
  %v534 = fsub double %a2, %a3
  %v535 = fadd double %v534, %a4
  %v536 = fmul double %v535, %v535
  %v537 = fmul double %v533, %v533
  %v538 = ptrtoint ptr %a6 to i64
  %v539 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v540 = sub i64 %v539, 1
  %v541 = sub nsw i64 %v538, %v540
  %v542 = inttoptr i64 %v541 to ptr
  %v543 = musttail call ptr @mlf.numeric.0.ddddddn(double %v535, double %v533, double %v536, double %v537, double %a4, double %a5, ptr %v542)
  ret ptr %v543
}

define private ptr @mlf.numeric.31.pii(ptr %a0, ptr %a1, ptr %a2) alwaysinline {
entry:
  %v747 = ptrtoint ptr %a2 to i64
  %v748 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v749 = icmp eq i64 %v747, %v748
  %v750 = select i1 %v749, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v751 = icmp eq ptr %v750, inttoptr (i64 6 to ptr)
  br i1 %v751, label %tail.yes.752, label %tail.no.753
tail.yes.752:
  ret ptr inttoptr (i64 4 to ptr)
tail.no.753:
  %v754 = getelementptr i8, ptr %a0, i64 24
  %v755 = load i64, ptr %v754, align 8, !tbaa !3
  %v756 = getelementptr i8, ptr %a0, i64 32
  %v757 = load ptr, ptr %v756, align 8, !tbaa !3
  %v758 = ptrtoint ptr %a1 to i64
  %v759 = ashr i64 %v758, 1
  %v760 = and i64 %v758, 1
  %v761 = icmp ne i64 %v760, 0
  %v762 = icmp ult i64 %v759, %v755
  %v763 = and i1 %v761, %v762
  br i1 %v763, label %array.valid.764, label %array.invalid.765
array.invalid.765:
  call void @mlf_bounds_failure()
  unreachable
array.valid.764:
  %v766 = getelementptr i8, ptr %v757, i64 %v759
  %v767 = load i8, ptr %v766, align 1, !tbaa !4
  %v768 = zext i8 %v767 to i64
  %v769 = shl i64 %v768, 1
  %v770 = or i64 %v769, 1
  %v771 = inttoptr i64 %v770 to ptr
  %v772 = ptrtoint ptr %v771 to i64
  %v773 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v774 = ashr i64 %v772, 1
  %v775 = ashr i64 %v773, 1
  %v776 = mul nsw i64 %v774, %v775
  %v777 = shl i64 %v776, 1
  %v778 = or i64 %v777, 1
  %v779 = inttoptr i64 %v778 to ptr
  %v780 = ptrtoint ptr %a1 to i64
  %v781 = ashr i64 %v780, 1
  %v782 = and i64 %v780, 1
  %v783 = icmp ne i64 %v782, 0
  %v784 = icmp ult i64 %v781, %v755
  %v785 = and i1 %v783, %v784
  br i1 %v785, label %array.valid.786, label %array.invalid.787
array.invalid.787:
  call void @mlf_bounds_failure()
  unreachable
array.valid.786:
  %v788 = getelementptr i8, ptr %v757, i64 %v781
  %v789 = ptrtoint ptr %v779 to i64
  %v790 = ashr i64 %v789, 1
  %v791 = and i64 %v789, 1
  %v792 = icmp ne i64 %v791, 0
  %v793 = icmp ult i64 %v790, 256
  %v794 = and i1 %v792, %v793
  br i1 %v794, label %yes.795, label %no.796
yes.795:
  %v798 = trunc i64 %v790 to i8
  br label %join.797
no.796:
  %v799 = call i8 @mlf_byte(ptr %v779)
  br label %join.797
join.797:
  %v800 = phi i8 [ %v798, %yes.795 ], [ %v799, %no.796 ]
  store i8 %v800, ptr %v788, align 1, !tbaa !4
  %v801 = ptrtoint ptr %a2 to i64
  %v802 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v803 = sub i64 %v802, 1
  %v804 = sub nsw i64 %v801, %v803
  %v805 = inttoptr i64 %v804 to ptr
  %v806 = musttail call ptr @mlf.numeric.31.pii(ptr %a0, ptr %a1, ptr %v805)
  ret ptr %v806
}

define private ptr @mlf.numeric.31(ptr %a0, ptr %a1, ptr %a2) alwaysinline {
entry:
  %v733 = ptrtoint ptr %a1 to i64
  %v734 = and i64 %v733, 1
  %v735 = icmp ne i64 %v734, 0
  %v736 = icmp ult i64 %v733, 4294967296
  %v737 = and i1 %v735, %v736
  %v738 = ptrtoint ptr %a2 to i64
  %v739 = and i64 %v738, 1
  %v740 = icmp ne i64 %v739, 0
  %v741 = icmp ult i64 %v738, 4294967296
  %v742 = and i1 %v740, %v741
  %v743 = and i1 true, %v737
  %v744 = and i1 %v743, %v742
  br i1 %v744, label %range.fast.745, label %range.general.746
range.fast.745:
  %v807 = musttail call ptr @mlf.numeric.31.pii(ptr %a0, ptr %a1, ptr %a2)
  ret ptr %v807
range.general.746:
  %v808 = ptrtoint ptr %a2 to i64
  %v809 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v810 = and i64 %v808, %v809
  %v811 = and i64 %v810, 1
  %v812 = icmp ne i64 %v811, 0
  br i1 %v812, label %yes.813, label %no.814
yes.813:
  %v816 = icmp eq i64 %v808, %v809
  %v817 = select i1 %v816, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.815
no.814:
  %v818 = call ptr @mlf_eq_int(ptr %a2, ptr inttoptr (i64 1 to ptr))
  br label %join.815
join.815:
  %v819 = phi ptr [ %v817, %yes.813 ], [ %v818, %no.814 ]
  %v820 = icmp eq ptr %v819, inttoptr (i64 6 to ptr)
  br i1 %v820, label %tail.yes.821, label %tail.no.822
tail.yes.821:
  ret ptr inttoptr (i64 4 to ptr)
tail.no.822:
  %v823 = getelementptr i8, ptr %a0, i64 24
  %v824 = load i64, ptr %v823, align 8, !tbaa !3
  %v825 = getelementptr i8, ptr %a0, i64 32
  %v826 = load ptr, ptr %v825, align 8, !tbaa !3
  %v827 = ptrtoint ptr %a1 to i64
  %v828 = ashr i64 %v827, 1
  %v829 = and i64 %v827, 1
  %v830 = icmp ne i64 %v829, 0
  %v831 = icmp ult i64 %v828, %v824
  %v832 = and i1 %v830, %v831
  br i1 %v832, label %array.valid.833, label %array.invalid.834
array.invalid.834:
  call void @mlf_bounds_failure()
  unreachable
array.valid.833:
  %v835 = getelementptr i8, ptr %v826, i64 %v828
  %v836 = load i8, ptr %v835, align 1, !tbaa !4
  %v837 = zext i8 %v836 to i64
  %v838 = shl i64 %v837, 1
  %v839 = or i64 %v838, 1
  %v840 = inttoptr i64 %v839 to ptr
  %v841 = ptrtoint ptr %v840 to i64
  %v842 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v843 = ashr i64 %v841, 1
  %v844 = ashr i64 %v842, 1
  %v845 = mul nsw i64 %v843, %v844
  %v846 = shl i64 %v845, 1
  %v847 = or i64 %v846, 1
  %v848 = inttoptr i64 %v847 to ptr
  %v849 = ptrtoint ptr %a1 to i64
  %v850 = ashr i64 %v849, 1
  %v851 = and i64 %v849, 1
  %v852 = icmp ne i64 %v851, 0
  %v853 = icmp ult i64 %v850, %v824
  %v854 = and i1 %v852, %v853
  br i1 %v854, label %array.valid.855, label %array.invalid.856
array.invalid.856:
  call void @mlf_bounds_failure()
  unreachable
array.valid.855:
  %v857 = getelementptr i8, ptr %v826, i64 %v850
  %v858 = ptrtoint ptr %v848 to i64
  %v859 = ashr i64 %v858, 1
  %v860 = and i64 %v858, 1
  %v861 = icmp ne i64 %v860, 0
  %v862 = icmp ult i64 %v859, 256
  %v863 = and i1 %v861, %v862
  br i1 %v863, label %yes.864, label %no.865
yes.864:
  %v867 = trunc i64 %v859 to i8
  br label %join.866
no.865:
  %v868 = call i8 @mlf_byte(ptr %v848)
  br label %join.866
join.866:
  %v869 = phi i8 [ %v867, %yes.864 ], [ %v868, %no.865 ]
  store i8 %v869, ptr %v857, align 1, !tbaa !4
  %v870 = ptrtoint ptr %a2 to i64
  %v871 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v872 = and i64 %v870, %v871
  %v873 = and i64 %v872, 1
  %v874 = icmp ne i64 %v873, 0
  br i1 %v874, label %yes.875, label %no.876
yes.875:
  %v878 = sub i64 %v871, 1
  %v879 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v870, i64 %v878)
  %v880 = extractvalue { i64, i1 } %v879, 0
  %v881 = extractvalue { i64, i1 } %v879, 1
  br i1 %v881, label %yes.882, label %no.883
yes.882:
  %v885 = call ptr @mlf_sub_int(ptr %a2, ptr inttoptr (i64 3 to ptr))
  br label %join.884
no.883:
  %v886 = inttoptr i64 %v880 to ptr
  br label %join.884
join.884:
  %v887 = phi ptr [ %v885, %yes.882 ], [ %v886, %no.883 ]
  br label %join.877
no.876:
  %v888 = call ptr @mlf_sub_int(ptr %a2, ptr inttoptr (i64 3 to ptr))
  br label %join.877
join.877:
  %v889 = phi ptr [ %v887, %join.884 ], [ %v888, %no.876 ]
  %v890 = musttail call ptr @mlf.numeric.31(ptr %a0, ptr %a1, ptr %v889)
  ret ptr %v890
}

define private ptr @mlf.numeric.37(ptr %a0, ptr %a1, ptr %a2, ptr %a3) alwaysinline {
entry:
  %v137 = ptrtoint ptr %a3 to i64
  %v138 = ptrtoint ptr %a1 to i64
  %v139 = and i64 %v137, %v138
  %v140 = and i64 %v139, 1
  %v141 = icmp ne i64 %v140, 0
  br i1 %v141, label %yes.142, label %no.143
yes.142:
  %v145 = icmp slt i64 %v137, %v138
  %v146 = select i1 %v145, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.144
no.143:
  %v147 = call ptr @mlf_lt_int(ptr %a3, ptr %a1)
  br label %join.144
join.144:
  %v148 = phi ptr [ %v146, %yes.142 ], [ %v147, %no.143 ]
  %v149 = icmp eq ptr %v148, inttoptr (i64 6 to ptr)
  br i1 %v149, label %tail.yes.150, label %tail.no.151
tail.yes.150:
  %v152 = ptrtoint ptr %a3 to i64
  %v153 = and i64 %v152, 1
  %v154 = icmp ne i64 %v153, 0
  br i1 %v154, label %yes.155, label %no.156
yes.155:
  %v158 = ashr i64 %v152, 1
  %v159 = sitofp i64 %v158 to double
  br label %join.157
no.156:
  %v160 = call double @mlf_int_to_double(ptr %a3)
  br label %join.157
join.157:
  %v161 = phi double [ %v159, %yes.155 ], [ %v160, %no.156 ]
  %v162 = fmul double 0x4000000000000000, %v161
  %v163 = ptrtoint ptr %a1 to i64
  %v164 = and i64 %v163, 1
  %v165 = icmp ne i64 %v164, 0
  br i1 %v165, label %yes.166, label %no.167
yes.166:
  %v169 = ashr i64 %v163, 1
  %v170 = sitofp i64 %v169 to double
  br label %join.168
no.167:
  %v171 = call double @mlf_int_to_double(ptr %a1)
  br label %join.168
join.168:
  %v172 = phi double [ %v170, %yes.166 ], [ %v171, %no.167 ]
  %v173 = fdiv double %v162, %v172
  %v174 = fsub double %v173, 0x3ff8000000000000
  %v175 = ptrtoint ptr %a2 to i64
  %v176 = and i64 %v175, 1
  %v177 = icmp ne i64 %v176, 0
  br i1 %v177, label %yes.178, label %no.179
yes.178:
  %v181 = ashr i64 %v175, 1
  %v182 = sitofp i64 %v181 to double
  br label %join.180
no.179:
  %v183 = call double @mlf_int_to_double(ptr %a2)
  br label %join.180
join.180:
  %v184 = phi double [ %v182, %yes.178 ], [ %v183, %no.179 ]
  %v185 = fmul double 0x4000000000000000, %v184
  %v186 = ptrtoint ptr %a1 to i64
  %v187 = and i64 %v186, 1
  %v188 = icmp ne i64 %v187, 0
  br i1 %v188, label %yes.189, label %no.190
yes.189:
  %v192 = ashr i64 %v186, 1
  %v193 = sitofp i64 %v192 to double
  br label %join.191
no.190:
  %v194 = call double @mlf_int_to_double(ptr %a1)
  br label %join.191
join.191:
  %v195 = phi double [ %v193, %yes.189 ], [ %v194, %no.190 ]
  %v196 = fdiv double %v185, %v195
  %v197 = fsub double %v196, 0x3ff0000000000000
  %v198 = ptrtoint ptr %a3 to i64
  %v199 = ptrtoint ptr inttoptr (i64 17 to ptr) to i64
  %v200 = and i64 %v198, %v199
  %v201 = and i64 %v200, 1
  %v202 = icmp ne i64 %v201, 0
  br i1 %v202, label %yes.203, label %no.204
yes.203:
  %v206 = ashr i64 %v198, 1
  %v207 = ashr i64 %v199, 1
  %v208 = icmp ne i64 %v207, 0
  %v209 = icmp eq i64 %v206, -4611686018427387904
  %v210 = icmp eq i64 %v207, -1
  %v211 = and i1 %v209, %v210
  %v212 = xor i1 %v211, true
  %v213 = and i1 %v208, %v212
  br i1 %v213, label %yes.214, label %no.215
yes.214:
  %v217 = sdiv i64 %v206, %v207
  %v218 = shl i64 %v217, 1
  %v219 = or i64 %v218, 1
  %v220 = inttoptr i64 %v219 to ptr
  br label %join.216
no.215:
  %v221 = call ptr @mlf_prim2(i64 15, ptr %a3, ptr inttoptr (i64 17 to ptr))
  br label %join.216
join.216:
  %v222 = phi ptr [ %v220, %yes.214 ], [ %v221, %no.215 ]
  br label %join.205
no.204:
  %v223 = call ptr @mlf_prim2(i64 15, ptr %a3, ptr inttoptr (i64 17 to ptr))
  br label %join.205
join.205:
  %v224 = phi ptr [ %v222, %join.216 ], [ %v223, %no.204 ]
  %v225 = ptrtoint ptr %a3 to i64
  %v226 = ptrtoint ptr inttoptr (i64 17 to ptr) to i64
  %v227 = and i64 %v225, %v226
  %v228 = and i64 %v227, 1
  %v229 = icmp ne i64 %v228, 0
  br i1 %v229, label %yes.230, label %no.231
yes.230:
  %v233 = ashr i64 %v225, 1
  %v234 = ashr i64 %v226, 1
  %v235 = icmp ne i64 %v234, 0
  %v236 = icmp eq i64 %v233, -4611686018427387904
  %v237 = icmp eq i64 %v234, -1
  %v238 = and i1 %v236, %v237
  %v239 = xor i1 %v238, true
  %v240 = and i1 %v235, %v239
  br i1 %v240, label %yes.241, label %no.242
yes.241:
  %v244 = srem i64 %v233, %v234
  %v245 = shl i64 %v244, 1
  %v246 = or i64 %v245, 1
  %v247 = inttoptr i64 %v246 to ptr
  br label %join.243
no.242:
  %v248 = call ptr @mlf_prim2(i64 16, ptr %a3, ptr inttoptr (i64 17 to ptr))
  br label %join.243
join.243:
  %v249 = phi ptr [ %v247, %yes.241 ], [ %v248, %no.242 ]
  br label %join.232
no.231:
  %v250 = call ptr @mlf_prim2(i64 16, ptr %a3, ptr inttoptr (i64 17 to ptr))
  br label %join.232
join.232:
  %v251 = phi ptr [ %v249, %join.243 ], [ %v250, %no.231 ]
  %v252 = ptrtoint ptr %v251 to i64
  %v253 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v254 = and i64 %v252, %v253
  %v255 = and i64 %v254, 1
  %v256 = icmp ne i64 %v255, 0
  br i1 %v256, label %yes.257, label %no.258
yes.257:
  %v260 = icmp eq i64 %v252, %v253
  %v261 = select i1 %v260, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.259
no.258:
  %v262 = call ptr @mlf_eq_int(ptr %v251, ptr inttoptr (i64 1 to ptr))
  br label %join.259
join.259:
  %v263 = phi ptr [ %v261, %yes.257 ], [ %v262, %no.258 ]
  %v264 = icmp eq ptr %v263, inttoptr (i64 6 to ptr)
  br i1 %v264, label %yes.265, label %no.266
yes.265:
  %v268 = getelementptr i8, ptr %a0, i64 24
  %v269 = load i64, ptr %v268, align 8, !tbaa !3
  %v270 = getelementptr i8, ptr %a0, i64 32
  %v271 = load ptr, ptr %v270, align 8, !tbaa !3
  %v272 = ptrtoint ptr %v224 to i64
  %v273 = ashr i64 %v272, 1
  %v274 = and i64 %v272, 1
  %v275 = icmp ne i64 %v274, 0
  %v276 = icmp ult i64 %v273, %v269
  %v277 = and i1 %v275, %v276
  br i1 %v277, label %array.valid.278, label %array.invalid.279
array.invalid.279:
  call void @mlf_bounds_failure()
  unreachable
array.valid.278:
  %v280 = getelementptr i8, ptr %v271, i64 %v273
  %v281 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v282 = ashr i64 %v281, 1
  %v283 = trunc i64 %v282 to i8
  store i8 %v283, ptr %v280, align 1, !tbaa !4
  br label %join.267
no.266:
  br label %join.267
join.267:
  %v284 = phi ptr [ inttoptr (i64 4 to ptr), %array.valid.278 ], [ inttoptr (i64 4 to ptr), %no.266 ]
  %v285 = getelementptr i8, ptr %a0, i64 24
  %v286 = load i64, ptr %v285, align 8, !tbaa !3
  %v287 = getelementptr i8, ptr %a0, i64 32
  %v288 = load ptr, ptr %v287, align 8, !tbaa !3
  %v289 = ptrtoint ptr %v224 to i64
  %v290 = ashr i64 %v289, 1
  %v291 = and i64 %v289, 1
  %v292 = icmp ne i64 %v291, 0
  %v293 = icmp ult i64 %v290, %v286
  %v294 = and i1 %v292, %v293
  br i1 %v294, label %array.valid.295, label %array.invalid.296
array.invalid.296:
  call void @mlf_bounds_failure()
  unreachable
array.valid.295:
  %v297 = getelementptr i8, ptr %v288, i64 %v290
  %v298 = load i8, ptr %v297, align 1, !tbaa !4
  %v299 = zext i8 %v298 to i64
  %v300 = shl i64 %v299, 1
  %v301 = or i64 %v300, 1
  %v302 = inttoptr i64 %v301 to ptr
  %v303 = ptrtoint ptr %a3 to i64
  %v304 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v305 = and i64 %v303, %v304
  %v306 = and i64 %v305, 1
  %v307 = icmp ne i64 %v306, 0
  br i1 %v307, label %yes.308, label %no.309
yes.308:
  %v311 = sub i64 %v304, 1
  %v312 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v303, i64 %v311)
  %v313 = extractvalue { i64, i1 } %v312, 0
  %v314 = extractvalue { i64, i1 } %v312, 1
  br i1 %v314, label %yes.315, label %no.316
yes.315:
  %v318 = call ptr @mlf_add_int(ptr %a3, ptr inttoptr (i64 3 to ptr))
  br label %join.317
no.316:
  %v319 = inttoptr i64 %v313 to ptr
  br label %join.317
join.317:
  %v320 = phi ptr [ %v318, %yes.315 ], [ %v319, %no.316 ]
  br label %join.310
no.309:
  %v321 = call ptr @mlf_add_int(ptr %a3, ptr inttoptr (i64 3 to ptr))
  br label %join.310
join.310:
  %v322 = phi ptr [ %v320, %join.317 ], [ %v321, %no.309 ]
  %v323 = ptrtoint ptr %v322 to i64
  %v324 = ptrtoint ptr %a1 to i64
  %v325 = and i64 %v323, %v324
  %v326 = and i64 %v325, 1
  %v327 = icmp ne i64 %v326, 0
  br i1 %v327, label %yes.328, label %no.329
yes.328:
  %v331 = icmp slt i64 %v323, %v324
  %v332 = select i1 %v331, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.330
no.329:
  %v333 = call ptr @mlf_lt_int(ptr %v322, ptr %a1)
  br label %join.330
join.330:
  %v334 = phi ptr [ %v332, %yes.328 ], [ %v333, %no.329 ]
  %v335 = icmp eq ptr %v334, inttoptr (i64 6 to ptr)
  br i1 %v335, label %tail.yes.336, label %tail.no.337
tail.yes.336:
  %v338 = ptrtoint ptr %a3 to i64
  %v339 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v340 = and i64 %v338, %v339
  %v341 = and i64 %v340, 1
  %v342 = icmp ne i64 %v341, 0
  br i1 %v342, label %yes.343, label %no.344
yes.343:
  %v346 = sub i64 %v339, 1
  %v347 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v338, i64 %v346)
  %v348 = extractvalue { i64, i1 } %v347, 0
  %v349 = extractvalue { i64, i1 } %v347, 1
  br i1 %v349, label %yes.350, label %no.351
yes.350:
  %v353 = call ptr @mlf_add_int(ptr %a3, ptr inttoptr (i64 3 to ptr))
  br label %join.352
no.351:
  %v354 = inttoptr i64 %v348 to ptr
  br label %join.352
join.352:
  %v355 = phi ptr [ %v353, %yes.350 ], [ %v354, %no.351 ]
  br label %join.345
no.344:
  %v356 = call ptr @mlf_add_int(ptr %a3, ptr inttoptr (i64 3 to ptr))
  br label %join.345
join.345:
  %v357 = phi ptr [ %v355, %join.352 ], [ %v356, %no.344 ]
  %v358 = ptrtoint ptr %v357 to i64
  %v359 = and i64 %v358, 1
  %v360 = icmp ne i64 %v359, 0
  br i1 %v360, label %yes.361, label %no.362
yes.361:
  %v364 = ashr i64 %v358, 1
  %v365 = sitofp i64 %v364 to double
  br label %join.363
no.362:
  %v366 = call double @mlf_int_to_double(ptr %v357)
  br label %join.363
join.363:
  %v367 = phi double [ %v365, %yes.361 ], [ %v366, %no.362 ]
  %v368 = fmul double 0x4000000000000000, %v367
  %v369 = ptrtoint ptr %a1 to i64
  %v370 = and i64 %v369, 1
  %v371 = icmp ne i64 %v370, 0
  br i1 %v371, label %yes.372, label %no.373
yes.372:
  %v375 = ashr i64 %v369, 1
  %v376 = sitofp i64 %v375 to double
  br label %join.374
no.373:
  %v377 = call double @mlf_int_to_double(ptr %a1)
  br label %join.374
join.374:
  %v378 = phi double [ %v376, %yes.372 ], [ %v377, %no.373 ]
  %v379 = fdiv double %v368, %v378
  %v380 = fsub double %v379, 0x3ff8000000000000
  %v447 = call ptr @mlf.numeric.10.dddddddddddppn(double 0x0000000000000000, double 0x0000000000000000, double 0x0000000000000000, double 0x0000000000000000, double %v174, double 0x0000000000000000, double 0x0000000000000000, double 0x0000000000000000, double 0x0000000000000000, double %v380, double %v197, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 101 to ptr))
  %v448 = ptrtoint ptr %v302 to i64
  %v449 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v450 = ashr i64 %v448, 1
  %v451 = ashr i64 %v449, 1
  %v452 = mul nsw i64 %v450, %v451
  %v453 = shl i64 %v452, 1
  %v454 = or i64 %v453, 1
  %v455 = inttoptr i64 %v454 to ptr
  %v456 = ptrtoint ptr %v455 to i64
  %v457 = ptrtoint ptr %v447 to i64
  %v458 = and i64 %v456, %v457
  %v459 = and i64 %v458, 1
  %v460 = icmp ne i64 %v459, 0
  br i1 %v460, label %yes.461, label %no.462
yes.461:
  %v464 = sub i64 %v457, 1
  %v465 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v456, i64 %v464)
  %v466 = extractvalue { i64, i1 } %v465, 0
  %v467 = extractvalue { i64, i1 } %v465, 1
  br i1 %v467, label %yes.468, label %no.469
yes.468:
  %v471 = call ptr @mlf_add_int(ptr %v455, ptr %v447)
  br label %join.470
no.469:
  %v472 = inttoptr i64 %v466 to ptr
  br label %join.470
join.470:
  %v473 = phi ptr [ %v471, %yes.468 ], [ %v472, %no.469 ]
  br label %join.463
no.462:
  %v474 = call ptr @mlf_add_int(ptr %v455, ptr %v447)
  br label %join.463
join.463:
  %v475 = phi ptr [ %v473, %join.470 ], [ %v474, %no.462 ]
  %v476 = ptrtoint ptr %v224 to i64
  %v477 = ashr i64 %v476, 1
  %v478 = and i64 %v476, 1
  %v479 = icmp ne i64 %v478, 0
  %v480 = icmp ult i64 %v477, %v286
  %v481 = and i1 %v479, %v480
  br i1 %v481, label %array.valid.482, label %array.invalid.483
array.invalid.483:
  call void @mlf_bounds_failure()
  unreachable
array.valid.482:
  %v484 = getelementptr i8, ptr %v288, i64 %v477
  %v485 = ptrtoint ptr %v475 to i64
  %v486 = ashr i64 %v485, 1
  %v487 = and i64 %v485, 1
  %v488 = icmp ne i64 %v487, 0
  %v489 = icmp ult i64 %v486, 256
  %v490 = and i1 %v488, %v489
  br i1 %v490, label %yes.491, label %no.492
yes.491:
  %v494 = trunc i64 %v486 to i8
  br label %join.493
no.492:
  %v495 = call i8 @mlf_byte(ptr %v475)
  br label %join.493
join.493:
  %v496 = phi i8 [ %v494, %yes.491 ], [ %v495, %no.492 ]
  store i8 %v496, ptr %v484, align 1, !tbaa !4
  %v497 = ptrtoint ptr %a3 to i64
  %v498 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v499 = and i64 %v497, %v498
  %v500 = and i64 %v499, 1
  %v501 = icmp ne i64 %v500, 0
  br i1 %v501, label %yes.502, label %no.503
yes.502:
  %v505 = sub i64 %v498, 1
  %v506 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v497, i64 %v505)
  %v507 = extractvalue { i64, i1 } %v506, 0
  %v508 = extractvalue { i64, i1 } %v506, 1
  br i1 %v508, label %yes.509, label %no.510
yes.509:
  %v512 = call ptr @mlf_add_int(ptr %a3, ptr inttoptr (i64 5 to ptr))
  br label %join.511
no.510:
  %v513 = inttoptr i64 %v507 to ptr
  br label %join.511
join.511:
  %v514 = phi ptr [ %v512, %yes.509 ], [ %v513, %no.510 ]
  br label %join.504
no.503:
  %v515 = call ptr @mlf_add_int(ptr %a3, ptr inttoptr (i64 5 to ptr))
  br label %join.504
join.504:
  %v516 = phi ptr [ %v514, %join.511 ], [ %v515, %no.503 ]
  %v517 = musttail call ptr @mlf.numeric.37(ptr %a0, ptr %a1, ptr %a2, ptr %v516)
  ret ptr %v517
tail.no.337:
  %v544 = call ptr @mlf.numeric.0.ddddddn(double 0x0000000000000000, double 0x0000000000000000, double 0x0000000000000000, double 0x0000000000000000, double %v174, double %v197, ptr inttoptr (i64 101 to ptr))
  %v545 = ptrtoint ptr %v302 to i64
  %v546 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v547 = ashr i64 %v545, 1
  %v548 = ashr i64 %v546, 1
  %v549 = mul nsw i64 %v547, %v548
  %v550 = shl i64 %v549, 1
  %v551 = or i64 %v550, 1
  %v552 = inttoptr i64 %v551 to ptr
  %v553 = ptrtoint ptr %v552 to i64
  %v554 = ptrtoint ptr %v544 to i64
  %v555 = and i64 %v553, %v554
  %v556 = and i64 %v555, 1
  %v557 = icmp ne i64 %v556, 0
  br i1 %v557, label %yes.558, label %no.559
yes.558:
  %v561 = sub i64 %v554, 1
  %v562 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v553, i64 %v561)
  %v563 = extractvalue { i64, i1 } %v562, 0
  %v564 = extractvalue { i64, i1 } %v562, 1
  br i1 %v564, label %yes.565, label %no.566
yes.565:
  %v568 = call ptr @mlf_add_int(ptr %v552, ptr %v544)
  br label %join.567
no.566:
  %v569 = inttoptr i64 %v563 to ptr
  br label %join.567
join.567:
  %v570 = phi ptr [ %v568, %yes.565 ], [ %v569, %no.566 ]
  br label %join.560
no.559:
  %v571 = call ptr @mlf_add_int(ptr %v552, ptr %v544)
  br label %join.560
join.560:
  %v572 = phi ptr [ %v570, %join.567 ], [ %v571, %no.559 ]
  %v573 = ptrtoint ptr %v224 to i64
  %v574 = ashr i64 %v573, 1
  %v575 = and i64 %v573, 1
  %v576 = icmp ne i64 %v575, 0
  %v577 = icmp ult i64 %v574, %v286
  %v578 = and i1 %v576, %v577
  br i1 %v578, label %array.valid.579, label %array.invalid.580
array.invalid.580:
  call void @mlf_bounds_failure()
  unreachable
array.valid.579:
  %v581 = getelementptr i8, ptr %v288, i64 %v574
  %v582 = ptrtoint ptr %v572 to i64
  %v583 = ashr i64 %v582, 1
  %v584 = and i64 %v582, 1
  %v585 = icmp ne i64 %v584, 0
  %v586 = icmp ult i64 %v583, 256
  %v587 = and i1 %v585, %v586
  br i1 %v587, label %yes.588, label %no.589
yes.588:
  %v591 = trunc i64 %v583 to i8
  br label %join.590
no.589:
  %v592 = call i8 @mlf_byte(ptr %v572)
  br label %join.590
join.590:
  %v593 = phi i8 [ %v591, %yes.588 ], [ %v592, %no.589 ]
  store i8 %v593, ptr %v581, align 1, !tbaa !4
  %v594 = ptrtoint ptr %a3 to i64
  %v595 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v596 = and i64 %v594, %v595
  %v597 = and i64 %v596, 1
  %v598 = icmp ne i64 %v597, 0
  br i1 %v598, label %yes.599, label %no.600
yes.599:
  %v602 = sub i64 %v595, 1
  %v603 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v594, i64 %v602)
  %v604 = extractvalue { i64, i1 } %v603, 0
  %v605 = extractvalue { i64, i1 } %v603, 1
  br i1 %v605, label %yes.606, label %no.607
yes.606:
  %v609 = call ptr @mlf_add_int(ptr %a3, ptr inttoptr (i64 3 to ptr))
  br label %join.608
no.607:
  %v610 = inttoptr i64 %v604 to ptr
  br label %join.608
join.608:
  %v611 = phi ptr [ %v609, %yes.606 ], [ %v610, %no.607 ]
  br label %join.601
no.600:
  %v612 = call ptr @mlf_add_int(ptr %a3, ptr inttoptr (i64 3 to ptr))
  br label %join.601
join.601:
  %v613 = phi ptr [ %v611, %join.608 ], [ %v612, %no.600 ]
  %v614 = musttail call ptr @mlf.numeric.37(ptr %a0, ptr %a1, ptr %a2, ptr %v613)
  ret ptr %v614
tail.no.151:
  %v615 = ptrtoint ptr %a1 to i64
  %v616 = ptrtoint ptr inttoptr (i64 17 to ptr) to i64
  %v617 = and i64 %v615, %v616
  %v618 = and i64 %v617, 1
  %v619 = icmp ne i64 %v618, 0
  br i1 %v619, label %yes.620, label %no.621
yes.620:
  %v623 = ashr i64 %v615, 1
  %v624 = ashr i64 %v616, 1
  %v625 = icmp ne i64 %v624, 0
  %v626 = icmp eq i64 %v623, -4611686018427387904
  %v627 = icmp eq i64 %v624, -1
  %v628 = and i1 %v626, %v627
  %v629 = xor i1 %v628, true
  %v630 = and i1 %v625, %v629
  br i1 %v630, label %yes.631, label %no.632
yes.631:
  %v634 = sdiv i64 %v623, %v624
  %v635 = shl i64 %v634, 1
  %v636 = or i64 %v635, 1
  %v637 = inttoptr i64 %v636 to ptr
  br label %join.633
no.632:
  %v638 = call ptr @mlf_prim2(i64 15, ptr %a1, ptr inttoptr (i64 17 to ptr))
  br label %join.633
join.633:
  %v639 = phi ptr [ %v637, %yes.631 ], [ %v638, %no.632 ]
  br label %join.622
no.621:
  %v640 = call ptr @mlf_prim2(i64 15, ptr %a1, ptr inttoptr (i64 17 to ptr))
  br label %join.622
join.622:
  %v641 = phi ptr [ %v639, %join.633 ], [ %v640, %no.621 ]
  %v642 = ptrtoint ptr %a1 to i64
  %v643 = ptrtoint ptr inttoptr (i64 17 to ptr) to i64
  %v644 = and i64 %v642, %v643
  %v645 = and i64 %v644, 1
  %v646 = icmp ne i64 %v645, 0
  br i1 %v646, label %yes.647, label %no.648
yes.647:
  %v650 = ashr i64 %v642, 1
  %v651 = ashr i64 %v643, 1
  %v652 = icmp ne i64 %v651, 0
  %v653 = icmp eq i64 %v650, -4611686018427387904
  %v654 = icmp eq i64 %v651, -1
  %v655 = and i1 %v653, %v654
  %v656 = xor i1 %v655, true
  %v657 = and i1 %v652, %v656
  br i1 %v657, label %yes.658, label %no.659
yes.658:
  %v661 = srem i64 %v650, %v651
  %v662 = shl i64 %v661, 1
  %v663 = or i64 %v662, 1
  %v664 = inttoptr i64 %v663 to ptr
  br label %join.660
no.659:
  %v665 = call ptr @mlf_prim2(i64 16, ptr %a1, ptr inttoptr (i64 17 to ptr))
  br label %join.660
join.660:
  %v666 = phi ptr [ %v664, %yes.658 ], [ %v665, %no.659 ]
  br label %join.649
no.648:
  %v667 = call ptr @mlf_prim2(i64 16, ptr %a1, ptr inttoptr (i64 17 to ptr))
  br label %join.649
join.649:
  %v668 = phi ptr [ %v666, %join.660 ], [ %v667, %no.648 ]
  %v669 = ptrtoint ptr %v668 to i64
  %v670 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v671 = and i64 %v669, %v670
  %v672 = and i64 %v671, 1
  %v673 = icmp ne i64 %v672, 0
  br i1 %v673, label %yes.674, label %no.675
yes.674:
  %v677 = icmp eq i64 %v669, %v670
  %v678 = select i1 %v677, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.676
no.675:
  %v679 = call ptr @mlf_eq_int(ptr %v668, ptr inttoptr (i64 1 to ptr))
  br label %join.676
join.676:
  %v680 = phi ptr [ %v678, %yes.674 ], [ %v679, %no.675 ]
  %v681 = icmp eq ptr %v680, inttoptr (i64 6 to ptr)
  br i1 %v681, label %yes.682, label %no.683
yes.682:
  br label %join.684
no.683:
  %v685 = ptrtoint ptr %a1 to i64
  %v686 = ptrtoint ptr inttoptr (i64 17 to ptr) to i64
  %v687 = and i64 %v685, %v686
  %v688 = and i64 %v687, 1
  %v689 = icmp ne i64 %v688, 0
  br i1 %v689, label %yes.690, label %no.691
yes.690:
  %v693 = ashr i64 %v685, 1
  %v694 = ashr i64 %v686, 1
  %v695 = icmp ne i64 %v694, 0
  %v696 = icmp eq i64 %v693, -4611686018427387904
  %v697 = icmp eq i64 %v694, -1
  %v698 = and i1 %v696, %v697
  %v699 = xor i1 %v698, true
  %v700 = and i1 %v695, %v699
  br i1 %v700, label %yes.701, label %no.702
yes.701:
  %v704 = srem i64 %v693, %v694
  %v705 = shl i64 %v704, 1
  %v706 = or i64 %v705, 1
  %v707 = inttoptr i64 %v706 to ptr
  br label %join.703
no.702:
  %v708 = call ptr @mlf_prim2(i64 16, ptr %a1, ptr inttoptr (i64 17 to ptr))
  br label %join.703
join.703:
  %v709 = phi ptr [ %v707, %yes.701 ], [ %v708, %no.702 ]
  br label %join.692
no.691:
  %v710 = call ptr @mlf_prim2(i64 16, ptr %a1, ptr inttoptr (i64 17 to ptr))
  br label %join.692
join.692:
  %v711 = phi ptr [ %v709, %join.703 ], [ %v710, %no.691 ]
  %v712 = ptrtoint ptr inttoptr (i64 17 to ptr) to i64
  %v713 = ptrtoint ptr %v711 to i64
  %v714 = and i64 %v712, %v713
  %v715 = and i64 %v714, 1
  %v716 = icmp ne i64 %v715, 0
  br i1 %v716, label %yes.717, label %no.718
yes.717:
  %v720 = sub i64 %v713, 1
  %v721 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v712, i64 %v720)
  %v722 = extractvalue { i64, i1 } %v721, 0
  %v723 = extractvalue { i64, i1 } %v721, 1
  br i1 %v723, label %yes.724, label %no.725
yes.724:
  %v727 = call ptr @mlf_sub_int(ptr inttoptr (i64 17 to ptr), ptr %v711)
  br label %join.726
no.725:
  %v728 = inttoptr i64 %v722 to ptr
  br label %join.726
join.726:
  %v729 = phi ptr [ %v727, %yes.724 ], [ %v728, %no.725 ]
  br label %join.719
no.718:
  %v730 = call ptr @mlf_sub_int(ptr inttoptr (i64 17 to ptr), ptr %v711)
  br label %join.719
join.719:
  %v731 = phi ptr [ %v729, %join.726 ], [ %v730, %no.718 ]
  br label %join.684
join.684:
  %v732 = phi ptr [ inttoptr (i64 1 to ptr), %yes.682 ], [ %v731, %join.719 ]
  %v891 = call ptr @mlf.numeric.31(ptr %a0, ptr %v641, ptr %v732)
  ret ptr %v891
}

define private ptr @mlf.numeric.52(ptr %a0, ptr %a1, ptr %a2) alwaysinline {
entry:
  %v122 = ptrtoint ptr %a2 to i64
  %v123 = ptrtoint ptr %a1 to i64
  %v124 = and i64 %v122, %v123
  %v125 = and i64 %v124, 1
  %v126 = icmp ne i64 %v125, 0
  br i1 %v126, label %yes.127, label %no.128
yes.127:
  %v130 = icmp slt i64 %v122, %v123
  %v131 = select i1 %v130, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.129
no.128:
  %v132 = call ptr @mlf_lt_int(ptr %a2, ptr %a1)
  br label %join.129
join.129:
  %v133 = phi ptr [ %v131, %yes.127 ], [ %v132, %no.128 ]
  %v134 = icmp eq ptr %v133, inttoptr (i64 6 to ptr)
  br i1 %v134, label %tail.yes.135, label %tail.no.136
tail.yes.135:
  %v892 = call ptr @mlf.numeric.37(ptr %a0, ptr %a1, ptr %a2, ptr inttoptr (i64 1 to ptr))
  %v893 = ptrtoint ptr %a1 to i64
  %v894 = ptrtoint ptr inttoptr (i64 15 to ptr) to i64
  %v895 = and i64 %v893, %v894
  %v896 = and i64 %v895, 1
  %v897 = icmp ne i64 %v896, 0
  br i1 %v897, label %yes.898, label %no.899
yes.898:
  %v901 = sub i64 %v894, 1
  %v902 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v893, i64 %v901)
  %v903 = extractvalue { i64, i1 } %v902, 0
  %v904 = extractvalue { i64, i1 } %v902, 1
  br i1 %v904, label %yes.905, label %no.906
yes.905:
  %v908 = call ptr @mlf_add_int(ptr %a1, ptr inttoptr (i64 15 to ptr))
  br label %join.907
no.906:
  %v909 = inttoptr i64 %v903 to ptr
  br label %join.907
join.907:
  %v910 = phi ptr [ %v908, %yes.905 ], [ %v909, %no.906 ]
  br label %join.900
no.899:
  %v911 = call ptr @mlf_add_int(ptr %a1, ptr inttoptr (i64 15 to ptr))
  br label %join.900
join.900:
  %v912 = phi ptr [ %v910, %join.907 ], [ %v911, %no.899 ]
  %v913 = ptrtoint ptr %v912 to i64
  %v914 = ptrtoint ptr inttoptr (i64 17 to ptr) to i64
  %v915 = and i64 %v913, %v914
  %v916 = and i64 %v915, 1
  %v917 = icmp ne i64 %v916, 0
  br i1 %v917, label %yes.918, label %no.919
yes.918:
  %v921 = ashr i64 %v913, 1
  %v922 = ashr i64 %v914, 1
  %v923 = icmp ne i64 %v922, 0
  %v924 = icmp eq i64 %v921, -4611686018427387904
  %v925 = icmp eq i64 %v922, -1
  %v926 = and i1 %v924, %v925
  %v927 = xor i1 %v926, true
  %v928 = and i1 %v923, %v927
  br i1 %v928, label %yes.929, label %no.930
yes.929:
  %v932 = sdiv i64 %v921, %v922
  %v933 = shl i64 %v932, 1
  %v934 = or i64 %v933, 1
  %v935 = inttoptr i64 %v934 to ptr
  br label %join.931
no.930:
  %v936 = call ptr @mlf_prim2(i64 15, ptr %v912, ptr inttoptr (i64 17 to ptr))
  br label %join.931
join.931:
  %v937 = phi ptr [ %v935, %yes.929 ], [ %v936, %no.930 ]
  br label %join.920
no.919:
  %v938 = call ptr @mlf_prim2(i64 15, ptr %v912, ptr inttoptr (i64 17 to ptr))
  br label %join.920
join.920:
  %v939 = phi ptr [ %v937, %join.931 ], [ %v938, %no.919 ]
  %v940 = call ptr @mlf_put_bytes(ptr %a0, ptr inttoptr (i64 1 to ptr), ptr %v939)
  %v941 = ptrtoint ptr %a2 to i64
  %v942 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v943 = and i64 %v941, %v942
  %v944 = and i64 %v943, 1
  %v945 = icmp ne i64 %v944, 0
  br i1 %v945, label %yes.946, label %no.947
yes.946:
  %v949 = sub i64 %v942, 1
  %v950 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v941, i64 %v949)
  %v951 = extractvalue { i64, i1 } %v950, 0
  %v952 = extractvalue { i64, i1 } %v950, 1
  br i1 %v952, label %yes.953, label %no.954
yes.953:
  %v956 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 3 to ptr))
  br label %join.955
no.954:
  %v957 = inttoptr i64 %v951 to ptr
  br label %join.955
join.955:
  %v958 = phi ptr [ %v956, %yes.953 ], [ %v957, %no.954 ]
  br label %join.948
no.947:
  %v959 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 3 to ptr))
  br label %join.948
join.948:
  %v960 = phi ptr [ %v958, %join.955 ], [ %v959, %no.947 ]
  %v961 = musttail call ptr @mlf.numeric.52(ptr %a0, ptr %a1, ptr %v960)
  ret ptr %v961
tail.no.136:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.code.1007(ptr %env, ptr %arg) {
entry:
  %v1008 = getelementptr i8, ptr %env, i64 24
  %v1009 = load ptr, ptr %v1008, align 8, !tbaa !3
  %v1010 = getelementptr i8, ptr %env, i64 32
  %v1011 = load ptr, ptr %v1010, align 8, !tbaa !3
  %v1012 = call ptr @mlf_double(double 0x4000000000000000)
  %v1013 = call ptr @mlf_force(ptr %v1011)
  %v1014 = call ptr @mlf_prim1(i64 25, ptr %v1013)
  %v1015 = call ptr @mlf_prim2(i64 20, ptr %v1012, ptr %v1014)
  %v1016 = call ptr @mlf_force(ptr %v1009)
  %v1017 = call ptr @mlf_prim1(i64 25, ptr %v1016)
  %v1018 = call ptr @mlf_prim2(i64 21, ptr %v1015, ptr %v1017)
  %v1019 = call ptr @mlf_double(double 0x3ff8000000000000)
  %v1020 = call ptr @mlf_prim2(i64 19, ptr %v1018, ptr %v1019)
  ret ptr %v1020
}

define private ptr @mlf.code.1025(ptr %env, ptr %arg) {
entry:
  %v1026 = getelementptr i8, ptr %env, i64 24
  %v1027 = load ptr, ptr %v1026, align 8, !tbaa !3
  %v1028 = getelementptr i8, ptr %env, i64 32
  %v1029 = load ptr, ptr %v1028, align 8, !tbaa !3
  %v1030 = call ptr @mlf_double(double 0x4000000000000000)
  %v1031 = call ptr @mlf_force(ptr %v1029)
  %v1032 = call ptr @mlf_prim1(i64 25, ptr %v1031)
  %v1033 = call ptr @mlf_prim2(i64 20, ptr %v1030, ptr %v1032)
  %v1034 = call ptr @mlf_force(ptr %v1027)
  %v1035 = call ptr @mlf_prim1(i64 25, ptr %v1034)
  %v1036 = call ptr @mlf_prim2(i64 21, ptr %v1033, ptr %v1035)
  %v1037 = call ptr @mlf_double(double 0x3ff0000000000000)
  %v1038 = call ptr @mlf_prim2(i64 19, ptr %v1036, ptr %v1037)
  ret ptr %v1038
}

define private ptr @mlf.code.1043(ptr %env, ptr %arg) {
entry:
  %v1044 = getelementptr i8, ptr %env, i64 24
  %v1045 = load ptr, ptr %v1044, align 8, !tbaa !3
  %v1046 = call ptr @mlf_force(ptr %v1045)
  %v1047 = call ptr @mlf_prim2(i64 15, ptr %v1046, ptr inttoptr (i64 17 to ptr))
  ret ptr %v1047
}

define private ptr @mlf.code.1051(ptr %env, ptr %arg) {
entry:
  %v1052 = getelementptr i8, ptr %env, i64 24
  %v1053 = load ptr, ptr %v1052, align 8, !tbaa !3
  %v1054 = getelementptr i8, ptr %env, i64 32
  %v1055 = load ptr, ptr %v1054, align 8, !tbaa !3
  %v1056 = getelementptr i8, ptr %env, i64 40
  %v1057 = load ptr, ptr %v1056, align 8, !tbaa !3
  %v1058 = call ptr @mlf_force(ptr %v1055)
  %v1059 = call ptr @mlf_prim2(i64 16, ptr %v1058, ptr inttoptr (i64 17 to ptr))
  %v1060 = call ptr @mlf_prim2(i64 10, ptr %v1059, ptr inttoptr (i64 1 to ptr))
  %v1061 = icmp eq ptr %v1060, inttoptr (i64 6 to ptr)
  br i1 %v1061, label %yes.1062, label %no.1063
yes.1062:
  %v1065 = call ptr @mlf_prim3(i64 37, ptr %v1053, ptr %v1057, ptr inttoptr (i64 1 to ptr))
  br label %join.1064
no.1063:
  %v1066 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.1064
join.1064:
  %v1067 = phi ptr [ %v1065, %yes.1062 ], [ %v1066, %no.1063 ]
  ret ptr %v1067
}

define private ptr @mlf.code.1088(ptr %env, ptr %arg) {
entry:
  %v1089 = getelementptr i8, ptr %env, i64 24
  %v1090 = load ptr, ptr %v1089, align 8, !tbaa !3
  %v1091 = getelementptr i8, ptr %env, i64 32
  %v1092 = load ptr, ptr %v1091, align 8, !tbaa !3
  %v1093 = call ptr @mlf_prim2(i64 36, ptr %v1090, ptr %v1092)
  ret ptr %v1093
}

define private ptr @mlf.code.1121(ptr %env, ptr %arg) {
entry:
  %v1122 = getelementptr i8, ptr %env, i64 24
  %v1123 = load ptr, ptr %v1122, align 8, !tbaa !3
  %v1124 = getelementptr i8, ptr %env, i64 32
  %v1125 = load ptr, ptr %v1124, align 8, !tbaa !3
  %v1126 = call ptr @mlf_double(double 0x4000000000000000)
  %v1127 = call ptr @mlf_force(ptr %v1125)
  %v1128 = call ptr @mlf_prim2(i64 8, ptr %v1127, ptr inttoptr (i64 3 to ptr))
  %v1129 = call ptr @mlf_prim1(i64 25, ptr %v1128)
  %v1130 = call ptr @mlf_prim2(i64 20, ptr %v1126, ptr %v1129)
  %v1131 = call ptr @mlf_force(ptr %v1123)
  %v1132 = call ptr @mlf_prim1(i64 25, ptr %v1131)
  %v1133 = call ptr @mlf_prim2(i64 21, ptr %v1130, ptr %v1132)
  %v1134 = call ptr @mlf_double(double 0x3ff8000000000000)
  %v1135 = call ptr @mlf_prim2(i64 19, ptr %v1133, ptr %v1134)
  ret ptr %v1135
}

define private ptr @mlf.numeric.10.dddddddddddppp(double %a0, double %a1, double %a2, double %a3, double %a4, double %a5, double %a6, double %a7, double %a8, double %a9, double %a10, ptr %a11, ptr %a12, ptr %a13) alwaysinline {
entry:
  %v1331 = fadd double %a2, %a3
  %v1332 = fcmp olt double 0x4010000000000000, %v1331
  %v1333 = select i1 %v1332, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1334 = icmp eq ptr %v1333, inttoptr (i64 6 to ptr)
  br i1 %v1334, label %yes.1335, label %no.1336
yes.1335:
  br label %join.1337
no.1336:
  br label %join.1337
join.1337:
  %v1338 = phi ptr [ inttoptr (i64 2 to ptr), %yes.1335 ], [ %a11, %no.1336 ]
  %v1339 = fadd double %a7, %a8
  %v1340 = fcmp olt double 0x4010000000000000, %v1339
  %v1341 = select i1 %v1340, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1342 = icmp eq ptr %v1341, inttoptr (i64 6 to ptr)
  br i1 %v1342, label %yes.1343, label %no.1344
yes.1343:
  br label %join.1345
no.1344:
  br label %join.1345
join.1345:
  %v1346 = phi ptr [ inttoptr (i64 2 to ptr), %yes.1343 ], [ %a12, %no.1344 ]
  %v1347 = icmp eq ptr %v1338, inttoptr (i64 6 to ptr)
  br i1 %v1347, label %yes.1348, label %no.1349
yes.1348:
  br label %join.1350
no.1349:
  br label %join.1350
join.1350:
  %v1351 = phi ptr [ inttoptr (i64 6 to ptr), %yes.1348 ], [ %v1346, %no.1349 ]
  %v1352 = icmp eq ptr %v1351, inttoptr (i64 6 to ptr)
  br i1 %v1352, label %tail.yes.1353, label %tail.no.1354
tail.yes.1353:
  %v1355 = ptrtoint ptr %a13 to i64
  %v1356 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v1357 = and i64 %v1355, %v1356
  %v1358 = and i64 %v1357, 1
  %v1359 = icmp ne i64 %v1358, 0
  br i1 %v1359, label %yes.1360, label %no.1361
yes.1360:
  %v1363 = icmp eq i64 %v1355, %v1356
  %v1364 = select i1 %v1363, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1362
no.1361:
  %v1365 = call ptr @mlf_eq_int(ptr %a13, ptr inttoptr (i64 1 to ptr))
  br label %join.1362
join.1362:
  %v1366 = phi ptr [ %v1364, %yes.1360 ], [ %v1365, %no.1361 ]
  %v1367 = icmp eq ptr %v1366, inttoptr (i64 6 to ptr)
  br i1 %v1367, label %tail.yes.1368, label %tail.no.1369
tail.yes.1368:
  %v1370 = icmp eq ptr %v1338, inttoptr (i64 6 to ptr)
  br i1 %v1370, label %yes.1371, label %no.1372
yes.1371:
  br label %join.1373
no.1372:
  br label %join.1373
join.1373:
  %v1374 = phi ptr [ inttoptr (i64 5 to ptr), %yes.1371 ], [ inttoptr (i64 1 to ptr), %no.1372 ]
  %v1375 = icmp eq ptr %v1346, inttoptr (i64 6 to ptr)
  br i1 %v1375, label %yes.1376, label %no.1377
yes.1376:
  br label %join.1378
no.1377:
  br label %join.1378
join.1378:
  %v1379 = phi ptr [ inttoptr (i64 3 to ptr), %yes.1376 ], [ inttoptr (i64 1 to ptr), %no.1377 ]
  %v1380 = ptrtoint ptr %v1374 to i64
  %v1381 = ptrtoint ptr %v1379 to i64
  %v1382 = sub i64 %v1381, 1
  %v1383 = add nsw i64 %v1380, %v1382
  %v1384 = inttoptr i64 %v1383 to ptr
  ret ptr %v1384
tail.no.1369:
  %v1385 = fmul double 0x4000000000000000, %a0
  %v1386 = fmul double %v1385, %a1
  %v1387 = fadd double %v1386, %a10
  %v1388 = fsub double %a2, %a3
  %v1389 = fadd double %v1388, %a4
  %v1390 = fmul double 0x4000000000000000, %a5
  %v1391 = fmul double %v1390, %a6
  %v1392 = fadd double %v1391, %a10
  %v1393 = fsub double %a7, %a8
  %v1394 = fadd double %v1393, %a9
  %v1395 = fmul double %v1389, %v1389
  %v1396 = fmul double %v1387, %v1387
  %v1397 = fmul double %v1394, %v1394
  %v1398 = fmul double %v1392, %v1392
  %v1399 = ptrtoint ptr %a13 to i64
  %v1400 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1401 = and i64 %v1399, %v1400
  %v1402 = and i64 %v1401, 1
  %v1403 = icmp ne i64 %v1402, 0
  br i1 %v1403, label %yes.1404, label %no.1405
yes.1404:
  %v1407 = sub i64 %v1400, 1
  %v1408 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v1399, i64 %v1407)
  %v1409 = extractvalue { i64, i1 } %v1408, 0
  %v1410 = extractvalue { i64, i1 } %v1408, 1
  br i1 %v1410, label %yes.1411, label %no.1412
yes.1411:
  %v1414 = call ptr @mlf_sub_int(ptr %a13, ptr inttoptr (i64 3 to ptr))
  br label %join.1413
no.1412:
  %v1415 = inttoptr i64 %v1409 to ptr
  br label %join.1413
join.1413:
  %v1416 = phi ptr [ %v1414, %yes.1411 ], [ %v1415, %no.1412 ]
  br label %join.1406
no.1405:
  %v1417 = call ptr @mlf_sub_int(ptr %a13, ptr inttoptr (i64 3 to ptr))
  br label %join.1406
join.1406:
  %v1418 = phi ptr [ %v1416, %join.1413 ], [ %v1417, %no.1405 ]
  %v1419 = musttail call ptr @mlf.numeric.10.dddddddddddppp(double %v1389, double %v1387, double %v1395, double %v1396, double %a4, double %v1394, double %v1392, double %v1397, double %v1398, double %a9, double %a10, ptr %v1338, ptr %v1346, ptr %v1418)
  ret ptr %v1419
tail.no.1354:
  ret ptr inttoptr (i64 1 to ptr)
}

define private ptr @mlf.numeric.10(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6, ptr %a7, ptr %a8, ptr %a9, ptr %a10, ptr %a11, ptr %a12, ptr %a13) alwaysinline {
entry:
  %v1221 = getelementptr i8, ptr %a2, i64 24
  %v1222 = load double, ptr %v1221, align 8, !tbaa !3
  %v1223 = getelementptr i8, ptr %a3, i64 24
  %v1224 = load double, ptr %v1223, align 8, !tbaa !3
  %v1225 = fadd double %v1222, %v1224
  %v1226 = fcmp olt double 0x4010000000000000, %v1225
  %v1227 = select i1 %v1226, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1228 = icmp eq ptr %v1227, inttoptr (i64 6 to ptr)
  br i1 %v1228, label %yes.1229, label %no.1230
yes.1229:
  br label %join.1231
no.1230:
  br label %join.1231
join.1231:
  %v1232 = phi ptr [ inttoptr (i64 2 to ptr), %yes.1229 ], [ %a11, %no.1230 ]
  %v1233 = getelementptr i8, ptr %a7, i64 24
  %v1234 = load double, ptr %v1233, align 8, !tbaa !3
  %v1235 = getelementptr i8, ptr %a8, i64 24
  %v1236 = load double, ptr %v1235, align 8, !tbaa !3
  %v1237 = fadd double %v1234, %v1236
  %v1238 = fcmp olt double 0x4010000000000000, %v1237
  %v1239 = select i1 %v1238, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1240 = icmp eq ptr %v1239, inttoptr (i64 6 to ptr)
  br i1 %v1240, label %yes.1241, label %no.1242
yes.1241:
  br label %join.1243
no.1242:
  br label %join.1243
join.1243:
  %v1244 = phi ptr [ inttoptr (i64 2 to ptr), %yes.1241 ], [ %a12, %no.1242 ]
  %v1245 = icmp eq ptr %v1232, inttoptr (i64 6 to ptr)
  br i1 %v1245, label %yes.1246, label %no.1247
yes.1246:
  br label %join.1248
no.1247:
  br label %join.1248
join.1248:
  %v1249 = phi ptr [ inttoptr (i64 6 to ptr), %yes.1246 ], [ %v1244, %no.1247 ]
  %v1250 = icmp eq ptr %v1249, inttoptr (i64 6 to ptr)
  br i1 %v1250, label %tail.yes.1251, label %tail.no.1252
tail.yes.1251:
  %v1253 = ptrtoint ptr %a13 to i64
  %v1254 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v1255 = and i64 %v1253, %v1254
  %v1256 = and i64 %v1255, 1
  %v1257 = icmp ne i64 %v1256, 0
  br i1 %v1257, label %yes.1258, label %no.1259
yes.1258:
  %v1261 = icmp eq i64 %v1253, %v1254
  %v1262 = select i1 %v1261, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1260
no.1259:
  %v1263 = call ptr @mlf_eq_int(ptr %a13, ptr inttoptr (i64 1 to ptr))
  br label %join.1260
join.1260:
  %v1264 = phi ptr [ %v1262, %yes.1258 ], [ %v1263, %no.1259 ]
  %v1265 = icmp eq ptr %v1264, inttoptr (i64 6 to ptr)
  br i1 %v1265, label %tail.yes.1266, label %tail.no.1267
tail.yes.1266:
  %v1268 = icmp eq ptr %v1232, inttoptr (i64 6 to ptr)
  br i1 %v1268, label %yes.1269, label %no.1270
yes.1269:
  br label %join.1271
no.1270:
  br label %join.1271
join.1271:
  %v1272 = phi ptr [ inttoptr (i64 5 to ptr), %yes.1269 ], [ inttoptr (i64 1 to ptr), %no.1270 ]
  %v1273 = icmp eq ptr %v1244, inttoptr (i64 6 to ptr)
  br i1 %v1273, label %yes.1274, label %no.1275
yes.1274:
  br label %join.1276
no.1275:
  br label %join.1276
join.1276:
  %v1277 = phi ptr [ inttoptr (i64 3 to ptr), %yes.1274 ], [ inttoptr (i64 1 to ptr), %no.1275 ]
  %v1278 = ptrtoint ptr %v1272 to i64
  %v1279 = ptrtoint ptr %v1277 to i64
  %v1280 = sub i64 %v1279, 1
  %v1281 = add nsw i64 %v1278, %v1280
  %v1282 = inttoptr i64 %v1281 to ptr
  ret ptr %v1282
tail.no.1267:
  %v1283 = getelementptr i8, ptr %a0, i64 24
  %v1284 = load double, ptr %v1283, align 8, !tbaa !3
  %v1285 = fmul double 0x4000000000000000, %v1284
  %v1286 = getelementptr i8, ptr %a1, i64 24
  %v1287 = load double, ptr %v1286, align 8, !tbaa !3
  %v1288 = fmul double %v1285, %v1287
  %v1289 = getelementptr i8, ptr %a10, i64 24
  %v1290 = load double, ptr %v1289, align 8, !tbaa !3
  %v1291 = fadd double %v1288, %v1290
  %v1292 = fsub double %v1222, %v1224
  %v1293 = getelementptr i8, ptr %a4, i64 24
  %v1294 = load double, ptr %v1293, align 8, !tbaa !3
  %v1295 = fadd double %v1292, %v1294
  %v1296 = getelementptr i8, ptr %a5, i64 24
  %v1297 = load double, ptr %v1296, align 8, !tbaa !3
  %v1298 = fmul double 0x4000000000000000, %v1297
  %v1299 = getelementptr i8, ptr %a6, i64 24
  %v1300 = load double, ptr %v1299, align 8, !tbaa !3
  %v1301 = fmul double %v1298, %v1300
  %v1302 = fadd double %v1301, %v1290
  %v1303 = fsub double %v1234, %v1236
  %v1304 = getelementptr i8, ptr %a9, i64 24
  %v1305 = load double, ptr %v1304, align 8, !tbaa !3
  %v1306 = fadd double %v1303, %v1305
  %v1307 = fmul double %v1295, %v1295
  %v1308 = fmul double %v1291, %v1291
  %v1309 = fmul double %v1306, %v1306
  %v1310 = fmul double %v1302, %v1302
  %v1311 = ptrtoint ptr %a13 to i64
  %v1312 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1313 = and i64 %v1311, %v1312
  %v1314 = and i64 %v1313, 1
  %v1315 = icmp ne i64 %v1314, 0
  br i1 %v1315, label %yes.1316, label %no.1317
yes.1316:
  %v1319 = sub i64 %v1312, 1
  %v1320 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v1311, i64 %v1319)
  %v1321 = extractvalue { i64, i1 } %v1320, 0
  %v1322 = extractvalue { i64, i1 } %v1320, 1
  br i1 %v1322, label %yes.1323, label %no.1324
yes.1323:
  %v1326 = call ptr @mlf_sub_int(ptr %a13, ptr inttoptr (i64 3 to ptr))
  br label %join.1325
no.1324:
  %v1327 = inttoptr i64 %v1321 to ptr
  br label %join.1325
join.1325:
  %v1328 = phi ptr [ %v1326, %yes.1323 ], [ %v1327, %no.1324 ]
  br label %join.1318
no.1317:
  %v1329 = call ptr @mlf_sub_int(ptr %a13, ptr inttoptr (i64 3 to ptr))
  br label %join.1318
join.1318:
  %v1330 = phi ptr [ %v1328, %join.1325 ], [ %v1329, %no.1317 ]
  %v1420 = call ptr @mlf.numeric.10.dddddddddddppp(double %v1295, double %v1291, double %v1307, double %v1308, double %v1294, double %v1306, double %v1302, double %v1309, double %v1310, double %v1305, double %v1290, ptr %v1232, ptr %v1244, ptr %v1330)
  ret ptr %v1420
tail.no.1252:
  ret ptr inttoptr (i64 1 to ptr)
}

define private ptr @mlf.code.1432(ptr %env, ptr %arg) {
entry:
  %v1433 = getelementptr i8, ptr %env, i64 24
  %v1434 = load ptr, ptr %v1433, align 8, !tbaa !3
  %v1435 = getelementptr i8, ptr %env, i64 32
  %v1436 = load ptr, ptr %v1435, align 8, !tbaa !3
  %v1437 = getelementptr i8, ptr %env, i64 40
  %v1438 = load ptr, ptr %v1437, align 8, !tbaa !3
  %v1439 = call ptr @mlf_double(double 0x4010000000000000)
  %v1440 = call ptr @mlf_force(ptr %v1434)
  %v1441 = call ptr @mlf_force(ptr %v1436)
  %v1442 = call ptr @mlf_prim2(i64 18, ptr %v1440, ptr %v1441)
  %v1443 = call ptr @mlf_prim2(i64 24, ptr %v1439, ptr %v1442)
  %v1444 = icmp eq ptr %v1443, inttoptr (i64 6 to ptr)
  br i1 %v1444, label %yes.1445, label %no.1446
yes.1445:
  br label %join.1447
no.1446:
  %v1448 = call ptr @mlf_force(ptr %v1438)
  br label %join.1447
join.1447:
  %v1449 = phi ptr [ inttoptr (i64 2 to ptr), %yes.1445 ], [ %v1448, %no.1446 ]
  ret ptr %v1449
}

define private ptr @mlf.code.1471(ptr %env, ptr %arg) {
entry:
  %v1472 = getelementptr i8, ptr %env, i64 24
  %v1473 = load ptr, ptr %v1472, align 8, !tbaa !3
  %v1474 = getelementptr i8, ptr %env, i64 32
  %v1475 = load ptr, ptr %v1474, align 8, !tbaa !3
  %v1476 = call ptr @mlf_force(ptr %v1473)
  %v1477 = icmp eq ptr %v1476, inttoptr (i64 6 to ptr)
  br i1 %v1477, label %yes.1478, label %no.1479
yes.1478:
  br label %join.1480
no.1479:
  br label %join.1480
join.1480:
  %v1481 = phi ptr [ inttoptr (i64 5 to ptr), %yes.1478 ], [ inttoptr (i64 1 to ptr), %no.1479 ]
  %v1482 = call ptr @mlf_force(ptr %v1475)
  %v1483 = icmp eq ptr %v1482, inttoptr (i64 6 to ptr)
  br i1 %v1483, label %yes.1484, label %no.1485
yes.1484:
  br label %join.1486
no.1485:
  br label %join.1486
join.1486:
  %v1487 = phi ptr [ inttoptr (i64 3 to ptr), %yes.1484 ], [ inttoptr (i64 1 to ptr), %no.1485 ]
  %v1488 = call ptr @mlf_prim2(i64 8, ptr %v1481, ptr %v1487)
  ret ptr %v1488
}

define private ptr @mlf.code.1504(ptr %env, ptr %arg) {
entry:
  %v1505 = getelementptr i8, ptr %env, i64 24
  %v1506 = load ptr, ptr %v1505, align 8, !tbaa !3
  %v1507 = getelementptr i8, ptr %env, i64 32
  %v1508 = load ptr, ptr %v1507, align 8, !tbaa !3
  %v1509 = getelementptr i8, ptr %env, i64 40
  %v1510 = load ptr, ptr %v1509, align 8, !tbaa !3
  %v1511 = call ptr @mlf_double(double 0x4000000000000000)
  %v1512 = call ptr @mlf_force(ptr %v1506)
  %v1513 = call ptr @mlf_prim2(i64 20, ptr %v1511, ptr %v1512)
  %v1514 = call ptr @mlf_force(ptr %v1508)
  %v1515 = call ptr @mlf_prim2(i64 20, ptr %v1513, ptr %v1514)
  %v1516 = call ptr @mlf_force(ptr %v1510)
  %v1517 = call ptr @mlf_prim2(i64 18, ptr %v1515, ptr %v1516)
  ret ptr %v1517
}

define private ptr @mlf.code.1523(ptr %env, ptr %arg) {
entry:
  %v1524 = getelementptr i8, ptr %env, i64 24
  %v1525 = load ptr, ptr %v1524, align 8, !tbaa !3
  %v1526 = getelementptr i8, ptr %env, i64 32
  %v1527 = load ptr, ptr %v1526, align 8, !tbaa !3
  %v1528 = getelementptr i8, ptr %env, i64 40
  %v1529 = load ptr, ptr %v1528, align 8, !tbaa !3
  %v1530 = call ptr @mlf_force(ptr %v1525)
  %v1531 = call ptr @mlf_force(ptr %v1527)
  %v1532 = call ptr @mlf_prim2(i64 19, ptr %v1530, ptr %v1531)
  %v1533 = call ptr @mlf_force(ptr %v1529)
  %v1534 = call ptr @mlf_prim2(i64 18, ptr %v1532, ptr %v1533)
  ret ptr %v1534
}

define private ptr @mlf.code.1542(ptr %env, ptr %arg) {
entry:
  %v1543 = getelementptr i8, ptr %env, i64 24
  %v1544 = load ptr, ptr %v1543, align 8, !tbaa !3
  %v1545 = call ptr @mlf_force(ptr %v1544)
  %v1546 = call ptr @mlf_prim2(i64 20, ptr %v1545, ptr %v1545)
  ret ptr %v1546
}

define private ptr @mlf.code.1550(ptr %env, ptr %arg) {
entry:
  %v1551 = getelementptr i8, ptr %env, i64 24
  %v1552 = load ptr, ptr %v1551, align 8, !tbaa !3
  %v1553 = call ptr @mlf_force(ptr %v1552)
  %v1554 = call ptr @mlf_prim2(i64 20, ptr %v1553, ptr %v1553)
  ret ptr %v1554
}

define private ptr @mlf.code.1558(ptr %env, ptr %arg) {
entry:
  %v1559 = getelementptr i8, ptr %env, i64 24
  %v1560 = load ptr, ptr %v1559, align 8, !tbaa !3
  %v1561 = call ptr @mlf_force(ptr %v1560)
  %v1562 = call ptr @mlf_prim2(i64 9, ptr %v1561, ptr inttoptr (i64 3 to ptr))
  ret ptr %v1562
}

define private ptr @mlf.worker.10(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6, ptr %a7, ptr %a8, ptr %a9, ptr %a10, ptr %a11, ptr %a12, ptr %a13) {
entry:
  %v1423 = call ptr @mlf_double(double 0x4010000000000000)
  %v1424 = call ptr @mlf_prim2(i64 18, ptr %a2, ptr %a3)
  %v1425 = call ptr @mlf_prim2(i64 24, ptr %v1423, ptr %v1424)
  %v1426 = icmp eq ptr %v1425, inttoptr (i64 6 to ptr)
  br i1 %v1426, label %yes.1427, label %no.1428
yes.1427:
  br label %join.1429
no.1428:
  %v1430 = call ptr @mlf_force(ptr %a11)
  br label %join.1429
join.1429:
  %v1431 = phi ptr [ inttoptr (i64 2 to ptr), %yes.1427 ], [ %v1430, %no.1428 ]
  %v1450 = call ptr @mlf_env_new(i64 3)
  %v1451 = getelementptr i8, ptr %v1450, i64 24
  store ptr %a7, ptr %v1451, align 8, !tbaa !3
  %v1452 = getelementptr i8, ptr %v1450, i64 32
  store ptr %a8, ptr %v1452, align 8, !tbaa !3
  %v1453 = getelementptr i8, ptr %v1450, i64 40
  store ptr %a12, ptr %v1453, align 8, !tbaa !3
  %v1454 = call ptr @mlf_thunk(ptr @mlf.code.1432, ptr %v1450)
  %v1455 = icmp eq ptr %v1431, inttoptr (i64 6 to ptr)
  br i1 %v1455, label %yes.1456, label %no.1457
yes.1456:
  br label %join.1458
no.1457:
  %v1459 = call ptr @mlf_force(ptr %v1454)
  br label %join.1458
join.1458:
  %v1460 = phi ptr [ inttoptr (i64 6 to ptr), %yes.1456 ], [ %v1459, %no.1457 ]
  %v1461 = icmp eq ptr %v1460, inttoptr (i64 6 to ptr)
  br i1 %v1461, label %yes.1462, label %no.1463
yes.1462:
  %v1465 = call ptr @mlf_force(ptr %a13)
  %v1466 = call ptr @mlf_prim2(i64 10, ptr %v1465, ptr inttoptr (i64 1 to ptr))
  %v1467 = icmp eq ptr %v1466, inttoptr (i64 6 to ptr)
  br i1 %v1467, label %yes.1468, label %no.1469
yes.1468:
  %v1489 = call ptr @mlf_env_new(i64 2)
  %v1490 = getelementptr i8, ptr %v1489, i64 24
  store ptr %v1431, ptr %v1490, align 8, !tbaa !3
  %v1491 = getelementptr i8, ptr %v1489, i64 32
  store ptr %v1454, ptr %v1491, align 8, !tbaa !3
  %v1492 = call ptr @mlf_thunk(ptr @mlf.code.1471, ptr %v1489)
  %v1493 = call ptr @mlf_prim1(i64 0, ptr %v1492)
  br label %join.1470
no.1469:
  %v1494 = call ptr @mlf_double(double 0x4000000000000000)
  %v1495 = call ptr @mlf_force(ptr %a0)
  %v1496 = call ptr @mlf_prim2(i64 20, ptr %v1494, ptr %v1495)
  %v1497 = call ptr @mlf_force(ptr %a1)
  %v1498 = call ptr @mlf_prim2(i64 20, ptr %v1496, ptr %v1497)
  %v1499 = call ptr @mlf_force(ptr %a10)
  %v1500 = call ptr @mlf_prim2(i64 18, ptr %v1498, ptr %v1499)
  %v1501 = call ptr @mlf_prim2(i64 19, ptr %a2, ptr %a3)
  %v1502 = call ptr @mlf_force(ptr %a4)
  %v1503 = call ptr @mlf_prim2(i64 18, ptr %v1501, ptr %v1502)
  %v1518 = call ptr @mlf_env_new(i64 3)
  %v1519 = getelementptr i8, ptr %v1518, i64 24
  store ptr %a5, ptr %v1519, align 8, !tbaa !3
  %v1520 = getelementptr i8, ptr %v1518, i64 32
  store ptr %a6, ptr %v1520, align 8, !tbaa !3
  %v1521 = getelementptr i8, ptr %v1518, i64 40
  store ptr %v1499, ptr %v1521, align 8, !tbaa !3
  %v1522 = call ptr @mlf_thunk(ptr @mlf.code.1504, ptr %v1518)
  %v1535 = call ptr @mlf_env_new(i64 3)
  %v1536 = getelementptr i8, ptr %v1535, i64 24
  store ptr %a7, ptr %v1536, align 8, !tbaa !3
  %v1537 = getelementptr i8, ptr %v1535, i64 32
  store ptr %a8, ptr %v1537, align 8, !tbaa !3
  %v1538 = getelementptr i8, ptr %v1535, i64 40
  store ptr %a9, ptr %v1538, align 8, !tbaa !3
  %v1539 = call ptr @mlf_thunk(ptr @mlf.code.1523, ptr %v1535)
  %v1540 = call ptr @mlf_prim2(i64 20, ptr %v1503, ptr %v1503)
  %v1541 = call ptr @mlf_prim2(i64 20, ptr %v1500, ptr %v1500)
  %v1547 = call ptr @mlf_env_new(i64 1)
  %v1548 = getelementptr i8, ptr %v1547, i64 24
  store ptr %v1539, ptr %v1548, align 8, !tbaa !3
  %v1549 = call ptr @mlf_thunk(ptr @mlf.code.1542, ptr %v1547)
  %v1555 = call ptr @mlf_env_new(i64 1)
  %v1556 = getelementptr i8, ptr %v1555, i64 24
  store ptr %v1522, ptr %v1556, align 8, !tbaa !3
  %v1557 = call ptr @mlf_thunk(ptr @mlf.code.1550, ptr %v1555)
  %v1563 = call ptr @mlf_env_new(i64 1)
  %v1564 = getelementptr i8, ptr %v1563, i64 24
  store ptr %v1465, ptr %v1564, align 8, !tbaa !3
  %v1565 = call ptr @mlf_thunk(ptr @mlf.code.1558, ptr %v1563)
  %v1566 = call ptr @mlf_env_new(i64 14)
  %v1567 = getelementptr i8, ptr %v1566, i64 24
  store ptr %v1503, ptr %v1567, align 8, !tbaa !3
  %v1568 = getelementptr i8, ptr %v1566, i64 32
  store ptr %v1500, ptr %v1568, align 8, !tbaa !3
  %v1569 = getelementptr i8, ptr %v1566, i64 40
  store ptr %v1540, ptr %v1569, align 8, !tbaa !3
  %v1570 = getelementptr i8, ptr %v1566, i64 48
  store ptr %v1541, ptr %v1570, align 8, !tbaa !3
  %v1571 = getelementptr i8, ptr %v1566, i64 56
  store ptr %v1502, ptr %v1571, align 8, !tbaa !3
  %v1572 = getelementptr i8, ptr %v1566, i64 64
  store ptr %v1539, ptr %v1572, align 8, !tbaa !3
  %v1573 = getelementptr i8, ptr %v1566, i64 72
  store ptr %v1522, ptr %v1573, align 8, !tbaa !3
  %v1574 = getelementptr i8, ptr %v1566, i64 80
  store ptr %v1549, ptr %v1574, align 8, !tbaa !3
  %v1575 = getelementptr i8, ptr %v1566, i64 88
  store ptr %v1557, ptr %v1575, align 8, !tbaa !3
  %v1576 = getelementptr i8, ptr %v1566, i64 96
  store ptr %a9, ptr %v1576, align 8, !tbaa !3
  %v1577 = getelementptr i8, ptr %v1566, i64 104
  store ptr %v1499, ptr %v1577, align 8, !tbaa !3
  %v1578 = getelementptr i8, ptr %v1566, i64 112
  store ptr %v1431, ptr %v1578, align 8, !tbaa !3
  %v1579 = getelementptr i8, ptr %v1566, i64 120
  store ptr %v1454, ptr %v1579, align 8, !tbaa !3
  %v1580 = getelementptr i8, ptr %v1566, i64 128
  store ptr %v1565, ptr %v1580, align 8, !tbaa !3
  %v1581 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1147, ptr %v1566)
  br label %join.1470
join.1470:
  %v1582 = phi ptr [ %v1493, %yes.1468 ], [ %v1581, %no.1469 ]
  br label %join.1464
no.1463:
  %v1583 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 1 to ptr))
  br label %join.1464
join.1464:
  %v1584 = phi ptr [ %v1582, %join.1470 ], [ %v1583, %no.1463 ]
  ret ptr %v1584
}

define private ptr @mlf.numeric.entry.1147(ptr %env, ptr %arg) {
entry:
  %v1148 = getelementptr i8, ptr %env, i64 24
  %v1149 = load ptr, ptr %v1148, align 8, !tbaa !3
  %v1150 = getelementptr i8, ptr %env, i64 32
  %v1151 = load ptr, ptr %v1150, align 8, !tbaa !3
  %v1152 = getelementptr i8, ptr %env, i64 40
  %v1153 = load ptr, ptr %v1152, align 8, !tbaa !3
  %v1154 = getelementptr i8, ptr %env, i64 48
  %v1155 = load ptr, ptr %v1154, align 8, !tbaa !3
  %v1156 = getelementptr i8, ptr %env, i64 56
  %v1157 = load ptr, ptr %v1156, align 8, !tbaa !3
  %v1158 = getelementptr i8, ptr %env, i64 64
  %v1159 = load ptr, ptr %v1158, align 8, !tbaa !3
  %v1160 = getelementptr i8, ptr %env, i64 72
  %v1161 = load ptr, ptr %v1160, align 8, !tbaa !3
  %v1162 = getelementptr i8, ptr %env, i64 80
  %v1163 = load ptr, ptr %v1162, align 8, !tbaa !3
  %v1164 = getelementptr i8, ptr %env, i64 88
  %v1165 = load ptr, ptr %v1164, align 8, !tbaa !3
  %v1166 = getelementptr i8, ptr %env, i64 96
  %v1167 = load ptr, ptr %v1166, align 8, !tbaa !3
  %v1168 = getelementptr i8, ptr %env, i64 104
  %v1169 = load ptr, ptr %v1168, align 8, !tbaa !3
  %v1170 = getelementptr i8, ptr %env, i64 112
  %v1171 = load ptr, ptr %v1170, align 8, !tbaa !3
  %v1172 = getelementptr i8, ptr %env, i64 120
  %v1173 = load ptr, ptr %v1172, align 8, !tbaa !3
  %v1174 = getelementptr i8, ptr %env, i64 128
  %v1175 = load ptr, ptr %v1174, align 8, !tbaa !3
  %v1176 = call ptr @mlf_peek(ptr %v1149)
  %v1177 = call ptr @mlf_peek(ptr %v1151)
  %v1178 = call ptr @mlf_peek(ptr %v1153)
  %v1179 = call ptr @mlf_peek(ptr %v1155)
  %v1180 = call ptr @mlf_peek(ptr %v1157)
  %v1181 = call ptr @mlf_peek(ptr %v1159)
  %v1182 = call ptr @mlf_peek(ptr %v1161)
  %v1183 = call ptr @mlf_peek(ptr %v1163)
  %v1184 = call ptr @mlf_peek(ptr %v1165)
  %v1185 = call ptr @mlf_peek(ptr %v1167)
  %v1186 = call ptr @mlf_peek(ptr %v1169)
  %v1187 = call ptr @mlf_peek(ptr %v1171)
  %v1188 = call ptr @mlf_peek(ptr %v1173)
  %v1189 = call ptr @mlf_peek(ptr %v1175)
  %v1190 = icmp ne ptr %v1176, null
  %v1191 = icmp ne ptr %v1177, null
  %v1192 = icmp ne ptr %v1178, null
  %v1193 = icmp ne ptr %v1179, null
  %v1194 = icmp ne ptr %v1180, null
  %v1195 = icmp ne ptr %v1181, null
  %v1196 = icmp ne ptr %v1182, null
  %v1197 = icmp ne ptr %v1183, null
  %v1198 = icmp ne ptr %v1184, null
  %v1199 = icmp ne ptr %v1185, null
  %v1200 = icmp ne ptr %v1186, null
  %v1201 = icmp ne ptr %v1187, null
  %v1202 = icmp ne ptr %v1188, null
  %v1203 = icmp ne ptr %v1189, null
  %v1204 = and i1 true, %v1190
  %v1205 = and i1 %v1204, %v1191
  %v1206 = and i1 %v1205, %v1192
  %v1207 = and i1 %v1206, %v1193
  %v1208 = and i1 %v1207, %v1194
  %v1209 = and i1 %v1208, %v1195
  %v1210 = and i1 %v1209, %v1196
  %v1211 = and i1 %v1210, %v1197
  %v1212 = and i1 %v1211, %v1198
  %v1213 = and i1 %v1212, %v1199
  %v1214 = and i1 %v1213, %v1200
  %v1215 = and i1 %v1214, %v1201
  %v1216 = and i1 %v1215, %v1202
  %v1217 = and i1 %v1216, %v1203
  br i1 %v1217, label %yes.1218, label %no.1219
yes.1218:
  %v1421 = call ptr @mlf.numeric.10(ptr %v1176, ptr %v1177, ptr %v1178, ptr %v1179, ptr %v1180, ptr %v1181, ptr %v1182, ptr %v1183, ptr %v1184, ptr %v1185, ptr %v1186, ptr %v1187, ptr %v1188, ptr %v1189)
  %v1422 = call ptr @mlf_prim1(i64 0, ptr %v1421)
  br label %join.1220
no.1219:
  %v1585 = call ptr @mlf_force(ptr %v1153)
  %v1586 = call ptr @mlf_force(ptr %v1155)
  %v1587 = call ptr @mlf.worker.10(ptr %v1149, ptr %v1151, ptr %v1585, ptr %v1586, ptr %v1157, ptr %v1159, ptr %v1161, ptr %v1163, ptr %v1165, ptr %v1167, ptr %v1169, ptr %v1171, ptr %v1173, ptr %v1175)
  br label %join.1220
join.1220:
  %v1588 = phi ptr [ %v1422, %yes.1218 ], [ %v1587, %no.1219 ]
  ret ptr %v1588
}

define private ptr @mlf.code.1140(ptr %env, ptr %arg) {
entry:
  %v1141 = getelementptr i8, ptr %env, i64 24
  %v1142 = load ptr, ptr %v1141, align 8, !tbaa !3
  %v1143 = getelementptr i8, ptr %env, i64 32
  %v1144 = load ptr, ptr %v1143, align 8, !tbaa !3
  %v1145 = getelementptr i8, ptr %env, i64 40
  %v1146 = load ptr, ptr %v1145, align 8, !tbaa !3
  %v1589 = call ptr @mlf_double(double 0x0000000000000000)
  %v1590 = call ptr @mlf_double(double 0x0000000000000000)
  %v1591 = call ptr @mlf_double(double 0x0000000000000000)
  %v1592 = call ptr @mlf_double(double 0x0000000000000000)
  %v1593 = call ptr @mlf_double(double 0x0000000000000000)
  %v1594 = call ptr @mlf_double(double 0x0000000000000000)
  %v1595 = call ptr @mlf_double(double 0x0000000000000000)
  %v1596 = call ptr @mlf_double(double 0x0000000000000000)
  %v1597 = call ptr @mlf_env_new(i64 14)
  %v1598 = getelementptr i8, ptr %v1597, i64 24
  store ptr %v1589, ptr %v1598, align 8, !tbaa !3
  %v1599 = getelementptr i8, ptr %v1597, i64 32
  store ptr %v1590, ptr %v1599, align 8, !tbaa !3
  %v1600 = getelementptr i8, ptr %v1597, i64 40
  store ptr %v1591, ptr %v1600, align 8, !tbaa !3
  %v1601 = getelementptr i8, ptr %v1597, i64 48
  store ptr %v1592, ptr %v1601, align 8, !tbaa !3
  %v1602 = getelementptr i8, ptr %v1597, i64 56
  store ptr %v1142, ptr %v1602, align 8, !tbaa !3
  %v1603 = getelementptr i8, ptr %v1597, i64 64
  store ptr %v1593, ptr %v1603, align 8, !tbaa !3
  %v1604 = getelementptr i8, ptr %v1597, i64 72
  store ptr %v1594, ptr %v1604, align 8, !tbaa !3
  %v1605 = getelementptr i8, ptr %v1597, i64 80
  store ptr %v1595, ptr %v1605, align 8, !tbaa !3
  %v1606 = getelementptr i8, ptr %v1597, i64 88
  store ptr %v1596, ptr %v1606, align 8, !tbaa !3
  %v1607 = getelementptr i8, ptr %v1597, i64 96
  store ptr %v1146, ptr %v1607, align 8, !tbaa !3
  %v1608 = getelementptr i8, ptr %v1597, i64 104
  store ptr %v1144, ptr %v1608, align 8, !tbaa !3
  %v1609 = getelementptr i8, ptr %v1597, i64 112
  store ptr inttoptr (i64 6 to ptr), ptr %v1609, align 8, !tbaa !3
  %v1610 = getelementptr i8, ptr %v1597, i64 120
  store ptr inttoptr (i64 6 to ptr), ptr %v1610, align 8, !tbaa !3
  %v1611 = getelementptr i8, ptr %v1597, i64 128
  store ptr inttoptr (i64 101 to ptr), ptr %v1611, align 8, !tbaa !3
  %v1612 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1147, ptr %v1597)
  ret ptr %v1612
}

define private ptr @mlf.code.1640(ptr %env, ptr %arg) {
entry:
  %v1641 = getelementptr i8, ptr %env, i64 24
  %v1642 = load ptr, ptr %v1641, align 8, !tbaa !3
  %v1643 = getelementptr i8, ptr %env, i64 32
  %v1644 = load ptr, ptr %v1643, align 8, !tbaa !3
  %v1645 = call ptr @mlf_force(ptr %v1642)
  %v1646 = call ptr @mlf_prim2(i64 14, ptr %v1645, ptr inttoptr (i64 9 to ptr))
  %v1647 = call ptr @mlf_force(ptr %v1644)
  %v1648 = call ptr @mlf_prim2(i64 8, ptr %v1646, ptr %v1647)
  ret ptr %v1648
}

define private ptr @mlf.code.1631(ptr %env, ptr %arg) {
entry:
  %v1632 = getelementptr i8, ptr %env, i64 24
  %v1633 = load ptr, ptr %v1632, align 8, !tbaa !3
  %v1634 = getelementptr i8, ptr %env, i64 32
  %v1635 = load ptr, ptr %v1634, align 8, !tbaa !3
  %v1636 = getelementptr i8, ptr %env, i64 40
  %v1637 = load ptr, ptr %v1636, align 8, !tbaa !3
  %v1638 = getelementptr i8, ptr %env, i64 48
  %v1639 = load ptr, ptr %v1638, align 8, !tbaa !3
  %v1649 = call ptr @mlf_env_new(i64 2)
  %v1650 = getelementptr i8, ptr %v1649, i64 24
  store ptr %v1637, ptr %v1650, align 8, !tbaa !3
  %v1651 = getelementptr i8, ptr %v1649, i64 32
  store ptr %v1639, ptr %v1651, align 8, !tbaa !3
  %v1652 = call ptr @mlf_thunk(ptr @mlf.code.1640, ptr %v1649)
  %v1653 = call ptr @mlf_prim3(i64 37, ptr %v1633, ptr %v1635, ptr %v1652)
  ret ptr %v1653
}

define private ptr @mlf.code.1660(ptr %env, ptr %arg) {
entry:
  %v1661 = getelementptr i8, ptr %env, i64 24
  %v1662 = load ptr, ptr %v1661, align 8, !tbaa !3
  %v1663 = getelementptr i8, ptr %env, i64 32
  %v1664 = load ptr, ptr %v1663, align 8, !tbaa !3
  %v1665 = getelementptr i8, ptr %env, i64 40
  %v1666 = load ptr, ptr %v1665, align 8, !tbaa !3
  %v1667 = getelementptr i8, ptr %env, i64 48
  %v1668 = load ptr, ptr %v1667, align 8, !tbaa !3
  %v1669 = call ptr @mlf_force(ptr %v1664)
  %v1670 = call ptr @mlf_force(ptr %v1668)
  %v1671 = call ptr @mlf_prim2(i64 8, ptr %v1670, ptr inttoptr (i64 5 to ptr))
  %v1672 = call ptr @mlf_env_new(i64 4)
  %v1673 = getelementptr i8, ptr %v1672, i64 24
  store ptr %v1662, ptr %v1673, align 8, !tbaa !3
  %v1674 = getelementptr i8, ptr %v1672, i64 32
  store ptr %v1669, ptr %v1674, align 8, !tbaa !3
  %v1675 = getelementptr i8, ptr %v1672, i64 40
  store ptr %v1666, ptr %v1675, align 8, !tbaa !3
  %v1676 = getelementptr i8, ptr %v1672, i64 48
  store ptr %v1671, ptr %v1676, align 8, !tbaa !3
  %v1677 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.976, ptr %v1672)
  ret ptr %v1677
}

define private ptr @mlf.code.1618(ptr %env, ptr %arg) {
entry:
  %v1619 = getelementptr i8, ptr %env, i64 24
  %v1620 = load ptr, ptr %v1619, align 8, !tbaa !3
  %v1621 = getelementptr i8, ptr %env, i64 32
  %v1622 = load ptr, ptr %v1621, align 8, !tbaa !3
  %v1623 = getelementptr i8, ptr %env, i64 40
  %v1624 = load ptr, ptr %v1623, align 8, !tbaa !3
  %v1625 = getelementptr i8, ptr %env, i64 48
  %v1626 = load ptr, ptr %v1625, align 8, !tbaa !3
  %v1627 = getelementptr i8, ptr %env, i64 56
  %v1628 = load ptr, ptr %v1627, align 8, !tbaa !3
  %v1629 = getelementptr i8, ptr %env, i64 64
  %v1630 = load ptr, ptr %v1629, align 8, !tbaa !3
  %v1654 = call ptr @mlf_env_new(i64 4)
  %v1655 = getelementptr i8, ptr %v1654, i64 24
  store ptr %v1620, ptr %v1655, align 8, !tbaa !3
  %v1656 = getelementptr i8, ptr %v1654, i64 32
  store ptr %v1628, ptr %v1656, align 8, !tbaa !3
  %v1657 = getelementptr i8, ptr %v1654, i64 40
  store ptr %v1630, ptr %v1657, align 8, !tbaa !3
  %v1658 = getelementptr i8, ptr %v1654, i64 48
  store ptr %arg, ptr %v1658, align 8, !tbaa !3
  %v1659 = call ptr @mlf_thunk(ptr @mlf.code.1631, ptr %v1654)
  %v1678 = call ptr @mlf_env_new(i64 4)
  %v1679 = getelementptr i8, ptr %v1678, i64 24
  store ptr %v1620, ptr %v1679, align 8, !tbaa !3
  %v1680 = getelementptr i8, ptr %v1678, i64 32
  store ptr %v1622, ptr %v1680, align 8, !tbaa !3
  %v1681 = getelementptr i8, ptr %v1678, i64 40
  store ptr %v1624, ptr %v1681, align 8, !tbaa !3
  %v1682 = getelementptr i8, ptr %v1678, i64 48
  store ptr %v1626, ptr %v1682, align 8, !tbaa !3
  %v1683 = call ptr @mlf_closure(ptr @mlf.code.1660, ptr %v1678)
  %v1684 = call ptr @mlf_prim2(i64 1, ptr %v1659, ptr %v1683)
  ret ptr %v1684
}

define private ptr @mlf.numeric.0.ddddddp(double %a0, double %a1, double %a2, double %a3, double %a4, double %a5, ptr %a6) alwaysinline {
entry:
  %v1798 = fadd double %a2, %a3
  %v1799 = fcmp olt double 0x4010000000000000, %v1798
  %v1800 = select i1 %v1799, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1801 = icmp eq ptr %v1800, inttoptr (i64 6 to ptr)
  br i1 %v1801, label %tail.yes.1802, label %tail.no.1803
tail.yes.1802:
  ret ptr inttoptr (i64 1 to ptr)
tail.no.1803:
  %v1804 = ptrtoint ptr %a6 to i64
  %v1805 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v1806 = and i64 %v1804, %v1805
  %v1807 = and i64 %v1806, 1
  %v1808 = icmp ne i64 %v1807, 0
  br i1 %v1808, label %yes.1809, label %no.1810
yes.1809:
  %v1812 = icmp eq i64 %v1804, %v1805
  %v1813 = select i1 %v1812, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1811
no.1810:
  %v1814 = call ptr @mlf_eq_int(ptr %a6, ptr inttoptr (i64 1 to ptr))
  br label %join.1811
join.1811:
  %v1815 = phi ptr [ %v1813, %yes.1809 ], [ %v1814, %no.1810 ]
  %v1816 = icmp eq ptr %v1815, inttoptr (i64 6 to ptr)
  br i1 %v1816, label %tail.yes.1817, label %tail.no.1818
tail.yes.1817:
  ret ptr inttoptr (i64 3 to ptr)
tail.no.1818:
  %v1819 = fmul double 0x4000000000000000, %a0
  %v1820 = fmul double %v1819, %a1
  %v1821 = fadd double %v1820, %a5
  %v1822 = fsub double %a2, %a3
  %v1823 = fadd double %v1822, %a4
  %v1824 = fmul double %v1823, %v1823
  %v1825 = fmul double %v1821, %v1821
  %v1826 = ptrtoint ptr %a6 to i64
  %v1827 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1828 = and i64 %v1826, %v1827
  %v1829 = and i64 %v1828, 1
  %v1830 = icmp ne i64 %v1829, 0
  br i1 %v1830, label %yes.1831, label %no.1832
yes.1831:
  %v1834 = sub i64 %v1827, 1
  %v1835 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v1826, i64 %v1834)
  %v1836 = extractvalue { i64, i1 } %v1835, 0
  %v1837 = extractvalue { i64, i1 } %v1835, 1
  br i1 %v1837, label %yes.1838, label %no.1839
yes.1838:
  %v1841 = call ptr @mlf_sub_int(ptr %a6, ptr inttoptr (i64 3 to ptr))
  br label %join.1840
no.1839:
  %v1842 = inttoptr i64 %v1836 to ptr
  br label %join.1840
join.1840:
  %v1843 = phi ptr [ %v1841, %yes.1838 ], [ %v1842, %no.1839 ]
  br label %join.1833
no.1832:
  %v1844 = call ptr @mlf_sub_int(ptr %a6, ptr inttoptr (i64 3 to ptr))
  br label %join.1833
join.1833:
  %v1845 = phi ptr [ %v1843, %join.1840 ], [ %v1844, %no.1832 ]
  %v1846 = musttail call ptr @mlf.numeric.0.ddddddp(double %v1823, double %v1821, double %v1824, double %v1825, double %a4, double %a5, ptr %v1845)
  ret ptr %v1846
}

define private ptr @mlf.numeric.0(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6) alwaysinline {
entry:
  %v1738 = getelementptr i8, ptr %a2, i64 24
  %v1739 = load double, ptr %v1738, align 8, !tbaa !3
  %v1740 = getelementptr i8, ptr %a3, i64 24
  %v1741 = load double, ptr %v1740, align 8, !tbaa !3
  %v1742 = fadd double %v1739, %v1741
  %v1743 = fcmp olt double 0x4010000000000000, %v1742
  %v1744 = select i1 %v1743, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1745 = icmp eq ptr %v1744, inttoptr (i64 6 to ptr)
  br i1 %v1745, label %tail.yes.1746, label %tail.no.1747
tail.yes.1746:
  ret ptr inttoptr (i64 1 to ptr)
tail.no.1747:
  %v1748 = ptrtoint ptr %a6 to i64
  %v1749 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v1750 = and i64 %v1748, %v1749
  %v1751 = and i64 %v1750, 1
  %v1752 = icmp ne i64 %v1751, 0
  br i1 %v1752, label %yes.1753, label %no.1754
yes.1753:
  %v1756 = icmp eq i64 %v1748, %v1749
  %v1757 = select i1 %v1756, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1755
no.1754:
  %v1758 = call ptr @mlf_eq_int(ptr %a6, ptr inttoptr (i64 1 to ptr))
  br label %join.1755
join.1755:
  %v1759 = phi ptr [ %v1757, %yes.1753 ], [ %v1758, %no.1754 ]
  %v1760 = icmp eq ptr %v1759, inttoptr (i64 6 to ptr)
  br i1 %v1760, label %tail.yes.1761, label %tail.no.1762
tail.yes.1761:
  ret ptr inttoptr (i64 3 to ptr)
tail.no.1762:
  %v1763 = getelementptr i8, ptr %a0, i64 24
  %v1764 = load double, ptr %v1763, align 8, !tbaa !3
  %v1765 = fmul double 0x4000000000000000, %v1764
  %v1766 = getelementptr i8, ptr %a1, i64 24
  %v1767 = load double, ptr %v1766, align 8, !tbaa !3
  %v1768 = fmul double %v1765, %v1767
  %v1769 = getelementptr i8, ptr %a5, i64 24
  %v1770 = load double, ptr %v1769, align 8, !tbaa !3
  %v1771 = fadd double %v1768, %v1770
  %v1772 = fsub double %v1739, %v1741
  %v1773 = getelementptr i8, ptr %a4, i64 24
  %v1774 = load double, ptr %v1773, align 8, !tbaa !3
  %v1775 = fadd double %v1772, %v1774
  %v1776 = fmul double %v1775, %v1775
  %v1777 = fmul double %v1771, %v1771
  %v1778 = ptrtoint ptr %a6 to i64
  %v1779 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1780 = and i64 %v1778, %v1779
  %v1781 = and i64 %v1780, 1
  %v1782 = icmp ne i64 %v1781, 0
  br i1 %v1782, label %yes.1783, label %no.1784
yes.1783:
  %v1786 = sub i64 %v1779, 1
  %v1787 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v1778, i64 %v1786)
  %v1788 = extractvalue { i64, i1 } %v1787, 0
  %v1789 = extractvalue { i64, i1 } %v1787, 1
  br i1 %v1789, label %yes.1790, label %no.1791
yes.1790:
  %v1793 = call ptr @mlf_sub_int(ptr %a6, ptr inttoptr (i64 3 to ptr))
  br label %join.1792
no.1791:
  %v1794 = inttoptr i64 %v1788 to ptr
  br label %join.1792
join.1792:
  %v1795 = phi ptr [ %v1793, %yes.1790 ], [ %v1794, %no.1791 ]
  br label %join.1785
no.1784:
  %v1796 = call ptr @mlf_sub_int(ptr %a6, ptr inttoptr (i64 3 to ptr))
  br label %join.1785
join.1785:
  %v1797 = phi ptr [ %v1795, %join.1792 ], [ %v1796, %no.1784 ]
  %v1847 = call ptr @mlf.numeric.0.ddddddp(double %v1775, double %v1771, double %v1776, double %v1777, double %v1774, double %v1770, ptr %v1797)
  ret ptr %v1847
}

define private ptr @mlf.code.1877(ptr %env, ptr %arg) {
entry:
  %v1878 = getelementptr i8, ptr %env, i64 24
  %v1879 = load ptr, ptr %v1878, align 8, !tbaa !3
  %v1880 = call ptr @mlf_force(ptr %v1879)
  %v1881 = call ptr @mlf_prim2(i64 9, ptr %v1880, ptr inttoptr (i64 3 to ptr))
  ret ptr %v1881
}

define private ptr @mlf.worker.0(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6) {
entry:
  %v1850 = call ptr @mlf_double(double 0x4010000000000000)
  %v1851 = call ptr @mlf_prim2(i64 18, ptr %a2, ptr %a3)
  %v1852 = call ptr @mlf_prim2(i64 24, ptr %v1850, ptr %v1851)
  %v1853 = icmp eq ptr %v1852, inttoptr (i64 6 to ptr)
  br i1 %v1853, label %yes.1854, label %no.1855
yes.1854:
  %v1857 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 1 to ptr))
  br label %join.1856
no.1855:
  %v1858 = call ptr @mlf_force(ptr %a6)
  %v1859 = call ptr @mlf_prim2(i64 10, ptr %v1858, ptr inttoptr (i64 1 to ptr))
  %v1860 = icmp eq ptr %v1859, inttoptr (i64 6 to ptr)
  br i1 %v1860, label %yes.1861, label %no.1862
yes.1861:
  %v1864 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 3 to ptr))
  br label %join.1863
no.1862:
  %v1865 = call ptr @mlf_double(double 0x4000000000000000)
  %v1866 = call ptr @mlf_force(ptr %a0)
  %v1867 = call ptr @mlf_prim2(i64 20, ptr %v1865, ptr %v1866)
  %v1868 = call ptr @mlf_force(ptr %a1)
  %v1869 = call ptr @mlf_prim2(i64 20, ptr %v1867, ptr %v1868)
  %v1870 = call ptr @mlf_force(ptr %a5)
  %v1871 = call ptr @mlf_prim2(i64 18, ptr %v1869, ptr %v1870)
  %v1872 = call ptr @mlf_prim2(i64 19, ptr %a2, ptr %a3)
  %v1873 = call ptr @mlf_force(ptr %a4)
  %v1874 = call ptr @mlf_prim2(i64 18, ptr %v1872, ptr %v1873)
  %v1875 = call ptr @mlf_prim2(i64 20, ptr %v1874, ptr %v1874)
  %v1876 = call ptr @mlf_prim2(i64 20, ptr %v1871, ptr %v1871)
  %v1882 = call ptr @mlf_env_new(i64 1)
  %v1883 = getelementptr i8, ptr %v1882, i64 24
  store ptr %v1858, ptr %v1883, align 8, !tbaa !3
  %v1884 = call ptr @mlf_thunk(ptr @mlf.code.1877, ptr %v1882)
  %v1885 = call ptr @mlf_env_new(i64 7)
  %v1886 = getelementptr i8, ptr %v1885, i64 24
  store ptr %v1874, ptr %v1886, align 8, !tbaa !3
  %v1887 = getelementptr i8, ptr %v1885, i64 32
  store ptr %v1871, ptr %v1887, align 8, !tbaa !3
  %v1888 = getelementptr i8, ptr %v1885, i64 40
  store ptr %v1875, ptr %v1888, align 8, !tbaa !3
  %v1889 = getelementptr i8, ptr %v1885, i64 48
  store ptr %v1876, ptr %v1889, align 8, !tbaa !3
  %v1890 = getelementptr i8, ptr %v1885, i64 56
  store ptr %v1873, ptr %v1890, align 8, !tbaa !3
  %v1891 = getelementptr i8, ptr %v1885, i64 64
  store ptr %v1870, ptr %v1891, align 8, !tbaa !3
  %v1892 = getelementptr i8, ptr %v1885, i64 72
  store ptr %v1884, ptr %v1892, align 8, !tbaa !3
  %v1893 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1699, ptr %v1885)
  br label %join.1863
join.1863:
  %v1894 = phi ptr [ %v1864, %yes.1861 ], [ %v1893, %no.1862 ]
  br label %join.1856
join.1856:
  %v1895 = phi ptr [ %v1857, %yes.1854 ], [ %v1894, %join.1863 ]
  ret ptr %v1895
}

define private ptr @mlf.numeric.entry.1699(ptr %env, ptr %arg) {
entry:
  %v1700 = getelementptr i8, ptr %env, i64 24
  %v1701 = load ptr, ptr %v1700, align 8, !tbaa !3
  %v1702 = getelementptr i8, ptr %env, i64 32
  %v1703 = load ptr, ptr %v1702, align 8, !tbaa !3
  %v1704 = getelementptr i8, ptr %env, i64 40
  %v1705 = load ptr, ptr %v1704, align 8, !tbaa !3
  %v1706 = getelementptr i8, ptr %env, i64 48
  %v1707 = load ptr, ptr %v1706, align 8, !tbaa !3
  %v1708 = getelementptr i8, ptr %env, i64 56
  %v1709 = load ptr, ptr %v1708, align 8, !tbaa !3
  %v1710 = getelementptr i8, ptr %env, i64 64
  %v1711 = load ptr, ptr %v1710, align 8, !tbaa !3
  %v1712 = getelementptr i8, ptr %env, i64 72
  %v1713 = load ptr, ptr %v1712, align 8, !tbaa !3
  %v1714 = call ptr @mlf_peek(ptr %v1701)
  %v1715 = call ptr @mlf_peek(ptr %v1703)
  %v1716 = call ptr @mlf_peek(ptr %v1705)
  %v1717 = call ptr @mlf_peek(ptr %v1707)
  %v1718 = call ptr @mlf_peek(ptr %v1709)
  %v1719 = call ptr @mlf_peek(ptr %v1711)
  %v1720 = call ptr @mlf_peek(ptr %v1713)
  %v1721 = icmp ne ptr %v1714, null
  %v1722 = icmp ne ptr %v1715, null
  %v1723 = icmp ne ptr %v1716, null
  %v1724 = icmp ne ptr %v1717, null
  %v1725 = icmp ne ptr %v1718, null
  %v1726 = icmp ne ptr %v1719, null
  %v1727 = icmp ne ptr %v1720, null
  %v1728 = and i1 true, %v1721
  %v1729 = and i1 %v1728, %v1722
  %v1730 = and i1 %v1729, %v1723
  %v1731 = and i1 %v1730, %v1724
  %v1732 = and i1 %v1731, %v1725
  %v1733 = and i1 %v1732, %v1726
  %v1734 = and i1 %v1733, %v1727
  br i1 %v1734, label %yes.1735, label %no.1736
yes.1735:
  %v1848 = call ptr @mlf.numeric.0(ptr %v1714, ptr %v1715, ptr %v1716, ptr %v1717, ptr %v1718, ptr %v1719, ptr %v1720)
  %v1849 = call ptr @mlf_prim1(i64 0, ptr %v1848)
  br label %join.1737
no.1736:
  %v1896 = call ptr @mlf_force(ptr %v1705)
  %v1897 = call ptr @mlf_force(ptr %v1707)
  %v1898 = call ptr @mlf.worker.0(ptr %v1701, ptr %v1703, ptr %v1896, ptr %v1897, ptr %v1709, ptr %v1711, ptr %v1713)
  br label %join.1737
join.1737:
  %v1899 = phi ptr [ %v1849, %yes.1735 ], [ %v1898, %no.1736 ]
  ret ptr %v1899
}

define private ptr @mlf.code.1694(ptr %env, ptr %arg) {
entry:
  %v1695 = getelementptr i8, ptr %env, i64 24
  %v1696 = load ptr, ptr %v1695, align 8, !tbaa !3
  %v1697 = getelementptr i8, ptr %env, i64 32
  %v1698 = load ptr, ptr %v1697, align 8, !tbaa !3
  %v1900 = call ptr @mlf_double(double 0x0000000000000000)
  %v1901 = call ptr @mlf_double(double 0x0000000000000000)
  %v1902 = call ptr @mlf_double(double 0x0000000000000000)
  %v1903 = call ptr @mlf_double(double 0x0000000000000000)
  %v1904 = call ptr @mlf_env_new(i64 7)
  %v1905 = getelementptr i8, ptr %v1904, i64 24
  store ptr %v1900, ptr %v1905, align 8, !tbaa !3
  %v1906 = getelementptr i8, ptr %v1904, i64 32
  store ptr %v1901, ptr %v1906, align 8, !tbaa !3
  %v1907 = getelementptr i8, ptr %v1904, i64 40
  store ptr %v1902, ptr %v1907, align 8, !tbaa !3
  %v1908 = getelementptr i8, ptr %v1904, i64 48
  store ptr %v1903, ptr %v1908, align 8, !tbaa !3
  %v1909 = getelementptr i8, ptr %v1904, i64 56
  store ptr %v1696, ptr %v1909, align 8, !tbaa !3
  %v1910 = getelementptr i8, ptr %v1904, i64 64
  store ptr %v1698, ptr %v1910, align 8, !tbaa !3
  %v1911 = getelementptr i8, ptr %v1904, i64 72
  store ptr inttoptr (i64 101 to ptr), ptr %v1911, align 8, !tbaa !3
  %v1912 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1699, ptr %v1904)
  ret ptr %v1912
}

define private ptr @mlf.code.1939(ptr %env, ptr %arg) {
entry:
  %v1940 = getelementptr i8, ptr %env, i64 24
  %v1941 = load ptr, ptr %v1940, align 8, !tbaa !3
  %v1942 = getelementptr i8, ptr %env, i64 32
  %v1943 = load ptr, ptr %v1942, align 8, !tbaa !3
  %v1944 = call ptr @mlf_force(ptr %v1941)
  %v1945 = call ptr @mlf_prim2(i64 14, ptr %v1944, ptr inttoptr (i64 5 to ptr))
  %v1946 = call ptr @mlf_force(ptr %v1943)
  %v1947 = call ptr @mlf_prim2(i64 8, ptr %v1945, ptr %v1946)
  ret ptr %v1947
}

define private ptr @mlf.code.1930(ptr %env, ptr %arg) {
entry:
  %v1931 = getelementptr i8, ptr %env, i64 24
  %v1932 = load ptr, ptr %v1931, align 8, !tbaa !3
  %v1933 = getelementptr i8, ptr %env, i64 32
  %v1934 = load ptr, ptr %v1933, align 8, !tbaa !3
  %v1935 = getelementptr i8, ptr %env, i64 40
  %v1936 = load ptr, ptr %v1935, align 8, !tbaa !3
  %v1937 = getelementptr i8, ptr %env, i64 48
  %v1938 = load ptr, ptr %v1937, align 8, !tbaa !3
  %v1948 = call ptr @mlf_env_new(i64 2)
  %v1949 = getelementptr i8, ptr %v1948, i64 24
  store ptr %v1936, ptr %v1949, align 8, !tbaa !3
  %v1950 = getelementptr i8, ptr %v1948, i64 32
  store ptr %v1938, ptr %v1950, align 8, !tbaa !3
  %v1951 = call ptr @mlf_thunk(ptr @mlf.code.1939, ptr %v1948)
  %v1952 = call ptr @mlf_prim3(i64 37, ptr %v1932, ptr %v1934, ptr %v1951)
  ret ptr %v1952
}

define private ptr @mlf.code.1959(ptr %env, ptr %arg) {
entry:
  %v1960 = getelementptr i8, ptr %env, i64 24
  %v1961 = load ptr, ptr %v1960, align 8, !tbaa !3
  %v1962 = getelementptr i8, ptr %env, i64 32
  %v1963 = load ptr, ptr %v1962, align 8, !tbaa !3
  %v1964 = getelementptr i8, ptr %env, i64 40
  %v1965 = load ptr, ptr %v1964, align 8, !tbaa !3
  %v1966 = getelementptr i8, ptr %env, i64 48
  %v1967 = load ptr, ptr %v1966, align 8, !tbaa !3
  %v1968 = call ptr @mlf_force(ptr %v1963)
  %v1969 = call ptr @mlf_force(ptr %v1967)
  %v1970 = call ptr @mlf_prim2(i64 8, ptr %v1969, ptr inttoptr (i64 3 to ptr))
  %v1971 = call ptr @mlf_env_new(i64 4)
  %v1972 = getelementptr i8, ptr %v1971, i64 24
  store ptr %v1961, ptr %v1972, align 8, !tbaa !3
  %v1973 = getelementptr i8, ptr %v1971, i64 32
  store ptr %v1968, ptr %v1973, align 8, !tbaa !3
  %v1974 = getelementptr i8, ptr %v1971, i64 40
  store ptr %v1965, ptr %v1974, align 8, !tbaa !3
  %v1975 = getelementptr i8, ptr %v1971, i64 48
  store ptr %v1970, ptr %v1975, align 8, !tbaa !3
  %v1976 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.976, ptr %v1971)
  ret ptr %v1976
}

define private ptr @mlf.code.1917(ptr %env, ptr %arg) {
entry:
  %v1918 = getelementptr i8, ptr %env, i64 24
  %v1919 = load ptr, ptr %v1918, align 8, !tbaa !3
  %v1920 = getelementptr i8, ptr %env, i64 32
  %v1921 = load ptr, ptr %v1920, align 8, !tbaa !3
  %v1922 = getelementptr i8, ptr %env, i64 40
  %v1923 = load ptr, ptr %v1922, align 8, !tbaa !3
  %v1924 = getelementptr i8, ptr %env, i64 48
  %v1925 = load ptr, ptr %v1924, align 8, !tbaa !3
  %v1926 = getelementptr i8, ptr %env, i64 56
  %v1927 = load ptr, ptr %v1926, align 8, !tbaa !3
  %v1928 = getelementptr i8, ptr %env, i64 64
  %v1929 = load ptr, ptr %v1928, align 8, !tbaa !3
  %v1953 = call ptr @mlf_env_new(i64 4)
  %v1954 = getelementptr i8, ptr %v1953, i64 24
  store ptr %v1919, ptr %v1954, align 8, !tbaa !3
  %v1955 = getelementptr i8, ptr %v1953, i64 32
  store ptr %v1927, ptr %v1955, align 8, !tbaa !3
  %v1956 = getelementptr i8, ptr %v1953, i64 40
  store ptr %v1929, ptr %v1956, align 8, !tbaa !3
  %v1957 = getelementptr i8, ptr %v1953, i64 48
  store ptr %arg, ptr %v1957, align 8, !tbaa !3
  %v1958 = call ptr @mlf_thunk(ptr @mlf.code.1930, ptr %v1953)
  %v1977 = call ptr @mlf_env_new(i64 4)
  %v1978 = getelementptr i8, ptr %v1977, i64 24
  store ptr %v1919, ptr %v1978, align 8, !tbaa !3
  %v1979 = getelementptr i8, ptr %v1977, i64 32
  store ptr %v1921, ptr %v1979, align 8, !tbaa !3
  %v1980 = getelementptr i8, ptr %v1977, i64 40
  store ptr %v1923, ptr %v1980, align 8, !tbaa !3
  %v1981 = getelementptr i8, ptr %v1977, i64 48
  store ptr %v1925, ptr %v1981, align 8, !tbaa !3
  %v1982 = call ptr @mlf_closure(ptr @mlf.code.1959, ptr %v1977)
  %v1983 = call ptr @mlf_prim2(i64 1, ptr %v1958, ptr %v1982)
  ret ptr %v1983
}

define private ptr @mlf.code.1098(ptr %env, ptr %arg) {
entry:
  %v1099 = getelementptr i8, ptr %env, i64 24
  %v1100 = load ptr, ptr %v1099, align 8, !tbaa !3
  %v1101 = getelementptr i8, ptr %env, i64 32
  %v1102 = load ptr, ptr %v1101, align 8, !tbaa !3
  %v1103 = getelementptr i8, ptr %env, i64 40
  %v1104 = load ptr, ptr %v1103, align 8, !tbaa !3
  %v1105 = getelementptr i8, ptr %env, i64 48
  %v1106 = load ptr, ptr %v1105, align 8, !tbaa !3
  %v1107 = getelementptr i8, ptr %env, i64 56
  %v1108 = load ptr, ptr %v1107, align 8, !tbaa !3
  %v1109 = getelementptr i8, ptr %env, i64 64
  %v1110 = load ptr, ptr %v1109, align 8, !tbaa !3
  %v1111 = getelementptr i8, ptr %env, i64 72
  %v1112 = load ptr, ptr %v1111, align 8, !tbaa !3
  %v1113 = call ptr @mlf_force(ptr %v1106)
  %v1114 = call ptr @mlf_prim2(i64 8, ptr %v1113, ptr inttoptr (i64 3 to ptr))
  %v1115 = call ptr @mlf_force(ptr %v1102)
  %v1116 = call ptr @mlf_prim2(i64 11, ptr %v1114, ptr %v1115)
  %v1117 = icmp eq ptr %v1116, inttoptr (i64 6 to ptr)
  br i1 %v1117, label %yes.1118, label %no.1119
yes.1118:
  %v1136 = call ptr @mlf_env_new(i64 2)
  %v1137 = getelementptr i8, ptr %v1136, i64 24
  store ptr %v1115, ptr %v1137, align 8, !tbaa !3
  %v1138 = getelementptr i8, ptr %v1136, i64 32
  store ptr %v1113, ptr %v1138, align 8, !tbaa !3
  %v1139 = call ptr @mlf_thunk(ptr @mlf.code.1121, ptr %v1136)
  %v1613 = call ptr @mlf_env_new(i64 3)
  %v1614 = getelementptr i8, ptr %v1613, i64 24
  store ptr %v1108, ptr %v1614, align 8, !tbaa !3
  %v1615 = getelementptr i8, ptr %v1613, i64 32
  store ptr %v1110, ptr %v1615, align 8, !tbaa !3
  %v1616 = getelementptr i8, ptr %v1613, i64 40
  store ptr %v1139, ptr %v1616, align 8, !tbaa !3
  %v1617 = call ptr @mlf_thunk(ptr @mlf.code.1140, ptr %v1613)
  %v1685 = call ptr @mlf_env_new(i64 6)
  %v1686 = getelementptr i8, ptr %v1685, i64 24
  store ptr %v1100, ptr %v1686, align 8, !tbaa !3
  %v1687 = getelementptr i8, ptr %v1685, i64 32
  store ptr %v1115, ptr %v1687, align 8, !tbaa !3
  %v1688 = getelementptr i8, ptr %v1685, i64 40
  store ptr %v1104, ptr %v1688, align 8, !tbaa !3
  %v1689 = getelementptr i8, ptr %v1685, i64 48
  store ptr %v1113, ptr %v1689, align 8, !tbaa !3
  %v1690 = getelementptr i8, ptr %v1685, i64 56
  store ptr %v1112, ptr %v1690, align 8, !tbaa !3
  %v1691 = getelementptr i8, ptr %v1685, i64 64
  store ptr %arg, ptr %v1691, align 8, !tbaa !3
  %v1692 = call ptr @mlf_closure(ptr @mlf.code.1618, ptr %v1685)
  %v1693 = call ptr @mlf_prim2(i64 1, ptr %v1617, ptr %v1692)
  br label %join.1120
no.1119:
  %v1913 = call ptr @mlf_env_new(i64 2)
  %v1914 = getelementptr i8, ptr %v1913, i64 24
  store ptr %v1108, ptr %v1914, align 8, !tbaa !3
  %v1915 = getelementptr i8, ptr %v1913, i64 32
  store ptr %v1110, ptr %v1915, align 8, !tbaa !3
  %v1916 = call ptr @mlf_thunk(ptr @mlf.code.1694, ptr %v1913)
  %v1984 = call ptr @mlf_env_new(i64 6)
  %v1985 = getelementptr i8, ptr %v1984, i64 24
  store ptr %v1100, ptr %v1985, align 8, !tbaa !3
  %v1986 = getelementptr i8, ptr %v1984, i64 32
  store ptr %v1115, ptr %v1986, align 8, !tbaa !3
  %v1987 = getelementptr i8, ptr %v1984, i64 40
  store ptr %v1104, ptr %v1987, align 8, !tbaa !3
  %v1988 = getelementptr i8, ptr %v1984, i64 48
  store ptr %v1113, ptr %v1988, align 8, !tbaa !3
  %v1989 = getelementptr i8, ptr %v1984, i64 56
  store ptr %v1112, ptr %v1989, align 8, !tbaa !3
  %v1990 = getelementptr i8, ptr %v1984, i64 64
  store ptr %arg, ptr %v1990, align 8, !tbaa !3
  %v1991 = call ptr @mlf_closure(ptr @mlf.code.1917, ptr %v1984)
  %v1992 = call ptr @mlf_prim2(i64 1, ptr %v1916, ptr %v1991)
  br label %join.1120
join.1120:
  %v1993 = phi ptr [ %v1693, %yes.1118 ], [ %v1992, %no.1119 ]
  ret ptr %v1993
}

define private ptr @mlf.code.1073(ptr %env, ptr %arg) {
entry:
  %v1074 = getelementptr i8, ptr %env, i64 24
  %v1075 = load ptr, ptr %v1074, align 8, !tbaa !3
  %v1076 = getelementptr i8, ptr %env, i64 32
  %v1077 = load ptr, ptr %v1076, align 8, !tbaa !3
  %v1078 = getelementptr i8, ptr %env, i64 40
  %v1079 = load ptr, ptr %v1078, align 8, !tbaa !3
  %v1080 = getelementptr i8, ptr %env, i64 48
  %v1081 = load ptr, ptr %v1080, align 8, !tbaa !3
  %v1082 = getelementptr i8, ptr %env, i64 56
  %v1083 = load ptr, ptr %v1082, align 8, !tbaa !3
  %v1084 = getelementptr i8, ptr %env, i64 64
  %v1085 = load ptr, ptr %v1084, align 8, !tbaa !3
  %v1086 = getelementptr i8, ptr %env, i64 72
  %v1087 = load ptr, ptr %v1086, align 8, !tbaa !3
  %v1094 = call ptr @mlf_env_new(i64 2)
  %v1095 = getelementptr i8, ptr %v1094, i64 24
  store ptr %v1075, ptr %v1095, align 8, !tbaa !3
  %v1096 = getelementptr i8, ptr %v1094, i64 32
  store ptr %v1087, ptr %v1096, align 8, !tbaa !3
  %v1097 = call ptr @mlf_thunk(ptr @mlf.code.1088, ptr %v1094)
  %v1994 = call ptr @mlf_env_new(i64 7)
  %v1995 = getelementptr i8, ptr %v1994, i64 24
  store ptr %v1075, ptr %v1995, align 8, !tbaa !3
  %v1996 = getelementptr i8, ptr %v1994, i64 32
  store ptr %v1077, ptr %v1996, align 8, !tbaa !3
  %v1997 = getelementptr i8, ptr %v1994, i64 40
  store ptr %v1079, ptr %v1997, align 8, !tbaa !3
  %v1998 = getelementptr i8, ptr %v1994, i64 48
  store ptr %v1081, ptr %v1998, align 8, !tbaa !3
  %v1999 = getelementptr i8, ptr %v1994, i64 56
  store ptr %v1083, ptr %v1999, align 8, !tbaa !3
  %v2000 = getelementptr i8, ptr %v1994, i64 64
  store ptr %v1085, ptr %v2000, align 8, !tbaa !3
  %v2001 = getelementptr i8, ptr %v1994, i64 72
  store ptr %v1087, ptr %v2001, align 8, !tbaa !3
  %v2002 = call ptr @mlf_closure(ptr @mlf.code.1098, ptr %v1994)
  %v2003 = call ptr @mlf_prim2(i64 1, ptr %v1097, ptr %v2002)
  ret ptr %v2003
}

define private ptr @mlf.code.2041(ptr %env, ptr %arg) {
entry:
  %v2042 = getelementptr i8, ptr %env, i64 24
  %v2043 = load ptr, ptr %v2042, align 8, !tbaa !3
  %v2044 = getelementptr i8, ptr %env, i64 32
  %v2045 = load ptr, ptr %v2044, align 8, !tbaa !3
  %v2046 = call ptr @mlf_prim2(i64 36, ptr %v2043, ptr %v2045)
  ret ptr %v2046
}

define private ptr @mlf.code.2065(ptr %env, ptr %arg) {
entry:
  %v2066 = getelementptr i8, ptr %env, i64 24
  %v2067 = load ptr, ptr %v2066, align 8, !tbaa !3
  %v2068 = call ptr @mlf_force(ptr %v2067)
  %v2069 = call ptr @mlf_prim2(i64 14, ptr %v2068, ptr inttoptr (i64 5 to ptr))
  ret ptr %v2069
}

define private ptr @mlf.code.2058(ptr %env, ptr %arg) {
entry:
  %v2059 = getelementptr i8, ptr %env, i64 24
  %v2060 = load ptr, ptr %v2059, align 8, !tbaa !3
  %v2061 = getelementptr i8, ptr %env, i64 32
  %v2062 = load ptr, ptr %v2061, align 8, !tbaa !3
  %v2063 = getelementptr i8, ptr %env, i64 40
  %v2064 = load ptr, ptr %v2063, align 8, !tbaa !3
  %v2070 = call ptr @mlf_env_new(i64 1)
  %v2071 = getelementptr i8, ptr %v2070, i64 24
  store ptr %v2064, ptr %v2071, align 8, !tbaa !3
  %v2072 = call ptr @mlf_thunk(ptr @mlf.code.2065, ptr %v2070)
  %v2073 = call ptr @mlf_prim3(i64 37, ptr %v2060, ptr %v2062, ptr %v2072)
  ret ptr %v2073
}

define private ptr @mlf.code.2079(ptr %env, ptr %arg) {
entry:
  %v2080 = getelementptr i8, ptr %env, i64 24
  %v2081 = load ptr, ptr %v2080, align 8, !tbaa !3
  %v2082 = getelementptr i8, ptr %env, i64 32
  %v2083 = load ptr, ptr %v2082, align 8, !tbaa !3
  %v2084 = getelementptr i8, ptr %env, i64 40
  %v2085 = load ptr, ptr %v2084, align 8, !tbaa !3
  %v2086 = call ptr @mlf_force(ptr %v2085)
  %v2087 = call ptr @mlf_prim2(i64 9, ptr %v2086, ptr inttoptr (i64 3 to ptr))
  %v2088 = call ptr @mlf_env_new(i64 3)
  %v2089 = getelementptr i8, ptr %v2088, i64 24
  store ptr %v2081, ptr %v2089, align 8, !tbaa !3
  %v2090 = getelementptr i8, ptr %v2088, i64 32
  store ptr %v2083, ptr %v2090, align 8, !tbaa !3
  %v2091 = getelementptr i8, ptr %v2088, i64 40
  store ptr %v2087, ptr %v2091, align 8, !tbaa !3
  %v2092 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2014, ptr %v2088)
  ret ptr %v2092
}

define private ptr @mlf.code.2051(ptr %env, ptr %arg) {
entry:
  %v2052 = getelementptr i8, ptr %env, i64 24
  %v2053 = load ptr, ptr %v2052, align 8, !tbaa !3
  %v2054 = getelementptr i8, ptr %env, i64 32
  %v2055 = load ptr, ptr %v2054, align 8, !tbaa !3
  %v2056 = getelementptr i8, ptr %env, i64 40
  %v2057 = load ptr, ptr %v2056, align 8, !tbaa !3
  %v2074 = call ptr @mlf_env_new(i64 3)
  %v2075 = getelementptr i8, ptr %v2074, i64 24
  store ptr %v2053, ptr %v2075, align 8, !tbaa !3
  %v2076 = getelementptr i8, ptr %v2074, i64 32
  store ptr %v2055, ptr %v2076, align 8, !tbaa !3
  %v2077 = getelementptr i8, ptr %v2074, i64 40
  store ptr %arg, ptr %v2077, align 8, !tbaa !3
  %v2078 = call ptr @mlf_thunk(ptr @mlf.code.2058, ptr %v2074)
  %v2093 = call ptr @mlf_env_new(i64 3)
  %v2094 = getelementptr i8, ptr %v2093, i64 24
  store ptr %v2053, ptr %v2094, align 8, !tbaa !3
  %v2095 = getelementptr i8, ptr %v2093, i64 32
  store ptr %v2055, ptr %v2095, align 8, !tbaa !3
  %v2096 = getelementptr i8, ptr %v2093, i64 40
  store ptr %v2057, ptr %v2096, align 8, !tbaa !3
  %v2097 = call ptr @mlf_closure(ptr @mlf.code.2079, ptr %v2093)
  %v2098 = call ptr @mlf_prim2(i64 1, ptr %v2078, ptr %v2097)
  ret ptr %v2098
}

define private ptr @mlf.worker.31(ptr %a0, ptr %a1, ptr %a2) {
entry:
  %v2035 = call ptr @mlf_prim2(i64 10, ptr %a2, ptr inttoptr (i64 1 to ptr))
  %v2036 = icmp eq ptr %v2035, inttoptr (i64 6 to ptr)
  br i1 %v2036, label %yes.2037, label %no.2038
yes.2037:
  %v2040 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.2039
no.2038:
  %v2047 = call ptr @mlf_env_new(i64 2)
  %v2048 = getelementptr i8, ptr %v2047, i64 24
  store ptr %a0, ptr %v2048, align 8, !tbaa !3
  %v2049 = getelementptr i8, ptr %v2047, i64 32
  store ptr %a1, ptr %v2049, align 8, !tbaa !3
  %v2050 = call ptr @mlf_thunk(ptr @mlf.code.2041, ptr %v2047)
  %v2099 = call ptr @mlf_env_new(i64 3)
  %v2100 = getelementptr i8, ptr %v2099, i64 24
  store ptr %a0, ptr %v2100, align 8, !tbaa !3
  %v2101 = getelementptr i8, ptr %v2099, i64 32
  store ptr %a1, ptr %v2101, align 8, !tbaa !3
  %v2102 = getelementptr i8, ptr %v2099, i64 40
  store ptr %a2, ptr %v2102, align 8, !tbaa !3
  %v2103 = call ptr @mlf_closure(ptr @mlf.code.2051, ptr %v2099)
  %v2104 = call ptr @mlf_prim2(i64 1, ptr %v2050, ptr %v2103)
  br label %join.2039
join.2039:
  %v2105 = phi ptr [ %v2040, %yes.2037 ], [ %v2104, %no.2038 ]
  ret ptr %v2105
}

define private ptr @mlf.numeric.entry.2014(ptr %env, ptr %arg) {
entry:
  %v2015 = getelementptr i8, ptr %env, i64 24
  %v2016 = load ptr, ptr %v2015, align 8, !tbaa !3
  %v2017 = getelementptr i8, ptr %env, i64 32
  %v2018 = load ptr, ptr %v2017, align 8, !tbaa !3
  %v2019 = getelementptr i8, ptr %env, i64 40
  %v2020 = load ptr, ptr %v2019, align 8, !tbaa !3
  %v2021 = call ptr @mlf_peek(ptr %v2016)
  %v2022 = call ptr @mlf_peek(ptr %v2018)
  %v2023 = call ptr @mlf_peek(ptr %v2020)
  %v2024 = icmp ne ptr %v2021, null
  %v2025 = icmp ne ptr %v2022, null
  %v2026 = icmp ne ptr %v2023, null
  %v2027 = and i1 true, %v2024
  %v2028 = and i1 %v2027, %v2025
  %v2029 = and i1 %v2028, %v2026
  br i1 %v2029, label %yes.2030, label %no.2031
yes.2030:
  %v2033 = call ptr @mlf.numeric.31(ptr %v2021, ptr %v2022, ptr %v2023)
  %v2034 = call ptr @mlf_prim1(i64 0, ptr %v2033)
  br label %join.2032
no.2031:
  %v2106 = call ptr @mlf_force(ptr %v2020)
  %v2107 = call ptr @mlf.worker.31(ptr %v2016, ptr %v2018, ptr %v2106)
  br label %join.2032
join.2032:
  %v2108 = phi ptr [ %v2034, %yes.2030 ], [ %v2107, %no.2031 ]
  ret ptr %v2108
}

define private ptr @mlf.code.2109(ptr %env, ptr %arg) {
entry:
  %v2110 = getelementptr i8, ptr %env, i64 24
  %v2111 = load ptr, ptr %v2110, align 8, !tbaa !3
  %v2112 = call ptr @mlf_force(ptr %v2111)
  %v2113 = call ptr @mlf_prim2(i64 15, ptr %v2112, ptr inttoptr (i64 17 to ptr))
  ret ptr %v2113
}

define private ptr @mlf.worker.37(ptr %a0, ptr %a1, ptr %a2, ptr %a3) {
entry:
  %v1002 = call ptr @mlf_prim2(i64 11, ptr %a3, ptr %a1)
  %v1003 = icmp eq ptr %v1002, inttoptr (i64 6 to ptr)
  br i1 %v1003, label %yes.1004, label %no.1005
yes.1004:
  %v1021 = call ptr @mlf_env_new(i64 2)
  %v1022 = getelementptr i8, ptr %v1021, i64 24
  store ptr %a1, ptr %v1022, align 8, !tbaa !3
  %v1023 = getelementptr i8, ptr %v1021, i64 32
  store ptr %a3, ptr %v1023, align 8, !tbaa !3
  %v1024 = call ptr @mlf_thunk(ptr @mlf.code.1007, ptr %v1021)
  %v1039 = call ptr @mlf_env_new(i64 2)
  %v1040 = getelementptr i8, ptr %v1039, i64 24
  store ptr %a1, ptr %v1040, align 8, !tbaa !3
  %v1041 = getelementptr i8, ptr %v1039, i64 32
  store ptr %a2, ptr %v1041, align 8, !tbaa !3
  %v1042 = call ptr @mlf_thunk(ptr @mlf.code.1025, ptr %v1039)
  %v1048 = call ptr @mlf_env_new(i64 1)
  %v1049 = getelementptr i8, ptr %v1048, i64 24
  store ptr %a3, ptr %v1049, align 8, !tbaa !3
  %v1050 = call ptr @mlf_thunk(ptr @mlf.code.1043, ptr %v1048)
  %v1068 = call ptr @mlf_env_new(i64 3)
  %v1069 = getelementptr i8, ptr %v1068, i64 24
  store ptr %a0, ptr %v1069, align 8, !tbaa !3
  %v1070 = getelementptr i8, ptr %v1068, i64 32
  store ptr %a3, ptr %v1070, align 8, !tbaa !3
  %v1071 = getelementptr i8, ptr %v1068, i64 40
  store ptr %v1050, ptr %v1071, align 8, !tbaa !3
  %v1072 = call ptr @mlf_thunk(ptr @mlf.code.1051, ptr %v1068)
  %v2004 = call ptr @mlf_env_new(i64 7)
  %v2005 = getelementptr i8, ptr %v2004, i64 24
  store ptr %a0, ptr %v2005, align 8, !tbaa !3
  %v2006 = getelementptr i8, ptr %v2004, i64 32
  store ptr %a1, ptr %v2006, align 8, !tbaa !3
  %v2007 = getelementptr i8, ptr %v2004, i64 40
  store ptr %a2, ptr %v2007, align 8, !tbaa !3
  %v2008 = getelementptr i8, ptr %v2004, i64 48
  store ptr %a3, ptr %v2008, align 8, !tbaa !3
  %v2009 = getelementptr i8, ptr %v2004, i64 56
  store ptr %v1024, ptr %v2009, align 8, !tbaa !3
  %v2010 = getelementptr i8, ptr %v2004, i64 64
  store ptr %v1042, ptr %v2010, align 8, !tbaa !3
  %v2011 = getelementptr i8, ptr %v2004, i64 72
  store ptr %v1050, ptr %v2011, align 8, !tbaa !3
  %v2012 = call ptr @mlf_closure(ptr @mlf.code.1073, ptr %v2004)
  %v2013 = call ptr @mlf_prim2(i64 1, ptr %v1072, ptr %v2012)
  br label %join.1006
no.1005:
  %v2114 = call ptr @mlf_env_new(i64 1)
  %v2115 = getelementptr i8, ptr %v2114, i64 24
  store ptr %a1, ptr %v2115, align 8, !tbaa !3
  %v2116 = call ptr @mlf_thunk(ptr @mlf.code.2109, ptr %v2114)
  %v2117 = call ptr @mlf_prim2(i64 16, ptr %a1, ptr inttoptr (i64 17 to ptr))
  %v2118 = call ptr @mlf_prim2(i64 10, ptr %v2117, ptr inttoptr (i64 1 to ptr))
  %v2119 = icmp eq ptr %v2118, inttoptr (i64 6 to ptr)
  br i1 %v2119, label %yes.2120, label %no.2121
yes.2120:
  br label %join.2122
no.2121:
  %v2123 = call ptr @mlf_prim2(i64 16, ptr %a1, ptr inttoptr (i64 17 to ptr))
  %v2124 = call ptr @mlf_prim2(i64 9, ptr inttoptr (i64 17 to ptr), ptr %v2123)
  br label %join.2122
join.2122:
  %v2125 = phi ptr [ inttoptr (i64 1 to ptr), %yes.2120 ], [ %v2124, %no.2121 ]
  %v2126 = call ptr @mlf_env_new(i64 3)
  %v2127 = getelementptr i8, ptr %v2126, i64 24
  store ptr %a0, ptr %v2127, align 8, !tbaa !3
  %v2128 = getelementptr i8, ptr %v2126, i64 32
  store ptr %v2116, ptr %v2128, align 8, !tbaa !3
  %v2129 = getelementptr i8, ptr %v2126, i64 40
  store ptr %v2125, ptr %v2129, align 8, !tbaa !3
  %v2130 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2014, ptr %v2126)
  br label %join.1006
join.1006:
  %v2131 = phi ptr [ %v2013, %yes.1004 ], [ %v2130, %join.2122 ]
  ret ptr %v2131
}

define private ptr @mlf.numeric.entry.976(ptr %env, ptr %arg) {
entry:
  %v977 = getelementptr i8, ptr %env, i64 24
  %v978 = load ptr, ptr %v977, align 8, !tbaa !3
  %v979 = getelementptr i8, ptr %env, i64 32
  %v980 = load ptr, ptr %v979, align 8, !tbaa !3
  %v981 = getelementptr i8, ptr %env, i64 40
  %v982 = load ptr, ptr %v981, align 8, !tbaa !3
  %v983 = getelementptr i8, ptr %env, i64 48
  %v984 = load ptr, ptr %v983, align 8, !tbaa !3
  %v985 = call ptr @mlf_peek(ptr %v978)
  %v986 = call ptr @mlf_peek(ptr %v980)
  %v987 = call ptr @mlf_peek(ptr %v982)
  %v988 = call ptr @mlf_peek(ptr %v984)
  %v989 = icmp ne ptr %v985, null
  %v990 = icmp ne ptr %v986, null
  %v991 = icmp ne ptr %v987, null
  %v992 = icmp ne ptr %v988, null
  %v993 = and i1 true, %v989
  %v994 = and i1 %v993, %v990
  %v995 = and i1 %v994, %v991
  %v996 = and i1 %v995, %v992
  br i1 %v996, label %yes.997, label %no.998
yes.997:
  %v1000 = call ptr @mlf.numeric.37(ptr %v985, ptr %v986, ptr %v987, ptr %v988)
  %v1001 = call ptr @mlf_prim1(i64 0, ptr %v1000)
  br label %join.999
no.998:
  %v2132 = call ptr @mlf_force(ptr %v980)
  %v2133 = call ptr @mlf_force(ptr %v984)
  %v2134 = call ptr @mlf.worker.37(ptr %v978, ptr %v2132, ptr %v982, ptr %v2133)
  br label %join.999
join.999:
  %v2135 = phi ptr [ %v1001, %yes.997 ], [ %v2134, %no.998 ]
  ret ptr %v2135
}

define private ptr @mlf.code.969(ptr %env, ptr %arg) {
entry:
  %v970 = getelementptr i8, ptr %env, i64 24
  %v971 = load ptr, ptr %v970, align 8, !tbaa !3
  %v972 = getelementptr i8, ptr %env, i64 32
  %v973 = load ptr, ptr %v972, align 8, !tbaa !3
  %v974 = getelementptr i8, ptr %env, i64 40
  %v975 = load ptr, ptr %v974, align 8, !tbaa !3
  %v2136 = call ptr @mlf_force(ptr %v973)
  %v2137 = call ptr @mlf_env_new(i64 4)
  %v2138 = getelementptr i8, ptr %v2137, i64 24
  store ptr %v971, ptr %v2138, align 8, !tbaa !3
  %v2139 = getelementptr i8, ptr %v2137, i64 32
  store ptr %v2136, ptr %v2139, align 8, !tbaa !3
  %v2140 = getelementptr i8, ptr %v2137, i64 40
  store ptr %v975, ptr %v2140, align 8, !tbaa !3
  %v2141 = getelementptr i8, ptr %v2137, i64 48
  store ptr inttoptr (i64 1 to ptr), ptr %v2141, align 8, !tbaa !3
  %v2142 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.976, ptr %v2137)
  ret ptr %v2142
}

define private ptr @mlf.code.2160(ptr %env, ptr %arg) {
entry:
  %v2161 = getelementptr i8, ptr %env, i64 24
  %v2162 = load ptr, ptr %v2161, align 8, !tbaa !3
  %v2163 = call ptr @mlf_force(ptr %v2162)
  %v2164 = call ptr @mlf_prim2(i64 8, ptr %v2163, ptr inttoptr (i64 15 to ptr))
  %v2165 = call ptr @mlf_prim2(i64 15, ptr %v2164, ptr inttoptr (i64 17 to ptr))
  ret ptr %v2165
}

define private ptr @mlf.code.2155(ptr %env, ptr %arg) {
entry:
  %v2156 = getelementptr i8, ptr %env, i64 24
  %v2157 = load ptr, ptr %v2156, align 8, !tbaa !3
  %v2158 = getelementptr i8, ptr %env, i64 32
  %v2159 = load ptr, ptr %v2158, align 8, !tbaa !3
  %v2166 = call ptr @mlf_env_new(i64 1)
  %v2167 = getelementptr i8, ptr %v2166, i64 24
  store ptr %v2159, ptr %v2167, align 8, !tbaa !3
  %v2168 = call ptr @mlf_thunk(ptr @mlf.code.2160, ptr %v2166)
  %v2169 = call ptr @mlf_prim3(i64 40, ptr %v2157, ptr inttoptr (i64 1 to ptr), ptr %v2168)
  ret ptr %v2169
}

define private ptr @mlf.code.2174(ptr %env, ptr %arg) {
entry:
  %v2175 = getelementptr i8, ptr %env, i64 24
  %v2176 = load ptr, ptr %v2175, align 8, !tbaa !3
  %v2177 = getelementptr i8, ptr %env, i64 32
  %v2178 = load ptr, ptr %v2177, align 8, !tbaa !3
  %v2179 = getelementptr i8, ptr %env, i64 40
  %v2180 = load ptr, ptr %v2179, align 8, !tbaa !3
  %v2181 = call ptr @mlf_force(ptr %v2178)
  %v2182 = call ptr @mlf_force(ptr %v2180)
  %v2183 = call ptr @mlf_prim2(i64 8, ptr %v2182, ptr inttoptr (i64 3 to ptr))
  %v2184 = call ptr @mlf_env_new(i64 3)
  %v2185 = getelementptr i8, ptr %v2184, i64 24
  store ptr %v2176, ptr %v2185, align 8, !tbaa !3
  %v2186 = getelementptr i8, ptr %v2184, i64 32
  store ptr %v2181, ptr %v2186, align 8, !tbaa !3
  %v2187 = getelementptr i8, ptr %v2184, i64 40
  store ptr %v2183, ptr %v2187, align 8, !tbaa !3
  %v2188 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.103, ptr %v2184)
  ret ptr %v2188
}

define private ptr @mlf.code.2148(ptr %env, ptr %arg) {
entry:
  %v2149 = getelementptr i8, ptr %env, i64 24
  %v2150 = load ptr, ptr %v2149, align 8, !tbaa !3
  %v2151 = getelementptr i8, ptr %env, i64 32
  %v2152 = load ptr, ptr %v2151, align 8, !tbaa !3
  %v2153 = getelementptr i8, ptr %env, i64 40
  %v2154 = load ptr, ptr %v2153, align 8, !tbaa !3
  %v2170 = call ptr @mlf_env_new(i64 2)
  %v2171 = getelementptr i8, ptr %v2170, i64 24
  store ptr %v2150, ptr %v2171, align 8, !tbaa !3
  %v2172 = getelementptr i8, ptr %v2170, i64 32
  store ptr %v2152, ptr %v2172, align 8, !tbaa !3
  %v2173 = call ptr @mlf_thunk(ptr @mlf.code.2155, ptr %v2170)
  %v2189 = call ptr @mlf_env_new(i64 3)
  %v2190 = getelementptr i8, ptr %v2189, i64 24
  store ptr %v2150, ptr %v2190, align 8, !tbaa !3
  %v2191 = getelementptr i8, ptr %v2189, i64 32
  store ptr %v2152, ptr %v2191, align 8, !tbaa !3
  %v2192 = getelementptr i8, ptr %v2189, i64 40
  store ptr %v2154, ptr %v2192, align 8, !tbaa !3
  %v2193 = call ptr @mlf_closure(ptr @mlf.code.2174, ptr %v2189)
  %v2194 = call ptr @mlf_prim2(i64 1, ptr %v2173, ptr %v2193)
  ret ptr %v2194
}

define private ptr @mlf.worker.52(ptr %a0, ptr %a1, ptr %a2) {
entry:
  %v964 = call ptr @mlf_prim2(i64 11, ptr %a2, ptr %a1)
  %v965 = icmp eq ptr %v964, inttoptr (i64 6 to ptr)
  br i1 %v965, label %yes.966, label %no.967
yes.966:
  %v2143 = call ptr @mlf_env_new(i64 3)
  %v2144 = getelementptr i8, ptr %v2143, i64 24
  store ptr %a0, ptr %v2144, align 8, !tbaa !3
  %v2145 = getelementptr i8, ptr %v2143, i64 32
  store ptr %a1, ptr %v2145, align 8, !tbaa !3
  %v2146 = getelementptr i8, ptr %v2143, i64 40
  store ptr %a2, ptr %v2146, align 8, !tbaa !3
  %v2147 = call ptr @mlf_thunk(ptr @mlf.code.969, ptr %v2143)
  %v2195 = call ptr @mlf_env_new(i64 3)
  %v2196 = getelementptr i8, ptr %v2195, i64 24
  store ptr %a0, ptr %v2196, align 8, !tbaa !3
  %v2197 = getelementptr i8, ptr %v2195, i64 32
  store ptr %a1, ptr %v2197, align 8, !tbaa !3
  %v2198 = getelementptr i8, ptr %v2195, i64 40
  store ptr %a2, ptr %v2198, align 8, !tbaa !3
  %v2199 = call ptr @mlf_closure(ptr @mlf.code.2148, ptr %v2195)
  %v2200 = call ptr @mlf_prim2(i64 1, ptr %v2147, ptr %v2199)
  br label %join.968
no.967:
  %v2201 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.968
join.968:
  %v2202 = phi ptr [ %v2200, %yes.966 ], [ %v2201, %no.967 ]
  ret ptr %v2202
}

define private ptr @mlf.numeric.entry.103(ptr %env, ptr %arg) {
entry:
  %v104 = getelementptr i8, ptr %env, i64 24
  %v105 = load ptr, ptr %v104, align 8, !tbaa !3
  %v106 = getelementptr i8, ptr %env, i64 32
  %v107 = load ptr, ptr %v106, align 8, !tbaa !3
  %v108 = getelementptr i8, ptr %env, i64 40
  %v109 = load ptr, ptr %v108, align 8, !tbaa !3
  %v110 = call ptr @mlf_peek(ptr %v105)
  %v111 = call ptr @mlf_peek(ptr %v107)
  %v112 = call ptr @mlf_peek(ptr %v109)
  %v113 = icmp ne ptr %v110, null
  %v114 = icmp ne ptr %v111, null
  %v115 = icmp ne ptr %v112, null
  %v116 = and i1 true, %v113
  %v117 = and i1 %v116, %v114
  %v118 = and i1 %v117, %v115
  br i1 %v118, label %yes.119, label %no.120
yes.119:
  %v962 = call ptr @mlf.numeric.52(ptr %v110, ptr %v111, ptr %v112)
  %v963 = call ptr @mlf_prim1(i64 0, ptr %v962)
  br label %join.121
no.120:
  %v2203 = call ptr @mlf_force(ptr %v107)
  %v2204 = call ptr @mlf_force(ptr %v109)
  %v2205 = call ptr @mlf.worker.52(ptr %v105, ptr %v2203, ptr %v2204)
  br label %join.121
join.121:
  %v2206 = phi ptr [ %v963, %yes.119 ], [ %v2205, %no.120 ]
  ret ptr %v2206
}

define private ptr @mlf.code.98(ptr %env, ptr %arg) {
entry:
  %v99 = getelementptr i8, ptr %env, i64 24
  %v100 = load ptr, ptr %v99, align 8, !tbaa !3
  %v101 = getelementptr i8, ptr %env, i64 32
  %v102 = load ptr, ptr %v101, align 8, !tbaa !3
  %v2207 = call ptr @mlf_force(ptr %v100)
  %v2208 = call ptr @mlf_env_new(i64 3)
  %v2209 = getelementptr i8, ptr %v2208, i64 24
  store ptr %v102, ptr %v2209, align 8, !tbaa !3
  %v2210 = getelementptr i8, ptr %v2208, i64 32
  store ptr %v2207, ptr %v2210, align 8, !tbaa !3
  %v2211 = getelementptr i8, ptr %v2208, i64 40
  store ptr inttoptr (i64 1 to ptr), ptr %v2211, align 8, !tbaa !3
  %v2212 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.103, ptr %v2208)
  ret ptr %v2212
}

define private ptr @mlf.code.72(ptr %env, ptr %arg) {
entry:
  %v73 = getelementptr i8, ptr %env, i64 24
  %v74 = load ptr, ptr %v73, align 8, !tbaa !3
  %v95 = call ptr @mlf_env_new(i64 1)
  %v96 = getelementptr i8, ptr %v95, i64 24
  store ptr %v74, ptr %v96, align 8, !tbaa !3
  %v97 = call ptr @mlf_thunk(ptr @mlf.code.75, ptr %v95)
  %v2213 = call ptr @mlf_env_new(i64 2)
  %v2214 = getelementptr i8, ptr %v2213, i64 24
  store ptr %v74, ptr %v2214, align 8, !tbaa !3
  %v2215 = getelementptr i8, ptr %v2213, i64 32
  store ptr %arg, ptr %v2215, align 8, !tbaa !3
  %v2216 = call ptr @mlf_closure(ptr @mlf.code.98, ptr %v2213)
  %v2217 = call ptr @mlf_prim2(i64 1, ptr %v97, ptr %v2216)
  ret ptr %v2217
}

define private ptr @mlf.code.2(ptr %env, ptr %arg) {
entry:
  %v8 = call ptr @mlf_env_new(i64 1)
  %v9 = getelementptr i8, ptr %v8, i64 24
  store ptr %arg, ptr %v9, align 8, !tbaa !3
  %v10 = call ptr @mlf_thunk(ptr @mlf.code.3, ptr %v8)
  %v69 = call ptr @mlf_env_new(i64 1)
  %v70 = getelementptr i8, ptr %v69, i64 24
  store ptr %v10, ptr %v70, align 8, !tbaa !3
  %v71 = call ptr @mlf_thunk(ptr @mlf.code.11, ptr %v69)
  %v2218 = call ptr @mlf_env_new(i64 1)
  %v2219 = getelementptr i8, ptr %v2218, i64 24
  store ptr %v10, ptr %v2219, align 8, !tbaa !3
  %v2220 = call ptr @mlf_closure(ptr @mlf.code.72, ptr %v2218)
  %v2221 = call ptr @mlf_prim2(i64 1, ptr %v71, ptr %v2220)
  ret ptr %v2221
}

define private ptr @mlf.code.0(ptr %env, ptr %arg) {
entry:
  %v1 = call ptr @mlf_primitive(i64 4)
  %v2222 = call ptr @mlf_closure(ptr @mlf.code.2, ptr null)
  %v2223 = call ptr @mlf_prim2(i64 1, ptr %v1, ptr %v2222)
  ret ptr %v2223
}

declare void @mlf_require_standard_abi()
define ptr @mlf_entry() {
  call void @mlf_require_standard_abi()
  %root = call ptr @mlf.code.0(ptr null, ptr null)
  ret ptr %root
}
define i32 @main(i32 %argc, ptr %argv) {
  call void @mlf_set_args(i32 %argc, ptr %argv)
  %root = call ptr @mlf_entry()
  %status = call i32 @mlf_run(ptr %root, i64 1)
  ret i32 %status
}
