; Generated from independently checked xMLF.
source_filename = "emlf"

declare ptr @mlf_thunk_new(ptr, i64)
declare ptr @mlf_execute_st_lazy(ptr)
declare ptr @mlf_st_new_array(ptr, ptr)
declare ptr @mlf_st_read_array(ptr, ptr)
declare ptr @mlf_st_write_array(ptr, ptr, ptr)
declare ptr @mlf_st_length_array(ptr)
declare void @mlf_set_args(i32, ptr)
declare ptr @mlf_env_new(i64)
declare void @mlf_env_set(ptr, i64, ptr)
declare ptr @mlf_env_get(ptr, i64)
declare ptr @mlf_thunk(ptr, ptr)
declare ptr @mlf_closure(ptr, ptr)
declare ptr @mlf_application(ptr, ptr)
declare ptr @mlf_hole()
declare void @mlf_fill(ptr, ptr)
declare ptr @mlf_integer(ptr)
declare ptr @mlf_string(ptr, i64)
declare ptr @mlf_double(double)
declare double @llvm.sqrt.f64(double)
declare double @mlf_int_to_double(ptr)
declare ptr @mlf_read_int_table(ptr, ptr)
declare ptr @mlf_write_int_table(ptr, ptr, ptr)
declare ptr @mlf_add_int_table(ptr, ptr, ptr)
declare void @mlf_roots_enter(ptr, i64, ptr)
declare void @mlf_roots_leave(ptr)
declare void @mlf_gc_check(i64, ptr)
declare ptr @mlf_get_byte_line()
declare ptr @mlf_new_array(i64, ptr, ptr)
declare ptr @mlf_bytes_from_string(ptr)
declare ptr @mlf_put_bytes(ptr, ptr, ptr)
declare ptr @mlf_new_int_table()
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare i8 @mlf_byte(ptr)
declare ptr @mlf_peek(ptr)
declare ptr @mlf_native_io(ptr, ptr)
declare void @mlf_bounds_failure() noreturn
declare ptr @mlf_primitive(i64)
declare ptr @mlf_prim1(i64, ptr)
declare ptr @mlf_prim2(i64, ptr, ptr)
declare i64 @mlf_truth(ptr)
declare ptr @mlf_prim3(i64, ptr, ptr, ptr)
declare ptr @mlf_force(ptr)
declare ptr @mlf_add_int(ptr, ptr)
declare ptr @mlf_sub_int(ptr, ptr)
declare ptr @mlf_eq_int(ptr, ptr)
declare ptr @mlf_lt_int(ptr, ptr)
declare ptr @mlf_constructor(i64, i64)
declare ptr @mlf_constructor1(i64, ptr)
declare ptr @mlf_constructor2(i64, ptr, ptr)
declare ptr @mlf_constructor_fields(i64, ptr)
declare ptr @mlf_constructor_new(i64, i64)
declare ptr @mlf_field(ptr, i64)
declare void @mlf_match_failure() noreturn
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare i32 @mlf_run(ptr, i64)

@mlf_constructor_pending = external global [33 x ptr]
declare ptr @mlf_constructor_allocate(i64, i64)
define private ptr @mlf.allocate.constructor(i64 %identity, i64 %count, i64 %size) alwaysinline {
entry:
  %small = icmp ule i64 %size, 256
  br i1 %small, label %batch, label %slow
batch:
  %index = lshr i64 %size, 3
  %slot = getelementptr [33 x ptr], ptr @mlf_constructor_pending, i64 0, i64 %index
  %value = load ptr, ptr %slot, align 8
  %empty = icmp eq ptr %value, null
  br i1 %empty, label %slow, label %ready
ready:
  %next = load ptr, ptr %value, align 8
  store ptr %next, ptr %slot, align 8
  store i64 0, ptr %value, align 8
  ret ptr %value
slow:
  %allocated = call ptr @mlf_constructor_allocate(i64 %identity, i64 %count)
  ret ptr %allocated
}
define private ptr @mlf.construct.1(i64 %identity, ptr %a) alwaysinline {
entry:
  %value = call ptr @mlf.allocate.constructor(i64 %identity, i64 1, i64 24)
  store i32 12, ptr %value, align 4
  %id = getelementptr i8, ptr %value, i64 8
  store i64 %identity, ptr %id, align 8
  %first = getelementptr i8, ptr %value, i64 16
  store ptr %a, ptr %first, align 8
  ret ptr %value
}
define private ptr @mlf.construct.2(i64 %identity, ptr %a, ptr %b) alwaysinline {
entry:
  %value = call ptr @mlf.allocate.constructor(i64 %identity, i64 2, i64 32)
  store i32 13, ptr %value, align 4
  %id = getelementptr i8, ptr %value, i64 8
  store i64 %identity, ptr %id, align 8
  %first = getelementptr i8, ptr %value, i64 16
  store ptr %a, ptr %first, align 8
  %second = getelementptr i8, ptr %value, i64 24
  store ptr %b, ptr %second, align 8
  ret ptr %value
}
define private ptr @mlf.construct.wide(i64 %identity, i64 %count) alwaysinline {
entry:
  %fields = mul i64 %count, 8
  %size = add i64 %fields, 24
  %value = call ptr @mlf.allocate.constructor(i64 %identity, i64 %count, i64 %size)
  store i32 28, ptr %value, align 4
  %id = getelementptr i8, ptr %value, i64 8
  store i64 %identity, ptr %id, align 8
  %arity = getelementptr i8, ptr %value, i64 16
  store i64 %count, ptr %arity, align 8
  ret ptr %value
}
@mlf_compact_pending = external global [17 x ptr]
define private ptr @mlf.allocate.thunk(ptr %code, i64 %count) alwaysinline {
entry:
  %words = add i64 %count, 4
  %index = lshr i64 %words, 1
  %slot = getelementptr [17 x ptr], ptr @mlf_compact_pending, i64 0, i64 %index
  %value = load ptr, ptr %slot, align 8
  %empty = icmp eq ptr %value, null
  br i1 %empty, label %slow, label %ready
ready:
  %next = load ptr, ptr %value, align 8
  store ptr %next, ptr %slot, align 8
  store i64 3, ptr %value, align 8
  %function = getelementptr i8, ptr %value, i64 8
  store ptr %code, ptr %function, align 8
  %environment = getelementptr i8, ptr %value, i64 24
  %capture = getelementptr i8, ptr %value, i64 16
  store ptr %environment, ptr %capture, align 8
  store i64 %count, ptr %environment, align 8
  ret ptr %value
slow:
  %allocated = call ptr @mlf_thunk_new(ptr %code, i64 %count)
  ret ptr %allocated
}
define private ptr @mlf.force(ptr %value) alwaysinline {
entry:
  %null = icmp eq ptr %value, null
  br i1 %null, label %slow, label %test
test:
  %bits = ptrtoint ptr %value to i64
  %kind = and i64 %bits, 7
  %immediate = icmp ne i64 %kind, 0
  br i1 %immediate, label %done, label %tagged
tagged:
  %tag = load i32, ptr %value, align 4
  %ready = icmp uge i32 %tag, 5
  br i1 %ready, label %done, label %deferred
deferred:
  %isthunk = icmp eq i32 %tag, 3
  br i1 %isthunk, label %enter, label %indirect
indirect:
  %forwarded = icmp eq i32 %tag, 2
  br i1 %forwarded, label %next, label %slow
next:
  %slot = getelementptr i8, ptr %value, i64 8
  %p = load ptr, ptr %slot, align 8
  %missing = icmp eq ptr %p, null
  br i1 %missing, label %slow, label %nexttest
nexttest:
  %pbits = ptrtoint ptr %p to i64
  %pkind = and i64 %pbits, 7
  %pimm = icmp ne i64 %pkind, 0
  br i1 %pimm, label %forward, label %ptagged
ptagged:
  %ptag = load i32, ptr %p, align 4
  %pready = icmp uge i32 %ptag, 5
  br i1 %pready, label %forward, label %slow
forward:
  ret ptr %p
done:
  ret ptr %value
enter:
  %code.slot = getelementptr i8, ptr %value, i64 8
  %env.slot = getelementptr i8, ptr %value, i64 16
  %code = load ptr, ptr %code.slot, align 8
  %env = load ptr, ptr %env.slot, align 8
  store i32 1, ptr %value, align 4
  store ptr null, ptr %code.slot, align 8
  store ptr null, ptr %env.slot, align 8
  %returned = call ptr %code(ptr %env, ptr null)
  %canonical = call ptr @mlf_force(ptr %returned)
  store i32 2, ptr %value, align 4
  store ptr %canonical, ptr %code.slot, align 8
  ret ptr %canonical
slow:
  %result = tail call ptr @mlf_force(ptr %value)
  ret ptr %result
}
!0 = !{!"MLF storage"}
!1 = !{!"managed object", !0}
!2 = !{!"array cells", !0}
!3 = !{!1, !1, i64 0}
!4 = !{!2, !2, i64 0}
@mlf.bytes.2147 = private unnamed_addr constant [13 x i8] c"\50\66\61\6e\6e\6b\75\63\68\65\6e\28\00", align 1
@mlf.bytes.2147.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 12, ptr @mlf.bytes.2147, ptr null }, align 8
@mlf.bytes.2150 = private unnamed_addr constant [5 x i8] c"\29\20\3d\20\00", align 1
@mlf.bytes.2150.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 4, ptr @mlf.bytes.2150, ptr null }, align 8
define private ptr @mlf.code.3(ptr %env, ptr %arg) {
entry:
  %v4 = getelementptr i8, ptr %env, i64 8
  %v5 = load ptr, ptr %v4, align 8, !tbaa !3
  %v6 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v6, align 8, !tbaa !3
  %v7 = call ptr @mlf.force(ptr %v5)
  %v8 = call ptr @mlf_prim1(i64 17, ptr %v7)
  ret ptr %v8
}

define private ptr @mlf.code.13(ptr %env, ptr %arg) {
entry:
  %v14 = getelementptr i8, ptr %env, i64 8
  %v15 = load ptr, ptr %v14, align 8, !tbaa !3
  %v16 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v16, align 8, !tbaa !3
  %v17 = call ptr @mlf_prim2(i64 27, ptr %v15, ptr inttoptr (i64 1 to ptr))
  ret ptr %v17
}

define private ptr @mlf.code.25(ptr %env, ptr %arg) {
entry:
  %v26 = getelementptr i8, ptr %env, i64 8
  %v27 = load ptr, ptr %v26, align 8, !tbaa !3
  %v28 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v28, align 8, !tbaa !3
  %v29 = call ptr @mlf_prim2(i64 27, ptr %v27, ptr inttoptr (i64 1 to ptr))
  ret ptr %v29
}

define private ptr @mlf.code.39(ptr %env, ptr %arg) {
entry:
  %v40 = getelementptr i8, ptr %env, i64 8
  %v41 = load ptr, ptr %v40, align 8, !tbaa !3
  %v42 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v42, align 8, !tbaa !3
  %v43 = call ptr @mlf_prim2(i64 27, ptr %v41, ptr inttoptr (i64 1 to ptr))
  ret ptr %v43
}

define private ptr @mlf.numeric.0.pii(ptr %a0, ptr %a1, ptr %a2) alwaysinline {
entry:
  %v95 = ptrtoint ptr %a2 to i64
  %v96 = ptrtoint ptr %a1 to i64
  %v97 = icmp eq i64 %v95, %v96
  %v98 = select i1 %v97, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v99 = icmp eq ptr %v98, inttoptr (i64 6 to ptr)
  br i1 %v99, label %tail.yes.100, label %tail.no.101
tail.yes.100:
  ret ptr inttoptr (i64 4 to ptr)
tail.no.101:
  %v102 = ptrtoint ptr %a2 to i64
  %v103 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v104 = sub i64 %v103, 1
  %v105 = add nsw i64 %v102, %v104
  %v106 = inttoptr i64 %v105 to ptr
  %v107 = getelementptr i8, ptr %a0, i64 8
  %v108 = load i64, ptr %v107, align 8, !tbaa !3
  %v109 = getelementptr i8, ptr %a0, i64 16
  %v110 = load ptr, ptr %v109, align 8, !tbaa !3
  %v111 = ptrtoint ptr %a2 to i64
  %v112 = ashr i64 %v111, 1
  %v113 = and i64 %v111, 1
  %v114 = icmp ne i64 %v113, 0
  %v115 = icmp ult i64 %v112, %v108
  %v116 = and i1 %v114, %v115
  br i1 %v116, label %array.valid.117, label %array.invalid.118
array.invalid.118:
  call void @mlf_bounds_failure()
  unreachable
array.valid.117:
  %v119 = getelementptr i64, ptr %v110, i64 %v112
  store ptr %v106, ptr %v119, align 8, !tbaa !4
  %v120 = ptrtoint ptr %a2 to i64
  %v121 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v122 = sub i64 %v121, 1
  %v123 = add nsw i64 %v120, %v122
  %v124 = inttoptr i64 %v123 to ptr
  %v125 = musttail call ptr @mlf.numeric.0(ptr %a0, ptr %a1, ptr %v124)
  ret ptr %v125
}

define private ptr @mlf.numeric.0(ptr %a0, ptr %a1, ptr %a2) alwaysinline {
entry:
  %v81 = ptrtoint ptr %a1 to i64
  %v82 = and i64 %v81, 1
  %v83 = icmp ne i64 %v82, 0
  %v84 = icmp ult i64 %v81, 4294967296
  %v85 = and i1 %v83, %v84
  %v86 = ptrtoint ptr %a2 to i64
  %v87 = and i64 %v86, 1
  %v88 = icmp ne i64 %v87, 0
  %v89 = icmp ult i64 %v86, 4294967296
  %v90 = and i1 %v88, %v89
  %v91 = and i1 true, %v85
  %v92 = and i1 %v91, %v90
  br i1 %v92, label %range.fast.93, label %range.general.94
range.fast.93:
  %v126 = musttail call ptr @mlf.numeric.0.pii(ptr %a0, ptr %a1, ptr %a2)
  ret ptr %v126
range.general.94:
  %v127 = ptrtoint ptr %a2 to i64
  %v128 = ptrtoint ptr %a1 to i64
  %v129 = and i64 %v127, %v128
  %v130 = and i64 %v129, 1
  %v131 = icmp ne i64 %v130, 0
  br i1 %v131, label %yes.132, label %no.133
yes.132:
  %v135 = icmp eq i64 %v127, %v128
  %v136 = select i1 %v135, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.134
no.133:
  %v137 = call ptr @mlf_eq_int(ptr %a2, ptr %a1)
  br label %join.134
join.134:
  %v138 = phi ptr [ %v136, %yes.132 ], [ %v137, %no.133 ]
  %v139 = icmp eq ptr %v138, inttoptr (i64 6 to ptr)
  br i1 %v139, label %tail.yes.140, label %tail.no.141
tail.yes.140:
  ret ptr inttoptr (i64 4 to ptr)
tail.no.141:
  %v142 = ptrtoint ptr %a2 to i64
  %v143 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v144 = and i64 %v142, %v143
  %v145 = and i64 %v144, 1
  %v146 = icmp ne i64 %v145, 0
  br i1 %v146, label %yes.147, label %no.148
yes.147:
  %v150 = sub i64 %v143, 1
  %v151 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v142, i64 %v150)
  %v152 = extractvalue { i64, i1 } %v151, 0
  %v153 = extractvalue { i64, i1 } %v151, 1
  br i1 %v153, label %yes.154, label %no.155
yes.154:
  %v157 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 3 to ptr))
  br label %join.156
no.155:
  %v158 = inttoptr i64 %v152 to ptr
  br label %join.156
join.156:
  %v159 = phi ptr [ %v157, %yes.154 ], [ %v158, %no.155 ]
  br label %join.149
no.148:
  %v160 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 3 to ptr))
  br label %join.149
join.149:
  %v161 = phi ptr [ %v159, %join.156 ], [ %v160, %no.148 ]
  %v162 = getelementptr i8, ptr %a0, i64 8
  %v163 = load i64, ptr %v162, align 8, !tbaa !3
  %v164 = getelementptr i8, ptr %a0, i64 16
  %v165 = load ptr, ptr %v164, align 8, !tbaa !3
  %v166 = ptrtoint ptr %a2 to i64
  %v167 = ashr i64 %v166, 1
  %v168 = and i64 %v166, 1
  %v169 = icmp ne i64 %v168, 0
  %v170 = icmp ult i64 %v167, %v163
  %v171 = and i1 %v169, %v170
  br i1 %v171, label %array.valid.172, label %array.invalid.173
array.invalid.173:
  call void @mlf_bounds_failure()
  unreachable
array.valid.172:
  %v174 = getelementptr i64, ptr %v165, i64 %v167
  store ptr %v161, ptr %v174, align 8, !tbaa !4
  %v175 = ptrtoint ptr %a2 to i64
  %v176 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v177 = sub i64 %v176, 1
  %v178 = add nsw i64 %v175, %v177
  %v179 = inttoptr i64 %v178 to ptr
  %v180 = musttail call ptr @mlf.numeric.0(ptr %a0, ptr %a1, ptr %v179)
  ret ptr %v180
}

define private ptr @mlf.code.196(ptr %env, ptr %arg) {
entry:
  %v197 = getelementptr i8, ptr %env, i64 8
  %v198 = load ptr, ptr %v197, align 8, !tbaa !3
  %v199 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v199, align 8, !tbaa !3
  %v200 = call ptr @mlf.force(ptr %v198)
  %v201 = call ptr @mlf_prim2(i64 8, ptr %v200, ptr inttoptr (i64 3 to ptr))
  ret ptr %v201
}

define private ptr @mlf.code.189(ptr %env, ptr %arg) {
entry:
  %v190 = getelementptr i8, ptr %env, i64 8
  %v191 = load ptr, ptr %v190, align 8, !tbaa !3
  %v192 = getelementptr i8, ptr %env, i64 16
  %v193 = load ptr, ptr %v192, align 8, !tbaa !3
  %v194 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v194, align 8, !tbaa !3
  %v195 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v195, align 8, !tbaa !3
  %v202 = call ptr @mlf.allocate.thunk(ptr @mlf.code.196, i64 1)
  %v203 = getelementptr i8, ptr %v202, i64 16
  %v204 = load ptr, ptr %v203, align 8, !tbaa !3
  %v205 = getelementptr i8, ptr %v204, i64 8
  store ptr %v193, ptr %v205, align 8, !tbaa !3
  %v206 = call ptr @mlf_prim3(i64 29, ptr %v191, ptr %v193, ptr %v202)
  ret ptr %v206
}

define private ptr @mlf.code.212(ptr %env, ptr %arg) {
entry:
  %v213 = getelementptr i8, ptr %env, i64 8
  %v214 = load ptr, ptr %v213, align 8, !tbaa !3
  %v215 = getelementptr i8, ptr %env, i64 16
  %v216 = load ptr, ptr %v215, align 8, !tbaa !3
  %v217 = getelementptr i8, ptr %env, i64 24
  %v218 = load ptr, ptr %v217, align 8, !tbaa !3
  %v219 = call ptr @mlf.force(ptr %v216)
  %v220 = call ptr @mlf.force(ptr %v218)
  %v221 = call ptr @mlf_prim2(i64 8, ptr %v220, ptr inttoptr (i64 3 to ptr))
  %v222 = call ptr @mlf_env_new(i64 3)
  %v223 = getelementptr i8, ptr %v222, i64 8
  store ptr %v214, ptr %v223, align 8, !tbaa !3
  %v224 = getelementptr i8, ptr %v222, i64 16
  store ptr %v219, ptr %v224, align 8, !tbaa !3
  %v225 = getelementptr i8, ptr %v222, i64 24
  store ptr %v221, ptr %v225, align 8, !tbaa !3
  %v226 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.62, ptr %v222)
  ret ptr %v226
}

define private ptr @mlf.worker.0(ptr %a0, ptr %a1, ptr %a2) {
entry:
  %v183 = call ptr @mlf_prim2(i64 10, ptr %a2, ptr %a1)
  %v184 = icmp eq ptr %v183, inttoptr (i64 6 to ptr)
  br i1 %v184, label %yes.185, label %no.186
yes.185:
  %v188 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.187
no.186:
  %v207 = call ptr @mlf.allocate.thunk(ptr @mlf.code.189, i64 2)
  %v208 = getelementptr i8, ptr %v207, i64 16
  %v209 = load ptr, ptr %v208, align 8, !tbaa !3
  %v210 = getelementptr i8, ptr %v209, i64 8
  store ptr %a0, ptr %v210, align 8, !tbaa !3
  %v211 = getelementptr i8, ptr %v209, i64 16
  store ptr %a2, ptr %v211, align 8, !tbaa !3
  %v227 = call ptr @mlf_env_new(i64 3)
  %v228 = getelementptr i8, ptr %v227, i64 8
  store ptr %a0, ptr %v228, align 8, !tbaa !3
  %v229 = getelementptr i8, ptr %v227, i64 16
  store ptr %a1, ptr %v229, align 8, !tbaa !3
  %v230 = getelementptr i8, ptr %v227, i64 24
  store ptr %a2, ptr %v230, align 8, !tbaa !3
  %v231 = call ptr @mlf_closure(ptr @mlf.code.212, ptr %v227)
  %v232 = call ptr @mlf_prim2(i64 1, ptr %v207, ptr %v231)
  br label %join.187
join.187:
  %v233 = phi ptr [ %v188, %yes.185 ], [ %v232, %no.186 ]
  ret ptr %v233
}

define private ptr @mlf.numeric.entry.62(ptr %env, ptr %arg) {
entry:
  %v63 = getelementptr i8, ptr %env, i64 8
  %v64 = load ptr, ptr %v63, align 8, !tbaa !3
  %v65 = getelementptr i8, ptr %env, i64 16
  %v66 = load ptr, ptr %v65, align 8, !tbaa !3
  %v67 = getelementptr i8, ptr %env, i64 24
  %v68 = load ptr, ptr %v67, align 8, !tbaa !3
  %v69 = call ptr @mlf_peek(ptr %v64)
  %v70 = call ptr @mlf_peek(ptr %v66)
  %v71 = call ptr @mlf_peek(ptr %v68)
  %v72 = icmp ne ptr %v69, null
  %v73 = icmp ne ptr %v70, null
  %v74 = icmp ne ptr %v71, null
  %v75 = and i1 true, %v72
  %v76 = and i1 %v75, %v73
  %v77 = and i1 %v76, %v74
  br i1 %v77, label %yes.78, label %no.79
yes.78:
  %v181 = call ptr @mlf.numeric.0(ptr %v69, ptr %v70, ptr %v71)
  %v182 = call ptr @mlf_prim1(i64 0, ptr %v181)
  br label %join.80
no.79:
  %v234 = call ptr @mlf.force(ptr %v66)
  %v235 = call ptr @mlf.force(ptr %v68)
  %v236 = call ptr @mlf.worker.0(ptr %v64, ptr %v234, ptr %v235)
  br label %join.80
join.80:
  %v237 = phi ptr [ %v182, %yes.78 ], [ %v236, %no.79 ]
  ret ptr %v237
}

define private ptr @mlf.code.55(ptr %env, ptr %arg) {
entry:
  %v56 = getelementptr i8, ptr %env, i64 8
  %v57 = load ptr, ptr %v56, align 8, !tbaa !3
  %v58 = getelementptr i8, ptr %env, i64 16
  %v59 = load ptr, ptr %v58, align 8, !tbaa !3
  %v60 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v60, align 8, !tbaa !3
  %v61 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v61, align 8, !tbaa !3
  %v238 = call ptr @mlf.force(ptr %v57)
  %v239 = call ptr @mlf_env_new(i64 3)
  %v240 = getelementptr i8, ptr %v239, i64 8
  store ptr %v59, ptr %v240, align 8, !tbaa !3
  %v241 = getelementptr i8, ptr %v239, i64 16
  store ptr %v238, ptr %v241, align 8, !tbaa !3
  %v242 = getelementptr i8, ptr %v239, i64 24
  store ptr inttoptr (i64 1 to ptr), ptr %v242, align 8, !tbaa !3
  %v243 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.62, ptr %v239)
  ret ptr %v243
}

define private ptr @mlf.numeric.5.ppii(ptr %a0, ptr %a1, ptr %a2, ptr %a3) alwaysinline {
entry:
  %v324 = ptrtoint ptr %a3 to i64
  %v325 = ptrtoint ptr %a2 to i64
  %v326 = icmp eq i64 %v324, %v325
  %v327 = select i1 %v326, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v328 = icmp eq ptr %v327, inttoptr (i64 6 to ptr)
  br i1 %v328, label %tail.yes.329, label %tail.no.330
tail.yes.329:
  ret ptr inttoptr (i64 4 to ptr)
tail.no.330:
  %v331 = getelementptr i8, ptr %a0, i64 8
  %v332 = load i64, ptr %v331, align 8, !tbaa !3
  %v333 = getelementptr i8, ptr %a0, i64 16
  %v334 = load ptr, ptr %v333, align 8, !tbaa !3
  %v335 = ptrtoint ptr %a3 to i64
  %v336 = ashr i64 %v335, 1
  %v337 = and i64 %v335, 1
  %v338 = icmp ne i64 %v337, 0
  %v339 = icmp ult i64 %v336, %v332
  %v340 = and i1 %v338, %v339
  br i1 %v340, label %array.valid.341, label %array.invalid.342
array.invalid.342:
  call void @mlf_bounds_failure()
  unreachable
array.valid.341:
  %v343 = getelementptr i64, ptr %v334, i64 %v336
  %v344 = load ptr, ptr %v343, align 8, !tbaa !4
  %v345 = getelementptr i8, ptr %a1, i64 8
  %v346 = load i64, ptr %v345, align 8, !tbaa !3
  %v347 = getelementptr i8, ptr %a1, i64 16
  %v348 = load ptr, ptr %v347, align 8, !tbaa !3
  %v349 = ptrtoint ptr %a3 to i64
  %v350 = ashr i64 %v349, 1
  %v351 = and i64 %v349, 1
  %v352 = icmp ne i64 %v351, 0
  %v353 = icmp ult i64 %v350, %v346
  %v354 = and i1 %v352, %v353
  br i1 %v354, label %array.valid.355, label %array.invalid.356
array.invalid.356:
  call void @mlf_bounds_failure()
  unreachable
array.valid.355:
  %v357 = getelementptr i64, ptr %v348, i64 %v350
  store ptr %v344, ptr %v357, align 8, !tbaa !4
  %v358 = ptrtoint ptr %a3 to i64
  %v359 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v360 = sub i64 %v359, 1
  %v361 = add nsw i64 %v358, %v360
  %v362 = inttoptr i64 %v361 to ptr
  %v363 = musttail call ptr @mlf.numeric.5(ptr %a0, ptr %a1, ptr %a2, ptr %v362)
  ret ptr %v363
}

define private ptr @mlf.numeric.5(ptr %a0, ptr %a1, ptr %a2, ptr %a3) alwaysinline {
entry:
  %v310 = ptrtoint ptr %a2 to i64
  %v311 = and i64 %v310, 1
  %v312 = icmp ne i64 %v311, 0
  %v313 = icmp ult i64 %v310, 4294967296
  %v314 = and i1 %v312, %v313
  %v315 = ptrtoint ptr %a3 to i64
  %v316 = and i64 %v315, 1
  %v317 = icmp ne i64 %v316, 0
  %v318 = icmp ult i64 %v315, 4294967296
  %v319 = and i1 %v317, %v318
  %v320 = and i1 true, %v314
  %v321 = and i1 %v320, %v319
  br i1 %v321, label %range.fast.322, label %range.general.323
range.fast.322:
  %v364 = musttail call ptr @mlf.numeric.5.ppii(ptr %a0, ptr %a1, ptr %a2, ptr %a3)
  ret ptr %v364
range.general.323:
  %v365 = ptrtoint ptr %a3 to i64
  %v366 = ptrtoint ptr %a2 to i64
  %v367 = and i64 %v365, %v366
  %v368 = and i64 %v367, 1
  %v369 = icmp ne i64 %v368, 0
  br i1 %v369, label %yes.370, label %no.371
yes.370:
  %v373 = icmp eq i64 %v365, %v366
  %v374 = select i1 %v373, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.372
no.371:
  %v375 = call ptr @mlf_eq_int(ptr %a3, ptr %a2)
  br label %join.372
join.372:
  %v376 = phi ptr [ %v374, %yes.370 ], [ %v375, %no.371 ]
  %v377 = icmp eq ptr %v376, inttoptr (i64 6 to ptr)
  br i1 %v377, label %tail.yes.378, label %tail.no.379
tail.yes.378:
  ret ptr inttoptr (i64 4 to ptr)
tail.no.379:
  %v380 = getelementptr i8, ptr %a0, i64 8
  %v381 = load i64, ptr %v380, align 8, !tbaa !3
  %v382 = getelementptr i8, ptr %a0, i64 16
  %v383 = load ptr, ptr %v382, align 8, !tbaa !3
  %v384 = ptrtoint ptr %a3 to i64
  %v385 = ashr i64 %v384, 1
  %v386 = and i64 %v384, 1
  %v387 = icmp ne i64 %v386, 0
  %v388 = icmp ult i64 %v385, %v381
  %v389 = and i1 %v387, %v388
  br i1 %v389, label %array.valid.390, label %array.invalid.391
array.invalid.391:
  call void @mlf_bounds_failure()
  unreachable
array.valid.390:
  %v392 = getelementptr i64, ptr %v383, i64 %v385
  %v393 = load ptr, ptr %v392, align 8, !tbaa !4
  %v394 = getelementptr i8, ptr %a1, i64 8
  %v395 = load i64, ptr %v394, align 8, !tbaa !3
  %v396 = getelementptr i8, ptr %a1, i64 16
  %v397 = load ptr, ptr %v396, align 8, !tbaa !3
  %v398 = ptrtoint ptr %a3 to i64
  %v399 = ashr i64 %v398, 1
  %v400 = and i64 %v398, 1
  %v401 = icmp ne i64 %v400, 0
  %v402 = icmp ult i64 %v399, %v395
  %v403 = and i1 %v401, %v402
  br i1 %v403, label %array.valid.404, label %array.invalid.405
array.invalid.405:
  call void @mlf_bounds_failure()
  unreachable
array.valid.404:
  %v406 = getelementptr i64, ptr %v397, i64 %v399
  store ptr %v393, ptr %v406, align 8, !tbaa !4
  %v407 = ptrtoint ptr %a3 to i64
  %v408 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v409 = sub i64 %v408, 1
  %v410 = add nsw i64 %v407, %v409
  %v411 = inttoptr i64 %v410 to ptr
  %v412 = musttail call ptr @mlf.numeric.5(ptr %a0, ptr %a1, ptr %a2, ptr %v411)
  ret ptr %v412
}

define private ptr @mlf.numeric.12.pii(ptr %a0, ptr %a1, ptr %a2) alwaysinline {
entry:
  %v477 = ptrtoint ptr %a1 to i64
  %v478 = ptrtoint ptr %a2 to i64
  %v479 = icmp slt i64 %v477, %v478
  %v480 = select i1 %v479, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v481 = icmp eq ptr %v480, inttoptr (i64 6 to ptr)
  br i1 %v481, label %tail.yes.482, label %tail.no.483
tail.yes.482:
  %v484 = getelementptr i8, ptr %a0, i64 8
  %v485 = load i64, ptr %v484, align 8, !tbaa !3
  %v486 = getelementptr i8, ptr %a0, i64 16
  %v487 = load ptr, ptr %v486, align 8, !tbaa !3
  %v488 = ptrtoint ptr %a1 to i64
  %v489 = ashr i64 %v488, 1
  %v490 = and i64 %v488, 1
  %v491 = icmp ne i64 %v490, 0
  %v492 = icmp ult i64 %v489, %v485
  %v493 = and i1 %v491, %v492
  br i1 %v493, label %array.valid.494, label %array.invalid.495
array.invalid.495:
  call void @mlf_bounds_failure()
  unreachable
array.valid.494:
  %v496 = getelementptr i64, ptr %v487, i64 %v489
  %v497 = load ptr, ptr %v496, align 8, !tbaa !4
  %v498 = ptrtoint ptr %a2 to i64
  %v499 = ashr i64 %v498, 1
  %v500 = and i64 %v498, 1
  %v501 = icmp ne i64 %v500, 0
  %v502 = icmp ult i64 %v499, %v485
  %v503 = and i1 %v501, %v502
  br i1 %v503, label %array.valid.504, label %array.invalid.505
array.invalid.505:
  call void @mlf_bounds_failure()
  unreachable
array.valid.504:
  %v506 = getelementptr i64, ptr %v487, i64 %v499
  %v507 = load ptr, ptr %v506, align 8, !tbaa !4
  %v508 = ptrtoint ptr %a1 to i64
  %v509 = ashr i64 %v508, 1
  %v510 = and i64 %v508, 1
  %v511 = icmp ne i64 %v510, 0
  %v512 = icmp ult i64 %v509, %v485
  %v513 = and i1 %v511, %v512
  br i1 %v513, label %array.valid.514, label %array.invalid.515
array.invalid.515:
  call void @mlf_bounds_failure()
  unreachable
array.valid.514:
  %v516 = getelementptr i64, ptr %v487, i64 %v509
  store ptr %v507, ptr %v516, align 8, !tbaa !4
  %v517 = ptrtoint ptr %a2 to i64
  %v518 = ashr i64 %v517, 1
  %v519 = and i64 %v517, 1
  %v520 = icmp ne i64 %v519, 0
  %v521 = icmp ult i64 %v518, %v485
  %v522 = and i1 %v520, %v521
  br i1 %v522, label %array.valid.523, label %array.invalid.524
array.invalid.524:
  call void @mlf_bounds_failure()
  unreachable
array.valid.523:
  %v525 = getelementptr i64, ptr %v487, i64 %v518
  store ptr %v497, ptr %v525, align 8, !tbaa !4
  %v526 = ptrtoint ptr %a1 to i64
  %v527 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v528 = sub i64 %v527, 1
  %v529 = add nsw i64 %v526, %v528
  %v530 = inttoptr i64 %v529 to ptr
  %v531 = ptrtoint ptr %a2 to i64
  %v532 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v533 = sub i64 %v532, 1
  %v534 = sub nsw i64 %v531, %v533
  %v535 = inttoptr i64 %v534 to ptr
  %v536 = musttail call ptr @mlf.numeric.12.pii(ptr %a0, ptr %v530, ptr %v535)
  ret ptr %v536
tail.no.483:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.numeric.12(ptr %a0, ptr %a1, ptr %a2) alwaysinline {
entry:
  %v463 = ptrtoint ptr %a1 to i64
  %v464 = and i64 %v463, 1
  %v465 = icmp ne i64 %v464, 0
  %v466 = icmp ult i64 %v463, 4294967296
  %v467 = and i1 %v465, %v466
  %v468 = ptrtoint ptr %a2 to i64
  %v469 = and i64 %v468, 1
  %v470 = icmp ne i64 %v469, 0
  %v471 = icmp ult i64 %v468, 4294967296
  %v472 = and i1 %v470, %v471
  %v473 = and i1 true, %v467
  %v474 = and i1 %v473, %v472
  br i1 %v474, label %range.fast.475, label %range.general.476
range.fast.475:
  %v537 = musttail call ptr @mlf.numeric.12.pii(ptr %a0, ptr %a1, ptr %a2)
  ret ptr %v537
range.general.476:
  %v538 = ptrtoint ptr %a1 to i64
  %v539 = ptrtoint ptr %a2 to i64
  %v540 = and i64 %v538, %v539
  %v541 = and i64 %v540, 1
  %v542 = icmp ne i64 %v541, 0
  br i1 %v542, label %yes.543, label %no.544
yes.543:
  %v546 = icmp slt i64 %v538, %v539
  %v547 = select i1 %v546, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.545
no.544:
  %v548 = call ptr @mlf_lt_int(ptr %a1, ptr %a2)
  br label %join.545
join.545:
  %v549 = phi ptr [ %v547, %yes.543 ], [ %v548, %no.544 ]
  %v550 = icmp eq ptr %v549, inttoptr (i64 6 to ptr)
  br i1 %v550, label %tail.yes.551, label %tail.no.552
tail.yes.551:
  %v553 = getelementptr i8, ptr %a0, i64 8
  %v554 = load i64, ptr %v553, align 8, !tbaa !3
  %v555 = getelementptr i8, ptr %a0, i64 16
  %v556 = load ptr, ptr %v555, align 8, !tbaa !3
  %v557 = ptrtoint ptr %a1 to i64
  %v558 = ashr i64 %v557, 1
  %v559 = and i64 %v557, 1
  %v560 = icmp ne i64 %v559, 0
  %v561 = icmp ult i64 %v558, %v554
  %v562 = and i1 %v560, %v561
  br i1 %v562, label %array.valid.563, label %array.invalid.564
array.invalid.564:
  call void @mlf_bounds_failure()
  unreachable
array.valid.563:
  %v565 = getelementptr i64, ptr %v556, i64 %v558
  %v566 = load ptr, ptr %v565, align 8, !tbaa !4
  %v567 = ptrtoint ptr %a2 to i64
  %v568 = ashr i64 %v567, 1
  %v569 = and i64 %v567, 1
  %v570 = icmp ne i64 %v569, 0
  %v571 = icmp ult i64 %v568, %v554
  %v572 = and i1 %v570, %v571
  br i1 %v572, label %array.valid.573, label %array.invalid.574
array.invalid.574:
  call void @mlf_bounds_failure()
  unreachable
array.valid.573:
  %v575 = getelementptr i64, ptr %v556, i64 %v568
  %v576 = load ptr, ptr %v575, align 8, !tbaa !4
  %v577 = ptrtoint ptr %a1 to i64
  %v578 = ashr i64 %v577, 1
  %v579 = and i64 %v577, 1
  %v580 = icmp ne i64 %v579, 0
  %v581 = icmp ult i64 %v578, %v554
  %v582 = and i1 %v580, %v581
  br i1 %v582, label %array.valid.583, label %array.invalid.584
array.invalid.584:
  call void @mlf_bounds_failure()
  unreachable
array.valid.583:
  %v585 = getelementptr i64, ptr %v556, i64 %v578
  store ptr %v576, ptr %v585, align 8, !tbaa !4
  %v586 = ptrtoint ptr %a2 to i64
  %v587 = ashr i64 %v586, 1
  %v588 = and i64 %v586, 1
  %v589 = icmp ne i64 %v588, 0
  %v590 = icmp ult i64 %v587, %v554
  %v591 = and i1 %v589, %v590
  br i1 %v591, label %array.valid.592, label %array.invalid.593
array.invalid.593:
  call void @mlf_bounds_failure()
  unreachable
array.valid.592:
  %v594 = getelementptr i64, ptr %v556, i64 %v587
  store ptr %v566, ptr %v594, align 8, !tbaa !4
  %v595 = ptrtoint ptr %a1 to i64
  %v596 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v597 = sub i64 %v596, 1
  %v598 = add nsw i64 %v595, %v597
  %v599 = inttoptr i64 %v598 to ptr
  %v600 = ptrtoint ptr %a2 to i64
  %v601 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v602 = sub i64 %v601, 1
  %v603 = sub nsw i64 %v600, %v602
  %v604 = inttoptr i64 %v603 to ptr
  %v605 = musttail call ptr @mlf.numeric.12(ptr %a0, ptr %v599, ptr %v604)
  ret ptr %v605
tail.no.552:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.numeric.20(ptr %a0, ptr %a1) alwaysinline {
entry:
  %v612 = ptrtoint ptr %a1 to i64
  %v613 = and i64 %v612, 1
  %v614 = icmp ne i64 %v613, 0
  %v615 = icmp ult i64 %v612, 4294967296
  %v616 = and i1 %v614, %v615
  %v617 = and i1 true, %v616
  br i1 %v617, label %range.fast.618, label %range.general.619
range.fast.618:
  %v620 = musttail call ptr @mlf.numeric.20.pi(ptr %a0, ptr %a1)
  ret ptr %v620
range.general.619:
  %v621 = getelementptr i8, ptr %a0, i64 8
  %v622 = load i64, ptr %v621, align 8, !tbaa !3
  %v623 = getelementptr i8, ptr %a0, i64 16
  %v624 = load ptr, ptr %v623, align 8, !tbaa !3
  %v625 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v626 = ashr i64 %v625, 1
  %v627 = and i64 %v625, 1
  %v628 = icmp ne i64 %v627, 0
  %v629 = icmp ult i64 %v626, %v622
  %v630 = and i1 %v628, %v629
  br i1 %v630, label %array.valid.631, label %array.invalid.632
array.invalid.632:
  call void @mlf_bounds_failure()
  unreachable
array.valid.631:
  %v633 = getelementptr i64, ptr %v624, i64 %v626
  %v634 = load ptr, ptr %v633, align 8, !tbaa !4
  %v635 = ptrtoint ptr %v634 to i64
  %v636 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v637 = and i64 %v635, %v636
  %v638 = and i64 %v637, 1
  %v639 = icmp ne i64 %v638, 0
  br i1 %v639, label %yes.640, label %no.641
yes.640:
  %v643 = icmp eq i64 %v635, %v636
  %v644 = select i1 %v643, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.642
no.641:
  %v645 = call ptr @mlf_eq_int(ptr %v634, ptr inttoptr (i64 3 to ptr))
  br label %join.642
join.642:
  %v646 = phi ptr [ %v644, %yes.640 ], [ %v645, %no.641 ]
  %v647 = icmp eq ptr %v646, inttoptr (i64 6 to ptr)
  br i1 %v647, label %tail.yes.648, label %tail.no.649
tail.yes.648:
  ret ptr %a1
tail.no.649:
  %v650 = ptrtoint ptr %v634 to i64
  %v651 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v652 = and i64 %v650, %v651
  %v653 = and i64 %v652, 1
  %v654 = icmp ne i64 %v653, 0
  br i1 %v654, label %yes.655, label %no.656
yes.655:
  %v658 = sub i64 %v651, 1
  %v659 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v650, i64 %v658)
  %v660 = extractvalue { i64, i1 } %v659, 0
  %v661 = extractvalue { i64, i1 } %v659, 1
  br i1 %v661, label %yes.662, label %no.663
yes.662:
  %v665 = call ptr @mlf_sub_int(ptr %v634, ptr inttoptr (i64 3 to ptr))
  br label %join.664
no.663:
  %v666 = inttoptr i64 %v660 to ptr
  br label %join.664
join.664:
  %v667 = phi ptr [ %v665, %yes.662 ], [ %v666, %no.663 ]
  br label %join.657
no.656:
  %v668 = call ptr @mlf_sub_int(ptr %v634, ptr inttoptr (i64 3 to ptr))
  br label %join.657
join.657:
  %v669 = phi ptr [ %v667, %join.664 ], [ %v668, %no.656 ]
  %v670 = call ptr @mlf.numeric.12(ptr %a0, ptr inttoptr (i64 1 to ptr), ptr %v669)
  %v671 = ptrtoint ptr %a1 to i64
  %v672 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v673 = and i64 %v671, %v672
  %v674 = and i64 %v673, 1
  %v675 = icmp ne i64 %v674, 0
  br i1 %v675, label %yes.676, label %no.677
yes.676:
  %v679 = sub i64 %v672, 1
  %v680 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v671, i64 %v679)
  %v681 = extractvalue { i64, i1 } %v680, 0
  %v682 = extractvalue { i64, i1 } %v680, 1
  br i1 %v682, label %yes.683, label %no.684
yes.683:
  %v686 = call ptr @mlf_add_int(ptr %a1, ptr inttoptr (i64 3 to ptr))
  br label %join.685
no.684:
  %v687 = inttoptr i64 %v681 to ptr
  br label %join.685
join.685:
  %v688 = phi ptr [ %v686, %yes.683 ], [ %v687, %no.684 ]
  br label %join.678
no.677:
  %v689 = call ptr @mlf_add_int(ptr %a1, ptr inttoptr (i64 3 to ptr))
  br label %join.678
join.678:
  %v690 = phi ptr [ %v688, %join.685 ], [ %v689, %no.677 ]
  %v691 = musttail call ptr @mlf.numeric.20(ptr %a0, ptr %v690)
  ret ptr %v691
}

define private ptr @mlf.numeric.20.pi(ptr %a0, ptr %a1) alwaysinline {
entry:
  %v414 = getelementptr i8, ptr %a0, i64 8
  %v415 = load i64, ptr %v414, align 8, !tbaa !3
  %v416 = getelementptr i8, ptr %a0, i64 16
  %v417 = load ptr, ptr %v416, align 8, !tbaa !3
  %v418 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v419 = ashr i64 %v418, 1
  %v420 = and i64 %v418, 1
  %v421 = icmp ne i64 %v420, 0
  %v422 = icmp ult i64 %v419, %v415
  %v423 = and i1 %v421, %v422
  br i1 %v423, label %array.valid.424, label %array.invalid.425
array.invalid.425:
  call void @mlf_bounds_failure()
  unreachable
array.valid.424:
  %v426 = getelementptr i64, ptr %v417, i64 %v419
  %v427 = load ptr, ptr %v426, align 8, !tbaa !4
  %v428 = ptrtoint ptr %v427 to i64
  %v429 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v430 = and i64 %v428, %v429
  %v431 = and i64 %v430, 1
  %v432 = icmp ne i64 %v431, 0
  br i1 %v432, label %yes.433, label %no.434
yes.433:
  %v436 = icmp eq i64 %v428, %v429
  %v437 = select i1 %v436, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.435
no.434:
  %v438 = call ptr @mlf_eq_int(ptr %v427, ptr inttoptr (i64 3 to ptr))
  br label %join.435
join.435:
  %v439 = phi ptr [ %v437, %yes.433 ], [ %v438, %no.434 ]
  %v440 = icmp eq ptr %v439, inttoptr (i64 6 to ptr)
  br i1 %v440, label %tail.yes.441, label %tail.no.442
tail.yes.441:
  ret ptr %a1
tail.no.442:
  %v443 = ptrtoint ptr %v427 to i64
  %v444 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v445 = and i64 %v443, %v444
  %v446 = and i64 %v445, 1
  %v447 = icmp ne i64 %v446, 0
  br i1 %v447, label %yes.448, label %no.449
yes.448:
  %v451 = sub i64 %v444, 1
  %v452 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v443, i64 %v451)
  %v453 = extractvalue { i64, i1 } %v452, 0
  %v454 = extractvalue { i64, i1 } %v452, 1
  br i1 %v454, label %yes.455, label %no.456
yes.455:
  %v458 = call ptr @mlf_sub_int(ptr %v427, ptr inttoptr (i64 3 to ptr))
  br label %join.457
no.456:
  %v459 = inttoptr i64 %v453 to ptr
  br label %join.457
join.457:
  %v460 = phi ptr [ %v458, %yes.455 ], [ %v459, %no.456 ]
  br label %join.450
no.449:
  %v461 = call ptr @mlf_sub_int(ptr %v427, ptr inttoptr (i64 3 to ptr))
  br label %join.450
join.450:
  %v462 = phi ptr [ %v460, %join.457 ], [ %v461, %no.449 ]
  %v606 = call ptr @mlf.numeric.12(ptr %a0, ptr inttoptr (i64 1 to ptr), ptr %v462)
  %v607 = ptrtoint ptr %a1 to i64
  %v608 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v609 = sub i64 %v608, 1
  %v610 = add nsw i64 %v607, %v609
  %v611 = inttoptr i64 %v610 to ptr
  %v692 = musttail call ptr @mlf.numeric.20(ptr %a0, ptr %v611)
  ret ptr %v692
}

define private ptr @mlf.numeric.25.piii(ptr %a0, ptr %a1, ptr %a2, ptr %a3) alwaysinline {
entry:
  %v856 = ptrtoint ptr %a3 to i64
  %v857 = ptrtoint ptr %a1 to i64
  %v858 = icmp eq i64 %v856, %v857
  %v859 = select i1 %v858, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v860 = icmp eq ptr %v859, inttoptr (i64 6 to ptr)
  br i1 %v860, label %tail.yes.861, label %tail.no.862
tail.yes.861:
  %v863 = getelementptr i8, ptr %a0, i64 8
  %v864 = load i64, ptr %v863, align 8, !tbaa !3
  %v865 = getelementptr i8, ptr %a0, i64 16
  %v866 = load ptr, ptr %v865, align 8, !tbaa !3
  %v867 = ptrtoint ptr %a1 to i64
  %v868 = ashr i64 %v867, 1
  %v869 = and i64 %v867, 1
  %v870 = icmp ne i64 %v869, 0
  %v871 = icmp ult i64 %v868, %v864
  %v872 = and i1 %v870, %v871
  br i1 %v872, label %array.valid.873, label %array.invalid.874
array.invalid.874:
  call void @mlf_bounds_failure()
  unreachable
array.valid.873:
  %v875 = getelementptr i64, ptr %v866, i64 %v868
  store ptr %a2, ptr %v875, align 8, !tbaa !4
  ret ptr inttoptr (i64 4 to ptr)
tail.no.862:
  %v876 = ptrtoint ptr %a3 to i64
  %v877 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v878 = sub i64 %v877, 1
  %v879 = add nsw i64 %v876, %v878
  %v880 = inttoptr i64 %v879 to ptr
  %v881 = getelementptr i8, ptr %a0, i64 8
  %v882 = load i64, ptr %v881, align 8, !tbaa !3
  %v883 = getelementptr i8, ptr %a0, i64 16
  %v884 = load ptr, ptr %v883, align 8, !tbaa !3
  %v885 = ptrtoint ptr %v880 to i64
  %v886 = ashr i64 %v885, 1
  %v887 = and i64 %v885, 1
  %v888 = icmp ne i64 %v887, 0
  %v889 = icmp ult i64 %v886, %v882
  %v890 = and i1 %v888, %v889
  br i1 %v890, label %array.valid.891, label %array.invalid.892
array.invalid.892:
  call void @mlf_bounds_failure()
  unreachable
array.valid.891:
  %v893 = getelementptr i64, ptr %v884, i64 %v886
  %v894 = load ptr, ptr %v893, align 8, !tbaa !4
  %v895 = ptrtoint ptr %a3 to i64
  %v896 = ashr i64 %v895, 1
  %v897 = and i64 %v895, 1
  %v898 = icmp ne i64 %v897, 0
  %v899 = icmp ult i64 %v896, %v882
  %v900 = and i1 %v898, %v899
  br i1 %v900, label %array.valid.901, label %array.invalid.902
array.invalid.902:
  call void @mlf_bounds_failure()
  unreachable
array.valid.901:
  %v903 = getelementptr i64, ptr %v884, i64 %v896
  store ptr %v894, ptr %v903, align 8, !tbaa !4
  %v904 = ptrtoint ptr %a3 to i64
  %v905 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v906 = sub i64 %v905, 1
  %v907 = add nsw i64 %v904, %v906
  %v908 = inttoptr i64 %v907 to ptr
  %v909 = musttail call ptr @mlf.numeric.25(ptr %a0, ptr %a1, ptr %a2, ptr %v908)
  ret ptr %v909
}

define private ptr @mlf.numeric.25(ptr %a0, ptr %a1, ptr %a2, ptr %a3) alwaysinline {
entry:
  %v836 = ptrtoint ptr %a1 to i64
  %v837 = and i64 %v836, 1
  %v838 = icmp ne i64 %v837, 0
  %v839 = icmp ult i64 %v836, 4294967296
  %v840 = and i1 %v838, %v839
  %v841 = ptrtoint ptr %a2 to i64
  %v842 = and i64 %v841, 1
  %v843 = icmp ne i64 %v842, 0
  %v844 = icmp ult i64 %v841, 4294967296
  %v845 = and i1 %v843, %v844
  %v846 = ptrtoint ptr %a3 to i64
  %v847 = and i64 %v846, 1
  %v848 = icmp ne i64 %v847, 0
  %v849 = icmp ult i64 %v846, 4294967296
  %v850 = and i1 %v848, %v849
  %v851 = and i1 true, %v840
  %v852 = and i1 %v851, %v845
  %v853 = and i1 %v852, %v850
  br i1 %v853, label %range.fast.854, label %range.general.855
range.fast.854:
  %v910 = musttail call ptr @mlf.numeric.25.piii(ptr %a0, ptr %a1, ptr %a2, ptr %a3)
  ret ptr %v910
range.general.855:
  %v911 = ptrtoint ptr %a3 to i64
  %v912 = ptrtoint ptr %a1 to i64
  %v913 = and i64 %v911, %v912
  %v914 = and i64 %v913, 1
  %v915 = icmp ne i64 %v914, 0
  br i1 %v915, label %yes.916, label %no.917
yes.916:
  %v919 = icmp eq i64 %v911, %v912
  %v920 = select i1 %v919, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.918
no.917:
  %v921 = call ptr @mlf_eq_int(ptr %a3, ptr %a1)
  br label %join.918
join.918:
  %v922 = phi ptr [ %v920, %yes.916 ], [ %v921, %no.917 ]
  %v923 = icmp eq ptr %v922, inttoptr (i64 6 to ptr)
  br i1 %v923, label %tail.yes.924, label %tail.no.925
tail.yes.924:
  %v926 = getelementptr i8, ptr %a0, i64 8
  %v927 = load i64, ptr %v926, align 8, !tbaa !3
  %v928 = getelementptr i8, ptr %a0, i64 16
  %v929 = load ptr, ptr %v928, align 8, !tbaa !3
  %v930 = ptrtoint ptr %a1 to i64
  %v931 = ashr i64 %v930, 1
  %v932 = and i64 %v930, 1
  %v933 = icmp ne i64 %v932, 0
  %v934 = icmp ult i64 %v931, %v927
  %v935 = and i1 %v933, %v934
  br i1 %v935, label %array.valid.936, label %array.invalid.937
array.invalid.937:
  call void @mlf_bounds_failure()
  unreachable
array.valid.936:
  %v938 = getelementptr i64, ptr %v929, i64 %v931
  store ptr %a2, ptr %v938, align 8, !tbaa !4
  ret ptr inttoptr (i64 4 to ptr)
tail.no.925:
  %v939 = ptrtoint ptr %a3 to i64
  %v940 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v941 = and i64 %v939, %v940
  %v942 = and i64 %v941, 1
  %v943 = icmp ne i64 %v942, 0
  br i1 %v943, label %yes.944, label %no.945
yes.944:
  %v947 = sub i64 %v940, 1
  %v948 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v939, i64 %v947)
  %v949 = extractvalue { i64, i1 } %v948, 0
  %v950 = extractvalue { i64, i1 } %v948, 1
  br i1 %v950, label %yes.951, label %no.952
yes.951:
  %v954 = call ptr @mlf_add_int(ptr %a3, ptr inttoptr (i64 3 to ptr))
  br label %join.953
no.952:
  %v955 = inttoptr i64 %v949 to ptr
  br label %join.953
join.953:
  %v956 = phi ptr [ %v954, %yes.951 ], [ %v955, %no.952 ]
  br label %join.946
no.945:
  %v957 = call ptr @mlf_add_int(ptr %a3, ptr inttoptr (i64 3 to ptr))
  br label %join.946
join.946:
  %v958 = phi ptr [ %v956, %join.953 ], [ %v957, %no.945 ]
  %v959 = getelementptr i8, ptr %a0, i64 8
  %v960 = load i64, ptr %v959, align 8, !tbaa !3
  %v961 = getelementptr i8, ptr %a0, i64 16
  %v962 = load ptr, ptr %v961, align 8, !tbaa !3
  %v963 = ptrtoint ptr %v958 to i64
  %v964 = ashr i64 %v963, 1
  %v965 = and i64 %v963, 1
  %v966 = icmp ne i64 %v965, 0
  %v967 = icmp ult i64 %v964, %v960
  %v968 = and i1 %v966, %v967
  br i1 %v968, label %array.valid.969, label %array.invalid.970
array.invalid.970:
  call void @mlf_bounds_failure()
  unreachable
array.valid.969:
  %v971 = getelementptr i64, ptr %v962, i64 %v964
  %v972 = load ptr, ptr %v971, align 8, !tbaa !4
  %v973 = ptrtoint ptr %a3 to i64
  %v974 = ashr i64 %v973, 1
  %v975 = and i64 %v973, 1
  %v976 = icmp ne i64 %v975, 0
  %v977 = icmp ult i64 %v974, %v960
  %v978 = and i1 %v976, %v977
  br i1 %v978, label %array.valid.979, label %array.invalid.980
array.invalid.980:
  call void @mlf_bounds_failure()
  unreachable
array.valid.979:
  %v981 = getelementptr i64, ptr %v962, i64 %v974
  store ptr %v972, ptr %v981, align 8, !tbaa !4
  %v982 = ptrtoint ptr %a3 to i64
  %v983 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v984 = sub i64 %v983, 1
  %v985 = add nsw i64 %v982, %v984
  %v986 = inttoptr i64 %v985 to ptr
  %v987 = musttail call ptr @mlf.numeric.25(ptr %a0, ptr %a1, ptr %a2, ptr %v986)
  ret ptr %v987
}

define private ptr @mlf.numeric.32.ppii(ptr %a0, ptr %a1, ptr %a2, ptr %a3) alwaysinline {
entry:
  %v815 = ptrtoint ptr %a3 to i64
  %v816 = ptrtoint ptr %a2 to i64
  %v817 = icmp eq i64 %v815, %v816
  %v818 = select i1 %v817, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v819 = icmp eq ptr %v818, inttoptr (i64 6 to ptr)
  br i1 %v819, label %tail.yes.820, label %tail.no.821
tail.yes.820:
  ret ptr inttoptr (i64 2 to ptr)
tail.no.821:
  %v822 = getelementptr i8, ptr %a0, i64 8
  %v823 = load i64, ptr %v822, align 8, !tbaa !3
  %v824 = getelementptr i8, ptr %a0, i64 16
  %v825 = load ptr, ptr %v824, align 8, !tbaa !3
  %v826 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v827 = ashr i64 %v826, 1
  %v828 = and i64 %v826, 1
  %v829 = icmp ne i64 %v828, 0
  %v830 = icmp ult i64 %v827, %v823
  %v831 = and i1 %v829, %v830
  br i1 %v831, label %array.valid.832, label %array.invalid.833
array.invalid.833:
  call void @mlf_bounds_failure()
  unreachable
array.valid.832:
  %v834 = getelementptr i64, ptr %v825, i64 %v827
  %v835 = load ptr, ptr %v834, align 8, !tbaa !4
  %v988 = call ptr @mlf.numeric.25(ptr %a0, ptr %a3, ptr %v835, ptr inttoptr (i64 1 to ptr))
  %v989 = getelementptr i8, ptr %a1, i64 8
  %v990 = load i64, ptr %v989, align 8, !tbaa !3
  %v991 = getelementptr i8, ptr %a1, i64 16
  %v992 = load ptr, ptr %v991, align 8, !tbaa !3
  %v993 = ptrtoint ptr %a3 to i64
  %v994 = ashr i64 %v993, 1
  %v995 = and i64 %v993, 1
  %v996 = icmp ne i64 %v995, 0
  %v997 = icmp ult i64 %v994, %v990
  %v998 = and i1 %v996, %v997
  br i1 %v998, label %array.valid.999, label %array.invalid.1000
array.invalid.1000:
  call void @mlf_bounds_failure()
  unreachable
array.valid.999:
  %v1001 = getelementptr i64, ptr %v992, i64 %v994
  %v1002 = load ptr, ptr %v1001, align 8, !tbaa !4
  %v1003 = ptrtoint ptr %v1002 to i64
  %v1004 = ptrtoint ptr %a3 to i64
  %v1005 = and i64 %v1003, %v1004
  %v1006 = and i64 %v1005, 1
  %v1007 = icmp ne i64 %v1006, 0
  br i1 %v1007, label %yes.1008, label %no.1009
yes.1008:
  %v1011 = icmp slt i64 %v1003, %v1004
  %v1012 = select i1 %v1011, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1010
no.1009:
  %v1013 = call ptr @mlf_lt_int(ptr %v1002, ptr %a3)
  br label %join.1010
join.1010:
  %v1014 = phi ptr [ %v1012, %yes.1008 ], [ %v1013, %no.1009 ]
  %v1015 = icmp eq ptr %v1014, inttoptr (i64 6 to ptr)
  br i1 %v1015, label %tail.yes.1016, label %tail.no.1017
tail.yes.1016:
  %v1018 = ptrtoint ptr %v1002 to i64
  %v1019 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1020 = and i64 %v1018, %v1019
  %v1021 = and i64 %v1020, 1
  %v1022 = icmp ne i64 %v1021, 0
  br i1 %v1022, label %yes.1023, label %no.1024
yes.1023:
  %v1026 = sub i64 %v1019, 1
  %v1027 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1018, i64 %v1026)
  %v1028 = extractvalue { i64, i1 } %v1027, 0
  %v1029 = extractvalue { i64, i1 } %v1027, 1
  br i1 %v1029, label %yes.1030, label %no.1031
yes.1030:
  %v1033 = call ptr @mlf_add_int(ptr %v1002, ptr inttoptr (i64 3 to ptr))
  br label %join.1032
no.1031:
  %v1034 = inttoptr i64 %v1028 to ptr
  br label %join.1032
join.1032:
  %v1035 = phi ptr [ %v1033, %yes.1030 ], [ %v1034, %no.1031 ]
  br label %join.1025
no.1024:
  %v1036 = call ptr @mlf_add_int(ptr %v1002, ptr inttoptr (i64 3 to ptr))
  br label %join.1025
join.1025:
  %v1037 = phi ptr [ %v1035, %join.1032 ], [ %v1036, %no.1024 ]
  %v1038 = ptrtoint ptr %a3 to i64
  %v1039 = ashr i64 %v1038, 1
  %v1040 = and i64 %v1038, 1
  %v1041 = icmp ne i64 %v1040, 0
  %v1042 = icmp ult i64 %v1039, %v990
  %v1043 = and i1 %v1041, %v1042
  br i1 %v1043, label %array.valid.1044, label %array.invalid.1045
array.invalid.1045:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1044:
  %v1046 = getelementptr i64, ptr %v992, i64 %v1039
  store ptr %v1037, ptr %v1046, align 8, !tbaa !4
  ret ptr inttoptr (i64 6 to ptr)
tail.no.1017:
  %v1047 = ptrtoint ptr %a3 to i64
  %v1048 = ashr i64 %v1047, 1
  %v1049 = and i64 %v1047, 1
  %v1050 = icmp ne i64 %v1049, 0
  %v1051 = icmp ult i64 %v1048, %v990
  %v1052 = and i1 %v1050, %v1051
  br i1 %v1052, label %array.valid.1053, label %array.invalid.1054
array.invalid.1054:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1053:
  %v1055 = getelementptr i64, ptr %v992, i64 %v1048
  store ptr inttoptr (i64 1 to ptr), ptr %v1055, align 8, !tbaa !4
  %v1056 = ptrtoint ptr %a3 to i64
  %v1057 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1058 = sub i64 %v1057, 1
  %v1059 = add nsw i64 %v1056, %v1058
  %v1060 = inttoptr i64 %v1059 to ptr
  %v1061 = musttail call ptr @mlf.numeric.32(ptr %a0, ptr %a1, ptr %a2, ptr %v1060)
  ret ptr %v1061
}

define private ptr @mlf.numeric.32(ptr %a0, ptr %a1, ptr %a2, ptr %a3) alwaysinline {
entry:
  %v801 = ptrtoint ptr %a2 to i64
  %v802 = and i64 %v801, 1
  %v803 = icmp ne i64 %v802, 0
  %v804 = icmp ult i64 %v801, 4294967296
  %v805 = and i1 %v803, %v804
  %v806 = ptrtoint ptr %a3 to i64
  %v807 = and i64 %v806, 1
  %v808 = icmp ne i64 %v807, 0
  %v809 = icmp ult i64 %v806, 4294967296
  %v810 = and i1 %v808, %v809
  %v811 = and i1 true, %v805
  %v812 = and i1 %v811, %v810
  br i1 %v812, label %range.fast.813, label %range.general.814
range.fast.813:
  %v1062 = musttail call ptr @mlf.numeric.32.ppii(ptr %a0, ptr %a1, ptr %a2, ptr %a3)
  ret ptr %v1062
range.general.814:
  %v1063 = ptrtoint ptr %a3 to i64
  %v1064 = ptrtoint ptr %a2 to i64
  %v1065 = and i64 %v1063, %v1064
  %v1066 = and i64 %v1065, 1
  %v1067 = icmp ne i64 %v1066, 0
  br i1 %v1067, label %yes.1068, label %no.1069
yes.1068:
  %v1071 = icmp eq i64 %v1063, %v1064
  %v1072 = select i1 %v1071, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1070
no.1069:
  %v1073 = call ptr @mlf_eq_int(ptr %a3, ptr %a2)
  br label %join.1070
join.1070:
  %v1074 = phi ptr [ %v1072, %yes.1068 ], [ %v1073, %no.1069 ]
  %v1075 = icmp eq ptr %v1074, inttoptr (i64 6 to ptr)
  br i1 %v1075, label %tail.yes.1076, label %tail.no.1077
tail.yes.1076:
  ret ptr inttoptr (i64 2 to ptr)
tail.no.1077:
  %v1078 = getelementptr i8, ptr %a0, i64 8
  %v1079 = load i64, ptr %v1078, align 8, !tbaa !3
  %v1080 = getelementptr i8, ptr %a0, i64 16
  %v1081 = load ptr, ptr %v1080, align 8, !tbaa !3
  %v1082 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v1083 = ashr i64 %v1082, 1
  %v1084 = and i64 %v1082, 1
  %v1085 = icmp ne i64 %v1084, 0
  %v1086 = icmp ult i64 %v1083, %v1079
  %v1087 = and i1 %v1085, %v1086
  br i1 %v1087, label %array.valid.1088, label %array.invalid.1089
array.invalid.1089:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1088:
  %v1090 = getelementptr i64, ptr %v1081, i64 %v1083
  %v1091 = load ptr, ptr %v1090, align 8, !tbaa !4
  %v1092 = call ptr @mlf.numeric.25(ptr %a0, ptr %a3, ptr %v1091, ptr inttoptr (i64 1 to ptr))
  %v1093 = getelementptr i8, ptr %a1, i64 8
  %v1094 = load i64, ptr %v1093, align 8, !tbaa !3
  %v1095 = getelementptr i8, ptr %a1, i64 16
  %v1096 = load ptr, ptr %v1095, align 8, !tbaa !3
  %v1097 = ptrtoint ptr %a3 to i64
  %v1098 = ashr i64 %v1097, 1
  %v1099 = and i64 %v1097, 1
  %v1100 = icmp ne i64 %v1099, 0
  %v1101 = icmp ult i64 %v1098, %v1094
  %v1102 = and i1 %v1100, %v1101
  br i1 %v1102, label %array.valid.1103, label %array.invalid.1104
array.invalid.1104:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1103:
  %v1105 = getelementptr i64, ptr %v1096, i64 %v1098
  %v1106 = load ptr, ptr %v1105, align 8, !tbaa !4
  %v1107 = ptrtoint ptr %v1106 to i64
  %v1108 = ptrtoint ptr %a3 to i64
  %v1109 = and i64 %v1107, %v1108
  %v1110 = and i64 %v1109, 1
  %v1111 = icmp ne i64 %v1110, 0
  br i1 %v1111, label %yes.1112, label %no.1113
yes.1112:
  %v1115 = icmp slt i64 %v1107, %v1108
  %v1116 = select i1 %v1115, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1114
no.1113:
  %v1117 = call ptr @mlf_lt_int(ptr %v1106, ptr %a3)
  br label %join.1114
join.1114:
  %v1118 = phi ptr [ %v1116, %yes.1112 ], [ %v1117, %no.1113 ]
  %v1119 = icmp eq ptr %v1118, inttoptr (i64 6 to ptr)
  br i1 %v1119, label %tail.yes.1120, label %tail.no.1121
tail.yes.1120:
  %v1122 = ptrtoint ptr %v1106 to i64
  %v1123 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1124 = and i64 %v1122, %v1123
  %v1125 = and i64 %v1124, 1
  %v1126 = icmp ne i64 %v1125, 0
  br i1 %v1126, label %yes.1127, label %no.1128
yes.1127:
  %v1130 = sub i64 %v1123, 1
  %v1131 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1122, i64 %v1130)
  %v1132 = extractvalue { i64, i1 } %v1131, 0
  %v1133 = extractvalue { i64, i1 } %v1131, 1
  br i1 %v1133, label %yes.1134, label %no.1135
yes.1134:
  %v1137 = call ptr @mlf_add_int(ptr %v1106, ptr inttoptr (i64 3 to ptr))
  br label %join.1136
no.1135:
  %v1138 = inttoptr i64 %v1132 to ptr
  br label %join.1136
join.1136:
  %v1139 = phi ptr [ %v1137, %yes.1134 ], [ %v1138, %no.1135 ]
  br label %join.1129
no.1128:
  %v1140 = call ptr @mlf_add_int(ptr %v1106, ptr inttoptr (i64 3 to ptr))
  br label %join.1129
join.1129:
  %v1141 = phi ptr [ %v1139, %join.1136 ], [ %v1140, %no.1128 ]
  %v1142 = ptrtoint ptr %a3 to i64
  %v1143 = ashr i64 %v1142, 1
  %v1144 = and i64 %v1142, 1
  %v1145 = icmp ne i64 %v1144, 0
  %v1146 = icmp ult i64 %v1143, %v1094
  %v1147 = and i1 %v1145, %v1146
  br i1 %v1147, label %array.valid.1148, label %array.invalid.1149
array.invalid.1149:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1148:
  %v1150 = getelementptr i64, ptr %v1096, i64 %v1143
  store ptr %v1141, ptr %v1150, align 8, !tbaa !4
  ret ptr inttoptr (i64 6 to ptr)
tail.no.1121:
  %v1151 = ptrtoint ptr %a3 to i64
  %v1152 = ashr i64 %v1151, 1
  %v1153 = and i64 %v1151, 1
  %v1154 = icmp ne i64 %v1153, 0
  %v1155 = icmp ult i64 %v1152, %v1094
  %v1156 = and i1 %v1154, %v1155
  br i1 %v1156, label %array.valid.1157, label %array.invalid.1158
array.invalid.1158:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1157:
  %v1159 = getelementptr i64, ptr %v1096, i64 %v1152
  store ptr inttoptr (i64 1 to ptr), ptr %v1159, align 8, !tbaa !4
  %v1160 = ptrtoint ptr %a3 to i64
  %v1161 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1162 = sub i64 %v1161, 1
  %v1163 = add nsw i64 %v1160, %v1162
  %v1164 = inttoptr i64 %v1163 to ptr
  %v1165 = musttail call ptr @mlf.numeric.32(ptr %a0, ptr %a1, ptr %a2, ptr %v1164)
  ret ptr %v1165
}

define private ptr @mlf.numeric.42(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6) alwaysinline {
entry:
  %v413 = call ptr @mlf.numeric.5(ptr %a0, ptr %a1, ptr %a3, ptr inttoptr (i64 1 to ptr))
  %v693 = call ptr @mlf.numeric.20.pi(ptr %a1, ptr inttoptr (i64 1 to ptr))
  %v694 = ptrtoint ptr %a4 to i64
  %v695 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v696 = and i64 %v694, %v695
  %v697 = and i64 %v696, 1
  %v698 = icmp ne i64 %v697, 0
  br i1 %v698, label %yes.699, label %no.700
yes.699:
  %v702 = ashr i64 %v694, 1
  %v703 = ashr i64 %v695, 1
  %v704 = icmp ne i64 %v703, 0
  %v705 = icmp eq i64 %v702, -4611686018427387904
  %v706 = icmp eq i64 %v703, -1
  %v707 = and i1 %v705, %v706
  %v708 = xor i1 %v707, true
  %v709 = and i1 %v704, %v708
  br i1 %v709, label %yes.710, label %no.711
yes.710:
  %v713 = srem i64 %v702, %v703
  %v714 = shl i64 %v713, 1
  %v715 = or i64 %v714, 1
  %v716 = inttoptr i64 %v715 to ptr
  br label %join.712
no.711:
  %v717 = call ptr @mlf_prim2(i64 16, ptr %a4, ptr inttoptr (i64 5 to ptr))
  br label %join.712
join.712:
  %v718 = phi ptr [ %v716, %yes.710 ], [ %v717, %no.711 ]
  br label %join.701
no.700:
  %v719 = call ptr @mlf_prim2(i64 16, ptr %a4, ptr inttoptr (i64 5 to ptr))
  br label %join.701
join.701:
  %v720 = phi ptr [ %v718, %join.712 ], [ %v719, %no.700 ]
  %v721 = ptrtoint ptr %v720 to i64
  %v722 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v723 = and i64 %v721, %v722
  %v724 = and i64 %v723, 1
  %v725 = icmp ne i64 %v724, 0
  br i1 %v725, label %yes.726, label %no.727
yes.726:
  %v729 = icmp eq i64 %v721, %v722
  %v730 = select i1 %v729, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.728
no.727:
  %v731 = call ptr @mlf_eq_int(ptr %v720, ptr inttoptr (i64 1 to ptr))
  br label %join.728
join.728:
  %v732 = phi ptr [ %v730, %yes.726 ], [ %v731, %no.727 ]
  %v733 = icmp eq ptr %v732, inttoptr (i64 6 to ptr)
  br i1 %v733, label %yes.734, label %no.735
yes.734:
  %v737 = ptrtoint ptr %a5 to i64
  %v738 = ptrtoint ptr %v693 to i64
  %v739 = and i64 %v737, %v738
  %v740 = and i64 %v739, 1
  %v741 = icmp ne i64 %v740, 0
  br i1 %v741, label %yes.742, label %no.743
yes.742:
  %v745 = sub i64 %v738, 1
  %v746 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v737, i64 %v745)
  %v747 = extractvalue { i64, i1 } %v746, 0
  %v748 = extractvalue { i64, i1 } %v746, 1
  br i1 %v748, label %yes.749, label %no.750
yes.749:
  %v752 = call ptr @mlf_add_int(ptr %a5, ptr %v693)
  br label %join.751
no.750:
  %v753 = inttoptr i64 %v747 to ptr
  br label %join.751
join.751:
  %v754 = phi ptr [ %v752, %yes.749 ], [ %v753, %no.750 ]
  br label %join.744
no.743:
  %v755 = call ptr @mlf_add_int(ptr %a5, ptr %v693)
  br label %join.744
join.744:
  %v756 = phi ptr [ %v754, %join.751 ], [ %v755, %no.743 ]
  br label %join.736
no.735:
  %v757 = ptrtoint ptr %a5 to i64
  %v758 = ptrtoint ptr %v693 to i64
  %v759 = and i64 %v757, %v758
  %v760 = and i64 %v759, 1
  %v761 = icmp ne i64 %v760, 0
  br i1 %v761, label %yes.762, label %no.763
yes.762:
  %v765 = sub i64 %v758, 1
  %v766 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v757, i64 %v765)
  %v767 = extractvalue { i64, i1 } %v766, 0
  %v768 = extractvalue { i64, i1 } %v766, 1
  br i1 %v768, label %yes.769, label %no.770
yes.769:
  %v772 = call ptr @mlf_sub_int(ptr %a5, ptr %v693)
  br label %join.771
no.770:
  %v773 = inttoptr i64 %v767 to ptr
  br label %join.771
join.771:
  %v774 = phi ptr [ %v772, %yes.769 ], [ %v773, %no.770 ]
  br label %join.764
no.763:
  %v775 = call ptr @mlf_sub_int(ptr %a5, ptr %v693)
  br label %join.764
join.764:
  %v776 = phi ptr [ %v774, %join.771 ], [ %v775, %no.763 ]
  br label %join.736
join.736:
  %v777 = phi ptr [ %v756, %join.744 ], [ %v776, %join.764 ]
  %v778 = ptrtoint ptr %a6 to i64
  %v779 = ptrtoint ptr %v693 to i64
  %v780 = and i64 %v778, %v779
  %v781 = and i64 %v780, 1
  %v782 = icmp ne i64 %v781, 0
  br i1 %v782, label %yes.783, label %no.784
yes.783:
  %v786 = icmp slt i64 %v778, %v779
  %v787 = select i1 %v786, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.785
no.784:
  %v788 = call ptr @mlf_lt_int(ptr %a6, ptr %v693)
  br label %join.785
join.785:
  %v789 = phi ptr [ %v787, %yes.783 ], [ %v788, %no.784 ]
  %v790 = icmp eq ptr %v789, inttoptr (i64 6 to ptr)
  br i1 %v790, label %yes.791, label %no.792
yes.791:
  br label %join.793
no.792:
  br label %join.793
join.793:
  %v794 = phi ptr [ %v693, %yes.791 ], [ %a6, %no.792 ]
  %v795 = icmp eq ptr inttoptr (i64 6 to ptr), inttoptr (i64 6 to ptr)
  br i1 %v795, label %tail.yes.796, label %tail.no.797
tail.yes.796:
  %v798 = icmp eq ptr inttoptr (i64 6 to ptr), inttoptr (i64 6 to ptr)
  br i1 %v798, label %tail.yes.799, label %tail.no.800
tail.yes.799:
  %v1166 = call ptr @mlf.numeric.32(ptr %a0, ptr %a2, ptr %a3, ptr inttoptr (i64 3 to ptr))
  %v1167 = icmp eq ptr %v1166, inttoptr (i64 6 to ptr)
  br i1 %v1167, label %tail.yes.1168, label %tail.no.1169
tail.yes.1168:
  %v1170 = ptrtoint ptr %a4 to i64
  %v1171 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1172 = and i64 %v1170, %v1171
  %v1173 = and i64 %v1172, 1
  %v1174 = icmp ne i64 %v1173, 0
  br i1 %v1174, label %yes.1175, label %no.1176
yes.1175:
  %v1178 = sub i64 %v1171, 1
  %v1179 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1170, i64 %v1178)
  %v1180 = extractvalue { i64, i1 } %v1179, 0
  %v1181 = extractvalue { i64, i1 } %v1179, 1
  br i1 %v1181, label %yes.1182, label %no.1183
yes.1182:
  %v1185 = call ptr @mlf_add_int(ptr %a4, ptr inttoptr (i64 3 to ptr))
  br label %join.1184
no.1183:
  %v1186 = inttoptr i64 %v1180 to ptr
  br label %join.1184
join.1184:
  %v1187 = phi ptr [ %v1185, %yes.1182 ], [ %v1186, %no.1183 ]
  br label %join.1177
no.1176:
  %v1188 = call ptr @mlf_add_int(ptr %a4, ptr inttoptr (i64 3 to ptr))
  br label %join.1177
join.1177:
  %v1189 = phi ptr [ %v1187, %join.1184 ], [ %v1188, %no.1176 ]
  %v1190 = musttail call ptr @mlf.numeric.42(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %v1189, ptr %v777, ptr %v794)
  ret ptr %v1190
tail.no.1169:
  %v1191 = call ptr @mlf.construct.2(i64 1, ptr %v777, ptr %v794)
  ret ptr %v1191
tail.no.800:
  %v1192 = call ptr @mlf.construct.2(i64 1, ptr inttoptr (i64 1 to ptr), ptr inttoptr (i64 1 to ptr))
  ret ptr %v1192
tail.no.797:
  %v1193 = call ptr @mlf.construct.2(i64 1, ptr inttoptr (i64 1 to ptr), ptr inttoptr (i64 1 to ptr))
  ret ptr %v1193
}

define private ptr @mlf.code.1238(ptr %env, ptr %arg) {
entry:
  %v1239 = getelementptr i8, ptr %env, i64 8
  %v1240 = load ptr, ptr %v1239, align 8, !tbaa !3
  %v1241 = getelementptr i8, ptr %env, i64 16
  %v1242 = load ptr, ptr %v1241, align 8, !tbaa !3
  %v1243 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1243, align 8, !tbaa !3
  %v1244 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1244, align 8, !tbaa !3
  %v1245 = call ptr @mlf_prim2(i64 28, ptr %v1240, ptr %v1242)
  ret ptr %v1245
}

define private ptr @mlf.code.1260(ptr %env, ptr %arg) {
entry:
  %v1261 = getelementptr i8, ptr %env, i64 8
  %v1262 = load ptr, ptr %v1261, align 8, !tbaa !3
  %v1263 = getelementptr i8, ptr %env, i64 16
  %v1264 = load ptr, ptr %v1263, align 8, !tbaa !3
  %v1265 = getelementptr i8, ptr %env, i64 24
  %v1266 = load ptr, ptr %v1265, align 8, !tbaa !3
  %v1267 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1267, align 8, !tbaa !3
  %v1268 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1268, align 8, !tbaa !3
  %v1269 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v1269, align 8, !tbaa !3
  %v1270 = call ptr @mlf_prim3(i64 29, ptr %v1262, ptr %v1264, ptr %v1266)
  ret ptr %v1270
}

define private ptr @mlf.code.1277(ptr %env, ptr %arg) {
entry:
  %v1278 = getelementptr i8, ptr %env, i64 8
  %v1279 = load ptr, ptr %v1278, align 8, !tbaa !3
  %v1280 = getelementptr i8, ptr %env, i64 16
  %v1281 = load ptr, ptr %v1280, align 8, !tbaa !3
  %v1282 = getelementptr i8, ptr %env, i64 24
  %v1283 = load ptr, ptr %v1282, align 8, !tbaa !3
  %v1284 = getelementptr i8, ptr %env, i64 32
  %v1285 = load ptr, ptr %v1284, align 8, !tbaa !3
  %v1286 = call ptr @mlf.force(ptr %v1283)
  %v1287 = call ptr @mlf.force(ptr %v1285)
  %v1288 = call ptr @mlf_prim2(i64 8, ptr %v1287, ptr inttoptr (i64 3 to ptr))
  %v1289 = call ptr @mlf_env_new(i64 4)
  %v1290 = getelementptr i8, ptr %v1289, i64 8
  store ptr %v1279, ptr %v1290, align 8, !tbaa !3
  %v1291 = getelementptr i8, ptr %v1289, i64 16
  store ptr %v1281, ptr %v1291, align 8, !tbaa !3
  %v1292 = getelementptr i8, ptr %v1289, i64 24
  store ptr %v1286, ptr %v1292, align 8, !tbaa !3
  %v1293 = getelementptr i8, ptr %v1289, i64 32
  store ptr %v1288, ptr %v1293, align 8, !tbaa !3
  %v1294 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1206, ptr %v1289)
  ret ptr %v1294
}

define private ptr @mlf.code.1251(ptr %env, ptr %arg) {
entry:
  %v1252 = getelementptr i8, ptr %env, i64 8
  %v1253 = load ptr, ptr %v1252, align 8, !tbaa !3
  %v1254 = getelementptr i8, ptr %env, i64 16
  %v1255 = load ptr, ptr %v1254, align 8, !tbaa !3
  %v1256 = getelementptr i8, ptr %env, i64 24
  %v1257 = load ptr, ptr %v1256, align 8, !tbaa !3
  %v1258 = getelementptr i8, ptr %env, i64 32
  %v1259 = load ptr, ptr %v1258, align 8, !tbaa !3
  %v1271 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1260, i64 3)
  %v1272 = getelementptr i8, ptr %v1271, i64 16
  %v1273 = load ptr, ptr %v1272, align 8, !tbaa !3
  %v1274 = getelementptr i8, ptr %v1273, i64 8
  store ptr %v1255, ptr %v1274, align 8, !tbaa !3
  %v1275 = getelementptr i8, ptr %v1273, i64 16
  store ptr %v1259, ptr %v1275, align 8, !tbaa !3
  %v1276 = getelementptr i8, ptr %v1273, i64 24
  store ptr %arg, ptr %v1276, align 8, !tbaa !3
  %v1295 = call ptr @mlf_env_new(i64 4)
  %v1296 = getelementptr i8, ptr %v1295, i64 8
  store ptr %v1253, ptr %v1296, align 8, !tbaa !3
  %v1297 = getelementptr i8, ptr %v1295, i64 16
  store ptr %v1255, ptr %v1297, align 8, !tbaa !3
  %v1298 = getelementptr i8, ptr %v1295, i64 24
  store ptr %v1257, ptr %v1298, align 8, !tbaa !3
  %v1299 = getelementptr i8, ptr %v1295, i64 32
  store ptr %v1259, ptr %v1299, align 8, !tbaa !3
  %v1300 = call ptr @mlf_closure(ptr @mlf.code.1277, ptr %v1295)
  %v1301 = call ptr @mlf_prim2(i64 1, ptr %v1271, ptr %v1300)
  ret ptr %v1301
}

define private ptr @mlf.worker.5(ptr %a0, ptr %a1, ptr %a2, ptr %a3) {
entry:
  %v1232 = call ptr @mlf_prim2(i64 10, ptr %a3, ptr %a2)
  %v1233 = icmp eq ptr %v1232, inttoptr (i64 6 to ptr)
  br i1 %v1233, label %yes.1234, label %no.1235
yes.1234:
  %v1237 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.1236
no.1235:
  %v1246 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1238, i64 2)
  %v1247 = getelementptr i8, ptr %v1246, i64 16
  %v1248 = load ptr, ptr %v1247, align 8, !tbaa !3
  %v1249 = getelementptr i8, ptr %v1248, i64 8
  store ptr %a0, ptr %v1249, align 8, !tbaa !3
  %v1250 = getelementptr i8, ptr %v1248, i64 16
  store ptr %a3, ptr %v1250, align 8, !tbaa !3
  %v1302 = call ptr @mlf_env_new(i64 4)
  %v1303 = getelementptr i8, ptr %v1302, i64 8
  store ptr %a0, ptr %v1303, align 8, !tbaa !3
  %v1304 = getelementptr i8, ptr %v1302, i64 16
  store ptr %a1, ptr %v1304, align 8, !tbaa !3
  %v1305 = getelementptr i8, ptr %v1302, i64 24
  store ptr %a2, ptr %v1305, align 8, !tbaa !3
  %v1306 = getelementptr i8, ptr %v1302, i64 32
  store ptr %a3, ptr %v1306, align 8, !tbaa !3
  %v1307 = call ptr @mlf_closure(ptr @mlf.code.1251, ptr %v1302)
  %v1308 = call ptr @mlf_prim2(i64 1, ptr %v1246, ptr %v1307)
  br label %join.1236
join.1236:
  %v1309 = phi ptr [ %v1237, %yes.1234 ], [ %v1308, %no.1235 ]
  ret ptr %v1309
}

define private ptr @mlf.numeric.entry.1206(ptr %env, ptr %arg) {
entry:
  %v1207 = getelementptr i8, ptr %env, i64 8
  %v1208 = load ptr, ptr %v1207, align 8, !tbaa !3
  %v1209 = getelementptr i8, ptr %env, i64 16
  %v1210 = load ptr, ptr %v1209, align 8, !tbaa !3
  %v1211 = getelementptr i8, ptr %env, i64 24
  %v1212 = load ptr, ptr %v1211, align 8, !tbaa !3
  %v1213 = getelementptr i8, ptr %env, i64 32
  %v1214 = load ptr, ptr %v1213, align 8, !tbaa !3
  %v1215 = call ptr @mlf_peek(ptr %v1208)
  %v1216 = call ptr @mlf_peek(ptr %v1210)
  %v1217 = call ptr @mlf_peek(ptr %v1212)
  %v1218 = call ptr @mlf_peek(ptr %v1214)
  %v1219 = icmp ne ptr %v1215, null
  %v1220 = icmp ne ptr %v1216, null
  %v1221 = icmp ne ptr %v1217, null
  %v1222 = icmp ne ptr %v1218, null
  %v1223 = and i1 true, %v1219
  %v1224 = and i1 %v1223, %v1220
  %v1225 = and i1 %v1224, %v1221
  %v1226 = and i1 %v1225, %v1222
  br i1 %v1226, label %yes.1227, label %no.1228
yes.1227:
  %v1230 = call ptr @mlf.numeric.5(ptr %v1215, ptr %v1216, ptr %v1217, ptr %v1218)
  %v1231 = call ptr @mlf_prim1(i64 0, ptr %v1230)
  br label %join.1229
no.1228:
  %v1310 = call ptr @mlf.force(ptr %v1212)
  %v1311 = call ptr @mlf.force(ptr %v1214)
  %v1312 = call ptr @mlf.worker.5(ptr %v1208, ptr %v1210, ptr %v1310, ptr %v1311)
  br label %join.1229
join.1229:
  %v1313 = phi ptr [ %v1231, %yes.1227 ], [ %v1312, %no.1228 ]
  ret ptr %v1313
}

define private ptr @mlf.code.1196(ptr %env, ptr %arg) {
entry:
  %v1197 = getelementptr i8, ptr %env, i64 8
  %v1198 = load ptr, ptr %v1197, align 8, !tbaa !3
  %v1199 = getelementptr i8, ptr %env, i64 16
  %v1200 = load ptr, ptr %v1199, align 8, !tbaa !3
  %v1201 = getelementptr i8, ptr %env, i64 24
  %v1202 = load ptr, ptr %v1201, align 8, !tbaa !3
  %v1203 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1203, align 8, !tbaa !3
  %v1204 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1204, align 8, !tbaa !3
  %v1205 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v1205, align 8, !tbaa !3
  %v1314 = call ptr @mlf.force(ptr %v1202)
  %v1315 = call ptr @mlf_env_new(i64 4)
  %v1316 = getelementptr i8, ptr %v1315, i64 8
  store ptr %v1198, ptr %v1316, align 8, !tbaa !3
  %v1317 = getelementptr i8, ptr %v1315, i64 16
  store ptr %v1200, ptr %v1317, align 8, !tbaa !3
  %v1318 = getelementptr i8, ptr %v1315, i64 24
  store ptr %v1314, ptr %v1318, align 8, !tbaa !3
  %v1319 = getelementptr i8, ptr %v1315, i64 32
  store ptr inttoptr (i64 1 to ptr), ptr %v1319, align 8, !tbaa !3
  %v1320 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1206, ptr %v1315)
  ret ptr %v1320
}

define private ptr @mlf.code.1362(ptr %env, ptr %arg) {
entry:
  %v1363 = getelementptr i8, ptr %env, i64 8
  %v1364 = load ptr, ptr %v1363, align 8, !tbaa !3
  %v1365 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1365, align 8, !tbaa !3
  %v1366 = call ptr @mlf_prim2(i64 28, ptr %v1364, ptr inttoptr (i64 1 to ptr))
  ret ptr %v1366
}

define private ptr @mlf.code.1416(ptr %env, ptr %arg) {
entry:
  %v1417 = getelementptr i8, ptr %env, i64 8
  %v1418 = load ptr, ptr %v1417, align 8, !tbaa !3
  %v1419 = getelementptr i8, ptr %env, i64 16
  %v1420 = load ptr, ptr %v1419, align 8, !tbaa !3
  %v1421 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1421, align 8, !tbaa !3
  %v1422 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1422, align 8, !tbaa !3
  %v1423 = call ptr @mlf_prim2(i64 28, ptr %v1418, ptr %v1420)
  ret ptr %v1423
}

define private ptr @mlf.code.1436(ptr %env, ptr %arg) {
entry:
  %v1437 = getelementptr i8, ptr %env, i64 8
  %v1438 = load ptr, ptr %v1437, align 8, !tbaa !3
  %v1439 = getelementptr i8, ptr %env, i64 16
  %v1440 = load ptr, ptr %v1439, align 8, !tbaa !3
  %v1441 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1441, align 8, !tbaa !3
  %v1442 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1442, align 8, !tbaa !3
  %v1443 = call ptr @mlf_prim2(i64 28, ptr %v1438, ptr %v1440)
  ret ptr %v1443
}

define private ptr @mlf.code.1458(ptr %env, ptr %arg) {
entry:
  %v1459 = getelementptr i8, ptr %env, i64 8
  %v1460 = load ptr, ptr %v1459, align 8, !tbaa !3
  %v1461 = getelementptr i8, ptr %env, i64 16
  %v1462 = load ptr, ptr %v1461, align 8, !tbaa !3
  %v1463 = getelementptr i8, ptr %env, i64 24
  %v1464 = load ptr, ptr %v1463, align 8, !tbaa !3
  %v1465 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1465, align 8, !tbaa !3
  %v1466 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1466, align 8, !tbaa !3
  %v1467 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v1467, align 8, !tbaa !3
  %v1468 = call ptr @mlf_prim3(i64 29, ptr %v1460, ptr %v1462, ptr %v1464)
  ret ptr %v1468
}

define private ptr @mlf.code.1484(ptr %env, ptr %arg) {
entry:
  %v1485 = getelementptr i8, ptr %env, i64 8
  %v1486 = load ptr, ptr %v1485, align 8, !tbaa !3
  %v1487 = getelementptr i8, ptr %env, i64 16
  %v1488 = load ptr, ptr %v1487, align 8, !tbaa !3
  %v1489 = getelementptr i8, ptr %env, i64 24
  %v1490 = load ptr, ptr %v1489, align 8, !tbaa !3
  %v1491 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1491, align 8, !tbaa !3
  %v1492 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1492, align 8, !tbaa !3
  %v1493 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v1493, align 8, !tbaa !3
  %v1494 = call ptr @mlf_prim3(i64 29, ptr %v1486, ptr %v1488, ptr %v1490)
  ret ptr %v1494
}

define private ptr @mlf.code.1501(ptr %env, ptr %arg) {
entry:
  %v1502 = getelementptr i8, ptr %env, i64 8
  %v1503 = load ptr, ptr %v1502, align 8, !tbaa !3
  %v1504 = getelementptr i8, ptr %env, i64 16
  %v1505 = load ptr, ptr %v1504, align 8, !tbaa !3
  %v1506 = getelementptr i8, ptr %env, i64 24
  %v1507 = load ptr, ptr %v1506, align 8, !tbaa !3
  %v1508 = call ptr @mlf.force(ptr %v1505)
  %v1509 = call ptr @mlf_prim2(i64 8, ptr %v1508, ptr inttoptr (i64 3 to ptr))
  %v1510 = call ptr @mlf.force(ptr %v1507)
  %v1511 = call ptr @mlf_prim2(i64 9, ptr %v1510, ptr inttoptr (i64 3 to ptr))
  %v1512 = call ptr @mlf_env_new(i64 3)
  %v1513 = getelementptr i8, ptr %v1512, i64 8
  store ptr %v1503, ptr %v1513, align 8, !tbaa !3
  %v1514 = getelementptr i8, ptr %v1512, i64 16
  store ptr %v1509, ptr %v1514, align 8, !tbaa !3
  %v1515 = getelementptr i8, ptr %v1512, i64 24
  store ptr %v1511, ptr %v1515, align 8, !tbaa !3
  %v1516 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1390, ptr %v1512)
  ret ptr %v1516
}

define private ptr @mlf.code.1475(ptr %env, ptr %arg) {
entry:
  %v1476 = getelementptr i8, ptr %env, i64 8
  %v1477 = load ptr, ptr %v1476, align 8, !tbaa !3
  %v1478 = getelementptr i8, ptr %env, i64 16
  %v1479 = load ptr, ptr %v1478, align 8, !tbaa !3
  %v1480 = getelementptr i8, ptr %env, i64 24
  %v1481 = load ptr, ptr %v1480, align 8, !tbaa !3
  %v1482 = getelementptr i8, ptr %env, i64 32
  %v1483 = load ptr, ptr %v1482, align 8, !tbaa !3
  %v1495 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1484, i64 3)
  %v1496 = getelementptr i8, ptr %v1495, i64 16
  %v1497 = load ptr, ptr %v1496, align 8, !tbaa !3
  %v1498 = getelementptr i8, ptr %v1497, i64 8
  store ptr %v1477, ptr %v1498, align 8, !tbaa !3
  %v1499 = getelementptr i8, ptr %v1497, i64 16
  store ptr %v1481, ptr %v1499, align 8, !tbaa !3
  %v1500 = getelementptr i8, ptr %v1497, i64 24
  store ptr %v1483, ptr %v1500, align 8, !tbaa !3
  %v1517 = call ptr @mlf_env_new(i64 3)
  %v1518 = getelementptr i8, ptr %v1517, i64 8
  store ptr %v1477, ptr %v1518, align 8, !tbaa !3
  %v1519 = getelementptr i8, ptr %v1517, i64 16
  store ptr %v1479, ptr %v1519, align 8, !tbaa !3
  %v1520 = getelementptr i8, ptr %v1517, i64 24
  store ptr %v1481, ptr %v1520, align 8, !tbaa !3
  %v1521 = call ptr @mlf_closure(ptr @mlf.code.1501, ptr %v1517)
  %v1522 = call ptr @mlf_prim2(i64 1, ptr %v1495, ptr %v1521)
  ret ptr %v1522
}

define private ptr @mlf.code.1449(ptr %env, ptr %arg) {
entry:
  %v1450 = getelementptr i8, ptr %env, i64 8
  %v1451 = load ptr, ptr %v1450, align 8, !tbaa !3
  %v1452 = getelementptr i8, ptr %env, i64 16
  %v1453 = load ptr, ptr %v1452, align 8, !tbaa !3
  %v1454 = getelementptr i8, ptr %env, i64 24
  %v1455 = load ptr, ptr %v1454, align 8, !tbaa !3
  %v1456 = getelementptr i8, ptr %env, i64 32
  %v1457 = load ptr, ptr %v1456, align 8, !tbaa !3
  %v1469 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1458, i64 3)
  %v1470 = getelementptr i8, ptr %v1469, i64 16
  %v1471 = load ptr, ptr %v1470, align 8, !tbaa !3
  %v1472 = getelementptr i8, ptr %v1471, i64 8
  store ptr %v1451, ptr %v1472, align 8, !tbaa !3
  %v1473 = getelementptr i8, ptr %v1471, i64 16
  store ptr %v1453, ptr %v1473, align 8, !tbaa !3
  %v1474 = getelementptr i8, ptr %v1471, i64 24
  store ptr %arg, ptr %v1474, align 8, !tbaa !3
  %v1523 = call ptr @mlf_env_new(i64 4)
  %v1524 = getelementptr i8, ptr %v1523, i64 8
  store ptr %v1451, ptr %v1524, align 8, !tbaa !3
  %v1525 = getelementptr i8, ptr %v1523, i64 16
  store ptr %v1453, ptr %v1525, align 8, !tbaa !3
  %v1526 = getelementptr i8, ptr %v1523, i64 24
  store ptr %v1455, ptr %v1526, align 8, !tbaa !3
  %v1527 = getelementptr i8, ptr %v1523, i64 32
  store ptr %v1457, ptr %v1527, align 8, !tbaa !3
  %v1528 = call ptr @mlf_closure(ptr @mlf.code.1475, ptr %v1523)
  %v1529 = call ptr @mlf_prim2(i64 1, ptr %v1469, ptr %v1528)
  ret ptr %v1529
}

define private ptr @mlf.code.1429(ptr %env, ptr %arg) {
entry:
  %v1430 = getelementptr i8, ptr %env, i64 8
  %v1431 = load ptr, ptr %v1430, align 8, !tbaa !3
  %v1432 = getelementptr i8, ptr %env, i64 16
  %v1433 = load ptr, ptr %v1432, align 8, !tbaa !3
  %v1434 = getelementptr i8, ptr %env, i64 24
  %v1435 = load ptr, ptr %v1434, align 8, !tbaa !3
  %v1444 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1436, i64 2)
  %v1445 = getelementptr i8, ptr %v1444, i64 16
  %v1446 = load ptr, ptr %v1445, align 8, !tbaa !3
  %v1447 = getelementptr i8, ptr %v1446, i64 8
  store ptr %v1431, ptr %v1447, align 8, !tbaa !3
  %v1448 = getelementptr i8, ptr %v1446, i64 16
  store ptr %v1435, ptr %v1448, align 8, !tbaa !3
  %v1530 = call ptr @mlf_env_new(i64 4)
  %v1531 = getelementptr i8, ptr %v1530, i64 8
  store ptr %v1431, ptr %v1531, align 8, !tbaa !3
  %v1532 = getelementptr i8, ptr %v1530, i64 16
  store ptr %v1433, ptr %v1532, align 8, !tbaa !3
  %v1533 = getelementptr i8, ptr %v1530, i64 24
  store ptr %v1435, ptr %v1533, align 8, !tbaa !3
  %v1534 = getelementptr i8, ptr %v1530, i64 32
  store ptr %arg, ptr %v1534, align 8, !tbaa !3
  %v1535 = call ptr @mlf_closure(ptr @mlf.code.1449, ptr %v1530)
  %v1536 = call ptr @mlf_prim2(i64 1, ptr %v1444, ptr %v1535)
  ret ptr %v1536
}

define private ptr @mlf.worker.12(ptr %a0, ptr %a1, ptr %a2) {
entry:
  %v1411 = call ptr @mlf_prim2(i64 11, ptr %a1, ptr %a2)
  %v1412 = icmp eq ptr %v1411, inttoptr (i64 6 to ptr)
  br i1 %v1412, label %yes.1413, label %no.1414
yes.1413:
  %v1424 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1416, i64 2)
  %v1425 = getelementptr i8, ptr %v1424, i64 16
  %v1426 = load ptr, ptr %v1425, align 8, !tbaa !3
  %v1427 = getelementptr i8, ptr %v1426, i64 8
  store ptr %a0, ptr %v1427, align 8, !tbaa !3
  %v1428 = getelementptr i8, ptr %v1426, i64 16
  store ptr %a1, ptr %v1428, align 8, !tbaa !3
  %v1537 = call ptr @mlf_env_new(i64 3)
  %v1538 = getelementptr i8, ptr %v1537, i64 8
  store ptr %a0, ptr %v1538, align 8, !tbaa !3
  %v1539 = getelementptr i8, ptr %v1537, i64 16
  store ptr %a1, ptr %v1539, align 8, !tbaa !3
  %v1540 = getelementptr i8, ptr %v1537, i64 24
  store ptr %a2, ptr %v1540, align 8, !tbaa !3
  %v1541 = call ptr @mlf_closure(ptr @mlf.code.1429, ptr %v1537)
  %v1542 = call ptr @mlf_prim2(i64 1, ptr %v1424, ptr %v1541)
  br label %join.1415
no.1414:
  %v1543 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.1415
join.1415:
  %v1544 = phi ptr [ %v1542, %yes.1413 ], [ %v1543, %no.1414 ]
  ret ptr %v1544
}

define private ptr @mlf.numeric.entry.1390(ptr %env, ptr %arg) {
entry:
  %v1391 = getelementptr i8, ptr %env, i64 8
  %v1392 = load ptr, ptr %v1391, align 8, !tbaa !3
  %v1393 = getelementptr i8, ptr %env, i64 16
  %v1394 = load ptr, ptr %v1393, align 8, !tbaa !3
  %v1395 = getelementptr i8, ptr %env, i64 24
  %v1396 = load ptr, ptr %v1395, align 8, !tbaa !3
  %v1397 = call ptr @mlf_peek(ptr %v1392)
  %v1398 = call ptr @mlf_peek(ptr %v1394)
  %v1399 = call ptr @mlf_peek(ptr %v1396)
  %v1400 = icmp ne ptr %v1397, null
  %v1401 = icmp ne ptr %v1398, null
  %v1402 = icmp ne ptr %v1399, null
  %v1403 = and i1 true, %v1400
  %v1404 = and i1 %v1403, %v1401
  %v1405 = and i1 %v1404, %v1402
  br i1 %v1405, label %yes.1406, label %no.1407
yes.1406:
  %v1409 = call ptr @mlf.numeric.12(ptr %v1397, ptr %v1398, ptr %v1399)
  %v1410 = call ptr @mlf_prim1(i64 0, ptr %v1409)
  br label %join.1408
no.1407:
  %v1545 = call ptr @mlf.force(ptr %v1394)
  %v1546 = call ptr @mlf.force(ptr %v1396)
  %v1547 = call ptr @mlf.worker.12(ptr %v1392, ptr %v1545, ptr %v1546)
  br label %join.1408
join.1408:
  %v1548 = phi ptr [ %v1410, %yes.1406 ], [ %v1547, %no.1407 ]
  ret ptr %v1548
}

define private ptr @mlf.code.1383(ptr %env, ptr %arg) {
entry:
  %v1384 = getelementptr i8, ptr %env, i64 8
  %v1385 = load ptr, ptr %v1384, align 8, !tbaa !3
  %v1386 = getelementptr i8, ptr %env, i64 16
  %v1387 = load ptr, ptr %v1386, align 8, !tbaa !3
  %v1388 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1388, align 8, !tbaa !3
  %v1389 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1389, align 8, !tbaa !3
  %v1549 = call ptr @mlf.force(ptr %v1387)
  %v1550 = call ptr @mlf_prim2(i64 9, ptr %v1549, ptr inttoptr (i64 3 to ptr))
  %v1551 = call ptr @mlf_env_new(i64 3)
  %v1552 = getelementptr i8, ptr %v1551, i64 8
  store ptr %v1385, ptr %v1552, align 8, !tbaa !3
  %v1553 = getelementptr i8, ptr %v1551, i64 16
  store ptr inttoptr (i64 1 to ptr), ptr %v1553, align 8, !tbaa !3
  %v1554 = getelementptr i8, ptr %v1551, i64 24
  store ptr %v1550, ptr %v1554, align 8, !tbaa !3
  %v1555 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1390, ptr %v1551)
  ret ptr %v1555
}

define private ptr @mlf.code.1566(ptr %env, ptr %arg) {
entry:
  %v1567 = getelementptr i8, ptr %env, i64 8
  %v1568 = load ptr, ptr %v1567, align 8, !tbaa !3
  %v1569 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1569, align 8, !tbaa !3
  %v1570 = call ptr @mlf.force(ptr %v1568)
  %v1571 = call ptr @mlf_prim2(i64 8, ptr %v1570, ptr inttoptr (i64 3 to ptr))
  ret ptr %v1571
}

define private ptr @mlf.code.1561(ptr %env, ptr %arg) {
entry:
  %v1562 = getelementptr i8, ptr %env, i64 8
  %v1563 = load ptr, ptr %v1562, align 8, !tbaa !3
  %v1564 = getelementptr i8, ptr %env, i64 16
  %v1565 = load ptr, ptr %v1564, align 8, !tbaa !3
  %v1572 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1566, i64 1)
  %v1573 = getelementptr i8, ptr %v1572, i64 16
  %v1574 = load ptr, ptr %v1573, align 8, !tbaa !3
  %v1575 = getelementptr i8, ptr %v1574, i64 8
  store ptr %v1565, ptr %v1575, align 8, !tbaa !3
  %v1576 = call ptr @mlf_env_new(i64 2)
  %v1577 = getelementptr i8, ptr %v1576, i64 8
  store ptr %v1563, ptr %v1577, align 8, !tbaa !3
  %v1578 = getelementptr i8, ptr %v1576, i64 16
  store ptr %v1572, ptr %v1578, align 8, !tbaa !3
  %v1579 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1346, ptr %v1576)
  ret ptr %v1579
}

define private ptr @mlf.code.1371(ptr %env, ptr %arg) {
entry:
  %v1372 = getelementptr i8, ptr %env, i64 8
  %v1373 = load ptr, ptr %v1372, align 8, !tbaa !3
  %v1374 = getelementptr i8, ptr %env, i64 16
  %v1375 = load ptr, ptr %v1374, align 8, !tbaa !3
  %v1376 = call ptr @mlf.force(ptr %arg)
  %v1377 = call ptr @mlf_prim2(i64 10, ptr %v1376, ptr inttoptr (i64 3 to ptr))
  %v1378 = icmp eq ptr %v1377, inttoptr (i64 6 to ptr)
  br i1 %v1378, label %yes.1379, label %no.1380
yes.1379:
  %v1382 = call ptr @mlf_prim1(i64 0, ptr %v1375)
  br label %join.1381
no.1380:
  %v1556 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1383, i64 2)
  %v1557 = getelementptr i8, ptr %v1556, i64 16
  %v1558 = load ptr, ptr %v1557, align 8, !tbaa !3
  %v1559 = getelementptr i8, ptr %v1558, i64 8
  store ptr %v1373, ptr %v1559, align 8, !tbaa !3
  %v1560 = getelementptr i8, ptr %v1558, i64 16
  store ptr %v1376, ptr %v1560, align 8, !tbaa !3
  %v1580 = call ptr @mlf_env_new(i64 2)
  %v1581 = getelementptr i8, ptr %v1580, i64 8
  store ptr %v1373, ptr %v1581, align 8, !tbaa !3
  %v1582 = getelementptr i8, ptr %v1580, i64 16
  store ptr %v1375, ptr %v1582, align 8, !tbaa !3
  %v1583 = call ptr @mlf_closure(ptr @mlf.code.1561, ptr %v1580)
  %v1584 = call ptr @mlf_prim2(i64 1, ptr %v1556, ptr %v1583)
  br label %join.1381
join.1381:
  %v1585 = phi ptr [ %v1382, %yes.1379 ], [ %v1584, %no.1380 ]
  ret ptr %v1585
}

define private ptr @mlf.worker.20(ptr %a0, ptr %a1) {
entry:
  %v1367 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1362, i64 1)
  %v1368 = getelementptr i8, ptr %v1367, i64 16
  %v1369 = load ptr, ptr %v1368, align 8, !tbaa !3
  %v1370 = getelementptr i8, ptr %v1369, i64 8
  store ptr %a0, ptr %v1370, align 8, !tbaa !3
  %v1586 = call ptr @mlf_env_new(i64 2)
  %v1587 = getelementptr i8, ptr %v1586, i64 8
  store ptr %a0, ptr %v1587, align 8, !tbaa !3
  %v1588 = getelementptr i8, ptr %v1586, i64 16
  store ptr %a1, ptr %v1588, align 8, !tbaa !3
  %v1589 = call ptr @mlf_closure(ptr @mlf.code.1371, ptr %v1586)
  %v1590 = call ptr @mlf_prim2(i64 1, ptr %v1367, ptr %v1589)
  ret ptr %v1590
}

define private ptr @mlf.numeric.entry.1346(ptr %env, ptr %arg) {
entry:
  %v1347 = getelementptr i8, ptr %env, i64 8
  %v1348 = load ptr, ptr %v1347, align 8, !tbaa !3
  %v1349 = getelementptr i8, ptr %env, i64 16
  %v1350 = load ptr, ptr %v1349, align 8, !tbaa !3
  %v1351 = call ptr @mlf_peek(ptr %v1348)
  %v1352 = call ptr @mlf_peek(ptr %v1350)
  %v1353 = icmp ne ptr %v1351, null
  %v1354 = icmp ne ptr %v1352, null
  %v1355 = and i1 true, %v1353
  %v1356 = and i1 %v1355, %v1354
  br i1 %v1356, label %yes.1357, label %no.1358
yes.1357:
  %v1360 = call ptr @mlf.numeric.20(ptr %v1351, ptr %v1352)
  %v1361 = call ptr @mlf_prim1(i64 0, ptr %v1360)
  br label %join.1359
no.1358:
  %v1591 = call ptr @mlf.worker.20(ptr %v1348, ptr %v1350)
  br label %join.1359
join.1359:
  %v1592 = phi ptr [ %v1361, %yes.1357 ], [ %v1591, %no.1358 ]
  ret ptr %v1592
}

define private ptr @mlf.code.1342(ptr %env, ptr %arg) {
entry:
  %v1343 = getelementptr i8, ptr %env, i64 8
  %v1344 = load ptr, ptr %v1343, align 8, !tbaa !3
  %v1345 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1345, align 8, !tbaa !3
  %v1593 = call ptr @mlf_env_new(i64 2)
  %v1594 = getelementptr i8, ptr %v1593, i64 8
  store ptr %v1344, ptr %v1594, align 8, !tbaa !3
  %v1595 = getelementptr i8, ptr %v1593, i64 16
  store ptr inttoptr (i64 1 to ptr), ptr %v1595, align 8, !tbaa !3
  %v1596 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1346, ptr %v1593)
  ret ptr %v1596
}

define private ptr @mlf.code.1630(ptr %env, ptr %arg) {
entry:
  %v1631 = getelementptr i8, ptr %env, i64 8
  %v1632 = load ptr, ptr %v1631, align 8, !tbaa !3
  %v1633 = getelementptr i8, ptr %env, i64 16
  %v1634 = load ptr, ptr %v1633, align 8, !tbaa !3
  %v1635 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1635, align 8, !tbaa !3
  %v1636 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1636, align 8, !tbaa !3
  %v1637 = call ptr @mlf.force(ptr %v1632)
  %v1638 = call ptr @mlf.force(ptr %v1634)
  %v1639 = call ptr @mlf_prim2(i64 11, ptr %v1637, ptr %v1638)
  %v1640 = icmp eq ptr %v1639, inttoptr (i64 6 to ptr)
  br i1 %v1640, label %yes.1641, label %no.1642
yes.1641:
  br label %join.1643
no.1642:
  br label %join.1643
join.1643:
  %v1644 = phi ptr [ %v1638, %yes.1641 ], [ %v1637, %no.1642 ]
  ret ptr %v1644
}

define private ptr @mlf.code.1703(ptr %env, ptr %arg) {
entry:
  %v1704 = getelementptr i8, ptr %env, i64 8
  %v1705 = load ptr, ptr %v1704, align 8, !tbaa !3
  %v1706 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1706, align 8, !tbaa !3
  %v1707 = call ptr @mlf_prim2(i64 28, ptr %v1705, ptr inttoptr (i64 1 to ptr))
  ret ptr %v1707
}

define private ptr @mlf.code.1770(ptr %env, ptr %arg) {
entry:
  %v1771 = getelementptr i8, ptr %env, i64 8
  %v1772 = load ptr, ptr %v1771, align 8, !tbaa !3
  %v1773 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1773, align 8, !tbaa !3
  %v1774 = call ptr @mlf.force(ptr %v1772)
  %v1775 = call ptr @mlf_prim2(i64 8, ptr %v1774, ptr inttoptr (i64 3 to ptr))
  ret ptr %v1775
}

define private ptr @mlf.code.1763(ptr %env, ptr %arg) {
entry:
  %v1764 = getelementptr i8, ptr %env, i64 8
  %v1765 = load ptr, ptr %v1764, align 8, !tbaa !3
  %v1766 = getelementptr i8, ptr %env, i64 16
  %v1767 = load ptr, ptr %v1766, align 8, !tbaa !3
  %v1768 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1768, align 8, !tbaa !3
  %v1769 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1769, align 8, !tbaa !3
  %v1776 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1770, i64 1)
  %v1777 = getelementptr i8, ptr %v1776, i64 16
  %v1778 = load ptr, ptr %v1777, align 8, !tbaa !3
  %v1779 = getelementptr i8, ptr %v1778, i64 8
  store ptr %v1767, ptr %v1779, align 8, !tbaa !3
  %v1780 = call ptr @mlf_prim2(i64 28, ptr %v1765, ptr %v1776)
  ret ptr %v1780
}

define private ptr @mlf.code.1795(ptr %env, ptr %arg) {
entry:
  %v1796 = getelementptr i8, ptr %env, i64 8
  %v1797 = load ptr, ptr %v1796, align 8, !tbaa !3
  %v1798 = getelementptr i8, ptr %env, i64 16
  %v1799 = load ptr, ptr %v1798, align 8, !tbaa !3
  %v1800 = getelementptr i8, ptr %env, i64 24
  %v1801 = load ptr, ptr %v1800, align 8, !tbaa !3
  %v1802 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1802, align 8, !tbaa !3
  %v1803 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1803, align 8, !tbaa !3
  %v1804 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v1804, align 8, !tbaa !3
  %v1805 = call ptr @mlf_prim3(i64 29, ptr %v1797, ptr %v1799, ptr %v1801)
  ret ptr %v1805
}

define private ptr @mlf.code.1812(ptr %env, ptr %arg) {
entry:
  %v1813 = getelementptr i8, ptr %env, i64 8
  %v1814 = load ptr, ptr %v1813, align 8, !tbaa !3
  %v1815 = getelementptr i8, ptr %env, i64 16
  %v1816 = load ptr, ptr %v1815, align 8, !tbaa !3
  %v1817 = getelementptr i8, ptr %env, i64 24
  %v1818 = load ptr, ptr %v1817, align 8, !tbaa !3
  %v1819 = getelementptr i8, ptr %env, i64 32
  %v1820 = load ptr, ptr %v1819, align 8, !tbaa !3
  %v1821 = call ptr @mlf.force(ptr %v1816)
  %v1822 = call ptr @mlf.force(ptr %v1820)
  %v1823 = call ptr @mlf_prim2(i64 8, ptr %v1822, ptr inttoptr (i64 3 to ptr))
  %v1824 = call ptr @mlf_env_new(i64 4)
  %v1825 = getelementptr i8, ptr %v1824, i64 8
  store ptr %v1814, ptr %v1825, align 8, !tbaa !3
  %v1826 = getelementptr i8, ptr %v1824, i64 16
  store ptr %v1821, ptr %v1826, align 8, !tbaa !3
  %v1827 = getelementptr i8, ptr %v1824, i64 24
  store ptr %v1818, ptr %v1827, align 8, !tbaa !3
  %v1828 = getelementptr i8, ptr %v1824, i64 32
  store ptr %v1823, ptr %v1828, align 8, !tbaa !3
  %v1829 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1731, ptr %v1824)
  ret ptr %v1829
}

define private ptr @mlf.code.1786(ptr %env, ptr %arg) {
entry:
  %v1787 = getelementptr i8, ptr %env, i64 8
  %v1788 = load ptr, ptr %v1787, align 8, !tbaa !3
  %v1789 = getelementptr i8, ptr %env, i64 16
  %v1790 = load ptr, ptr %v1789, align 8, !tbaa !3
  %v1791 = getelementptr i8, ptr %env, i64 24
  %v1792 = load ptr, ptr %v1791, align 8, !tbaa !3
  %v1793 = getelementptr i8, ptr %env, i64 32
  %v1794 = load ptr, ptr %v1793, align 8, !tbaa !3
  %v1806 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1795, i64 3)
  %v1807 = getelementptr i8, ptr %v1806, i64 16
  %v1808 = load ptr, ptr %v1807, align 8, !tbaa !3
  %v1809 = getelementptr i8, ptr %v1808, i64 8
  store ptr %v1788, ptr %v1809, align 8, !tbaa !3
  %v1810 = getelementptr i8, ptr %v1808, i64 16
  store ptr %v1794, ptr %v1810, align 8, !tbaa !3
  %v1811 = getelementptr i8, ptr %v1808, i64 24
  store ptr %arg, ptr %v1811, align 8, !tbaa !3
  %v1830 = call ptr @mlf_env_new(i64 4)
  %v1831 = getelementptr i8, ptr %v1830, i64 8
  store ptr %v1788, ptr %v1831, align 8, !tbaa !3
  %v1832 = getelementptr i8, ptr %v1830, i64 16
  store ptr %v1790, ptr %v1832, align 8, !tbaa !3
  %v1833 = getelementptr i8, ptr %v1830, i64 24
  store ptr %v1792, ptr %v1833, align 8, !tbaa !3
  %v1834 = getelementptr i8, ptr %v1830, i64 32
  store ptr %v1794, ptr %v1834, align 8, !tbaa !3
  %v1835 = call ptr @mlf_closure(ptr @mlf.code.1812, ptr %v1830)
  %v1836 = call ptr @mlf_prim2(i64 1, ptr %v1806, ptr %v1835)
  ret ptr %v1836
}

define private ptr @mlf.worker.25(ptr %a0, ptr %a1, ptr %a2, ptr %a3) {
entry:
  %v1757 = call ptr @mlf_prim2(i64 10, ptr %a3, ptr %a1)
  %v1758 = icmp eq ptr %v1757, inttoptr (i64 6 to ptr)
  br i1 %v1758, label %yes.1759, label %no.1760
yes.1759:
  %v1762 = call ptr @mlf_prim3(i64 29, ptr %a0, ptr %a1, ptr %a2)
  br label %join.1761
no.1760:
  %v1781 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1763, i64 2)
  %v1782 = getelementptr i8, ptr %v1781, i64 16
  %v1783 = load ptr, ptr %v1782, align 8, !tbaa !3
  %v1784 = getelementptr i8, ptr %v1783, i64 8
  store ptr %a0, ptr %v1784, align 8, !tbaa !3
  %v1785 = getelementptr i8, ptr %v1783, i64 16
  store ptr %a3, ptr %v1785, align 8, !tbaa !3
  %v1837 = call ptr @mlf_env_new(i64 4)
  %v1838 = getelementptr i8, ptr %v1837, i64 8
  store ptr %a0, ptr %v1838, align 8, !tbaa !3
  %v1839 = getelementptr i8, ptr %v1837, i64 16
  store ptr %a1, ptr %v1839, align 8, !tbaa !3
  %v1840 = getelementptr i8, ptr %v1837, i64 24
  store ptr %a2, ptr %v1840, align 8, !tbaa !3
  %v1841 = getelementptr i8, ptr %v1837, i64 32
  store ptr %a3, ptr %v1841, align 8, !tbaa !3
  %v1842 = call ptr @mlf_closure(ptr @mlf.code.1786, ptr %v1837)
  %v1843 = call ptr @mlf_prim2(i64 1, ptr %v1781, ptr %v1842)
  br label %join.1761
join.1761:
  %v1844 = phi ptr [ %v1762, %yes.1759 ], [ %v1843, %no.1760 ]
  ret ptr %v1844
}

define private ptr @mlf.numeric.entry.1731(ptr %env, ptr %arg) {
entry:
  %v1732 = getelementptr i8, ptr %env, i64 8
  %v1733 = load ptr, ptr %v1732, align 8, !tbaa !3
  %v1734 = getelementptr i8, ptr %env, i64 16
  %v1735 = load ptr, ptr %v1734, align 8, !tbaa !3
  %v1736 = getelementptr i8, ptr %env, i64 24
  %v1737 = load ptr, ptr %v1736, align 8, !tbaa !3
  %v1738 = getelementptr i8, ptr %env, i64 32
  %v1739 = load ptr, ptr %v1738, align 8, !tbaa !3
  %v1740 = call ptr @mlf_peek(ptr %v1733)
  %v1741 = call ptr @mlf_peek(ptr %v1735)
  %v1742 = call ptr @mlf_peek(ptr %v1737)
  %v1743 = call ptr @mlf_peek(ptr %v1739)
  %v1744 = icmp ne ptr %v1740, null
  %v1745 = icmp ne ptr %v1741, null
  %v1746 = icmp ne ptr %v1742, null
  %v1747 = icmp ne ptr %v1743, null
  %v1748 = and i1 true, %v1744
  %v1749 = and i1 %v1748, %v1745
  %v1750 = and i1 %v1749, %v1746
  %v1751 = and i1 %v1750, %v1747
  br i1 %v1751, label %yes.1752, label %no.1753
yes.1752:
  %v1755 = call ptr @mlf.numeric.25(ptr %v1740, ptr %v1741, ptr %v1742, ptr %v1743)
  %v1756 = call ptr @mlf_prim1(i64 0, ptr %v1755)
  br label %join.1754
no.1753:
  %v1845 = call ptr @mlf.force(ptr %v1735)
  %v1846 = call ptr @mlf.force(ptr %v1739)
  %v1847 = call ptr @mlf.worker.25(ptr %v1733, ptr %v1845, ptr %v1737, ptr %v1846)
  br label %join.1754
join.1754:
  %v1848 = phi ptr [ %v1756, %yes.1752 ], [ %v1847, %no.1753 ]
  ret ptr %v1848
}

define private ptr @mlf.code.1721(ptr %env, ptr %arg) {
entry:
  %v1722 = getelementptr i8, ptr %env, i64 8
  %v1723 = load ptr, ptr %v1722, align 8, !tbaa !3
  %v1724 = getelementptr i8, ptr %env, i64 16
  %v1725 = load ptr, ptr %v1724, align 8, !tbaa !3
  %v1726 = getelementptr i8, ptr %env, i64 24
  %v1727 = load ptr, ptr %v1726, align 8, !tbaa !3
  %v1728 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1728, align 8, !tbaa !3
  %v1729 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1729, align 8, !tbaa !3
  %v1730 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v1730, align 8, !tbaa !3
  %v1849 = call ptr @mlf.force(ptr %v1725)
  %v1850 = call ptr @mlf_env_new(i64 4)
  %v1851 = getelementptr i8, ptr %v1850, i64 8
  store ptr %v1723, ptr %v1851, align 8, !tbaa !3
  %v1852 = getelementptr i8, ptr %v1850, i64 16
  store ptr %v1849, ptr %v1852, align 8, !tbaa !3
  %v1853 = getelementptr i8, ptr %v1850, i64 24
  store ptr %v1727, ptr %v1853, align 8, !tbaa !3
  %v1854 = getelementptr i8, ptr %v1850, i64 32
  store ptr inttoptr (i64 1 to ptr), ptr %v1854, align 8, !tbaa !3
  %v1855 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1731, ptr %v1850)
  ret ptr %v1855
}

define private ptr @mlf.code.1871(ptr %env, ptr %arg) {
entry:
  %v1872 = getelementptr i8, ptr %env, i64 8
  %v1873 = load ptr, ptr %v1872, align 8, !tbaa !3
  %v1874 = getelementptr i8, ptr %env, i64 16
  %v1875 = load ptr, ptr %v1874, align 8, !tbaa !3
  %v1876 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1876, align 8, !tbaa !3
  %v1877 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1877, align 8, !tbaa !3
  %v1878 = call ptr @mlf_prim2(i64 28, ptr %v1873, ptr %v1875)
  ret ptr %v1878
}

define private ptr @mlf.code.1910(ptr %env, ptr %arg) {
entry:
  %v1911 = getelementptr i8, ptr %env, i64 8
  %v1912 = load ptr, ptr %v1911, align 8, !tbaa !3
  %v1913 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1913, align 8, !tbaa !3
  %v1914 = call ptr @mlf.force(ptr %v1912)
  %v1915 = call ptr @mlf_prim2(i64 8, ptr %v1914, ptr inttoptr (i64 3 to ptr))
  ret ptr %v1915
}

define private ptr @mlf.code.1900(ptr %env, ptr %arg) {
entry:
  %v1901 = getelementptr i8, ptr %env, i64 8
  %v1902 = load ptr, ptr %v1901, align 8, !tbaa !3
  %v1903 = getelementptr i8, ptr %env, i64 16
  %v1904 = load ptr, ptr %v1903, align 8, !tbaa !3
  %v1905 = getelementptr i8, ptr %env, i64 24
  %v1906 = load ptr, ptr %v1905, align 8, !tbaa !3
  %v1907 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1907, align 8, !tbaa !3
  %v1908 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1908, align 8, !tbaa !3
  %v1909 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v1909, align 8, !tbaa !3
  %v1916 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1910, i64 1)
  %v1917 = getelementptr i8, ptr %v1916, i64 16
  %v1918 = load ptr, ptr %v1917, align 8, !tbaa !3
  %v1919 = getelementptr i8, ptr %v1918, i64 8
  store ptr %v1906, ptr %v1919, align 8, !tbaa !3
  %v1920 = call ptr @mlf_prim3(i64 29, ptr %v1902, ptr %v1904, ptr %v1916)
  ret ptr %v1920
}

define private ptr @mlf.code.1927(ptr %env, ptr %arg) {
entry:
  %v1928 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 6 to ptr))
  ret ptr %v1928
}

define private ptr @mlf.code.1931(ptr %env, ptr %arg) {
entry:
  %v1932 = getelementptr i8, ptr %env, i64 8
  %v1933 = load ptr, ptr %v1932, align 8, !tbaa !3
  %v1934 = getelementptr i8, ptr %env, i64 16
  %v1935 = load ptr, ptr %v1934, align 8, !tbaa !3
  %v1936 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1936, align 8, !tbaa !3
  %v1937 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1937, align 8, !tbaa !3
  %v1938 = call ptr @mlf_prim3(i64 29, ptr %v1933, ptr %v1935, ptr inttoptr (i64 1 to ptr))
  ret ptr %v1938
}

define private ptr @mlf.code.1944(ptr %env, ptr %arg) {
entry:
  %v1945 = getelementptr i8, ptr %env, i64 8
  %v1946 = load ptr, ptr %v1945, align 8, !tbaa !3
  %v1947 = getelementptr i8, ptr %env, i64 16
  %v1948 = load ptr, ptr %v1947, align 8, !tbaa !3
  %v1949 = getelementptr i8, ptr %env, i64 24
  %v1950 = load ptr, ptr %v1949, align 8, !tbaa !3
  %v1951 = getelementptr i8, ptr %env, i64 32
  %v1952 = load ptr, ptr %v1951, align 8, !tbaa !3
  %v1953 = call ptr @mlf.force(ptr %v1950)
  %v1954 = call ptr @mlf.force(ptr %v1952)
  %v1955 = call ptr @mlf_prim2(i64 8, ptr %v1954, ptr inttoptr (i64 3 to ptr))
  %v1956 = call ptr @mlf_env_new(i64 4)
  %v1957 = getelementptr i8, ptr %v1956, i64 8
  store ptr %v1946, ptr %v1957, align 8, !tbaa !3
  %v1958 = getelementptr i8, ptr %v1956, i64 16
  store ptr %v1948, ptr %v1958, align 8, !tbaa !3
  %v1959 = getelementptr i8, ptr %v1956, i64 24
  store ptr %v1953, ptr %v1959, align 8, !tbaa !3
  %v1960 = getelementptr i8, ptr %v1956, i64 32
  store ptr %v1955, ptr %v1960, align 8, !tbaa !3
  %v1961 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1671, ptr %v1956)
  ret ptr %v1961
}

define private ptr @mlf.code.1884(ptr %env, ptr %arg) {
entry:
  %v1885 = getelementptr i8, ptr %env, i64 8
  %v1886 = load ptr, ptr %v1885, align 8, !tbaa !3
  %v1887 = getelementptr i8, ptr %env, i64 16
  %v1888 = load ptr, ptr %v1887, align 8, !tbaa !3
  %v1889 = getelementptr i8, ptr %env, i64 24
  %v1890 = load ptr, ptr %v1889, align 8, !tbaa !3
  %v1891 = getelementptr i8, ptr %env, i64 32
  %v1892 = load ptr, ptr %v1891, align 8, !tbaa !3
  %v1893 = call ptr @mlf.force(ptr %arg)
  %v1894 = call ptr @mlf.force(ptr %v1892)
  %v1895 = call ptr @mlf_prim2(i64 11, ptr %v1893, ptr %v1894)
  %v1896 = icmp eq ptr %v1895, inttoptr (i64 6 to ptr)
  br i1 %v1896, label %yes.1897, label %no.1898
yes.1897:
  %v1921 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1900, i64 3)
  %v1922 = getelementptr i8, ptr %v1921, i64 16
  %v1923 = load ptr, ptr %v1922, align 8, !tbaa !3
  %v1924 = getelementptr i8, ptr %v1923, i64 8
  store ptr %v1888, ptr %v1924, align 8, !tbaa !3
  %v1925 = getelementptr i8, ptr %v1923, i64 16
  store ptr %v1894, ptr %v1925, align 8, !tbaa !3
  %v1926 = getelementptr i8, ptr %v1923, i64 24
  store ptr %v1893, ptr %v1926, align 8, !tbaa !3
  %v1929 = call ptr @mlf_closure(ptr @mlf.code.1927, ptr null)
  %v1930 = call ptr @mlf_prim2(i64 1, ptr %v1921, ptr %v1929)
  br label %join.1899
no.1898:
  %v1939 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1931, i64 2)
  %v1940 = getelementptr i8, ptr %v1939, i64 16
  %v1941 = load ptr, ptr %v1940, align 8, !tbaa !3
  %v1942 = getelementptr i8, ptr %v1941, i64 8
  store ptr %v1888, ptr %v1942, align 8, !tbaa !3
  %v1943 = getelementptr i8, ptr %v1941, i64 16
  store ptr %v1894, ptr %v1943, align 8, !tbaa !3
  %v1962 = call ptr @mlf_env_new(i64 4)
  %v1963 = getelementptr i8, ptr %v1962, i64 8
  store ptr %v1886, ptr %v1963, align 8, !tbaa !3
  %v1964 = getelementptr i8, ptr %v1962, i64 16
  store ptr %v1888, ptr %v1964, align 8, !tbaa !3
  %v1965 = getelementptr i8, ptr %v1962, i64 24
  store ptr %v1890, ptr %v1965, align 8, !tbaa !3
  %v1966 = getelementptr i8, ptr %v1962, i64 32
  store ptr %v1894, ptr %v1966, align 8, !tbaa !3
  %v1967 = call ptr @mlf_closure(ptr @mlf.code.1944, ptr %v1962)
  %v1968 = call ptr @mlf_prim2(i64 1, ptr %v1939, ptr %v1967)
  br label %join.1899
join.1899:
  %v1969 = phi ptr [ %v1930, %yes.1897 ], [ %v1968, %no.1898 ]
  ret ptr %v1969
}

define private ptr @mlf.code.1862(ptr %env, ptr %arg) {
entry:
  %v1863 = getelementptr i8, ptr %env, i64 8
  %v1864 = load ptr, ptr %v1863, align 8, !tbaa !3
  %v1865 = getelementptr i8, ptr %env, i64 16
  %v1866 = load ptr, ptr %v1865, align 8, !tbaa !3
  %v1867 = getelementptr i8, ptr %env, i64 24
  %v1868 = load ptr, ptr %v1867, align 8, !tbaa !3
  %v1869 = getelementptr i8, ptr %env, i64 32
  %v1870 = load ptr, ptr %v1869, align 8, !tbaa !3
  %v1879 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1871, i64 2)
  %v1880 = getelementptr i8, ptr %v1879, i64 16
  %v1881 = load ptr, ptr %v1880, align 8, !tbaa !3
  %v1882 = getelementptr i8, ptr %v1881, i64 8
  store ptr %v1866, ptr %v1882, align 8, !tbaa !3
  %v1883 = getelementptr i8, ptr %v1881, i64 16
  store ptr %v1870, ptr %v1883, align 8, !tbaa !3
  %v1970 = call ptr @mlf_env_new(i64 4)
  %v1971 = getelementptr i8, ptr %v1970, i64 8
  store ptr %v1864, ptr %v1971, align 8, !tbaa !3
  %v1972 = getelementptr i8, ptr %v1970, i64 16
  store ptr %v1866, ptr %v1972, align 8, !tbaa !3
  %v1973 = getelementptr i8, ptr %v1970, i64 24
  store ptr %v1868, ptr %v1973, align 8, !tbaa !3
  %v1974 = getelementptr i8, ptr %v1970, i64 32
  store ptr %v1870, ptr %v1974, align 8, !tbaa !3
  %v1975 = call ptr @mlf_closure(ptr @mlf.code.1884, ptr %v1970)
  %v1976 = call ptr @mlf_prim2(i64 1, ptr %v1879, ptr %v1975)
  ret ptr %v1976
}

define private ptr @mlf.code.1712(ptr %env, ptr %arg) {
entry:
  %v1713 = getelementptr i8, ptr %env, i64 8
  %v1714 = load ptr, ptr %v1713, align 8, !tbaa !3
  %v1715 = getelementptr i8, ptr %env, i64 16
  %v1716 = load ptr, ptr %v1715, align 8, !tbaa !3
  %v1717 = getelementptr i8, ptr %env, i64 24
  %v1718 = load ptr, ptr %v1717, align 8, !tbaa !3
  %v1719 = getelementptr i8, ptr %env, i64 32
  %v1720 = load ptr, ptr %v1719, align 8, !tbaa !3
  %v1856 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1721, i64 3)
  %v1857 = getelementptr i8, ptr %v1856, i64 16
  %v1858 = load ptr, ptr %v1857, align 8, !tbaa !3
  %v1859 = getelementptr i8, ptr %v1858, i64 8
  store ptr %v1714, ptr %v1859, align 8, !tbaa !3
  %v1860 = getelementptr i8, ptr %v1858, i64 16
  store ptr %v1720, ptr %v1860, align 8, !tbaa !3
  %v1861 = getelementptr i8, ptr %v1858, i64 24
  store ptr %arg, ptr %v1861, align 8, !tbaa !3
  %v1977 = call ptr @mlf_env_new(i64 4)
  %v1978 = getelementptr i8, ptr %v1977, i64 8
  store ptr %v1714, ptr %v1978, align 8, !tbaa !3
  %v1979 = getelementptr i8, ptr %v1977, i64 16
  store ptr %v1716, ptr %v1979, align 8, !tbaa !3
  %v1980 = getelementptr i8, ptr %v1977, i64 24
  store ptr %v1718, ptr %v1980, align 8, !tbaa !3
  %v1981 = getelementptr i8, ptr %v1977, i64 32
  store ptr %v1720, ptr %v1981, align 8, !tbaa !3
  %v1982 = call ptr @mlf_closure(ptr @mlf.code.1862, ptr %v1977)
  %v1983 = call ptr @mlf_prim2(i64 1, ptr %v1856, ptr %v1982)
  ret ptr %v1983
}

define private ptr @mlf.worker.32(ptr %a0, ptr %a1, ptr %a2, ptr %a3) {
entry:
  %v1697 = call ptr @mlf_prim2(i64 10, ptr %a3, ptr %a2)
  %v1698 = icmp eq ptr %v1697, inttoptr (i64 6 to ptr)
  br i1 %v1698, label %yes.1699, label %no.1700
yes.1699:
  %v1702 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 2 to ptr))
  br label %join.1701
no.1700:
  %v1708 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1703, i64 1)
  %v1709 = getelementptr i8, ptr %v1708, i64 16
  %v1710 = load ptr, ptr %v1709, align 8, !tbaa !3
  %v1711 = getelementptr i8, ptr %v1710, i64 8
  store ptr %a0, ptr %v1711, align 8, !tbaa !3
  %v1984 = call ptr @mlf_env_new(i64 4)
  %v1985 = getelementptr i8, ptr %v1984, i64 8
  store ptr %a0, ptr %v1985, align 8, !tbaa !3
  %v1986 = getelementptr i8, ptr %v1984, i64 16
  store ptr %a1, ptr %v1986, align 8, !tbaa !3
  %v1987 = getelementptr i8, ptr %v1984, i64 24
  store ptr %a2, ptr %v1987, align 8, !tbaa !3
  %v1988 = getelementptr i8, ptr %v1984, i64 32
  store ptr %a3, ptr %v1988, align 8, !tbaa !3
  %v1989 = call ptr @mlf_closure(ptr @mlf.code.1712, ptr %v1984)
  %v1990 = call ptr @mlf_prim2(i64 1, ptr %v1708, ptr %v1989)
  br label %join.1701
join.1701:
  %v1991 = phi ptr [ %v1702, %yes.1699 ], [ %v1990, %no.1700 ]
  ret ptr %v1991
}

define private ptr @mlf.numeric.entry.1671(ptr %env, ptr %arg) {
entry:
  %v1672 = getelementptr i8, ptr %env, i64 8
  %v1673 = load ptr, ptr %v1672, align 8, !tbaa !3
  %v1674 = getelementptr i8, ptr %env, i64 16
  %v1675 = load ptr, ptr %v1674, align 8, !tbaa !3
  %v1676 = getelementptr i8, ptr %env, i64 24
  %v1677 = load ptr, ptr %v1676, align 8, !tbaa !3
  %v1678 = getelementptr i8, ptr %env, i64 32
  %v1679 = load ptr, ptr %v1678, align 8, !tbaa !3
  %v1680 = call ptr @mlf_peek(ptr %v1673)
  %v1681 = call ptr @mlf_peek(ptr %v1675)
  %v1682 = call ptr @mlf_peek(ptr %v1677)
  %v1683 = call ptr @mlf_peek(ptr %v1679)
  %v1684 = icmp ne ptr %v1680, null
  %v1685 = icmp ne ptr %v1681, null
  %v1686 = icmp ne ptr %v1682, null
  %v1687 = icmp ne ptr %v1683, null
  %v1688 = and i1 true, %v1684
  %v1689 = and i1 %v1688, %v1685
  %v1690 = and i1 %v1689, %v1686
  %v1691 = and i1 %v1690, %v1687
  br i1 %v1691, label %yes.1692, label %no.1693
yes.1692:
  %v1695 = call ptr @mlf.numeric.32(ptr %v1680, ptr %v1681, ptr %v1682, ptr %v1683)
  %v1696 = call ptr @mlf_prim1(i64 0, ptr %v1695)
  br label %join.1694
no.1693:
  %v1992 = call ptr @mlf.force(ptr %v1677)
  %v1993 = call ptr @mlf.force(ptr %v1679)
  %v1994 = call ptr @mlf.worker.32(ptr %v1673, ptr %v1675, ptr %v1992, ptr %v1993)
  br label %join.1694
join.1694:
  %v1995 = phi ptr [ %v1696, %yes.1692 ], [ %v1994, %no.1693 ]
  ret ptr %v1995
}

define private ptr @mlf.code.1661(ptr %env, ptr %arg) {
entry:
  %v1662 = getelementptr i8, ptr %env, i64 8
  %v1663 = load ptr, ptr %v1662, align 8, !tbaa !3
  %v1664 = getelementptr i8, ptr %env, i64 16
  %v1665 = load ptr, ptr %v1664, align 8, !tbaa !3
  %v1666 = getelementptr i8, ptr %env, i64 24
  %v1667 = load ptr, ptr %v1666, align 8, !tbaa !3
  %v1668 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1668, align 8, !tbaa !3
  %v1669 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1669, align 8, !tbaa !3
  %v1670 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v1670, align 8, !tbaa !3
  %v1996 = call ptr @mlf.force(ptr %v1667)
  %v1997 = call ptr @mlf_env_new(i64 4)
  %v1998 = getelementptr i8, ptr %v1997, i64 8
  store ptr %v1663, ptr %v1998, align 8, !tbaa !3
  %v1999 = getelementptr i8, ptr %v1997, i64 16
  store ptr %v1665, ptr %v1999, align 8, !tbaa !3
  %v2000 = getelementptr i8, ptr %v1997, i64 24
  store ptr %v1996, ptr %v2000, align 8, !tbaa !3
  %v2001 = getelementptr i8, ptr %v1997, i64 32
  store ptr inttoptr (i64 3 to ptr), ptr %v2001, align 8, !tbaa !3
  %v2002 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1671, ptr %v1997)
  ret ptr %v2002
}

define private ptr @mlf.code.2029(ptr %env, ptr %arg) {
entry:
  %v2030 = getelementptr i8, ptr %env, i64 8
  %v2031 = load ptr, ptr %v2030, align 8, !tbaa !3
  %v2032 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2032, align 8, !tbaa !3
  %v2033 = call ptr @mlf.force(ptr %v2031)
  %v2034 = call ptr @mlf_prim2(i64 8, ptr %v2033, ptr inttoptr (i64 3 to ptr))
  ret ptr %v2034
}

define private ptr @mlf.code.2009(ptr %env, ptr %arg) {
entry:
  %v2010 = getelementptr i8, ptr %env, i64 8
  %v2011 = load ptr, ptr %v2010, align 8, !tbaa !3
  %v2012 = getelementptr i8, ptr %env, i64 16
  %v2013 = load ptr, ptr %v2012, align 8, !tbaa !3
  %v2014 = getelementptr i8, ptr %env, i64 24
  %v2015 = load ptr, ptr %v2014, align 8, !tbaa !3
  %v2016 = getelementptr i8, ptr %env, i64 32
  %v2017 = load ptr, ptr %v2016, align 8, !tbaa !3
  %v2018 = getelementptr i8, ptr %env, i64 40
  %v2019 = load ptr, ptr %v2018, align 8, !tbaa !3
  %v2020 = getelementptr i8, ptr %env, i64 48
  %v2021 = load ptr, ptr %v2020, align 8, !tbaa !3
  %v2022 = getelementptr i8, ptr %env, i64 56
  %v2023 = load ptr, ptr %v2022, align 8, !tbaa !3
  %v2024 = call ptr @mlf.force(ptr %arg)
  %v2025 = icmp eq ptr %v2024, inttoptr (i64 6 to ptr)
  br i1 %v2025, label %yes.2026, label %no.2027
yes.2026:
  %v2035 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2029, i64 1)
  %v2036 = getelementptr i8, ptr %v2035, i64 16
  %v2037 = load ptr, ptr %v2036, align 8, !tbaa !3
  %v2038 = getelementptr i8, ptr %v2037, i64 8
  store ptr %v2019, ptr %v2038, align 8, !tbaa !3
  %v2039 = call ptr @mlf_env_new(i64 7)
  %v2040 = getelementptr i8, ptr %v2039, i64 8
  store ptr %v2011, ptr %v2040, align 8, !tbaa !3
  %v2041 = getelementptr i8, ptr %v2039, i64 16
  store ptr %v2013, ptr %v2041, align 8, !tbaa !3
  %v2042 = getelementptr i8, ptr %v2039, i64 24
  store ptr %v2015, ptr %v2042, align 8, !tbaa !3
  %v2043 = getelementptr i8, ptr %v2039, i64 32
  store ptr %v2017, ptr %v2043, align 8, !tbaa !3
  %v2044 = getelementptr i8, ptr %v2039, i64 40
  store ptr %v2035, ptr %v2044, align 8, !tbaa !3
  %v2045 = getelementptr i8, ptr %v2039, i64 48
  store ptr %v2021, ptr %v2045, align 8, !tbaa !3
  %v2046 = getelementptr i8, ptr %v2039, i64 56
  store ptr %v2023, ptr %v2046, align 8, !tbaa !3
  %v2047 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.271, ptr %v2039)
  br label %join.2028
no.2027:
  %v2048 = call ptr @mlf.construct.2(i64 1, ptr %v2021, ptr %v2023)
  %v2049 = call ptr @mlf_prim1(i64 0, ptr %v2048)
  br label %join.2028
join.2028:
  %v2050 = phi ptr [ %v2047, %yes.2026 ], [ %v2049, %no.2027 ]
  ret ptr %v2050
}

define private ptr @mlf.code.1601(ptr %env, ptr %arg) {
entry:
  %v1602 = getelementptr i8, ptr %env, i64 8
  %v1603 = load ptr, ptr %v1602, align 8, !tbaa !3
  %v1604 = getelementptr i8, ptr %env, i64 16
  %v1605 = load ptr, ptr %v1604, align 8, !tbaa !3
  %v1606 = getelementptr i8, ptr %env, i64 24
  %v1607 = load ptr, ptr %v1606, align 8, !tbaa !3
  %v1608 = getelementptr i8, ptr %env, i64 32
  %v1609 = load ptr, ptr %v1608, align 8, !tbaa !3
  %v1610 = getelementptr i8, ptr %env, i64 40
  %v1611 = load ptr, ptr %v1610, align 8, !tbaa !3
  %v1612 = getelementptr i8, ptr %env, i64 48
  %v1613 = load ptr, ptr %v1612, align 8, !tbaa !3
  %v1614 = getelementptr i8, ptr %env, i64 56
  %v1615 = load ptr, ptr %v1614, align 8, !tbaa !3
  %v1616 = call ptr @mlf.force(ptr %v1611)
  %v1617 = call ptr @mlf_prim2(i64 16, ptr %v1616, ptr inttoptr (i64 5 to ptr))
  %v1618 = call ptr @mlf_prim2(i64 10, ptr %v1617, ptr inttoptr (i64 1 to ptr))
  %v1619 = icmp eq ptr %v1618, inttoptr (i64 6 to ptr)
  br i1 %v1619, label %yes.1620, label %no.1621
yes.1620:
  %v1623 = call ptr @mlf.force(ptr %v1613)
  %v1624 = call ptr @mlf.force(ptr %arg)
  %v1625 = call ptr @mlf_prim2(i64 8, ptr %v1623, ptr %v1624)
  br label %join.1622
no.1621:
  %v1626 = call ptr @mlf.force(ptr %v1613)
  %v1627 = call ptr @mlf.force(ptr %arg)
  %v1628 = call ptr @mlf_prim2(i64 9, ptr %v1626, ptr %v1627)
  br label %join.1622
join.1622:
  %v1629 = phi ptr [ %v1625, %yes.1620 ], [ %v1628, %no.1621 ]
  %v1645 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1630, i64 2)
  %v1646 = getelementptr i8, ptr %v1645, i64 16
  %v1647 = load ptr, ptr %v1646, align 8, !tbaa !3
  %v1648 = getelementptr i8, ptr %v1647, i64 8
  store ptr %v1615, ptr %v1648, align 8, !tbaa !3
  %v1649 = getelementptr i8, ptr %v1647, i64 16
  store ptr %arg, ptr %v1649, align 8, !tbaa !3
  %v1650 = call ptr @mlf_prim2(i64 10, ptr %v1629, ptr %v1629)
  %v1651 = icmp eq ptr %v1650, inttoptr (i64 6 to ptr)
  br i1 %v1651, label %yes.1652, label %no.1653
yes.1652:
  %v1655 = call ptr @mlf.force(ptr %v1645)
  %v1656 = call ptr @mlf_prim2(i64 10, ptr %v1655, ptr %v1655)
  %v1657 = icmp eq ptr %v1656, inttoptr (i64 6 to ptr)
  br i1 %v1657, label %yes.1658, label %no.1659
yes.1658:
  %v2003 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1661, i64 3)
  %v2004 = getelementptr i8, ptr %v2003, i64 16
  %v2005 = load ptr, ptr %v2004, align 8, !tbaa !3
  %v2006 = getelementptr i8, ptr %v2005, i64 8
  store ptr %v1603, ptr %v2006, align 8, !tbaa !3
  %v2007 = getelementptr i8, ptr %v2005, i64 16
  store ptr %v1607, ptr %v2007, align 8, !tbaa !3
  %v2008 = getelementptr i8, ptr %v2005, i64 24
  store ptr %v1609, ptr %v2008, align 8, !tbaa !3
  %v2051 = call ptr @mlf_env_new(i64 7)
  %v2052 = getelementptr i8, ptr %v2051, i64 8
  store ptr %v1603, ptr %v2052, align 8, !tbaa !3
  %v2053 = getelementptr i8, ptr %v2051, i64 16
  store ptr %v1605, ptr %v2053, align 8, !tbaa !3
  %v2054 = getelementptr i8, ptr %v2051, i64 24
  store ptr %v1607, ptr %v2054, align 8, !tbaa !3
  %v2055 = getelementptr i8, ptr %v2051, i64 32
  store ptr %v1609, ptr %v2055, align 8, !tbaa !3
  %v2056 = getelementptr i8, ptr %v2051, i64 40
  store ptr %v1616, ptr %v2056, align 8, !tbaa !3
  %v2057 = getelementptr i8, ptr %v2051, i64 48
  store ptr %v1629, ptr %v2057, align 8, !tbaa !3
  %v2058 = getelementptr i8, ptr %v2051, i64 56
  store ptr %v1655, ptr %v2058, align 8, !tbaa !3
  %v2059 = call ptr @mlf_closure(ptr @mlf.code.2009, ptr %v2051)
  %v2060 = call ptr @mlf_prim2(i64 1, ptr %v2003, ptr %v2059)
  br label %join.1660
no.1659:
  %v2061 = call ptr @mlf.construct.2(i64 1, ptr inttoptr (i64 1 to ptr), ptr inttoptr (i64 1 to ptr))
  %v2062 = call ptr @mlf_prim1(i64 0, ptr %v2061)
  br label %join.1660
join.1660:
  %v2063 = phi ptr [ %v2060, %yes.1658 ], [ %v2062, %no.1659 ]
  br label %join.1654
no.1653:
  %v2064 = call ptr @mlf.construct.2(i64 1, ptr inttoptr (i64 1 to ptr), ptr inttoptr (i64 1 to ptr))
  %v2065 = call ptr @mlf_prim1(i64 0, ptr %v2064)
  br label %join.1654
join.1654:
  %v2066 = phi ptr [ %v2063, %join.1660 ], [ %v2065, %no.1653 ]
  ret ptr %v2066
}

define private ptr @mlf.code.1327(ptr %env, ptr %arg) {
entry:
  %v1328 = getelementptr i8, ptr %env, i64 8
  %v1329 = load ptr, ptr %v1328, align 8, !tbaa !3
  %v1330 = getelementptr i8, ptr %env, i64 16
  %v1331 = load ptr, ptr %v1330, align 8, !tbaa !3
  %v1332 = getelementptr i8, ptr %env, i64 24
  %v1333 = load ptr, ptr %v1332, align 8, !tbaa !3
  %v1334 = getelementptr i8, ptr %env, i64 32
  %v1335 = load ptr, ptr %v1334, align 8, !tbaa !3
  %v1336 = getelementptr i8, ptr %env, i64 40
  %v1337 = load ptr, ptr %v1336, align 8, !tbaa !3
  %v1338 = getelementptr i8, ptr %env, i64 48
  %v1339 = load ptr, ptr %v1338, align 8, !tbaa !3
  %v1340 = getelementptr i8, ptr %env, i64 56
  %v1341 = load ptr, ptr %v1340, align 8, !tbaa !3
  %v1597 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1342, i64 1)
  %v1598 = getelementptr i8, ptr %v1597, i64 16
  %v1599 = load ptr, ptr %v1598, align 8, !tbaa !3
  %v1600 = getelementptr i8, ptr %v1599, i64 8
  store ptr %v1331, ptr %v1600, align 8, !tbaa !3
  %v2067 = call ptr @mlf_env_new(i64 7)
  %v2068 = getelementptr i8, ptr %v2067, i64 8
  store ptr %v1329, ptr %v2068, align 8, !tbaa !3
  %v2069 = getelementptr i8, ptr %v2067, i64 16
  store ptr %v1331, ptr %v2069, align 8, !tbaa !3
  %v2070 = getelementptr i8, ptr %v2067, i64 24
  store ptr %v1333, ptr %v2070, align 8, !tbaa !3
  %v2071 = getelementptr i8, ptr %v2067, i64 32
  store ptr %v1335, ptr %v2071, align 8, !tbaa !3
  %v2072 = getelementptr i8, ptr %v2067, i64 40
  store ptr %v1337, ptr %v2072, align 8, !tbaa !3
  %v2073 = getelementptr i8, ptr %v2067, i64 48
  store ptr %v1339, ptr %v2073, align 8, !tbaa !3
  %v2074 = getelementptr i8, ptr %v2067, i64 56
  store ptr %v1341, ptr %v2074, align 8, !tbaa !3
  %v2075 = call ptr @mlf_closure(ptr @mlf.code.1601, ptr %v2067)
  %v2076 = call ptr @mlf_prim2(i64 1, ptr %v1597, ptr %v2075)
  ret ptr %v2076
}

define private ptr @mlf.worker.42(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6) {
entry:
  %v1321 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1196, i64 3)
  %v1322 = getelementptr i8, ptr %v1321, i64 16
  %v1323 = load ptr, ptr %v1322, align 8, !tbaa !3
  %v1324 = getelementptr i8, ptr %v1323, i64 8
  store ptr %a0, ptr %v1324, align 8, !tbaa !3
  %v1325 = getelementptr i8, ptr %v1323, i64 16
  store ptr %a1, ptr %v1325, align 8, !tbaa !3
  %v1326 = getelementptr i8, ptr %v1323, i64 24
  store ptr %a3, ptr %v1326, align 8, !tbaa !3
  %v2077 = call ptr @mlf_env_new(i64 7)
  %v2078 = getelementptr i8, ptr %v2077, i64 8
  store ptr %a0, ptr %v2078, align 8, !tbaa !3
  %v2079 = getelementptr i8, ptr %v2077, i64 16
  store ptr %a1, ptr %v2079, align 8, !tbaa !3
  %v2080 = getelementptr i8, ptr %v2077, i64 24
  store ptr %a2, ptr %v2080, align 8, !tbaa !3
  %v2081 = getelementptr i8, ptr %v2077, i64 32
  store ptr %a3, ptr %v2081, align 8, !tbaa !3
  %v2082 = getelementptr i8, ptr %v2077, i64 40
  store ptr %a4, ptr %v2082, align 8, !tbaa !3
  %v2083 = getelementptr i8, ptr %v2077, i64 48
  store ptr %a5, ptr %v2083, align 8, !tbaa !3
  %v2084 = getelementptr i8, ptr %v2077, i64 56
  store ptr %a6, ptr %v2084, align 8, !tbaa !3
  %v2085 = call ptr @mlf_closure(ptr @mlf.code.1327, ptr %v2077)
  %v2086 = call ptr @mlf_prim2(i64 1, ptr %v1321, ptr %v2085)
  ret ptr %v2086
}

define private ptr @mlf.numeric.entry.271(ptr %env, ptr %arg) {
entry:
  %v272 = getelementptr i8, ptr %env, i64 8
  %v273 = load ptr, ptr %v272, align 8, !tbaa !3
  %v274 = getelementptr i8, ptr %env, i64 16
  %v275 = load ptr, ptr %v274, align 8, !tbaa !3
  %v276 = getelementptr i8, ptr %env, i64 24
  %v277 = load ptr, ptr %v276, align 8, !tbaa !3
  %v278 = getelementptr i8, ptr %env, i64 32
  %v279 = load ptr, ptr %v278, align 8, !tbaa !3
  %v280 = getelementptr i8, ptr %env, i64 40
  %v281 = load ptr, ptr %v280, align 8, !tbaa !3
  %v282 = getelementptr i8, ptr %env, i64 48
  %v283 = load ptr, ptr %v282, align 8, !tbaa !3
  %v284 = getelementptr i8, ptr %env, i64 56
  %v285 = load ptr, ptr %v284, align 8, !tbaa !3
  %v286 = call ptr @mlf_peek(ptr %v273)
  %v287 = call ptr @mlf_peek(ptr %v275)
  %v288 = call ptr @mlf_peek(ptr %v277)
  %v289 = call ptr @mlf_peek(ptr %v279)
  %v290 = call ptr @mlf_peek(ptr %v281)
  %v291 = call ptr @mlf_peek(ptr %v283)
  %v292 = call ptr @mlf_peek(ptr %v285)
  %v293 = icmp ne ptr %v286, null
  %v294 = icmp ne ptr %v287, null
  %v295 = icmp ne ptr %v288, null
  %v296 = icmp ne ptr %v289, null
  %v297 = icmp ne ptr %v290, null
  %v298 = icmp ne ptr %v291, null
  %v299 = icmp ne ptr %v292, null
  %v300 = and i1 true, %v293
  %v301 = and i1 %v300, %v294
  %v302 = and i1 %v301, %v295
  %v303 = and i1 %v302, %v296
  %v304 = and i1 %v303, %v297
  %v305 = and i1 %v304, %v298
  %v306 = and i1 %v305, %v299
  br i1 %v306, label %yes.307, label %no.308
yes.307:
  %v1194 = call ptr @mlf.numeric.42(ptr %v286, ptr %v287, ptr %v288, ptr %v289, ptr %v290, ptr %v291, ptr %v292)
  %v1195 = call ptr @mlf_prim1(i64 0, ptr %v1194)
  br label %join.309
no.308:
  %v2087 = call ptr @mlf.worker.42(ptr %v273, ptr %v275, ptr %v277, ptr %v279, ptr %v281, ptr %v283, ptr %v285)
  br label %join.309
join.309:
  %v2088 = phi ptr [ %v1195, %yes.307 ], [ %v2087, %no.308 ]
  ret ptr %v2088
}

define private ptr @mlf.code.258(ptr %env, ptr %arg) {
entry:
  %v259 = getelementptr i8, ptr %env, i64 8
  %v260 = load ptr, ptr %v259, align 8, !tbaa !3
  %v261 = getelementptr i8, ptr %env, i64 16
  %v262 = load ptr, ptr %v261, align 8, !tbaa !3
  %v263 = getelementptr i8, ptr %env, i64 24
  %v264 = load ptr, ptr %v263, align 8, !tbaa !3
  %v265 = getelementptr i8, ptr %env, i64 32
  %v266 = load ptr, ptr %v265, align 8, !tbaa !3
  %v267 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v267, align 8, !tbaa !3
  %v268 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v268, align 8, !tbaa !3
  %v269 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v269, align 8, !tbaa !3
  %v270 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v270, align 8, !tbaa !3
  %v2089 = call ptr @mlf_env_new(i64 7)
  %v2090 = getelementptr i8, ptr %v2089, i64 8
  store ptr %v262, ptr %v2090, align 8, !tbaa !3
  %v2091 = getelementptr i8, ptr %v2089, i64 16
  store ptr %v264, ptr %v2091, align 8, !tbaa !3
  %v2092 = getelementptr i8, ptr %v2089, i64 24
  store ptr %v266, ptr %v2092, align 8, !tbaa !3
  %v2093 = getelementptr i8, ptr %v2089, i64 32
  store ptr %v260, ptr %v2093, align 8, !tbaa !3
  %v2094 = getelementptr i8, ptr %v2089, i64 40
  store ptr inttoptr (i64 1 to ptr), ptr %v2094, align 8, !tbaa !3
  %v2095 = getelementptr i8, ptr %v2089, i64 48
  store ptr inttoptr (i64 1 to ptr), ptr %v2095, align 8, !tbaa !3
  %v2096 = getelementptr i8, ptr %v2089, i64 56
  store ptr inttoptr (i64 1 to ptr), ptr %v2096, align 8, !tbaa !3
  %v2097 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.271, ptr %v2089)
  ret ptr %v2097
}

define private ptr @mlf.code.2126(ptr %env, ptr %arg) {
entry:
  %v2127 = getelementptr i8, ptr %env, i64 8
  %v2128 = load ptr, ptr %v2127, align 8, !tbaa !3
  %v2129 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2129, align 8, !tbaa !3
  %v2130 = call ptr @mlf_prim1(i64 5, ptr %v2128)
  ret ptr %v2130
}

define private ptr @mlf.code.2140(ptr %env, ptr %arg) {
entry:
  %v2141 = getelementptr i8, ptr %env, i64 8
  %v2142 = load ptr, ptr %v2141, align 8, !tbaa !3
  %v2143 = getelementptr i8, ptr %env, i64 16
  %v2144 = load ptr, ptr %v2143, align 8, !tbaa !3
  %v2145 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2145, align 8, !tbaa !3
  %v2146 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2146, align 8, !tbaa !3
  %v2148 = call ptr @mlf.force(ptr %v2142)
  %v2149 = call ptr @mlf_prim1(i64 7, ptr %v2148)
  %v2151 = call ptr @mlf.force(ptr %v2144)
  %v2152 = call ptr @mlf_prim1(i64 7, ptr %v2151)
  %v2153 = call ptr @mlf_prim2(i64 6, ptr @mlf.bytes.2150.value, ptr %v2152)
  %v2154 = call ptr @mlf_prim2(i64 6, ptr %v2149, ptr %v2153)
  %v2155 = call ptr @mlf_prim2(i64 6, ptr @mlf.bytes.2147.value, ptr %v2154)
  ret ptr %v2155
}

define private ptr @mlf.code.2135(ptr %env, ptr %arg) {
entry:
  %v2136 = getelementptr i8, ptr %env, i64 8
  %v2137 = load ptr, ptr %v2136, align 8, !tbaa !3
  %v2138 = getelementptr i8, ptr %env, i64 16
  %v2139 = load ptr, ptr %v2138, align 8, !tbaa !3
  %v2156 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2140, i64 2)
  %v2157 = getelementptr i8, ptr %v2156, i64 16
  %v2158 = load ptr, ptr %v2157, align 8, !tbaa !3
  %v2159 = getelementptr i8, ptr %v2158, i64 8
  store ptr %v2137, ptr %v2159, align 8, !tbaa !3
  %v2160 = getelementptr i8, ptr %v2158, i64 16
  store ptr %v2139, ptr %v2160, align 8, !tbaa !3
  %v2161 = call ptr @mlf_prim1(i64 3, ptr %v2156)
  ret ptr %v2161
}

define private ptr @mlf.code.2105(ptr %env, ptr %arg) {
entry:
  %v2106 = getelementptr i8, ptr %env, i64 8
  %v2107 = load ptr, ptr %v2106, align 8, !tbaa !3
  %v2108 = call ptr @mlf.force(ptr %arg)
  %v2109 = ptrtoint ptr %v2108 to i64
  %v2110 = and i64 %v2109, 7
  %v2111 = icmp eq i64 %v2110, 4
  br i1 %v2111, label %yes.2112, label %no.2113
yes.2112:
  %v2115 = lshr i64 %v2109, 3
  br label %join.2114
no.2113:
  %v2116 = getelementptr i8, ptr %v2108, i64 8
  %v2117 = load i64, ptr %v2116, align 8, !tbaa !3
  br label %join.2114
join.2114:
  %v2118 = phi i64 [ %v2115, %yes.2112 ], [ %v2117, %no.2113 ]
  switch i64 %v2118, label %case.missing.2120 [
    i64 1, label %case.2119
  ]
case.2119:
  %v2122 = getelementptr i8, ptr %v2108, i64 16
  %v2123 = load ptr, ptr %v2122, align 8, !tbaa !3
  %v2124 = getelementptr i8, ptr %v2108, i64 24
  %v2125 = load ptr, ptr %v2124, align 8, !tbaa !3
  %v2131 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2126, i64 1)
  %v2132 = getelementptr i8, ptr %v2131, i64 16
  %v2133 = load ptr, ptr %v2132, align 8, !tbaa !3
  %v2134 = getelementptr i8, ptr %v2133, i64 8
  store ptr %v2123, ptr %v2134, align 8, !tbaa !3
  %v2162 = call ptr @mlf_env_new(i64 2)
  %v2163 = getelementptr i8, ptr %v2162, i64 8
  store ptr %v2107, ptr %v2163, align 8, !tbaa !3
  %v2164 = getelementptr i8, ptr %v2162, i64 16
  store ptr %v2125, ptr %v2164, align 8, !tbaa !3
  %v2165 = call ptr @mlf_closure(ptr @mlf.code.2135, ptr %v2162)
  %v2166 = call ptr @mlf_prim2(i64 1, ptr %v2131, ptr %v2165)
  br label %case.join.2121
case.missing.2120:
  call void @mlf_match_failure()
  unreachable
case.join.2121:
  %v2167 = phi ptr [ %v2166, %case.2119 ]
  ret ptr %v2167
}

define private ptr @mlf.code.249(ptr %env, ptr %arg) {
entry:
  %v250 = getelementptr i8, ptr %env, i64 8
  %v251 = load ptr, ptr %v250, align 8, !tbaa !3
  %v252 = getelementptr i8, ptr %env, i64 16
  %v253 = load ptr, ptr %v252, align 8, !tbaa !3
  %v254 = getelementptr i8, ptr %env, i64 24
  %v255 = load ptr, ptr %v254, align 8, !tbaa !3
  %v256 = getelementptr i8, ptr %env, i64 32
  %v257 = load ptr, ptr %v256, align 8, !tbaa !3
  %v2098 = call ptr @mlf.allocate.thunk(ptr @mlf.code.258, i64 4)
  %v2099 = getelementptr i8, ptr %v2098, i64 16
  %v2100 = load ptr, ptr %v2099, align 8, !tbaa !3
  %v2101 = getelementptr i8, ptr %v2100, i64 8
  store ptr %v251, ptr %v2101, align 8, !tbaa !3
  %v2102 = getelementptr i8, ptr %v2100, i64 16
  store ptr %v253, ptr %v2102, align 8, !tbaa !3
  %v2103 = getelementptr i8, ptr %v2100, i64 24
  store ptr %v255, ptr %v2103, align 8, !tbaa !3
  %v2104 = getelementptr i8, ptr %v2100, i64 32
  store ptr %v257, ptr %v2104, align 8, !tbaa !3
  %v2168 = call ptr @mlf_env_new(i64 1)
  %v2169 = getelementptr i8, ptr %v2168, i64 8
  store ptr %v251, ptr %v2169, align 8, !tbaa !3
  %v2170 = call ptr @mlf_closure(ptr @mlf.code.2105, ptr %v2168)
  %v2171 = call ptr @mlf_prim2(i64 1, ptr %v2098, ptr %v2170)
  ret ptr %v2171
}

define private ptr @mlf.code.48(ptr %env, ptr %arg) {
entry:
  %v49 = getelementptr i8, ptr %env, i64 8
  %v50 = load ptr, ptr %v49, align 8, !tbaa !3
  %v51 = getelementptr i8, ptr %env, i64 16
  %v52 = load ptr, ptr %v51, align 8, !tbaa !3
  %v53 = getelementptr i8, ptr %env, i64 24
  %v54 = load ptr, ptr %v53, align 8, !tbaa !3
  %v244 = call ptr @mlf.allocate.thunk(ptr @mlf.code.55, i64 2)
  %v245 = getelementptr i8, ptr %v244, i64 16
  %v246 = load ptr, ptr %v245, align 8, !tbaa !3
  %v247 = getelementptr i8, ptr %v246, i64 8
  store ptr %v50, ptr %v247, align 8, !tbaa !3
  %v248 = getelementptr i8, ptr %v246, i64 16
  store ptr %v52, ptr %v248, align 8, !tbaa !3
  %v2172 = call ptr @mlf_env_new(i64 4)
  %v2173 = getelementptr i8, ptr %v2172, i64 8
  store ptr %v50, ptr %v2173, align 8, !tbaa !3
  %v2174 = getelementptr i8, ptr %v2172, i64 16
  store ptr %v52, ptr %v2174, align 8, !tbaa !3
  %v2175 = getelementptr i8, ptr %v2172, i64 24
  store ptr %v54, ptr %v2175, align 8, !tbaa !3
  %v2176 = getelementptr i8, ptr %v2172, i64 32
  store ptr %arg, ptr %v2176, align 8, !tbaa !3
  %v2177 = call ptr @mlf_closure(ptr @mlf.code.249, ptr %v2172)
  %v2178 = call ptr @mlf_prim2(i64 1, ptr %v244, ptr %v2177)
  ret ptr %v2178
}

define private ptr @mlf.code.34(ptr %env, ptr %arg) {
entry:
  %v35 = getelementptr i8, ptr %env, i64 8
  %v36 = load ptr, ptr %v35, align 8, !tbaa !3
  %v37 = getelementptr i8, ptr %env, i64 16
  %v38 = load ptr, ptr %v37, align 8, !tbaa !3
  %v44 = call ptr @mlf.allocate.thunk(ptr @mlf.code.39, i64 1)
  %v45 = getelementptr i8, ptr %v44, i64 16
  %v46 = load ptr, ptr %v45, align 8, !tbaa !3
  %v47 = getelementptr i8, ptr %v46, i64 8
  store ptr %v36, ptr %v47, align 8, !tbaa !3
  %v2179 = call ptr @mlf_env_new(i64 3)
  %v2180 = getelementptr i8, ptr %v2179, i64 8
  store ptr %v36, ptr %v2180, align 8, !tbaa !3
  %v2181 = getelementptr i8, ptr %v2179, i64 16
  store ptr %v38, ptr %v2181, align 8, !tbaa !3
  %v2182 = getelementptr i8, ptr %v2179, i64 24
  store ptr %arg, ptr %v2182, align 8, !tbaa !3
  %v2183 = call ptr @mlf_closure(ptr @mlf.code.48, ptr %v2179)
  %v2184 = call ptr @mlf_prim2(i64 1, ptr %v44, ptr %v2183)
  ret ptr %v2184
}

define private ptr @mlf.code.22(ptr %env, ptr %arg) {
entry:
  %v23 = getelementptr i8, ptr %env, i64 8
  %v24 = load ptr, ptr %v23, align 8, !tbaa !3
  %v30 = call ptr @mlf.allocate.thunk(ptr @mlf.code.25, i64 1)
  %v31 = getelementptr i8, ptr %v30, i64 16
  %v32 = load ptr, ptr %v31, align 8, !tbaa !3
  %v33 = getelementptr i8, ptr %v32, i64 8
  store ptr %v24, ptr %v33, align 8, !tbaa !3
  %v2185 = call ptr @mlf_env_new(i64 2)
  %v2186 = getelementptr i8, ptr %v2185, i64 8
  store ptr %v24, ptr %v2186, align 8, !tbaa !3
  %v2187 = getelementptr i8, ptr %v2185, i64 16
  store ptr %arg, ptr %v2187, align 8, !tbaa !3
  %v2188 = call ptr @mlf_closure(ptr @mlf.code.34, ptr %v2185)
  %v2189 = call ptr @mlf_prim2(i64 1, ptr %v30, ptr %v2188)
  ret ptr %v2189
}

define private ptr @mlf.code.2(ptr %env, ptr %arg) {
entry:
  %v9 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3, i64 1)
  %v10 = getelementptr i8, ptr %v9, i64 16
  %v11 = load ptr, ptr %v10, align 8, !tbaa !3
  %v12 = getelementptr i8, ptr %v11, i64 8
  store ptr %arg, ptr %v12, align 8, !tbaa !3
  %v18 = call ptr @mlf.allocate.thunk(ptr @mlf.code.13, i64 1)
  %v19 = getelementptr i8, ptr %v18, i64 16
  %v20 = load ptr, ptr %v19, align 8, !tbaa !3
  %v21 = getelementptr i8, ptr %v20, i64 8
  store ptr %v9, ptr %v21, align 8, !tbaa !3
  %v2190 = call ptr @mlf_env_new(i64 1)
  %v2191 = getelementptr i8, ptr %v2190, i64 8
  store ptr %v9, ptr %v2191, align 8, !tbaa !3
  %v2192 = call ptr @mlf_closure(ptr @mlf.code.22, ptr %v2190)
  %v2193 = call ptr @mlf_prim2(i64 1, ptr %v18, ptr %v2192)
  ret ptr %v2193
}

define private ptr @mlf.code.0(ptr %env, ptr %arg) {
entry:
  %v1 = call ptr @mlf_primitive(i64 4)
  %v2194 = call ptr @mlf_closure(ptr @mlf.code.2, ptr null)
  %v2195 = call ptr @mlf_prim2(i64 1, ptr %v1, ptr %v2194)
  ret ptr %v2195
}

declare void @mlf_require_compact_gc_abi()
define ptr @mlf_entry() {
  call void @mlf_require_compact_gc_abi()
  %root = call ptr @mlf.code.0(ptr null, ptr null)
  ret ptr %root
}
define i32 @main(i32 %argc, ptr %argv) {
  call void @mlf_set_args(i32 %argc, ptr %argv)
  %root = call ptr @mlf_entry()
  %status = call i32 @mlf_run(ptr %root, i64 1)
  ret i32 %status
}
