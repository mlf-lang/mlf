; Generated from independently checked xMLF.
source_filename = "emlf"

declare ptr @mlf_execute_st_lazy(ptr)
declare ptr @mlf_st_new_array(ptr, ptr)
declare ptr @mlf_st_read_array(ptr, ptr)
declare ptr @mlf_st_write_array(ptr, ptr, ptr)
declare ptr @mlf_st_length_array(ptr)
declare void @mlf_set_args(i32, ptr)
declare ptr @mlf_env_new(i64)
declare void @mlf_env_set(ptr, i64, ptr)
declare ptr @mlf_env_get(ptr, i64)
declare ptr @mlf_thunk(ptr, ptr)
declare ptr @mlf_closure(ptr, ptr)
declare ptr @mlf_application(ptr, ptr)
declare ptr @mlf_hole()
declare void @mlf_fill(ptr, ptr)
declare ptr @mlf_integer(ptr)
declare ptr @mlf_string(ptr, i64)
declare ptr @mlf_double(double)
declare double @llvm.sqrt.f64(double)
declare double @mlf_int_to_double(ptr)
declare ptr @mlf_read_int_table(ptr, ptr)
declare ptr @mlf_write_int_table(ptr, ptr, ptr)
declare ptr @mlf_add_int_table(ptr, ptr, ptr)
declare void @mlf_roots_enter(ptr, i64, ptr)
declare void @mlf_roots_leave(ptr)
declare void @mlf_gc_check(i64, ptr)
declare ptr @mlf_get_byte_line()
declare ptr @mlf_new_array(i64, ptr, ptr)
declare ptr @mlf_bytes_from_string(ptr)
declare ptr @mlf_put_bytes(ptr, ptr, ptr)
declare ptr @mlf_new_int_table()
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare i8 @mlf_byte(ptr)
declare ptr @mlf_peek(ptr)
declare ptr @mlf_native_io(ptr, ptr)
declare void @mlf_bounds_failure() noreturn
declare ptr @mlf_primitive(i64)
declare ptr @mlf_prim1(i64, ptr)
declare ptr @mlf_prim2(i64, ptr, ptr)
declare i64 @mlf_truth(ptr)
declare ptr @mlf_prim3(i64, ptr, ptr, ptr)
declare ptr @mlf_force(ptr)
declare ptr @mlf_add_int(ptr, ptr)
declare ptr @mlf_sub_int(ptr, ptr)
declare ptr @mlf_eq_int(ptr, ptr)
declare ptr @mlf_lt_int(ptr, ptr)
declare ptr @mlf_constructor(i64, i64)
declare ptr @mlf_constructor1(i64, ptr)
declare ptr @mlf_constructor2(i64, ptr, ptr)
declare ptr @mlf_constructor_fields(i64, ptr)
declare ptr @mlf_constructor_new(i64, i64)
declare ptr @mlf_field(ptr, i64)
declare void @mlf_match_failure() noreturn
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare i32 @mlf_run(ptr, i64)

!0 = !{!"MLF storage"}
!1 = !{!"managed object", !0}
!2 = !{!"array cells", !0}
!3 = !{!1, !1, i64 0}
!4 = !{!2, !2, i64 0}
@mlf.bytes.6 = private unnamed_addr constant [17 x i8] c"\41\43\47\54\55\4d\52\57\53\59\4b\56\48\44\42\4e\00", align 1
@mlf.bytes.14 = private unnamed_addr constant [17 x i8] c"\54\47\43\41\41\4b\59\57\53\52\4d\42\44\48\56\4e\00", align 1
define private ptr @mlf.code.1(ptr %env, ptr %arg) {
entry:
  %v2 = call ptr @mlf_prim2(i64 35, ptr inttoptr (i64 513 to ptr), ptr inttoptr (i64 1 to ptr))
  ret ptr %v2
}

define private ptr @mlf.code.5(ptr %env, ptr %arg) {
entry:
  %v7 = call ptr @mlf_string(ptr @mlf.bytes.6, i64 16)
  %v8 = call ptr @mlf_prim1(i64 39, ptr %v7)
  ret ptr %v8
}

define private ptr @mlf.code.13(ptr %env, ptr %arg) {
entry:
  %v15 = call ptr @mlf_string(ptr @mlf.bytes.14, i64 16)
  %v16 = call ptr @mlf_prim1(i64 39, ptr %v15)
  ret ptr %v16
}

define private ptr @mlf.numeric.15.pppi(ptr %a0, ptr %a1, ptr %a2, ptr %a3) alwaysinline {
entry:
  %v62 = ptrtoint ptr %a3 to i64
  %v63 = ptrtoint ptr inttoptr (i64 33 to ptr) to i64
  %v64 = icmp slt i64 %v62, %v63
  %v65 = select i1 %v64, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v66 = icmp eq ptr %v65, inttoptr (i64 6 to ptr)
  br i1 %v66, label %tail.yes.67, label %tail.no.68
tail.yes.67:
  %v69 = getelementptr i8, ptr %a1, i64 24
  %v70 = load i64, ptr %v69, align 8, !tbaa !3
  %v71 = getelementptr i8, ptr %a1, i64 32
  %v72 = load ptr, ptr %v71, align 8, !tbaa !3
  %v73 = ptrtoint ptr %a3 to i64
  %v74 = ashr i64 %v73, 1
  %v75 = and i64 %v73, 1
  %v76 = icmp ne i64 %v75, 0
  %v77 = icmp ult i64 %v74, %v70
  %v78 = and i1 %v76, %v77
  br i1 %v78, label %array.valid.79, label %array.invalid.80
array.invalid.80:
  call void @mlf_bounds_failure()
  unreachable
array.valid.79:
  %v81 = getelementptr i8, ptr %v72, i64 %v74
  %v82 = load i8, ptr %v81, align 1, !tbaa !4
  %v83 = zext i8 %v82 to i64
  %v84 = shl i64 %v83, 1
  %v85 = or i64 %v84, 1
  %v86 = inttoptr i64 %v85 to ptr
  %v87 = getelementptr i8, ptr %a2, i64 24
  %v88 = load i64, ptr %v87, align 8, !tbaa !3
  %v89 = getelementptr i8, ptr %a2, i64 32
  %v90 = load ptr, ptr %v89, align 8, !tbaa !3
  %v91 = ptrtoint ptr %a3 to i64
  %v92 = ashr i64 %v91, 1
  %v93 = and i64 %v91, 1
  %v94 = icmp ne i64 %v93, 0
  %v95 = icmp ult i64 %v92, %v88
  %v96 = and i1 %v94, %v95
  br i1 %v96, label %array.valid.97, label %array.invalid.98
array.invalid.98:
  call void @mlf_bounds_failure()
  unreachable
array.valid.97:
  %v99 = getelementptr i8, ptr %v90, i64 %v92
  %v100 = load i8, ptr %v99, align 1, !tbaa !4
  %v101 = zext i8 %v100 to i64
  %v102 = shl i64 %v101, 1
  %v103 = or i64 %v102, 1
  %v104 = inttoptr i64 %v103 to ptr
  %v105 = getelementptr i8, ptr %a0, i64 24
  %v106 = load i64, ptr %v105, align 8, !tbaa !3
  %v107 = getelementptr i8, ptr %a0, i64 32
  %v108 = load ptr, ptr %v107, align 8, !tbaa !3
  %v109 = ptrtoint ptr %v86 to i64
  %v110 = ashr i64 %v109, 1
  %v111 = and i64 %v109, 1
  %v112 = icmp ne i64 %v111, 0
  %v113 = icmp ult i64 %v110, %v106
  %v114 = and i1 %v112, %v113
  br i1 %v114, label %array.valid.115, label %array.invalid.116
array.invalid.116:
  call void @mlf_bounds_failure()
  unreachable
array.valid.115:
  %v117 = getelementptr i8, ptr %v108, i64 %v110
  %v118 = ptrtoint ptr %v104 to i64
  %v119 = ashr i64 %v118, 1
  %v120 = trunc i64 %v119 to i8
  store i8 %v120, ptr %v117, align 1, !tbaa !4
  %v121 = ptrtoint ptr %v86 to i64
  %v122 = ptrtoint ptr inttoptr (i64 65 to ptr) to i64
  %v123 = sub i64 %v122, 1
  %v124 = add nsw i64 %v121, %v123
  %v125 = inttoptr i64 %v124 to ptr
  %v126 = ptrtoint ptr %v125 to i64
  %v127 = ashr i64 %v126, 1
  %v128 = and i64 %v126, 1
  %v129 = icmp ne i64 %v128, 0
  %v130 = icmp ult i64 %v127, %v106
  %v131 = and i1 %v129, %v130
  br i1 %v131, label %array.valid.132, label %array.invalid.133
array.invalid.133:
  call void @mlf_bounds_failure()
  unreachable
array.valid.132:
  %v134 = getelementptr i8, ptr %v108, i64 %v127
  %v135 = ptrtoint ptr %v104 to i64
  %v136 = ashr i64 %v135, 1
  %v137 = trunc i64 %v136 to i8
  store i8 %v137, ptr %v134, align 1, !tbaa !4
  %v138 = ptrtoint ptr %a3 to i64
  %v139 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v140 = sub i64 %v139, 1
  %v141 = add nsw i64 %v138, %v140
  %v142 = inttoptr i64 %v141 to ptr
  %v143 = musttail call ptr @mlf.numeric.15.pppi(ptr %a0, ptr %a1, ptr %a2, ptr %v142)
  ret ptr %v143
tail.no.68:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.numeric.15(ptr %a0, ptr %a1, ptr %a2, ptr %a3) alwaysinline {
entry:
  %v54 = ptrtoint ptr %a3 to i64
  %v55 = and i64 %v54, 1
  %v56 = icmp ne i64 %v55, 0
  %v57 = icmp ult i64 %v54, 4294967296
  %v58 = and i1 %v56, %v57
  %v59 = and i1 true, %v58
  br i1 %v59, label %range.fast.60, label %range.general.61
range.fast.60:
  %v144 = musttail call ptr @mlf.numeric.15.pppi(ptr %a0, ptr %a1, ptr %a2, ptr %a3)
  ret ptr %v144
range.general.61:
  %v145 = ptrtoint ptr %a3 to i64
  %v146 = ptrtoint ptr inttoptr (i64 33 to ptr) to i64
  %v147 = and i64 %v145, %v146
  %v148 = and i64 %v147, 1
  %v149 = icmp ne i64 %v148, 0
  br i1 %v149, label %yes.150, label %no.151
yes.150:
  %v153 = icmp slt i64 %v145, %v146
  %v154 = select i1 %v153, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.152
no.151:
  %v155 = call ptr @mlf_lt_int(ptr %a3, ptr inttoptr (i64 33 to ptr))
  br label %join.152
join.152:
  %v156 = phi ptr [ %v154, %yes.150 ], [ %v155, %no.151 ]
  %v157 = icmp eq ptr %v156, inttoptr (i64 6 to ptr)
  br i1 %v157, label %tail.yes.158, label %tail.no.159
tail.yes.158:
  %v160 = getelementptr i8, ptr %a1, i64 24
  %v161 = load i64, ptr %v160, align 8, !tbaa !3
  %v162 = getelementptr i8, ptr %a1, i64 32
  %v163 = load ptr, ptr %v162, align 8, !tbaa !3
  %v164 = ptrtoint ptr %a3 to i64
  %v165 = ashr i64 %v164, 1
  %v166 = and i64 %v164, 1
  %v167 = icmp ne i64 %v166, 0
  %v168 = icmp ult i64 %v165, %v161
  %v169 = and i1 %v167, %v168
  br i1 %v169, label %array.valid.170, label %array.invalid.171
array.invalid.171:
  call void @mlf_bounds_failure()
  unreachable
array.valid.170:
  %v172 = getelementptr i8, ptr %v163, i64 %v165
  %v173 = load i8, ptr %v172, align 1, !tbaa !4
  %v174 = zext i8 %v173 to i64
  %v175 = shl i64 %v174, 1
  %v176 = or i64 %v175, 1
  %v177 = inttoptr i64 %v176 to ptr
  %v178 = getelementptr i8, ptr %a2, i64 24
  %v179 = load i64, ptr %v178, align 8, !tbaa !3
  %v180 = getelementptr i8, ptr %a2, i64 32
  %v181 = load ptr, ptr %v180, align 8, !tbaa !3
  %v182 = ptrtoint ptr %a3 to i64
  %v183 = ashr i64 %v182, 1
  %v184 = and i64 %v182, 1
  %v185 = icmp ne i64 %v184, 0
  %v186 = icmp ult i64 %v183, %v179
  %v187 = and i1 %v185, %v186
  br i1 %v187, label %array.valid.188, label %array.invalid.189
array.invalid.189:
  call void @mlf_bounds_failure()
  unreachable
array.valid.188:
  %v190 = getelementptr i8, ptr %v181, i64 %v183
  %v191 = load i8, ptr %v190, align 1, !tbaa !4
  %v192 = zext i8 %v191 to i64
  %v193 = shl i64 %v192, 1
  %v194 = or i64 %v193, 1
  %v195 = inttoptr i64 %v194 to ptr
  %v196 = getelementptr i8, ptr %a0, i64 24
  %v197 = load i64, ptr %v196, align 8, !tbaa !3
  %v198 = getelementptr i8, ptr %a0, i64 32
  %v199 = load ptr, ptr %v198, align 8, !tbaa !3
  %v200 = ptrtoint ptr %v177 to i64
  %v201 = ashr i64 %v200, 1
  %v202 = and i64 %v200, 1
  %v203 = icmp ne i64 %v202, 0
  %v204 = icmp ult i64 %v201, %v197
  %v205 = and i1 %v203, %v204
  br i1 %v205, label %array.valid.206, label %array.invalid.207
array.invalid.207:
  call void @mlf_bounds_failure()
  unreachable
array.valid.206:
  %v208 = getelementptr i8, ptr %v199, i64 %v201
  %v209 = ptrtoint ptr %v195 to i64
  %v210 = ashr i64 %v209, 1
  %v211 = trunc i64 %v210 to i8
  store i8 %v211, ptr %v208, align 1, !tbaa !4
  %v212 = ptrtoint ptr %v177 to i64
  %v213 = ptrtoint ptr inttoptr (i64 65 to ptr) to i64
  %v214 = sub i64 %v213, 1
  %v215 = add nsw i64 %v212, %v214
  %v216 = inttoptr i64 %v215 to ptr
  %v217 = ptrtoint ptr %v216 to i64
  %v218 = ashr i64 %v217, 1
  %v219 = and i64 %v217, 1
  %v220 = icmp ne i64 %v219, 0
  %v221 = icmp ult i64 %v218, %v197
  %v222 = and i1 %v220, %v221
  br i1 %v222, label %array.valid.223, label %array.invalid.224
array.invalid.224:
  call void @mlf_bounds_failure()
  unreachable
array.valid.223:
  %v225 = getelementptr i8, ptr %v199, i64 %v218
  %v226 = ptrtoint ptr %v195 to i64
  %v227 = ashr i64 %v226, 1
  %v228 = trunc i64 %v227 to i8
  store i8 %v228, ptr %v225, align 1, !tbaa !4
  %v229 = ptrtoint ptr %a3 to i64
  %v230 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v231 = sub i64 %v230, 1
  %v232 = add nsw i64 %v229, %v231
  %v233 = inttoptr i64 %v232 to ptr
  %v234 = musttail call ptr @mlf.numeric.15(ptr %a0, ptr %a1, ptr %a2, ptr %v233)
  ret ptr %v234
tail.no.159:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.code.242(ptr %env, ptr %arg) {
entry:
  %v243 = getelementptr i8, ptr %env, i64 24
  %v244 = load ptr, ptr %v243, align 8, !tbaa !3
  %v245 = getelementptr i8, ptr %env, i64 32
  %v246 = load ptr, ptr %v245, align 8, !tbaa !3
  %v247 = call ptr @mlf_prim2(i64 36, ptr %v244, ptr %v246)
  ret ptr %v247
}

define private ptr @mlf.code.261(ptr %env, ptr %arg) {
entry:
  %v262 = getelementptr i8, ptr %env, i64 24
  %v263 = load ptr, ptr %v262, align 8, !tbaa !3
  %v264 = getelementptr i8, ptr %env, i64 32
  %v265 = load ptr, ptr %v264, align 8, !tbaa !3
  %v266 = call ptr @mlf_prim2(i64 36, ptr %v263, ptr %v265)
  ret ptr %v266
}

define private ptr @mlf.code.282(ptr %env, ptr %arg) {
entry:
  %v283 = getelementptr i8, ptr %env, i64 24
  %v284 = load ptr, ptr %v283, align 8, !tbaa !3
  %v285 = getelementptr i8, ptr %env, i64 32
  %v286 = load ptr, ptr %v285, align 8, !tbaa !3
  %v287 = getelementptr i8, ptr %env, i64 40
  %v288 = load ptr, ptr %v287, align 8, !tbaa !3
  %v289 = call ptr @mlf_prim3(i64 37, ptr %v284, ptr %v286, ptr %v288)
  ret ptr %v289
}

define private ptr @mlf.code.315(ptr %env, ptr %arg) {
entry:
  %v316 = getelementptr i8, ptr %env, i64 24
  %v317 = load ptr, ptr %v316, align 8, !tbaa !3
  %v318 = call ptr @mlf_force(ptr %v317)
  %v319 = call ptr @mlf_prim2(i64 8, ptr %v318, ptr inttoptr (i64 65 to ptr))
  ret ptr %v319
}

define private ptr @mlf.code.308(ptr %env, ptr %arg) {
entry:
  %v309 = getelementptr i8, ptr %env, i64 24
  %v310 = load ptr, ptr %v309, align 8, !tbaa !3
  %v311 = getelementptr i8, ptr %env, i64 32
  %v312 = load ptr, ptr %v311, align 8, !tbaa !3
  %v313 = getelementptr i8, ptr %env, i64 40
  %v314 = load ptr, ptr %v313, align 8, !tbaa !3
  %v320 = call ptr @mlf_env_new(i64 1)
  %v321 = getelementptr i8, ptr %v320, i64 24
  store ptr %v312, ptr %v321, align 8, !tbaa !3
  %v322 = call ptr @mlf_thunk(ptr @mlf.code.315, ptr %v320)
  %v323 = call ptr @mlf_prim3(i64 37, ptr %v310, ptr %v322, ptr %v314)
  ret ptr %v323
}

define private ptr @mlf.code.329(ptr %env, ptr %arg) {
entry:
  %v330 = getelementptr i8, ptr %env, i64 24
  %v331 = load ptr, ptr %v330, align 8, !tbaa !3
  %v332 = getelementptr i8, ptr %env, i64 32
  %v333 = load ptr, ptr %v332, align 8, !tbaa !3
  %v334 = getelementptr i8, ptr %env, i64 40
  %v335 = load ptr, ptr %v334, align 8, !tbaa !3
  %v336 = getelementptr i8, ptr %env, i64 48
  %v337 = load ptr, ptr %v336, align 8, !tbaa !3
  %v338 = call ptr @mlf_force(ptr %v337)
  %v339 = call ptr @mlf_prim2(i64 8, ptr %v338, ptr inttoptr (i64 3 to ptr))
  %v340 = call ptr @mlf_env_new(i64 4)
  %v341 = getelementptr i8, ptr %v340, i64 24
  store ptr %v331, ptr %v341, align 8, !tbaa !3
  %v342 = getelementptr i8, ptr %v340, i64 32
  store ptr %v333, ptr %v342, align 8, !tbaa !3
  %v343 = getelementptr i8, ptr %v340, i64 40
  store ptr %v335, ptr %v343, align 8, !tbaa !3
  %v344 = getelementptr i8, ptr %v340, i64 48
  store ptr %v339, ptr %v344, align 8, !tbaa !3
  %v345 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.30, ptr %v340)
  ret ptr %v345
}

define private ptr @mlf.code.295(ptr %env, ptr %arg) {
entry:
  %v296 = getelementptr i8, ptr %env, i64 24
  %v297 = load ptr, ptr %v296, align 8, !tbaa !3
  %v298 = getelementptr i8, ptr %env, i64 32
  %v299 = load ptr, ptr %v298, align 8, !tbaa !3
  %v300 = getelementptr i8, ptr %env, i64 40
  %v301 = load ptr, ptr %v300, align 8, !tbaa !3
  %v302 = getelementptr i8, ptr %env, i64 48
  %v303 = load ptr, ptr %v302, align 8, !tbaa !3
  %v304 = getelementptr i8, ptr %env, i64 56
  %v305 = load ptr, ptr %v304, align 8, !tbaa !3
  %v306 = getelementptr i8, ptr %env, i64 64
  %v307 = load ptr, ptr %v306, align 8, !tbaa !3
  %v324 = call ptr @mlf_env_new(i64 3)
  %v325 = getelementptr i8, ptr %v324, i64 24
  store ptr %v297, ptr %v325, align 8, !tbaa !3
  %v326 = getelementptr i8, ptr %v324, i64 32
  store ptr %v305, ptr %v326, align 8, !tbaa !3
  %v327 = getelementptr i8, ptr %v324, i64 40
  store ptr %v307, ptr %v327, align 8, !tbaa !3
  %v328 = call ptr @mlf_thunk(ptr @mlf.code.308, ptr %v324)
  %v346 = call ptr @mlf_env_new(i64 4)
  %v347 = getelementptr i8, ptr %v346, i64 24
  store ptr %v297, ptr %v347, align 8, !tbaa !3
  %v348 = getelementptr i8, ptr %v346, i64 32
  store ptr %v299, ptr %v348, align 8, !tbaa !3
  %v349 = getelementptr i8, ptr %v346, i64 40
  store ptr %v301, ptr %v349, align 8, !tbaa !3
  %v350 = getelementptr i8, ptr %v346, i64 48
  store ptr %v303, ptr %v350, align 8, !tbaa !3
  %v351 = call ptr @mlf_closure(ptr @mlf.code.329, ptr %v346)
  %v352 = call ptr @mlf_prim2(i64 1, ptr %v328, ptr %v351)
  ret ptr %v352
}

define private ptr @mlf.code.271(ptr %env, ptr %arg) {
entry:
  %v272 = getelementptr i8, ptr %env, i64 24
  %v273 = load ptr, ptr %v272, align 8, !tbaa !3
  %v274 = getelementptr i8, ptr %env, i64 32
  %v275 = load ptr, ptr %v274, align 8, !tbaa !3
  %v276 = getelementptr i8, ptr %env, i64 40
  %v277 = load ptr, ptr %v276, align 8, !tbaa !3
  %v278 = getelementptr i8, ptr %env, i64 48
  %v279 = load ptr, ptr %v278, align 8, !tbaa !3
  %v280 = getelementptr i8, ptr %env, i64 56
  %v281 = load ptr, ptr %v280, align 8, !tbaa !3
  %v290 = call ptr @mlf_env_new(i64 3)
  %v291 = getelementptr i8, ptr %v290, i64 24
  store ptr %v273, ptr %v291, align 8, !tbaa !3
  %v292 = getelementptr i8, ptr %v290, i64 32
  store ptr %v281, ptr %v292, align 8, !tbaa !3
  %v293 = getelementptr i8, ptr %v290, i64 40
  store ptr %arg, ptr %v293, align 8, !tbaa !3
  %v294 = call ptr @mlf_thunk(ptr @mlf.code.282, ptr %v290)
  %v353 = call ptr @mlf_env_new(i64 6)
  %v354 = getelementptr i8, ptr %v353, i64 24
  store ptr %v273, ptr %v354, align 8, !tbaa !3
  %v355 = getelementptr i8, ptr %v353, i64 32
  store ptr %v275, ptr %v355, align 8, !tbaa !3
  %v356 = getelementptr i8, ptr %v353, i64 40
  store ptr %v277, ptr %v356, align 8, !tbaa !3
  %v357 = getelementptr i8, ptr %v353, i64 48
  store ptr %v279, ptr %v357, align 8, !tbaa !3
  %v358 = getelementptr i8, ptr %v353, i64 56
  store ptr %v281, ptr %v358, align 8, !tbaa !3
  %v359 = getelementptr i8, ptr %v353, i64 64
  store ptr %arg, ptr %v359, align 8, !tbaa !3
  %v360 = call ptr @mlf_closure(ptr @mlf.code.295, ptr %v353)
  %v361 = call ptr @mlf_prim2(i64 1, ptr %v294, ptr %v360)
  ret ptr %v361
}

define private ptr @mlf.code.252(ptr %env, ptr %arg) {
entry:
  %v253 = getelementptr i8, ptr %env, i64 24
  %v254 = load ptr, ptr %v253, align 8, !tbaa !3
  %v255 = getelementptr i8, ptr %env, i64 32
  %v256 = load ptr, ptr %v255, align 8, !tbaa !3
  %v257 = getelementptr i8, ptr %env, i64 40
  %v258 = load ptr, ptr %v257, align 8, !tbaa !3
  %v259 = getelementptr i8, ptr %env, i64 48
  %v260 = load ptr, ptr %v259, align 8, !tbaa !3
  %v267 = call ptr @mlf_env_new(i64 2)
  %v268 = getelementptr i8, ptr %v267, i64 24
  store ptr %v258, ptr %v268, align 8, !tbaa !3
  %v269 = getelementptr i8, ptr %v267, i64 32
  store ptr %v260, ptr %v269, align 8, !tbaa !3
  %v270 = call ptr @mlf_thunk(ptr @mlf.code.261, ptr %v267)
  %v362 = call ptr @mlf_env_new(i64 5)
  %v363 = getelementptr i8, ptr %v362, i64 24
  store ptr %v254, ptr %v363, align 8, !tbaa !3
  %v364 = getelementptr i8, ptr %v362, i64 32
  store ptr %v256, ptr %v364, align 8, !tbaa !3
  %v365 = getelementptr i8, ptr %v362, i64 40
  store ptr %v258, ptr %v365, align 8, !tbaa !3
  %v366 = getelementptr i8, ptr %v362, i64 48
  store ptr %v260, ptr %v366, align 8, !tbaa !3
  %v367 = getelementptr i8, ptr %v362, i64 56
  store ptr %arg, ptr %v367, align 8, !tbaa !3
  %v368 = call ptr @mlf_closure(ptr @mlf.code.271, ptr %v362)
  %v369 = call ptr @mlf_prim2(i64 1, ptr %v270, ptr %v368)
  ret ptr %v369
}

define private ptr @mlf.worker.15(ptr %a0, ptr %a1, ptr %a2, ptr %a3) {
entry:
  %v237 = call ptr @mlf_prim2(i64 11, ptr %a3, ptr inttoptr (i64 33 to ptr))
  %v238 = icmp eq ptr %v237, inttoptr (i64 6 to ptr)
  br i1 %v238, label %yes.239, label %no.240
yes.239:
  %v248 = call ptr @mlf_env_new(i64 2)
  %v249 = getelementptr i8, ptr %v248, i64 24
  store ptr %a1, ptr %v249, align 8, !tbaa !3
  %v250 = getelementptr i8, ptr %v248, i64 32
  store ptr %a3, ptr %v250, align 8, !tbaa !3
  %v251 = call ptr @mlf_thunk(ptr @mlf.code.242, ptr %v248)
  %v370 = call ptr @mlf_env_new(i64 4)
  %v371 = getelementptr i8, ptr %v370, i64 24
  store ptr %a0, ptr %v371, align 8, !tbaa !3
  %v372 = getelementptr i8, ptr %v370, i64 32
  store ptr %a1, ptr %v372, align 8, !tbaa !3
  %v373 = getelementptr i8, ptr %v370, i64 40
  store ptr %a2, ptr %v373, align 8, !tbaa !3
  %v374 = getelementptr i8, ptr %v370, i64 48
  store ptr %a3, ptr %v374, align 8, !tbaa !3
  %v375 = call ptr @mlf_closure(ptr @mlf.code.252, ptr %v370)
  %v376 = call ptr @mlf_prim2(i64 1, ptr %v251, ptr %v375)
  br label %join.241
no.240:
  %v377 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.241
join.241:
  %v378 = phi ptr [ %v376, %yes.239 ], [ %v377, %no.240 ]
  ret ptr %v378
}

define private ptr @mlf.numeric.entry.30(ptr %env, ptr %arg) {
entry:
  %v31 = getelementptr i8, ptr %env, i64 24
  %v32 = load ptr, ptr %v31, align 8, !tbaa !3
  %v33 = getelementptr i8, ptr %env, i64 32
  %v34 = load ptr, ptr %v33, align 8, !tbaa !3
  %v35 = getelementptr i8, ptr %env, i64 40
  %v36 = load ptr, ptr %v35, align 8, !tbaa !3
  %v37 = getelementptr i8, ptr %env, i64 48
  %v38 = load ptr, ptr %v37, align 8, !tbaa !3
  %v39 = call ptr @mlf_peek(ptr %v32)
  %v40 = call ptr @mlf_peek(ptr %v34)
  %v41 = call ptr @mlf_peek(ptr %v36)
  %v42 = call ptr @mlf_peek(ptr %v38)
  %v43 = icmp ne ptr %v39, null
  %v44 = icmp ne ptr %v40, null
  %v45 = icmp ne ptr %v41, null
  %v46 = icmp ne ptr %v42, null
  %v47 = and i1 true, %v43
  %v48 = and i1 %v47, %v44
  %v49 = and i1 %v48, %v45
  %v50 = and i1 %v49, %v46
  br i1 %v50, label %yes.51, label %no.52
yes.51:
  %v235 = call ptr @mlf.numeric.15(ptr %v39, ptr %v40, ptr %v41, ptr %v42)
  %v236 = call ptr @mlf_prim1(i64 0, ptr %v235)
  br label %join.53
no.52:
  %v379 = call ptr @mlf_force(ptr %v38)
  %v380 = call ptr @mlf.worker.15(ptr %v32, ptr %v34, ptr %v36, ptr %v379)
  br label %join.53
join.53:
  %v381 = phi ptr [ %v236, %yes.51 ], [ %v380, %no.52 ]
  ret ptr %v381
}

define private ptr @mlf.code.23(ptr %env, ptr %arg) {
entry:
  %v24 = getelementptr i8, ptr %env, i64 24
  %v25 = load ptr, ptr %v24, align 8, !tbaa !3
  %v26 = getelementptr i8, ptr %env, i64 32
  %v27 = load ptr, ptr %v26, align 8, !tbaa !3
  %v28 = getelementptr i8, ptr %env, i64 40
  %v29 = load ptr, ptr %v28, align 8, !tbaa !3
  %v382 = call ptr @mlf_env_new(i64 4)
  %v383 = getelementptr i8, ptr %v382, i64 24
  store ptr %v25, ptr %v383, align 8, !tbaa !3
  %v384 = getelementptr i8, ptr %v382, i64 32
  store ptr %v27, ptr %v384, align 8, !tbaa !3
  %v385 = getelementptr i8, ptr %v382, i64 40
  store ptr %v29, ptr %v385, align 8, !tbaa !3
  %v386 = getelementptr i8, ptr %v382, i64 48
  store ptr inttoptr (i64 1 to ptr), ptr %v386, align 8, !tbaa !3
  %v387 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.30, ptr %v382)
  ret ptr %v387
}

define private ptr @mlf.code.396(ptr %env, ptr %arg) {
entry:
  %v397 = call ptr @mlf_prim2(i64 35, ptr inttoptr (i64 2049 to ptr), ptr inttoptr (i64 1 to ptr))
  ret ptr %v397
}

define private ptr @mlf.code.402(ptr %env, ptr %arg) {
entry:
  %v403 = call ptr @mlf_prim2(i64 35, ptr inttoptr (i64 124929 to ptr), ptr inttoptr (i64 1 to ptr))
  ret ptr %v403
}

define private ptr @mlf.numeric.24.pppiiii(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6) alwaysinline {
entry:
  %v556 = ptrtoint ptr %a6 to i64
  %v557 = ptrtoint ptr %a5 to i64
  %v558 = icmp slt i64 %v556, %v557
  %v559 = select i1 %v558, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v560 = icmp eq ptr %v559, inttoptr (i64 6 to ptr)
  br i1 %v560, label %tail.yes.561, label %tail.no.562
tail.yes.561:
  %v563 = ptrtoint ptr %a3 to i64
  %v564 = ptrtoint ptr %a6 to i64
  %v565 = sub i64 %v564, 1
  %v566 = sub nsw i64 %v563, %v565
  %v567 = inttoptr i64 %v566 to ptr
  %v568 = getelementptr i8, ptr %a1, i64 24
  %v569 = load i64, ptr %v568, align 8, !tbaa !3
  %v570 = getelementptr i8, ptr %a1, i64 32
  %v571 = load ptr, ptr %v570, align 8, !tbaa !3
  %v572 = ptrtoint ptr %v567 to i64
  %v573 = ashr i64 %v572, 1
  %v574 = and i64 %v572, 1
  %v575 = icmp ne i64 %v574, 0
  %v576 = icmp ult i64 %v573, %v569
  %v577 = and i1 %v575, %v576
  br i1 %v577, label %array.valid.578, label %array.invalid.579
array.invalid.579:
  call void @mlf_bounds_failure()
  unreachable
array.valid.578:
  %v580 = getelementptr i8, ptr %v571, i64 %v573
  %v581 = load i8, ptr %v580, align 1, !tbaa !4
  %v582 = zext i8 %v581 to i64
  %v583 = shl i64 %v582, 1
  %v584 = or i64 %v583, 1
  %v585 = inttoptr i64 %v584 to ptr
  %v586 = getelementptr i8, ptr %a0, i64 24
  %v587 = load i64, ptr %v586, align 8, !tbaa !3
  %v588 = getelementptr i8, ptr %a0, i64 32
  %v589 = load ptr, ptr %v588, align 8, !tbaa !3
  %v590 = ptrtoint ptr %v585 to i64
  %v591 = ashr i64 %v590, 1
  %v592 = and i64 %v590, 1
  %v593 = icmp ne i64 %v592, 0
  %v594 = icmp ult i64 %v591, %v587
  %v595 = and i1 %v593, %v594
  br i1 %v595, label %array.valid.596, label %array.invalid.597
array.invalid.597:
  call void @mlf_bounds_failure()
  unreachable
array.valid.596:
  %v598 = getelementptr i8, ptr %v589, i64 %v591
  %v599 = load i8, ptr %v598, align 1, !tbaa !4
  %v600 = zext i8 %v599 to i64
  %v601 = shl i64 %v600, 1
  %v602 = or i64 %v601, 1
  %v603 = inttoptr i64 %v602 to ptr
  %v604 = ptrtoint ptr %a4 to i64
  %v605 = ptrtoint ptr %a6 to i64
  %v606 = sub i64 %v605, 1
  %v607 = add nsw i64 %v604, %v606
  %v608 = inttoptr i64 %v607 to ptr
  %v609 = getelementptr i8, ptr %a2, i64 24
  %v610 = load i64, ptr %v609, align 8, !tbaa !3
  %v611 = getelementptr i8, ptr %a2, i64 32
  %v612 = load ptr, ptr %v611, align 8, !tbaa !3
  %v613 = ptrtoint ptr %v608 to i64
  %v614 = ashr i64 %v613, 1
  %v615 = and i64 %v613, 1
  %v616 = icmp ne i64 %v615, 0
  %v617 = icmp ult i64 %v614, %v610
  %v618 = and i1 %v616, %v617
  br i1 %v618, label %array.valid.619, label %array.invalid.620
array.invalid.620:
  call void @mlf_bounds_failure()
  unreachable
array.valid.619:
  %v621 = getelementptr i8, ptr %v612, i64 %v614
  %v622 = ptrtoint ptr %v603 to i64
  %v623 = ashr i64 %v622, 1
  %v624 = trunc i64 %v623 to i8
  store i8 %v624, ptr %v621, align 1, !tbaa !4
  %v625 = ptrtoint ptr %a6 to i64
  %v626 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v627 = sub i64 %v626, 1
  %v628 = add nsw i64 %v625, %v627
  %v629 = inttoptr i64 %v628 to ptr
  %v630 = musttail call ptr @mlf.numeric.24.pppiiii(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %v629)
  ret ptr %v630
tail.no.562:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.numeric.35.pppiii(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5) alwaysinline {
entry:
  %v540 = ptrtoint ptr %a4 to i64
  %v541 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v542 = icmp eq i64 %v540, %v541
  %v543 = select i1 %v542, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v544 = icmp eq ptr %v543, inttoptr (i64 6 to ptr)
  br i1 %v544, label %tail.yes.545, label %tail.no.546
tail.yes.545:
  ret ptr inttoptr (i64 4 to ptr)
tail.no.546:
  %v547 = ptrtoint ptr %a4 to i64
  %v548 = ptrtoint ptr inttoptr (i64 121 to ptr) to i64
  %v549 = icmp slt i64 %v547, %v548
  %v550 = select i1 %v549, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v551 = icmp eq ptr %v550, inttoptr (i64 6 to ptr)
  br i1 %v551, label %yes.552, label %no.553
yes.552:
  br label %join.554
no.553:
  br label %join.554
join.554:
  %v555 = phi ptr [ %a4, %yes.552 ], [ inttoptr (i64 121 to ptr), %no.553 ]
  %v631 = call ptr @mlf.numeric.24.pppiiii(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a5, ptr %v555, ptr inttoptr (i64 1 to ptr))
  %v632 = ptrtoint ptr %a5 to i64
  %v633 = ptrtoint ptr %v555 to i64
  %v634 = sub i64 %v633, 1
  %v635 = add nsw i64 %v632, %v634
  %v636 = inttoptr i64 %v635 to ptr
  %v637 = getelementptr i8, ptr %a2, i64 24
  %v638 = load i64, ptr %v637, align 8, !tbaa !3
  %v639 = getelementptr i8, ptr %a2, i64 32
  %v640 = load ptr, ptr %v639, align 8, !tbaa !3
  %v641 = ptrtoint ptr %v636 to i64
  %v642 = ashr i64 %v641, 1
  %v643 = and i64 %v641, 1
  %v644 = icmp ne i64 %v643, 0
  %v645 = icmp ult i64 %v642, %v638
  %v646 = and i1 %v644, %v645
  br i1 %v646, label %array.valid.647, label %array.invalid.648
array.invalid.648:
  call void @mlf_bounds_failure()
  unreachable
array.valid.647:
  %v649 = getelementptr i8, ptr %v640, i64 %v642
  %v650 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v651 = ashr i64 %v650, 1
  %v652 = trunc i64 %v651 to i8
  store i8 %v652, ptr %v649, align 1, !tbaa !4
  %v653 = ptrtoint ptr %a3 to i64
  %v654 = ptrtoint ptr %v555 to i64
  %v655 = sub i64 %v654, 1
  %v656 = sub nsw i64 %v653, %v655
  %v657 = inttoptr i64 %v656 to ptr
  %v658 = ptrtoint ptr %a4 to i64
  %v659 = ptrtoint ptr %v555 to i64
  %v660 = sub i64 %v659, 1
  %v661 = sub nsw i64 %v658, %v660
  %v662 = inttoptr i64 %v661 to ptr
  %v663 = ptrtoint ptr %a5 to i64
  %v664 = ptrtoint ptr %v555 to i64
  %v665 = sub i64 %v664, 1
  %v666 = add nsw i64 %v663, %v665
  %v667 = inttoptr i64 %v666 to ptr
  %v668 = ptrtoint ptr %v667 to i64
  %v669 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v670 = sub i64 %v669, 1
  %v671 = add nsw i64 %v668, %v670
  %v672 = inttoptr i64 %v671 to ptr
  %v673 = musttail call ptr @mlf.numeric.35(ptr %a0, ptr %a1, ptr %a2, ptr %v657, ptr %v662, ptr %v672)
  ret ptr %v673
}

define private ptr @mlf.numeric.24(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6) alwaysinline {
entry:
  %v707 = ptrtoint ptr %a3 to i64
  %v708 = and i64 %v707, 1
  %v709 = icmp ne i64 %v708, 0
  %v710 = icmp ult i64 %v707, 4294967296
  %v711 = and i1 %v709, %v710
  %v712 = ptrtoint ptr %a4 to i64
  %v713 = and i64 %v712, 1
  %v714 = icmp ne i64 %v713, 0
  %v715 = icmp ult i64 %v712, 4294967296
  %v716 = and i1 %v714, %v715
  %v717 = ptrtoint ptr %a5 to i64
  %v718 = and i64 %v717, 1
  %v719 = icmp ne i64 %v718, 0
  %v720 = icmp ult i64 %v717, 4294967296
  %v721 = and i1 %v719, %v720
  %v722 = ptrtoint ptr %a6 to i64
  %v723 = and i64 %v722, 1
  %v724 = icmp ne i64 %v723, 0
  %v725 = icmp ult i64 %v722, 4294967296
  %v726 = and i1 %v724, %v725
  %v727 = and i1 true, %v711
  %v728 = and i1 %v727, %v716
  %v729 = and i1 %v728, %v721
  %v730 = and i1 %v729, %v726
  br i1 %v730, label %range.fast.731, label %range.general.732
range.fast.731:
  %v733 = musttail call ptr @mlf.numeric.24.pppiiii(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6)
  ret ptr %v733
range.general.732:
  %v734 = ptrtoint ptr %a6 to i64
  %v735 = ptrtoint ptr %a5 to i64
  %v736 = and i64 %v734, %v735
  %v737 = and i64 %v736, 1
  %v738 = icmp ne i64 %v737, 0
  br i1 %v738, label %yes.739, label %no.740
yes.739:
  %v742 = icmp slt i64 %v734, %v735
  %v743 = select i1 %v742, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.741
no.740:
  %v744 = call ptr @mlf_lt_int(ptr %a6, ptr %a5)
  br label %join.741
join.741:
  %v745 = phi ptr [ %v743, %yes.739 ], [ %v744, %no.740 ]
  %v746 = icmp eq ptr %v745, inttoptr (i64 6 to ptr)
  br i1 %v746, label %tail.yes.747, label %tail.no.748
tail.yes.747:
  %v749 = ptrtoint ptr %a3 to i64
  %v750 = ptrtoint ptr %a6 to i64
  %v751 = and i64 %v749, %v750
  %v752 = and i64 %v751, 1
  %v753 = icmp ne i64 %v752, 0
  br i1 %v753, label %yes.754, label %no.755
yes.754:
  %v757 = sub i64 %v750, 1
  %v758 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v749, i64 %v757)
  %v759 = extractvalue { i64, i1 } %v758, 0
  %v760 = extractvalue { i64, i1 } %v758, 1
  br i1 %v760, label %yes.761, label %no.762
yes.761:
  %v764 = call ptr @mlf_sub_int(ptr %a3, ptr %a6)
  br label %join.763
no.762:
  %v765 = inttoptr i64 %v759 to ptr
  br label %join.763
join.763:
  %v766 = phi ptr [ %v764, %yes.761 ], [ %v765, %no.762 ]
  br label %join.756
no.755:
  %v767 = call ptr @mlf_sub_int(ptr %a3, ptr %a6)
  br label %join.756
join.756:
  %v768 = phi ptr [ %v766, %join.763 ], [ %v767, %no.755 ]
  %v769 = getelementptr i8, ptr %a1, i64 24
  %v770 = load i64, ptr %v769, align 8, !tbaa !3
  %v771 = getelementptr i8, ptr %a1, i64 32
  %v772 = load ptr, ptr %v771, align 8, !tbaa !3
  %v773 = ptrtoint ptr %v768 to i64
  %v774 = ashr i64 %v773, 1
  %v775 = and i64 %v773, 1
  %v776 = icmp ne i64 %v775, 0
  %v777 = icmp ult i64 %v774, %v770
  %v778 = and i1 %v776, %v777
  br i1 %v778, label %array.valid.779, label %array.invalid.780
array.invalid.780:
  call void @mlf_bounds_failure()
  unreachable
array.valid.779:
  %v781 = getelementptr i8, ptr %v772, i64 %v774
  %v782 = load i8, ptr %v781, align 1, !tbaa !4
  %v783 = zext i8 %v782 to i64
  %v784 = shl i64 %v783, 1
  %v785 = or i64 %v784, 1
  %v786 = inttoptr i64 %v785 to ptr
  %v787 = getelementptr i8, ptr %a0, i64 24
  %v788 = load i64, ptr %v787, align 8, !tbaa !3
  %v789 = getelementptr i8, ptr %a0, i64 32
  %v790 = load ptr, ptr %v789, align 8, !tbaa !3
  %v791 = ptrtoint ptr %v786 to i64
  %v792 = ashr i64 %v791, 1
  %v793 = and i64 %v791, 1
  %v794 = icmp ne i64 %v793, 0
  %v795 = icmp ult i64 %v792, %v788
  %v796 = and i1 %v794, %v795
  br i1 %v796, label %array.valid.797, label %array.invalid.798
array.invalid.798:
  call void @mlf_bounds_failure()
  unreachable
array.valid.797:
  %v799 = getelementptr i8, ptr %v790, i64 %v792
  %v800 = load i8, ptr %v799, align 1, !tbaa !4
  %v801 = zext i8 %v800 to i64
  %v802 = shl i64 %v801, 1
  %v803 = or i64 %v802, 1
  %v804 = inttoptr i64 %v803 to ptr
  %v805 = ptrtoint ptr %a4 to i64
  %v806 = ptrtoint ptr %a6 to i64
  %v807 = and i64 %v805, %v806
  %v808 = and i64 %v807, 1
  %v809 = icmp ne i64 %v808, 0
  br i1 %v809, label %yes.810, label %no.811
yes.810:
  %v813 = sub i64 %v806, 1
  %v814 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v805, i64 %v813)
  %v815 = extractvalue { i64, i1 } %v814, 0
  %v816 = extractvalue { i64, i1 } %v814, 1
  br i1 %v816, label %yes.817, label %no.818
yes.817:
  %v820 = call ptr @mlf_add_int(ptr %a4, ptr %a6)
  br label %join.819
no.818:
  %v821 = inttoptr i64 %v815 to ptr
  br label %join.819
join.819:
  %v822 = phi ptr [ %v820, %yes.817 ], [ %v821, %no.818 ]
  br label %join.812
no.811:
  %v823 = call ptr @mlf_add_int(ptr %a4, ptr %a6)
  br label %join.812
join.812:
  %v824 = phi ptr [ %v822, %join.819 ], [ %v823, %no.811 ]
  %v825 = getelementptr i8, ptr %a2, i64 24
  %v826 = load i64, ptr %v825, align 8, !tbaa !3
  %v827 = getelementptr i8, ptr %a2, i64 32
  %v828 = load ptr, ptr %v827, align 8, !tbaa !3
  %v829 = ptrtoint ptr %v824 to i64
  %v830 = ashr i64 %v829, 1
  %v831 = and i64 %v829, 1
  %v832 = icmp ne i64 %v831, 0
  %v833 = icmp ult i64 %v830, %v826
  %v834 = and i1 %v832, %v833
  br i1 %v834, label %array.valid.835, label %array.invalid.836
array.invalid.836:
  call void @mlf_bounds_failure()
  unreachable
array.valid.835:
  %v837 = getelementptr i8, ptr %v828, i64 %v830
  %v838 = ptrtoint ptr %v804 to i64
  %v839 = ashr i64 %v838, 1
  %v840 = trunc i64 %v839 to i8
  store i8 %v840, ptr %v837, align 1, !tbaa !4
  %v841 = ptrtoint ptr %a6 to i64
  %v842 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v843 = and i64 %v841, %v842
  %v844 = and i64 %v843, 1
  %v845 = icmp ne i64 %v844, 0
  br i1 %v845, label %yes.846, label %no.847
yes.846:
  %v849 = sub i64 %v842, 1
  %v850 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v841, i64 %v849)
  %v851 = extractvalue { i64, i1 } %v850, 0
  %v852 = extractvalue { i64, i1 } %v850, 1
  br i1 %v852, label %yes.853, label %no.854
yes.853:
  %v856 = call ptr @mlf_add_int(ptr %a6, ptr inttoptr (i64 3 to ptr))
  br label %join.855
no.854:
  %v857 = inttoptr i64 %v851 to ptr
  br label %join.855
join.855:
  %v858 = phi ptr [ %v856, %yes.853 ], [ %v857, %no.854 ]
  br label %join.848
no.847:
  %v859 = call ptr @mlf_add_int(ptr %a6, ptr inttoptr (i64 3 to ptr))
  br label %join.848
join.848:
  %v860 = phi ptr [ %v858, %join.855 ], [ %v859, %no.847 ]
  %v861 = musttail call ptr @mlf.numeric.24(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %v860)
  ret ptr %v861
tail.no.748:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.numeric.35(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5) alwaysinline {
entry:
  %v520 = ptrtoint ptr %a3 to i64
  %v521 = and i64 %v520, 1
  %v522 = icmp ne i64 %v521, 0
  %v523 = icmp ult i64 %v520, 4294967296
  %v524 = and i1 %v522, %v523
  %v525 = ptrtoint ptr %a4 to i64
  %v526 = and i64 %v525, 1
  %v527 = icmp ne i64 %v526, 0
  %v528 = icmp ult i64 %v525, 4294967296
  %v529 = and i1 %v527, %v528
  %v530 = ptrtoint ptr %a5 to i64
  %v531 = and i64 %v530, 1
  %v532 = icmp ne i64 %v531, 0
  %v533 = icmp ult i64 %v530, 4294967296
  %v534 = and i1 %v532, %v533
  %v535 = and i1 true, %v524
  %v536 = and i1 %v535, %v529
  %v537 = and i1 %v536, %v534
  br i1 %v537, label %range.fast.538, label %range.general.539
range.fast.538:
  %v674 = musttail call ptr @mlf.numeric.35.pppiii(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5)
  ret ptr %v674
range.general.539:
  %v675 = ptrtoint ptr %a4 to i64
  %v676 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v677 = and i64 %v675, %v676
  %v678 = and i64 %v677, 1
  %v679 = icmp ne i64 %v678, 0
  br i1 %v679, label %yes.680, label %no.681
yes.680:
  %v683 = icmp eq i64 %v675, %v676
  %v684 = select i1 %v683, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.682
no.681:
  %v685 = call ptr @mlf_eq_int(ptr %a4, ptr inttoptr (i64 1 to ptr))
  br label %join.682
join.682:
  %v686 = phi ptr [ %v684, %yes.680 ], [ %v685, %no.681 ]
  %v687 = icmp eq ptr %v686, inttoptr (i64 6 to ptr)
  br i1 %v687, label %tail.yes.688, label %tail.no.689
tail.yes.688:
  ret ptr inttoptr (i64 4 to ptr)
tail.no.689:
  %v690 = ptrtoint ptr %a4 to i64
  %v691 = ptrtoint ptr inttoptr (i64 121 to ptr) to i64
  %v692 = and i64 %v690, %v691
  %v693 = and i64 %v692, 1
  %v694 = icmp ne i64 %v693, 0
  br i1 %v694, label %yes.695, label %no.696
yes.695:
  %v698 = icmp slt i64 %v690, %v691
  %v699 = select i1 %v698, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.697
no.696:
  %v700 = call ptr @mlf_lt_int(ptr %a4, ptr inttoptr (i64 121 to ptr))
  br label %join.697
join.697:
  %v701 = phi ptr [ %v699, %yes.695 ], [ %v700, %no.696 ]
  %v702 = icmp eq ptr %v701, inttoptr (i64 6 to ptr)
  br i1 %v702, label %yes.703, label %no.704
yes.703:
  br label %join.705
no.704:
  br label %join.705
join.705:
  %v706 = phi ptr [ %a4, %yes.703 ], [ inttoptr (i64 121 to ptr), %no.704 ]
  %v862 = call ptr @mlf.numeric.24(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a5, ptr %v706, ptr inttoptr (i64 1 to ptr))
  %v863 = ptrtoint ptr %a5 to i64
  %v864 = ptrtoint ptr %v706 to i64
  %v865 = and i64 %v863, %v864
  %v866 = and i64 %v865, 1
  %v867 = icmp ne i64 %v866, 0
  br i1 %v867, label %yes.868, label %no.869
yes.868:
  %v871 = sub i64 %v864, 1
  %v872 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v863, i64 %v871)
  %v873 = extractvalue { i64, i1 } %v872, 0
  %v874 = extractvalue { i64, i1 } %v872, 1
  br i1 %v874, label %yes.875, label %no.876
yes.875:
  %v878 = call ptr @mlf_add_int(ptr %a5, ptr %v706)
  br label %join.877
no.876:
  %v879 = inttoptr i64 %v873 to ptr
  br label %join.877
join.877:
  %v880 = phi ptr [ %v878, %yes.875 ], [ %v879, %no.876 ]
  br label %join.870
no.869:
  %v881 = call ptr @mlf_add_int(ptr %a5, ptr %v706)
  br label %join.870
join.870:
  %v882 = phi ptr [ %v880, %join.877 ], [ %v881, %no.869 ]
  %v883 = getelementptr i8, ptr %a2, i64 24
  %v884 = load i64, ptr %v883, align 8, !tbaa !3
  %v885 = getelementptr i8, ptr %a2, i64 32
  %v886 = load ptr, ptr %v885, align 8, !tbaa !3
  %v887 = ptrtoint ptr %v882 to i64
  %v888 = ashr i64 %v887, 1
  %v889 = and i64 %v887, 1
  %v890 = icmp ne i64 %v889, 0
  %v891 = icmp ult i64 %v888, %v884
  %v892 = and i1 %v890, %v891
  br i1 %v892, label %array.valid.893, label %array.invalid.894
array.invalid.894:
  call void @mlf_bounds_failure()
  unreachable
array.valid.893:
  %v895 = getelementptr i8, ptr %v886, i64 %v888
  %v896 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v897 = ashr i64 %v896, 1
  %v898 = trunc i64 %v897 to i8
  store i8 %v898, ptr %v895, align 1, !tbaa !4
  %v899 = ptrtoint ptr %a3 to i64
  %v900 = ptrtoint ptr %v706 to i64
  %v901 = and i64 %v899, %v900
  %v902 = and i64 %v901, 1
  %v903 = icmp ne i64 %v902, 0
  br i1 %v903, label %yes.904, label %no.905
yes.904:
  %v907 = sub i64 %v900, 1
  %v908 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v899, i64 %v907)
  %v909 = extractvalue { i64, i1 } %v908, 0
  %v910 = extractvalue { i64, i1 } %v908, 1
  br i1 %v910, label %yes.911, label %no.912
yes.911:
  %v914 = call ptr @mlf_sub_int(ptr %a3, ptr %v706)
  br label %join.913
no.912:
  %v915 = inttoptr i64 %v909 to ptr
  br label %join.913
join.913:
  %v916 = phi ptr [ %v914, %yes.911 ], [ %v915, %no.912 ]
  br label %join.906
no.905:
  %v917 = call ptr @mlf_sub_int(ptr %a3, ptr %v706)
  br label %join.906
join.906:
  %v918 = phi ptr [ %v916, %join.913 ], [ %v917, %no.905 ]
  %v919 = ptrtoint ptr %a4 to i64
  %v920 = ptrtoint ptr %v706 to i64
  %v921 = and i64 %v919, %v920
  %v922 = and i64 %v921, 1
  %v923 = icmp ne i64 %v922, 0
  br i1 %v923, label %yes.924, label %no.925
yes.924:
  %v927 = sub i64 %v920, 1
  %v928 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v919, i64 %v927)
  %v929 = extractvalue { i64, i1 } %v928, 0
  %v930 = extractvalue { i64, i1 } %v928, 1
  br i1 %v930, label %yes.931, label %no.932
yes.931:
  %v934 = call ptr @mlf_sub_int(ptr %a4, ptr %v706)
  br label %join.933
no.932:
  %v935 = inttoptr i64 %v929 to ptr
  br label %join.933
join.933:
  %v936 = phi ptr [ %v934, %yes.931 ], [ %v935, %no.932 ]
  br label %join.926
no.925:
  %v937 = call ptr @mlf_sub_int(ptr %a4, ptr %v706)
  br label %join.926
join.926:
  %v938 = phi ptr [ %v936, %join.933 ], [ %v937, %no.925 ]
  %v939 = ptrtoint ptr %a5 to i64
  %v940 = ptrtoint ptr %v706 to i64
  %v941 = and i64 %v939, %v940
  %v942 = and i64 %v941, 1
  %v943 = icmp ne i64 %v942, 0
  br i1 %v943, label %yes.944, label %no.945
yes.944:
  %v947 = sub i64 %v940, 1
  %v948 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v939, i64 %v947)
  %v949 = extractvalue { i64, i1 } %v948, 0
  %v950 = extractvalue { i64, i1 } %v948, 1
  br i1 %v950, label %yes.951, label %no.952
yes.951:
  %v954 = call ptr @mlf_add_int(ptr %a5, ptr %v706)
  br label %join.953
no.952:
  %v955 = inttoptr i64 %v949 to ptr
  br label %join.953
join.953:
  %v956 = phi ptr [ %v954, %yes.951 ], [ %v955, %no.952 ]
  br label %join.946
no.945:
  %v957 = call ptr @mlf_add_int(ptr %a5, ptr %v706)
  br label %join.946
join.946:
  %v958 = phi ptr [ %v956, %join.953 ], [ %v957, %no.945 ]
  %v959 = ptrtoint ptr %v958 to i64
  %v960 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v961 = and i64 %v959, %v960
  %v962 = and i64 %v961, 1
  %v963 = icmp ne i64 %v962, 0
  br i1 %v963, label %yes.964, label %no.965
yes.964:
  %v967 = sub i64 %v960, 1
  %v968 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v959, i64 %v967)
  %v969 = extractvalue { i64, i1 } %v968, 0
  %v970 = extractvalue { i64, i1 } %v968, 1
  br i1 %v970, label %yes.971, label %no.972
yes.971:
  %v974 = call ptr @mlf_add_int(ptr %v958, ptr inttoptr (i64 3 to ptr))
  br label %join.973
no.972:
  %v975 = inttoptr i64 %v969 to ptr
  br label %join.973
join.973:
  %v976 = phi ptr [ %v974, %yes.971 ], [ %v975, %no.972 ]
  br label %join.966
no.965:
  %v977 = call ptr @mlf_add_int(ptr %v958, ptr inttoptr (i64 3 to ptr))
  br label %join.966
join.966:
  %v978 = phi ptr [ %v976, %join.973 ], [ %v977, %no.965 ]
  %v979 = musttail call ptr @mlf.numeric.35(ptr %a0, ptr %a1, ptr %a2, ptr %v918, ptr %v938, ptr %v978)
  ret ptr %v979
}

define private ptr @mlf.numeric.45(ptr %a0, ptr %a1, ptr %a2, ptr %a3) alwaysinline {
entry:
  %v468 = ptrtoint ptr %a3 to i64
  %v469 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v470 = and i64 %v468, %v469
  %v471 = and i64 %v470, 1
  %v472 = icmp ne i64 %v471, 0
  br i1 %v472, label %yes.473, label %no.474
yes.473:
  %v476 = icmp eq i64 %v468, %v469
  %v477 = select i1 %v476, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.475
no.474:
  %v478 = call ptr @mlf_eq_int(ptr %a3, ptr inttoptr (i64 1 to ptr))
  br label %join.475
join.475:
  %v479 = phi ptr [ %v477, %yes.473 ], [ %v478, %no.474 ]
  %v480 = icmp eq ptr %v479, inttoptr (i64 6 to ptr)
  br i1 %v480, label %tail.yes.481, label %tail.no.482
tail.yes.481:
  ret ptr inttoptr (i64 4 to ptr)
tail.no.482:
  %v483 = ptrtoint ptr %a3 to i64
  %v484 = ptrtoint ptr inttoptr (i64 122881 to ptr) to i64
  %v485 = and i64 %v483, %v484
  %v486 = and i64 %v485, 1
  %v487 = icmp ne i64 %v486, 0
  br i1 %v487, label %yes.488, label %no.489
yes.488:
  %v491 = icmp slt i64 %v483, %v484
  %v492 = select i1 %v491, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.490
no.489:
  %v493 = call ptr @mlf_lt_int(ptr %a3, ptr inttoptr (i64 122881 to ptr))
  br label %join.490
join.490:
  %v494 = phi ptr [ %v492, %yes.488 ], [ %v493, %no.489 ]
  %v495 = icmp eq ptr %v494, inttoptr (i64 6 to ptr)
  br i1 %v495, label %yes.496, label %no.497
yes.496:
  br label %join.498
no.497:
  br label %join.498
join.498:
  %v499 = phi ptr [ %a3, %yes.496 ], [ inttoptr (i64 122881 to ptr), %no.497 ]
  %v500 = ptrtoint ptr %a3 to i64
  %v501 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v502 = and i64 %v500, %v501
  %v503 = and i64 %v502, 1
  %v504 = icmp ne i64 %v503, 0
  br i1 %v504, label %yes.505, label %no.506
yes.505:
  %v508 = sub i64 %v501, 1
  %v509 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v500, i64 %v508)
  %v510 = extractvalue { i64, i1 } %v509, 0
  %v511 = extractvalue { i64, i1 } %v509, 1
  br i1 %v511, label %yes.512, label %no.513
yes.512:
  %v515 = call ptr @mlf_sub_int(ptr %a3, ptr inttoptr (i64 3 to ptr))
  br label %join.514
no.513:
  %v516 = inttoptr i64 %v510 to ptr
  br label %join.514
join.514:
  %v517 = phi ptr [ %v515, %yes.512 ], [ %v516, %no.513 ]
  br label %join.507
no.506:
  %v518 = call ptr @mlf_sub_int(ptr %a3, ptr inttoptr (i64 3 to ptr))
  br label %join.507
join.507:
  %v519 = phi ptr [ %v517, %join.514 ], [ %v518, %no.506 ]
  %v980 = call ptr @mlf.numeric.35(ptr %a0, ptr %a2, ptr %a1, ptr %v519, ptr %v499, ptr inttoptr (i64 1 to ptr))
  %v981 = ptrtoint ptr %v499 to i64
  %v982 = ptrtoint ptr inttoptr (i64 119 to ptr) to i64
  %v983 = and i64 %v981, %v982
  %v984 = and i64 %v983, 1
  %v985 = icmp ne i64 %v984, 0
  br i1 %v985, label %yes.986, label %no.987
yes.986:
  %v989 = sub i64 %v982, 1
  %v990 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v981, i64 %v989)
  %v991 = extractvalue { i64, i1 } %v990, 0
  %v992 = extractvalue { i64, i1 } %v990, 1
  br i1 %v992, label %yes.993, label %no.994
yes.993:
  %v996 = call ptr @mlf_add_int(ptr %v499, ptr inttoptr (i64 119 to ptr))
  br label %join.995
no.994:
  %v997 = inttoptr i64 %v991 to ptr
  br label %join.995
join.995:
  %v998 = phi ptr [ %v996, %yes.993 ], [ %v997, %no.994 ]
  br label %join.988
no.987:
  %v999 = call ptr @mlf_add_int(ptr %v499, ptr inttoptr (i64 119 to ptr))
  br label %join.988
join.988:
  %v1000 = phi ptr [ %v998, %join.995 ], [ %v999, %no.987 ]
  %v1001 = ptrtoint ptr %v1000 to i64
  %v1002 = ptrtoint ptr inttoptr (i64 121 to ptr) to i64
  %v1003 = and i64 %v1001, %v1002
  %v1004 = and i64 %v1003, 1
  %v1005 = icmp ne i64 %v1004, 0
  br i1 %v1005, label %yes.1006, label %no.1007
yes.1006:
  %v1009 = ashr i64 %v1001, 1
  %v1010 = ashr i64 %v1002, 1
  %v1011 = icmp ne i64 %v1010, 0
  %v1012 = icmp eq i64 %v1009, -4611686018427387904
  %v1013 = icmp eq i64 %v1010, -1
  %v1014 = and i1 %v1012, %v1013
  %v1015 = xor i1 %v1014, true
  %v1016 = and i1 %v1011, %v1015
  br i1 %v1016, label %yes.1017, label %no.1018
yes.1017:
  %v1020 = sdiv i64 %v1009, %v1010
  %v1021 = shl i64 %v1020, 1
  %v1022 = or i64 %v1021, 1
  %v1023 = inttoptr i64 %v1022 to ptr
  br label %join.1019
no.1018:
  %v1024 = call ptr @mlf_prim2(i64 15, ptr %v1000, ptr inttoptr (i64 121 to ptr))
  br label %join.1019
join.1019:
  %v1025 = phi ptr [ %v1023, %yes.1017 ], [ %v1024, %no.1018 ]
  br label %join.1008
no.1007:
  %v1026 = call ptr @mlf_prim2(i64 15, ptr %v1000, ptr inttoptr (i64 121 to ptr))
  br label %join.1008
join.1008:
  %v1027 = phi ptr [ %v1025, %join.1019 ], [ %v1026, %no.1007 ]
  %v1028 = ptrtoint ptr %v499 to i64
  %v1029 = ptrtoint ptr %v1027 to i64
  %v1030 = and i64 %v1028, %v1029
  %v1031 = and i64 %v1030, 1
  %v1032 = icmp ne i64 %v1031, 0
  br i1 %v1032, label %yes.1033, label %no.1034
yes.1033:
  %v1036 = sub i64 %v1029, 1
  %v1037 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1028, i64 %v1036)
  %v1038 = extractvalue { i64, i1 } %v1037, 0
  %v1039 = extractvalue { i64, i1 } %v1037, 1
  br i1 %v1039, label %yes.1040, label %no.1041
yes.1040:
  %v1043 = call ptr @mlf_add_int(ptr %v499, ptr %v1027)
  br label %join.1042
no.1041:
  %v1044 = inttoptr i64 %v1038 to ptr
  br label %join.1042
join.1042:
  %v1045 = phi ptr [ %v1043, %yes.1040 ], [ %v1044, %no.1041 ]
  br label %join.1035
no.1034:
  %v1046 = call ptr @mlf_add_int(ptr %v499, ptr %v1027)
  br label %join.1035
join.1035:
  %v1047 = phi ptr [ %v1045, %join.1042 ], [ %v1046, %no.1034 ]
  %v1048 = call ptr @mlf_put_bytes(ptr %a1, ptr inttoptr (i64 1 to ptr), ptr %v1047)
  %v1049 = ptrtoint ptr %a3 to i64
  %v1050 = ptrtoint ptr %v499 to i64
  %v1051 = and i64 %v1049, %v1050
  %v1052 = and i64 %v1051, 1
  %v1053 = icmp ne i64 %v1052, 0
  br i1 %v1053, label %yes.1054, label %no.1055
yes.1054:
  %v1057 = sub i64 %v1050, 1
  %v1058 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v1049, i64 %v1057)
  %v1059 = extractvalue { i64, i1 } %v1058, 0
  %v1060 = extractvalue { i64, i1 } %v1058, 1
  br i1 %v1060, label %yes.1061, label %no.1062
yes.1061:
  %v1064 = call ptr @mlf_sub_int(ptr %a3, ptr %v499)
  br label %join.1063
no.1062:
  %v1065 = inttoptr i64 %v1059 to ptr
  br label %join.1063
join.1063:
  %v1066 = phi ptr [ %v1064, %yes.1061 ], [ %v1065, %no.1062 ]
  br label %join.1056
no.1055:
  %v1067 = call ptr @mlf_sub_int(ptr %a3, ptr %v499)
  br label %join.1056
join.1056:
  %v1068 = phi ptr [ %v1066, %join.1063 ], [ %v1067, %no.1055 ]
  %v1069 = musttail call ptr @mlf.numeric.45(ptr %a0, ptr %a1, ptr %a2, ptr %v1068)
  ret ptr %v1069
}

define private ptr @mlf.numeric.11.pi(ptr %a0, ptr %a1) alwaysinline {
entry:
  %v1103 = ptrtoint ptr %a1 to i64
  %v1104 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v1105 = icmp eq i64 %v1103, %v1104
  %v1106 = select i1 %v1105, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1107 = icmp eq ptr %v1106, inttoptr (i64 6 to ptr)
  br i1 %v1107, label %tail.yes.1108, label %tail.no.1109
tail.yes.1108:
  ret ptr inttoptr (i64 1 to ptr)
tail.no.1109:
  %v1110 = ptrtoint ptr %a1 to i64
  %v1111 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1112 = sub i64 %v1111, 1
  %v1113 = sub nsw i64 %v1110, %v1112
  %v1114 = inttoptr i64 %v1113 to ptr
  %v1115 = getelementptr i8, ptr %a0, i64 24
  %v1116 = load i64, ptr %v1115, align 8, !tbaa !3
  %v1117 = getelementptr i8, ptr %a0, i64 32
  %v1118 = load ptr, ptr %v1117, align 8, !tbaa !3
  %v1119 = ptrtoint ptr %v1114 to i64
  %v1120 = ashr i64 %v1119, 1
  %v1121 = and i64 %v1119, 1
  %v1122 = icmp ne i64 %v1121, 0
  %v1123 = icmp ult i64 %v1120, %v1116
  %v1124 = and i1 %v1122, %v1123
  br i1 %v1124, label %array.valid.1125, label %array.invalid.1126
array.invalid.1126:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1125:
  %v1127 = getelementptr i8, ptr %v1118, i64 %v1120
  %v1128 = load i8, ptr %v1127, align 1, !tbaa !4
  %v1129 = zext i8 %v1128 to i64
  %v1130 = shl i64 %v1129, 1
  %v1131 = or i64 %v1130, 1
  %v1132 = inttoptr i64 %v1131 to ptr
  %v1133 = ptrtoint ptr %v1132 to i64
  %v1134 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v1135 = icmp eq i64 %v1133, %v1134
  %v1136 = select i1 %v1135, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1137 = icmp eq ptr %v1136, inttoptr (i64 6 to ptr)
  br i1 %v1137, label %tail.yes.1138, label %tail.no.1139
tail.yes.1138:
  %v1140 = ptrtoint ptr %a1 to i64
  %v1141 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1142 = sub i64 %v1141, 1
  %v1143 = sub nsw i64 %v1140, %v1142
  %v1144 = inttoptr i64 %v1143 to ptr
  %v1145 = musttail call ptr @mlf.numeric.11.pi(ptr %a0, ptr %v1144)
  ret ptr %v1145
tail.no.1139:
  %v1146 = ptrtoint ptr %v1132 to i64
  %v1147 = ptrtoint ptr inttoptr (i64 27 to ptr) to i64
  %v1148 = icmp eq i64 %v1146, %v1147
  %v1149 = select i1 %v1148, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1150 = icmp eq ptr %v1149, inttoptr (i64 6 to ptr)
  br i1 %v1150, label %tail.yes.1151, label %tail.no.1152
tail.yes.1151:
  %v1153 = ptrtoint ptr %a1 to i64
  %v1154 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1155 = sub i64 %v1154, 1
  %v1156 = sub nsw i64 %v1153, %v1155
  %v1157 = inttoptr i64 %v1156 to ptr
  %v1158 = musttail call ptr @mlf.numeric.11.pi(ptr %a0, ptr %v1157)
  ret ptr %v1158
tail.no.1152:
  ret ptr %a1
}

define private ptr @mlf.numeric.11(ptr %a0, ptr %a1) alwaysinline {
entry:
  %v1095 = ptrtoint ptr %a1 to i64
  %v1096 = and i64 %v1095, 1
  %v1097 = icmp ne i64 %v1096, 0
  %v1098 = icmp ult i64 %v1095, 4294967296
  %v1099 = and i1 %v1097, %v1098
  %v1100 = and i1 true, %v1099
  br i1 %v1100, label %range.fast.1101, label %range.general.1102
range.fast.1101:
  %v1159 = musttail call ptr @mlf.numeric.11.pi(ptr %a0, ptr %a1)
  ret ptr %v1159
range.general.1102:
  %v1160 = ptrtoint ptr %a1 to i64
  %v1161 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v1162 = and i64 %v1160, %v1161
  %v1163 = and i64 %v1162, 1
  %v1164 = icmp ne i64 %v1163, 0
  br i1 %v1164, label %yes.1165, label %no.1166
yes.1165:
  %v1168 = icmp eq i64 %v1160, %v1161
  %v1169 = select i1 %v1168, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1167
no.1166:
  %v1170 = call ptr @mlf_eq_int(ptr %a1, ptr inttoptr (i64 1 to ptr))
  br label %join.1167
join.1167:
  %v1171 = phi ptr [ %v1169, %yes.1165 ], [ %v1170, %no.1166 ]
  %v1172 = icmp eq ptr %v1171, inttoptr (i64 6 to ptr)
  br i1 %v1172, label %tail.yes.1173, label %tail.no.1174
tail.yes.1173:
  ret ptr inttoptr (i64 1 to ptr)
tail.no.1174:
  %v1175 = ptrtoint ptr %a1 to i64
  %v1176 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1177 = and i64 %v1175, %v1176
  %v1178 = and i64 %v1177, 1
  %v1179 = icmp ne i64 %v1178, 0
  br i1 %v1179, label %yes.1180, label %no.1181
yes.1180:
  %v1183 = sub i64 %v1176, 1
  %v1184 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v1175, i64 %v1183)
  %v1185 = extractvalue { i64, i1 } %v1184, 0
  %v1186 = extractvalue { i64, i1 } %v1184, 1
  br i1 %v1186, label %yes.1187, label %no.1188
yes.1187:
  %v1190 = call ptr @mlf_sub_int(ptr %a1, ptr inttoptr (i64 3 to ptr))
  br label %join.1189
no.1188:
  %v1191 = inttoptr i64 %v1185 to ptr
  br label %join.1189
join.1189:
  %v1192 = phi ptr [ %v1190, %yes.1187 ], [ %v1191, %no.1188 ]
  br label %join.1182
no.1181:
  %v1193 = call ptr @mlf_sub_int(ptr %a1, ptr inttoptr (i64 3 to ptr))
  br label %join.1182
join.1182:
  %v1194 = phi ptr [ %v1192, %join.1189 ], [ %v1193, %no.1181 ]
  %v1195 = getelementptr i8, ptr %a0, i64 24
  %v1196 = load i64, ptr %v1195, align 8, !tbaa !3
  %v1197 = getelementptr i8, ptr %a0, i64 32
  %v1198 = load ptr, ptr %v1197, align 8, !tbaa !3
  %v1199 = ptrtoint ptr %v1194 to i64
  %v1200 = ashr i64 %v1199, 1
  %v1201 = and i64 %v1199, 1
  %v1202 = icmp ne i64 %v1201, 0
  %v1203 = icmp ult i64 %v1200, %v1196
  %v1204 = and i1 %v1202, %v1203
  br i1 %v1204, label %array.valid.1205, label %array.invalid.1206
array.invalid.1206:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1205:
  %v1207 = getelementptr i8, ptr %v1198, i64 %v1200
  %v1208 = load i8, ptr %v1207, align 1, !tbaa !4
  %v1209 = zext i8 %v1208 to i64
  %v1210 = shl i64 %v1209, 1
  %v1211 = or i64 %v1210, 1
  %v1212 = inttoptr i64 %v1211 to ptr
  %v1213 = ptrtoint ptr %v1212 to i64
  %v1214 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v1215 = icmp eq i64 %v1213, %v1214
  %v1216 = select i1 %v1215, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1217 = icmp eq ptr %v1216, inttoptr (i64 6 to ptr)
  br i1 %v1217, label %tail.yes.1218, label %tail.no.1219
tail.yes.1218:
  %v1220 = ptrtoint ptr %a1 to i64
  %v1221 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1222 = and i64 %v1220, %v1221
  %v1223 = and i64 %v1222, 1
  %v1224 = icmp ne i64 %v1223, 0
  br i1 %v1224, label %yes.1225, label %no.1226
yes.1225:
  %v1228 = sub i64 %v1221, 1
  %v1229 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v1220, i64 %v1228)
  %v1230 = extractvalue { i64, i1 } %v1229, 0
  %v1231 = extractvalue { i64, i1 } %v1229, 1
  br i1 %v1231, label %yes.1232, label %no.1233
yes.1232:
  %v1235 = call ptr @mlf_sub_int(ptr %a1, ptr inttoptr (i64 3 to ptr))
  br label %join.1234
no.1233:
  %v1236 = inttoptr i64 %v1230 to ptr
  br label %join.1234
join.1234:
  %v1237 = phi ptr [ %v1235, %yes.1232 ], [ %v1236, %no.1233 ]
  br label %join.1227
no.1226:
  %v1238 = call ptr @mlf_sub_int(ptr %a1, ptr inttoptr (i64 3 to ptr))
  br label %join.1227
join.1227:
  %v1239 = phi ptr [ %v1237, %join.1234 ], [ %v1238, %no.1226 ]
  %v1240 = musttail call ptr @mlf.numeric.11(ptr %a0, ptr %v1239)
  ret ptr %v1240
tail.no.1219:
  %v1241 = ptrtoint ptr %v1212 to i64
  %v1242 = ptrtoint ptr inttoptr (i64 27 to ptr) to i64
  %v1243 = icmp eq i64 %v1241, %v1242
  %v1244 = select i1 %v1243, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1245 = icmp eq ptr %v1244, inttoptr (i64 6 to ptr)
  br i1 %v1245, label %tail.yes.1246, label %tail.no.1247
tail.yes.1246:
  %v1248 = ptrtoint ptr %a1 to i64
  %v1249 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1250 = and i64 %v1248, %v1249
  %v1251 = and i64 %v1250, 1
  %v1252 = icmp ne i64 %v1251, 0
  br i1 %v1252, label %yes.1253, label %no.1254
yes.1253:
  %v1256 = sub i64 %v1249, 1
  %v1257 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v1248, i64 %v1256)
  %v1258 = extractvalue { i64, i1 } %v1257, 0
  %v1259 = extractvalue { i64, i1 } %v1257, 1
  br i1 %v1259, label %yes.1260, label %no.1261
yes.1260:
  %v1263 = call ptr @mlf_sub_int(ptr %a1, ptr inttoptr (i64 3 to ptr))
  br label %join.1262
no.1261:
  %v1264 = inttoptr i64 %v1258 to ptr
  br label %join.1262
join.1262:
  %v1265 = phi ptr [ %v1263, %yes.1260 ], [ %v1264, %no.1261 ]
  br label %join.1255
no.1254:
  %v1266 = call ptr @mlf_sub_int(ptr %a1, ptr inttoptr (i64 3 to ptr))
  br label %join.1255
join.1255:
  %v1267 = phi ptr [ %v1265, %join.1262 ], [ %v1266, %no.1254 ]
  %v1268 = musttail call ptr @mlf.numeric.11(ptr %a0, ptr %v1267)
  ret ptr %v1268
tail.no.1247:
  ret ptr %a1
}

define private ptr @mlf.numeric.8(ptr %a0, ptr %a1) alwaysinline {
entry:
  %v1305 = ptrtoint ptr %a0 to i64
  %v1306 = ptrtoint ptr %a1 to i64
  %v1307 = and i64 %v1305, %v1306
  %v1308 = and i64 %v1307, 1
  %v1309 = icmp ne i64 %v1308, 0
  br i1 %v1309, label %yes.1310, label %no.1311
yes.1310:
  %v1313 = icmp slt i64 %v1305, %v1306
  %v1314 = select i1 %v1313, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1312
no.1311:
  %v1315 = call ptr @mlf_lt_int(ptr %a0, ptr %a1)
  br label %join.1312
join.1312:
  %v1316 = phi ptr [ %v1314, %yes.1310 ], [ %v1315, %no.1311 ]
  %v1317 = icmp eq ptr %v1316, inttoptr (i64 6 to ptr)
  br i1 %v1317, label %tail.yes.1318, label %tail.no.1319
tail.yes.1318:
  %v1320 = ptrtoint ptr %a0 to i64
  %v1321 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v1322 = and i64 %v1320, %v1321
  %v1323 = and i64 %v1322, 1
  %v1324 = icmp ne i64 %v1323, 0
  br i1 %v1324, label %yes.1325, label %no.1326
yes.1325:
  %v1328 = ashr i64 %v1320, 1
  %v1329 = ashr i64 %v1321, 1
  %v1330 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v1328, i64 %v1329)
  %v1331 = extractvalue { i64, i1 } %v1330, 0
  %v1332 = extractvalue { i64, i1 } %v1330, 1
  %v1333 = xor i1 %v1332, true
  %v1334 = icmp sge i64 %v1331, -4611686018427387904
  %v1335 = icmp sle i64 %v1331, 4611686018427387903
  %v1336 = and i1 %v1334, %v1335
  %v1337 = and i1 %v1336, %v1333
  br i1 %v1337, label %yes.1338, label %no.1339
yes.1338:
  %v1341 = shl i64 %v1331, 1
  %v1342 = or i64 %v1341, 1
  %v1343 = inttoptr i64 %v1342 to ptr
  br label %join.1340
no.1339:
  %v1344 = call ptr @mlf_prim2(i64 14, ptr %a0, ptr inttoptr (i64 5 to ptr))
  br label %join.1340
join.1340:
  %v1345 = phi ptr [ %v1343, %yes.1338 ], [ %v1344, %no.1339 ]
  br label %join.1327
no.1326:
  %v1346 = call ptr @mlf_prim2(i64 14, ptr %a0, ptr inttoptr (i64 5 to ptr))
  br label %join.1327
join.1327:
  %v1347 = phi ptr [ %v1345, %join.1340 ], [ %v1346, %no.1326 ]
  %v1348 = musttail call ptr @mlf.numeric.8(ptr %v1347, ptr %a1)
  ret ptr %v1348
tail.no.1319:
  ret ptr %a0
}

define private ptr @mlf.numeric.0(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) alwaysinline {
entry:
  %v1351 = getelementptr i8, ptr %a0, i64 24
  %v1352 = load i64, ptr %v1351, align 8, !tbaa !3
  %v1353 = getelementptr i8, ptr %a0, i64 32
  %v1354 = load ptr, ptr %v1353, align 8, !tbaa !3
  %v1355 = getelementptr i8, ptr %a1, i64 24
  %v1356 = load i64, ptr %v1355, align 8, !tbaa !3
  %v1357 = getelementptr i8, ptr %a1, i64 32
  %v1358 = load ptr, ptr %v1357, align 8, !tbaa !3
  %v1359 = ptrtoint ptr %a2 to i64
  %v1360 = ptrtoint ptr %a3 to i64
  %v1361 = ptrtoint ptr %a4 to i64
  %v1362 = and i64 %v1359, 1
  %v1363 = icmp ne i64 %v1362, 0
  %v1364 = and i64 %v1360, 1
  %v1365 = icmp ne i64 %v1364, 0
  %v1366 = and i64 %v1361, 1
  %v1367 = icmp ne i64 %v1366, 0
  %v1368 = ashr i64 %v1359, 1
  %v1369 = ashr i64 %v1360, 1
  %v1370 = ashr i64 %v1361, 1
  %v1371 = icmp sge i64 %v1370, 0
  %v1372 = icmp sge i64 %v1368, %v1370
  %v1373 = icmp ule i64 %v1368, %v1352
  %v1374 = icmp ule i64 %v1369, %v1356
  %v1375 = sub i64 %v1356, %v1369
  %v1376 = icmp ule i64 %v1368, %v1375
  %v1377 = sub i64 %v1368, %v1370
  %v1378 = icmp ne ptr %v1354, %v1358
  %v1379 = icmp eq i64 %v1369, 0
  %v1380 = icmp uge i64 %v1369, %v1377
  %v1381 = or i1 %v1378, %v1379
  %v1382 = or i1 %v1381, %v1380
  %v1383 = and i1 true, %v1363
  %v1384 = and i1 %v1383, %v1365
  %v1385 = and i1 %v1384, %v1367
  %v1386 = and i1 %v1385, %v1371
  %v1387 = and i1 %v1386, %v1372
  %v1388 = and i1 %v1387, %v1373
  %v1389 = and i1 %v1388, %v1374
  %v1390 = and i1 %v1389, %v1376
  %v1391 = and i1 %v1390, %v1382
  br i1 %v1391, label %copy.bulk.1392, label %copy.scalar.1393
copy.bulk.1392:
  %v1394 = getelementptr i8, ptr %v1354, i64 %v1370
  %v1395 = add i64 %v1369, %v1370
  %v1396 = getelementptr i8, ptr %v1358, i64 %v1395
  call void @llvm.memmove.p0.p0.i64(ptr %v1396, ptr %v1394, i64 %v1377, i1 false)
  ret ptr inttoptr (i64 4 to ptr)
copy.scalar.1393:
  %v1397 = ptrtoint ptr %a4 to i64
  %v1398 = ptrtoint ptr %a2 to i64
  %v1399 = and i64 %v1397, %v1398
  %v1400 = and i64 %v1399, 1
  %v1401 = icmp ne i64 %v1400, 0
  br i1 %v1401, label %yes.1402, label %no.1403
yes.1402:
  %v1405 = icmp slt i64 %v1397, %v1398
  %v1406 = select i1 %v1405, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1404
no.1403:
  %v1407 = call ptr @mlf_lt_int(ptr %a4, ptr %a2)
  br label %join.1404
join.1404:
  %v1408 = phi ptr [ %v1406, %yes.1402 ], [ %v1407, %no.1403 ]
  %v1409 = icmp eq ptr %v1408, inttoptr (i64 6 to ptr)
  br i1 %v1409, label %tail.yes.1410, label %tail.no.1411
tail.yes.1410:
  %v1412 = ptrtoint ptr %a4 to i64
  %v1413 = ashr i64 %v1412, 1
  %v1414 = and i64 %v1412, 1
  %v1415 = icmp ne i64 %v1414, 0
  %v1416 = icmp ult i64 %v1413, %v1352
  %v1417 = and i1 %v1415, %v1416
  br i1 %v1417, label %array.valid.1418, label %array.invalid.1419
array.invalid.1419:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1418:
  %v1420 = getelementptr i8, ptr %v1354, i64 %v1413
  %v1421 = load i8, ptr %v1420, align 1, !tbaa !4
  %v1422 = zext i8 %v1421 to i64
  %v1423 = shl i64 %v1422, 1
  %v1424 = or i64 %v1423, 1
  %v1425 = inttoptr i64 %v1424 to ptr
  %v1426 = ptrtoint ptr %a3 to i64
  %v1427 = ptrtoint ptr %a4 to i64
  %v1428 = and i64 %v1426, %v1427
  %v1429 = and i64 %v1428, 1
  %v1430 = icmp ne i64 %v1429, 0
  br i1 %v1430, label %yes.1431, label %no.1432
yes.1431:
  %v1434 = sub i64 %v1427, 1
  %v1435 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1426, i64 %v1434)
  %v1436 = extractvalue { i64, i1 } %v1435, 0
  %v1437 = extractvalue { i64, i1 } %v1435, 1
  br i1 %v1437, label %yes.1438, label %no.1439
yes.1438:
  %v1441 = call ptr @mlf_add_int(ptr %a3, ptr %a4)
  br label %join.1440
no.1439:
  %v1442 = inttoptr i64 %v1436 to ptr
  br label %join.1440
join.1440:
  %v1443 = phi ptr [ %v1441, %yes.1438 ], [ %v1442, %no.1439 ]
  br label %join.1433
no.1432:
  %v1444 = call ptr @mlf_add_int(ptr %a3, ptr %a4)
  br label %join.1433
join.1433:
  %v1445 = phi ptr [ %v1443, %join.1440 ], [ %v1444, %no.1432 ]
  %v1446 = ptrtoint ptr %v1445 to i64
  %v1447 = ashr i64 %v1446, 1
  %v1448 = and i64 %v1446, 1
  %v1449 = icmp ne i64 %v1448, 0
  %v1450 = icmp ult i64 %v1447, %v1356
  %v1451 = and i1 %v1449, %v1450
  br i1 %v1451, label %array.valid.1452, label %array.invalid.1453
array.invalid.1453:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1452:
  %v1454 = getelementptr i8, ptr %v1358, i64 %v1447
  %v1455 = ptrtoint ptr %v1425 to i64
  %v1456 = ashr i64 %v1455, 1
  %v1457 = trunc i64 %v1456 to i8
  store i8 %v1457, ptr %v1454, align 1, !tbaa !4
  %v1458 = ptrtoint ptr %a4 to i64
  %v1459 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1460 = sub i64 %v1459, 1
  %v1461 = add nsw i64 %v1458, %v1460
  %v1462 = inttoptr i64 %v1461 to ptr
  %v1463 = musttail call ptr @mlf.numeric.0(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %v1462)
  ret ptr %v1463
tail.no.1411:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.numeric.53(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) {
entry:
  %v439 = alloca [5 x ptr], align 8
  %v440 = getelementptr ptr, ptr %v439, i64 0
  store ptr %a0, ptr %v440, align 8
  %v441 = getelementptr ptr, ptr %v439, i64 1
  store ptr %a1, ptr %v441, align 8
  %v442 = getelementptr ptr, ptr %v439, i64 2
  store ptr %a2, ptr %v442, align 8
  %v443 = getelementptr ptr, ptr %v439, i64 3
  store ptr %a3, ptr %v443, align 8
  %v444 = getelementptr ptr, ptr %v439, i64 4
  store ptr %a4, ptr %v444, align 8
  call void @mlf_gc_check(i64 5, ptr %v439)
  %v445 = call ptr @mlf_get_byte_line()
  %v446 = getelementptr i8, ptr %v445, i64 24
  %v447 = load i64, ptr %v446, align 8, !tbaa !3
  %v448 = getelementptr i8, ptr %v445, i64 32
  %v449 = load ptr, ptr %v448, align 8, !tbaa !3
  %v450 = shl i64 %v447, 1
  %v451 = or i64 %v450, 1
  %v452 = inttoptr i64 %v451 to ptr
  %v453 = ptrtoint ptr %v452 to i64
  %v454 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v455 = and i64 %v453, %v454
  %v456 = and i64 %v455, 1
  %v457 = icmp ne i64 %v456, 0
  br i1 %v457, label %yes.458, label %no.459
yes.458:
  %v461 = icmp eq i64 %v453, %v454
  %v462 = select i1 %v461, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.460
no.459:
  %v463 = call ptr @mlf_eq_int(ptr %v452, ptr inttoptr (i64 1 to ptr))
  br label %join.460
join.460:
  %v464 = phi ptr [ %v462, %yes.458 ], [ %v463, %no.459 ]
  %v465 = icmp eq ptr %v464, inttoptr (i64 6 to ptr)
  br i1 %v465, label %tail.yes.466, label %tail.no.467
tail.yes.466:
  %v1070 = call ptr @mlf.numeric.45(ptr %a0, ptr %a1, ptr %a2, ptr %a3)
  ret ptr %v1070
tail.no.467:
  %v1071 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v1072 = ashr i64 %v1071, 1
  %v1073 = and i64 %v1071, 1
  %v1074 = icmp ne i64 %v1073, 0
  %v1075 = icmp ult i64 %v1072, %v447
  %v1076 = and i1 %v1074, %v1075
  br i1 %v1076, label %array.valid.1077, label %array.invalid.1078
array.invalid.1078:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1077:
  %v1079 = getelementptr i8, ptr %v449, i64 %v1072
  %v1080 = load i8, ptr %v1079, align 1, !tbaa !4
  %v1081 = zext i8 %v1080 to i64
  %v1082 = shl i64 %v1081, 1
  %v1083 = or i64 %v1082, 1
  %v1084 = inttoptr i64 %v1083 to ptr
  %v1085 = ptrtoint ptr %v1084 to i64
  %v1086 = ptrtoint ptr inttoptr (i64 125 to ptr) to i64
  %v1087 = icmp eq i64 %v1085, %v1086
  %v1088 = select i1 %v1087, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1089 = icmp eq ptr %v1088, inttoptr (i64 6 to ptr)
  br i1 %v1089, label %tail.yes.1090, label %tail.no.1091
tail.yes.1090:
  %v1092 = call ptr @mlf.numeric.45(ptr %a0, ptr %a1, ptr %a2, ptr %a3)
  %v1093 = call ptr @mlf_put_bytes(ptr %v445, ptr inttoptr (i64 1 to ptr), ptr %v452)
  %v1094 = musttail call ptr @mlf.numeric.53(ptr %a0, ptr %a1, ptr %a2, ptr inttoptr (i64 1 to ptr), ptr %a4)
  ret ptr %v1094
tail.no.1091:
  %v1269 = call ptr @mlf.numeric.11(ptr %v445, ptr %v452)
  %v1270 = ptrtoint ptr %a3 to i64
  %v1271 = ptrtoint ptr %v1269 to i64
  %v1272 = and i64 %v1270, %v1271
  %v1273 = and i64 %v1272, 1
  %v1274 = icmp ne i64 %v1273, 0
  br i1 %v1274, label %yes.1275, label %no.1276
yes.1275:
  %v1278 = sub i64 %v1271, 1
  %v1279 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1270, i64 %v1278)
  %v1280 = extractvalue { i64, i1 } %v1279, 0
  %v1281 = extractvalue { i64, i1 } %v1279, 1
  br i1 %v1281, label %yes.1282, label %no.1283
yes.1282:
  %v1285 = call ptr @mlf_add_int(ptr %a3, ptr %v1269)
  br label %join.1284
no.1283:
  %v1286 = inttoptr i64 %v1280 to ptr
  br label %join.1284
join.1284:
  %v1287 = phi ptr [ %v1285, %yes.1282 ], [ %v1286, %no.1283 ]
  br label %join.1277
no.1276:
  %v1288 = call ptr @mlf_add_int(ptr %a3, ptr %v1269)
  br label %join.1277
join.1277:
  %v1289 = phi ptr [ %v1287, %join.1284 ], [ %v1288, %no.1276 ]
  %v1290 = ptrtoint ptr %a4 to i64
  %v1291 = ptrtoint ptr %v1289 to i64
  %v1292 = and i64 %v1290, %v1291
  %v1293 = and i64 %v1292, 1
  %v1294 = icmp ne i64 %v1293, 0
  br i1 %v1294, label %yes.1295, label %no.1296
yes.1295:
  %v1298 = icmp slt i64 %v1290, %v1291
  %v1299 = select i1 %v1298, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1297
no.1296:
  %v1300 = call ptr @mlf_lt_int(ptr %a4, ptr %v1289)
  br label %join.1297
join.1297:
  %v1301 = phi ptr [ %v1299, %yes.1295 ], [ %v1300, %no.1296 ]
  %v1302 = icmp eq ptr %v1301, inttoptr (i64 6 to ptr)
  br i1 %v1302, label %tail.yes.1303, label %tail.no.1304
tail.yes.1303:
  %v1349 = call ptr @mlf.numeric.8(ptr %a4, ptr %v1289)
  %v1350 = call ptr @mlf_new_array(i64 35, ptr %v1349, ptr inttoptr (i64 1 to ptr))
  %v1464 = call ptr @mlf.numeric.0(ptr %a2, ptr %v1350, ptr %a3, ptr inttoptr (i64 1 to ptr), ptr inttoptr (i64 1 to ptr))
  %v1465 = call ptr @mlf.numeric.0(ptr %v445, ptr %v1350, ptr %v1269, ptr %a3, ptr inttoptr (i64 1 to ptr))
  %v1466 = musttail call ptr @mlf.numeric.53(ptr %a0, ptr %a1, ptr %v1350, ptr %v1289, ptr %v1349)
  ret ptr %v1466
tail.no.1304:
  %v1467 = call ptr @mlf.numeric.0(ptr %v445, ptr %a2, ptr %v1269, ptr %a3, ptr inttoptr (i64 1 to ptr))
  %v1468 = musttail call ptr @mlf.numeric.53(ptr %a0, ptr %a1, ptr %a2, ptr %v1289, ptr %a4)
  ret ptr %v1468
}

define private ptr @mlf.code.1483(ptr %env, ptr %arg) {
entry:
  %v1484 = getelementptr i8, ptr %env, i64 24
  %v1485 = load ptr, ptr %v1484, align 8, !tbaa !3
  %v1486 = call ptr @mlf_prim1(i64 38, ptr %v1485)
  ret ptr %v1486
}

define private ptr @mlf.code.1541(ptr %env, ptr %arg) {
entry:
  %v1542 = getelementptr i8, ptr %env, i64 24
  %v1543 = load ptr, ptr %v1542, align 8, !tbaa !3
  %v1544 = call ptr @mlf_force(ptr %v1543)
  %v1545 = call ptr @mlf_prim2(i64 11, ptr %v1544, ptr inttoptr (i64 122881 to ptr))
  %v1546 = icmp eq ptr %v1545, inttoptr (i64 6 to ptr)
  br i1 %v1546, label %yes.1547, label %no.1548
yes.1547:
  br label %join.1549
no.1548:
  br label %join.1549
join.1549:
  %v1550 = phi ptr [ %v1544, %yes.1547 ], [ inttoptr (i64 122881 to ptr), %no.1548 ]
  ret ptr %v1550
}

define private ptr @mlf.code.1607(ptr %env, ptr %arg) {
entry:
  %v1608 = getelementptr i8, ptr %env, i64 24
  %v1609 = load ptr, ptr %v1608, align 8, !tbaa !3
  %v1610 = call ptr @mlf_force(ptr %v1609)
  %v1611 = call ptr @mlf_prim2(i64 11, ptr %v1610, ptr inttoptr (i64 121 to ptr))
  %v1612 = icmp eq ptr %v1611, inttoptr (i64 6 to ptr)
  br i1 %v1612, label %yes.1613, label %no.1614
yes.1613:
  br label %join.1615
no.1614:
  br label %join.1615
join.1615:
  %v1616 = phi ptr [ %v1610, %yes.1613 ], [ inttoptr (i64 121 to ptr), %no.1614 ]
  ret ptr %v1616
}

define private ptr @mlf.code.1686(ptr %env, ptr %arg) {
entry:
  %v1687 = getelementptr i8, ptr %env, i64 24
  %v1688 = load ptr, ptr %v1687, align 8, !tbaa !3
  %v1689 = getelementptr i8, ptr %env, i64 32
  %v1690 = load ptr, ptr %v1689, align 8, !tbaa !3
  %v1691 = call ptr @mlf_force(ptr %v1688)
  %v1692 = call ptr @mlf_force(ptr %v1690)
  %v1693 = call ptr @mlf_prim2(i64 9, ptr %v1691, ptr %v1692)
  ret ptr %v1693
}

define private ptr @mlf.code.1679(ptr %env, ptr %arg) {
entry:
  %v1680 = getelementptr i8, ptr %env, i64 24
  %v1681 = load ptr, ptr %v1680, align 8, !tbaa !3
  %v1682 = getelementptr i8, ptr %env, i64 32
  %v1683 = load ptr, ptr %v1682, align 8, !tbaa !3
  %v1684 = getelementptr i8, ptr %env, i64 40
  %v1685 = load ptr, ptr %v1684, align 8, !tbaa !3
  %v1694 = call ptr @mlf_env_new(i64 2)
  %v1695 = getelementptr i8, ptr %v1694, i64 24
  store ptr %v1683, ptr %v1695, align 8, !tbaa !3
  %v1696 = getelementptr i8, ptr %v1694, i64 32
  store ptr %v1685, ptr %v1696, align 8, !tbaa !3
  %v1697 = call ptr @mlf_thunk(ptr @mlf.code.1686, ptr %v1694)
  %v1698 = call ptr @mlf_prim2(i64 36, ptr %v1681, ptr %v1697)
  ret ptr %v1698
}

define private ptr @mlf.code.1719(ptr %env, ptr %arg) {
entry:
  %v1720 = getelementptr i8, ptr %env, i64 24
  %v1721 = load ptr, ptr %v1720, align 8, !tbaa !3
  %v1722 = getelementptr i8, ptr %env, i64 32
  %v1723 = load ptr, ptr %v1722, align 8, !tbaa !3
  %v1724 = call ptr @mlf_prim2(i64 36, ptr %v1721, ptr %v1723)
  ret ptr %v1724
}

define private ptr @mlf.code.1753(ptr %env, ptr %arg) {
entry:
  %v1754 = getelementptr i8, ptr %env, i64 24
  %v1755 = load ptr, ptr %v1754, align 8, !tbaa !3
  %v1756 = getelementptr i8, ptr %env, i64 32
  %v1757 = load ptr, ptr %v1756, align 8, !tbaa !3
  %v1758 = call ptr @mlf_force(ptr %v1755)
  %v1759 = call ptr @mlf_force(ptr %v1757)
  %v1760 = call ptr @mlf_prim2(i64 8, ptr %v1758, ptr %v1759)
  ret ptr %v1760
}

define private ptr @mlf.code.1744(ptr %env, ptr %arg) {
entry:
  %v1745 = getelementptr i8, ptr %env, i64 24
  %v1746 = load ptr, ptr %v1745, align 8, !tbaa !3
  %v1747 = getelementptr i8, ptr %env, i64 32
  %v1748 = load ptr, ptr %v1747, align 8, !tbaa !3
  %v1749 = getelementptr i8, ptr %env, i64 40
  %v1750 = load ptr, ptr %v1749, align 8, !tbaa !3
  %v1751 = getelementptr i8, ptr %env, i64 48
  %v1752 = load ptr, ptr %v1751, align 8, !tbaa !3
  %v1761 = call ptr @mlf_env_new(i64 2)
  %v1762 = getelementptr i8, ptr %v1761, i64 24
  store ptr %v1748, ptr %v1762, align 8, !tbaa !3
  %v1763 = getelementptr i8, ptr %v1761, i64 32
  store ptr %v1750, ptr %v1763, align 8, !tbaa !3
  %v1764 = call ptr @mlf_thunk(ptr @mlf.code.1753, ptr %v1761)
  %v1765 = call ptr @mlf_prim3(i64 37, ptr %v1746, ptr %v1764, ptr %v1752)
  ret ptr %v1765
}

define private ptr @mlf.code.1772(ptr %env, ptr %arg) {
entry:
  %v1773 = getelementptr i8, ptr %env, i64 24
  %v1774 = load ptr, ptr %v1773, align 8, !tbaa !3
  %v1775 = getelementptr i8, ptr %env, i64 32
  %v1776 = load ptr, ptr %v1775, align 8, !tbaa !3
  %v1777 = getelementptr i8, ptr %env, i64 40
  %v1778 = load ptr, ptr %v1777, align 8, !tbaa !3
  %v1779 = getelementptr i8, ptr %env, i64 48
  %v1780 = load ptr, ptr %v1779, align 8, !tbaa !3
  %v1781 = getelementptr i8, ptr %env, i64 56
  %v1782 = load ptr, ptr %v1781, align 8, !tbaa !3
  %v1783 = getelementptr i8, ptr %env, i64 64
  %v1784 = load ptr, ptr %v1783, align 8, !tbaa !3
  %v1785 = getelementptr i8, ptr %env, i64 72
  %v1786 = load ptr, ptr %v1785, align 8, !tbaa !3
  %v1787 = call ptr @mlf_force(ptr %v1784)
  %v1788 = call ptr @mlf_force(ptr %v1786)
  %v1789 = call ptr @mlf_prim2(i64 8, ptr %v1788, ptr inttoptr (i64 3 to ptr))
  %v1790 = call ptr @mlf_env_new(i64 7)
  %v1791 = getelementptr i8, ptr %v1790, i64 24
  store ptr %v1774, ptr %v1791, align 8, !tbaa !3
  %v1792 = getelementptr i8, ptr %v1790, i64 32
  store ptr %v1776, ptr %v1792, align 8, !tbaa !3
  %v1793 = getelementptr i8, ptr %v1790, i64 40
  store ptr %v1778, ptr %v1793, align 8, !tbaa !3
  %v1794 = getelementptr i8, ptr %v1790, i64 48
  store ptr %v1780, ptr %v1794, align 8, !tbaa !3
  %v1795 = getelementptr i8, ptr %v1790, i64 56
  store ptr %v1782, ptr %v1795, align 8, !tbaa !3
  %v1796 = getelementptr i8, ptr %v1790, i64 64
  store ptr %v1787, ptr %v1796, align 8, !tbaa !3
  %v1797 = getelementptr i8, ptr %v1790, i64 72
  store ptr %v1789, ptr %v1797, align 8, !tbaa !3
  %v1798 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1633, ptr %v1790)
  ret ptr %v1798
}

define private ptr @mlf.code.1729(ptr %env, ptr %arg) {
entry:
  %v1730 = getelementptr i8, ptr %env, i64 24
  %v1731 = load ptr, ptr %v1730, align 8, !tbaa !3
  %v1732 = getelementptr i8, ptr %env, i64 32
  %v1733 = load ptr, ptr %v1732, align 8, !tbaa !3
  %v1734 = getelementptr i8, ptr %env, i64 40
  %v1735 = load ptr, ptr %v1734, align 8, !tbaa !3
  %v1736 = getelementptr i8, ptr %env, i64 48
  %v1737 = load ptr, ptr %v1736, align 8, !tbaa !3
  %v1738 = getelementptr i8, ptr %env, i64 56
  %v1739 = load ptr, ptr %v1738, align 8, !tbaa !3
  %v1740 = getelementptr i8, ptr %env, i64 64
  %v1741 = load ptr, ptr %v1740, align 8, !tbaa !3
  %v1742 = getelementptr i8, ptr %env, i64 72
  %v1743 = load ptr, ptr %v1742, align 8, !tbaa !3
  %v1766 = call ptr @mlf_env_new(i64 4)
  %v1767 = getelementptr i8, ptr %v1766, i64 24
  store ptr %v1735, ptr %v1767, align 8, !tbaa !3
  %v1768 = getelementptr i8, ptr %v1766, i64 32
  store ptr %v1739, ptr %v1768, align 8, !tbaa !3
  %v1769 = getelementptr i8, ptr %v1766, i64 40
  store ptr %v1743, ptr %v1769, align 8, !tbaa !3
  %v1770 = getelementptr i8, ptr %v1766, i64 48
  store ptr %arg, ptr %v1770, align 8, !tbaa !3
  %v1771 = call ptr @mlf_thunk(ptr @mlf.code.1744, ptr %v1766)
  %v1799 = call ptr @mlf_env_new(i64 7)
  %v1800 = getelementptr i8, ptr %v1799, i64 24
  store ptr %v1731, ptr %v1800, align 8, !tbaa !3
  %v1801 = getelementptr i8, ptr %v1799, i64 32
  store ptr %v1733, ptr %v1801, align 8, !tbaa !3
  %v1802 = getelementptr i8, ptr %v1799, i64 40
  store ptr %v1735, ptr %v1802, align 8, !tbaa !3
  %v1803 = getelementptr i8, ptr %v1799, i64 48
  store ptr %v1737, ptr %v1803, align 8, !tbaa !3
  %v1804 = getelementptr i8, ptr %v1799, i64 56
  store ptr %v1739, ptr %v1804, align 8, !tbaa !3
  %v1805 = getelementptr i8, ptr %v1799, i64 64
  store ptr %v1741, ptr %v1805, align 8, !tbaa !3
  %v1806 = getelementptr i8, ptr %v1799, i64 72
  store ptr %v1743, ptr %v1806, align 8, !tbaa !3
  %v1807 = call ptr @mlf_closure(ptr @mlf.code.1772, ptr %v1799)
  %v1808 = call ptr @mlf_prim2(i64 1, ptr %v1771, ptr %v1807)
  ret ptr %v1808
}

define private ptr @mlf.code.1704(ptr %env, ptr %arg) {
entry:
  %v1705 = getelementptr i8, ptr %env, i64 24
  %v1706 = load ptr, ptr %v1705, align 8, !tbaa !3
  %v1707 = getelementptr i8, ptr %env, i64 32
  %v1708 = load ptr, ptr %v1707, align 8, !tbaa !3
  %v1709 = getelementptr i8, ptr %env, i64 40
  %v1710 = load ptr, ptr %v1709, align 8, !tbaa !3
  %v1711 = getelementptr i8, ptr %env, i64 48
  %v1712 = load ptr, ptr %v1711, align 8, !tbaa !3
  %v1713 = getelementptr i8, ptr %env, i64 56
  %v1714 = load ptr, ptr %v1713, align 8, !tbaa !3
  %v1715 = getelementptr i8, ptr %env, i64 64
  %v1716 = load ptr, ptr %v1715, align 8, !tbaa !3
  %v1717 = getelementptr i8, ptr %env, i64 72
  %v1718 = load ptr, ptr %v1717, align 8, !tbaa !3
  %v1725 = call ptr @mlf_env_new(i64 2)
  %v1726 = getelementptr i8, ptr %v1725, i64 24
  store ptr %v1706, ptr %v1726, align 8, !tbaa !3
  %v1727 = getelementptr i8, ptr %v1725, i64 32
  store ptr %arg, ptr %v1727, align 8, !tbaa !3
  %v1728 = call ptr @mlf_thunk(ptr @mlf.code.1719, ptr %v1725)
  %v1809 = call ptr @mlf_env_new(i64 7)
  %v1810 = getelementptr i8, ptr %v1809, i64 24
  store ptr %v1706, ptr %v1810, align 8, !tbaa !3
  %v1811 = getelementptr i8, ptr %v1809, i64 32
  store ptr %v1708, ptr %v1811, align 8, !tbaa !3
  %v1812 = getelementptr i8, ptr %v1809, i64 40
  store ptr %v1710, ptr %v1812, align 8, !tbaa !3
  %v1813 = getelementptr i8, ptr %v1809, i64 48
  store ptr %v1712, ptr %v1813, align 8, !tbaa !3
  %v1814 = getelementptr i8, ptr %v1809, i64 56
  store ptr %v1714, ptr %v1814, align 8, !tbaa !3
  %v1815 = getelementptr i8, ptr %v1809, i64 64
  store ptr %v1716, ptr %v1815, align 8, !tbaa !3
  %v1816 = getelementptr i8, ptr %v1809, i64 72
  store ptr %v1718, ptr %v1816, align 8, !tbaa !3
  %v1817 = call ptr @mlf_closure(ptr @mlf.code.1729, ptr %v1809)
  %v1818 = call ptr @mlf_prim2(i64 1, ptr %v1728, ptr %v1817)
  ret ptr %v1818
}

define private ptr @mlf.worker.24(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6) {
entry:
  %v1674 = call ptr @mlf_prim2(i64 11, ptr %a6, ptr %a5)
  %v1675 = icmp eq ptr %v1674, inttoptr (i64 6 to ptr)
  br i1 %v1675, label %yes.1676, label %no.1677
yes.1676:
  %v1699 = call ptr @mlf_env_new(i64 3)
  %v1700 = getelementptr i8, ptr %v1699, i64 24
  store ptr %a1, ptr %v1700, align 8, !tbaa !3
  %v1701 = getelementptr i8, ptr %v1699, i64 32
  store ptr %a3, ptr %v1701, align 8, !tbaa !3
  %v1702 = getelementptr i8, ptr %v1699, i64 40
  store ptr %a6, ptr %v1702, align 8, !tbaa !3
  %v1703 = call ptr @mlf_thunk(ptr @mlf.code.1679, ptr %v1699)
  %v1819 = call ptr @mlf_env_new(i64 7)
  %v1820 = getelementptr i8, ptr %v1819, i64 24
  store ptr %a0, ptr %v1820, align 8, !tbaa !3
  %v1821 = getelementptr i8, ptr %v1819, i64 32
  store ptr %a1, ptr %v1821, align 8, !tbaa !3
  %v1822 = getelementptr i8, ptr %v1819, i64 40
  store ptr %a2, ptr %v1822, align 8, !tbaa !3
  %v1823 = getelementptr i8, ptr %v1819, i64 48
  store ptr %a3, ptr %v1823, align 8, !tbaa !3
  %v1824 = getelementptr i8, ptr %v1819, i64 56
  store ptr %a4, ptr %v1824, align 8, !tbaa !3
  %v1825 = getelementptr i8, ptr %v1819, i64 64
  store ptr %a5, ptr %v1825, align 8, !tbaa !3
  %v1826 = getelementptr i8, ptr %v1819, i64 72
  store ptr %a6, ptr %v1826, align 8, !tbaa !3
  %v1827 = call ptr @mlf_closure(ptr @mlf.code.1704, ptr %v1819)
  %v1828 = call ptr @mlf_prim2(i64 1, ptr %v1703, ptr %v1827)
  br label %join.1678
no.1677:
  %v1829 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.1678
join.1678:
  %v1830 = phi ptr [ %v1828, %yes.1676 ], [ %v1829, %no.1677 ]
  ret ptr %v1830
}

define private ptr @mlf.numeric.entry.1633(ptr %env, ptr %arg) {
entry:
  %v1634 = getelementptr i8, ptr %env, i64 24
  %v1635 = load ptr, ptr %v1634, align 8, !tbaa !3
  %v1636 = getelementptr i8, ptr %env, i64 32
  %v1637 = load ptr, ptr %v1636, align 8, !tbaa !3
  %v1638 = getelementptr i8, ptr %env, i64 40
  %v1639 = load ptr, ptr %v1638, align 8, !tbaa !3
  %v1640 = getelementptr i8, ptr %env, i64 48
  %v1641 = load ptr, ptr %v1640, align 8, !tbaa !3
  %v1642 = getelementptr i8, ptr %env, i64 56
  %v1643 = load ptr, ptr %v1642, align 8, !tbaa !3
  %v1644 = getelementptr i8, ptr %env, i64 64
  %v1645 = load ptr, ptr %v1644, align 8, !tbaa !3
  %v1646 = getelementptr i8, ptr %env, i64 72
  %v1647 = load ptr, ptr %v1646, align 8, !tbaa !3
  %v1648 = call ptr @mlf_peek(ptr %v1635)
  %v1649 = call ptr @mlf_peek(ptr %v1637)
  %v1650 = call ptr @mlf_peek(ptr %v1639)
  %v1651 = call ptr @mlf_peek(ptr %v1641)
  %v1652 = call ptr @mlf_peek(ptr %v1643)
  %v1653 = call ptr @mlf_peek(ptr %v1645)
  %v1654 = call ptr @mlf_peek(ptr %v1647)
  %v1655 = icmp ne ptr %v1648, null
  %v1656 = icmp ne ptr %v1649, null
  %v1657 = icmp ne ptr %v1650, null
  %v1658 = icmp ne ptr %v1651, null
  %v1659 = icmp ne ptr %v1652, null
  %v1660 = icmp ne ptr %v1653, null
  %v1661 = icmp ne ptr %v1654, null
  %v1662 = and i1 true, %v1655
  %v1663 = and i1 %v1662, %v1656
  %v1664 = and i1 %v1663, %v1657
  %v1665 = and i1 %v1664, %v1658
  %v1666 = and i1 %v1665, %v1659
  %v1667 = and i1 %v1666, %v1660
  %v1668 = and i1 %v1667, %v1661
  br i1 %v1668, label %yes.1669, label %no.1670
yes.1669:
  %v1672 = call ptr @mlf.numeric.24(ptr %v1648, ptr %v1649, ptr %v1650, ptr %v1651, ptr %v1652, ptr %v1653, ptr %v1654)
  %v1673 = call ptr @mlf_prim1(i64 0, ptr %v1672)
  br label %join.1671
no.1670:
  %v1831 = call ptr @mlf_force(ptr %v1645)
  %v1832 = call ptr @mlf_force(ptr %v1647)
  %v1833 = call ptr @mlf.worker.24(ptr %v1635, ptr %v1637, ptr %v1639, ptr %v1641, ptr %v1643, ptr %v1831, ptr %v1832)
  br label %join.1671
join.1671:
  %v1834 = phi ptr [ %v1673, %yes.1669 ], [ %v1833, %no.1670 ]
  ret ptr %v1834
}

define private ptr @mlf.code.1620(ptr %env, ptr %arg) {
entry:
  %v1621 = getelementptr i8, ptr %env, i64 24
  %v1622 = load ptr, ptr %v1621, align 8, !tbaa !3
  %v1623 = getelementptr i8, ptr %env, i64 32
  %v1624 = load ptr, ptr %v1623, align 8, !tbaa !3
  %v1625 = getelementptr i8, ptr %env, i64 40
  %v1626 = load ptr, ptr %v1625, align 8, !tbaa !3
  %v1627 = getelementptr i8, ptr %env, i64 48
  %v1628 = load ptr, ptr %v1627, align 8, !tbaa !3
  %v1629 = getelementptr i8, ptr %env, i64 56
  %v1630 = load ptr, ptr %v1629, align 8, !tbaa !3
  %v1631 = getelementptr i8, ptr %env, i64 64
  %v1632 = load ptr, ptr %v1631, align 8, !tbaa !3
  %v1835 = call ptr @mlf_force(ptr %v1632)
  %v1836 = call ptr @mlf_env_new(i64 7)
  %v1837 = getelementptr i8, ptr %v1836, i64 24
  store ptr %v1622, ptr %v1837, align 8, !tbaa !3
  %v1838 = getelementptr i8, ptr %v1836, i64 32
  store ptr %v1624, ptr %v1838, align 8, !tbaa !3
  %v1839 = getelementptr i8, ptr %v1836, i64 40
  store ptr %v1626, ptr %v1839, align 8, !tbaa !3
  %v1840 = getelementptr i8, ptr %v1836, i64 48
  store ptr %v1628, ptr %v1840, align 8, !tbaa !3
  %v1841 = getelementptr i8, ptr %v1836, i64 56
  store ptr %v1630, ptr %v1841, align 8, !tbaa !3
  %v1842 = getelementptr i8, ptr %v1836, i64 64
  store ptr %v1835, ptr %v1842, align 8, !tbaa !3
  %v1843 = getelementptr i8, ptr %v1836, i64 72
  store ptr inttoptr (i64 1 to ptr), ptr %v1843, align 8, !tbaa !3
  %v1844 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1633, ptr %v1836)
  ret ptr %v1844
}

define private ptr @mlf.code.1875(ptr %env, ptr %arg) {
entry:
  %v1876 = getelementptr i8, ptr %env, i64 24
  %v1877 = load ptr, ptr %v1876, align 8, !tbaa !3
  %v1878 = getelementptr i8, ptr %env, i64 32
  %v1879 = load ptr, ptr %v1878, align 8, !tbaa !3
  %v1880 = call ptr @mlf_force(ptr %v1877)
  %v1881 = call ptr @mlf_force(ptr %v1879)
  %v1882 = call ptr @mlf_prim2(i64 8, ptr %v1880, ptr %v1881)
  ret ptr %v1882
}

define private ptr @mlf.code.1868(ptr %env, ptr %arg) {
entry:
  %v1869 = getelementptr i8, ptr %env, i64 24
  %v1870 = load ptr, ptr %v1869, align 8, !tbaa !3
  %v1871 = getelementptr i8, ptr %env, i64 32
  %v1872 = load ptr, ptr %v1871, align 8, !tbaa !3
  %v1873 = getelementptr i8, ptr %env, i64 40
  %v1874 = load ptr, ptr %v1873, align 8, !tbaa !3
  %v1883 = call ptr @mlf_env_new(i64 2)
  %v1884 = getelementptr i8, ptr %v1883, i64 24
  store ptr %v1872, ptr %v1884, align 8, !tbaa !3
  %v1885 = getelementptr i8, ptr %v1883, i64 32
  store ptr %v1874, ptr %v1885, align 8, !tbaa !3
  %v1886 = call ptr @mlf_thunk(ptr @mlf.code.1875, ptr %v1883)
  %v1887 = call ptr @mlf_prim3(i64 37, ptr %v1870, ptr %v1886, ptr inttoptr (i64 21 to ptr))
  ret ptr %v1887
}

define private ptr @mlf.code.1908(ptr %env, ptr %arg) {
entry:
  %v1909 = getelementptr i8, ptr %env, i64 24
  %v1910 = load ptr, ptr %v1909, align 8, !tbaa !3
  %v1911 = getelementptr i8, ptr %env, i64 32
  %v1912 = load ptr, ptr %v1911, align 8, !tbaa !3
  %v1913 = call ptr @mlf_force(ptr %v1910)
  %v1914 = call ptr @mlf_force(ptr %v1912)
  %v1915 = call ptr @mlf_prim2(i64 9, ptr %v1913, ptr %v1914)
  ret ptr %v1915
}

define private ptr @mlf.code.1923(ptr %env, ptr %arg) {
entry:
  %v1924 = getelementptr i8, ptr %env, i64 24
  %v1925 = load ptr, ptr %v1924, align 8, !tbaa !3
  %v1926 = getelementptr i8, ptr %env, i64 32
  %v1927 = load ptr, ptr %v1926, align 8, !tbaa !3
  %v1928 = call ptr @mlf_force(ptr %v1925)
  %v1929 = call ptr @mlf_force(ptr %v1927)
  %v1930 = call ptr @mlf_prim2(i64 8, ptr %v1928, ptr %v1929)
  %v1931 = call ptr @mlf_prim2(i64 8, ptr %v1930, ptr inttoptr (i64 3 to ptr))
  ret ptr %v1931
}

define private ptr @mlf.code.1893(ptr %env, ptr %arg) {
entry:
  %v1894 = getelementptr i8, ptr %env, i64 24
  %v1895 = load ptr, ptr %v1894, align 8, !tbaa !3
  %v1896 = getelementptr i8, ptr %env, i64 32
  %v1897 = load ptr, ptr %v1896, align 8, !tbaa !3
  %v1898 = getelementptr i8, ptr %env, i64 40
  %v1899 = load ptr, ptr %v1898, align 8, !tbaa !3
  %v1900 = getelementptr i8, ptr %env, i64 48
  %v1901 = load ptr, ptr %v1900, align 8, !tbaa !3
  %v1902 = getelementptr i8, ptr %env, i64 56
  %v1903 = load ptr, ptr %v1902, align 8, !tbaa !3
  %v1904 = getelementptr i8, ptr %env, i64 64
  %v1905 = load ptr, ptr %v1904, align 8, !tbaa !3
  %v1906 = getelementptr i8, ptr %env, i64 72
  %v1907 = load ptr, ptr %v1906, align 8, !tbaa !3
  %v1916 = call ptr @mlf_env_new(i64 2)
  %v1917 = getelementptr i8, ptr %v1916, i64 24
  store ptr %v1901, ptr %v1917, align 8, !tbaa !3
  %v1918 = getelementptr i8, ptr %v1916, i64 32
  store ptr %v1907, ptr %v1918, align 8, !tbaa !3
  %v1919 = call ptr @mlf_thunk(ptr @mlf.code.1908, ptr %v1916)
  %v1920 = call ptr @mlf_force(ptr %v1903)
  %v1921 = call ptr @mlf_force(ptr %v1907)
  %v1922 = call ptr @mlf_prim2(i64 9, ptr %v1920, ptr %v1921)
  %v1932 = call ptr @mlf_env_new(i64 2)
  %v1933 = getelementptr i8, ptr %v1932, i64 24
  store ptr %v1905, ptr %v1933, align 8, !tbaa !3
  %v1934 = getelementptr i8, ptr %v1932, i64 32
  store ptr %v1921, ptr %v1934, align 8, !tbaa !3
  %v1935 = call ptr @mlf_thunk(ptr @mlf.code.1923, ptr %v1932)
  %v1936 = call ptr @mlf_env_new(i64 6)
  %v1937 = getelementptr i8, ptr %v1936, i64 24
  store ptr %v1895, ptr %v1937, align 8, !tbaa !3
  %v1938 = getelementptr i8, ptr %v1936, i64 32
  store ptr %v1897, ptr %v1938, align 8, !tbaa !3
  %v1939 = getelementptr i8, ptr %v1936, i64 40
  store ptr %v1899, ptr %v1939, align 8, !tbaa !3
  %v1940 = getelementptr i8, ptr %v1936, i64 48
  store ptr %v1919, ptr %v1940, align 8, !tbaa !3
  %v1941 = getelementptr i8, ptr %v1936, i64 56
  store ptr %v1922, ptr %v1941, align 8, !tbaa !3
  %v1942 = getelementptr i8, ptr %v1936, i64 64
  store ptr %v1935, ptr %v1942, align 8, !tbaa !3
  %v1943 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1565, ptr %v1936)
  ret ptr %v1943
}

define private ptr @mlf.code.1853(ptr %env, ptr %arg) {
entry:
  %v1854 = getelementptr i8, ptr %env, i64 24
  %v1855 = load ptr, ptr %v1854, align 8, !tbaa !3
  %v1856 = getelementptr i8, ptr %env, i64 32
  %v1857 = load ptr, ptr %v1856, align 8, !tbaa !3
  %v1858 = getelementptr i8, ptr %env, i64 40
  %v1859 = load ptr, ptr %v1858, align 8, !tbaa !3
  %v1860 = getelementptr i8, ptr %env, i64 48
  %v1861 = load ptr, ptr %v1860, align 8, !tbaa !3
  %v1862 = getelementptr i8, ptr %env, i64 56
  %v1863 = load ptr, ptr %v1862, align 8, !tbaa !3
  %v1864 = getelementptr i8, ptr %env, i64 64
  %v1865 = load ptr, ptr %v1864, align 8, !tbaa !3
  %v1866 = getelementptr i8, ptr %env, i64 72
  %v1867 = load ptr, ptr %v1866, align 8, !tbaa !3
  %v1888 = call ptr @mlf_env_new(i64 3)
  %v1889 = getelementptr i8, ptr %v1888, i64 24
  store ptr %v1859, ptr %v1889, align 8, !tbaa !3
  %v1890 = getelementptr i8, ptr %v1888, i64 32
  store ptr %v1865, ptr %v1890, align 8, !tbaa !3
  %v1891 = getelementptr i8, ptr %v1888, i64 40
  store ptr %v1867, ptr %v1891, align 8, !tbaa !3
  %v1892 = call ptr @mlf_thunk(ptr @mlf.code.1868, ptr %v1888)
  %v1944 = call ptr @mlf_env_new(i64 7)
  %v1945 = getelementptr i8, ptr %v1944, i64 24
  store ptr %v1855, ptr %v1945, align 8, !tbaa !3
  %v1946 = getelementptr i8, ptr %v1944, i64 32
  store ptr %v1857, ptr %v1946, align 8, !tbaa !3
  %v1947 = getelementptr i8, ptr %v1944, i64 40
  store ptr %v1859, ptr %v1947, align 8, !tbaa !3
  %v1948 = getelementptr i8, ptr %v1944, i64 48
  store ptr %v1861, ptr %v1948, align 8, !tbaa !3
  %v1949 = getelementptr i8, ptr %v1944, i64 56
  store ptr %v1863, ptr %v1949, align 8, !tbaa !3
  %v1950 = getelementptr i8, ptr %v1944, i64 64
  store ptr %v1865, ptr %v1950, align 8, !tbaa !3
  %v1951 = getelementptr i8, ptr %v1944, i64 72
  store ptr %v1867, ptr %v1951, align 8, !tbaa !3
  %v1952 = call ptr @mlf_closure(ptr @mlf.code.1893, ptr %v1944)
  %v1953 = call ptr @mlf_prim2(i64 1, ptr %v1892, ptr %v1952)
  ret ptr %v1953
}

define private ptr @mlf.worker.35(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5) {
entry:
  %v1601 = call ptr @mlf_prim2(i64 10, ptr %a4, ptr inttoptr (i64 1 to ptr))
  %v1602 = icmp eq ptr %v1601, inttoptr (i64 6 to ptr)
  br i1 %v1602, label %yes.1603, label %no.1604
yes.1603:
  %v1606 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.1605
no.1604:
  %v1617 = call ptr @mlf_env_new(i64 1)
  %v1618 = getelementptr i8, ptr %v1617, i64 24
  store ptr %a4, ptr %v1618, align 8, !tbaa !3
  %v1619 = call ptr @mlf_thunk(ptr @mlf.code.1607, ptr %v1617)
  %v1845 = call ptr @mlf_env_new(i64 6)
  %v1846 = getelementptr i8, ptr %v1845, i64 24
  store ptr %a0, ptr %v1846, align 8, !tbaa !3
  %v1847 = getelementptr i8, ptr %v1845, i64 32
  store ptr %a1, ptr %v1847, align 8, !tbaa !3
  %v1848 = getelementptr i8, ptr %v1845, i64 40
  store ptr %a2, ptr %v1848, align 8, !tbaa !3
  %v1849 = getelementptr i8, ptr %v1845, i64 48
  store ptr %a3, ptr %v1849, align 8, !tbaa !3
  %v1850 = getelementptr i8, ptr %v1845, i64 56
  store ptr %a5, ptr %v1850, align 8, !tbaa !3
  %v1851 = getelementptr i8, ptr %v1845, i64 64
  store ptr %v1619, ptr %v1851, align 8, !tbaa !3
  %v1852 = call ptr @mlf_thunk(ptr @mlf.code.1620, ptr %v1845)
  %v1954 = call ptr @mlf_env_new(i64 7)
  %v1955 = getelementptr i8, ptr %v1954, i64 24
  store ptr %a0, ptr %v1955, align 8, !tbaa !3
  %v1956 = getelementptr i8, ptr %v1954, i64 32
  store ptr %a1, ptr %v1956, align 8, !tbaa !3
  %v1957 = getelementptr i8, ptr %v1954, i64 40
  store ptr %a2, ptr %v1957, align 8, !tbaa !3
  %v1958 = getelementptr i8, ptr %v1954, i64 48
  store ptr %a3, ptr %v1958, align 8, !tbaa !3
  %v1959 = getelementptr i8, ptr %v1954, i64 56
  store ptr %a4, ptr %v1959, align 8, !tbaa !3
  %v1960 = getelementptr i8, ptr %v1954, i64 64
  store ptr %a5, ptr %v1960, align 8, !tbaa !3
  %v1961 = getelementptr i8, ptr %v1954, i64 72
  store ptr %v1619, ptr %v1961, align 8, !tbaa !3
  %v1962 = call ptr @mlf_closure(ptr @mlf.code.1853, ptr %v1954)
  %v1963 = call ptr @mlf_prim2(i64 1, ptr %v1852, ptr %v1962)
  br label %join.1605
join.1605:
  %v1964 = phi ptr [ %v1606, %yes.1603 ], [ %v1963, %no.1604 ]
  ret ptr %v1964
}

define private ptr @mlf.numeric.entry.1565(ptr %env, ptr %arg) {
entry:
  %v1566 = getelementptr i8, ptr %env, i64 24
  %v1567 = load ptr, ptr %v1566, align 8, !tbaa !3
  %v1568 = getelementptr i8, ptr %env, i64 32
  %v1569 = load ptr, ptr %v1568, align 8, !tbaa !3
  %v1570 = getelementptr i8, ptr %env, i64 40
  %v1571 = load ptr, ptr %v1570, align 8, !tbaa !3
  %v1572 = getelementptr i8, ptr %env, i64 48
  %v1573 = load ptr, ptr %v1572, align 8, !tbaa !3
  %v1574 = getelementptr i8, ptr %env, i64 56
  %v1575 = load ptr, ptr %v1574, align 8, !tbaa !3
  %v1576 = getelementptr i8, ptr %env, i64 64
  %v1577 = load ptr, ptr %v1576, align 8, !tbaa !3
  %v1578 = call ptr @mlf_peek(ptr %v1567)
  %v1579 = call ptr @mlf_peek(ptr %v1569)
  %v1580 = call ptr @mlf_peek(ptr %v1571)
  %v1581 = call ptr @mlf_peek(ptr %v1573)
  %v1582 = call ptr @mlf_peek(ptr %v1575)
  %v1583 = call ptr @mlf_peek(ptr %v1577)
  %v1584 = icmp ne ptr %v1578, null
  %v1585 = icmp ne ptr %v1579, null
  %v1586 = icmp ne ptr %v1580, null
  %v1587 = icmp ne ptr %v1581, null
  %v1588 = icmp ne ptr %v1582, null
  %v1589 = icmp ne ptr %v1583, null
  %v1590 = and i1 true, %v1584
  %v1591 = and i1 %v1590, %v1585
  %v1592 = and i1 %v1591, %v1586
  %v1593 = and i1 %v1592, %v1587
  %v1594 = and i1 %v1593, %v1588
  %v1595 = and i1 %v1594, %v1589
  br i1 %v1595, label %yes.1596, label %no.1597
yes.1596:
  %v1599 = call ptr @mlf.numeric.35(ptr %v1578, ptr %v1579, ptr %v1580, ptr %v1581, ptr %v1582, ptr %v1583)
  %v1600 = call ptr @mlf_prim1(i64 0, ptr %v1599)
  br label %join.1598
no.1597:
  %v1965 = call ptr @mlf_force(ptr %v1575)
  %v1966 = call ptr @mlf.worker.35(ptr %v1567, ptr %v1569, ptr %v1571, ptr %v1573, ptr %v1965, ptr %v1577)
  br label %join.1598
join.1598:
  %v1967 = phi ptr [ %v1600, %yes.1596 ], [ %v1966, %no.1597 ]
  ret ptr %v1967
}

define private ptr @mlf.code.1968(ptr %env, ptr %arg) {
entry:
  %v1969 = getelementptr i8, ptr %env, i64 24
  %v1970 = load ptr, ptr %v1969, align 8, !tbaa !3
  %v1971 = call ptr @mlf_force(ptr %v1970)
  %v1972 = call ptr @mlf_prim2(i64 9, ptr %v1971, ptr inttoptr (i64 3 to ptr))
  ret ptr %v1972
}

define private ptr @mlf.code.1554(ptr %env, ptr %arg) {
entry:
  %v1555 = getelementptr i8, ptr %env, i64 24
  %v1556 = load ptr, ptr %v1555, align 8, !tbaa !3
  %v1557 = getelementptr i8, ptr %env, i64 32
  %v1558 = load ptr, ptr %v1557, align 8, !tbaa !3
  %v1559 = getelementptr i8, ptr %env, i64 40
  %v1560 = load ptr, ptr %v1559, align 8, !tbaa !3
  %v1561 = getelementptr i8, ptr %env, i64 48
  %v1562 = load ptr, ptr %v1561, align 8, !tbaa !3
  %v1563 = getelementptr i8, ptr %env, i64 56
  %v1564 = load ptr, ptr %v1563, align 8, !tbaa !3
  %v1973 = call ptr @mlf_env_new(i64 1)
  %v1974 = getelementptr i8, ptr %v1973, i64 24
  store ptr %v1562, ptr %v1974, align 8, !tbaa !3
  %v1975 = call ptr @mlf_thunk(ptr @mlf.code.1968, ptr %v1973)
  %v1976 = call ptr @mlf_force(ptr %v1564)
  %v1977 = call ptr @mlf_env_new(i64 6)
  %v1978 = getelementptr i8, ptr %v1977, i64 24
  store ptr %v1556, ptr %v1978, align 8, !tbaa !3
  %v1979 = getelementptr i8, ptr %v1977, i64 32
  store ptr %v1560, ptr %v1979, align 8, !tbaa !3
  %v1980 = getelementptr i8, ptr %v1977, i64 40
  store ptr %v1558, ptr %v1980, align 8, !tbaa !3
  %v1981 = getelementptr i8, ptr %v1977, i64 48
  store ptr %v1975, ptr %v1981, align 8, !tbaa !3
  %v1982 = getelementptr i8, ptr %v1977, i64 56
  store ptr %v1976, ptr %v1982, align 8, !tbaa !3
  %v1983 = getelementptr i8, ptr %v1977, i64 64
  store ptr inttoptr (i64 1 to ptr), ptr %v1983, align 8, !tbaa !3
  %v1984 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1565, ptr %v1977)
  ret ptr %v1984
}

define private ptr @mlf.code.2008(ptr %env, ptr %arg) {
entry:
  %v2009 = getelementptr i8, ptr %env, i64 24
  %v2010 = load ptr, ptr %v2009, align 8, !tbaa !3
  %v2011 = call ptr @mlf_force(ptr %v2010)
  %v2012 = call ptr @mlf_prim2(i64 8, ptr %v2011, ptr inttoptr (i64 119 to ptr))
  %v2013 = call ptr @mlf_prim2(i64 15, ptr %v2012, ptr inttoptr (i64 121 to ptr))
  %v2014 = call ptr @mlf_prim2(i64 8, ptr %v2011, ptr %v2013)
  ret ptr %v2014
}

define private ptr @mlf.code.2003(ptr %env, ptr %arg) {
entry:
  %v2004 = getelementptr i8, ptr %env, i64 24
  %v2005 = load ptr, ptr %v2004, align 8, !tbaa !3
  %v2006 = getelementptr i8, ptr %env, i64 32
  %v2007 = load ptr, ptr %v2006, align 8, !tbaa !3
  %v2015 = call ptr @mlf_env_new(i64 1)
  %v2016 = getelementptr i8, ptr %v2015, i64 24
  store ptr %v2007, ptr %v2016, align 8, !tbaa !3
  %v2017 = call ptr @mlf_thunk(ptr @mlf.code.2008, ptr %v2015)
  %v2018 = call ptr @mlf_prim3(i64 40, ptr %v2005, ptr inttoptr (i64 1 to ptr), ptr %v2017)
  ret ptr %v2018
}

define private ptr @mlf.code.2023(ptr %env, ptr %arg) {
entry:
  %v2024 = getelementptr i8, ptr %env, i64 24
  %v2025 = load ptr, ptr %v2024, align 8, !tbaa !3
  %v2026 = getelementptr i8, ptr %env, i64 32
  %v2027 = load ptr, ptr %v2026, align 8, !tbaa !3
  %v2028 = getelementptr i8, ptr %env, i64 40
  %v2029 = load ptr, ptr %v2028, align 8, !tbaa !3
  %v2030 = getelementptr i8, ptr %env, i64 48
  %v2031 = load ptr, ptr %v2030, align 8, !tbaa !3
  %v2032 = getelementptr i8, ptr %env, i64 56
  %v2033 = load ptr, ptr %v2032, align 8, !tbaa !3
  %v2034 = call ptr @mlf_force(ptr %v2031)
  %v2035 = call ptr @mlf_force(ptr %v2033)
  %v2036 = call ptr @mlf_prim2(i64 9, ptr %v2034, ptr %v2035)
  %v2037 = call ptr @mlf_env_new(i64 4)
  %v2038 = getelementptr i8, ptr %v2037, i64 24
  store ptr %v2025, ptr %v2038, align 8, !tbaa !3
  %v2039 = getelementptr i8, ptr %v2037, i64 32
  store ptr %v2027, ptr %v2039, align 8, !tbaa !3
  %v2040 = getelementptr i8, ptr %v2037, i64 40
  store ptr %v2029, ptr %v2040, align 8, !tbaa !3
  %v2041 = getelementptr i8, ptr %v2037, i64 48
  store ptr %v2036, ptr %v2041, align 8, !tbaa !3
  %v2042 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1509, ptr %v2037)
  ret ptr %v2042
}

define private ptr @mlf.code.1992(ptr %env, ptr %arg) {
entry:
  %v1993 = getelementptr i8, ptr %env, i64 24
  %v1994 = load ptr, ptr %v1993, align 8, !tbaa !3
  %v1995 = getelementptr i8, ptr %env, i64 32
  %v1996 = load ptr, ptr %v1995, align 8, !tbaa !3
  %v1997 = getelementptr i8, ptr %env, i64 40
  %v1998 = load ptr, ptr %v1997, align 8, !tbaa !3
  %v1999 = getelementptr i8, ptr %env, i64 48
  %v2000 = load ptr, ptr %v1999, align 8, !tbaa !3
  %v2001 = getelementptr i8, ptr %env, i64 56
  %v2002 = load ptr, ptr %v2001, align 8, !tbaa !3
  %v2019 = call ptr @mlf_env_new(i64 2)
  %v2020 = getelementptr i8, ptr %v2019, i64 24
  store ptr %v1996, ptr %v2020, align 8, !tbaa !3
  %v2021 = getelementptr i8, ptr %v2019, i64 32
  store ptr %v2002, ptr %v2021, align 8, !tbaa !3
  %v2022 = call ptr @mlf_thunk(ptr @mlf.code.2003, ptr %v2019)
  %v2043 = call ptr @mlf_env_new(i64 5)
  %v2044 = getelementptr i8, ptr %v2043, i64 24
  store ptr %v1994, ptr %v2044, align 8, !tbaa !3
  %v2045 = getelementptr i8, ptr %v2043, i64 32
  store ptr %v1996, ptr %v2045, align 8, !tbaa !3
  %v2046 = getelementptr i8, ptr %v2043, i64 40
  store ptr %v1998, ptr %v2046, align 8, !tbaa !3
  %v2047 = getelementptr i8, ptr %v2043, i64 48
  store ptr %v2000, ptr %v2047, align 8, !tbaa !3
  %v2048 = getelementptr i8, ptr %v2043, i64 56
  store ptr %v2002, ptr %v2048, align 8, !tbaa !3
  %v2049 = call ptr @mlf_closure(ptr @mlf.code.2023, ptr %v2043)
  %v2050 = call ptr @mlf_prim2(i64 1, ptr %v2022, ptr %v2049)
  ret ptr %v2050
}

define private ptr @mlf.worker.45(ptr %a0, ptr %a1, ptr %a2, ptr %a3) {
entry:
  %v1535 = call ptr @mlf_prim2(i64 10, ptr %a3, ptr inttoptr (i64 1 to ptr))
  %v1536 = icmp eq ptr %v1535, inttoptr (i64 6 to ptr)
  br i1 %v1536, label %yes.1537, label %no.1538
yes.1537:
  %v1540 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.1539
no.1538:
  %v1551 = call ptr @mlf_env_new(i64 1)
  %v1552 = getelementptr i8, ptr %v1551, i64 24
  store ptr %a3, ptr %v1552, align 8, !tbaa !3
  %v1553 = call ptr @mlf_thunk(ptr @mlf.code.1541, ptr %v1551)
  %v1985 = call ptr @mlf_env_new(i64 5)
  %v1986 = getelementptr i8, ptr %v1985, i64 24
  store ptr %a0, ptr %v1986, align 8, !tbaa !3
  %v1987 = getelementptr i8, ptr %v1985, i64 32
  store ptr %a1, ptr %v1987, align 8, !tbaa !3
  %v1988 = getelementptr i8, ptr %v1985, i64 40
  store ptr %a2, ptr %v1988, align 8, !tbaa !3
  %v1989 = getelementptr i8, ptr %v1985, i64 48
  store ptr %a3, ptr %v1989, align 8, !tbaa !3
  %v1990 = getelementptr i8, ptr %v1985, i64 56
  store ptr %v1553, ptr %v1990, align 8, !tbaa !3
  %v1991 = call ptr @mlf_thunk(ptr @mlf.code.1554, ptr %v1985)
  %v2051 = call ptr @mlf_env_new(i64 5)
  %v2052 = getelementptr i8, ptr %v2051, i64 24
  store ptr %a0, ptr %v2052, align 8, !tbaa !3
  %v2053 = getelementptr i8, ptr %v2051, i64 32
  store ptr %a1, ptr %v2053, align 8, !tbaa !3
  %v2054 = getelementptr i8, ptr %v2051, i64 40
  store ptr %a2, ptr %v2054, align 8, !tbaa !3
  %v2055 = getelementptr i8, ptr %v2051, i64 48
  store ptr %a3, ptr %v2055, align 8, !tbaa !3
  %v2056 = getelementptr i8, ptr %v2051, i64 56
  store ptr %v1553, ptr %v2056, align 8, !tbaa !3
  %v2057 = call ptr @mlf_closure(ptr @mlf.code.1992, ptr %v2051)
  %v2058 = call ptr @mlf_prim2(i64 1, ptr %v1991, ptr %v2057)
  br label %join.1539
join.1539:
  %v2059 = phi ptr [ %v1540, %yes.1537 ], [ %v2058, %no.1538 ]
  ret ptr %v2059
}

define private ptr @mlf.numeric.entry.1509(ptr %env, ptr %arg) {
entry:
  %v1510 = getelementptr i8, ptr %env, i64 24
  %v1511 = load ptr, ptr %v1510, align 8, !tbaa !3
  %v1512 = getelementptr i8, ptr %env, i64 32
  %v1513 = load ptr, ptr %v1512, align 8, !tbaa !3
  %v1514 = getelementptr i8, ptr %env, i64 40
  %v1515 = load ptr, ptr %v1514, align 8, !tbaa !3
  %v1516 = getelementptr i8, ptr %env, i64 48
  %v1517 = load ptr, ptr %v1516, align 8, !tbaa !3
  %v1518 = call ptr @mlf_peek(ptr %v1511)
  %v1519 = call ptr @mlf_peek(ptr %v1513)
  %v1520 = call ptr @mlf_peek(ptr %v1515)
  %v1521 = call ptr @mlf_peek(ptr %v1517)
  %v1522 = icmp ne ptr %v1518, null
  %v1523 = icmp ne ptr %v1519, null
  %v1524 = icmp ne ptr %v1520, null
  %v1525 = icmp ne ptr %v1521, null
  %v1526 = and i1 true, %v1522
  %v1527 = and i1 %v1526, %v1523
  %v1528 = and i1 %v1527, %v1524
  %v1529 = and i1 %v1528, %v1525
  br i1 %v1529, label %yes.1530, label %no.1531
yes.1530:
  %v1533 = call ptr @mlf.numeric.45(ptr %v1518, ptr %v1519, ptr %v1520, ptr %v1521)
  %v1534 = call ptr @mlf_prim1(i64 0, ptr %v1533)
  br label %join.1532
no.1531:
  %v2060 = call ptr @mlf_force(ptr %v1517)
  %v2061 = call ptr @mlf.worker.45(ptr %v1511, ptr %v1513, ptr %v1515, ptr %v2060)
  br label %join.1532
join.1532:
  %v2062 = phi ptr [ %v1534, %yes.1530 ], [ %v2061, %no.1531 ]
  ret ptr %v2062
}

define private ptr @mlf.code.2070(ptr %env, ptr %arg) {
entry:
  %v2071 = getelementptr i8, ptr %env, i64 24
  %v2072 = load ptr, ptr %v2071, align 8, !tbaa !3
  %v2073 = call ptr @mlf_prim2(i64 36, ptr %v2072, ptr inttoptr (i64 1 to ptr))
  ret ptr %v2073
}

define private ptr @mlf.code.2098(ptr %env, ptr %arg) {
entry:
  %v2099 = getelementptr i8, ptr %env, i64 24
  %v2100 = load ptr, ptr %v2099, align 8, !tbaa !3
  %v2101 = getelementptr i8, ptr %env, i64 32
  %v2102 = load ptr, ptr %v2101, align 8, !tbaa !3
  %v2103 = getelementptr i8, ptr %env, i64 40
  %v2104 = load ptr, ptr %v2103, align 8, !tbaa !3
  %v2105 = getelementptr i8, ptr %env, i64 48
  %v2106 = load ptr, ptr %v2105, align 8, !tbaa !3
  %v2107 = call ptr @mlf_force(ptr %v2106)
  %v2108 = call ptr @mlf_env_new(i64 4)
  %v2109 = getelementptr i8, ptr %v2108, i64 24
  store ptr %v2100, ptr %v2109, align 8, !tbaa !3
  %v2110 = getelementptr i8, ptr %v2108, i64 32
  store ptr %v2102, ptr %v2110, align 8, !tbaa !3
  %v2111 = getelementptr i8, ptr %v2108, i64 40
  store ptr %v2104, ptr %v2111, align 8, !tbaa !3
  %v2112 = getelementptr i8, ptr %v2108, i64 48
  store ptr %v2107, ptr %v2112, align 8, !tbaa !3
  %v2113 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1509, ptr %v2108)
  ret ptr %v2113
}

define private ptr @mlf.code.2133(ptr %env, ptr %arg) {
entry:
  %v2134 = getelementptr i8, ptr %env, i64 24
  %v2135 = load ptr, ptr %v2134, align 8, !tbaa !3
  %v2136 = getelementptr i8, ptr %env, i64 32
  %v2137 = load ptr, ptr %v2136, align 8, !tbaa !3
  %v2138 = call ptr @mlf_prim3(i64 40, ptr %v2135, ptr inttoptr (i64 1 to ptr), ptr %v2137)
  ret ptr %v2138
}

define private ptr @mlf.code.2143(ptr %env, ptr %arg) {
entry:
  %v2144 = getelementptr i8, ptr %env, i64 24
  %v2145 = load ptr, ptr %v2144, align 8, !tbaa !3
  %v2146 = getelementptr i8, ptr %env, i64 32
  %v2147 = load ptr, ptr %v2146, align 8, !tbaa !3
  %v2148 = getelementptr i8, ptr %env, i64 40
  %v2149 = load ptr, ptr %v2148, align 8, !tbaa !3
  %v2150 = getelementptr i8, ptr %env, i64 48
  %v2151 = load ptr, ptr %v2150, align 8, !tbaa !3
  %v2152 = call ptr @mlf_env_new(i64 5)
  %v2153 = getelementptr i8, ptr %v2152, i64 24
  store ptr %v2145, ptr %v2153, align 8, !tbaa !3
  %v2154 = getelementptr i8, ptr %v2152, i64 32
  store ptr %v2147, ptr %v2154, align 8, !tbaa !3
  %v2155 = getelementptr i8, ptr %v2152, i64 40
  store ptr %v2149, ptr %v2155, align 8, !tbaa !3
  %v2156 = getelementptr i8, ptr %v2152, i64 48
  store ptr inttoptr (i64 1 to ptr), ptr %v2156, align 8, !tbaa !3
  %v2157 = getelementptr i8, ptr %v2152, i64 56
  store ptr %v2151, ptr %v2157, align 8, !tbaa !3
  %v2158 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.410, ptr %v2152)
  ret ptr %v2158
}

define private ptr @mlf.code.2120(ptr %env, ptr %arg) {
entry:
  %v2121 = getelementptr i8, ptr %env, i64 24
  %v2122 = load ptr, ptr %v2121, align 8, !tbaa !3
  %v2123 = getelementptr i8, ptr %env, i64 32
  %v2124 = load ptr, ptr %v2123, align 8, !tbaa !3
  %v2125 = getelementptr i8, ptr %env, i64 40
  %v2126 = load ptr, ptr %v2125, align 8, !tbaa !3
  %v2127 = getelementptr i8, ptr %env, i64 48
  %v2128 = load ptr, ptr %v2127, align 8, !tbaa !3
  %v2129 = getelementptr i8, ptr %env, i64 56
  %v2130 = load ptr, ptr %v2129, align 8, !tbaa !3
  %v2131 = getelementptr i8, ptr %env, i64 64
  %v2132 = load ptr, ptr %v2131, align 8, !tbaa !3
  %v2139 = call ptr @mlf_env_new(i64 2)
  %v2140 = getelementptr i8, ptr %v2139, i64 24
  store ptr %v2130, ptr %v2140, align 8, !tbaa !3
  %v2141 = getelementptr i8, ptr %v2139, i64 32
  store ptr %v2132, ptr %v2141, align 8, !tbaa !3
  %v2142 = call ptr @mlf_thunk(ptr @mlf.code.2133, ptr %v2139)
  %v2159 = call ptr @mlf_env_new(i64 4)
  %v2160 = getelementptr i8, ptr %v2159, i64 24
  store ptr %v2122, ptr %v2160, align 8, !tbaa !3
  %v2161 = getelementptr i8, ptr %v2159, i64 32
  store ptr %v2124, ptr %v2161, align 8, !tbaa !3
  %v2162 = getelementptr i8, ptr %v2159, i64 40
  store ptr %v2126, ptr %v2162, align 8, !tbaa !3
  %v2163 = getelementptr i8, ptr %v2159, i64 48
  store ptr %v2128, ptr %v2163, align 8, !tbaa !3
  %v2164 = call ptr @mlf_closure(ptr @mlf.code.2143, ptr %v2159)
  %v2165 = call ptr @mlf_prim2(i64 1, ptr %v2142, ptr %v2164)
  ret ptr %v2165
}

define private ptr @mlf.code.2207(ptr %env, ptr %arg) {
entry:
  %v2208 = getelementptr i8, ptr %env, i64 24
  %v2209 = load ptr, ptr %v2208, align 8, !tbaa !3
  %v2210 = call ptr @mlf_force(ptr %v2209)
  %v2211 = call ptr @mlf_prim2(i64 9, ptr %v2210, ptr inttoptr (i64 3 to ptr))
  ret ptr %v2211
}

define private ptr @mlf.code.2202(ptr %env, ptr %arg) {
entry:
  %v2203 = getelementptr i8, ptr %env, i64 24
  %v2204 = load ptr, ptr %v2203, align 8, !tbaa !3
  %v2205 = getelementptr i8, ptr %env, i64 32
  %v2206 = load ptr, ptr %v2205, align 8, !tbaa !3
  %v2212 = call ptr @mlf_env_new(i64 1)
  %v2213 = getelementptr i8, ptr %v2212, i64 24
  store ptr %v2206, ptr %v2213, align 8, !tbaa !3
  %v2214 = call ptr @mlf_thunk(ptr @mlf.code.2207, ptr %v2212)
  %v2215 = call ptr @mlf_prim2(i64 36, ptr %v2204, ptr %v2214)
  ret ptr %v2215
}

define private ptr @mlf.code.2220(ptr %env, ptr %arg) {
entry:
  %v2221 = getelementptr i8, ptr %env, i64 24
  %v2222 = load ptr, ptr %v2221, align 8, !tbaa !3
  %v2223 = getelementptr i8, ptr %env, i64 32
  %v2224 = load ptr, ptr %v2223, align 8, !tbaa !3
  %v2225 = call ptr @mlf_force(ptr %arg)
  %v2226 = call ptr @mlf_prim2(i64 10, ptr %v2225, ptr inttoptr (i64 21 to ptr))
  %v2227 = icmp eq ptr %v2226, inttoptr (i64 6 to ptr)
  br i1 %v2227, label %yes.2228, label %no.2229
yes.2228:
  %v2231 = call ptr @mlf_force(ptr %v2224)
  %v2232 = call ptr @mlf_prim2(i64 9, ptr %v2231, ptr inttoptr (i64 3 to ptr))
  %v2233 = call ptr @mlf_env_new(i64 2)
  %v2234 = getelementptr i8, ptr %v2233, i64 24
  store ptr %v2222, ptr %v2234, align 8, !tbaa !3
  %v2235 = getelementptr i8, ptr %v2233, i64 32
  store ptr %v2232, ptr %v2235, align 8, !tbaa !3
  %v2236 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2180, ptr %v2233)
  br label %join.2230
no.2229:
  %v2237 = call ptr @mlf_prim2(i64 10, ptr %v2225, ptr inttoptr (i64 27 to ptr))
  %v2238 = icmp eq ptr %v2237, inttoptr (i64 6 to ptr)
  br i1 %v2238, label %yes.2239, label %no.2240
yes.2239:
  %v2242 = call ptr @mlf_force(ptr %v2224)
  %v2243 = call ptr @mlf_prim2(i64 9, ptr %v2242, ptr inttoptr (i64 3 to ptr))
  %v2244 = call ptr @mlf_env_new(i64 2)
  %v2245 = getelementptr i8, ptr %v2244, i64 24
  store ptr %v2222, ptr %v2245, align 8, !tbaa !3
  %v2246 = getelementptr i8, ptr %v2244, i64 32
  store ptr %v2243, ptr %v2246, align 8, !tbaa !3
  %v2247 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2180, ptr %v2244)
  br label %join.2241
no.2240:
  %v2248 = call ptr @mlf_prim1(i64 0, ptr %v2224)
  br label %join.2241
join.2241:
  %v2249 = phi ptr [ %v2247, %yes.2239 ], [ %v2248, %no.2240 ]
  br label %join.2230
join.2230:
  %v2250 = phi ptr [ %v2236, %yes.2228 ], [ %v2249, %join.2241 ]
  ret ptr %v2250
}

define private ptr @mlf.worker.11(ptr %a0, ptr %a1) {
entry:
  %v2196 = call ptr @mlf_prim2(i64 10, ptr %a1, ptr inttoptr (i64 1 to ptr))
  %v2197 = icmp eq ptr %v2196, inttoptr (i64 6 to ptr)
  br i1 %v2197, label %yes.2198, label %no.2199
yes.2198:
  %v2201 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 1 to ptr))
  br label %join.2200
no.2199:
  %v2216 = call ptr @mlf_env_new(i64 2)
  %v2217 = getelementptr i8, ptr %v2216, i64 24
  store ptr %a0, ptr %v2217, align 8, !tbaa !3
  %v2218 = getelementptr i8, ptr %v2216, i64 32
  store ptr %a1, ptr %v2218, align 8, !tbaa !3
  %v2219 = call ptr @mlf_thunk(ptr @mlf.code.2202, ptr %v2216)
  %v2251 = call ptr @mlf_env_new(i64 2)
  %v2252 = getelementptr i8, ptr %v2251, i64 24
  store ptr %a0, ptr %v2252, align 8, !tbaa !3
  %v2253 = getelementptr i8, ptr %v2251, i64 32
  store ptr %a1, ptr %v2253, align 8, !tbaa !3
  %v2254 = call ptr @mlf_closure(ptr @mlf.code.2220, ptr %v2251)
  %v2255 = call ptr @mlf_prim2(i64 1, ptr %v2219, ptr %v2254)
  br label %join.2200
join.2200:
  %v2256 = phi ptr [ %v2201, %yes.2198 ], [ %v2255, %no.2199 ]
  ret ptr %v2256
}

define private ptr @mlf.numeric.entry.2180(ptr %env, ptr %arg) {
entry:
  %v2181 = getelementptr i8, ptr %env, i64 24
  %v2182 = load ptr, ptr %v2181, align 8, !tbaa !3
  %v2183 = getelementptr i8, ptr %env, i64 32
  %v2184 = load ptr, ptr %v2183, align 8, !tbaa !3
  %v2185 = call ptr @mlf_peek(ptr %v2182)
  %v2186 = call ptr @mlf_peek(ptr %v2184)
  %v2187 = icmp ne ptr %v2185, null
  %v2188 = icmp ne ptr %v2186, null
  %v2189 = and i1 true, %v2187
  %v2190 = and i1 %v2189, %v2188
  br i1 %v2190, label %yes.2191, label %no.2192
yes.2191:
  %v2194 = call ptr @mlf.numeric.11(ptr %v2185, ptr %v2186)
  %v2195 = call ptr @mlf_prim1(i64 0, ptr %v2194)
  br label %join.2193
no.2192:
  %v2257 = call ptr @mlf_force(ptr %v2184)
  %v2258 = call ptr @mlf.worker.11(ptr %v2182, ptr %v2257)
  br label %join.2193
join.2193:
  %v2259 = phi ptr [ %v2195, %yes.2191 ], [ %v2258, %no.2192 ]
  ret ptr %v2259
}

define private ptr @mlf.code.2175(ptr %env, ptr %arg) {
entry:
  %v2176 = getelementptr i8, ptr %env, i64 24
  %v2177 = load ptr, ptr %v2176, align 8, !tbaa !3
  %v2178 = getelementptr i8, ptr %env, i64 32
  %v2179 = load ptr, ptr %v2178, align 8, !tbaa !3
  %v2260 = call ptr @mlf_force(ptr %v2179)
  %v2261 = call ptr @mlf_env_new(i64 2)
  %v2262 = getelementptr i8, ptr %v2261, i64 24
  store ptr %v2177, ptr %v2262, align 8, !tbaa !3
  %v2263 = getelementptr i8, ptr %v2261, i64 32
  store ptr %v2260, ptr %v2263, align 8, !tbaa !3
  %v2264 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2180, ptr %v2261)
  ret ptr %v2264
}

define private ptr @mlf.worker.8(ptr %a0, ptr %a1) {
entry:
  %v2312 = call ptr @mlf_prim2(i64 11, ptr %a0, ptr %a1)
  %v2313 = icmp eq ptr %v2312, inttoptr (i64 6 to ptr)
  br i1 %v2313, label %yes.2314, label %no.2315
yes.2314:
  %v2317 = call ptr @mlf_prim2(i64 14, ptr %a0, ptr inttoptr (i64 5 to ptr))
  %v2318 = call ptr @mlf_env_new(i64 2)
  %v2319 = getelementptr i8, ptr %v2318, i64 24
  store ptr %v2317, ptr %v2319, align 8, !tbaa !3
  %v2320 = getelementptr i8, ptr %v2318, i64 32
  store ptr %a1, ptr %v2320, align 8, !tbaa !3
  %v2321 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2296, ptr %v2318)
  br label %join.2316
no.2315:
  %v2322 = call ptr @mlf_prim1(i64 0, ptr %a0)
  br label %join.2316
join.2316:
  %v2323 = phi ptr [ %v2321, %yes.2314 ], [ %v2322, %no.2315 ]
  ret ptr %v2323
}

define private ptr @mlf.numeric.entry.2296(ptr %env, ptr %arg) {
entry:
  %v2297 = getelementptr i8, ptr %env, i64 24
  %v2298 = load ptr, ptr %v2297, align 8, !tbaa !3
  %v2299 = getelementptr i8, ptr %env, i64 32
  %v2300 = load ptr, ptr %v2299, align 8, !tbaa !3
  %v2301 = call ptr @mlf_peek(ptr %v2298)
  %v2302 = call ptr @mlf_peek(ptr %v2300)
  %v2303 = icmp ne ptr %v2301, null
  %v2304 = icmp ne ptr %v2302, null
  %v2305 = and i1 true, %v2303
  %v2306 = and i1 %v2305, %v2304
  br i1 %v2306, label %yes.2307, label %no.2308
yes.2307:
  %v2310 = call ptr @mlf.numeric.8(ptr %v2301, ptr %v2302)
  %v2311 = call ptr @mlf_prim1(i64 0, ptr %v2310)
  br label %join.2309
no.2308:
  %v2324 = call ptr @mlf_force(ptr %v2298)
  %v2325 = call ptr @mlf_force(ptr %v2300)
  %v2326 = call ptr @mlf.worker.8(ptr %v2324, ptr %v2325)
  br label %join.2309
join.2309:
  %v2327 = phi ptr [ %v2311, %yes.2307 ], [ %v2326, %no.2308 ]
  ret ptr %v2327
}

define private ptr @mlf.code.2291(ptr %env, ptr %arg) {
entry:
  %v2292 = getelementptr i8, ptr %env, i64 24
  %v2293 = load ptr, ptr %v2292, align 8, !tbaa !3
  %v2294 = getelementptr i8, ptr %env, i64 32
  %v2295 = load ptr, ptr %v2294, align 8, !tbaa !3
  %v2328 = call ptr @mlf_force(ptr %v2293)
  %v2329 = call ptr @mlf_force(ptr %v2295)
  %v2330 = call ptr @mlf_env_new(i64 2)
  %v2331 = getelementptr i8, ptr %v2330, i64 24
  store ptr %v2328, ptr %v2331, align 8, !tbaa !3
  %v2332 = getelementptr i8, ptr %v2330, i64 32
  store ptr %v2329, ptr %v2332, align 8, !tbaa !3
  %v2333 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2296, ptr %v2330)
  ret ptr %v2333
}

define private ptr @mlf.code.2353(ptr %env, ptr %arg) {
entry:
  %v2354 = getelementptr i8, ptr %env, i64 24
  %v2355 = load ptr, ptr %v2354, align 8, !tbaa !3
  %v2356 = call ptr @mlf_prim2(i64 35, ptr %v2355, ptr inttoptr (i64 1 to ptr))
  ret ptr %v2356
}

define private ptr @mlf.code.2420(ptr %env, ptr %arg) {
entry:
  %v2421 = getelementptr i8, ptr %env, i64 24
  %v2422 = load ptr, ptr %v2421, align 8, !tbaa !3
  %v2423 = getelementptr i8, ptr %env, i64 32
  %v2424 = load ptr, ptr %v2423, align 8, !tbaa !3
  %v2425 = call ptr @mlf_prim2(i64 36, ptr %v2422, ptr %v2424)
  ret ptr %v2425
}

define private ptr @mlf.code.2450(ptr %env, ptr %arg) {
entry:
  %v2451 = getelementptr i8, ptr %env, i64 24
  %v2452 = load ptr, ptr %v2451, align 8, !tbaa !3
  %v2453 = getelementptr i8, ptr %env, i64 32
  %v2454 = load ptr, ptr %v2453, align 8, !tbaa !3
  %v2455 = call ptr @mlf_force(ptr %v2452)
  %v2456 = call ptr @mlf_force(ptr %v2454)
  %v2457 = call ptr @mlf_prim2(i64 8, ptr %v2455, ptr %v2456)
  ret ptr %v2457
}

define private ptr @mlf.code.2441(ptr %env, ptr %arg) {
entry:
  %v2442 = getelementptr i8, ptr %env, i64 24
  %v2443 = load ptr, ptr %v2442, align 8, !tbaa !3
  %v2444 = getelementptr i8, ptr %env, i64 32
  %v2445 = load ptr, ptr %v2444, align 8, !tbaa !3
  %v2446 = getelementptr i8, ptr %env, i64 40
  %v2447 = load ptr, ptr %v2446, align 8, !tbaa !3
  %v2448 = getelementptr i8, ptr %env, i64 48
  %v2449 = load ptr, ptr %v2448, align 8, !tbaa !3
  %v2458 = call ptr @mlf_env_new(i64 2)
  %v2459 = getelementptr i8, ptr %v2458, i64 24
  store ptr %v2445, ptr %v2459, align 8, !tbaa !3
  %v2460 = getelementptr i8, ptr %v2458, i64 32
  store ptr %v2447, ptr %v2460, align 8, !tbaa !3
  %v2461 = call ptr @mlf_thunk(ptr @mlf.code.2450, ptr %v2458)
  %v2462 = call ptr @mlf_prim3(i64 37, ptr %v2443, ptr %v2461, ptr %v2449)
  ret ptr %v2462
}

define private ptr @mlf.code.2469(ptr %env, ptr %arg) {
entry:
  %v2470 = getelementptr i8, ptr %env, i64 24
  %v2471 = load ptr, ptr %v2470, align 8, !tbaa !3
  %v2472 = getelementptr i8, ptr %env, i64 32
  %v2473 = load ptr, ptr %v2472, align 8, !tbaa !3
  %v2474 = getelementptr i8, ptr %env, i64 40
  %v2475 = load ptr, ptr %v2474, align 8, !tbaa !3
  %v2476 = getelementptr i8, ptr %env, i64 48
  %v2477 = load ptr, ptr %v2476, align 8, !tbaa !3
  %v2478 = getelementptr i8, ptr %env, i64 56
  %v2479 = load ptr, ptr %v2478, align 8, !tbaa !3
  %v2480 = call ptr @mlf_force(ptr %v2475)
  %v2481 = call ptr @mlf_force(ptr %v2479)
  %v2482 = call ptr @mlf_prim2(i64 8, ptr %v2481, ptr inttoptr (i64 3 to ptr))
  %v2483 = call ptr @mlf_env_new(i64 5)
  %v2484 = getelementptr i8, ptr %v2483, i64 24
  store ptr %v2471, ptr %v2484, align 8, !tbaa !3
  %v2485 = getelementptr i8, ptr %v2483, i64 32
  store ptr %v2473, ptr %v2485, align 8, !tbaa !3
  %v2486 = getelementptr i8, ptr %v2483, i64 40
  store ptr %v2480, ptr %v2486, align 8, !tbaa !3
  %v2487 = getelementptr i8, ptr %v2483, i64 48
  store ptr %v2477, ptr %v2487, align 8, !tbaa !3
  %v2488 = getelementptr i8, ptr %v2483, i64 56
  store ptr %v2482, ptr %v2488, align 8, !tbaa !3
  %v2489 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2384, ptr %v2483)
  ret ptr %v2489
}

define private ptr @mlf.code.2430(ptr %env, ptr %arg) {
entry:
  %v2431 = getelementptr i8, ptr %env, i64 24
  %v2432 = load ptr, ptr %v2431, align 8, !tbaa !3
  %v2433 = getelementptr i8, ptr %env, i64 32
  %v2434 = load ptr, ptr %v2433, align 8, !tbaa !3
  %v2435 = getelementptr i8, ptr %env, i64 40
  %v2436 = load ptr, ptr %v2435, align 8, !tbaa !3
  %v2437 = getelementptr i8, ptr %env, i64 48
  %v2438 = load ptr, ptr %v2437, align 8, !tbaa !3
  %v2439 = getelementptr i8, ptr %env, i64 56
  %v2440 = load ptr, ptr %v2439, align 8, !tbaa !3
  %v2463 = call ptr @mlf_env_new(i64 4)
  %v2464 = getelementptr i8, ptr %v2463, i64 24
  store ptr %v2434, ptr %v2464, align 8, !tbaa !3
  %v2465 = getelementptr i8, ptr %v2463, i64 32
  store ptr %v2438, ptr %v2465, align 8, !tbaa !3
  %v2466 = getelementptr i8, ptr %v2463, i64 40
  store ptr %v2440, ptr %v2466, align 8, !tbaa !3
  %v2467 = getelementptr i8, ptr %v2463, i64 48
  store ptr %arg, ptr %v2467, align 8, !tbaa !3
  %v2468 = call ptr @mlf_thunk(ptr @mlf.code.2441, ptr %v2463)
  %v2490 = call ptr @mlf_env_new(i64 5)
  %v2491 = getelementptr i8, ptr %v2490, i64 24
  store ptr %v2432, ptr %v2491, align 8, !tbaa !3
  %v2492 = getelementptr i8, ptr %v2490, i64 32
  store ptr %v2434, ptr %v2492, align 8, !tbaa !3
  %v2493 = getelementptr i8, ptr %v2490, i64 40
  store ptr %v2436, ptr %v2493, align 8, !tbaa !3
  %v2494 = getelementptr i8, ptr %v2490, i64 48
  store ptr %v2438, ptr %v2494, align 8, !tbaa !3
  %v2495 = getelementptr i8, ptr %v2490, i64 56
  store ptr %v2440, ptr %v2495, align 8, !tbaa !3
  %v2496 = call ptr @mlf_closure(ptr @mlf.code.2469, ptr %v2490)
  %v2497 = call ptr @mlf_prim2(i64 1, ptr %v2468, ptr %v2496)
  ret ptr %v2497
}

define private ptr @mlf.worker.0(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) {
entry:
  %v2415 = call ptr @mlf_prim2(i64 11, ptr %a4, ptr %a2)
  %v2416 = icmp eq ptr %v2415, inttoptr (i64 6 to ptr)
  br i1 %v2416, label %yes.2417, label %no.2418
yes.2417:
  %v2426 = call ptr @mlf_env_new(i64 2)
  %v2427 = getelementptr i8, ptr %v2426, i64 24
  store ptr %a0, ptr %v2427, align 8, !tbaa !3
  %v2428 = getelementptr i8, ptr %v2426, i64 32
  store ptr %a4, ptr %v2428, align 8, !tbaa !3
  %v2429 = call ptr @mlf_thunk(ptr @mlf.code.2420, ptr %v2426)
  %v2498 = call ptr @mlf_env_new(i64 5)
  %v2499 = getelementptr i8, ptr %v2498, i64 24
  store ptr %a0, ptr %v2499, align 8, !tbaa !3
  %v2500 = getelementptr i8, ptr %v2498, i64 32
  store ptr %a1, ptr %v2500, align 8, !tbaa !3
  %v2501 = getelementptr i8, ptr %v2498, i64 40
  store ptr %a2, ptr %v2501, align 8, !tbaa !3
  %v2502 = getelementptr i8, ptr %v2498, i64 48
  store ptr %a3, ptr %v2502, align 8, !tbaa !3
  %v2503 = getelementptr i8, ptr %v2498, i64 56
  store ptr %a4, ptr %v2503, align 8, !tbaa !3
  %v2504 = call ptr @mlf_closure(ptr @mlf.code.2430, ptr %v2498)
  %v2505 = call ptr @mlf_prim2(i64 1, ptr %v2429, ptr %v2504)
  br label %join.2419
no.2418:
  %v2506 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.2419
join.2419:
  %v2507 = phi ptr [ %v2505, %yes.2417 ], [ %v2506, %no.2418 ]
  ret ptr %v2507
}

define private ptr @mlf.numeric.entry.2384(ptr %env, ptr %arg) {
entry:
  %v2385 = getelementptr i8, ptr %env, i64 24
  %v2386 = load ptr, ptr %v2385, align 8, !tbaa !3
  %v2387 = getelementptr i8, ptr %env, i64 32
  %v2388 = load ptr, ptr %v2387, align 8, !tbaa !3
  %v2389 = getelementptr i8, ptr %env, i64 40
  %v2390 = load ptr, ptr %v2389, align 8, !tbaa !3
  %v2391 = getelementptr i8, ptr %env, i64 48
  %v2392 = load ptr, ptr %v2391, align 8, !tbaa !3
  %v2393 = getelementptr i8, ptr %env, i64 56
  %v2394 = load ptr, ptr %v2393, align 8, !tbaa !3
  %v2395 = call ptr @mlf_peek(ptr %v2386)
  %v2396 = call ptr @mlf_peek(ptr %v2388)
  %v2397 = call ptr @mlf_peek(ptr %v2390)
  %v2398 = call ptr @mlf_peek(ptr %v2392)
  %v2399 = call ptr @mlf_peek(ptr %v2394)
  %v2400 = icmp ne ptr %v2395, null
  %v2401 = icmp ne ptr %v2396, null
  %v2402 = icmp ne ptr %v2397, null
  %v2403 = icmp ne ptr %v2398, null
  %v2404 = icmp ne ptr %v2399, null
  %v2405 = and i1 true, %v2400
  %v2406 = and i1 %v2405, %v2401
  %v2407 = and i1 %v2406, %v2402
  %v2408 = and i1 %v2407, %v2403
  %v2409 = and i1 %v2408, %v2404
  br i1 %v2409, label %yes.2410, label %no.2411
yes.2410:
  %v2413 = call ptr @mlf.numeric.0(ptr %v2395, ptr %v2396, ptr %v2397, ptr %v2398, ptr %v2399)
  %v2414 = call ptr @mlf_prim1(i64 0, ptr %v2413)
  br label %join.2412
no.2411:
  %v2508 = call ptr @mlf_force(ptr %v2390)
  %v2509 = call ptr @mlf_force(ptr %v2394)
  %v2510 = call ptr @mlf.worker.0(ptr %v2386, ptr %v2388, ptr %v2508, ptr %v2392, ptr %v2509)
  br label %join.2412
join.2412:
  %v2511 = phi ptr [ %v2414, %yes.2410 ], [ %v2510, %no.2411 ]
  ret ptr %v2511
}

define private ptr @mlf.code.2377(ptr %env, ptr %arg) {
entry:
  %v2378 = getelementptr i8, ptr %env, i64 24
  %v2379 = load ptr, ptr %v2378, align 8, !tbaa !3
  %v2380 = getelementptr i8, ptr %env, i64 32
  %v2381 = load ptr, ptr %v2380, align 8, !tbaa !3
  %v2382 = getelementptr i8, ptr %env, i64 40
  %v2383 = load ptr, ptr %v2382, align 8, !tbaa !3
  %v2512 = call ptr @mlf_force(ptr %v2381)
  %v2513 = call ptr @mlf_env_new(i64 5)
  %v2514 = getelementptr i8, ptr %v2513, i64 24
  store ptr %v2379, ptr %v2514, align 8, !tbaa !3
  %v2515 = getelementptr i8, ptr %v2513, i64 32
  store ptr %v2383, ptr %v2515, align 8, !tbaa !3
  %v2516 = getelementptr i8, ptr %v2513, i64 40
  store ptr %v2512, ptr %v2516, align 8, !tbaa !3
  %v2517 = getelementptr i8, ptr %v2513, i64 48
  store ptr inttoptr (i64 1 to ptr), ptr %v2517, align 8, !tbaa !3
  %v2518 = getelementptr i8, ptr %v2513, i64 56
  store ptr inttoptr (i64 1 to ptr), ptr %v2518, align 8, !tbaa !3
  %v2519 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2384, ptr %v2513)
  ret ptr %v2519
}

define private ptr @mlf.code.2542(ptr %env, ptr %arg) {
entry:
  %v2543 = getelementptr i8, ptr %env, i64 24
  %v2544 = load ptr, ptr %v2543, align 8, !tbaa !3
  %v2545 = getelementptr i8, ptr %env, i64 32
  %v2546 = load ptr, ptr %v2545, align 8, !tbaa !3
  %v2547 = getelementptr i8, ptr %env, i64 40
  %v2548 = load ptr, ptr %v2547, align 8, !tbaa !3
  %v2549 = getelementptr i8, ptr %env, i64 48
  %v2550 = load ptr, ptr %v2549, align 8, !tbaa !3
  %v2551 = call ptr @mlf_force(ptr %v2548)
  %v2552 = call ptr @mlf_env_new(i64 5)
  %v2553 = getelementptr i8, ptr %v2552, i64 24
  store ptr %v2546, ptr %v2553, align 8, !tbaa !3
  %v2554 = getelementptr i8, ptr %v2552, i64 32
  store ptr %v2550, ptr %v2554, align 8, !tbaa !3
  %v2555 = getelementptr i8, ptr %v2552, i64 40
  store ptr %v2551, ptr %v2555, align 8, !tbaa !3
  %v2556 = getelementptr i8, ptr %v2552, i64 48
  store ptr %v2544, ptr %v2556, align 8, !tbaa !3
  %v2557 = getelementptr i8, ptr %v2552, i64 56
  store ptr inttoptr (i64 1 to ptr), ptr %v2557, align 8, !tbaa !3
  %v2558 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2384, ptr %v2552)
  ret ptr %v2558
}

define private ptr @mlf.code.2565(ptr %env, ptr %arg) {
entry:
  %v2566 = getelementptr i8, ptr %env, i64 24
  %v2567 = load ptr, ptr %v2566, align 8, !tbaa !3
  %v2568 = getelementptr i8, ptr %env, i64 32
  %v2569 = load ptr, ptr %v2568, align 8, !tbaa !3
  %v2570 = getelementptr i8, ptr %env, i64 40
  %v2571 = load ptr, ptr %v2570, align 8, !tbaa !3
  %v2572 = getelementptr i8, ptr %env, i64 48
  %v2573 = load ptr, ptr %v2572, align 8, !tbaa !3
  %v2574 = getelementptr i8, ptr %env, i64 56
  %v2575 = load ptr, ptr %v2574, align 8, !tbaa !3
  %v2576 = call ptr @mlf_env_new(i64 5)
  %v2577 = getelementptr i8, ptr %v2576, i64 24
  store ptr %v2567, ptr %v2577, align 8, !tbaa !3
  %v2578 = getelementptr i8, ptr %v2576, i64 32
  store ptr %v2569, ptr %v2578, align 8, !tbaa !3
  %v2579 = getelementptr i8, ptr %v2576, i64 40
  store ptr %v2575, ptr %v2579, align 8, !tbaa !3
  %v2580 = getelementptr i8, ptr %v2576, i64 48
  store ptr %v2571, ptr %v2580, align 8, !tbaa !3
  %v2581 = getelementptr i8, ptr %v2576, i64 56
  store ptr %v2573, ptr %v2581, align 8, !tbaa !3
  %v2582 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.410, ptr %v2576)
  ret ptr %v2582
}

define private ptr @mlf.code.2525(ptr %env, ptr %arg) {
entry:
  %v2526 = getelementptr i8, ptr %env, i64 24
  %v2527 = load ptr, ptr %v2526, align 8, !tbaa !3
  %v2528 = getelementptr i8, ptr %env, i64 32
  %v2529 = load ptr, ptr %v2528, align 8, !tbaa !3
  %v2530 = getelementptr i8, ptr %env, i64 40
  %v2531 = load ptr, ptr %v2530, align 8, !tbaa !3
  %v2532 = getelementptr i8, ptr %env, i64 48
  %v2533 = load ptr, ptr %v2532, align 8, !tbaa !3
  %v2534 = getelementptr i8, ptr %env, i64 56
  %v2535 = load ptr, ptr %v2534, align 8, !tbaa !3
  %v2536 = getelementptr i8, ptr %env, i64 64
  %v2537 = load ptr, ptr %v2536, align 8, !tbaa !3
  %v2538 = getelementptr i8, ptr %env, i64 72
  %v2539 = load ptr, ptr %v2538, align 8, !tbaa !3
  %v2540 = getelementptr i8, ptr %env, i64 80
  %v2541 = load ptr, ptr %v2540, align 8, !tbaa !3
  %v2559 = call ptr @mlf_env_new(i64 4)
  %v2560 = getelementptr i8, ptr %v2559, i64 24
  store ptr %v2531, ptr %v2560, align 8, !tbaa !3
  %v2561 = getelementptr i8, ptr %v2559, i64 32
  store ptr %v2533, ptr %v2561, align 8, !tbaa !3
  %v2562 = getelementptr i8, ptr %v2559, i64 40
  store ptr %v2535, ptr %v2562, align 8, !tbaa !3
  %v2563 = getelementptr i8, ptr %v2559, i64 48
  store ptr %v2541, ptr %v2563, align 8, !tbaa !3
  %v2564 = call ptr @mlf_thunk(ptr @mlf.code.2542, ptr %v2559)
  %v2583 = call ptr @mlf_env_new(i64 5)
  %v2584 = getelementptr i8, ptr %v2583, i64 24
  store ptr %v2527, ptr %v2584, align 8, !tbaa !3
  %v2585 = getelementptr i8, ptr %v2583, i64 32
  store ptr %v2529, ptr %v2585, align 8, !tbaa !3
  %v2586 = getelementptr i8, ptr %v2583, i64 40
  store ptr %v2537, ptr %v2586, align 8, !tbaa !3
  %v2587 = getelementptr i8, ptr %v2583, i64 48
  store ptr %v2539, ptr %v2587, align 8, !tbaa !3
  %v2588 = getelementptr i8, ptr %v2583, i64 56
  store ptr %v2541, ptr %v2588, align 8, !tbaa !3
  %v2589 = call ptr @mlf_closure(ptr @mlf.code.2565, ptr %v2583)
  %v2590 = call ptr @mlf_prim2(i64 1, ptr %v2564, ptr %v2589)
  ret ptr %v2590
}

define private ptr @mlf.code.2360(ptr %env, ptr %arg) {
entry:
  %v2361 = getelementptr i8, ptr %env, i64 24
  %v2362 = load ptr, ptr %v2361, align 8, !tbaa !3
  %v2363 = getelementptr i8, ptr %env, i64 32
  %v2364 = load ptr, ptr %v2363, align 8, !tbaa !3
  %v2365 = getelementptr i8, ptr %env, i64 40
  %v2366 = load ptr, ptr %v2365, align 8, !tbaa !3
  %v2367 = getelementptr i8, ptr %env, i64 48
  %v2368 = load ptr, ptr %v2367, align 8, !tbaa !3
  %v2369 = getelementptr i8, ptr %env, i64 56
  %v2370 = load ptr, ptr %v2369, align 8, !tbaa !3
  %v2371 = getelementptr i8, ptr %env, i64 64
  %v2372 = load ptr, ptr %v2371, align 8, !tbaa !3
  %v2373 = getelementptr i8, ptr %env, i64 72
  %v2374 = load ptr, ptr %v2373, align 8, !tbaa !3
  %v2375 = getelementptr i8, ptr %env, i64 80
  %v2376 = load ptr, ptr %v2375, align 8, !tbaa !3
  %v2520 = call ptr @mlf_env_new(i64 3)
  %v2521 = getelementptr i8, ptr %v2520, i64 24
  store ptr %v2366, ptr %v2521, align 8, !tbaa !3
  %v2522 = getelementptr i8, ptr %v2520, i64 32
  store ptr %v2368, ptr %v2522, align 8, !tbaa !3
  %v2523 = getelementptr i8, ptr %v2520, i64 40
  store ptr %arg, ptr %v2523, align 8, !tbaa !3
  %v2524 = call ptr @mlf_thunk(ptr @mlf.code.2377, ptr %v2520)
  %v2591 = call ptr @mlf_env_new(i64 8)
  %v2592 = getelementptr i8, ptr %v2591, i64 24
  store ptr %v2362, ptr %v2592, align 8, !tbaa !3
  %v2593 = getelementptr i8, ptr %v2591, i64 32
  store ptr %v2364, ptr %v2593, align 8, !tbaa !3
  %v2594 = getelementptr i8, ptr %v2591, i64 40
  store ptr %v2368, ptr %v2594, align 8, !tbaa !3
  %v2595 = getelementptr i8, ptr %v2591, i64 48
  store ptr %v2370, ptr %v2595, align 8, !tbaa !3
  %v2596 = getelementptr i8, ptr %v2591, i64 56
  store ptr %v2372, ptr %v2596, align 8, !tbaa !3
  %v2597 = getelementptr i8, ptr %v2591, i64 64
  store ptr %v2374, ptr %v2597, align 8, !tbaa !3
  %v2598 = getelementptr i8, ptr %v2591, i64 72
  store ptr %v2376, ptr %v2598, align 8, !tbaa !3
  %v2599 = getelementptr i8, ptr %v2591, i64 80
  store ptr %arg, ptr %v2599, align 8, !tbaa !3
  %v2600 = call ptr @mlf_closure(ptr @mlf.code.2525, ptr %v2591)
  %v2601 = call ptr @mlf_prim2(i64 1, ptr %v2524, ptr %v2600)
  ret ptr %v2601
}

define private ptr @mlf.code.2338(ptr %env, ptr %arg) {
entry:
  %v2339 = getelementptr i8, ptr %env, i64 24
  %v2340 = load ptr, ptr %v2339, align 8, !tbaa !3
  %v2341 = getelementptr i8, ptr %env, i64 32
  %v2342 = load ptr, ptr %v2341, align 8, !tbaa !3
  %v2343 = getelementptr i8, ptr %env, i64 40
  %v2344 = load ptr, ptr %v2343, align 8, !tbaa !3
  %v2345 = getelementptr i8, ptr %env, i64 48
  %v2346 = load ptr, ptr %v2345, align 8, !tbaa !3
  %v2347 = getelementptr i8, ptr %env, i64 56
  %v2348 = load ptr, ptr %v2347, align 8, !tbaa !3
  %v2349 = getelementptr i8, ptr %env, i64 64
  %v2350 = load ptr, ptr %v2349, align 8, !tbaa !3
  %v2351 = getelementptr i8, ptr %env, i64 72
  %v2352 = load ptr, ptr %v2351, align 8, !tbaa !3
  %v2357 = call ptr @mlf_env_new(i64 1)
  %v2358 = getelementptr i8, ptr %v2357, i64 24
  store ptr %arg, ptr %v2358, align 8, !tbaa !3
  %v2359 = call ptr @mlf_thunk(ptr @mlf.code.2353, ptr %v2357)
  %v2602 = call ptr @mlf_env_new(i64 8)
  %v2603 = getelementptr i8, ptr %v2602, i64 24
  store ptr %v2340, ptr %v2603, align 8, !tbaa !3
  %v2604 = getelementptr i8, ptr %v2602, i64 32
  store ptr %v2342, ptr %v2604, align 8, !tbaa !3
  %v2605 = getelementptr i8, ptr %v2602, i64 40
  store ptr %v2344, ptr %v2605, align 8, !tbaa !3
  %v2606 = getelementptr i8, ptr %v2602, i64 48
  store ptr %v2346, ptr %v2606, align 8, !tbaa !3
  %v2607 = getelementptr i8, ptr %v2602, i64 56
  store ptr %v2348, ptr %v2607, align 8, !tbaa !3
  %v2608 = getelementptr i8, ptr %v2602, i64 64
  store ptr %v2350, ptr %v2608, align 8, !tbaa !3
  %v2609 = getelementptr i8, ptr %v2602, i64 72
  store ptr %v2352, ptr %v2609, align 8, !tbaa !3
  %v2610 = getelementptr i8, ptr %v2602, i64 80
  store ptr %arg, ptr %v2610, align 8, !tbaa !3
  %v2611 = call ptr @mlf_closure(ptr @mlf.code.2360, ptr %v2602)
  %v2612 = call ptr @mlf_prim2(i64 1, ptr %v2359, ptr %v2611)
  ret ptr %v2612
}

define private ptr @mlf.code.2623(ptr %env, ptr %arg) {
entry:
  %v2624 = getelementptr i8, ptr %env, i64 24
  %v2625 = load ptr, ptr %v2624, align 8, !tbaa !3
  %v2626 = getelementptr i8, ptr %env, i64 32
  %v2627 = load ptr, ptr %v2626, align 8, !tbaa !3
  %v2628 = getelementptr i8, ptr %env, i64 40
  %v2629 = load ptr, ptr %v2628, align 8, !tbaa !3
  %v2630 = getelementptr i8, ptr %env, i64 48
  %v2631 = load ptr, ptr %v2630, align 8, !tbaa !3
  %v2632 = call ptr @mlf_force(ptr %v2631)
  %v2633 = call ptr @mlf_env_new(i64 5)
  %v2634 = getelementptr i8, ptr %v2633, i64 24
  store ptr %v2629, ptr %v2634, align 8, !tbaa !3
  %v2635 = getelementptr i8, ptr %v2633, i64 32
  store ptr %v2625, ptr %v2635, align 8, !tbaa !3
  %v2636 = getelementptr i8, ptr %v2633, i64 40
  store ptr %v2632, ptr %v2636, align 8, !tbaa !3
  %v2637 = getelementptr i8, ptr %v2633, i64 48
  store ptr %v2627, ptr %v2637, align 8, !tbaa !3
  %v2638 = getelementptr i8, ptr %v2633, i64 56
  store ptr inttoptr (i64 1 to ptr), ptr %v2638, align 8, !tbaa !3
  %v2639 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2384, ptr %v2633)
  ret ptr %v2639
}

define private ptr @mlf.code.2646(ptr %env, ptr %arg) {
entry:
  %v2647 = getelementptr i8, ptr %env, i64 24
  %v2648 = load ptr, ptr %v2647, align 8, !tbaa !3
  %v2649 = getelementptr i8, ptr %env, i64 32
  %v2650 = load ptr, ptr %v2649, align 8, !tbaa !3
  %v2651 = getelementptr i8, ptr %env, i64 40
  %v2652 = load ptr, ptr %v2651, align 8, !tbaa !3
  %v2653 = getelementptr i8, ptr %env, i64 48
  %v2654 = load ptr, ptr %v2653, align 8, !tbaa !3
  %v2655 = getelementptr i8, ptr %env, i64 56
  %v2656 = load ptr, ptr %v2655, align 8, !tbaa !3
  %v2657 = call ptr @mlf_env_new(i64 5)
  %v2658 = getelementptr i8, ptr %v2657, i64 24
  store ptr %v2648, ptr %v2658, align 8, !tbaa !3
  %v2659 = getelementptr i8, ptr %v2657, i64 32
  store ptr %v2650, ptr %v2659, align 8, !tbaa !3
  %v2660 = getelementptr i8, ptr %v2657, i64 40
  store ptr %v2652, ptr %v2660, align 8, !tbaa !3
  %v2661 = getelementptr i8, ptr %v2657, i64 48
  store ptr %v2656, ptr %v2661, align 8, !tbaa !3
  %v2662 = getelementptr i8, ptr %v2657, i64 56
  store ptr %v2654, ptr %v2662, align 8, !tbaa !3
  %v2663 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.410, ptr %v2657)
  ret ptr %v2663
}

define private ptr @mlf.code.2269(ptr %env, ptr %arg) {
entry:
  %v2270 = getelementptr i8, ptr %env, i64 24
  %v2271 = load ptr, ptr %v2270, align 8, !tbaa !3
  %v2272 = getelementptr i8, ptr %env, i64 32
  %v2273 = load ptr, ptr %v2272, align 8, !tbaa !3
  %v2274 = getelementptr i8, ptr %env, i64 40
  %v2275 = load ptr, ptr %v2274, align 8, !tbaa !3
  %v2276 = getelementptr i8, ptr %env, i64 48
  %v2277 = load ptr, ptr %v2276, align 8, !tbaa !3
  %v2278 = getelementptr i8, ptr %env, i64 56
  %v2279 = load ptr, ptr %v2278, align 8, !tbaa !3
  %v2280 = getelementptr i8, ptr %env, i64 64
  %v2281 = load ptr, ptr %v2280, align 8, !tbaa !3
  %v2282 = call ptr @mlf_force(ptr %v2277)
  %v2283 = call ptr @mlf_force(ptr %arg)
  %v2284 = call ptr @mlf_prim2(i64 8, ptr %v2282, ptr %v2283)
  %v2285 = call ptr @mlf_force(ptr %v2279)
  %v2286 = call ptr @mlf_prim2(i64 11, ptr %v2285, ptr %v2284)
  %v2287 = icmp eq ptr %v2286, inttoptr (i64 6 to ptr)
  br i1 %v2287, label %yes.2288, label %no.2289
yes.2288:
  %v2334 = call ptr @mlf_env_new(i64 2)
  %v2335 = getelementptr i8, ptr %v2334, i64 24
  store ptr %v2285, ptr %v2335, align 8, !tbaa !3
  %v2336 = getelementptr i8, ptr %v2334, i64 32
  store ptr %v2284, ptr %v2336, align 8, !tbaa !3
  %v2337 = call ptr @mlf_thunk(ptr @mlf.code.2291, ptr %v2334)
  %v2613 = call ptr @mlf_env_new(i64 7)
  %v2614 = getelementptr i8, ptr %v2613, i64 24
  store ptr %v2271, ptr %v2614, align 8, !tbaa !3
  %v2615 = getelementptr i8, ptr %v2613, i64 32
  store ptr %v2273, ptr %v2615, align 8, !tbaa !3
  %v2616 = getelementptr i8, ptr %v2613, i64 40
  store ptr %v2275, ptr %v2616, align 8, !tbaa !3
  %v2617 = getelementptr i8, ptr %v2613, i64 48
  store ptr %v2282, ptr %v2617, align 8, !tbaa !3
  %v2618 = getelementptr i8, ptr %v2613, i64 56
  store ptr %v2281, ptr %v2618, align 8, !tbaa !3
  %v2619 = getelementptr i8, ptr %v2613, i64 64
  store ptr %v2283, ptr %v2619, align 8, !tbaa !3
  %v2620 = getelementptr i8, ptr %v2613, i64 72
  store ptr %v2284, ptr %v2620, align 8, !tbaa !3
  %v2621 = call ptr @mlf_closure(ptr @mlf.code.2338, ptr %v2613)
  %v2622 = call ptr @mlf_prim2(i64 1, ptr %v2337, ptr %v2621)
  br label %join.2290
no.2289:
  %v2640 = call ptr @mlf_env_new(i64 4)
  %v2641 = getelementptr i8, ptr %v2640, i64 24
  store ptr %v2275, ptr %v2641, align 8, !tbaa !3
  %v2642 = getelementptr i8, ptr %v2640, i64 32
  store ptr %v2282, ptr %v2642, align 8, !tbaa !3
  %v2643 = getelementptr i8, ptr %v2640, i64 40
  store ptr %v2281, ptr %v2643, align 8, !tbaa !3
  %v2644 = getelementptr i8, ptr %v2640, i64 48
  store ptr %v2283, ptr %v2644, align 8, !tbaa !3
  %v2645 = call ptr @mlf_thunk(ptr @mlf.code.2623, ptr %v2640)
  %v2664 = call ptr @mlf_env_new(i64 5)
  %v2665 = getelementptr i8, ptr %v2664, i64 24
  store ptr %v2271, ptr %v2665, align 8, !tbaa !3
  %v2666 = getelementptr i8, ptr %v2664, i64 32
  store ptr %v2273, ptr %v2666, align 8, !tbaa !3
  %v2667 = getelementptr i8, ptr %v2664, i64 40
  store ptr %v2275, ptr %v2667, align 8, !tbaa !3
  %v2668 = getelementptr i8, ptr %v2664, i64 48
  store ptr %v2285, ptr %v2668, align 8, !tbaa !3
  %v2669 = getelementptr i8, ptr %v2664, i64 56
  store ptr %v2284, ptr %v2669, align 8, !tbaa !3
  %v2670 = call ptr @mlf_closure(ptr @mlf.code.2646, ptr %v2664)
  %v2671 = call ptr @mlf_prim2(i64 1, ptr %v2645, ptr %v2670)
  br label %join.2290
join.2290:
  %v2672 = phi ptr [ %v2622, %yes.2288 ], [ %v2671, %no.2289 ]
  ret ptr %v2672
}

define private ptr @mlf.code.2077(ptr %env, ptr %arg) {
entry:
  %v2078 = getelementptr i8, ptr %env, i64 24
  %v2079 = load ptr, ptr %v2078, align 8, !tbaa !3
  %v2080 = getelementptr i8, ptr %env, i64 32
  %v2081 = load ptr, ptr %v2080, align 8, !tbaa !3
  %v2082 = getelementptr i8, ptr %env, i64 40
  %v2083 = load ptr, ptr %v2082, align 8, !tbaa !3
  %v2084 = getelementptr i8, ptr %env, i64 48
  %v2085 = load ptr, ptr %v2084, align 8, !tbaa !3
  %v2086 = getelementptr i8, ptr %env, i64 56
  %v2087 = load ptr, ptr %v2086, align 8, !tbaa !3
  %v2088 = getelementptr i8, ptr %env, i64 64
  %v2089 = load ptr, ptr %v2088, align 8, !tbaa !3
  %v2090 = getelementptr i8, ptr %env, i64 72
  %v2091 = load ptr, ptr %v2090, align 8, !tbaa !3
  %v2092 = call ptr @mlf_force(ptr %arg)
  %v2093 = call ptr @mlf_prim2(i64 10, ptr %v2092, ptr inttoptr (i64 125 to ptr))
  %v2094 = icmp eq ptr %v2093, inttoptr (i64 6 to ptr)
  br i1 %v2094, label %yes.2095, label %no.2096
yes.2095:
  %v2114 = call ptr @mlf_env_new(i64 4)
  %v2115 = getelementptr i8, ptr %v2114, i64 24
  store ptr %v2079, ptr %v2115, align 8, !tbaa !3
  %v2116 = getelementptr i8, ptr %v2114, i64 32
  store ptr %v2081, ptr %v2116, align 8, !tbaa !3
  %v2117 = getelementptr i8, ptr %v2114, i64 40
  store ptr %v2083, ptr %v2117, align 8, !tbaa !3
  %v2118 = getelementptr i8, ptr %v2114, i64 48
  store ptr %v2085, ptr %v2118, align 8, !tbaa !3
  %v2119 = call ptr @mlf_thunk(ptr @mlf.code.2098, ptr %v2114)
  %v2166 = call ptr @mlf_env_new(i64 6)
  %v2167 = getelementptr i8, ptr %v2166, i64 24
  store ptr %v2079, ptr %v2167, align 8, !tbaa !3
  %v2168 = getelementptr i8, ptr %v2166, i64 32
  store ptr %v2081, ptr %v2168, align 8, !tbaa !3
  %v2169 = getelementptr i8, ptr %v2166, i64 40
  store ptr %v2083, ptr %v2169, align 8, !tbaa !3
  %v2170 = getelementptr i8, ptr %v2166, i64 48
  store ptr %v2087, ptr %v2170, align 8, !tbaa !3
  %v2171 = getelementptr i8, ptr %v2166, i64 56
  store ptr %v2089, ptr %v2171, align 8, !tbaa !3
  %v2172 = getelementptr i8, ptr %v2166, i64 64
  store ptr %v2091, ptr %v2172, align 8, !tbaa !3
  %v2173 = call ptr @mlf_closure(ptr @mlf.code.2120, ptr %v2166)
  %v2174 = call ptr @mlf_prim2(i64 1, ptr %v2119, ptr %v2173)
  br label %join.2097
no.2096:
  %v2265 = call ptr @mlf_env_new(i64 2)
  %v2266 = getelementptr i8, ptr %v2265, i64 24
  store ptr %v2089, ptr %v2266, align 8, !tbaa !3
  %v2267 = getelementptr i8, ptr %v2265, i64 32
  store ptr %v2091, ptr %v2267, align 8, !tbaa !3
  %v2268 = call ptr @mlf_thunk(ptr @mlf.code.2175, ptr %v2265)
  %v2673 = call ptr @mlf_env_new(i64 6)
  %v2674 = getelementptr i8, ptr %v2673, i64 24
  store ptr %v2079, ptr %v2674, align 8, !tbaa !3
  %v2675 = getelementptr i8, ptr %v2673, i64 32
  store ptr %v2081, ptr %v2675, align 8, !tbaa !3
  %v2676 = getelementptr i8, ptr %v2673, i64 40
  store ptr %v2083, ptr %v2676, align 8, !tbaa !3
  %v2677 = getelementptr i8, ptr %v2673, i64 48
  store ptr %v2085, ptr %v2677, align 8, !tbaa !3
  %v2678 = getelementptr i8, ptr %v2673, i64 56
  store ptr %v2087, ptr %v2678, align 8, !tbaa !3
  %v2679 = getelementptr i8, ptr %v2673, i64 64
  store ptr %v2089, ptr %v2679, align 8, !tbaa !3
  %v2680 = call ptr @mlf_closure(ptr @mlf.code.2269, ptr %v2673)
  %v2681 = call ptr @mlf_prim2(i64 1, ptr %v2268, ptr %v2680)
  br label %join.2097
join.2097:
  %v2682 = phi ptr [ %v2174, %yes.2095 ], [ %v2681, %no.2096 ]
  ret ptr %v2682
}

define private ptr @mlf.code.1490(ptr %env, ptr %arg) {
entry:
  %v1491 = getelementptr i8, ptr %env, i64 24
  %v1492 = load ptr, ptr %v1491, align 8, !tbaa !3
  %v1493 = getelementptr i8, ptr %env, i64 32
  %v1494 = load ptr, ptr %v1493, align 8, !tbaa !3
  %v1495 = getelementptr i8, ptr %env, i64 40
  %v1496 = load ptr, ptr %v1495, align 8, !tbaa !3
  %v1497 = getelementptr i8, ptr %env, i64 48
  %v1498 = load ptr, ptr %v1497, align 8, !tbaa !3
  %v1499 = getelementptr i8, ptr %env, i64 56
  %v1500 = load ptr, ptr %v1499, align 8, !tbaa !3
  %v1501 = getelementptr i8, ptr %env, i64 64
  %v1502 = load ptr, ptr %v1501, align 8, !tbaa !3
  %v1503 = call ptr @mlf_force(ptr %arg)
  %v1504 = call ptr @mlf_prim2(i64 10, ptr %v1503, ptr inttoptr (i64 1 to ptr))
  %v1505 = icmp eq ptr %v1504, inttoptr (i64 6 to ptr)
  br i1 %v1505, label %yes.1506, label %no.1507
yes.1506:
  %v2063 = call ptr @mlf_force(ptr %v1498)
  %v2064 = call ptr @mlf_env_new(i64 4)
  %v2065 = getelementptr i8, ptr %v2064, i64 24
  store ptr %v1492, ptr %v2065, align 8, !tbaa !3
  %v2066 = getelementptr i8, ptr %v2064, i64 32
  store ptr %v1494, ptr %v2066, align 8, !tbaa !3
  %v2067 = getelementptr i8, ptr %v2064, i64 40
  store ptr %v1496, ptr %v2067, align 8, !tbaa !3
  %v2068 = getelementptr i8, ptr %v2064, i64 48
  store ptr %v2063, ptr %v2068, align 8, !tbaa !3
  %v2069 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1509, ptr %v2064)
  br label %join.1508
no.1507:
  %v2074 = call ptr @mlf_env_new(i64 1)
  %v2075 = getelementptr i8, ptr %v2074, i64 24
  store ptr %v1502, ptr %v2075, align 8, !tbaa !3
  %v2076 = call ptr @mlf_thunk(ptr @mlf.code.2070, ptr %v2074)
  %v2683 = call ptr @mlf_env_new(i64 7)
  %v2684 = getelementptr i8, ptr %v2683, i64 24
  store ptr %v1492, ptr %v2684, align 8, !tbaa !3
  %v2685 = getelementptr i8, ptr %v2683, i64 32
  store ptr %v1494, ptr %v2685, align 8, !tbaa !3
  %v2686 = getelementptr i8, ptr %v2683, i64 40
  store ptr %v1496, ptr %v2686, align 8, !tbaa !3
  %v2687 = getelementptr i8, ptr %v2683, i64 48
  store ptr %v1498, ptr %v2687, align 8, !tbaa !3
  %v2688 = getelementptr i8, ptr %v2683, i64 56
  store ptr %v1500, ptr %v2688, align 8, !tbaa !3
  %v2689 = getelementptr i8, ptr %v2683, i64 64
  store ptr %v1502, ptr %v2689, align 8, !tbaa !3
  %v2690 = getelementptr i8, ptr %v2683, i64 72
  store ptr %v1503, ptr %v2690, align 8, !tbaa !3
  %v2691 = call ptr @mlf_closure(ptr @mlf.code.2077, ptr %v2683)
  %v2692 = call ptr @mlf_prim2(i64 1, ptr %v2076, ptr %v2691)
  br label %join.1508
join.1508:
  %v2693 = phi ptr [ %v2069, %yes.1506 ], [ %v2692, %no.1507 ]
  ret ptr %v2693
}

define private ptr @mlf.code.1472(ptr %env, ptr %arg) {
entry:
  %v1473 = getelementptr i8, ptr %env, i64 24
  %v1474 = load ptr, ptr %v1473, align 8, !tbaa !3
  %v1475 = getelementptr i8, ptr %env, i64 32
  %v1476 = load ptr, ptr %v1475, align 8, !tbaa !3
  %v1477 = getelementptr i8, ptr %env, i64 40
  %v1478 = load ptr, ptr %v1477, align 8, !tbaa !3
  %v1479 = getelementptr i8, ptr %env, i64 48
  %v1480 = load ptr, ptr %v1479, align 8, !tbaa !3
  %v1481 = getelementptr i8, ptr %env, i64 56
  %v1482 = load ptr, ptr %v1481, align 8, !tbaa !3
  %v1487 = call ptr @mlf_env_new(i64 1)
  %v1488 = getelementptr i8, ptr %v1487, i64 24
  store ptr %arg, ptr %v1488, align 8, !tbaa !3
  %v1489 = call ptr @mlf_thunk(ptr @mlf.code.1483, ptr %v1487)
  %v2694 = call ptr @mlf_env_new(i64 6)
  %v2695 = getelementptr i8, ptr %v2694, i64 24
  store ptr %v1474, ptr %v2695, align 8, !tbaa !3
  %v2696 = getelementptr i8, ptr %v2694, i64 32
  store ptr %v1476, ptr %v2696, align 8, !tbaa !3
  %v2697 = getelementptr i8, ptr %v2694, i64 40
  store ptr %v1478, ptr %v2697, align 8, !tbaa !3
  %v2698 = getelementptr i8, ptr %v2694, i64 48
  store ptr %v1480, ptr %v2698, align 8, !tbaa !3
  %v2699 = getelementptr i8, ptr %v2694, i64 56
  store ptr %v1482, ptr %v2699, align 8, !tbaa !3
  %v2700 = getelementptr i8, ptr %v2694, i64 64
  store ptr %arg, ptr %v2700, align 8, !tbaa !3
  %v2701 = call ptr @mlf_closure(ptr @mlf.code.1490, ptr %v2694)
  %v2702 = call ptr @mlf_prim2(i64 1, ptr %v1489, ptr %v2701)
  ret ptr %v2702
}

define private ptr @mlf.worker.53(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) {
entry:
  %v1471 = call ptr @mlf_primitive(i64 41)
  %v2703 = call ptr @mlf_env_new(i64 5)
  %v2704 = getelementptr i8, ptr %v2703, i64 24
  store ptr %a0, ptr %v2704, align 8, !tbaa !3
  %v2705 = getelementptr i8, ptr %v2703, i64 32
  store ptr %a1, ptr %v2705, align 8, !tbaa !3
  %v2706 = getelementptr i8, ptr %v2703, i64 40
  store ptr %a2, ptr %v2706, align 8, !tbaa !3
  %v2707 = getelementptr i8, ptr %v2703, i64 48
  store ptr %a3, ptr %v2707, align 8, !tbaa !3
  %v2708 = getelementptr i8, ptr %v2703, i64 56
  store ptr %a4, ptr %v2708, align 8, !tbaa !3
  %v2709 = call ptr @mlf_closure(ptr @mlf.code.1472, ptr %v2703)
  %v2710 = call ptr @mlf_prim2(i64 1, ptr %v1471, ptr %v2709)
  ret ptr %v2710
}

define private ptr @mlf.numeric.entry.410(ptr %env, ptr %arg) {
entry:
  %v411 = getelementptr i8, ptr %env, i64 24
  %v412 = load ptr, ptr %v411, align 8, !tbaa !3
  %v413 = getelementptr i8, ptr %env, i64 32
  %v414 = load ptr, ptr %v413, align 8, !tbaa !3
  %v415 = getelementptr i8, ptr %env, i64 40
  %v416 = load ptr, ptr %v415, align 8, !tbaa !3
  %v417 = getelementptr i8, ptr %env, i64 48
  %v418 = load ptr, ptr %v417, align 8, !tbaa !3
  %v419 = getelementptr i8, ptr %env, i64 56
  %v420 = load ptr, ptr %v419, align 8, !tbaa !3
  %v421 = call ptr @mlf_peek(ptr %v412)
  %v422 = call ptr @mlf_peek(ptr %v414)
  %v423 = call ptr @mlf_peek(ptr %v416)
  %v424 = call ptr @mlf_peek(ptr %v418)
  %v425 = call ptr @mlf_peek(ptr %v420)
  %v426 = icmp ne ptr %v421, null
  %v427 = icmp ne ptr %v422, null
  %v428 = icmp ne ptr %v423, null
  %v429 = icmp ne ptr %v424, null
  %v430 = icmp ne ptr %v425, null
  %v431 = and i1 true, %v426
  %v432 = and i1 %v431, %v427
  %v433 = and i1 %v432, %v428
  %v434 = and i1 %v433, %v429
  %v435 = and i1 %v434, %v430
  br i1 %v435, label %yes.436, label %no.437
yes.436:
  %v1469 = call ptr @mlf.numeric.53(ptr %v421, ptr %v422, ptr %v423, ptr %v424, ptr %v425)
  %v1470 = call ptr @mlf_prim1(i64 0, ptr %v1469)
  br label %join.438
no.437:
  %v2711 = call ptr @mlf.worker.53(ptr %v412, ptr %v414, ptr %v416, ptr %v418, ptr %v420)
  br label %join.438
join.438:
  %v2712 = phi ptr [ %v1470, %yes.436 ], [ %v2711, %no.437 ]
  ret ptr %v2712
}

define private ptr @mlf.code.405(ptr %env, ptr %arg) {
entry:
  %v406 = getelementptr i8, ptr %env, i64 24
  %v407 = load ptr, ptr %v406, align 8, !tbaa !3
  %v408 = getelementptr i8, ptr %env, i64 32
  %v409 = load ptr, ptr %v408, align 8, !tbaa !3
  %v2713 = call ptr @mlf_env_new(i64 5)
  %v2714 = getelementptr i8, ptr %v2713, i64 24
  store ptr %v407, ptr %v2714, align 8, !tbaa !3
  %v2715 = getelementptr i8, ptr %v2713, i64 32
  store ptr %arg, ptr %v2715, align 8, !tbaa !3
  %v2716 = getelementptr i8, ptr %v2713, i64 40
  store ptr %v409, ptr %v2716, align 8, !tbaa !3
  %v2717 = getelementptr i8, ptr %v2713, i64 48
  store ptr inttoptr (i64 1 to ptr), ptr %v2717, align 8, !tbaa !3
  %v2718 = getelementptr i8, ptr %v2713, i64 56
  store ptr inttoptr (i64 2049 to ptr), ptr %v2718, align 8, !tbaa !3
  %v2719 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.410, ptr %v2713)
  ret ptr %v2719
}

define private ptr @mlf.code.399(ptr %env, ptr %arg) {
entry:
  %v400 = getelementptr i8, ptr %env, i64 24
  %v401 = load ptr, ptr %v400, align 8, !tbaa !3
  %v404 = call ptr @mlf_thunk(ptr @mlf.code.402, ptr null)
  %v2720 = call ptr @mlf_env_new(i64 2)
  %v2721 = getelementptr i8, ptr %v2720, i64 24
  store ptr %v401, ptr %v2721, align 8, !tbaa !3
  %v2722 = getelementptr i8, ptr %v2720, i64 32
  store ptr %arg, ptr %v2722, align 8, !tbaa !3
  %v2723 = call ptr @mlf_closure(ptr @mlf.code.405, ptr %v2720)
  %v2724 = call ptr @mlf_prim2(i64 1, ptr %v404, ptr %v2723)
  ret ptr %v2724
}

define private ptr @mlf.code.393(ptr %env, ptr %arg) {
entry:
  %v394 = getelementptr i8, ptr %env, i64 24
  %v395 = load ptr, ptr %v394, align 8, !tbaa !3
  %v398 = call ptr @mlf_thunk(ptr @mlf.code.396, ptr null)
  %v2725 = call ptr @mlf_env_new(i64 1)
  %v2726 = getelementptr i8, ptr %v2725, i64 24
  store ptr %v395, ptr %v2726, align 8, !tbaa !3
  %v2727 = call ptr @mlf_closure(ptr @mlf.code.399, ptr %v2725)
  %v2728 = call ptr @mlf_prim2(i64 1, ptr %v398, ptr %v2727)
  ret ptr %v2728
}

define private ptr @mlf.code.18(ptr %env, ptr %arg) {
entry:
  %v19 = getelementptr i8, ptr %env, i64 24
  %v20 = load ptr, ptr %v19, align 8, !tbaa !3
  %v21 = getelementptr i8, ptr %env, i64 32
  %v22 = load ptr, ptr %v21, align 8, !tbaa !3
  %v388 = call ptr @mlf_env_new(i64 3)
  %v389 = getelementptr i8, ptr %v388, i64 24
  store ptr %v20, ptr %v389, align 8, !tbaa !3
  %v390 = getelementptr i8, ptr %v388, i64 32
  store ptr %v22, ptr %v390, align 8, !tbaa !3
  %v391 = getelementptr i8, ptr %v388, i64 40
  store ptr %arg, ptr %v391, align 8, !tbaa !3
  %v392 = call ptr @mlf_thunk(ptr @mlf.code.23, ptr %v388)
  %v2729 = call ptr @mlf_env_new(i64 1)
  %v2730 = getelementptr i8, ptr %v2729, i64 24
  store ptr %v20, ptr %v2730, align 8, !tbaa !3
  %v2731 = call ptr @mlf_closure(ptr @mlf.code.393, ptr %v2729)
  %v2732 = call ptr @mlf_prim2(i64 1, ptr %v392, ptr %v2731)
  ret ptr %v2732
}

define private ptr @mlf.code.10(ptr %env, ptr %arg) {
entry:
  %v11 = getelementptr i8, ptr %env, i64 24
  %v12 = load ptr, ptr %v11, align 8, !tbaa !3
  %v17 = call ptr @mlf_thunk(ptr @mlf.code.13, ptr null)
  %v2733 = call ptr @mlf_env_new(i64 2)
  %v2734 = getelementptr i8, ptr %v2733, i64 24
  store ptr %v12, ptr %v2734, align 8, !tbaa !3
  %v2735 = getelementptr i8, ptr %v2733, i64 32
  store ptr %arg, ptr %v2735, align 8, !tbaa !3
  %v2736 = call ptr @mlf_closure(ptr @mlf.code.18, ptr %v2733)
  %v2737 = call ptr @mlf_prim2(i64 1, ptr %v17, ptr %v2736)
  ret ptr %v2737
}

define private ptr @mlf.code.4(ptr %env, ptr %arg) {
entry:
  %v9 = call ptr @mlf_thunk(ptr @mlf.code.5, ptr null)
  %v2738 = call ptr @mlf_env_new(i64 1)
  %v2739 = getelementptr i8, ptr %v2738, i64 24
  store ptr %arg, ptr %v2739, align 8, !tbaa !3
  %v2740 = call ptr @mlf_closure(ptr @mlf.code.10, ptr %v2738)
  %v2741 = call ptr @mlf_prim2(i64 1, ptr %v9, ptr %v2740)
  ret ptr %v2741
}

define private ptr @mlf.code.0(ptr %env, ptr %arg) {
entry:
  %v3 = call ptr @mlf_thunk(ptr @mlf.code.1, ptr null)
  %v2742 = call ptr @mlf_closure(ptr @mlf.code.4, ptr null)
  %v2743 = call ptr @mlf_prim2(i64 1, ptr %v3, ptr %v2742)
  ret ptr %v2743
}

declare void @mlf_require_standard_abi()
define ptr @mlf_entry() {
  call void @mlf_require_standard_abi()
  %root = call ptr @mlf.code.0(ptr null, ptr null)
  ret ptr %root
}
define i32 @main(i32 %argc, ptr %argv) {
  call void @mlf_set_args(i32 %argc, ptr %argv)
  %root = call ptr @mlf_entry()
  %status = call i32 @mlf_run(ptr %root, i64 1)
  ret i32 %status
}
