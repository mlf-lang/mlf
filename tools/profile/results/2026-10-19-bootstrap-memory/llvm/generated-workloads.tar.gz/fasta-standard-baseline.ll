; Generated from independently checked xMLF.
source_filename = "emlf"

declare ptr @mlf_execute_st_lazy(ptr)
declare ptr @mlf_st_new_array(ptr, ptr)
declare ptr @mlf_st_read_array(ptr, ptr)
declare ptr @mlf_st_write_array(ptr, ptr, ptr)
declare ptr @mlf_st_length_array(ptr)
declare void @mlf_set_args(i32, ptr)
declare ptr @mlf_env_new(i64)
declare void @mlf_env_set(ptr, i64, ptr)
declare ptr @mlf_env_get(ptr, i64)
declare ptr @mlf_thunk(ptr, ptr)
declare ptr @mlf_closure(ptr, ptr)
declare ptr @mlf_application(ptr, ptr)
declare ptr @mlf_hole()
declare void @mlf_fill(ptr, ptr)
declare ptr @mlf_integer(ptr)
declare ptr @mlf_string(ptr, i64)
declare ptr @mlf_double(double)
declare double @llvm.sqrt.f64(double)
declare double @mlf_int_to_double(ptr)
declare ptr @mlf_read_int_table(ptr, ptr)
declare ptr @mlf_write_int_table(ptr, ptr, ptr)
declare ptr @mlf_add_int_table(ptr, ptr, ptr)
declare void @mlf_roots_enter(ptr, i64, ptr)
declare void @mlf_roots_leave(ptr)
declare void @mlf_gc_check(i64, ptr)
declare ptr @mlf_get_byte_line()
declare ptr @mlf_new_array(i64, ptr, ptr)
declare ptr @mlf_bytes_from_string(ptr)
declare ptr @mlf_put_bytes(ptr, ptr, ptr)
declare ptr @mlf_new_int_table()
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare i8 @mlf_byte(ptr)
declare ptr @mlf_peek(ptr)
declare ptr @mlf_native_io(ptr, ptr)
declare void @mlf_bounds_failure() noreturn
declare ptr @mlf_primitive(i64)
declare ptr @mlf_prim1(i64, ptr)
declare ptr @mlf_prim2(i64, ptr, ptr)
declare i64 @mlf_truth(ptr)
declare ptr @mlf_prim3(i64, ptr, ptr, ptr)
declare ptr @mlf_force(ptr)
declare ptr @mlf_add_int(ptr, ptr)
declare ptr @mlf_sub_int(ptr, ptr)
declare ptr @mlf_eq_int(ptr, ptr)
declare ptr @mlf_lt_int(ptr, ptr)
declare ptr @mlf_constructor(i64, i64)
declare ptr @mlf_constructor1(i64, ptr)
declare ptr @mlf_constructor2(i64, ptr, ptr)
declare ptr @mlf_constructor_fields(i64, ptr)
declare ptr @mlf_constructor_new(i64, i64)
declare ptr @mlf_field(ptr, i64)
declare void @mlf_match_failure() noreturn
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare i32 @mlf_run(ptr, i64)

!0 = !{!"MLF storage"}
!1 = !{!"managed object", !0}
!2 = !{!"array cells", !0}
!3 = !{!1, !1, i64 0}
!4 = !{!2, !2, i64 0}
@mlf.bytes.12 = private unnamed_addr constant [288 x i8] c"\47\47\43\43\47\47\47\43\47\43\47\47\54\47\47\43\54\43\41\43\47\43\43\54\47\54\41\41\54\43\43\43\41\47\43\41\43\54\54\54\47\47\47\41\47\47\43\43\47\41\47\47\43\47\47\47\43\47\47\41\54\43\41\43\43\54\47\41\47\47\54\43\41\47\47\41\47\54\54\43\47\41\47\41\43\43\41\47\43\43\54\47\47\43\43\41\41\43\41\54\47\47\54\47\41\41\41\43\43\43\43\47\54\43\54\43\54\41\43\54\41\41\41\41\41\54\41\43\41\41\41\41\41\54\54\41\47\43\43\47\47\47\43\47\54\47\47\54\47\47\43\47\43\47\43\47\43\43\54\47\54\41\41\54\43\43\43\41\47\43\54\41\43\54\43\47\47\47\41\47\47\43\54\47\41\47\47\43\41\47\47\41\47\41\41\54\43\47\43\54\54\47\41\41\43\43\43\47\47\47\41\47\47\43\47\47\41\47\47\54\54\47\43\41\47\54\47\41\47\43\43\47\41\47\41\54\43\47\43\47\43\43\41\43\54\47\43\41\43\54\43\43\41\47\43\43\54\47\47\47\43\47\41\43\41\47\41\47\43\47\41\47\41\43\54\43\43\47\54\43\54\43\41\41\41\41\41\00", align 1
@mlf.bytes.20 = private unnamed_addr constant [16 x i8] c"\61\63\67\74\42\44\48\4b\4d\4e\52\53\56\57\59\00", align 1
@mlf.bytes.30 = private unnamed_addr constant [5 x i8] c"\61\63\67\74\00", align 1
@mlf.bytes.572 = private unnamed_addr constant [22 x i8] c"\3e\4f\4e\45\20\48\6f\6d\6f\20\73\61\70\69\65\6e\73\20\61\6c\75\00", align 1
@mlf.bytes.1910 = private unnamed_addr constant [25 x i8] c"\3e\54\57\4f\20\49\55\42\20\61\6d\62\69\67\75\69\74\79\20\63\6f\64\65\73\00", align 1
@mlf.bytes.3837 = private unnamed_addr constant [30 x i8] c"\3e\54\48\52\45\45\20\48\6f\6d\6f\20\73\61\70\69\65\6e\73\20\66\72\65\71\75\65\6e\63\79\00", align 1
define private ptr @mlf.code.3(ptr %env, ptr %arg) {
entry:
  %v4 = getelementptr i8, ptr %env, i64 24
  %v5 = load ptr, ptr %v4, align 8, !tbaa !3
  %v6 = call ptr @mlf_force(ptr %v5)
  %v7 = call ptr @mlf_prim1(i64 17, ptr %v6)
  ret ptr %v7
}

define private ptr @mlf.code.11(ptr %env, ptr %arg) {
entry:
  %v13 = call ptr @mlf_string(ptr @mlf.bytes.12, i64 287)
  %v14 = call ptr @mlf_prim1(i64 39, ptr %v13)
  ret ptr %v14
}

define private ptr @mlf.code.19(ptr %env, ptr %arg) {
entry:
  %v21 = call ptr @mlf_string(ptr @mlf.bytes.20, i64 15)
  %v22 = call ptr @mlf_prim1(i64 39, ptr %v21)
  ret ptr %v22
}

define private ptr @mlf.code.29(ptr %env, ptr %arg) {
entry:
  %v31 = call ptr @mlf_string(ptr @mlf.bytes.30, i64 4)
  %v32 = call ptr @mlf_prim1(i64 39, ptr %v31)
  ret ptr %v32
}

define private ptr @mlf.code.41(ptr %env, ptr %arg) {
entry:
  %v42 = call ptr @mlf_double(double 0x3f947ae147ae147b)
  %v43 = call ptr @mlf_prim2(i64 31, ptr inttoptr (i64 31 to ptr), ptr %v42)
  ret ptr %v43
}

define private ptr @mlf.code.54(ptr %env, ptr %arg) {
entry:
  %v55 = getelementptr i8, ptr %env, i64 24
  %v56 = load ptr, ptr %v55, align 8, !tbaa !3
  %v57 = call ptr @mlf_double(double 0x3fd147ae147ae148)
  %v58 = call ptr @mlf_prim3(i64 33, ptr %v56, ptr inttoptr (i64 1 to ptr), ptr %v57)
  ret ptr %v58
}

define private ptr @mlf.code.73(ptr %env, ptr %arg) {
entry:
  %v74 = getelementptr i8, ptr %env, i64 24
  %v75 = load ptr, ptr %v74, align 8, !tbaa !3
  %v76 = call ptr @mlf_double(double 0x3fbeb851eb851eb8)
  %v77 = call ptr @mlf_prim3(i64 33, ptr %v75, ptr inttoptr (i64 3 to ptr), ptr %v76)
  ret ptr %v77
}

define private ptr @mlf.code.92(ptr %env, ptr %arg) {
entry:
  %v93 = getelementptr i8, ptr %env, i64 24
  %v94 = load ptr, ptr %v93, align 8, !tbaa !3
  %v95 = call ptr @mlf_double(double 0x3fbeb851eb851eb8)
  %v96 = call ptr @mlf_prim3(i64 33, ptr %v94, ptr inttoptr (i64 5 to ptr), ptr %v95)
  ret ptr %v96
}

define private ptr @mlf.code.111(ptr %env, ptr %arg) {
entry:
  %v112 = getelementptr i8, ptr %env, i64 24
  %v113 = load ptr, ptr %v112, align 8, !tbaa !3
  %v114 = call ptr @mlf_double(double 0x3fd147ae147ae148)
  %v115 = call ptr @mlf_prim3(i64 33, ptr %v113, ptr inttoptr (i64 7 to ptr), ptr %v114)
  ret ptr %v115
}

define private ptr @mlf.code.130(ptr %env, ptr %arg) {
entry:
  %v131 = call ptr @mlf_double(double 0x0000000000000000)
  %v132 = call ptr @mlf_prim2(i64 31, ptr inttoptr (i64 9 to ptr), ptr %v131)
  ret ptr %v132
}

define private ptr @mlf.code.145(ptr %env, ptr %arg) {
entry:
  %v146 = getelementptr i8, ptr %env, i64 24
  %v147 = load ptr, ptr %v146, align 8, !tbaa !3
  %v148 = call ptr @mlf_double(double 0x3fd3639d20baeb5b)
  %v149 = call ptr @mlf_prim3(i64 33, ptr %v147, ptr inttoptr (i64 1 to ptr), ptr %v148)
  ret ptr %v149
}

define private ptr @mlf.code.166(ptr %env, ptr %arg) {
entry:
  %v167 = getelementptr i8, ptr %env, i64 24
  %v168 = load ptr, ptr %v167, align 8, !tbaa !3
  %v169 = call ptr @mlf_double(double 0x3fc957ae3dcd561b)
  %v170 = call ptr @mlf_prim3(i64 33, ptr %v168, ptr inttoptr (i64 3 to ptr), ptr %v169)
  ret ptr %v170
}

define private ptr @mlf.code.187(ptr %env, ptr %arg) {
entry:
  %v188 = getelementptr i8, ptr %env, i64 24
  %v189 = load ptr, ptr %v188, align 8, !tbaa !3
  %v190 = call ptr @mlf_double(double 0x3fc9493aeab6c2bf)
  %v191 = call ptr @mlf_prim3(i64 33, ptr %v189, ptr inttoptr (i64 5 to ptr), ptr %v190)
  ret ptr %v191
}

define private ptr @mlf.code.208(ptr %env, ptr %arg) {
entry:
  %v209 = getelementptr i8, ptr %env, i64 24
  %v210 = load ptr, ptr %v209, align 8, !tbaa !3
  %v211 = call ptr @mlf_double(double 0x3fd34bee4b030838)
  %v212 = call ptr @mlf_prim3(i64 33, ptr %v210, ptr inttoptr (i64 7 to ptr), ptr %v211)
  ret ptr %v212
}

define private ptr @mlf.numeric.0(ptr %a0, ptr %a1, ptr %a2) alwaysinline {
entry:
  %v251 = ptrtoint ptr %a2 to i64
  %v252 = ptrtoint ptr %a1 to i64
  %v253 = and i64 %v251, %v252
  %v254 = and i64 %v253, 1
  %v255 = icmp ne i64 %v254, 0
  br i1 %v255, label %yes.256, label %no.257
yes.256:
  %v259 = icmp slt i64 %v251, %v252
  %v260 = select i1 %v259, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.258
no.257:
  %v261 = call ptr @mlf_lt_int(ptr %a2, ptr %a1)
  br label %join.258
join.258:
  %v262 = phi ptr [ %v260, %yes.256 ], [ %v261, %no.257 ]
  %v263 = icmp eq ptr %v262, inttoptr (i64 6 to ptr)
  br i1 %v263, label %tail.yes.264, label %tail.no.265
tail.yes.264:
  %v266 = ptrtoint ptr %a2 to i64
  %v267 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v268 = and i64 %v266, %v267
  %v269 = and i64 %v268, 1
  %v270 = icmp ne i64 %v269, 0
  br i1 %v270, label %yes.271, label %no.272
yes.271:
  %v274 = sub i64 %v267, 1
  %v275 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v266, i64 %v274)
  %v276 = extractvalue { i64, i1 } %v275, 0
  %v277 = extractvalue { i64, i1 } %v275, 1
  br i1 %v277, label %yes.278, label %no.279
yes.278:
  %v281 = call ptr @mlf_sub_int(ptr %a2, ptr inttoptr (i64 3 to ptr))
  br label %join.280
no.279:
  %v282 = inttoptr i64 %v276 to ptr
  br label %join.280
join.280:
  %v283 = phi ptr [ %v281, %yes.278 ], [ %v282, %no.279 ]
  br label %join.273
no.272:
  %v284 = call ptr @mlf_sub_int(ptr %a2, ptr inttoptr (i64 3 to ptr))
  br label %join.273
join.273:
  %v285 = phi ptr [ %v283, %join.280 ], [ %v284, %no.272 ]
  %v286 = getelementptr i8, ptr %a0, i64 24
  %v287 = load i64, ptr %v286, align 8, !tbaa !3
  %v288 = getelementptr i8, ptr %a0, i64 32
  %v289 = load ptr, ptr %v288, align 8, !tbaa !3
  %v290 = ptrtoint ptr %v285 to i64
  %v291 = ashr i64 %v290, 1
  %v292 = and i64 %v290, 1
  %v293 = icmp ne i64 %v292, 0
  %v294 = icmp ult i64 %v291, %v287
  %v295 = and i1 %v293, %v294
  br i1 %v295, label %array.valid.296, label %array.invalid.297
array.invalid.297:
  call void @mlf_bounds_failure()
  unreachable
array.valid.296:
  %v298 = getelementptr i64, ptr %v289, i64 %v291
  %v299 = load double, ptr %v298, align 8, !tbaa !4
  %v300 = ptrtoint ptr %a2 to i64
  %v301 = ashr i64 %v300, 1
  %v302 = and i64 %v300, 1
  %v303 = icmp ne i64 %v302, 0
  %v304 = icmp ult i64 %v301, %v287
  %v305 = and i1 %v303, %v304
  br i1 %v305, label %array.valid.306, label %array.invalid.307
array.invalid.307:
  call void @mlf_bounds_failure()
  unreachable
array.valid.306:
  %v308 = getelementptr i64, ptr %v289, i64 %v301
  %v309 = load double, ptr %v308, align 8, !tbaa !4
  %v310 = fadd double %v299, %v309
  %v311 = ptrtoint ptr %a2 to i64
  %v312 = ashr i64 %v311, 1
  %v313 = and i64 %v311, 1
  %v314 = icmp ne i64 %v313, 0
  %v315 = icmp ult i64 %v312, %v287
  %v316 = and i1 %v314, %v315
  br i1 %v316, label %array.valid.317, label %array.invalid.318
array.invalid.318:
  call void @mlf_bounds_failure()
  unreachable
array.valid.317:
  %v319 = getelementptr i64, ptr %v289, i64 %v312
  store double %v310, ptr %v319, align 8, !tbaa !4
  %v320 = ptrtoint ptr %a2 to i64
  %v321 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v322 = sub i64 %v321, 1
  %v323 = add nsw i64 %v320, %v322
  %v324 = inttoptr i64 %v323 to ptr
  %v325 = musttail call ptr @mlf.numeric.0(ptr %a0, ptr %a1, ptr %v324)
  ret ptr %v325
tail.no.265:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.code.338(ptr %env, ptr %arg) {
entry:
  %v339 = getelementptr i8, ptr %env, i64 24
  %v340 = load ptr, ptr %v339, align 8, !tbaa !3
  %v341 = call ptr @mlf_force(ptr %v340)
  %v342 = call ptr @mlf_prim2(i64 9, ptr %v341, ptr inttoptr (i64 3 to ptr))
  ret ptr %v342
}

define private ptr @mlf.code.333(ptr %env, ptr %arg) {
entry:
  %v334 = getelementptr i8, ptr %env, i64 24
  %v335 = load ptr, ptr %v334, align 8, !tbaa !3
  %v336 = getelementptr i8, ptr %env, i64 32
  %v337 = load ptr, ptr %v336, align 8, !tbaa !3
  %v343 = call ptr @mlf_env_new(i64 1)
  %v344 = getelementptr i8, ptr %v343, i64 24
  store ptr %v337, ptr %v344, align 8, !tbaa !3
  %v345 = call ptr @mlf_thunk(ptr @mlf.code.338, ptr %v343)
  %v346 = call ptr @mlf_prim2(i64 32, ptr %v335, ptr %v345)
  ret ptr %v346
}

define private ptr @mlf.code.358(ptr %env, ptr %arg) {
entry:
  %v359 = getelementptr i8, ptr %env, i64 24
  %v360 = load ptr, ptr %v359, align 8, !tbaa !3
  %v361 = getelementptr i8, ptr %env, i64 32
  %v362 = load ptr, ptr %v361, align 8, !tbaa !3
  %v363 = call ptr @mlf_prim2(i64 32, ptr %v360, ptr %v362)
  ret ptr %v363
}

define private ptr @mlf.code.386(ptr %env, ptr %arg) {
entry:
  %v387 = getelementptr i8, ptr %env, i64 24
  %v388 = load ptr, ptr %v387, align 8, !tbaa !3
  %v389 = getelementptr i8, ptr %env, i64 32
  %v390 = load ptr, ptr %v389, align 8, !tbaa !3
  %v391 = call ptr @mlf_force(ptr %v388)
  %v392 = call ptr @mlf_force(ptr %v390)
  %v393 = call ptr @mlf_prim2(i64 18, ptr %v391, ptr %v392)
  ret ptr %v393
}

define private ptr @mlf.code.377(ptr %env, ptr %arg) {
entry:
  %v378 = getelementptr i8, ptr %env, i64 24
  %v379 = load ptr, ptr %v378, align 8, !tbaa !3
  %v380 = getelementptr i8, ptr %env, i64 32
  %v381 = load ptr, ptr %v380, align 8, !tbaa !3
  %v382 = getelementptr i8, ptr %env, i64 40
  %v383 = load ptr, ptr %v382, align 8, !tbaa !3
  %v384 = getelementptr i8, ptr %env, i64 48
  %v385 = load ptr, ptr %v384, align 8, !tbaa !3
  %v394 = call ptr @mlf_env_new(i64 2)
  %v395 = getelementptr i8, ptr %v394, i64 24
  store ptr %v383, ptr %v395, align 8, !tbaa !3
  %v396 = getelementptr i8, ptr %v394, i64 32
  store ptr %v385, ptr %v396, align 8, !tbaa !3
  %v397 = call ptr @mlf_thunk(ptr @mlf.code.386, ptr %v394)
  %v398 = call ptr @mlf_prim3(i64 33, ptr %v379, ptr %v381, ptr %v397)
  ret ptr %v398
}

define private ptr @mlf.code.405(ptr %env, ptr %arg) {
entry:
  %v406 = getelementptr i8, ptr %env, i64 24
  %v407 = load ptr, ptr %v406, align 8, !tbaa !3
  %v408 = getelementptr i8, ptr %env, i64 32
  %v409 = load ptr, ptr %v408, align 8, !tbaa !3
  %v410 = getelementptr i8, ptr %env, i64 40
  %v411 = load ptr, ptr %v410, align 8, !tbaa !3
  %v412 = call ptr @mlf_force(ptr %v409)
  %v413 = call ptr @mlf_force(ptr %v411)
  %v414 = call ptr @mlf_prim2(i64 8, ptr %v413, ptr inttoptr (i64 3 to ptr))
  %v415 = call ptr @mlf_env_new(i64 3)
  %v416 = getelementptr i8, ptr %v415, i64 24
  store ptr %v407, ptr %v416, align 8, !tbaa !3
  %v417 = getelementptr i8, ptr %v415, i64 32
  store ptr %v412, ptr %v417, align 8, !tbaa !3
  %v418 = getelementptr i8, ptr %v415, i64 40
  store ptr %v414, ptr %v418, align 8, !tbaa !3
  %v419 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.232, ptr %v415)
  ret ptr %v419
}

define private ptr @mlf.code.368(ptr %env, ptr %arg) {
entry:
  %v369 = getelementptr i8, ptr %env, i64 24
  %v370 = load ptr, ptr %v369, align 8, !tbaa !3
  %v371 = getelementptr i8, ptr %env, i64 32
  %v372 = load ptr, ptr %v371, align 8, !tbaa !3
  %v373 = getelementptr i8, ptr %env, i64 40
  %v374 = load ptr, ptr %v373, align 8, !tbaa !3
  %v375 = getelementptr i8, ptr %env, i64 48
  %v376 = load ptr, ptr %v375, align 8, !tbaa !3
  %v399 = call ptr @mlf_env_new(i64 4)
  %v400 = getelementptr i8, ptr %v399, i64 24
  store ptr %v370, ptr %v400, align 8, !tbaa !3
  %v401 = getelementptr i8, ptr %v399, i64 32
  store ptr %v374, ptr %v401, align 8, !tbaa !3
  %v402 = getelementptr i8, ptr %v399, i64 40
  store ptr %v376, ptr %v402, align 8, !tbaa !3
  %v403 = getelementptr i8, ptr %v399, i64 48
  store ptr %arg, ptr %v403, align 8, !tbaa !3
  %v404 = call ptr @mlf_thunk(ptr @mlf.code.377, ptr %v399)
  %v420 = call ptr @mlf_env_new(i64 3)
  %v421 = getelementptr i8, ptr %v420, i64 24
  store ptr %v370, ptr %v421, align 8, !tbaa !3
  %v422 = getelementptr i8, ptr %v420, i64 32
  store ptr %v372, ptr %v422, align 8, !tbaa !3
  %v423 = getelementptr i8, ptr %v420, i64 40
  store ptr %v374, ptr %v423, align 8, !tbaa !3
  %v424 = call ptr @mlf_closure(ptr @mlf.code.405, ptr %v420)
  %v425 = call ptr @mlf_prim2(i64 1, ptr %v404, ptr %v424)
  ret ptr %v425
}

define private ptr @mlf.code.351(ptr %env, ptr %arg) {
entry:
  %v352 = getelementptr i8, ptr %env, i64 24
  %v353 = load ptr, ptr %v352, align 8, !tbaa !3
  %v354 = getelementptr i8, ptr %env, i64 32
  %v355 = load ptr, ptr %v354, align 8, !tbaa !3
  %v356 = getelementptr i8, ptr %env, i64 40
  %v357 = load ptr, ptr %v356, align 8, !tbaa !3
  %v364 = call ptr @mlf_env_new(i64 2)
  %v365 = getelementptr i8, ptr %v364, i64 24
  store ptr %v353, ptr %v365, align 8, !tbaa !3
  %v366 = getelementptr i8, ptr %v364, i64 32
  store ptr %v357, ptr %v366, align 8, !tbaa !3
  %v367 = call ptr @mlf_thunk(ptr @mlf.code.358, ptr %v364)
  %v426 = call ptr @mlf_env_new(i64 4)
  %v427 = getelementptr i8, ptr %v426, i64 24
  store ptr %v353, ptr %v427, align 8, !tbaa !3
  %v428 = getelementptr i8, ptr %v426, i64 32
  store ptr %v355, ptr %v428, align 8, !tbaa !3
  %v429 = getelementptr i8, ptr %v426, i64 40
  store ptr %v357, ptr %v429, align 8, !tbaa !3
  %v430 = getelementptr i8, ptr %v426, i64 48
  store ptr %arg, ptr %v430, align 8, !tbaa !3
  %v431 = call ptr @mlf_closure(ptr @mlf.code.368, ptr %v426)
  %v432 = call ptr @mlf_prim2(i64 1, ptr %v367, ptr %v431)
  ret ptr %v432
}

define private ptr @mlf.worker.0(ptr %a0, ptr %a1, ptr %a2) {
entry:
  %v328 = call ptr @mlf_prim2(i64 11, ptr %a2, ptr %a1)
  %v329 = icmp eq ptr %v328, inttoptr (i64 6 to ptr)
  br i1 %v329, label %yes.330, label %no.331
yes.330:
  %v347 = call ptr @mlf_env_new(i64 2)
  %v348 = getelementptr i8, ptr %v347, i64 24
  store ptr %a0, ptr %v348, align 8, !tbaa !3
  %v349 = getelementptr i8, ptr %v347, i64 32
  store ptr %a2, ptr %v349, align 8, !tbaa !3
  %v350 = call ptr @mlf_thunk(ptr @mlf.code.333, ptr %v347)
  %v433 = call ptr @mlf_env_new(i64 3)
  %v434 = getelementptr i8, ptr %v433, i64 24
  store ptr %a0, ptr %v434, align 8, !tbaa !3
  %v435 = getelementptr i8, ptr %v433, i64 32
  store ptr %a1, ptr %v435, align 8, !tbaa !3
  %v436 = getelementptr i8, ptr %v433, i64 40
  store ptr %a2, ptr %v436, align 8, !tbaa !3
  %v437 = call ptr @mlf_closure(ptr @mlf.code.351, ptr %v433)
  %v438 = call ptr @mlf_prim2(i64 1, ptr %v350, ptr %v437)
  br label %join.332
no.331:
  %v439 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.332
join.332:
  %v440 = phi ptr [ %v438, %yes.330 ], [ %v439, %no.331 ]
  ret ptr %v440
}

define private ptr @mlf.numeric.entry.232(ptr %env, ptr %arg) {
entry:
  %v233 = getelementptr i8, ptr %env, i64 24
  %v234 = load ptr, ptr %v233, align 8, !tbaa !3
  %v235 = getelementptr i8, ptr %env, i64 32
  %v236 = load ptr, ptr %v235, align 8, !tbaa !3
  %v237 = getelementptr i8, ptr %env, i64 40
  %v238 = load ptr, ptr %v237, align 8, !tbaa !3
  %v239 = call ptr @mlf_peek(ptr %v234)
  %v240 = call ptr @mlf_peek(ptr %v236)
  %v241 = call ptr @mlf_peek(ptr %v238)
  %v242 = icmp ne ptr %v239, null
  %v243 = icmp ne ptr %v240, null
  %v244 = icmp ne ptr %v241, null
  %v245 = and i1 true, %v242
  %v246 = and i1 %v245, %v243
  %v247 = and i1 %v246, %v244
  br i1 %v247, label %yes.248, label %no.249
yes.248:
  %v326 = call ptr @mlf.numeric.0(ptr %v239, ptr %v240, ptr %v241)
  %v327 = call ptr @mlf_prim1(i64 0, ptr %v326)
  br label %join.250
no.249:
  %v441 = call ptr @mlf_force(ptr %v236)
  %v442 = call ptr @mlf_force(ptr %v238)
  %v443 = call ptr @mlf.worker.0(ptr %v234, ptr %v441, ptr %v442)
  br label %join.250
join.250:
  %v444 = phi ptr [ %v327, %yes.248 ], [ %v443, %no.249 ]
  ret ptr %v444
}

define private ptr @mlf.code.229(ptr %env, ptr %arg) {
entry:
  %v230 = getelementptr i8, ptr %env, i64 24
  %v231 = load ptr, ptr %v230, align 8, !tbaa !3
  %v445 = call ptr @mlf_env_new(i64 3)
  %v446 = getelementptr i8, ptr %v445, i64 24
  store ptr %v231, ptr %v446, align 8, !tbaa !3
  %v447 = getelementptr i8, ptr %v445, i64 32
  store ptr inttoptr (i64 31 to ptr), ptr %v447, align 8, !tbaa !3
  %v448 = getelementptr i8, ptr %v445, i64 40
  store ptr inttoptr (i64 3 to ptr), ptr %v448, align 8, !tbaa !3
  %v449 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.232, ptr %v445)
  ret ptr %v449
}

define private ptr @mlf.code.466(ptr %env, ptr %arg) {
entry:
  %v467 = getelementptr i8, ptr %env, i64 24
  %v468 = load ptr, ptr %v467, align 8, !tbaa !3
  %v469 = call ptr @mlf_env_new(i64 3)
  %v470 = getelementptr i8, ptr %v469, i64 24
  store ptr %v468, ptr %v470, align 8, !tbaa !3
  %v471 = getelementptr i8, ptr %v469, i64 32
  store ptr inttoptr (i64 9 to ptr), ptr %v471, align 8, !tbaa !3
  %v472 = getelementptr i8, ptr %v469, i64 40
  store ptr inttoptr (i64 3 to ptr), ptr %v472, align 8, !tbaa !3
  %v473 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.232, ptr %v469)
  ret ptr %v473
}

define private ptr @mlf.code.490(ptr %env, ptr %arg) {
entry:
  %v491 = call ptr @mlf_prim2(i64 35, ptr inttoptr (i64 124929 to ptr), ptr inttoptr (i64 1 to ptr))
  ret ptr %v491
}

define private ptr @mlf.code.506(ptr %env, ptr %arg) {
entry:
  %v507 = call ptr @mlf_prim2(i64 27, ptr inttoptr (i64 3 to ptr), ptr inttoptr (i64 85 to ptr))
  ret ptr %v507
}

define private ptr @mlf.code.524(ptr %env, ptr %arg) {
entry:
  %v525 = call ptr @mlf_double(double 0x0000000000000000)
  %v526 = call ptr @mlf_prim2(i64 31, ptr inttoptr (i64 3 to ptr), ptr %v525)
  ret ptr %v526
}

define private ptr @mlf.code.545(ptr %env, ptr %arg) {
entry:
  %v546 = getelementptr i8, ptr %env, i64 24
  %v547 = load ptr, ptr %v546, align 8, !tbaa !3
  %v548 = call ptr @mlf_prim1(i64 38, ptr %v547)
  ret ptr %v548
}

define private ptr @mlf.code.571(ptr %env, ptr %arg) {
entry:
  %v573 = call ptr @mlf_string(ptr @mlf.bytes.572, i64 21)
  %v574 = call ptr @mlf_prim1(i64 3, ptr %v573)
  ret ptr %v574
}

define private ptr @mlf.numeric.16.ppiiiiii(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6, ptr %a7) alwaysinline {
entry:
  %v705 = ptrtoint ptr %a6 to i64
  %v706 = ptrtoint ptr %a7 to i64
  %v707 = sub i64 %v706, 1
  %v708 = add nsw i64 %v705, %v707
  %v709 = inttoptr i64 %v708 to ptr
  %v710 = ptrtoint ptr %a5 to i64
  %v711 = ptrtoint ptr %v709 to i64
  %v712 = sub i64 %v711, 1
  %v713 = add nsw i64 %v710, %v712
  %v714 = inttoptr i64 %v713 to ptr
  %v715 = ptrtoint ptr %a4 to i64
  %v716 = ptrtoint ptr %v714 to i64
  %v717 = sub i64 %v716, 1
  %v718 = add nsw i64 %v715, %v717
  %v719 = inttoptr i64 %v718 to ptr
  %v720 = icmp eq ptr inttoptr (i64 6 to ptr), inttoptr (i64 6 to ptr)
  br i1 %v720, label %tail.yes.721, label %tail.no.722
tail.yes.721:
  %v723 = ptrtoint ptr %a6 to i64
  %v724 = ptrtoint ptr inttoptr (i64 121 to ptr) to i64
  %v725 = icmp eq i64 %v723, %v724
  %v726 = select i1 %v725, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v727 = icmp eq ptr %v726, inttoptr (i64 6 to ptr)
  br i1 %v727, label %tail.yes.728, label %tail.no.729
tail.yes.728:
  %v730 = getelementptr i8, ptr %a1, i64 24
  %v731 = load i64, ptr %v730, align 8, !tbaa !3
  %v732 = getelementptr i8, ptr %a1, i64 32
  %v733 = load ptr, ptr %v732, align 8, !tbaa !3
  %v734 = ptrtoint ptr %a7 to i64
  %v735 = ashr i64 %v734, 1
  %v736 = and i64 %v734, 1
  %v737 = icmp ne i64 %v736, 0
  %v738 = icmp ult i64 %v735, %v731
  %v739 = and i1 %v737, %v738
  br i1 %v739, label %array.valid.740, label %array.invalid.741
array.invalid.741:
  call void @mlf_bounds_failure()
  unreachable
array.valid.740:
  %v742 = getelementptr i8, ptr %v733, i64 %v735
  %v743 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v744 = ashr i64 %v743, 1
  %v745 = trunc i64 %v744 to i8
  store i8 %v745, ptr %v742, align 1, !tbaa !4
  %v746 = ptrtoint ptr %a7 to i64
  %v747 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v748 = sub i64 %v747, 1
  %v749 = add nsw i64 %v746, %v748
  %v750 = inttoptr i64 %v749 to ptr
  %v751 = musttail call ptr @mlf.numeric.16.ppppppnp(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr inttoptr (i64 1 to ptr), ptr %v750)
  ret ptr %v751
tail.no.729:
  %v752 = ptrtoint ptr %a4 to i64
  %v753 = ptrtoint ptr %a3 to i64
  %v754 = icmp eq i64 %v752, %v753
  %v755 = select i1 %v754, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v756 = icmp eq ptr %v755, inttoptr (i64 6 to ptr)
  br i1 %v756, label %tail.yes.757, label %tail.no.758
tail.yes.757:
  %v759 = ptrtoint ptr %a6 to i64
  %v760 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v761 = icmp eq i64 %v759, %v760
  %v762 = select i1 %v761, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v763 = icmp eq ptr %v762, inttoptr (i64 6 to ptr)
  br i1 %v763, label %tail.yes.764, label %tail.no.765
tail.yes.764:
  ret ptr %a5
tail.no.765:
  %v766 = getelementptr i8, ptr %a1, i64 24
  %v767 = load i64, ptr %v766, align 8, !tbaa !3
  %v768 = getelementptr i8, ptr %a1, i64 32
  %v769 = load ptr, ptr %v768, align 8, !tbaa !3
  %v770 = ptrtoint ptr %a7 to i64
  %v771 = ashr i64 %v770, 1
  %v772 = and i64 %v770, 1
  %v773 = icmp ne i64 %v772, 0
  %v774 = icmp ult i64 %v771, %v767
  %v775 = and i1 %v773, %v774
  br i1 %v775, label %array.valid.776, label %array.invalid.777
array.invalid.777:
  call void @mlf_bounds_failure()
  unreachable
array.valid.776:
  %v778 = getelementptr i8, ptr %v769, i64 %v771
  %v779 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v780 = ashr i64 %v779, 1
  %v781 = trunc i64 %v780 to i8
  store i8 %v781, ptr %v778, align 1, !tbaa !4
  ret ptr %a5
tail.no.758:
  %v782 = getelementptr i8, ptr %a0, i64 24
  %v783 = load i64, ptr %v782, align 8, !tbaa !3
  %v784 = getelementptr i8, ptr %a0, i64 32
  %v785 = load ptr, ptr %v784, align 8, !tbaa !3
  %v786 = ptrtoint ptr %a5 to i64
  %v787 = ashr i64 %v786, 1
  %v788 = and i64 %v786, 1
  %v789 = icmp ne i64 %v788, 0
  %v790 = icmp ult i64 %v787, %v783
  %v791 = and i1 %v789, %v790
  br i1 %v791, label %array.valid.792, label %array.invalid.793
array.invalid.793:
  call void @mlf_bounds_failure()
  unreachable
array.valid.792:
  %v794 = getelementptr i8, ptr %v785, i64 %v787
  %v795 = load i8, ptr %v794, align 1, !tbaa !4
  %v796 = zext i8 %v795 to i64
  %v797 = shl i64 %v796, 1
  %v798 = or i64 %v797, 1
  %v799 = inttoptr i64 %v798 to ptr
  %v800 = getelementptr i8, ptr %a1, i64 24
  %v801 = load i64, ptr %v800, align 8, !tbaa !3
  %v802 = getelementptr i8, ptr %a1, i64 32
  %v803 = load ptr, ptr %v802, align 8, !tbaa !3
  %v804 = ptrtoint ptr %a7 to i64
  %v805 = ashr i64 %v804, 1
  %v806 = and i64 %v804, 1
  %v807 = icmp ne i64 %v806, 0
  %v808 = icmp ult i64 %v805, %v801
  %v809 = and i1 %v807, %v808
  br i1 %v809, label %array.valid.810, label %array.invalid.811
array.invalid.811:
  call void @mlf_bounds_failure()
  unreachable
array.valid.810:
  %v812 = getelementptr i8, ptr %v803, i64 %v805
  %v813 = ptrtoint ptr %v799 to i64
  %v814 = ashr i64 %v813, 1
  %v815 = trunc i64 %v814 to i8
  store i8 %v815, ptr %v812, align 1, !tbaa !4
  %v816 = ptrtoint ptr %a5 to i64
  %v817 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v818 = sub i64 %v817, 1
  %v819 = add nsw i64 %v816, %v818
  %v820 = inttoptr i64 %v819 to ptr
  %v821 = ptrtoint ptr %v820 to i64
  %v822 = ptrtoint ptr %a2 to i64
  %v823 = icmp slt i64 %v821, %v822
  %v824 = select i1 %v823, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v825 = icmp eq ptr %v824, inttoptr (i64 6 to ptr)
  br i1 %v825, label %yes.826, label %no.827
yes.826:
  %v829 = ptrtoint ptr %a5 to i64
  %v830 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v831 = sub i64 %v830, 1
  %v832 = add nsw i64 %v829, %v831
  %v833 = inttoptr i64 %v832 to ptr
  br label %join.828
no.827:
  br label %join.828
join.828:
  %v834 = phi ptr [ %v833, %yes.826 ], [ inttoptr (i64 1 to ptr), %no.827 ]
  %v835 = ptrtoint ptr %a4 to i64
  %v836 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v837 = sub i64 %v836, 1
  %v838 = add nsw i64 %v835, %v837
  %v839 = inttoptr i64 %v838 to ptr
  %v840 = ptrtoint ptr %a6 to i64
  %v841 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v842 = sub i64 %v841, 1
  %v843 = add nsw i64 %v840, %v842
  %v844 = inttoptr i64 %v843 to ptr
  %v845 = ptrtoint ptr %a7 to i64
  %v846 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v847 = sub i64 %v846, 1
  %v848 = add nsw i64 %v845, %v847
  %v849 = inttoptr i64 %v848 to ptr
  %v850 = musttail call ptr @mlf.numeric.16.ppppppnp(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %v839, ptr %v834, ptr %v844, ptr %v849)
  ret ptr %v850
tail.no.722:
  ret ptr inttoptr (i64 1 to ptr)
}

define private ptr @mlf.numeric.16(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6, ptr %a7) alwaysinline {
entry:
  %v1088 = ptrtoint ptr %a2 to i64
  %v1089 = and i64 %v1088, 1
  %v1090 = icmp ne i64 %v1089, 0
  %v1091 = icmp ult i64 %v1088, 4294967296
  %v1092 = and i1 %v1090, %v1091
  %v1093 = ptrtoint ptr %a3 to i64
  %v1094 = and i64 %v1093, 1
  %v1095 = icmp ne i64 %v1094, 0
  %v1096 = icmp ult i64 %v1093, 4294967296
  %v1097 = and i1 %v1095, %v1096
  %v1098 = ptrtoint ptr %a4 to i64
  %v1099 = and i64 %v1098, 1
  %v1100 = icmp ne i64 %v1099, 0
  %v1101 = icmp ult i64 %v1098, 4294967296
  %v1102 = and i1 %v1100, %v1101
  %v1103 = ptrtoint ptr %a5 to i64
  %v1104 = and i64 %v1103, 1
  %v1105 = icmp ne i64 %v1104, 0
  %v1106 = icmp ult i64 %v1103, 4294967296
  %v1107 = and i1 %v1105, %v1106
  %v1108 = ptrtoint ptr %a6 to i64
  %v1109 = and i64 %v1108, 1
  %v1110 = icmp ne i64 %v1109, 0
  %v1111 = icmp ult i64 %v1108, 4294967296
  %v1112 = and i1 %v1110, %v1111
  %v1113 = ptrtoint ptr %a7 to i64
  %v1114 = and i64 %v1113, 1
  %v1115 = icmp ne i64 %v1114, 0
  %v1116 = icmp ult i64 %v1113, 4294967296
  %v1117 = and i1 %v1115, %v1116
  %v1118 = and i1 true, %v1092
  %v1119 = and i1 %v1118, %v1097
  %v1120 = and i1 %v1119, %v1102
  %v1121 = and i1 %v1120, %v1107
  %v1122 = and i1 %v1121, %v1112
  %v1123 = and i1 %v1122, %v1117
  br i1 %v1123, label %range.fast.1124, label %range.general.1125
range.fast.1124:
  %v1126 = musttail call ptr @mlf.numeric.16.ppiiiiii(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6, ptr %a7)
  ret ptr %v1126
range.general.1125:
  %v1127 = ptrtoint ptr %a6 to i64
  %v1128 = ptrtoint ptr %a7 to i64
  %v1129 = and i64 %v1127, %v1128
  %v1130 = and i64 %v1129, 1
  %v1131 = icmp ne i64 %v1130, 0
  br i1 %v1131, label %yes.1132, label %no.1133
yes.1132:
  %v1135 = sub i64 %v1128, 1
  %v1136 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1127, i64 %v1135)
  %v1137 = extractvalue { i64, i1 } %v1136, 0
  %v1138 = extractvalue { i64, i1 } %v1136, 1
  br i1 %v1138, label %yes.1139, label %no.1140
yes.1139:
  %v1142 = call ptr @mlf_add_int(ptr %a6, ptr %a7)
  br label %join.1141
no.1140:
  %v1143 = inttoptr i64 %v1137 to ptr
  br label %join.1141
join.1141:
  %v1144 = phi ptr [ %v1142, %yes.1139 ], [ %v1143, %no.1140 ]
  br label %join.1134
no.1133:
  %v1145 = call ptr @mlf_add_int(ptr %a6, ptr %a7)
  br label %join.1134
join.1134:
  %v1146 = phi ptr [ %v1144, %join.1141 ], [ %v1145, %no.1133 ]
  %v1147 = ptrtoint ptr %a5 to i64
  %v1148 = ptrtoint ptr %v1146 to i64
  %v1149 = and i64 %v1147, %v1148
  %v1150 = and i64 %v1149, 1
  %v1151 = icmp ne i64 %v1150, 0
  br i1 %v1151, label %yes.1152, label %no.1153
yes.1152:
  %v1155 = sub i64 %v1148, 1
  %v1156 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1147, i64 %v1155)
  %v1157 = extractvalue { i64, i1 } %v1156, 0
  %v1158 = extractvalue { i64, i1 } %v1156, 1
  br i1 %v1158, label %yes.1159, label %no.1160
yes.1159:
  %v1162 = call ptr @mlf_add_int(ptr %a5, ptr %v1146)
  br label %join.1161
no.1160:
  %v1163 = inttoptr i64 %v1157 to ptr
  br label %join.1161
join.1161:
  %v1164 = phi ptr [ %v1162, %yes.1159 ], [ %v1163, %no.1160 ]
  br label %join.1154
no.1153:
  %v1165 = call ptr @mlf_add_int(ptr %a5, ptr %v1146)
  br label %join.1154
join.1154:
  %v1166 = phi ptr [ %v1164, %join.1161 ], [ %v1165, %no.1153 ]
  %v1167 = ptrtoint ptr %a4 to i64
  %v1168 = ptrtoint ptr %v1166 to i64
  %v1169 = and i64 %v1167, %v1168
  %v1170 = and i64 %v1169, 1
  %v1171 = icmp ne i64 %v1170, 0
  br i1 %v1171, label %yes.1172, label %no.1173
yes.1172:
  %v1175 = sub i64 %v1168, 1
  %v1176 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1167, i64 %v1175)
  %v1177 = extractvalue { i64, i1 } %v1176, 0
  %v1178 = extractvalue { i64, i1 } %v1176, 1
  br i1 %v1178, label %yes.1179, label %no.1180
yes.1179:
  %v1182 = call ptr @mlf_add_int(ptr %a4, ptr %v1166)
  br label %join.1181
no.1180:
  %v1183 = inttoptr i64 %v1177 to ptr
  br label %join.1181
join.1181:
  %v1184 = phi ptr [ %v1182, %yes.1179 ], [ %v1183, %no.1180 ]
  br label %join.1174
no.1173:
  %v1185 = call ptr @mlf_add_int(ptr %a4, ptr %v1166)
  br label %join.1174
join.1174:
  %v1186 = phi ptr [ %v1184, %join.1181 ], [ %v1185, %no.1173 ]
  %v1187 = icmp eq ptr inttoptr (i64 6 to ptr), inttoptr (i64 6 to ptr)
  br i1 %v1187, label %tail.yes.1188, label %tail.no.1189
tail.yes.1188:
  %v1190 = ptrtoint ptr %a6 to i64
  %v1191 = ptrtoint ptr inttoptr (i64 121 to ptr) to i64
  %v1192 = and i64 %v1190, %v1191
  %v1193 = and i64 %v1192, 1
  %v1194 = icmp ne i64 %v1193, 0
  br i1 %v1194, label %yes.1195, label %no.1196
yes.1195:
  %v1198 = icmp eq i64 %v1190, %v1191
  %v1199 = select i1 %v1198, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1197
no.1196:
  %v1200 = call ptr @mlf_eq_int(ptr %a6, ptr inttoptr (i64 121 to ptr))
  br label %join.1197
join.1197:
  %v1201 = phi ptr [ %v1199, %yes.1195 ], [ %v1200, %no.1196 ]
  %v1202 = icmp eq ptr %v1201, inttoptr (i64 6 to ptr)
  br i1 %v1202, label %tail.yes.1203, label %tail.no.1204
tail.yes.1203:
  %v1205 = getelementptr i8, ptr %a1, i64 24
  %v1206 = load i64, ptr %v1205, align 8, !tbaa !3
  %v1207 = getelementptr i8, ptr %a1, i64 32
  %v1208 = load ptr, ptr %v1207, align 8, !tbaa !3
  %v1209 = ptrtoint ptr %a7 to i64
  %v1210 = ashr i64 %v1209, 1
  %v1211 = and i64 %v1209, 1
  %v1212 = icmp ne i64 %v1211, 0
  %v1213 = icmp ult i64 %v1210, %v1206
  %v1214 = and i1 %v1212, %v1213
  br i1 %v1214, label %array.valid.1215, label %array.invalid.1216
array.invalid.1216:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1215:
  %v1217 = getelementptr i8, ptr %v1208, i64 %v1210
  %v1218 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v1219 = ashr i64 %v1218, 1
  %v1220 = trunc i64 %v1219 to i8
  store i8 %v1220, ptr %v1217, align 1, !tbaa !4
  %v1221 = ptrtoint ptr %a7 to i64
  %v1222 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1223 = sub i64 %v1222, 1
  %v1224 = add nsw i64 %v1221, %v1223
  %v1225 = inttoptr i64 %v1224 to ptr
  %v1226 = musttail call ptr @mlf.numeric.16.ppppppnp(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr inttoptr (i64 1 to ptr), ptr %v1225)
  ret ptr %v1226
tail.no.1204:
  %v1227 = ptrtoint ptr %a4 to i64
  %v1228 = ptrtoint ptr %a3 to i64
  %v1229 = and i64 %v1227, %v1228
  %v1230 = and i64 %v1229, 1
  %v1231 = icmp ne i64 %v1230, 0
  br i1 %v1231, label %yes.1232, label %no.1233
yes.1232:
  %v1235 = icmp eq i64 %v1227, %v1228
  %v1236 = select i1 %v1235, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1234
no.1233:
  %v1237 = call ptr @mlf_eq_int(ptr %a4, ptr %a3)
  br label %join.1234
join.1234:
  %v1238 = phi ptr [ %v1236, %yes.1232 ], [ %v1237, %no.1233 ]
  %v1239 = icmp eq ptr %v1238, inttoptr (i64 6 to ptr)
  br i1 %v1239, label %tail.yes.1240, label %tail.no.1241
tail.yes.1240:
  %v1242 = ptrtoint ptr %a6 to i64
  %v1243 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v1244 = and i64 %v1242, %v1243
  %v1245 = and i64 %v1244, 1
  %v1246 = icmp ne i64 %v1245, 0
  br i1 %v1246, label %yes.1247, label %no.1248
yes.1247:
  %v1250 = icmp eq i64 %v1242, %v1243
  %v1251 = select i1 %v1250, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1249
no.1248:
  %v1252 = call ptr @mlf_eq_int(ptr %a6, ptr inttoptr (i64 1 to ptr))
  br label %join.1249
join.1249:
  %v1253 = phi ptr [ %v1251, %yes.1247 ], [ %v1252, %no.1248 ]
  %v1254 = icmp eq ptr %v1253, inttoptr (i64 6 to ptr)
  br i1 %v1254, label %tail.yes.1255, label %tail.no.1256
tail.yes.1255:
  ret ptr %a5
tail.no.1256:
  %v1257 = getelementptr i8, ptr %a1, i64 24
  %v1258 = load i64, ptr %v1257, align 8, !tbaa !3
  %v1259 = getelementptr i8, ptr %a1, i64 32
  %v1260 = load ptr, ptr %v1259, align 8, !tbaa !3
  %v1261 = ptrtoint ptr %a7 to i64
  %v1262 = ashr i64 %v1261, 1
  %v1263 = and i64 %v1261, 1
  %v1264 = icmp ne i64 %v1263, 0
  %v1265 = icmp ult i64 %v1262, %v1258
  %v1266 = and i1 %v1264, %v1265
  br i1 %v1266, label %array.valid.1267, label %array.invalid.1268
array.invalid.1268:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1267:
  %v1269 = getelementptr i8, ptr %v1260, i64 %v1262
  %v1270 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v1271 = ashr i64 %v1270, 1
  %v1272 = trunc i64 %v1271 to i8
  store i8 %v1272, ptr %v1269, align 1, !tbaa !4
  ret ptr %a5
tail.no.1241:
  %v1273 = getelementptr i8, ptr %a0, i64 24
  %v1274 = load i64, ptr %v1273, align 8, !tbaa !3
  %v1275 = getelementptr i8, ptr %a0, i64 32
  %v1276 = load ptr, ptr %v1275, align 8, !tbaa !3
  %v1277 = ptrtoint ptr %a5 to i64
  %v1278 = ashr i64 %v1277, 1
  %v1279 = and i64 %v1277, 1
  %v1280 = icmp ne i64 %v1279, 0
  %v1281 = icmp ult i64 %v1278, %v1274
  %v1282 = and i1 %v1280, %v1281
  br i1 %v1282, label %array.valid.1283, label %array.invalid.1284
array.invalid.1284:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1283:
  %v1285 = getelementptr i8, ptr %v1276, i64 %v1278
  %v1286 = load i8, ptr %v1285, align 1, !tbaa !4
  %v1287 = zext i8 %v1286 to i64
  %v1288 = shl i64 %v1287, 1
  %v1289 = or i64 %v1288, 1
  %v1290 = inttoptr i64 %v1289 to ptr
  %v1291 = getelementptr i8, ptr %a1, i64 24
  %v1292 = load i64, ptr %v1291, align 8, !tbaa !3
  %v1293 = getelementptr i8, ptr %a1, i64 32
  %v1294 = load ptr, ptr %v1293, align 8, !tbaa !3
  %v1295 = ptrtoint ptr %a7 to i64
  %v1296 = ashr i64 %v1295, 1
  %v1297 = and i64 %v1295, 1
  %v1298 = icmp ne i64 %v1297, 0
  %v1299 = icmp ult i64 %v1296, %v1292
  %v1300 = and i1 %v1298, %v1299
  br i1 %v1300, label %array.valid.1301, label %array.invalid.1302
array.invalid.1302:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1301:
  %v1303 = getelementptr i8, ptr %v1294, i64 %v1296
  %v1304 = ptrtoint ptr %v1290 to i64
  %v1305 = ashr i64 %v1304, 1
  %v1306 = trunc i64 %v1305 to i8
  store i8 %v1306, ptr %v1303, align 1, !tbaa !4
  %v1307 = ptrtoint ptr %a5 to i64
  %v1308 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1309 = sub i64 %v1308, 1
  %v1310 = add nsw i64 %v1307, %v1309
  %v1311 = inttoptr i64 %v1310 to ptr
  %v1312 = ptrtoint ptr %v1311 to i64
  %v1313 = ptrtoint ptr %a2 to i64
  %v1314 = and i64 %v1312, %v1313
  %v1315 = and i64 %v1314, 1
  %v1316 = icmp ne i64 %v1315, 0
  br i1 %v1316, label %yes.1317, label %no.1318
yes.1317:
  %v1320 = icmp slt i64 %v1312, %v1313
  %v1321 = select i1 %v1320, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1319
no.1318:
  %v1322 = call ptr @mlf_lt_int(ptr %v1311, ptr %a2)
  br label %join.1319
join.1319:
  %v1323 = phi ptr [ %v1321, %yes.1317 ], [ %v1322, %no.1318 ]
  %v1324 = icmp eq ptr %v1323, inttoptr (i64 6 to ptr)
  br i1 %v1324, label %yes.1325, label %no.1326
yes.1325:
  %v1328 = ptrtoint ptr %a5 to i64
  %v1329 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1330 = sub i64 %v1329, 1
  %v1331 = add nsw i64 %v1328, %v1330
  %v1332 = inttoptr i64 %v1331 to ptr
  br label %join.1327
no.1326:
  br label %join.1327
join.1327:
  %v1333 = phi ptr [ %v1332, %yes.1325 ], [ inttoptr (i64 1 to ptr), %no.1326 ]
  %v1334 = ptrtoint ptr %a4 to i64
  %v1335 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1336 = and i64 %v1334, %v1335
  %v1337 = and i64 %v1336, 1
  %v1338 = icmp ne i64 %v1337, 0
  br i1 %v1338, label %yes.1339, label %no.1340
yes.1339:
  %v1342 = sub i64 %v1335, 1
  %v1343 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1334, i64 %v1342)
  %v1344 = extractvalue { i64, i1 } %v1343, 0
  %v1345 = extractvalue { i64, i1 } %v1343, 1
  br i1 %v1345, label %yes.1346, label %no.1347
yes.1346:
  %v1349 = call ptr @mlf_add_int(ptr %a4, ptr inttoptr (i64 3 to ptr))
  br label %join.1348
no.1347:
  %v1350 = inttoptr i64 %v1344 to ptr
  br label %join.1348
join.1348:
  %v1351 = phi ptr [ %v1349, %yes.1346 ], [ %v1350, %no.1347 ]
  br label %join.1341
no.1340:
  %v1352 = call ptr @mlf_add_int(ptr %a4, ptr inttoptr (i64 3 to ptr))
  br label %join.1341
join.1341:
  %v1353 = phi ptr [ %v1351, %join.1348 ], [ %v1352, %no.1340 ]
  %v1354 = ptrtoint ptr %a6 to i64
  %v1355 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1356 = and i64 %v1354, %v1355
  %v1357 = and i64 %v1356, 1
  %v1358 = icmp ne i64 %v1357, 0
  br i1 %v1358, label %yes.1359, label %no.1360
yes.1359:
  %v1362 = sub i64 %v1355, 1
  %v1363 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1354, i64 %v1362)
  %v1364 = extractvalue { i64, i1 } %v1363, 0
  %v1365 = extractvalue { i64, i1 } %v1363, 1
  br i1 %v1365, label %yes.1366, label %no.1367
yes.1366:
  %v1369 = call ptr @mlf_add_int(ptr %a6, ptr inttoptr (i64 3 to ptr))
  br label %join.1368
no.1367:
  %v1370 = inttoptr i64 %v1364 to ptr
  br label %join.1368
join.1368:
  %v1371 = phi ptr [ %v1369, %yes.1366 ], [ %v1370, %no.1367 ]
  br label %join.1361
no.1360:
  %v1372 = call ptr @mlf_add_int(ptr %a6, ptr inttoptr (i64 3 to ptr))
  br label %join.1361
join.1361:
  %v1373 = phi ptr [ %v1371, %join.1368 ], [ %v1372, %no.1360 ]
  %v1374 = ptrtoint ptr %a7 to i64
  %v1375 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1376 = sub i64 %v1375, 1
  %v1377 = add nsw i64 %v1374, %v1376
  %v1378 = inttoptr i64 %v1377 to ptr
  %v1379 = musttail call ptr @mlf.numeric.16(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %v1353, ptr %v1333, ptr %v1373, ptr %v1378)
  ret ptr %v1379
tail.no.1189:
  ret ptr inttoptr (i64 1 to ptr)
}

define private ptr @mlf.numeric.16.ppppppnp(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6, ptr %a7) alwaysinline {
entry:
  %v667 = ptrtoint ptr %a2 to i64
  %v668 = and i64 %v667, 1
  %v669 = icmp ne i64 %v668, 0
  %v670 = icmp ult i64 %v667, 4294967296
  %v671 = and i1 %v669, %v670
  %v672 = ptrtoint ptr %a3 to i64
  %v673 = and i64 %v672, 1
  %v674 = icmp ne i64 %v673, 0
  %v675 = icmp ult i64 %v672, 4294967296
  %v676 = and i1 %v674, %v675
  %v677 = ptrtoint ptr %a4 to i64
  %v678 = and i64 %v677, 1
  %v679 = icmp ne i64 %v678, 0
  %v680 = icmp ult i64 %v677, 4294967296
  %v681 = and i1 %v679, %v680
  %v682 = ptrtoint ptr %a5 to i64
  %v683 = and i64 %v682, 1
  %v684 = icmp ne i64 %v683, 0
  %v685 = icmp ult i64 %v682, 4294967296
  %v686 = and i1 %v684, %v685
  %v687 = ptrtoint ptr %a6 to i64
  %v688 = and i64 %v687, 1
  %v689 = icmp ne i64 %v688, 0
  %v690 = icmp ult i64 %v687, 4294967296
  %v691 = and i1 %v689, %v690
  %v692 = ptrtoint ptr %a7 to i64
  %v693 = and i64 %v692, 1
  %v694 = icmp ne i64 %v693, 0
  %v695 = icmp ult i64 %v692, 4294967296
  %v696 = and i1 %v694, %v695
  %v697 = and i1 true, %v671
  %v698 = and i1 %v697, %v676
  %v699 = and i1 %v698, %v681
  %v700 = and i1 %v699, %v686
  %v701 = and i1 %v700, %v691
  %v702 = and i1 %v701, %v696
  br i1 %v702, label %range.fast.703, label %range.general.704
range.fast.703:
  %v851 = musttail call ptr @mlf.numeric.16.ppiiiiii(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6, ptr %a7)
  ret ptr %v851
range.general.704:
  %v852 = ptrtoint ptr %a6 to i64
  %v853 = ptrtoint ptr %a7 to i64
  %v854 = and i64 %v852, %v853
  %v855 = and i64 %v854, 1
  %v856 = icmp ne i64 %v855, 0
  br i1 %v856, label %yes.857, label %no.858
yes.857:
  %v860 = sub i64 %v853, 1
  %v861 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v852, i64 %v860)
  %v862 = extractvalue { i64, i1 } %v861, 0
  %v863 = extractvalue { i64, i1 } %v861, 1
  br i1 %v863, label %yes.864, label %no.865
yes.864:
  %v867 = call ptr @mlf_add_int(ptr %a6, ptr %a7)
  br label %join.866
no.865:
  %v868 = inttoptr i64 %v862 to ptr
  br label %join.866
join.866:
  %v869 = phi ptr [ %v867, %yes.864 ], [ %v868, %no.865 ]
  br label %join.859
no.858:
  %v870 = call ptr @mlf_add_int(ptr %a6, ptr %a7)
  br label %join.859
join.859:
  %v871 = phi ptr [ %v869, %join.866 ], [ %v870, %no.858 ]
  %v872 = ptrtoint ptr %a5 to i64
  %v873 = ptrtoint ptr %v871 to i64
  %v874 = and i64 %v872, %v873
  %v875 = and i64 %v874, 1
  %v876 = icmp ne i64 %v875, 0
  br i1 %v876, label %yes.877, label %no.878
yes.877:
  %v880 = sub i64 %v873, 1
  %v881 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v872, i64 %v880)
  %v882 = extractvalue { i64, i1 } %v881, 0
  %v883 = extractvalue { i64, i1 } %v881, 1
  br i1 %v883, label %yes.884, label %no.885
yes.884:
  %v887 = call ptr @mlf_add_int(ptr %a5, ptr %v871)
  br label %join.886
no.885:
  %v888 = inttoptr i64 %v882 to ptr
  br label %join.886
join.886:
  %v889 = phi ptr [ %v887, %yes.884 ], [ %v888, %no.885 ]
  br label %join.879
no.878:
  %v890 = call ptr @mlf_add_int(ptr %a5, ptr %v871)
  br label %join.879
join.879:
  %v891 = phi ptr [ %v889, %join.886 ], [ %v890, %no.878 ]
  %v892 = ptrtoint ptr %a4 to i64
  %v893 = ptrtoint ptr %v891 to i64
  %v894 = and i64 %v892, %v893
  %v895 = and i64 %v894, 1
  %v896 = icmp ne i64 %v895, 0
  br i1 %v896, label %yes.897, label %no.898
yes.897:
  %v900 = sub i64 %v893, 1
  %v901 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v892, i64 %v900)
  %v902 = extractvalue { i64, i1 } %v901, 0
  %v903 = extractvalue { i64, i1 } %v901, 1
  br i1 %v903, label %yes.904, label %no.905
yes.904:
  %v907 = call ptr @mlf_add_int(ptr %a4, ptr %v891)
  br label %join.906
no.905:
  %v908 = inttoptr i64 %v902 to ptr
  br label %join.906
join.906:
  %v909 = phi ptr [ %v907, %yes.904 ], [ %v908, %no.905 ]
  br label %join.899
no.898:
  %v910 = call ptr @mlf_add_int(ptr %a4, ptr %v891)
  br label %join.899
join.899:
  %v911 = phi ptr [ %v909, %join.906 ], [ %v910, %no.898 ]
  %v912 = icmp eq ptr inttoptr (i64 6 to ptr), inttoptr (i64 6 to ptr)
  br i1 %v912, label %tail.yes.913, label %tail.no.914
tail.yes.913:
  %v915 = ptrtoint ptr %a6 to i64
  %v916 = ptrtoint ptr inttoptr (i64 121 to ptr) to i64
  %v917 = icmp eq i64 %v915, %v916
  %v918 = select i1 %v917, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v919 = icmp eq ptr %v918, inttoptr (i64 6 to ptr)
  br i1 %v919, label %tail.yes.920, label %tail.no.921
tail.yes.920:
  %v922 = getelementptr i8, ptr %a1, i64 24
  %v923 = load i64, ptr %v922, align 8, !tbaa !3
  %v924 = getelementptr i8, ptr %a1, i64 32
  %v925 = load ptr, ptr %v924, align 8, !tbaa !3
  %v926 = ptrtoint ptr %a7 to i64
  %v927 = ashr i64 %v926, 1
  %v928 = and i64 %v926, 1
  %v929 = icmp ne i64 %v928, 0
  %v930 = icmp ult i64 %v927, %v923
  %v931 = and i1 %v929, %v930
  br i1 %v931, label %array.valid.932, label %array.invalid.933
array.invalid.933:
  call void @mlf_bounds_failure()
  unreachable
array.valid.932:
  %v934 = getelementptr i8, ptr %v925, i64 %v927
  %v935 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v936 = ashr i64 %v935, 1
  %v937 = trunc i64 %v936 to i8
  store i8 %v937, ptr %v934, align 1, !tbaa !4
  %v938 = ptrtoint ptr %a7 to i64
  %v939 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v940 = sub i64 %v939, 1
  %v941 = add nsw i64 %v938, %v940
  %v942 = inttoptr i64 %v941 to ptr
  %v943 = musttail call ptr @mlf.numeric.16.ppppppnp(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr inttoptr (i64 1 to ptr), ptr %v942)
  ret ptr %v943
tail.no.921:
  %v944 = ptrtoint ptr %a4 to i64
  %v945 = ptrtoint ptr %a3 to i64
  %v946 = and i64 %v944, %v945
  %v947 = and i64 %v946, 1
  %v948 = icmp ne i64 %v947, 0
  br i1 %v948, label %yes.949, label %no.950
yes.949:
  %v952 = icmp eq i64 %v944, %v945
  %v953 = select i1 %v952, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.951
no.950:
  %v954 = call ptr @mlf_eq_int(ptr %a4, ptr %a3)
  br label %join.951
join.951:
  %v955 = phi ptr [ %v953, %yes.949 ], [ %v954, %no.950 ]
  %v956 = icmp eq ptr %v955, inttoptr (i64 6 to ptr)
  br i1 %v956, label %tail.yes.957, label %tail.no.958
tail.yes.957:
  %v959 = ptrtoint ptr %a6 to i64
  %v960 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v961 = icmp eq i64 %v959, %v960
  %v962 = select i1 %v961, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v963 = icmp eq ptr %v962, inttoptr (i64 6 to ptr)
  br i1 %v963, label %tail.yes.964, label %tail.no.965
tail.yes.964:
  ret ptr %a5
tail.no.965:
  %v966 = getelementptr i8, ptr %a1, i64 24
  %v967 = load i64, ptr %v966, align 8, !tbaa !3
  %v968 = getelementptr i8, ptr %a1, i64 32
  %v969 = load ptr, ptr %v968, align 8, !tbaa !3
  %v970 = ptrtoint ptr %a7 to i64
  %v971 = ashr i64 %v970, 1
  %v972 = and i64 %v970, 1
  %v973 = icmp ne i64 %v972, 0
  %v974 = icmp ult i64 %v971, %v967
  %v975 = and i1 %v973, %v974
  br i1 %v975, label %array.valid.976, label %array.invalid.977
array.invalid.977:
  call void @mlf_bounds_failure()
  unreachable
array.valid.976:
  %v978 = getelementptr i8, ptr %v969, i64 %v971
  %v979 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v980 = ashr i64 %v979, 1
  %v981 = trunc i64 %v980 to i8
  store i8 %v981, ptr %v978, align 1, !tbaa !4
  ret ptr %a5
tail.no.958:
  %v982 = getelementptr i8, ptr %a0, i64 24
  %v983 = load i64, ptr %v982, align 8, !tbaa !3
  %v984 = getelementptr i8, ptr %a0, i64 32
  %v985 = load ptr, ptr %v984, align 8, !tbaa !3
  %v986 = ptrtoint ptr %a5 to i64
  %v987 = ashr i64 %v986, 1
  %v988 = and i64 %v986, 1
  %v989 = icmp ne i64 %v988, 0
  %v990 = icmp ult i64 %v987, %v983
  %v991 = and i1 %v989, %v990
  br i1 %v991, label %array.valid.992, label %array.invalid.993
array.invalid.993:
  call void @mlf_bounds_failure()
  unreachable
array.valid.992:
  %v994 = getelementptr i8, ptr %v985, i64 %v987
  %v995 = load i8, ptr %v994, align 1, !tbaa !4
  %v996 = zext i8 %v995 to i64
  %v997 = shl i64 %v996, 1
  %v998 = or i64 %v997, 1
  %v999 = inttoptr i64 %v998 to ptr
  %v1000 = getelementptr i8, ptr %a1, i64 24
  %v1001 = load i64, ptr %v1000, align 8, !tbaa !3
  %v1002 = getelementptr i8, ptr %a1, i64 32
  %v1003 = load ptr, ptr %v1002, align 8, !tbaa !3
  %v1004 = ptrtoint ptr %a7 to i64
  %v1005 = ashr i64 %v1004, 1
  %v1006 = and i64 %v1004, 1
  %v1007 = icmp ne i64 %v1006, 0
  %v1008 = icmp ult i64 %v1005, %v1001
  %v1009 = and i1 %v1007, %v1008
  br i1 %v1009, label %array.valid.1010, label %array.invalid.1011
array.invalid.1011:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1010:
  %v1012 = getelementptr i8, ptr %v1003, i64 %v1005
  %v1013 = ptrtoint ptr %v999 to i64
  %v1014 = ashr i64 %v1013, 1
  %v1015 = trunc i64 %v1014 to i8
  store i8 %v1015, ptr %v1012, align 1, !tbaa !4
  %v1016 = ptrtoint ptr %a5 to i64
  %v1017 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1018 = sub i64 %v1017, 1
  %v1019 = add nsw i64 %v1016, %v1018
  %v1020 = inttoptr i64 %v1019 to ptr
  %v1021 = ptrtoint ptr %v1020 to i64
  %v1022 = ptrtoint ptr %a2 to i64
  %v1023 = and i64 %v1021, %v1022
  %v1024 = and i64 %v1023, 1
  %v1025 = icmp ne i64 %v1024, 0
  br i1 %v1025, label %yes.1026, label %no.1027
yes.1026:
  %v1029 = icmp slt i64 %v1021, %v1022
  %v1030 = select i1 %v1029, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1028
no.1027:
  %v1031 = call ptr @mlf_lt_int(ptr %v1020, ptr %a2)
  br label %join.1028
join.1028:
  %v1032 = phi ptr [ %v1030, %yes.1026 ], [ %v1031, %no.1027 ]
  %v1033 = icmp eq ptr %v1032, inttoptr (i64 6 to ptr)
  br i1 %v1033, label %yes.1034, label %no.1035
yes.1034:
  %v1037 = ptrtoint ptr %a5 to i64
  %v1038 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1039 = sub i64 %v1038, 1
  %v1040 = add nsw i64 %v1037, %v1039
  %v1041 = inttoptr i64 %v1040 to ptr
  br label %join.1036
no.1035:
  br label %join.1036
join.1036:
  %v1042 = phi ptr [ %v1041, %yes.1034 ], [ inttoptr (i64 1 to ptr), %no.1035 ]
  %v1043 = ptrtoint ptr %a4 to i64
  %v1044 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1045 = and i64 %v1043, %v1044
  %v1046 = and i64 %v1045, 1
  %v1047 = icmp ne i64 %v1046, 0
  br i1 %v1047, label %yes.1048, label %no.1049
yes.1048:
  %v1051 = sub i64 %v1044, 1
  %v1052 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1043, i64 %v1051)
  %v1053 = extractvalue { i64, i1 } %v1052, 0
  %v1054 = extractvalue { i64, i1 } %v1052, 1
  br i1 %v1054, label %yes.1055, label %no.1056
yes.1055:
  %v1058 = call ptr @mlf_add_int(ptr %a4, ptr inttoptr (i64 3 to ptr))
  br label %join.1057
no.1056:
  %v1059 = inttoptr i64 %v1053 to ptr
  br label %join.1057
join.1057:
  %v1060 = phi ptr [ %v1058, %yes.1055 ], [ %v1059, %no.1056 ]
  br label %join.1050
no.1049:
  %v1061 = call ptr @mlf_add_int(ptr %a4, ptr inttoptr (i64 3 to ptr))
  br label %join.1050
join.1050:
  %v1062 = phi ptr [ %v1060, %join.1057 ], [ %v1061, %no.1049 ]
  %v1063 = ptrtoint ptr %a6 to i64
  %v1064 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1065 = and i64 %v1063, %v1064
  %v1066 = and i64 %v1065, 1
  %v1067 = icmp ne i64 %v1066, 0
  br i1 %v1067, label %yes.1068, label %no.1069
yes.1068:
  %v1071 = sub i64 %v1064, 1
  %v1072 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1063, i64 %v1071)
  %v1073 = extractvalue { i64, i1 } %v1072, 0
  %v1074 = extractvalue { i64, i1 } %v1072, 1
  br i1 %v1074, label %yes.1075, label %no.1076
yes.1075:
  %v1078 = call ptr @mlf_add_int(ptr %a6, ptr inttoptr (i64 3 to ptr))
  br label %join.1077
no.1076:
  %v1079 = inttoptr i64 %v1073 to ptr
  br label %join.1077
join.1077:
  %v1080 = phi ptr [ %v1078, %yes.1075 ], [ %v1079, %no.1076 ]
  br label %join.1070
no.1069:
  %v1081 = call ptr @mlf_add_int(ptr %a6, ptr inttoptr (i64 3 to ptr))
  br label %join.1070
join.1070:
  %v1082 = phi ptr [ %v1080, %join.1077 ], [ %v1081, %no.1069 ]
  %v1083 = ptrtoint ptr %a7 to i64
  %v1084 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1085 = sub i64 %v1084, 1
  %v1086 = add nsw i64 %v1083, %v1085
  %v1087 = inttoptr i64 %v1086 to ptr
  %v1380 = musttail call ptr @mlf.numeric.16(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %v1062, ptr %v1042, ptr %v1082, ptr %v1087)
  ret ptr %v1380
tail.no.914:
  ret ptr inttoptr (i64 1 to ptr)
}

define private ptr @mlf.numeric.31(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) alwaysinline {
entry:
  %v635 = ptrtoint ptr %a3 to i64
  %v636 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v637 = and i64 %v635, %v636
  %v638 = and i64 %v637, 1
  %v639 = icmp ne i64 %v638, 0
  br i1 %v639, label %yes.640, label %no.641
yes.640:
  %v643 = icmp eq i64 %v635, %v636
  %v644 = select i1 %v643, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.642
no.641:
  %v645 = call ptr @mlf_eq_int(ptr %a3, ptr inttoptr (i64 1 to ptr))
  br label %join.642
join.642:
  %v646 = phi ptr [ %v644, %yes.640 ], [ %v645, %no.641 ]
  %v647 = icmp eq ptr %v646, inttoptr (i64 6 to ptr)
  br i1 %v647, label %tail.yes.648, label %tail.no.649
tail.yes.648:
  ret ptr inttoptr (i64 4 to ptr)
tail.no.649:
  %v650 = ptrtoint ptr %a3 to i64
  %v651 = ptrtoint ptr inttoptr (i64 122881 to ptr) to i64
  %v652 = and i64 %v650, %v651
  %v653 = and i64 %v652, 1
  %v654 = icmp ne i64 %v653, 0
  br i1 %v654, label %yes.655, label %no.656
yes.655:
  %v658 = icmp slt i64 %v650, %v651
  %v659 = select i1 %v658, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.657
no.656:
  %v660 = call ptr @mlf_lt_int(ptr %a3, ptr inttoptr (i64 122881 to ptr))
  br label %join.657
join.657:
  %v661 = phi ptr [ %v659, %yes.655 ], [ %v660, %no.656 ]
  %v662 = icmp eq ptr %v661, inttoptr (i64 6 to ptr)
  br i1 %v662, label %yes.663, label %no.664
yes.663:
  br label %join.665
no.664:
  br label %join.665
join.665:
  %v666 = phi ptr [ %a3, %yes.663 ], [ inttoptr (i64 122881 to ptr), %no.664 ]
  %v1381 = call ptr @mlf.numeric.16.ppppppnp(ptr %a0, ptr %a1, ptr %a2, ptr %v666, ptr inttoptr (i64 1 to ptr), ptr %a4, ptr inttoptr (i64 1 to ptr), ptr inttoptr (i64 1 to ptr))
  %v1382 = ptrtoint ptr %v666 to i64
  %v1383 = ptrtoint ptr inttoptr (i64 119 to ptr) to i64
  %v1384 = and i64 %v1382, %v1383
  %v1385 = and i64 %v1384, 1
  %v1386 = icmp ne i64 %v1385, 0
  br i1 %v1386, label %yes.1387, label %no.1388
yes.1387:
  %v1390 = sub i64 %v1383, 1
  %v1391 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1382, i64 %v1390)
  %v1392 = extractvalue { i64, i1 } %v1391, 0
  %v1393 = extractvalue { i64, i1 } %v1391, 1
  br i1 %v1393, label %yes.1394, label %no.1395
yes.1394:
  %v1397 = call ptr @mlf_add_int(ptr %v666, ptr inttoptr (i64 119 to ptr))
  br label %join.1396
no.1395:
  %v1398 = inttoptr i64 %v1392 to ptr
  br label %join.1396
join.1396:
  %v1399 = phi ptr [ %v1397, %yes.1394 ], [ %v1398, %no.1395 ]
  br label %join.1389
no.1388:
  %v1400 = call ptr @mlf_add_int(ptr %v666, ptr inttoptr (i64 119 to ptr))
  br label %join.1389
join.1389:
  %v1401 = phi ptr [ %v1399, %join.1396 ], [ %v1400, %no.1388 ]
  %v1402 = ptrtoint ptr %v1401 to i64
  %v1403 = ptrtoint ptr inttoptr (i64 121 to ptr) to i64
  %v1404 = and i64 %v1402, %v1403
  %v1405 = and i64 %v1404, 1
  %v1406 = icmp ne i64 %v1405, 0
  br i1 %v1406, label %yes.1407, label %no.1408
yes.1407:
  %v1410 = ashr i64 %v1402, 1
  %v1411 = ashr i64 %v1403, 1
  %v1412 = icmp ne i64 %v1411, 0
  %v1413 = icmp eq i64 %v1410, -4611686018427387904
  %v1414 = icmp eq i64 %v1411, -1
  %v1415 = and i1 %v1413, %v1414
  %v1416 = xor i1 %v1415, true
  %v1417 = and i1 %v1412, %v1416
  br i1 %v1417, label %yes.1418, label %no.1419
yes.1418:
  %v1421 = sdiv i64 %v1410, %v1411
  %v1422 = shl i64 %v1421, 1
  %v1423 = or i64 %v1422, 1
  %v1424 = inttoptr i64 %v1423 to ptr
  br label %join.1420
no.1419:
  %v1425 = call ptr @mlf_prim2(i64 15, ptr %v1401, ptr inttoptr (i64 121 to ptr))
  br label %join.1420
join.1420:
  %v1426 = phi ptr [ %v1424, %yes.1418 ], [ %v1425, %no.1419 ]
  br label %join.1409
no.1408:
  %v1427 = call ptr @mlf_prim2(i64 15, ptr %v1401, ptr inttoptr (i64 121 to ptr))
  br label %join.1409
join.1409:
  %v1428 = phi ptr [ %v1426, %join.1420 ], [ %v1427, %no.1408 ]
  %v1429 = ptrtoint ptr %v666 to i64
  %v1430 = ptrtoint ptr %v1428 to i64
  %v1431 = and i64 %v1429, %v1430
  %v1432 = and i64 %v1431, 1
  %v1433 = icmp ne i64 %v1432, 0
  br i1 %v1433, label %yes.1434, label %no.1435
yes.1434:
  %v1437 = sub i64 %v1430, 1
  %v1438 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1429, i64 %v1437)
  %v1439 = extractvalue { i64, i1 } %v1438, 0
  %v1440 = extractvalue { i64, i1 } %v1438, 1
  br i1 %v1440, label %yes.1441, label %no.1442
yes.1441:
  %v1444 = call ptr @mlf_add_int(ptr %v666, ptr %v1428)
  br label %join.1443
no.1442:
  %v1445 = inttoptr i64 %v1439 to ptr
  br label %join.1443
join.1443:
  %v1446 = phi ptr [ %v1444, %yes.1441 ], [ %v1445, %no.1442 ]
  br label %join.1436
no.1435:
  %v1447 = call ptr @mlf_add_int(ptr %v666, ptr %v1428)
  br label %join.1436
join.1436:
  %v1448 = phi ptr [ %v1446, %join.1443 ], [ %v1447, %no.1435 ]
  %v1449 = call ptr @mlf_put_bytes(ptr %a1, ptr inttoptr (i64 1 to ptr), ptr %v1448)
  %v1450 = ptrtoint ptr %a3 to i64
  %v1451 = ptrtoint ptr %v666 to i64
  %v1452 = and i64 %v1450, %v1451
  %v1453 = and i64 %v1452, 1
  %v1454 = icmp ne i64 %v1453, 0
  br i1 %v1454, label %yes.1455, label %no.1456
yes.1455:
  %v1458 = sub i64 %v1451, 1
  %v1459 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v1450, i64 %v1458)
  %v1460 = extractvalue { i64, i1 } %v1459, 0
  %v1461 = extractvalue { i64, i1 } %v1459, 1
  br i1 %v1461, label %yes.1462, label %no.1463
yes.1462:
  %v1465 = call ptr @mlf_sub_int(ptr %a3, ptr %v666)
  br label %join.1464
no.1463:
  %v1466 = inttoptr i64 %v1460 to ptr
  br label %join.1464
join.1464:
  %v1467 = phi ptr [ %v1465, %yes.1462 ], [ %v1466, %no.1463 ]
  br label %join.1457
no.1456:
  %v1468 = call ptr @mlf_sub_int(ptr %a3, ptr %v666)
  br label %join.1457
join.1457:
  %v1469 = phi ptr [ %v1467, %join.1464 ], [ %v1468, %no.1456 ]
  %v1470 = musttail call ptr @mlf.numeric.31(ptr %a0, ptr %a1, ptr %a2, ptr %v1469, ptr %v1381)
  ret ptr %v1470
}

define private ptr @mlf.code.1479(ptr %env, ptr %arg) {
entry:
  %v1480 = getelementptr i8, ptr %env, i64 24
  %v1481 = load ptr, ptr %v1480, align 8, !tbaa !3
  %v1482 = call ptr @mlf_force(ptr %v1481)
  %v1483 = call ptr @mlf_prim2(i64 11, ptr %v1482, ptr inttoptr (i64 122881 to ptr))
  %v1484 = icmp eq ptr %v1483, inttoptr (i64 6 to ptr)
  br i1 %v1484, label %yes.1485, label %no.1486
yes.1485:
  br label %join.1487
no.1486:
  br label %join.1487
join.1487:
  %v1488 = phi ptr [ %v1482, %yes.1485 ], [ inttoptr (i64 122881 to ptr), %no.1486 ]
  ret ptr %v1488
}

define private ptr @mlf.code.1562(ptr %env, ptr %arg) {
entry:
  %v1563 = getelementptr i8, ptr %env, i64 24
  %v1564 = load ptr, ptr %v1563, align 8, !tbaa !3
  %v1565 = getelementptr i8, ptr %env, i64 32
  %v1566 = load ptr, ptr %v1565, align 8, !tbaa !3
  %v1567 = call ptr @mlf_prim3(i64 37, ptr %v1564, ptr %v1566, ptr inttoptr (i64 21 to ptr))
  ret ptr %v1567
}

define private ptr @mlf.code.1572(ptr %env, ptr %arg) {
entry:
  %v1573 = getelementptr i8, ptr %env, i64 24
  %v1574 = load ptr, ptr %v1573, align 8, !tbaa !3
  %v1575 = getelementptr i8, ptr %env, i64 32
  %v1576 = load ptr, ptr %v1575, align 8, !tbaa !3
  %v1577 = getelementptr i8, ptr %env, i64 40
  %v1578 = load ptr, ptr %v1577, align 8, !tbaa !3
  %v1579 = getelementptr i8, ptr %env, i64 48
  %v1580 = load ptr, ptr %v1579, align 8, !tbaa !3
  %v1581 = getelementptr i8, ptr %env, i64 56
  %v1582 = load ptr, ptr %v1581, align 8, !tbaa !3
  %v1583 = getelementptr i8, ptr %env, i64 64
  %v1584 = load ptr, ptr %v1583, align 8, !tbaa !3
  %v1585 = getelementptr i8, ptr %env, i64 72
  %v1586 = load ptr, ptr %v1585, align 8, !tbaa !3
  %v1587 = call ptr @mlf_force(ptr %v1582)
  %v1588 = call ptr @mlf_force(ptr %v1584)
  %v1589 = call ptr @mlf_force(ptr %v1586)
  %v1590 = call ptr @mlf_prim2(i64 8, ptr %v1589, ptr inttoptr (i64 3 to ptr))
  %v1591 = call ptr @mlf_env_new(i64 8)
  %v1592 = getelementptr i8, ptr %v1591, i64 24
  store ptr %v1574, ptr %v1592, align 8, !tbaa !3
  %v1593 = getelementptr i8, ptr %v1591, i64 32
  store ptr %v1576, ptr %v1593, align 8, !tbaa !3
  %v1594 = getelementptr i8, ptr %v1591, i64 40
  store ptr %v1578, ptr %v1594, align 8, !tbaa !3
  %v1595 = getelementptr i8, ptr %v1591, i64 48
  store ptr %v1580, ptr %v1595, align 8, !tbaa !3
  %v1596 = getelementptr i8, ptr %v1591, i64 56
  store ptr %v1587, ptr %v1596, align 8, !tbaa !3
  %v1597 = getelementptr i8, ptr %v1591, i64 64
  store ptr %v1588, ptr %v1597, align 8, !tbaa !3
  %v1598 = getelementptr i8, ptr %v1591, i64 72
  store ptr inttoptr (i64 1 to ptr), ptr %v1598, align 8, !tbaa !3
  %v1599 = getelementptr i8, ptr %v1591, i64 80
  store ptr %v1590, ptr %v1599, align 8, !tbaa !3
  %v1600 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1503, ptr %v1591)
  ret ptr %v1600
}

define private ptr @mlf.code.1623(ptr %env, ptr %arg) {
entry:
  %v1624 = getelementptr i8, ptr %env, i64 24
  %v1625 = load ptr, ptr %v1624, align 8, !tbaa !3
  %v1626 = getelementptr i8, ptr %env, i64 32
  %v1627 = load ptr, ptr %v1626, align 8, !tbaa !3
  %v1628 = call ptr @mlf_prim3(i64 37, ptr %v1625, ptr %v1627, ptr inttoptr (i64 21 to ptr))
  ret ptr %v1628
}

define private ptr @mlf.code.1633(ptr %env, ptr %arg) {
entry:
  %v1634 = getelementptr i8, ptr %env, i64 24
  %v1635 = load ptr, ptr %v1634, align 8, !tbaa !3
  %v1636 = call ptr @mlf_prim1(i64 0, ptr %v1635)
  ret ptr %v1636
}

define private ptr @mlf.code.1642(ptr %env, ptr %arg) {
entry:
  %v1643 = getelementptr i8, ptr %env, i64 24
  %v1644 = load ptr, ptr %v1643, align 8, !tbaa !3
  %v1645 = getelementptr i8, ptr %env, i64 32
  %v1646 = load ptr, ptr %v1645, align 8, !tbaa !3
  %v1647 = call ptr @mlf_prim2(i64 36, ptr %v1644, ptr %v1646)
  ret ptr %v1647
}

define private ptr @mlf.code.1669(ptr %env, ptr %arg) {
entry:
  %v1670 = getelementptr i8, ptr %env, i64 24
  %v1671 = load ptr, ptr %v1670, align 8, !tbaa !3
  %v1672 = getelementptr i8, ptr %env, i64 32
  %v1673 = load ptr, ptr %v1672, align 8, !tbaa !3
  %v1674 = getelementptr i8, ptr %env, i64 40
  %v1675 = load ptr, ptr %v1674, align 8, !tbaa !3
  %v1676 = call ptr @mlf_prim3(i64 37, ptr %v1671, ptr %v1673, ptr %v1675)
  ret ptr %v1676
}

define private ptr @mlf.code.1682(ptr %env, ptr %arg) {
entry:
  %v1683 = getelementptr i8, ptr %env, i64 24
  %v1684 = load ptr, ptr %v1683, align 8, !tbaa !3
  %v1685 = getelementptr i8, ptr %env, i64 32
  %v1686 = load ptr, ptr %v1685, align 8, !tbaa !3
  %v1687 = getelementptr i8, ptr %env, i64 40
  %v1688 = load ptr, ptr %v1687, align 8, !tbaa !3
  %v1689 = getelementptr i8, ptr %env, i64 48
  %v1690 = load ptr, ptr %v1689, align 8, !tbaa !3
  %v1691 = getelementptr i8, ptr %env, i64 56
  %v1692 = load ptr, ptr %v1691, align 8, !tbaa !3
  %v1693 = getelementptr i8, ptr %env, i64 64
  %v1694 = load ptr, ptr %v1693, align 8, !tbaa !3
  %v1695 = getelementptr i8, ptr %env, i64 72
  %v1696 = load ptr, ptr %v1695, align 8, !tbaa !3
  %v1697 = getelementptr i8, ptr %env, i64 80
  %v1698 = load ptr, ptr %v1697, align 8, !tbaa !3
  %v1699 = call ptr @mlf_force(ptr %v1694)
  %v1700 = call ptr @mlf_prim2(i64 8, ptr %v1699, ptr inttoptr (i64 3 to ptr))
  %v1701 = call ptr @mlf_force(ptr %v1688)
  %v1702 = call ptr @mlf_prim2(i64 11, ptr %v1700, ptr %v1701)
  %v1703 = icmp eq ptr %v1702, inttoptr (i64 6 to ptr)
  br i1 %v1703, label %yes.1704, label %no.1705
yes.1704:
  %v1707 = call ptr @mlf_prim2(i64 8, ptr %v1699, ptr inttoptr (i64 3 to ptr))
  br label %join.1706
no.1705:
  br label %join.1706
join.1706:
  %v1708 = phi ptr [ %v1707, %yes.1704 ], [ inttoptr (i64 1 to ptr), %no.1705 ]
  %v1709 = call ptr @mlf_force(ptr %v1692)
  %v1710 = call ptr @mlf_prim2(i64 8, ptr %v1709, ptr inttoptr (i64 3 to ptr))
  %v1711 = call ptr @mlf_force(ptr %v1696)
  %v1712 = call ptr @mlf_prim2(i64 8, ptr %v1711, ptr inttoptr (i64 3 to ptr))
  %v1713 = call ptr @mlf_force(ptr %v1698)
  %v1714 = call ptr @mlf_prim2(i64 8, ptr %v1713, ptr inttoptr (i64 3 to ptr))
  %v1715 = call ptr @mlf_env_new(i64 8)
  %v1716 = getelementptr i8, ptr %v1715, i64 24
  store ptr %v1684, ptr %v1716, align 8, !tbaa !3
  %v1717 = getelementptr i8, ptr %v1715, i64 32
  store ptr %v1686, ptr %v1717, align 8, !tbaa !3
  %v1718 = getelementptr i8, ptr %v1715, i64 40
  store ptr %v1701, ptr %v1718, align 8, !tbaa !3
  %v1719 = getelementptr i8, ptr %v1715, i64 48
  store ptr %v1690, ptr %v1719, align 8, !tbaa !3
  %v1720 = getelementptr i8, ptr %v1715, i64 56
  store ptr %v1710, ptr %v1720, align 8, !tbaa !3
  %v1721 = getelementptr i8, ptr %v1715, i64 64
  store ptr %v1708, ptr %v1721, align 8, !tbaa !3
  %v1722 = getelementptr i8, ptr %v1715, i64 72
  store ptr %v1712, ptr %v1722, align 8, !tbaa !3
  %v1723 = getelementptr i8, ptr %v1715, i64 80
  store ptr %v1714, ptr %v1723, align 8, !tbaa !3
  %v1724 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1503, ptr %v1715)
  ret ptr %v1724
}

define private ptr @mlf.code.1652(ptr %env, ptr %arg) {
entry:
  %v1653 = getelementptr i8, ptr %env, i64 24
  %v1654 = load ptr, ptr %v1653, align 8, !tbaa !3
  %v1655 = getelementptr i8, ptr %env, i64 32
  %v1656 = load ptr, ptr %v1655, align 8, !tbaa !3
  %v1657 = getelementptr i8, ptr %env, i64 40
  %v1658 = load ptr, ptr %v1657, align 8, !tbaa !3
  %v1659 = getelementptr i8, ptr %env, i64 48
  %v1660 = load ptr, ptr %v1659, align 8, !tbaa !3
  %v1661 = getelementptr i8, ptr %env, i64 56
  %v1662 = load ptr, ptr %v1661, align 8, !tbaa !3
  %v1663 = getelementptr i8, ptr %env, i64 64
  %v1664 = load ptr, ptr %v1663, align 8, !tbaa !3
  %v1665 = getelementptr i8, ptr %env, i64 72
  %v1666 = load ptr, ptr %v1665, align 8, !tbaa !3
  %v1667 = getelementptr i8, ptr %env, i64 80
  %v1668 = load ptr, ptr %v1667, align 8, !tbaa !3
  %v1677 = call ptr @mlf_env_new(i64 3)
  %v1678 = getelementptr i8, ptr %v1677, i64 24
  store ptr %v1656, ptr %v1678, align 8, !tbaa !3
  %v1679 = getelementptr i8, ptr %v1677, i64 32
  store ptr %v1668, ptr %v1679, align 8, !tbaa !3
  %v1680 = getelementptr i8, ptr %v1677, i64 40
  store ptr %arg, ptr %v1680, align 8, !tbaa !3
  %v1681 = call ptr @mlf_thunk(ptr @mlf.code.1669, ptr %v1677)
  %v1725 = call ptr @mlf_env_new(i64 8)
  %v1726 = getelementptr i8, ptr %v1725, i64 24
  store ptr %v1654, ptr %v1726, align 8, !tbaa !3
  %v1727 = getelementptr i8, ptr %v1725, i64 32
  store ptr %v1656, ptr %v1727, align 8, !tbaa !3
  %v1728 = getelementptr i8, ptr %v1725, i64 40
  store ptr %v1658, ptr %v1728, align 8, !tbaa !3
  %v1729 = getelementptr i8, ptr %v1725, i64 48
  store ptr %v1660, ptr %v1729, align 8, !tbaa !3
  %v1730 = getelementptr i8, ptr %v1725, i64 56
  store ptr %v1662, ptr %v1730, align 8, !tbaa !3
  %v1731 = getelementptr i8, ptr %v1725, i64 64
  store ptr %v1664, ptr %v1731, align 8, !tbaa !3
  %v1732 = getelementptr i8, ptr %v1725, i64 72
  store ptr %v1666, ptr %v1732, align 8, !tbaa !3
  %v1733 = getelementptr i8, ptr %v1725, i64 80
  store ptr %v1668, ptr %v1733, align 8, !tbaa !3
  %v1734 = call ptr @mlf_closure(ptr @mlf.code.1682, ptr %v1725)
  %v1735 = call ptr @mlf_prim2(i64 1, ptr %v1681, ptr %v1734)
  ret ptr %v1735
}

define private ptr @mlf.worker.16(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6, ptr %a7) {
entry:
  %v1549 = call ptr @mlf_prim2(i64 8, ptr %a6, ptr %a7)
  %v1550 = call ptr @mlf_prim2(i64 8, ptr %a5, ptr %v1549)
  %v1551 = call ptr @mlf_prim2(i64 8, ptr %a4, ptr %v1550)
  %v1552 = call ptr @mlf_prim2(i64 10, ptr %v1551, ptr %v1551)
  %v1553 = icmp eq ptr %v1552, inttoptr (i64 6 to ptr)
  br i1 %v1553, label %yes.1554, label %no.1555
yes.1554:
  %v1557 = call ptr @mlf_prim2(i64 10, ptr %a6, ptr inttoptr (i64 121 to ptr))
  %v1558 = icmp eq ptr %v1557, inttoptr (i64 6 to ptr)
  br i1 %v1558, label %yes.1559, label %no.1560
yes.1559:
  %v1568 = call ptr @mlf_env_new(i64 2)
  %v1569 = getelementptr i8, ptr %v1568, i64 24
  store ptr %a1, ptr %v1569, align 8, !tbaa !3
  %v1570 = getelementptr i8, ptr %v1568, i64 32
  store ptr %a7, ptr %v1570, align 8, !tbaa !3
  %v1571 = call ptr @mlf_thunk(ptr @mlf.code.1562, ptr %v1568)
  %v1601 = call ptr @mlf_env_new(i64 7)
  %v1602 = getelementptr i8, ptr %v1601, i64 24
  store ptr %a0, ptr %v1602, align 8, !tbaa !3
  %v1603 = getelementptr i8, ptr %v1601, i64 32
  store ptr %a1, ptr %v1603, align 8, !tbaa !3
  %v1604 = getelementptr i8, ptr %v1601, i64 40
  store ptr %a2, ptr %v1604, align 8, !tbaa !3
  %v1605 = getelementptr i8, ptr %v1601, i64 48
  store ptr %a3, ptr %v1605, align 8, !tbaa !3
  %v1606 = getelementptr i8, ptr %v1601, i64 56
  store ptr %a4, ptr %v1606, align 8, !tbaa !3
  %v1607 = getelementptr i8, ptr %v1601, i64 64
  store ptr %a5, ptr %v1607, align 8, !tbaa !3
  %v1608 = getelementptr i8, ptr %v1601, i64 72
  store ptr %a7, ptr %v1608, align 8, !tbaa !3
  %v1609 = call ptr @mlf_closure(ptr @mlf.code.1572, ptr %v1601)
  %v1610 = call ptr @mlf_prim2(i64 1, ptr %v1571, ptr %v1609)
  br label %join.1561
no.1560:
  %v1611 = call ptr @mlf_force(ptr %a3)
  %v1612 = call ptr @mlf_prim2(i64 10, ptr %a4, ptr %v1611)
  %v1613 = icmp eq ptr %v1612, inttoptr (i64 6 to ptr)
  br i1 %v1613, label %yes.1614, label %no.1615
yes.1614:
  %v1617 = call ptr @mlf_prim2(i64 10, ptr %a6, ptr inttoptr (i64 1 to ptr))
  %v1618 = icmp eq ptr %v1617, inttoptr (i64 6 to ptr)
  br i1 %v1618, label %yes.1619, label %no.1620
yes.1619:
  %v1622 = call ptr @mlf_prim1(i64 0, ptr %a5)
  br label %join.1621
no.1620:
  %v1629 = call ptr @mlf_env_new(i64 2)
  %v1630 = getelementptr i8, ptr %v1629, i64 24
  store ptr %a1, ptr %v1630, align 8, !tbaa !3
  %v1631 = getelementptr i8, ptr %v1629, i64 32
  store ptr %a7, ptr %v1631, align 8, !tbaa !3
  %v1632 = call ptr @mlf_thunk(ptr @mlf.code.1623, ptr %v1629)
  %v1637 = call ptr @mlf_env_new(i64 1)
  %v1638 = getelementptr i8, ptr %v1637, i64 24
  store ptr %a5, ptr %v1638, align 8, !tbaa !3
  %v1639 = call ptr @mlf_closure(ptr @mlf.code.1633, ptr %v1637)
  %v1640 = call ptr @mlf_prim2(i64 1, ptr %v1632, ptr %v1639)
  br label %join.1621
join.1621:
  %v1641 = phi ptr [ %v1622, %yes.1619 ], [ %v1640, %no.1620 ]
  br label %join.1616
no.1615:
  %v1648 = call ptr @mlf_env_new(i64 2)
  %v1649 = getelementptr i8, ptr %v1648, i64 24
  store ptr %a0, ptr %v1649, align 8, !tbaa !3
  %v1650 = getelementptr i8, ptr %v1648, i64 32
  store ptr %a5, ptr %v1650, align 8, !tbaa !3
  %v1651 = call ptr @mlf_thunk(ptr @mlf.code.1642, ptr %v1648)
  %v1736 = call ptr @mlf_env_new(i64 8)
  %v1737 = getelementptr i8, ptr %v1736, i64 24
  store ptr %a0, ptr %v1737, align 8, !tbaa !3
  %v1738 = getelementptr i8, ptr %v1736, i64 32
  store ptr %a1, ptr %v1738, align 8, !tbaa !3
  %v1739 = getelementptr i8, ptr %v1736, i64 40
  store ptr %a2, ptr %v1739, align 8, !tbaa !3
  %v1740 = getelementptr i8, ptr %v1736, i64 48
  store ptr %v1611, ptr %v1740, align 8, !tbaa !3
  %v1741 = getelementptr i8, ptr %v1736, i64 56
  store ptr %a4, ptr %v1741, align 8, !tbaa !3
  %v1742 = getelementptr i8, ptr %v1736, i64 64
  store ptr %a5, ptr %v1742, align 8, !tbaa !3
  %v1743 = getelementptr i8, ptr %v1736, i64 72
  store ptr %a6, ptr %v1743, align 8, !tbaa !3
  %v1744 = getelementptr i8, ptr %v1736, i64 80
  store ptr %a7, ptr %v1744, align 8, !tbaa !3
  %v1745 = call ptr @mlf_closure(ptr @mlf.code.1652, ptr %v1736)
  %v1746 = call ptr @mlf_prim2(i64 1, ptr %v1651, ptr %v1745)
  br label %join.1616
join.1616:
  %v1747 = phi ptr [ %v1641, %join.1621 ], [ %v1746, %no.1615 ]
  br label %join.1561
join.1561:
  %v1748 = phi ptr [ %v1610, %yes.1559 ], [ %v1747, %join.1616 ]
  br label %join.1556
no.1555:
  %v1749 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 1 to ptr))
  br label %join.1556
join.1556:
  %v1750 = phi ptr [ %v1748, %join.1561 ], [ %v1749, %no.1555 ]
  ret ptr %v1750
}

define private ptr @mlf.numeric.entry.1503(ptr %env, ptr %arg) {
entry:
  %v1504 = getelementptr i8, ptr %env, i64 24
  %v1505 = load ptr, ptr %v1504, align 8, !tbaa !3
  %v1506 = getelementptr i8, ptr %env, i64 32
  %v1507 = load ptr, ptr %v1506, align 8, !tbaa !3
  %v1508 = getelementptr i8, ptr %env, i64 40
  %v1509 = load ptr, ptr %v1508, align 8, !tbaa !3
  %v1510 = getelementptr i8, ptr %env, i64 48
  %v1511 = load ptr, ptr %v1510, align 8, !tbaa !3
  %v1512 = getelementptr i8, ptr %env, i64 56
  %v1513 = load ptr, ptr %v1512, align 8, !tbaa !3
  %v1514 = getelementptr i8, ptr %env, i64 64
  %v1515 = load ptr, ptr %v1514, align 8, !tbaa !3
  %v1516 = getelementptr i8, ptr %env, i64 72
  %v1517 = load ptr, ptr %v1516, align 8, !tbaa !3
  %v1518 = getelementptr i8, ptr %env, i64 80
  %v1519 = load ptr, ptr %v1518, align 8, !tbaa !3
  %v1520 = call ptr @mlf_peek(ptr %v1505)
  %v1521 = call ptr @mlf_peek(ptr %v1507)
  %v1522 = call ptr @mlf_peek(ptr %v1509)
  %v1523 = call ptr @mlf_peek(ptr %v1511)
  %v1524 = call ptr @mlf_peek(ptr %v1513)
  %v1525 = call ptr @mlf_peek(ptr %v1515)
  %v1526 = call ptr @mlf_peek(ptr %v1517)
  %v1527 = call ptr @mlf_peek(ptr %v1519)
  %v1528 = icmp ne ptr %v1520, null
  %v1529 = icmp ne ptr %v1521, null
  %v1530 = icmp ne ptr %v1522, null
  %v1531 = icmp ne ptr %v1523, null
  %v1532 = icmp ne ptr %v1524, null
  %v1533 = icmp ne ptr %v1525, null
  %v1534 = icmp ne ptr %v1526, null
  %v1535 = icmp ne ptr %v1527, null
  %v1536 = and i1 true, %v1528
  %v1537 = and i1 %v1536, %v1529
  %v1538 = and i1 %v1537, %v1530
  %v1539 = and i1 %v1538, %v1531
  %v1540 = and i1 %v1539, %v1532
  %v1541 = and i1 %v1540, %v1533
  %v1542 = and i1 %v1541, %v1534
  %v1543 = and i1 %v1542, %v1535
  br i1 %v1543, label %yes.1544, label %no.1545
yes.1544:
  %v1547 = call ptr @mlf.numeric.16(ptr %v1520, ptr %v1521, ptr %v1522, ptr %v1523, ptr %v1524, ptr %v1525, ptr %v1526, ptr %v1527)
  %v1548 = call ptr @mlf_prim1(i64 0, ptr %v1547)
  br label %join.1546
no.1545:
  %v1751 = call ptr @mlf_force(ptr %v1513)
  %v1752 = call ptr @mlf_force(ptr %v1515)
  %v1753 = call ptr @mlf_force(ptr %v1517)
  %v1754 = call ptr @mlf_force(ptr %v1519)
  %v1755 = call ptr @mlf.worker.16(ptr %v1505, ptr %v1507, ptr %v1509, ptr %v1511, ptr %v1751, ptr %v1752, ptr %v1753, ptr %v1754)
  br label %join.1546
join.1546:
  %v1756 = phi ptr [ %v1548, %yes.1544 ], [ %v1755, %no.1545 ]
  ret ptr %v1756
}

define private ptr @mlf.code.1492(ptr %env, ptr %arg) {
entry:
  %v1493 = getelementptr i8, ptr %env, i64 24
  %v1494 = load ptr, ptr %v1493, align 8, !tbaa !3
  %v1495 = getelementptr i8, ptr %env, i64 32
  %v1496 = load ptr, ptr %v1495, align 8, !tbaa !3
  %v1497 = getelementptr i8, ptr %env, i64 40
  %v1498 = load ptr, ptr %v1497, align 8, !tbaa !3
  %v1499 = getelementptr i8, ptr %env, i64 48
  %v1500 = load ptr, ptr %v1499, align 8, !tbaa !3
  %v1501 = getelementptr i8, ptr %env, i64 56
  %v1502 = load ptr, ptr %v1501, align 8, !tbaa !3
  %v1757 = call ptr @mlf_force(ptr %v1500)
  %v1758 = call ptr @mlf_env_new(i64 8)
  %v1759 = getelementptr i8, ptr %v1758, i64 24
  store ptr %v1494, ptr %v1759, align 8, !tbaa !3
  %v1760 = getelementptr i8, ptr %v1758, i64 32
  store ptr %v1496, ptr %v1760, align 8, !tbaa !3
  %v1761 = getelementptr i8, ptr %v1758, i64 40
  store ptr %v1498, ptr %v1761, align 8, !tbaa !3
  %v1762 = getelementptr i8, ptr %v1758, i64 48
  store ptr %v1502, ptr %v1762, align 8, !tbaa !3
  %v1763 = getelementptr i8, ptr %v1758, i64 56
  store ptr inttoptr (i64 1 to ptr), ptr %v1763, align 8, !tbaa !3
  %v1764 = getelementptr i8, ptr %v1758, i64 64
  store ptr %v1757, ptr %v1764, align 8, !tbaa !3
  %v1765 = getelementptr i8, ptr %v1758, i64 72
  store ptr inttoptr (i64 1 to ptr), ptr %v1765, align 8, !tbaa !3
  %v1766 = getelementptr i8, ptr %v1758, i64 80
  store ptr inttoptr (i64 1 to ptr), ptr %v1766, align 8, !tbaa !3
  %v1767 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1503, ptr %v1758)
  ret ptr %v1767
}

define private ptr @mlf.code.1791(ptr %env, ptr %arg) {
entry:
  %v1792 = getelementptr i8, ptr %env, i64 24
  %v1793 = load ptr, ptr %v1792, align 8, !tbaa !3
  %v1794 = call ptr @mlf_force(ptr %v1793)
  %v1795 = call ptr @mlf_prim2(i64 8, ptr %v1794, ptr inttoptr (i64 119 to ptr))
  %v1796 = call ptr @mlf_prim2(i64 15, ptr %v1795, ptr inttoptr (i64 121 to ptr))
  %v1797 = call ptr @mlf_prim2(i64 8, ptr %v1794, ptr %v1796)
  ret ptr %v1797
}

define private ptr @mlf.code.1786(ptr %env, ptr %arg) {
entry:
  %v1787 = getelementptr i8, ptr %env, i64 24
  %v1788 = load ptr, ptr %v1787, align 8, !tbaa !3
  %v1789 = getelementptr i8, ptr %env, i64 32
  %v1790 = load ptr, ptr %v1789, align 8, !tbaa !3
  %v1798 = call ptr @mlf_env_new(i64 1)
  %v1799 = getelementptr i8, ptr %v1798, i64 24
  store ptr %v1790, ptr %v1799, align 8, !tbaa !3
  %v1800 = call ptr @mlf_thunk(ptr @mlf.code.1791, ptr %v1798)
  %v1801 = call ptr @mlf_prim3(i64 40, ptr %v1788, ptr inttoptr (i64 1 to ptr), ptr %v1800)
  ret ptr %v1801
}

define private ptr @mlf.code.1806(ptr %env, ptr %arg) {
entry:
  %v1807 = getelementptr i8, ptr %env, i64 24
  %v1808 = load ptr, ptr %v1807, align 8, !tbaa !3
  %v1809 = getelementptr i8, ptr %env, i64 32
  %v1810 = load ptr, ptr %v1809, align 8, !tbaa !3
  %v1811 = getelementptr i8, ptr %env, i64 40
  %v1812 = load ptr, ptr %v1811, align 8, !tbaa !3
  %v1813 = getelementptr i8, ptr %env, i64 48
  %v1814 = load ptr, ptr %v1813, align 8, !tbaa !3
  %v1815 = getelementptr i8, ptr %env, i64 56
  %v1816 = load ptr, ptr %v1815, align 8, !tbaa !3
  %v1817 = getelementptr i8, ptr %env, i64 64
  %v1818 = load ptr, ptr %v1817, align 8, !tbaa !3
  %v1819 = call ptr @mlf_force(ptr %v1814)
  %v1820 = call ptr @mlf_force(ptr %v1816)
  %v1821 = call ptr @mlf_prim2(i64 9, ptr %v1819, ptr %v1820)
  %v1822 = call ptr @mlf_env_new(i64 5)
  %v1823 = getelementptr i8, ptr %v1822, i64 24
  store ptr %v1808, ptr %v1823, align 8, !tbaa !3
  %v1824 = getelementptr i8, ptr %v1822, i64 32
  store ptr %v1810, ptr %v1824, align 8, !tbaa !3
  %v1825 = getelementptr i8, ptr %v1822, i64 40
  store ptr %v1812, ptr %v1825, align 8, !tbaa !3
  %v1826 = getelementptr i8, ptr %v1822, i64 48
  store ptr %v1821, ptr %v1826, align 8, !tbaa !3
  %v1827 = getelementptr i8, ptr %v1822, i64 56
  store ptr %v1818, ptr %v1827, align 8, !tbaa !3
  %v1828 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.606, ptr %v1822)
  ret ptr %v1828
}

define private ptr @mlf.code.1775(ptr %env, ptr %arg) {
entry:
  %v1776 = getelementptr i8, ptr %env, i64 24
  %v1777 = load ptr, ptr %v1776, align 8, !tbaa !3
  %v1778 = getelementptr i8, ptr %env, i64 32
  %v1779 = load ptr, ptr %v1778, align 8, !tbaa !3
  %v1780 = getelementptr i8, ptr %env, i64 40
  %v1781 = load ptr, ptr %v1780, align 8, !tbaa !3
  %v1782 = getelementptr i8, ptr %env, i64 48
  %v1783 = load ptr, ptr %v1782, align 8, !tbaa !3
  %v1784 = getelementptr i8, ptr %env, i64 56
  %v1785 = load ptr, ptr %v1784, align 8, !tbaa !3
  %v1802 = call ptr @mlf_env_new(i64 2)
  %v1803 = getelementptr i8, ptr %v1802, i64 24
  store ptr %v1779, ptr %v1803, align 8, !tbaa !3
  %v1804 = getelementptr i8, ptr %v1802, i64 32
  store ptr %v1785, ptr %v1804, align 8, !tbaa !3
  %v1805 = call ptr @mlf_thunk(ptr @mlf.code.1786, ptr %v1802)
  %v1829 = call ptr @mlf_env_new(i64 6)
  %v1830 = getelementptr i8, ptr %v1829, i64 24
  store ptr %v1777, ptr %v1830, align 8, !tbaa !3
  %v1831 = getelementptr i8, ptr %v1829, i64 32
  store ptr %v1779, ptr %v1831, align 8, !tbaa !3
  %v1832 = getelementptr i8, ptr %v1829, i64 40
  store ptr %v1781, ptr %v1832, align 8, !tbaa !3
  %v1833 = getelementptr i8, ptr %v1829, i64 48
  store ptr %v1783, ptr %v1833, align 8, !tbaa !3
  %v1834 = getelementptr i8, ptr %v1829, i64 56
  store ptr %v1785, ptr %v1834, align 8, !tbaa !3
  %v1835 = getelementptr i8, ptr %v1829, i64 64
  store ptr %arg, ptr %v1835, align 8, !tbaa !3
  %v1836 = call ptr @mlf_closure(ptr @mlf.code.1806, ptr %v1829)
  %v1837 = call ptr @mlf_prim2(i64 1, ptr %v1805, ptr %v1836)
  ret ptr %v1837
}

define private ptr @mlf.worker.31(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) {
entry:
  %v1473 = call ptr @mlf_prim2(i64 10, ptr %a3, ptr inttoptr (i64 1 to ptr))
  %v1474 = icmp eq ptr %v1473, inttoptr (i64 6 to ptr)
  br i1 %v1474, label %yes.1475, label %no.1476
yes.1475:
  %v1478 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.1477
no.1476:
  %v1489 = call ptr @mlf_env_new(i64 1)
  %v1490 = getelementptr i8, ptr %v1489, i64 24
  store ptr %a3, ptr %v1490, align 8, !tbaa !3
  %v1491 = call ptr @mlf_thunk(ptr @mlf.code.1479, ptr %v1489)
  %v1768 = call ptr @mlf_env_new(i64 5)
  %v1769 = getelementptr i8, ptr %v1768, i64 24
  store ptr %a0, ptr %v1769, align 8, !tbaa !3
  %v1770 = getelementptr i8, ptr %v1768, i64 32
  store ptr %a1, ptr %v1770, align 8, !tbaa !3
  %v1771 = getelementptr i8, ptr %v1768, i64 40
  store ptr %a2, ptr %v1771, align 8, !tbaa !3
  %v1772 = getelementptr i8, ptr %v1768, i64 48
  store ptr %a4, ptr %v1772, align 8, !tbaa !3
  %v1773 = getelementptr i8, ptr %v1768, i64 56
  store ptr %v1491, ptr %v1773, align 8, !tbaa !3
  %v1774 = call ptr @mlf_thunk(ptr @mlf.code.1492, ptr %v1768)
  %v1838 = call ptr @mlf_env_new(i64 5)
  %v1839 = getelementptr i8, ptr %v1838, i64 24
  store ptr %a0, ptr %v1839, align 8, !tbaa !3
  %v1840 = getelementptr i8, ptr %v1838, i64 32
  store ptr %a1, ptr %v1840, align 8, !tbaa !3
  %v1841 = getelementptr i8, ptr %v1838, i64 40
  store ptr %a2, ptr %v1841, align 8, !tbaa !3
  %v1842 = getelementptr i8, ptr %v1838, i64 48
  store ptr %a3, ptr %v1842, align 8, !tbaa !3
  %v1843 = getelementptr i8, ptr %v1838, i64 56
  store ptr %v1491, ptr %v1843, align 8, !tbaa !3
  %v1844 = call ptr @mlf_closure(ptr @mlf.code.1775, ptr %v1838)
  %v1845 = call ptr @mlf_prim2(i64 1, ptr %v1774, ptr %v1844)
  br label %join.1477
join.1477:
  %v1846 = phi ptr [ %v1478, %yes.1475 ], [ %v1845, %no.1476 ]
  ret ptr %v1846
}

define private ptr @mlf.numeric.entry.606(ptr %env, ptr %arg) {
entry:
  %v607 = getelementptr i8, ptr %env, i64 24
  %v608 = load ptr, ptr %v607, align 8, !tbaa !3
  %v609 = getelementptr i8, ptr %env, i64 32
  %v610 = load ptr, ptr %v609, align 8, !tbaa !3
  %v611 = getelementptr i8, ptr %env, i64 40
  %v612 = load ptr, ptr %v611, align 8, !tbaa !3
  %v613 = getelementptr i8, ptr %env, i64 48
  %v614 = load ptr, ptr %v613, align 8, !tbaa !3
  %v615 = getelementptr i8, ptr %env, i64 56
  %v616 = load ptr, ptr %v615, align 8, !tbaa !3
  %v617 = call ptr @mlf_peek(ptr %v608)
  %v618 = call ptr @mlf_peek(ptr %v610)
  %v619 = call ptr @mlf_peek(ptr %v612)
  %v620 = call ptr @mlf_peek(ptr %v614)
  %v621 = call ptr @mlf_peek(ptr %v616)
  %v622 = icmp ne ptr %v617, null
  %v623 = icmp ne ptr %v618, null
  %v624 = icmp ne ptr %v619, null
  %v625 = icmp ne ptr %v620, null
  %v626 = icmp ne ptr %v621, null
  %v627 = and i1 true, %v622
  %v628 = and i1 %v627, %v623
  %v629 = and i1 %v628, %v624
  %v630 = and i1 %v629, %v625
  %v631 = and i1 %v630, %v626
  br i1 %v631, label %yes.632, label %no.633
yes.632:
  %v1471 = call ptr @mlf.numeric.31(ptr %v617, ptr %v618, ptr %v619, ptr %v620, ptr %v621)
  %v1472 = call ptr @mlf_prim1(i64 0, ptr %v1471)
  br label %join.634
no.633:
  %v1847 = call ptr @mlf_force(ptr %v614)
  %v1848 = call ptr @mlf.worker.31(ptr %v608, ptr %v610, ptr %v612, ptr %v1847, ptr %v616)
  br label %join.634
join.634:
  %v1849 = phi ptr [ %v1472, %yes.632 ], [ %v1848, %no.633 ]
  ret ptr %v1849
}

define private ptr @mlf.code.597(ptr %env, ptr %arg) {
entry:
  %v598 = getelementptr i8, ptr %env, i64 24
  %v599 = load ptr, ptr %v598, align 8, !tbaa !3
  %v600 = getelementptr i8, ptr %env, i64 32
  %v601 = load ptr, ptr %v600, align 8, !tbaa !3
  %v602 = getelementptr i8, ptr %env, i64 40
  %v603 = load ptr, ptr %v602, align 8, !tbaa !3
  %v604 = getelementptr i8, ptr %env, i64 48
  %v605 = load ptr, ptr %v604, align 8, !tbaa !3
  %v1850 = call ptr @mlf_force(ptr %v599)
  %v1851 = ptrtoint ptr %v1850 to i64
  %v1852 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v1853 = and i64 %v1851, %v1852
  %v1854 = and i64 %v1853, 1
  %v1855 = icmp ne i64 %v1854, 0
  br i1 %v1855, label %yes.1856, label %no.1857
yes.1856:
  %v1859 = ashr i64 %v1851, 1
  %v1860 = ashr i64 %v1852, 1
  %v1861 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v1859, i64 %v1860)
  %v1862 = extractvalue { i64, i1 } %v1861, 0
  %v1863 = extractvalue { i64, i1 } %v1861, 1
  %v1864 = xor i1 %v1863, true
  %v1865 = icmp sge i64 %v1862, -4611686018427387904
  %v1866 = icmp sle i64 %v1862, 4611686018427387903
  %v1867 = and i1 %v1865, %v1866
  %v1868 = and i1 %v1867, %v1864
  br i1 %v1868, label %yes.1869, label %no.1870
yes.1869:
  %v1872 = shl i64 %v1862, 1
  %v1873 = or i64 %v1872, 1
  %v1874 = inttoptr i64 %v1873 to ptr
  br label %join.1871
no.1870:
  %v1875 = call ptr @mlf_prim2(i64 14, ptr %v1850, ptr inttoptr (i64 5 to ptr))
  br label %join.1871
join.1871:
  %v1876 = phi ptr [ %v1874, %yes.1869 ], [ %v1875, %no.1870 ]
  br label %join.1858
no.1857:
  %v1877 = call ptr @mlf_prim2(i64 14, ptr %v1850, ptr inttoptr (i64 5 to ptr))
  br label %join.1858
join.1858:
  %v1878 = phi ptr [ %v1876, %join.1871 ], [ %v1877, %no.1857 ]
  %v1879 = call ptr @mlf_env_new(i64 5)
  %v1880 = getelementptr i8, ptr %v1879, i64 24
  store ptr %v601, ptr %v1880, align 8, !tbaa !3
  %v1881 = getelementptr i8, ptr %v1879, i64 32
  store ptr %v603, ptr %v1881, align 8, !tbaa !3
  %v1882 = getelementptr i8, ptr %v1879, i64 40
  store ptr %v605, ptr %v1882, align 8, !tbaa !3
  %v1883 = getelementptr i8, ptr %v1879, i64 48
  store ptr %v1878, ptr %v1883, align 8, !tbaa !3
  %v1884 = getelementptr i8, ptr %v1879, i64 56
  store ptr inttoptr (i64 1 to ptr), ptr %v1884, align 8, !tbaa !3
  %v1885 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.606, ptr %v1879)
  ret ptr %v1885
}

define private ptr @mlf.code.1909(ptr %env, ptr %arg) {
entry:
  %v1911 = call ptr @mlf_string(ptr @mlf.bytes.1910, i64 24)
  %v1912 = call ptr @mlf_prim1(i64 3, ptr %v1911)
  ret ptr %v1912
}

define private ptr @mlf.numeric.7(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) alwaysinline {
entry:
  %v2315 = ptrtoint ptr %a3 to i64
  %v2316 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2317 = and i64 %v2315, %v2316
  %v2318 = and i64 %v2317, 1
  %v2319 = icmp ne i64 %v2318, 0
  br i1 %v2319, label %yes.2320, label %no.2321
yes.2320:
  %v2323 = sub i64 %v2316, 1
  %v2324 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2315, i64 %v2323)
  %v2325 = extractvalue { i64, i1 } %v2324, 0
  %v2326 = extractvalue { i64, i1 } %v2324, 1
  br i1 %v2326, label %yes.2327, label %no.2328
yes.2327:
  %v2330 = call ptr @mlf_add_int(ptr %a3, ptr inttoptr (i64 3 to ptr))
  br label %join.2329
no.2328:
  %v2331 = inttoptr i64 %v2325 to ptr
  br label %join.2329
join.2329:
  %v2332 = phi ptr [ %v2330, %yes.2327 ], [ %v2331, %no.2328 ]
  br label %join.2322
no.2321:
  %v2333 = call ptr @mlf_add_int(ptr %a3, ptr inttoptr (i64 3 to ptr))
  br label %join.2322
join.2322:
  %v2334 = phi ptr [ %v2332, %join.2329 ], [ %v2333, %no.2321 ]
  %v2335 = ptrtoint ptr %v2334 to i64
  %v2336 = ptrtoint ptr %a4 to i64
  %v2337 = and i64 %v2335, %v2336
  %v2338 = and i64 %v2337, 1
  %v2339 = icmp ne i64 %v2338, 0
  br i1 %v2339, label %yes.2340, label %no.2341
yes.2340:
  %v2343 = icmp slt i64 %v2335, %v2336
  %v2344 = select i1 %v2343, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.2342
no.2341:
  %v2345 = call ptr @mlf_lt_int(ptr %v2334, ptr %a4)
  br label %join.2342
join.2342:
  %v2346 = phi ptr [ %v2344, %yes.2340 ], [ %v2345, %no.2341 ]
  %v2347 = icmp eq ptr %v2346, inttoptr (i64 6 to ptr)
  br i1 %v2347, label %tail.yes.2348, label %tail.no.2349
tail.yes.2348:
  %v2350 = ptrtoint ptr %a3 to i64
  %v2351 = ptrtoint ptr %a4 to i64
  %v2352 = and i64 %v2350, %v2351
  %v2353 = and i64 %v2352, 1
  %v2354 = icmp ne i64 %v2353, 0
  br i1 %v2354, label %yes.2355, label %no.2356
yes.2355:
  %v2358 = sub i64 %v2351, 1
  %v2359 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2350, i64 %v2358)
  %v2360 = extractvalue { i64, i1 } %v2359, 0
  %v2361 = extractvalue { i64, i1 } %v2359, 1
  br i1 %v2361, label %yes.2362, label %no.2363
yes.2362:
  %v2365 = call ptr @mlf_add_int(ptr %a3, ptr %a4)
  br label %join.2364
no.2363:
  %v2366 = inttoptr i64 %v2360 to ptr
  br label %join.2364
join.2364:
  %v2367 = phi ptr [ %v2365, %yes.2362 ], [ %v2366, %no.2363 ]
  br label %join.2357
no.2356:
  %v2368 = call ptr @mlf_add_int(ptr %a3, ptr %a4)
  br label %join.2357
join.2357:
  %v2369 = phi ptr [ %v2367, %join.2364 ], [ %v2368, %no.2356 ]
  %v2370 = ptrtoint ptr %v2369 to i64
  %v2371 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v2372 = and i64 %v2370, %v2371
  %v2373 = and i64 %v2372, 1
  %v2374 = icmp ne i64 %v2373, 0
  br i1 %v2374, label %yes.2375, label %no.2376
yes.2375:
  %v2378 = ashr i64 %v2370, 1
  %v2379 = ashr i64 %v2371, 1
  %v2380 = icmp ne i64 %v2379, 0
  %v2381 = icmp eq i64 %v2378, -4611686018427387904
  %v2382 = icmp eq i64 %v2379, -1
  %v2383 = and i1 %v2381, %v2382
  %v2384 = xor i1 %v2383, true
  %v2385 = and i1 %v2380, %v2384
  br i1 %v2385, label %yes.2386, label %no.2387
yes.2386:
  %v2389 = sdiv i64 %v2378, %v2379
  %v2390 = shl i64 %v2389, 1
  %v2391 = or i64 %v2390, 1
  %v2392 = inttoptr i64 %v2391 to ptr
  br label %join.2388
no.2387:
  %v2393 = call ptr @mlf_prim2(i64 15, ptr %v2369, ptr inttoptr (i64 5 to ptr))
  br label %join.2388
join.2388:
  %v2394 = phi ptr [ %v2392, %yes.2386 ], [ %v2393, %no.2387 ]
  br label %join.2377
no.2376:
  %v2395 = call ptr @mlf_prim2(i64 15, ptr %v2369, ptr inttoptr (i64 5 to ptr))
  br label %join.2377
join.2377:
  %v2396 = phi ptr [ %v2394, %join.2388 ], [ %v2395, %no.2376 ]
  %v2397 = getelementptr i8, ptr %a1, i64 24
  %v2398 = load i64, ptr %v2397, align 8, !tbaa !3
  %v2399 = getelementptr i8, ptr %a1, i64 32
  %v2400 = load ptr, ptr %v2399, align 8, !tbaa !3
  %v2401 = ptrtoint ptr %v2396 to i64
  %v2402 = ashr i64 %v2401, 1
  %v2403 = and i64 %v2401, 1
  %v2404 = icmp ne i64 %v2403, 0
  %v2405 = icmp ult i64 %v2402, %v2398
  %v2406 = and i1 %v2404, %v2405
  br i1 %v2406, label %array.valid.2407, label %array.invalid.2408
array.invalid.2408:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2407:
  %v2409 = getelementptr i64, ptr %v2400, i64 %v2402
  %v2410 = load double, ptr %v2409, align 8, !tbaa !4
  %v2411 = getelementptr i8, ptr %a2, i64 24
  %v2412 = load i64, ptr %v2411, align 8, !tbaa !3
  %v2413 = getelementptr i8, ptr %a2, i64 32
  %v2414 = load ptr, ptr %v2413, align 8, !tbaa !3
  %v2415 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v2416 = ashr i64 %v2415, 1
  %v2417 = and i64 %v2415, 1
  %v2418 = icmp ne i64 %v2417, 0
  %v2419 = icmp ult i64 %v2416, %v2412
  %v2420 = and i1 %v2418, %v2419
  br i1 %v2420, label %array.valid.2421, label %array.invalid.2422
array.invalid.2422:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2421:
  %v2423 = getelementptr i64, ptr %v2414, i64 %v2416
  %v2424 = load double, ptr %v2423, align 8, !tbaa !4
  %v2425 = fcmp olt double %v2424, %v2410
  %v2426 = select i1 %v2425, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v2427 = icmp eq ptr %v2426, inttoptr (i64 6 to ptr)
  br i1 %v2427, label %tail.yes.2428, label %tail.no.2429
tail.yes.2428:
  %v2430 = musttail call ptr @mlf.numeric.7(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %v2396)
  ret ptr %v2430
tail.no.2429:
  %v2431 = musttail call ptr @mlf.numeric.7(ptr %a0, ptr %a1, ptr %a2, ptr %v2396, ptr %a4)
  ret ptr %v2431
tail.no.2349:
  %v2432 = getelementptr i8, ptr %a0, i64 24
  %v2433 = load i64, ptr %v2432, align 8, !tbaa !3
  %v2434 = getelementptr i8, ptr %a0, i64 32
  %v2435 = load ptr, ptr %v2434, align 8, !tbaa !3
  %v2436 = ptrtoint ptr %a4 to i64
  %v2437 = ashr i64 %v2436, 1
  %v2438 = and i64 %v2436, 1
  %v2439 = icmp ne i64 %v2438, 0
  %v2440 = icmp ult i64 %v2437, %v2433
  %v2441 = and i1 %v2439, %v2440
  br i1 %v2441, label %array.valid.2442, label %array.invalid.2443
array.invalid.2443:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2442:
  %v2444 = getelementptr i8, ptr %v2435, i64 %v2437
  %v2445 = load i8, ptr %v2444, align 1, !tbaa !4
  %v2446 = zext i8 %v2445 to i64
  %v2447 = shl i64 %v2446, 1
  %v2448 = or i64 %v2447, 1
  %v2449 = inttoptr i64 %v2448 to ptr
  ret ptr %v2449
}

define private ptr @mlf.numeric.40(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6, ptr %a7, ptr %a8, ptr %a9) alwaysinline {
entry:
  %v2522 = ptrtoint ptr %a8 to i64
  %v2523 = ptrtoint ptr %a9 to i64
  %v2524 = and i64 %v2522, %v2523
  %v2525 = and i64 %v2524, 1
  %v2526 = icmp ne i64 %v2525, 0
  br i1 %v2526, label %yes.2527, label %no.2528
yes.2527:
  %v2530 = sub i64 %v2523, 1
  %v2531 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2522, i64 %v2530)
  %v2532 = extractvalue { i64, i1 } %v2531, 0
  %v2533 = extractvalue { i64, i1 } %v2531, 1
  br i1 %v2533, label %yes.2534, label %no.2535
yes.2534:
  %v2537 = call ptr @mlf_add_int(ptr %a8, ptr %a9)
  br label %join.2536
no.2535:
  %v2538 = inttoptr i64 %v2532 to ptr
  br label %join.2536
join.2536:
  %v2539 = phi ptr [ %v2537, %yes.2534 ], [ %v2538, %no.2535 ]
  br label %join.2529
no.2528:
  %v2540 = call ptr @mlf_add_int(ptr %a8, ptr %a9)
  br label %join.2529
join.2529:
  %v2541 = phi ptr [ %v2539, %join.2536 ], [ %v2540, %no.2528 ]
  %v2542 = ptrtoint ptr %a7 to i64
  %v2543 = ptrtoint ptr %v2541 to i64
  %v2544 = and i64 %v2542, %v2543
  %v2545 = and i64 %v2544, 1
  %v2546 = icmp ne i64 %v2545, 0
  br i1 %v2546, label %yes.2547, label %no.2548
yes.2547:
  %v2550 = sub i64 %v2543, 1
  %v2551 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2542, i64 %v2550)
  %v2552 = extractvalue { i64, i1 } %v2551, 0
  %v2553 = extractvalue { i64, i1 } %v2551, 1
  br i1 %v2553, label %yes.2554, label %no.2555
yes.2554:
  %v2557 = call ptr @mlf_add_int(ptr %a7, ptr %v2541)
  br label %join.2556
no.2555:
  %v2558 = inttoptr i64 %v2552 to ptr
  br label %join.2556
join.2556:
  %v2559 = phi ptr [ %v2557, %yes.2554 ], [ %v2558, %no.2555 ]
  br label %join.2549
no.2548:
  %v2560 = call ptr @mlf_add_int(ptr %a7, ptr %v2541)
  br label %join.2549
join.2549:
  %v2561 = phi ptr [ %v2559, %join.2556 ], [ %v2560, %no.2548 ]
  %v2562 = icmp eq ptr inttoptr (i64 6 to ptr), inttoptr (i64 6 to ptr)
  br i1 %v2562, label %tail.yes.2563, label %tail.no.2564
tail.yes.2563:
  %v2565 = ptrtoint ptr %a8 to i64
  %v2566 = ptrtoint ptr inttoptr (i64 121 to ptr) to i64
  %v2567 = and i64 %v2565, %v2566
  %v2568 = and i64 %v2567, 1
  %v2569 = icmp ne i64 %v2568, 0
  br i1 %v2569, label %yes.2570, label %no.2571
yes.2570:
  %v2573 = icmp eq i64 %v2565, %v2566
  %v2574 = select i1 %v2573, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.2572
no.2571:
  %v2575 = call ptr @mlf_eq_int(ptr %a8, ptr inttoptr (i64 121 to ptr))
  br label %join.2572
join.2572:
  %v2576 = phi ptr [ %v2574, %yes.2570 ], [ %v2575, %no.2571 ]
  %v2577 = icmp eq ptr %v2576, inttoptr (i64 6 to ptr)
  br i1 %v2577, label %tail.yes.2578, label %tail.no.2579
tail.yes.2578:
  %v2580 = getelementptr i8, ptr %a4, i64 24
  %v2581 = load i64, ptr %v2580, align 8, !tbaa !3
  %v2582 = getelementptr i8, ptr %a4, i64 32
  %v2583 = load ptr, ptr %v2582, align 8, !tbaa !3
  %v2584 = ptrtoint ptr %a9 to i64
  %v2585 = ashr i64 %v2584, 1
  %v2586 = and i64 %v2584, 1
  %v2587 = icmp ne i64 %v2586, 0
  %v2588 = icmp ult i64 %v2585, %v2581
  %v2589 = and i1 %v2587, %v2588
  br i1 %v2589, label %array.valid.2590, label %array.invalid.2591
array.invalid.2591:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2590:
  %v2592 = getelementptr i8, ptr %v2583, i64 %v2585
  %v2593 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v2594 = ashr i64 %v2593, 1
  %v2595 = trunc i64 %v2594 to i8
  store i8 %v2595, ptr %v2592, align 1, !tbaa !4
  %v2596 = ptrtoint ptr %a9 to i64
  %v2597 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2598 = sub i64 %v2597, 1
  %v2599 = add nsw i64 %v2596, %v2598
  %v2600 = inttoptr i64 %v2599 to ptr
  %v2601 = musttail call ptr @mlf.numeric.40.ppppppppnp(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6, ptr %a7, ptr inttoptr (i64 1 to ptr), ptr %v2600)
  ret ptr %v2601
tail.no.2579:
  %v2602 = ptrtoint ptr %a7 to i64
  %v2603 = ptrtoint ptr %a6 to i64
  %v2604 = and i64 %v2602, %v2603
  %v2605 = and i64 %v2604, 1
  %v2606 = icmp ne i64 %v2605, 0
  br i1 %v2606, label %yes.2607, label %no.2608
yes.2607:
  %v2610 = icmp eq i64 %v2602, %v2603
  %v2611 = select i1 %v2610, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.2609
no.2608:
  %v2612 = call ptr @mlf_eq_int(ptr %a7, ptr %a6)
  br label %join.2609
join.2609:
  %v2613 = phi ptr [ %v2611, %yes.2607 ], [ %v2612, %no.2608 ]
  %v2614 = icmp eq ptr %v2613, inttoptr (i64 6 to ptr)
  br i1 %v2614, label %tail.yes.2615, label %tail.no.2616
tail.yes.2615:
  %v2617 = ptrtoint ptr %a8 to i64
  %v2618 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v2619 = and i64 %v2617, %v2618
  %v2620 = and i64 %v2619, 1
  %v2621 = icmp ne i64 %v2620, 0
  br i1 %v2621, label %yes.2622, label %no.2623
yes.2622:
  %v2625 = icmp eq i64 %v2617, %v2618
  %v2626 = select i1 %v2625, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.2624
no.2623:
  %v2627 = call ptr @mlf_eq_int(ptr %a8, ptr inttoptr (i64 1 to ptr))
  br label %join.2624
join.2624:
  %v2628 = phi ptr [ %v2626, %yes.2622 ], [ %v2627, %no.2623 ]
  %v2629 = icmp eq ptr %v2628, inttoptr (i64 6 to ptr)
  br i1 %v2629, label %tail.yes.2630, label %tail.no.2631
tail.yes.2630:
  ret ptr inttoptr (i64 4 to ptr)
tail.no.2631:
  %v2632 = getelementptr i8, ptr %a4, i64 24
  %v2633 = load i64, ptr %v2632, align 8, !tbaa !3
  %v2634 = getelementptr i8, ptr %a4, i64 32
  %v2635 = load ptr, ptr %v2634, align 8, !tbaa !3
  %v2636 = ptrtoint ptr %a9 to i64
  %v2637 = ashr i64 %v2636, 1
  %v2638 = and i64 %v2636, 1
  %v2639 = icmp ne i64 %v2638, 0
  %v2640 = icmp ult i64 %v2637, %v2633
  %v2641 = and i1 %v2639, %v2640
  br i1 %v2641, label %array.valid.2642, label %array.invalid.2643
array.invalid.2643:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2642:
  %v2644 = getelementptr i8, ptr %v2635, i64 %v2637
  %v2645 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v2646 = ashr i64 %v2645, 1
  %v2647 = trunc i64 %v2646 to i8
  store i8 %v2647, ptr %v2644, align 1, !tbaa !4
  ret ptr inttoptr (i64 4 to ptr)
tail.no.2616:
  %v2648 = getelementptr i8, ptr %a2, i64 24
  %v2649 = load i64, ptr %v2648, align 8, !tbaa !3
  %v2650 = getelementptr i8, ptr %a2, i64 32
  %v2651 = load ptr, ptr %v2650, align 8, !tbaa !3
  %v2652 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v2653 = ashr i64 %v2652, 1
  %v2654 = and i64 %v2652, 1
  %v2655 = icmp ne i64 %v2654, 0
  %v2656 = icmp ult i64 %v2653, %v2649
  %v2657 = and i1 %v2655, %v2656
  br i1 %v2657, label %array.valid.2658, label %array.invalid.2659
array.invalid.2659:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2658:
  %v2660 = getelementptr i64, ptr %v2651, i64 %v2653
  %v2661 = load ptr, ptr %v2660, align 8, !tbaa !4
  %v2662 = ptrtoint ptr %v2661 to i64
  %v2663 = ptrtoint ptr inttoptr (i64 7755 to ptr) to i64
  %v2664 = and i64 %v2662, %v2663
  %v2665 = and i64 %v2664, 1
  %v2666 = icmp ne i64 %v2665, 0
  br i1 %v2666, label %yes.2667, label %no.2668
yes.2667:
  %v2670 = ashr i64 %v2662, 1
  %v2671 = ashr i64 %v2663, 1
  %v2672 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v2670, i64 %v2671)
  %v2673 = extractvalue { i64, i1 } %v2672, 0
  %v2674 = extractvalue { i64, i1 } %v2672, 1
  %v2675 = xor i1 %v2674, true
  %v2676 = icmp sge i64 %v2673, -4611686018427387904
  %v2677 = icmp sle i64 %v2673, 4611686018427387903
  %v2678 = and i1 %v2676, %v2677
  %v2679 = and i1 %v2678, %v2675
  br i1 %v2679, label %yes.2680, label %no.2681
yes.2680:
  %v2683 = shl i64 %v2673, 1
  %v2684 = or i64 %v2683, 1
  %v2685 = inttoptr i64 %v2684 to ptr
  br label %join.2682
no.2681:
  %v2686 = call ptr @mlf_prim2(i64 14, ptr %v2661, ptr inttoptr (i64 7755 to ptr))
  br label %join.2682
join.2682:
  %v2687 = phi ptr [ %v2685, %yes.2680 ], [ %v2686, %no.2681 ]
  br label %join.2669
no.2668:
  %v2688 = call ptr @mlf_prim2(i64 14, ptr %v2661, ptr inttoptr (i64 7755 to ptr))
  br label %join.2669
join.2669:
  %v2689 = phi ptr [ %v2687, %join.2682 ], [ %v2688, %no.2668 ]
  %v2690 = ptrtoint ptr %v2689 to i64
  %v2691 = ptrtoint ptr inttoptr (i64 59147 to ptr) to i64
  %v2692 = and i64 %v2690, %v2691
  %v2693 = and i64 %v2692, 1
  %v2694 = icmp ne i64 %v2693, 0
  br i1 %v2694, label %yes.2695, label %no.2696
yes.2695:
  %v2698 = sub i64 %v2691, 1
  %v2699 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2690, i64 %v2698)
  %v2700 = extractvalue { i64, i1 } %v2699, 0
  %v2701 = extractvalue { i64, i1 } %v2699, 1
  br i1 %v2701, label %yes.2702, label %no.2703
yes.2702:
  %v2705 = call ptr @mlf_add_int(ptr %v2689, ptr inttoptr (i64 59147 to ptr))
  br label %join.2704
no.2703:
  %v2706 = inttoptr i64 %v2700 to ptr
  br label %join.2704
join.2704:
  %v2707 = phi ptr [ %v2705, %yes.2702 ], [ %v2706, %no.2703 ]
  br label %join.2697
no.2696:
  %v2708 = call ptr @mlf_add_int(ptr %v2689, ptr inttoptr (i64 59147 to ptr))
  br label %join.2697
join.2697:
  %v2709 = phi ptr [ %v2707, %join.2704 ], [ %v2708, %no.2696 ]
  %v2710 = ptrtoint ptr %v2709 to i64
  %v2711 = ptrtoint ptr inttoptr (i64 279937 to ptr) to i64
  %v2712 = and i64 %v2710, %v2711
  %v2713 = and i64 %v2712, 1
  %v2714 = icmp ne i64 %v2713, 0
  br i1 %v2714, label %yes.2715, label %no.2716
yes.2715:
  %v2718 = ashr i64 %v2710, 1
  %v2719 = ashr i64 %v2711, 1
  %v2720 = icmp ne i64 %v2719, 0
  %v2721 = icmp eq i64 %v2718, -4611686018427387904
  %v2722 = icmp eq i64 %v2719, -1
  %v2723 = and i1 %v2721, %v2722
  %v2724 = xor i1 %v2723, true
  %v2725 = and i1 %v2720, %v2724
  br i1 %v2725, label %yes.2726, label %no.2727
yes.2726:
  %v2729 = srem i64 %v2718, %v2719
  %v2730 = shl i64 %v2729, 1
  %v2731 = or i64 %v2730, 1
  %v2732 = inttoptr i64 %v2731 to ptr
  br label %join.2728
no.2727:
  %v2733 = call ptr @mlf_prim2(i64 16, ptr %v2709, ptr inttoptr (i64 279937 to ptr))
  br label %join.2728
join.2728:
  %v2734 = phi ptr [ %v2732, %yes.2726 ], [ %v2733, %no.2727 ]
  br label %join.2717
no.2716:
  %v2735 = call ptr @mlf_prim2(i64 16, ptr %v2709, ptr inttoptr (i64 279937 to ptr))
  br label %join.2717
join.2717:
  %v2736 = phi ptr [ %v2734, %join.2728 ], [ %v2735, %no.2716 ]
  %v2737 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v2738 = ashr i64 %v2737, 1
  %v2739 = and i64 %v2737, 1
  %v2740 = icmp ne i64 %v2739, 0
  %v2741 = icmp ult i64 %v2738, %v2649
  %v2742 = and i1 %v2740, %v2741
  br i1 %v2742, label %array.valid.2743, label %array.invalid.2744
array.invalid.2744:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2743:
  %v2745 = getelementptr i64, ptr %v2651, i64 %v2738
  store ptr %v2736, ptr %v2745, align 8, !tbaa !4
  %v2746 = ptrtoint ptr %v2736 to i64
  %v2747 = and i64 %v2746, 1
  %v2748 = icmp ne i64 %v2747, 0
  br i1 %v2748, label %yes.2749, label %no.2750
yes.2749:
  %v2752 = ashr i64 %v2746, 1
  %v2753 = sitofp i64 %v2752 to double
  br label %join.2751
no.2750:
  %v2754 = call double @mlf_int_to_double(ptr %v2736)
  br label %join.2751
join.2751:
  %v2755 = phi double [ %v2753, %yes.2749 ], [ %v2754, %no.2750 ]
  %v2756 = fdiv double %v2755, 0x4101160000000000
  %v2757 = getelementptr i8, ptr %a3, i64 24
  %v2758 = load i64, ptr %v2757, align 8, !tbaa !3
  %v2759 = getelementptr i8, ptr %a3, i64 32
  %v2760 = load ptr, ptr %v2759, align 8, !tbaa !3
  %v2761 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v2762 = ashr i64 %v2761, 1
  %v2763 = and i64 %v2761, 1
  %v2764 = icmp ne i64 %v2763, 0
  %v2765 = icmp ult i64 %v2762, %v2758
  %v2766 = and i1 %v2764, %v2765
  br i1 %v2766, label %array.valid.2767, label %array.invalid.2768
array.invalid.2768:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2767:
  %v2769 = getelementptr i64, ptr %v2760, i64 %v2762
  store double %v2756, ptr %v2769, align 8, !tbaa !4
  %v2770 = getelementptr i8, ptr %a1, i64 24
  %v2771 = load i64, ptr %v2770, align 8, !tbaa !3
  %v2772 = getelementptr i8, ptr %a1, i64 32
  %v2773 = load ptr, ptr %v2772, align 8, !tbaa !3
  %v2774 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v2775 = ashr i64 %v2774, 1
  %v2776 = and i64 %v2774, 1
  %v2777 = icmp ne i64 %v2776, 0
  %v2778 = icmp ult i64 %v2775, %v2771
  %v2779 = and i1 %v2777, %v2778
  br i1 %v2779, label %array.valid.2780, label %array.invalid.2781
array.invalid.2781:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2780:
  %v2782 = getelementptr i64, ptr %v2773, i64 %v2775
  %v2783 = load double, ptr %v2782, align 8, !tbaa !4
  %v2784 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v2785 = ashr i64 %v2784, 1
  %v2786 = and i64 %v2784, 1
  %v2787 = icmp ne i64 %v2786, 0
  %v2788 = icmp ult i64 %v2785, %v2758
  %v2789 = and i1 %v2787, %v2788
  br i1 %v2789, label %array.valid.2790, label %array.invalid.2791
array.invalid.2791:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2790:
  %v2792 = getelementptr i64, ptr %v2760, i64 %v2785
  %v2793 = load double, ptr %v2792, align 8, !tbaa !4
  %v2794 = fcmp olt double %v2793, %v2783
  %v2795 = select i1 %v2794, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v2796 = icmp eq ptr %v2795, inttoptr (i64 6 to ptr)
  br i1 %v2796, label %yes.2797, label %no.2798
yes.2797:
  %v2800 = getelementptr i8, ptr %a0, i64 24
  %v2801 = load i64, ptr %v2800, align 8, !tbaa !3
  %v2802 = getelementptr i8, ptr %a0, i64 32
  %v2803 = load ptr, ptr %v2802, align 8, !tbaa !3
  %v2804 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v2805 = ashr i64 %v2804, 1
  %v2806 = and i64 %v2804, 1
  %v2807 = icmp ne i64 %v2806, 0
  %v2808 = icmp ult i64 %v2805, %v2801
  %v2809 = and i1 %v2807, %v2808
  br i1 %v2809, label %array.valid.2810, label %array.invalid.2811
array.invalid.2811:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2810:
  %v2812 = getelementptr i8, ptr %v2803, i64 %v2805
  %v2813 = load i8, ptr %v2812, align 1, !tbaa !4
  %v2814 = zext i8 %v2813 to i64
  %v2815 = shl i64 %v2814, 1
  %v2816 = or i64 %v2815, 1
  %v2817 = inttoptr i64 %v2816 to ptr
  br label %join.2799
no.2798:
  %v2818 = ptrtoint ptr %a5 to i64
  %v2819 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2820 = and i64 %v2818, %v2819
  %v2821 = and i64 %v2820, 1
  %v2822 = icmp ne i64 %v2821, 0
  br i1 %v2822, label %yes.2823, label %no.2824
yes.2823:
  %v2826 = sub i64 %v2819, 1
  %v2827 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v2818, i64 %v2826)
  %v2828 = extractvalue { i64, i1 } %v2827, 0
  %v2829 = extractvalue { i64, i1 } %v2827, 1
  br i1 %v2829, label %yes.2830, label %no.2831
yes.2830:
  %v2833 = call ptr @mlf_sub_int(ptr %a5, ptr inttoptr (i64 3 to ptr))
  br label %join.2832
no.2831:
  %v2834 = inttoptr i64 %v2828 to ptr
  br label %join.2832
join.2832:
  %v2835 = phi ptr [ %v2833, %yes.2830 ], [ %v2834, %no.2831 ]
  br label %join.2825
no.2824:
  %v2836 = call ptr @mlf_sub_int(ptr %a5, ptr inttoptr (i64 3 to ptr))
  br label %join.2825
join.2825:
  %v2837 = phi ptr [ %v2835, %join.2832 ], [ %v2836, %no.2824 ]
  %v2838 = call ptr @mlf.numeric.7(ptr %a0, ptr %a1, ptr %a3, ptr inttoptr (i64 1 to ptr), ptr %v2837)
  br label %join.2799
join.2799:
  %v2839 = phi ptr [ %v2817, %array.valid.2810 ], [ %v2838, %join.2825 ]
  %v2840 = getelementptr i8, ptr %a4, i64 24
  %v2841 = load i64, ptr %v2840, align 8, !tbaa !3
  %v2842 = getelementptr i8, ptr %a4, i64 32
  %v2843 = load ptr, ptr %v2842, align 8, !tbaa !3
  %v2844 = ptrtoint ptr %a9 to i64
  %v2845 = ashr i64 %v2844, 1
  %v2846 = and i64 %v2844, 1
  %v2847 = icmp ne i64 %v2846, 0
  %v2848 = icmp ult i64 %v2845, %v2841
  %v2849 = and i1 %v2847, %v2848
  br i1 %v2849, label %array.valid.2850, label %array.invalid.2851
array.invalid.2851:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2850:
  %v2852 = getelementptr i8, ptr %v2843, i64 %v2845
  %v2853 = ptrtoint ptr %v2839 to i64
  %v2854 = ashr i64 %v2853, 1
  %v2855 = and i64 %v2853, 1
  %v2856 = icmp ne i64 %v2855, 0
  %v2857 = icmp ult i64 %v2854, 256
  %v2858 = and i1 %v2856, %v2857
  br i1 %v2858, label %yes.2859, label %no.2860
yes.2859:
  %v2862 = trunc i64 %v2854 to i8
  br label %join.2861
no.2860:
  %v2863 = call i8 @mlf_byte(ptr %v2839)
  br label %join.2861
join.2861:
  %v2864 = phi i8 [ %v2862, %yes.2859 ], [ %v2863, %no.2860 ]
  store i8 %v2864, ptr %v2852, align 1, !tbaa !4
  %v2865 = ptrtoint ptr %a7 to i64
  %v2866 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2867 = and i64 %v2865, %v2866
  %v2868 = and i64 %v2867, 1
  %v2869 = icmp ne i64 %v2868, 0
  br i1 %v2869, label %yes.2870, label %no.2871
yes.2870:
  %v2873 = sub i64 %v2866, 1
  %v2874 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2865, i64 %v2873)
  %v2875 = extractvalue { i64, i1 } %v2874, 0
  %v2876 = extractvalue { i64, i1 } %v2874, 1
  br i1 %v2876, label %yes.2877, label %no.2878
yes.2877:
  %v2880 = call ptr @mlf_add_int(ptr %a7, ptr inttoptr (i64 3 to ptr))
  br label %join.2879
no.2878:
  %v2881 = inttoptr i64 %v2875 to ptr
  br label %join.2879
join.2879:
  %v2882 = phi ptr [ %v2880, %yes.2877 ], [ %v2881, %no.2878 ]
  br label %join.2872
no.2871:
  %v2883 = call ptr @mlf_add_int(ptr %a7, ptr inttoptr (i64 3 to ptr))
  br label %join.2872
join.2872:
  %v2884 = phi ptr [ %v2882, %join.2879 ], [ %v2883, %no.2871 ]
  %v2885 = ptrtoint ptr %a8 to i64
  %v2886 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2887 = and i64 %v2885, %v2886
  %v2888 = and i64 %v2887, 1
  %v2889 = icmp ne i64 %v2888, 0
  br i1 %v2889, label %yes.2890, label %no.2891
yes.2890:
  %v2893 = sub i64 %v2886, 1
  %v2894 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2885, i64 %v2893)
  %v2895 = extractvalue { i64, i1 } %v2894, 0
  %v2896 = extractvalue { i64, i1 } %v2894, 1
  br i1 %v2896, label %yes.2897, label %no.2898
yes.2897:
  %v2900 = call ptr @mlf_add_int(ptr %a8, ptr inttoptr (i64 3 to ptr))
  br label %join.2899
no.2898:
  %v2901 = inttoptr i64 %v2895 to ptr
  br label %join.2899
join.2899:
  %v2902 = phi ptr [ %v2900, %yes.2897 ], [ %v2901, %no.2898 ]
  br label %join.2892
no.2891:
  %v2903 = call ptr @mlf_add_int(ptr %a8, ptr inttoptr (i64 3 to ptr))
  br label %join.2892
join.2892:
  %v2904 = phi ptr [ %v2902, %join.2899 ], [ %v2903, %no.2891 ]
  %v2905 = ptrtoint ptr %a9 to i64
  %v2906 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2907 = sub i64 %v2906, 1
  %v2908 = add nsw i64 %v2905, %v2907
  %v2909 = inttoptr i64 %v2908 to ptr
  %v2910 = musttail call ptr @mlf.numeric.40(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6, ptr %v2884, ptr %v2904, ptr %v2909)
  ret ptr %v2910
tail.no.2564:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.numeric.40.ppppppppnp(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6, ptr %a7, ptr %a8, ptr %a9) alwaysinline {
entry:
  %v2015 = ptrtoint ptr %a8 to i64
  %v2016 = ptrtoint ptr %a9 to i64
  %v2017 = and i64 %v2015, %v2016
  %v2018 = and i64 %v2017, 1
  %v2019 = icmp ne i64 %v2018, 0
  br i1 %v2019, label %yes.2020, label %no.2021
yes.2020:
  %v2023 = sub i64 %v2016, 1
  %v2024 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2015, i64 %v2023)
  %v2025 = extractvalue { i64, i1 } %v2024, 0
  %v2026 = extractvalue { i64, i1 } %v2024, 1
  br i1 %v2026, label %yes.2027, label %no.2028
yes.2027:
  %v2030 = call ptr @mlf_add_int(ptr %a8, ptr %a9)
  br label %join.2029
no.2028:
  %v2031 = inttoptr i64 %v2025 to ptr
  br label %join.2029
join.2029:
  %v2032 = phi ptr [ %v2030, %yes.2027 ], [ %v2031, %no.2028 ]
  br label %join.2022
no.2021:
  %v2033 = call ptr @mlf_add_int(ptr %a8, ptr %a9)
  br label %join.2022
join.2022:
  %v2034 = phi ptr [ %v2032, %join.2029 ], [ %v2033, %no.2021 ]
  %v2035 = ptrtoint ptr %a7 to i64
  %v2036 = ptrtoint ptr %v2034 to i64
  %v2037 = and i64 %v2035, %v2036
  %v2038 = and i64 %v2037, 1
  %v2039 = icmp ne i64 %v2038, 0
  br i1 %v2039, label %yes.2040, label %no.2041
yes.2040:
  %v2043 = sub i64 %v2036, 1
  %v2044 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2035, i64 %v2043)
  %v2045 = extractvalue { i64, i1 } %v2044, 0
  %v2046 = extractvalue { i64, i1 } %v2044, 1
  br i1 %v2046, label %yes.2047, label %no.2048
yes.2047:
  %v2050 = call ptr @mlf_add_int(ptr %a7, ptr %v2034)
  br label %join.2049
no.2048:
  %v2051 = inttoptr i64 %v2045 to ptr
  br label %join.2049
join.2049:
  %v2052 = phi ptr [ %v2050, %yes.2047 ], [ %v2051, %no.2048 ]
  br label %join.2042
no.2041:
  %v2053 = call ptr @mlf_add_int(ptr %a7, ptr %v2034)
  br label %join.2042
join.2042:
  %v2054 = phi ptr [ %v2052, %join.2049 ], [ %v2053, %no.2041 ]
  %v2055 = icmp eq ptr inttoptr (i64 6 to ptr), inttoptr (i64 6 to ptr)
  br i1 %v2055, label %tail.yes.2056, label %tail.no.2057
tail.yes.2056:
  %v2058 = ptrtoint ptr %a8 to i64
  %v2059 = ptrtoint ptr inttoptr (i64 121 to ptr) to i64
  %v2060 = icmp eq i64 %v2058, %v2059
  %v2061 = select i1 %v2060, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v2062 = icmp eq ptr %v2061, inttoptr (i64 6 to ptr)
  br i1 %v2062, label %tail.yes.2063, label %tail.no.2064
tail.yes.2063:
  %v2065 = getelementptr i8, ptr %a4, i64 24
  %v2066 = load i64, ptr %v2065, align 8, !tbaa !3
  %v2067 = getelementptr i8, ptr %a4, i64 32
  %v2068 = load ptr, ptr %v2067, align 8, !tbaa !3
  %v2069 = ptrtoint ptr %a9 to i64
  %v2070 = ashr i64 %v2069, 1
  %v2071 = and i64 %v2069, 1
  %v2072 = icmp ne i64 %v2071, 0
  %v2073 = icmp ult i64 %v2070, %v2066
  %v2074 = and i1 %v2072, %v2073
  br i1 %v2074, label %array.valid.2075, label %array.invalid.2076
array.invalid.2076:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2075:
  %v2077 = getelementptr i8, ptr %v2068, i64 %v2070
  %v2078 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v2079 = ashr i64 %v2078, 1
  %v2080 = trunc i64 %v2079 to i8
  store i8 %v2080, ptr %v2077, align 1, !tbaa !4
  %v2081 = ptrtoint ptr %a9 to i64
  %v2082 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2083 = sub i64 %v2082, 1
  %v2084 = add nsw i64 %v2081, %v2083
  %v2085 = inttoptr i64 %v2084 to ptr
  %v2086 = musttail call ptr @mlf.numeric.40.ppppppppnp(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6, ptr %a7, ptr inttoptr (i64 1 to ptr), ptr %v2085)
  ret ptr %v2086
tail.no.2064:
  %v2087 = ptrtoint ptr %a7 to i64
  %v2088 = ptrtoint ptr %a6 to i64
  %v2089 = and i64 %v2087, %v2088
  %v2090 = and i64 %v2089, 1
  %v2091 = icmp ne i64 %v2090, 0
  br i1 %v2091, label %yes.2092, label %no.2093
yes.2092:
  %v2095 = icmp eq i64 %v2087, %v2088
  %v2096 = select i1 %v2095, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.2094
no.2093:
  %v2097 = call ptr @mlf_eq_int(ptr %a7, ptr %a6)
  br label %join.2094
join.2094:
  %v2098 = phi ptr [ %v2096, %yes.2092 ], [ %v2097, %no.2093 ]
  %v2099 = icmp eq ptr %v2098, inttoptr (i64 6 to ptr)
  br i1 %v2099, label %tail.yes.2100, label %tail.no.2101
tail.yes.2100:
  %v2102 = ptrtoint ptr %a8 to i64
  %v2103 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v2104 = icmp eq i64 %v2102, %v2103
  %v2105 = select i1 %v2104, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v2106 = icmp eq ptr %v2105, inttoptr (i64 6 to ptr)
  br i1 %v2106, label %tail.yes.2107, label %tail.no.2108
tail.yes.2107:
  ret ptr inttoptr (i64 4 to ptr)
tail.no.2108:
  %v2109 = getelementptr i8, ptr %a4, i64 24
  %v2110 = load i64, ptr %v2109, align 8, !tbaa !3
  %v2111 = getelementptr i8, ptr %a4, i64 32
  %v2112 = load ptr, ptr %v2111, align 8, !tbaa !3
  %v2113 = ptrtoint ptr %a9 to i64
  %v2114 = ashr i64 %v2113, 1
  %v2115 = and i64 %v2113, 1
  %v2116 = icmp ne i64 %v2115, 0
  %v2117 = icmp ult i64 %v2114, %v2110
  %v2118 = and i1 %v2116, %v2117
  br i1 %v2118, label %array.valid.2119, label %array.invalid.2120
array.invalid.2120:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2119:
  %v2121 = getelementptr i8, ptr %v2112, i64 %v2114
  %v2122 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v2123 = ashr i64 %v2122, 1
  %v2124 = trunc i64 %v2123 to i8
  store i8 %v2124, ptr %v2121, align 1, !tbaa !4
  ret ptr inttoptr (i64 4 to ptr)
tail.no.2101:
  %v2125 = getelementptr i8, ptr %a2, i64 24
  %v2126 = load i64, ptr %v2125, align 8, !tbaa !3
  %v2127 = getelementptr i8, ptr %a2, i64 32
  %v2128 = load ptr, ptr %v2127, align 8, !tbaa !3
  %v2129 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v2130 = ashr i64 %v2129, 1
  %v2131 = and i64 %v2129, 1
  %v2132 = icmp ne i64 %v2131, 0
  %v2133 = icmp ult i64 %v2130, %v2126
  %v2134 = and i1 %v2132, %v2133
  br i1 %v2134, label %array.valid.2135, label %array.invalid.2136
array.invalid.2136:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2135:
  %v2137 = getelementptr i64, ptr %v2128, i64 %v2130
  %v2138 = load ptr, ptr %v2137, align 8, !tbaa !4
  %v2139 = ptrtoint ptr %v2138 to i64
  %v2140 = ptrtoint ptr inttoptr (i64 7755 to ptr) to i64
  %v2141 = and i64 %v2139, %v2140
  %v2142 = and i64 %v2141, 1
  %v2143 = icmp ne i64 %v2142, 0
  br i1 %v2143, label %yes.2144, label %no.2145
yes.2144:
  %v2147 = ashr i64 %v2139, 1
  %v2148 = ashr i64 %v2140, 1
  %v2149 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v2147, i64 %v2148)
  %v2150 = extractvalue { i64, i1 } %v2149, 0
  %v2151 = extractvalue { i64, i1 } %v2149, 1
  %v2152 = xor i1 %v2151, true
  %v2153 = icmp sge i64 %v2150, -4611686018427387904
  %v2154 = icmp sle i64 %v2150, 4611686018427387903
  %v2155 = and i1 %v2153, %v2154
  %v2156 = and i1 %v2155, %v2152
  br i1 %v2156, label %yes.2157, label %no.2158
yes.2157:
  %v2160 = shl i64 %v2150, 1
  %v2161 = or i64 %v2160, 1
  %v2162 = inttoptr i64 %v2161 to ptr
  br label %join.2159
no.2158:
  %v2163 = call ptr @mlf_prim2(i64 14, ptr %v2138, ptr inttoptr (i64 7755 to ptr))
  br label %join.2159
join.2159:
  %v2164 = phi ptr [ %v2162, %yes.2157 ], [ %v2163, %no.2158 ]
  br label %join.2146
no.2145:
  %v2165 = call ptr @mlf_prim2(i64 14, ptr %v2138, ptr inttoptr (i64 7755 to ptr))
  br label %join.2146
join.2146:
  %v2166 = phi ptr [ %v2164, %join.2159 ], [ %v2165, %no.2145 ]
  %v2167 = ptrtoint ptr %v2166 to i64
  %v2168 = ptrtoint ptr inttoptr (i64 59147 to ptr) to i64
  %v2169 = and i64 %v2167, %v2168
  %v2170 = and i64 %v2169, 1
  %v2171 = icmp ne i64 %v2170, 0
  br i1 %v2171, label %yes.2172, label %no.2173
yes.2172:
  %v2175 = sub i64 %v2168, 1
  %v2176 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2167, i64 %v2175)
  %v2177 = extractvalue { i64, i1 } %v2176, 0
  %v2178 = extractvalue { i64, i1 } %v2176, 1
  br i1 %v2178, label %yes.2179, label %no.2180
yes.2179:
  %v2182 = call ptr @mlf_add_int(ptr %v2166, ptr inttoptr (i64 59147 to ptr))
  br label %join.2181
no.2180:
  %v2183 = inttoptr i64 %v2177 to ptr
  br label %join.2181
join.2181:
  %v2184 = phi ptr [ %v2182, %yes.2179 ], [ %v2183, %no.2180 ]
  br label %join.2174
no.2173:
  %v2185 = call ptr @mlf_add_int(ptr %v2166, ptr inttoptr (i64 59147 to ptr))
  br label %join.2174
join.2174:
  %v2186 = phi ptr [ %v2184, %join.2181 ], [ %v2185, %no.2173 ]
  %v2187 = ptrtoint ptr %v2186 to i64
  %v2188 = ptrtoint ptr inttoptr (i64 279937 to ptr) to i64
  %v2189 = and i64 %v2187, %v2188
  %v2190 = and i64 %v2189, 1
  %v2191 = icmp ne i64 %v2190, 0
  br i1 %v2191, label %yes.2192, label %no.2193
yes.2192:
  %v2195 = ashr i64 %v2187, 1
  %v2196 = ashr i64 %v2188, 1
  %v2197 = icmp ne i64 %v2196, 0
  %v2198 = icmp eq i64 %v2195, -4611686018427387904
  %v2199 = icmp eq i64 %v2196, -1
  %v2200 = and i1 %v2198, %v2199
  %v2201 = xor i1 %v2200, true
  %v2202 = and i1 %v2197, %v2201
  br i1 %v2202, label %yes.2203, label %no.2204
yes.2203:
  %v2206 = srem i64 %v2195, %v2196
  %v2207 = shl i64 %v2206, 1
  %v2208 = or i64 %v2207, 1
  %v2209 = inttoptr i64 %v2208 to ptr
  br label %join.2205
no.2204:
  %v2210 = call ptr @mlf_prim2(i64 16, ptr %v2186, ptr inttoptr (i64 279937 to ptr))
  br label %join.2205
join.2205:
  %v2211 = phi ptr [ %v2209, %yes.2203 ], [ %v2210, %no.2204 ]
  br label %join.2194
no.2193:
  %v2212 = call ptr @mlf_prim2(i64 16, ptr %v2186, ptr inttoptr (i64 279937 to ptr))
  br label %join.2194
join.2194:
  %v2213 = phi ptr [ %v2211, %join.2205 ], [ %v2212, %no.2193 ]
  %v2214 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v2215 = ashr i64 %v2214, 1
  %v2216 = and i64 %v2214, 1
  %v2217 = icmp ne i64 %v2216, 0
  %v2218 = icmp ult i64 %v2215, %v2126
  %v2219 = and i1 %v2217, %v2218
  br i1 %v2219, label %array.valid.2220, label %array.invalid.2221
array.invalid.2221:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2220:
  %v2222 = getelementptr i64, ptr %v2128, i64 %v2215
  store ptr %v2213, ptr %v2222, align 8, !tbaa !4
  %v2223 = ptrtoint ptr %v2213 to i64
  %v2224 = and i64 %v2223, 1
  %v2225 = icmp ne i64 %v2224, 0
  br i1 %v2225, label %yes.2226, label %no.2227
yes.2226:
  %v2229 = ashr i64 %v2223, 1
  %v2230 = sitofp i64 %v2229 to double
  br label %join.2228
no.2227:
  %v2231 = call double @mlf_int_to_double(ptr %v2213)
  br label %join.2228
join.2228:
  %v2232 = phi double [ %v2230, %yes.2226 ], [ %v2231, %no.2227 ]
  %v2233 = fdiv double %v2232, 0x4101160000000000
  %v2234 = getelementptr i8, ptr %a3, i64 24
  %v2235 = load i64, ptr %v2234, align 8, !tbaa !3
  %v2236 = getelementptr i8, ptr %a3, i64 32
  %v2237 = load ptr, ptr %v2236, align 8, !tbaa !3
  %v2238 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v2239 = ashr i64 %v2238, 1
  %v2240 = and i64 %v2238, 1
  %v2241 = icmp ne i64 %v2240, 0
  %v2242 = icmp ult i64 %v2239, %v2235
  %v2243 = and i1 %v2241, %v2242
  br i1 %v2243, label %array.valid.2244, label %array.invalid.2245
array.invalid.2245:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2244:
  %v2246 = getelementptr i64, ptr %v2237, i64 %v2239
  store double %v2233, ptr %v2246, align 8, !tbaa !4
  %v2247 = getelementptr i8, ptr %a1, i64 24
  %v2248 = load i64, ptr %v2247, align 8, !tbaa !3
  %v2249 = getelementptr i8, ptr %a1, i64 32
  %v2250 = load ptr, ptr %v2249, align 8, !tbaa !3
  %v2251 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v2252 = ashr i64 %v2251, 1
  %v2253 = and i64 %v2251, 1
  %v2254 = icmp ne i64 %v2253, 0
  %v2255 = icmp ult i64 %v2252, %v2248
  %v2256 = and i1 %v2254, %v2255
  br i1 %v2256, label %array.valid.2257, label %array.invalid.2258
array.invalid.2258:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2257:
  %v2259 = getelementptr i64, ptr %v2250, i64 %v2252
  %v2260 = load double, ptr %v2259, align 8, !tbaa !4
  %v2261 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v2262 = ashr i64 %v2261, 1
  %v2263 = and i64 %v2261, 1
  %v2264 = icmp ne i64 %v2263, 0
  %v2265 = icmp ult i64 %v2262, %v2235
  %v2266 = and i1 %v2264, %v2265
  br i1 %v2266, label %array.valid.2267, label %array.invalid.2268
array.invalid.2268:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2267:
  %v2269 = getelementptr i64, ptr %v2237, i64 %v2262
  %v2270 = load double, ptr %v2269, align 8, !tbaa !4
  %v2271 = fcmp olt double %v2270, %v2260
  %v2272 = select i1 %v2271, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v2273 = icmp eq ptr %v2272, inttoptr (i64 6 to ptr)
  br i1 %v2273, label %yes.2274, label %no.2275
yes.2274:
  %v2277 = getelementptr i8, ptr %a0, i64 24
  %v2278 = load i64, ptr %v2277, align 8, !tbaa !3
  %v2279 = getelementptr i8, ptr %a0, i64 32
  %v2280 = load ptr, ptr %v2279, align 8, !tbaa !3
  %v2281 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v2282 = ashr i64 %v2281, 1
  %v2283 = and i64 %v2281, 1
  %v2284 = icmp ne i64 %v2283, 0
  %v2285 = icmp ult i64 %v2282, %v2278
  %v2286 = and i1 %v2284, %v2285
  br i1 %v2286, label %array.valid.2287, label %array.invalid.2288
array.invalid.2288:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2287:
  %v2289 = getelementptr i8, ptr %v2280, i64 %v2282
  %v2290 = load i8, ptr %v2289, align 1, !tbaa !4
  %v2291 = zext i8 %v2290 to i64
  %v2292 = shl i64 %v2291, 1
  %v2293 = or i64 %v2292, 1
  %v2294 = inttoptr i64 %v2293 to ptr
  br label %join.2276
no.2275:
  %v2295 = ptrtoint ptr %a5 to i64
  %v2296 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2297 = and i64 %v2295, %v2296
  %v2298 = and i64 %v2297, 1
  %v2299 = icmp ne i64 %v2298, 0
  br i1 %v2299, label %yes.2300, label %no.2301
yes.2300:
  %v2303 = sub i64 %v2296, 1
  %v2304 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v2295, i64 %v2303)
  %v2305 = extractvalue { i64, i1 } %v2304, 0
  %v2306 = extractvalue { i64, i1 } %v2304, 1
  br i1 %v2306, label %yes.2307, label %no.2308
yes.2307:
  %v2310 = call ptr @mlf_sub_int(ptr %a5, ptr inttoptr (i64 3 to ptr))
  br label %join.2309
no.2308:
  %v2311 = inttoptr i64 %v2305 to ptr
  br label %join.2309
join.2309:
  %v2312 = phi ptr [ %v2310, %yes.2307 ], [ %v2311, %no.2308 ]
  br label %join.2302
no.2301:
  %v2313 = call ptr @mlf_sub_int(ptr %a5, ptr inttoptr (i64 3 to ptr))
  br label %join.2302
join.2302:
  %v2314 = phi ptr [ %v2312, %join.2309 ], [ %v2313, %no.2301 ]
  %v2450 = call ptr @mlf.numeric.7(ptr %a0, ptr %a1, ptr %a3, ptr inttoptr (i64 1 to ptr), ptr %v2314)
  br label %join.2276
join.2276:
  %v2451 = phi ptr [ %v2294, %array.valid.2287 ], [ %v2450, %join.2302 ]
  %v2452 = getelementptr i8, ptr %a4, i64 24
  %v2453 = load i64, ptr %v2452, align 8, !tbaa !3
  %v2454 = getelementptr i8, ptr %a4, i64 32
  %v2455 = load ptr, ptr %v2454, align 8, !tbaa !3
  %v2456 = ptrtoint ptr %a9 to i64
  %v2457 = ashr i64 %v2456, 1
  %v2458 = and i64 %v2456, 1
  %v2459 = icmp ne i64 %v2458, 0
  %v2460 = icmp ult i64 %v2457, %v2453
  %v2461 = and i1 %v2459, %v2460
  br i1 %v2461, label %array.valid.2462, label %array.invalid.2463
array.invalid.2463:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2462:
  %v2464 = getelementptr i8, ptr %v2455, i64 %v2457
  %v2465 = ptrtoint ptr %v2451 to i64
  %v2466 = ashr i64 %v2465, 1
  %v2467 = and i64 %v2465, 1
  %v2468 = icmp ne i64 %v2467, 0
  %v2469 = icmp ult i64 %v2466, 256
  %v2470 = and i1 %v2468, %v2469
  br i1 %v2470, label %yes.2471, label %no.2472
yes.2471:
  %v2474 = trunc i64 %v2466 to i8
  br label %join.2473
no.2472:
  %v2475 = call i8 @mlf_byte(ptr %v2451)
  br label %join.2473
join.2473:
  %v2476 = phi i8 [ %v2474, %yes.2471 ], [ %v2475, %no.2472 ]
  store i8 %v2476, ptr %v2464, align 1, !tbaa !4
  %v2477 = ptrtoint ptr %a7 to i64
  %v2478 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2479 = and i64 %v2477, %v2478
  %v2480 = and i64 %v2479, 1
  %v2481 = icmp ne i64 %v2480, 0
  br i1 %v2481, label %yes.2482, label %no.2483
yes.2482:
  %v2485 = sub i64 %v2478, 1
  %v2486 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2477, i64 %v2485)
  %v2487 = extractvalue { i64, i1 } %v2486, 0
  %v2488 = extractvalue { i64, i1 } %v2486, 1
  br i1 %v2488, label %yes.2489, label %no.2490
yes.2489:
  %v2492 = call ptr @mlf_add_int(ptr %a7, ptr inttoptr (i64 3 to ptr))
  br label %join.2491
no.2490:
  %v2493 = inttoptr i64 %v2487 to ptr
  br label %join.2491
join.2491:
  %v2494 = phi ptr [ %v2492, %yes.2489 ], [ %v2493, %no.2490 ]
  br label %join.2484
no.2483:
  %v2495 = call ptr @mlf_add_int(ptr %a7, ptr inttoptr (i64 3 to ptr))
  br label %join.2484
join.2484:
  %v2496 = phi ptr [ %v2494, %join.2491 ], [ %v2495, %no.2483 ]
  %v2497 = ptrtoint ptr %a8 to i64
  %v2498 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2499 = and i64 %v2497, %v2498
  %v2500 = and i64 %v2499, 1
  %v2501 = icmp ne i64 %v2500, 0
  br i1 %v2501, label %yes.2502, label %no.2503
yes.2502:
  %v2505 = sub i64 %v2498, 1
  %v2506 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2497, i64 %v2505)
  %v2507 = extractvalue { i64, i1 } %v2506, 0
  %v2508 = extractvalue { i64, i1 } %v2506, 1
  br i1 %v2508, label %yes.2509, label %no.2510
yes.2509:
  %v2512 = call ptr @mlf_add_int(ptr %a8, ptr inttoptr (i64 3 to ptr))
  br label %join.2511
no.2510:
  %v2513 = inttoptr i64 %v2507 to ptr
  br label %join.2511
join.2511:
  %v2514 = phi ptr [ %v2512, %yes.2509 ], [ %v2513, %no.2510 ]
  br label %join.2504
no.2503:
  %v2515 = call ptr @mlf_add_int(ptr %a8, ptr inttoptr (i64 3 to ptr))
  br label %join.2504
join.2504:
  %v2516 = phi ptr [ %v2514, %join.2511 ], [ %v2515, %no.2503 ]
  %v2517 = ptrtoint ptr %a9 to i64
  %v2518 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2519 = sub i64 %v2518, 1
  %v2520 = add nsw i64 %v2517, %v2519
  %v2521 = inttoptr i64 %v2520 to ptr
  %v2911 = musttail call ptr @mlf.numeric.40(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6, ptr %v2496, ptr %v2516, ptr %v2521)
  ret ptr %v2911
tail.no.2057:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.numeric.61(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6) alwaysinline {
entry:
  %v1983 = ptrtoint ptr %a6 to i64
  %v1984 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v1985 = and i64 %v1983, %v1984
  %v1986 = and i64 %v1985, 1
  %v1987 = icmp ne i64 %v1986, 0
  br i1 %v1987, label %yes.1988, label %no.1989
yes.1988:
  %v1991 = icmp eq i64 %v1983, %v1984
  %v1992 = select i1 %v1991, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1990
no.1989:
  %v1993 = call ptr @mlf_eq_int(ptr %a6, ptr inttoptr (i64 1 to ptr))
  br label %join.1990
join.1990:
  %v1994 = phi ptr [ %v1992, %yes.1988 ], [ %v1993, %no.1989 ]
  %v1995 = icmp eq ptr %v1994, inttoptr (i64 6 to ptr)
  br i1 %v1995, label %tail.yes.1996, label %tail.no.1997
tail.yes.1996:
  ret ptr inttoptr (i64 4 to ptr)
tail.no.1997:
  %v1998 = ptrtoint ptr %a6 to i64
  %v1999 = ptrtoint ptr inttoptr (i64 122881 to ptr) to i64
  %v2000 = and i64 %v1998, %v1999
  %v2001 = and i64 %v2000, 1
  %v2002 = icmp ne i64 %v2001, 0
  br i1 %v2002, label %yes.2003, label %no.2004
yes.2003:
  %v2006 = icmp slt i64 %v1998, %v1999
  %v2007 = select i1 %v2006, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.2005
no.2004:
  %v2008 = call ptr @mlf_lt_int(ptr %a6, ptr inttoptr (i64 122881 to ptr))
  br label %join.2005
join.2005:
  %v2009 = phi ptr [ %v2007, %yes.2003 ], [ %v2008, %no.2004 ]
  %v2010 = icmp eq ptr %v2009, inttoptr (i64 6 to ptr)
  br i1 %v2010, label %yes.2011, label %no.2012
yes.2011:
  br label %join.2013
no.2012:
  br label %join.2013
join.2013:
  %v2014 = phi ptr [ %a6, %yes.2011 ], [ inttoptr (i64 122881 to ptr), %no.2012 ]
  %v2912 = call ptr @mlf.numeric.40.ppppppppnp(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %v2014, ptr inttoptr (i64 1 to ptr), ptr inttoptr (i64 1 to ptr), ptr inttoptr (i64 1 to ptr))
  %v2913 = ptrtoint ptr %v2014 to i64
  %v2914 = ptrtoint ptr inttoptr (i64 119 to ptr) to i64
  %v2915 = and i64 %v2913, %v2914
  %v2916 = and i64 %v2915, 1
  %v2917 = icmp ne i64 %v2916, 0
  br i1 %v2917, label %yes.2918, label %no.2919
yes.2918:
  %v2921 = sub i64 %v2914, 1
  %v2922 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2913, i64 %v2921)
  %v2923 = extractvalue { i64, i1 } %v2922, 0
  %v2924 = extractvalue { i64, i1 } %v2922, 1
  br i1 %v2924, label %yes.2925, label %no.2926
yes.2925:
  %v2928 = call ptr @mlf_add_int(ptr %v2014, ptr inttoptr (i64 119 to ptr))
  br label %join.2927
no.2926:
  %v2929 = inttoptr i64 %v2923 to ptr
  br label %join.2927
join.2927:
  %v2930 = phi ptr [ %v2928, %yes.2925 ], [ %v2929, %no.2926 ]
  br label %join.2920
no.2919:
  %v2931 = call ptr @mlf_add_int(ptr %v2014, ptr inttoptr (i64 119 to ptr))
  br label %join.2920
join.2920:
  %v2932 = phi ptr [ %v2930, %join.2927 ], [ %v2931, %no.2919 ]
  %v2933 = ptrtoint ptr %v2932 to i64
  %v2934 = ptrtoint ptr inttoptr (i64 121 to ptr) to i64
  %v2935 = and i64 %v2933, %v2934
  %v2936 = and i64 %v2935, 1
  %v2937 = icmp ne i64 %v2936, 0
  br i1 %v2937, label %yes.2938, label %no.2939
yes.2938:
  %v2941 = ashr i64 %v2933, 1
  %v2942 = ashr i64 %v2934, 1
  %v2943 = icmp ne i64 %v2942, 0
  %v2944 = icmp eq i64 %v2941, -4611686018427387904
  %v2945 = icmp eq i64 %v2942, -1
  %v2946 = and i1 %v2944, %v2945
  %v2947 = xor i1 %v2946, true
  %v2948 = and i1 %v2943, %v2947
  br i1 %v2948, label %yes.2949, label %no.2950
yes.2949:
  %v2952 = sdiv i64 %v2941, %v2942
  %v2953 = shl i64 %v2952, 1
  %v2954 = or i64 %v2953, 1
  %v2955 = inttoptr i64 %v2954 to ptr
  br label %join.2951
no.2950:
  %v2956 = call ptr @mlf_prim2(i64 15, ptr %v2932, ptr inttoptr (i64 121 to ptr))
  br label %join.2951
join.2951:
  %v2957 = phi ptr [ %v2955, %yes.2949 ], [ %v2956, %no.2950 ]
  br label %join.2940
no.2939:
  %v2958 = call ptr @mlf_prim2(i64 15, ptr %v2932, ptr inttoptr (i64 121 to ptr))
  br label %join.2940
join.2940:
  %v2959 = phi ptr [ %v2957, %join.2951 ], [ %v2958, %no.2939 ]
  %v2960 = ptrtoint ptr %v2014 to i64
  %v2961 = ptrtoint ptr %v2959 to i64
  %v2962 = and i64 %v2960, %v2961
  %v2963 = and i64 %v2962, 1
  %v2964 = icmp ne i64 %v2963, 0
  br i1 %v2964, label %yes.2965, label %no.2966
yes.2965:
  %v2968 = sub i64 %v2961, 1
  %v2969 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2960, i64 %v2968)
  %v2970 = extractvalue { i64, i1 } %v2969, 0
  %v2971 = extractvalue { i64, i1 } %v2969, 1
  br i1 %v2971, label %yes.2972, label %no.2973
yes.2972:
  %v2975 = call ptr @mlf_add_int(ptr %v2014, ptr %v2959)
  br label %join.2974
no.2973:
  %v2976 = inttoptr i64 %v2970 to ptr
  br label %join.2974
join.2974:
  %v2977 = phi ptr [ %v2975, %yes.2972 ], [ %v2976, %no.2973 ]
  br label %join.2967
no.2966:
  %v2978 = call ptr @mlf_add_int(ptr %v2014, ptr %v2959)
  br label %join.2967
join.2967:
  %v2979 = phi ptr [ %v2977, %join.2974 ], [ %v2978, %no.2966 ]
  %v2980 = call ptr @mlf_put_bytes(ptr %a4, ptr inttoptr (i64 1 to ptr), ptr %v2979)
  %v2981 = ptrtoint ptr %a6 to i64
  %v2982 = ptrtoint ptr %v2014 to i64
  %v2983 = and i64 %v2981, %v2982
  %v2984 = and i64 %v2983, 1
  %v2985 = icmp ne i64 %v2984, 0
  br i1 %v2985, label %yes.2986, label %no.2987
yes.2986:
  %v2989 = sub i64 %v2982, 1
  %v2990 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v2981, i64 %v2989)
  %v2991 = extractvalue { i64, i1 } %v2990, 0
  %v2992 = extractvalue { i64, i1 } %v2990, 1
  br i1 %v2992, label %yes.2993, label %no.2994
yes.2993:
  %v2996 = call ptr @mlf_sub_int(ptr %a6, ptr %v2014)
  br label %join.2995
no.2994:
  %v2997 = inttoptr i64 %v2991 to ptr
  br label %join.2995
join.2995:
  %v2998 = phi ptr [ %v2996, %yes.2993 ], [ %v2997, %no.2994 ]
  br label %join.2988
no.2987:
  %v2999 = call ptr @mlf_sub_int(ptr %a6, ptr %v2014)
  br label %join.2988
join.2988:
  %v3000 = phi ptr [ %v2998, %join.2995 ], [ %v2999, %no.2987 ]
  %v3001 = musttail call ptr @mlf.numeric.61(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %v3000)
  ret ptr %v3001
}

define private ptr @mlf.code.3010(ptr %env, ptr %arg) {
entry:
  %v3011 = getelementptr i8, ptr %env, i64 24
  %v3012 = load ptr, ptr %v3011, align 8, !tbaa !3
  %v3013 = call ptr @mlf_force(ptr %v3012)
  %v3014 = call ptr @mlf_prim2(i64 11, ptr %v3013, ptr inttoptr (i64 122881 to ptr))
  %v3015 = icmp eq ptr %v3014, inttoptr (i64 6 to ptr)
  br i1 %v3015, label %yes.3016, label %no.3017
yes.3016:
  br label %join.3018
no.3017:
  br label %join.3018
join.3018:
  %v3019 = phi ptr [ %v3013, %yes.3016 ], [ inttoptr (i64 122881 to ptr), %no.3017 ]
  ret ptr %v3019
}

define private ptr @mlf.code.3106(ptr %env, ptr %arg) {
entry:
  %v3107 = getelementptr i8, ptr %env, i64 24
  %v3108 = load ptr, ptr %v3107, align 8, !tbaa !3
  %v3109 = getelementptr i8, ptr %env, i64 32
  %v3110 = load ptr, ptr %v3109, align 8, !tbaa !3
  %v3111 = call ptr @mlf_prim3(i64 37, ptr %v3108, ptr %v3110, ptr inttoptr (i64 21 to ptr))
  ret ptr %v3111
}

define private ptr @mlf.code.3116(ptr %env, ptr %arg) {
entry:
  %v3117 = getelementptr i8, ptr %env, i64 24
  %v3118 = load ptr, ptr %v3117, align 8, !tbaa !3
  %v3119 = getelementptr i8, ptr %env, i64 32
  %v3120 = load ptr, ptr %v3119, align 8, !tbaa !3
  %v3121 = getelementptr i8, ptr %env, i64 40
  %v3122 = load ptr, ptr %v3121, align 8, !tbaa !3
  %v3123 = getelementptr i8, ptr %env, i64 48
  %v3124 = load ptr, ptr %v3123, align 8, !tbaa !3
  %v3125 = getelementptr i8, ptr %env, i64 56
  %v3126 = load ptr, ptr %v3125, align 8, !tbaa !3
  %v3127 = getelementptr i8, ptr %env, i64 64
  %v3128 = load ptr, ptr %v3127, align 8, !tbaa !3
  %v3129 = getelementptr i8, ptr %env, i64 72
  %v3130 = load ptr, ptr %v3129, align 8, !tbaa !3
  %v3131 = getelementptr i8, ptr %env, i64 80
  %v3132 = load ptr, ptr %v3131, align 8, !tbaa !3
  %v3133 = getelementptr i8, ptr %env, i64 88
  %v3134 = load ptr, ptr %v3133, align 8, !tbaa !3
  %v3135 = call ptr @mlf_force(ptr %v3132)
  %v3136 = call ptr @mlf_force(ptr %v3134)
  %v3137 = call ptr @mlf_prim2(i64 8, ptr %v3136, ptr inttoptr (i64 3 to ptr))
  %v3138 = call ptr @mlf_env_new(i64 10)
  %v3139 = getelementptr i8, ptr %v3138, i64 24
  store ptr %v3118, ptr %v3139, align 8, !tbaa !3
  %v3140 = getelementptr i8, ptr %v3138, i64 32
  store ptr %v3120, ptr %v3140, align 8, !tbaa !3
  %v3141 = getelementptr i8, ptr %v3138, i64 40
  store ptr %v3122, ptr %v3141, align 8, !tbaa !3
  %v3142 = getelementptr i8, ptr %v3138, i64 48
  store ptr %v3124, ptr %v3142, align 8, !tbaa !3
  %v3143 = getelementptr i8, ptr %v3138, i64 56
  store ptr %v3126, ptr %v3143, align 8, !tbaa !3
  %v3144 = getelementptr i8, ptr %v3138, i64 64
  store ptr %v3128, ptr %v3144, align 8, !tbaa !3
  %v3145 = getelementptr i8, ptr %v3138, i64 72
  store ptr %v3130, ptr %v3145, align 8, !tbaa !3
  %v3146 = getelementptr i8, ptr %v3138, i64 80
  store ptr %v3135, ptr %v3146, align 8, !tbaa !3
  %v3147 = getelementptr i8, ptr %v3138, i64 88
  store ptr inttoptr (i64 1 to ptr), ptr %v3147, align 8, !tbaa !3
  %v3148 = getelementptr i8, ptr %v3138, i64 96
  store ptr %v3137, ptr %v3148, align 8, !tbaa !3
  %v3149 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.3038, ptr %v3138)
  ret ptr %v3149
}

define private ptr @mlf.code.3176(ptr %env, ptr %arg) {
entry:
  %v3177 = getelementptr i8, ptr %env, i64 24
  %v3178 = load ptr, ptr %v3177, align 8, !tbaa !3
  %v3179 = call ptr @mlf_prim2(i64 28, ptr %v3178, ptr inttoptr (i64 1 to ptr))
  ret ptr %v3179
}

define private ptr @mlf.code.3204(ptr %env, ptr %arg) {
entry:
  %v3205 = getelementptr i8, ptr %env, i64 24
  %v3206 = load ptr, ptr %v3205, align 8, !tbaa !3
  %v3207 = call ptr @mlf_force(ptr %v3206)
  %v3208 = call ptr @mlf_prim2(i64 14, ptr %v3207, ptr inttoptr (i64 7755 to ptr))
  %v3209 = call ptr @mlf_prim2(i64 8, ptr %v3208, ptr inttoptr (i64 59147 to ptr))
  %v3210 = call ptr @mlf_prim2(i64 16, ptr %v3209, ptr inttoptr (i64 279937 to ptr))
  ret ptr %v3210
}

define private ptr @mlf.code.3214(ptr %env, ptr %arg) {
entry:
  %v3215 = getelementptr i8, ptr %env, i64 24
  %v3216 = load ptr, ptr %v3215, align 8, !tbaa !3
  %v3217 = getelementptr i8, ptr %env, i64 32
  %v3218 = load ptr, ptr %v3217, align 8, !tbaa !3
  %v3219 = call ptr @mlf_prim3(i64 29, ptr %v3216, ptr inttoptr (i64 1 to ptr), ptr %v3218)
  ret ptr %v3219
}

define private ptr @mlf.code.3252(ptr %env, ptr %arg) {
entry:
  %v3253 = getelementptr i8, ptr %env, i64 24
  %v3254 = load ptr, ptr %v3253, align 8, !tbaa !3
  %v3255 = call ptr @mlf_force(ptr %v3254)
  %v3256 = call ptr @mlf_prim1(i64 25, ptr %v3255)
  %v3257 = call ptr @mlf_double(double 0x4101160000000000)
  %v3258 = call ptr @mlf_prim2(i64 21, ptr %v3256, ptr %v3257)
  ret ptr %v3258
}

define private ptr @mlf.code.3247(ptr %env, ptr %arg) {
entry:
  %v3248 = getelementptr i8, ptr %env, i64 24
  %v3249 = load ptr, ptr %v3248, align 8, !tbaa !3
  %v3250 = getelementptr i8, ptr %env, i64 32
  %v3251 = load ptr, ptr %v3250, align 8, !tbaa !3
  %v3259 = call ptr @mlf_env_new(i64 1)
  %v3260 = getelementptr i8, ptr %v3259, i64 24
  store ptr %v3251, ptr %v3260, align 8, !tbaa !3
  %v3261 = call ptr @mlf_thunk(ptr @mlf.code.3252, ptr %v3259)
  %v3262 = call ptr @mlf_prim3(i64 33, ptr %v3249, ptr inttoptr (i64 1 to ptr), ptr %v3261)
  ret ptr %v3262
}

define private ptr @mlf.code.3297(ptr %env, ptr %arg) {
entry:
  %v3298 = getelementptr i8, ptr %env, i64 24
  %v3299 = load ptr, ptr %v3298, align 8, !tbaa !3
  %v3300 = call ptr @mlf_prim2(i64 32, ptr %v3299, ptr inttoptr (i64 1 to ptr))
  ret ptr %v3300
}

define private ptr @mlf.code.3313(ptr %env, ptr %arg) {
entry:
  %v3314 = getelementptr i8, ptr %env, i64 24
  %v3315 = load ptr, ptr %v3314, align 8, !tbaa !3
  %v3316 = call ptr @mlf_prim2(i64 32, ptr %v3315, ptr inttoptr (i64 1 to ptr))
  ret ptr %v3316
}

define private ptr @mlf.code.3376(ptr %env, ptr %arg) {
entry:
  %v3377 = getelementptr i8, ptr %env, i64 24
  %v3378 = load ptr, ptr %v3377, align 8, !tbaa !3
  %v3379 = getelementptr i8, ptr %env, i64 32
  %v3380 = load ptr, ptr %v3379, align 8, !tbaa !3
  %v3381 = call ptr @mlf_force(ptr %v3378)
  %v3382 = call ptr @mlf_force(ptr %v3380)
  %v3383 = call ptr @mlf_prim2(i64 8, ptr %v3381, ptr %v3382)
  %v3384 = call ptr @mlf_prim2(i64 15, ptr %v3383, ptr inttoptr (i64 5 to ptr))
  ret ptr %v3384
}

define private ptr @mlf.code.3389(ptr %env, ptr %arg) {
entry:
  %v3390 = getelementptr i8, ptr %env, i64 24
  %v3391 = load ptr, ptr %v3390, align 8, !tbaa !3
  %v3392 = getelementptr i8, ptr %env, i64 32
  %v3393 = load ptr, ptr %v3392, align 8, !tbaa !3
  %v3394 = call ptr @mlf_prim2(i64 32, ptr %v3391, ptr %v3393)
  ret ptr %v3394
}

define private ptr @mlf.code.3412(ptr %env, ptr %arg) {
entry:
  %v3413 = getelementptr i8, ptr %env, i64 24
  %v3414 = load ptr, ptr %v3413, align 8, !tbaa !3
  %v3415 = call ptr @mlf_prim2(i64 32, ptr %v3414, ptr inttoptr (i64 1 to ptr))
  ret ptr %v3415
}

define private ptr @mlf.code.3419(ptr %env, ptr %arg) {
entry:
  %v3420 = getelementptr i8, ptr %env, i64 24
  %v3421 = load ptr, ptr %v3420, align 8, !tbaa !3
  %v3422 = getelementptr i8, ptr %env, i64 32
  %v3423 = load ptr, ptr %v3422, align 8, !tbaa !3
  %v3424 = getelementptr i8, ptr %env, i64 40
  %v3425 = load ptr, ptr %v3424, align 8, !tbaa !3
  %v3426 = getelementptr i8, ptr %env, i64 48
  %v3427 = load ptr, ptr %v3426, align 8, !tbaa !3
  %v3428 = getelementptr i8, ptr %env, i64 56
  %v3429 = load ptr, ptr %v3428, align 8, !tbaa !3
  %v3430 = getelementptr i8, ptr %env, i64 64
  %v3431 = load ptr, ptr %v3430, align 8, !tbaa !3
  %v3432 = getelementptr i8, ptr %env, i64 72
  %v3433 = load ptr, ptr %v3432, align 8, !tbaa !3
  %v3434 = call ptr @mlf_force(ptr %arg)
  %v3435 = call ptr @mlf_force(ptr %v3433)
  %v3436 = call ptr @mlf_prim2(i64 24, ptr %v3434, ptr %v3435)
  %v3437 = icmp eq ptr %v3436, inttoptr (i64 6 to ptr)
  br i1 %v3437, label %yes.3438, label %no.3439
yes.3438:
  %v3441 = call ptr @mlf_force(ptr %v3427)
  %v3442 = call ptr @mlf_force(ptr %v3431)
  %v3443 = call ptr @mlf_env_new(i64 5)
  %v3444 = getelementptr i8, ptr %v3443, i64 24
  store ptr %v3421, ptr %v3444, align 8, !tbaa !3
  %v3445 = getelementptr i8, ptr %v3443, i64 32
  store ptr %v3423, ptr %v3445, align 8, !tbaa !3
  %v3446 = getelementptr i8, ptr %v3443, i64 40
  store ptr %v3425, ptr %v3446, align 8, !tbaa !3
  %v3447 = getelementptr i8, ptr %v3443, i64 48
  store ptr %v3441, ptr %v3447, align 8, !tbaa !3
  %v3448 = getelementptr i8, ptr %v3443, i64 56
  store ptr %v3442, ptr %v3448, align 8, !tbaa !3
  %v3449 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.3339, ptr %v3443)
  br label %join.3440
no.3439:
  %v3450 = call ptr @mlf_force(ptr %v3431)
  %v3451 = call ptr @mlf_force(ptr %v3429)
  %v3452 = call ptr @mlf_env_new(i64 5)
  %v3453 = getelementptr i8, ptr %v3452, i64 24
  store ptr %v3421, ptr %v3453, align 8, !tbaa !3
  %v3454 = getelementptr i8, ptr %v3452, i64 32
  store ptr %v3423, ptr %v3454, align 8, !tbaa !3
  %v3455 = getelementptr i8, ptr %v3452, i64 40
  store ptr %v3425, ptr %v3455, align 8, !tbaa !3
  %v3456 = getelementptr i8, ptr %v3452, i64 48
  store ptr %v3450, ptr %v3456, align 8, !tbaa !3
  %v3457 = getelementptr i8, ptr %v3452, i64 56
  store ptr %v3451, ptr %v3457, align 8, !tbaa !3
  %v3458 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.3339, ptr %v3452)
  br label %join.3440
join.3440:
  %v3459 = phi ptr [ %v3449, %yes.3438 ], [ %v3458, %no.3439 ]
  ret ptr %v3459
}

define private ptr @mlf.code.3399(ptr %env, ptr %arg) {
entry:
  %v3400 = getelementptr i8, ptr %env, i64 24
  %v3401 = load ptr, ptr %v3400, align 8, !tbaa !3
  %v3402 = getelementptr i8, ptr %env, i64 32
  %v3403 = load ptr, ptr %v3402, align 8, !tbaa !3
  %v3404 = getelementptr i8, ptr %env, i64 40
  %v3405 = load ptr, ptr %v3404, align 8, !tbaa !3
  %v3406 = getelementptr i8, ptr %env, i64 48
  %v3407 = load ptr, ptr %v3406, align 8, !tbaa !3
  %v3408 = getelementptr i8, ptr %env, i64 56
  %v3409 = load ptr, ptr %v3408, align 8, !tbaa !3
  %v3410 = getelementptr i8, ptr %env, i64 64
  %v3411 = load ptr, ptr %v3410, align 8, !tbaa !3
  %v3416 = call ptr @mlf_env_new(i64 1)
  %v3417 = getelementptr i8, ptr %v3416, i64 24
  store ptr %v3405, ptr %v3417, align 8, !tbaa !3
  %v3418 = call ptr @mlf_thunk(ptr @mlf.code.3412, ptr %v3416)
  %v3460 = call ptr @mlf_env_new(i64 7)
  %v3461 = getelementptr i8, ptr %v3460, i64 24
  store ptr %v3401, ptr %v3461, align 8, !tbaa !3
  %v3462 = getelementptr i8, ptr %v3460, i64 32
  store ptr %v3403, ptr %v3462, align 8, !tbaa !3
  %v3463 = getelementptr i8, ptr %v3460, i64 40
  store ptr %v3405, ptr %v3463, align 8, !tbaa !3
  %v3464 = getelementptr i8, ptr %v3460, i64 48
  store ptr %v3407, ptr %v3464, align 8, !tbaa !3
  %v3465 = getelementptr i8, ptr %v3460, i64 56
  store ptr %v3409, ptr %v3465, align 8, !tbaa !3
  %v3466 = getelementptr i8, ptr %v3460, i64 64
  store ptr %v3411, ptr %v3466, align 8, !tbaa !3
  %v3467 = getelementptr i8, ptr %v3460, i64 72
  store ptr %arg, ptr %v3467, align 8, !tbaa !3
  %v3468 = call ptr @mlf_closure(ptr @mlf.code.3419, ptr %v3460)
  %v3469 = call ptr @mlf_prim2(i64 1, ptr %v3418, ptr %v3468)
  ret ptr %v3469
}

define private ptr @mlf.worker.7(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) {
entry:
  %v3370 = call ptr @mlf_prim2(i64 8, ptr %a3, ptr inttoptr (i64 3 to ptr))
  %v3371 = call ptr @mlf_prim2(i64 11, ptr %v3370, ptr %a4)
  %v3372 = icmp eq ptr %v3371, inttoptr (i64 6 to ptr)
  br i1 %v3372, label %yes.3373, label %no.3374
yes.3373:
  %v3385 = call ptr @mlf_env_new(i64 2)
  %v3386 = getelementptr i8, ptr %v3385, i64 24
  store ptr %a3, ptr %v3386, align 8, !tbaa !3
  %v3387 = getelementptr i8, ptr %v3385, i64 32
  store ptr %a4, ptr %v3387, align 8, !tbaa !3
  %v3388 = call ptr @mlf_thunk(ptr @mlf.code.3376, ptr %v3385)
  %v3395 = call ptr @mlf_env_new(i64 2)
  %v3396 = getelementptr i8, ptr %v3395, i64 24
  store ptr %a1, ptr %v3396, align 8, !tbaa !3
  %v3397 = getelementptr i8, ptr %v3395, i64 32
  store ptr %v3388, ptr %v3397, align 8, !tbaa !3
  %v3398 = call ptr @mlf_thunk(ptr @mlf.code.3389, ptr %v3395)
  %v3470 = call ptr @mlf_env_new(i64 6)
  %v3471 = getelementptr i8, ptr %v3470, i64 24
  store ptr %a0, ptr %v3471, align 8, !tbaa !3
  %v3472 = getelementptr i8, ptr %v3470, i64 32
  store ptr %a1, ptr %v3472, align 8, !tbaa !3
  %v3473 = getelementptr i8, ptr %v3470, i64 40
  store ptr %a2, ptr %v3473, align 8, !tbaa !3
  %v3474 = getelementptr i8, ptr %v3470, i64 48
  store ptr %a3, ptr %v3474, align 8, !tbaa !3
  %v3475 = getelementptr i8, ptr %v3470, i64 56
  store ptr %a4, ptr %v3475, align 8, !tbaa !3
  %v3476 = getelementptr i8, ptr %v3470, i64 64
  store ptr %v3388, ptr %v3476, align 8, !tbaa !3
  %v3477 = call ptr @mlf_closure(ptr @mlf.code.3399, ptr %v3470)
  %v3478 = call ptr @mlf_prim2(i64 1, ptr %v3398, ptr %v3477)
  br label %join.3375
no.3374:
  %v3479 = call ptr @mlf_prim2(i64 36, ptr %a0, ptr %a4)
  br label %join.3375
join.3375:
  %v3480 = phi ptr [ %v3478, %yes.3373 ], [ %v3479, %no.3374 ]
  ret ptr %v3480
}

define private ptr @mlf.numeric.entry.3339(ptr %env, ptr %arg) {
entry:
  %v3340 = getelementptr i8, ptr %env, i64 24
  %v3341 = load ptr, ptr %v3340, align 8, !tbaa !3
  %v3342 = getelementptr i8, ptr %env, i64 32
  %v3343 = load ptr, ptr %v3342, align 8, !tbaa !3
  %v3344 = getelementptr i8, ptr %env, i64 40
  %v3345 = load ptr, ptr %v3344, align 8, !tbaa !3
  %v3346 = getelementptr i8, ptr %env, i64 48
  %v3347 = load ptr, ptr %v3346, align 8, !tbaa !3
  %v3348 = getelementptr i8, ptr %env, i64 56
  %v3349 = load ptr, ptr %v3348, align 8, !tbaa !3
  %v3350 = call ptr @mlf_peek(ptr %v3341)
  %v3351 = call ptr @mlf_peek(ptr %v3343)
  %v3352 = call ptr @mlf_peek(ptr %v3345)
  %v3353 = call ptr @mlf_peek(ptr %v3347)
  %v3354 = call ptr @mlf_peek(ptr %v3349)
  %v3355 = icmp ne ptr %v3350, null
  %v3356 = icmp ne ptr %v3351, null
  %v3357 = icmp ne ptr %v3352, null
  %v3358 = icmp ne ptr %v3353, null
  %v3359 = icmp ne ptr %v3354, null
  %v3360 = and i1 true, %v3355
  %v3361 = and i1 %v3360, %v3356
  %v3362 = and i1 %v3361, %v3357
  %v3363 = and i1 %v3362, %v3358
  %v3364 = and i1 %v3363, %v3359
  br i1 %v3364, label %yes.3365, label %no.3366
yes.3365:
  %v3368 = call ptr @mlf.numeric.7(ptr %v3350, ptr %v3351, ptr %v3352, ptr %v3353, ptr %v3354)
  %v3369 = call ptr @mlf_prim1(i64 0, ptr %v3368)
  br label %join.3367
no.3366:
  %v3481 = call ptr @mlf_force(ptr %v3347)
  %v3482 = call ptr @mlf_force(ptr %v3349)
  %v3483 = call ptr @mlf.worker.7(ptr %v3341, ptr %v3343, ptr %v3345, ptr %v3481, ptr %v3482)
  br label %join.3367
join.3367:
  %v3484 = phi ptr [ %v3369, %yes.3365 ], [ %v3483, %no.3366 ]
  ret ptr %v3484
}

define private ptr @mlf.code.3320(ptr %env, ptr %arg) {
entry:
  %v3321 = getelementptr i8, ptr %env, i64 24
  %v3322 = load ptr, ptr %v3321, align 8, !tbaa !3
  %v3323 = getelementptr i8, ptr %env, i64 32
  %v3324 = load ptr, ptr %v3323, align 8, !tbaa !3
  %v3325 = getelementptr i8, ptr %env, i64 40
  %v3326 = load ptr, ptr %v3325, align 8, !tbaa !3
  %v3327 = getelementptr i8, ptr %env, i64 48
  %v3328 = load ptr, ptr %v3327, align 8, !tbaa !3
  %v3329 = getelementptr i8, ptr %env, i64 56
  %v3330 = load ptr, ptr %v3329, align 8, !tbaa !3
  %v3331 = call ptr @mlf_force(ptr %arg)
  %v3332 = call ptr @mlf_force(ptr %v3330)
  %v3333 = call ptr @mlf_prim2(i64 24, ptr %v3331, ptr %v3332)
  %v3334 = icmp eq ptr %v3333, inttoptr (i64 6 to ptr)
  br i1 %v3334, label %yes.3335, label %no.3336
yes.3335:
  %v3338 = call ptr @mlf_prim2(i64 36, ptr %v3322, ptr inttoptr (i64 1 to ptr))
  br label %join.3337
no.3336:
  %v3485 = call ptr @mlf_force(ptr %v3328)
  %v3486 = call ptr @mlf_prim2(i64 9, ptr %v3485, ptr inttoptr (i64 3 to ptr))
  %v3487 = call ptr @mlf_env_new(i64 5)
  %v3488 = getelementptr i8, ptr %v3487, i64 24
  store ptr %v3322, ptr %v3488, align 8, !tbaa !3
  %v3489 = getelementptr i8, ptr %v3487, i64 32
  store ptr %v3324, ptr %v3489, align 8, !tbaa !3
  %v3490 = getelementptr i8, ptr %v3487, i64 40
  store ptr %v3326, ptr %v3490, align 8, !tbaa !3
  %v3491 = getelementptr i8, ptr %v3487, i64 48
  store ptr inttoptr (i64 1 to ptr), ptr %v3491, align 8, !tbaa !3
  %v3492 = getelementptr i8, ptr %v3487, i64 56
  store ptr %v3486, ptr %v3492, align 8, !tbaa !3
  %v3493 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.3339, ptr %v3487)
  br label %join.3337
join.3337:
  %v3494 = phi ptr [ %v3338, %yes.3335 ], [ %v3493, %no.3336 ]
  ret ptr %v3494
}

define private ptr @mlf.code.3304(ptr %env, ptr %arg) {
entry:
  %v3305 = getelementptr i8, ptr %env, i64 24
  %v3306 = load ptr, ptr %v3305, align 8, !tbaa !3
  %v3307 = getelementptr i8, ptr %env, i64 32
  %v3308 = load ptr, ptr %v3307, align 8, !tbaa !3
  %v3309 = getelementptr i8, ptr %env, i64 40
  %v3310 = load ptr, ptr %v3309, align 8, !tbaa !3
  %v3311 = getelementptr i8, ptr %env, i64 48
  %v3312 = load ptr, ptr %v3311, align 8, !tbaa !3
  %v3317 = call ptr @mlf_env_new(i64 1)
  %v3318 = getelementptr i8, ptr %v3317, i64 24
  store ptr %v3310, ptr %v3318, align 8, !tbaa !3
  %v3319 = call ptr @mlf_thunk(ptr @mlf.code.3313, ptr %v3317)
  %v3495 = call ptr @mlf_env_new(i64 5)
  %v3496 = getelementptr i8, ptr %v3495, i64 24
  store ptr %v3306, ptr %v3496, align 8, !tbaa !3
  %v3497 = getelementptr i8, ptr %v3495, i64 32
  store ptr %v3308, ptr %v3497, align 8, !tbaa !3
  %v3498 = getelementptr i8, ptr %v3495, i64 40
  store ptr %v3310, ptr %v3498, align 8, !tbaa !3
  %v3499 = getelementptr i8, ptr %v3495, i64 48
  store ptr %v3312, ptr %v3499, align 8, !tbaa !3
  %v3500 = getelementptr i8, ptr %v3495, i64 56
  store ptr %arg, ptr %v3500, align 8, !tbaa !3
  %v3501 = call ptr @mlf_closure(ptr @mlf.code.3320, ptr %v3495)
  %v3502 = call ptr @mlf_prim2(i64 1, ptr %v3319, ptr %v3501)
  ret ptr %v3502
}

define private ptr @mlf.code.3288(ptr %env, ptr %arg) {
entry:
  %v3289 = getelementptr i8, ptr %env, i64 24
  %v3290 = load ptr, ptr %v3289, align 8, !tbaa !3
  %v3291 = getelementptr i8, ptr %env, i64 32
  %v3292 = load ptr, ptr %v3291, align 8, !tbaa !3
  %v3293 = getelementptr i8, ptr %env, i64 40
  %v3294 = load ptr, ptr %v3293, align 8, !tbaa !3
  %v3295 = getelementptr i8, ptr %env, i64 48
  %v3296 = load ptr, ptr %v3295, align 8, !tbaa !3
  %v3301 = call ptr @mlf_env_new(i64 1)
  %v3302 = getelementptr i8, ptr %v3301, i64 24
  store ptr %v3292, ptr %v3302, align 8, !tbaa !3
  %v3303 = call ptr @mlf_thunk(ptr @mlf.code.3297, ptr %v3301)
  %v3503 = call ptr @mlf_env_new(i64 4)
  %v3504 = getelementptr i8, ptr %v3503, i64 24
  store ptr %v3290, ptr %v3504, align 8, !tbaa !3
  %v3505 = getelementptr i8, ptr %v3503, i64 32
  store ptr %v3292, ptr %v3505, align 8, !tbaa !3
  %v3506 = getelementptr i8, ptr %v3503, i64 40
  store ptr %v3294, ptr %v3506, align 8, !tbaa !3
  %v3507 = getelementptr i8, ptr %v3503, i64 48
  store ptr %v3296, ptr %v3507, align 8, !tbaa !3
  %v3508 = call ptr @mlf_closure(ptr @mlf.code.3304, ptr %v3503)
  %v3509 = call ptr @mlf_prim2(i64 1, ptr %v3303, ptr %v3508)
  ret ptr %v3509
}

define private ptr @mlf.code.3537(ptr %env, ptr %arg) {
entry:
  %v3538 = getelementptr i8, ptr %env, i64 24
  %v3539 = load ptr, ptr %v3538, align 8, !tbaa !3
  %v3540 = getelementptr i8, ptr %env, i64 32
  %v3541 = load ptr, ptr %v3540, align 8, !tbaa !3
  %v3542 = getelementptr i8, ptr %env, i64 40
  %v3543 = load ptr, ptr %v3542, align 8, !tbaa !3
  %v3544 = call ptr @mlf_prim3(i64 37, ptr %v3539, ptr %v3541, ptr %v3543)
  ret ptr %v3544
}

define private ptr @mlf.code.3550(ptr %env, ptr %arg) {
entry:
  %v3551 = getelementptr i8, ptr %env, i64 24
  %v3552 = load ptr, ptr %v3551, align 8, !tbaa !3
  %v3553 = getelementptr i8, ptr %env, i64 32
  %v3554 = load ptr, ptr %v3553, align 8, !tbaa !3
  %v3555 = getelementptr i8, ptr %env, i64 40
  %v3556 = load ptr, ptr %v3555, align 8, !tbaa !3
  %v3557 = getelementptr i8, ptr %env, i64 48
  %v3558 = load ptr, ptr %v3557, align 8, !tbaa !3
  %v3559 = getelementptr i8, ptr %env, i64 56
  %v3560 = load ptr, ptr %v3559, align 8, !tbaa !3
  %v3561 = getelementptr i8, ptr %env, i64 64
  %v3562 = load ptr, ptr %v3561, align 8, !tbaa !3
  %v3563 = getelementptr i8, ptr %env, i64 72
  %v3564 = load ptr, ptr %v3563, align 8, !tbaa !3
  %v3565 = getelementptr i8, ptr %env, i64 80
  %v3566 = load ptr, ptr %v3565, align 8, !tbaa !3
  %v3567 = getelementptr i8, ptr %env, i64 88
  %v3568 = load ptr, ptr %v3567, align 8, !tbaa !3
  %v3569 = getelementptr i8, ptr %env, i64 96
  %v3570 = load ptr, ptr %v3569, align 8, !tbaa !3
  %v3571 = call ptr @mlf_force(ptr %v3566)
  %v3572 = call ptr @mlf_prim2(i64 8, ptr %v3571, ptr inttoptr (i64 3 to ptr))
  %v3573 = call ptr @mlf_force(ptr %v3568)
  %v3574 = call ptr @mlf_prim2(i64 8, ptr %v3573, ptr inttoptr (i64 3 to ptr))
  %v3575 = call ptr @mlf_force(ptr %v3570)
  %v3576 = call ptr @mlf_prim2(i64 8, ptr %v3575, ptr inttoptr (i64 3 to ptr))
  %v3577 = call ptr @mlf_env_new(i64 10)
  %v3578 = getelementptr i8, ptr %v3577, i64 24
  store ptr %v3552, ptr %v3578, align 8, !tbaa !3
  %v3579 = getelementptr i8, ptr %v3577, i64 32
  store ptr %v3554, ptr %v3579, align 8, !tbaa !3
  %v3580 = getelementptr i8, ptr %v3577, i64 40
  store ptr %v3556, ptr %v3580, align 8, !tbaa !3
  %v3581 = getelementptr i8, ptr %v3577, i64 48
  store ptr %v3558, ptr %v3581, align 8, !tbaa !3
  %v3582 = getelementptr i8, ptr %v3577, i64 56
  store ptr %v3560, ptr %v3582, align 8, !tbaa !3
  %v3583 = getelementptr i8, ptr %v3577, i64 64
  store ptr %v3562, ptr %v3583, align 8, !tbaa !3
  %v3584 = getelementptr i8, ptr %v3577, i64 72
  store ptr %v3564, ptr %v3584, align 8, !tbaa !3
  %v3585 = getelementptr i8, ptr %v3577, i64 80
  store ptr %v3572, ptr %v3585, align 8, !tbaa !3
  %v3586 = getelementptr i8, ptr %v3577, i64 88
  store ptr %v3574, ptr %v3586, align 8, !tbaa !3
  %v3587 = getelementptr i8, ptr %v3577, i64 96
  store ptr %v3576, ptr %v3587, align 8, !tbaa !3
  %v3588 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.3038, ptr %v3577)
  ret ptr %v3588
}

define private ptr @mlf.code.3516(ptr %env, ptr %arg) {
entry:
  %v3517 = getelementptr i8, ptr %env, i64 24
  %v3518 = load ptr, ptr %v3517, align 8, !tbaa !3
  %v3519 = getelementptr i8, ptr %env, i64 32
  %v3520 = load ptr, ptr %v3519, align 8, !tbaa !3
  %v3521 = getelementptr i8, ptr %env, i64 40
  %v3522 = load ptr, ptr %v3521, align 8, !tbaa !3
  %v3523 = getelementptr i8, ptr %env, i64 48
  %v3524 = load ptr, ptr %v3523, align 8, !tbaa !3
  %v3525 = getelementptr i8, ptr %env, i64 56
  %v3526 = load ptr, ptr %v3525, align 8, !tbaa !3
  %v3527 = getelementptr i8, ptr %env, i64 64
  %v3528 = load ptr, ptr %v3527, align 8, !tbaa !3
  %v3529 = getelementptr i8, ptr %env, i64 72
  %v3530 = load ptr, ptr %v3529, align 8, !tbaa !3
  %v3531 = getelementptr i8, ptr %env, i64 80
  %v3532 = load ptr, ptr %v3531, align 8, !tbaa !3
  %v3533 = getelementptr i8, ptr %env, i64 88
  %v3534 = load ptr, ptr %v3533, align 8, !tbaa !3
  %v3535 = getelementptr i8, ptr %env, i64 96
  %v3536 = load ptr, ptr %v3535, align 8, !tbaa !3
  %v3545 = call ptr @mlf_env_new(i64 3)
  %v3546 = getelementptr i8, ptr %v3545, i64 24
  store ptr %v3526, ptr %v3546, align 8, !tbaa !3
  %v3547 = getelementptr i8, ptr %v3545, i64 32
  store ptr %v3536, ptr %v3547, align 8, !tbaa !3
  %v3548 = getelementptr i8, ptr %v3545, i64 40
  store ptr %arg, ptr %v3548, align 8, !tbaa !3
  %v3549 = call ptr @mlf_thunk(ptr @mlf.code.3537, ptr %v3545)
  %v3589 = call ptr @mlf_env_new(i64 10)
  %v3590 = getelementptr i8, ptr %v3589, i64 24
  store ptr %v3518, ptr %v3590, align 8, !tbaa !3
  %v3591 = getelementptr i8, ptr %v3589, i64 32
  store ptr %v3520, ptr %v3591, align 8, !tbaa !3
  %v3592 = getelementptr i8, ptr %v3589, i64 40
  store ptr %v3522, ptr %v3592, align 8, !tbaa !3
  %v3593 = getelementptr i8, ptr %v3589, i64 48
  store ptr %v3524, ptr %v3593, align 8, !tbaa !3
  %v3594 = getelementptr i8, ptr %v3589, i64 56
  store ptr %v3526, ptr %v3594, align 8, !tbaa !3
  %v3595 = getelementptr i8, ptr %v3589, i64 64
  store ptr %v3528, ptr %v3595, align 8, !tbaa !3
  %v3596 = getelementptr i8, ptr %v3589, i64 72
  store ptr %v3530, ptr %v3596, align 8, !tbaa !3
  %v3597 = getelementptr i8, ptr %v3589, i64 80
  store ptr %v3532, ptr %v3597, align 8, !tbaa !3
  %v3598 = getelementptr i8, ptr %v3589, i64 88
  store ptr %v3534, ptr %v3598, align 8, !tbaa !3
  %v3599 = getelementptr i8, ptr %v3589, i64 96
  store ptr %v3536, ptr %v3599, align 8, !tbaa !3
  %v3600 = call ptr @mlf_closure(ptr @mlf.code.3550, ptr %v3589)
  %v3601 = call ptr @mlf_prim2(i64 1, ptr %v3549, ptr %v3600)
  ret ptr %v3601
}

define private ptr @mlf.code.3267(ptr %env, ptr %arg) {
entry:
  %v3268 = getelementptr i8, ptr %env, i64 24
  %v3269 = load ptr, ptr %v3268, align 8, !tbaa !3
  %v3270 = getelementptr i8, ptr %env, i64 32
  %v3271 = load ptr, ptr %v3270, align 8, !tbaa !3
  %v3272 = getelementptr i8, ptr %env, i64 40
  %v3273 = load ptr, ptr %v3272, align 8, !tbaa !3
  %v3274 = getelementptr i8, ptr %env, i64 48
  %v3275 = load ptr, ptr %v3274, align 8, !tbaa !3
  %v3276 = getelementptr i8, ptr %env, i64 56
  %v3277 = load ptr, ptr %v3276, align 8, !tbaa !3
  %v3278 = getelementptr i8, ptr %env, i64 64
  %v3279 = load ptr, ptr %v3278, align 8, !tbaa !3
  %v3280 = getelementptr i8, ptr %env, i64 72
  %v3281 = load ptr, ptr %v3280, align 8, !tbaa !3
  %v3282 = getelementptr i8, ptr %env, i64 80
  %v3283 = load ptr, ptr %v3282, align 8, !tbaa !3
  %v3284 = getelementptr i8, ptr %env, i64 88
  %v3285 = load ptr, ptr %v3284, align 8, !tbaa !3
  %v3286 = getelementptr i8, ptr %env, i64 96
  %v3287 = load ptr, ptr %v3286, align 8, !tbaa !3
  %v3510 = call ptr @mlf_env_new(i64 4)
  %v3511 = getelementptr i8, ptr %v3510, i64 24
  store ptr %v3269, ptr %v3511, align 8, !tbaa !3
  %v3512 = getelementptr i8, ptr %v3510, i64 32
  store ptr %v3271, ptr %v3512, align 8, !tbaa !3
  %v3513 = getelementptr i8, ptr %v3510, i64 40
  store ptr %v3275, ptr %v3513, align 8, !tbaa !3
  %v3514 = getelementptr i8, ptr %v3510, i64 48
  store ptr %v3279, ptr %v3514, align 8, !tbaa !3
  %v3515 = call ptr @mlf_thunk(ptr @mlf.code.3288, ptr %v3510)
  %v3602 = call ptr @mlf_env_new(i64 10)
  %v3603 = getelementptr i8, ptr %v3602, i64 24
  store ptr %v3269, ptr %v3603, align 8, !tbaa !3
  %v3604 = getelementptr i8, ptr %v3602, i64 32
  store ptr %v3271, ptr %v3604, align 8, !tbaa !3
  %v3605 = getelementptr i8, ptr %v3602, i64 40
  store ptr %v3273, ptr %v3605, align 8, !tbaa !3
  %v3606 = getelementptr i8, ptr %v3602, i64 48
  store ptr %v3275, ptr %v3606, align 8, !tbaa !3
  %v3607 = getelementptr i8, ptr %v3602, i64 56
  store ptr %v3277, ptr %v3607, align 8, !tbaa !3
  %v3608 = getelementptr i8, ptr %v3602, i64 64
  store ptr %v3279, ptr %v3608, align 8, !tbaa !3
  %v3609 = getelementptr i8, ptr %v3602, i64 72
  store ptr %v3281, ptr %v3609, align 8, !tbaa !3
  %v3610 = getelementptr i8, ptr %v3602, i64 80
  store ptr %v3283, ptr %v3610, align 8, !tbaa !3
  %v3611 = getelementptr i8, ptr %v3602, i64 88
  store ptr %v3285, ptr %v3611, align 8, !tbaa !3
  %v3612 = getelementptr i8, ptr %v3602, i64 96
  store ptr %v3287, ptr %v3612, align 8, !tbaa !3
  %v3613 = call ptr @mlf_closure(ptr @mlf.code.3516, ptr %v3602)
  %v3614 = call ptr @mlf_prim2(i64 1, ptr %v3515, ptr %v3613)
  ret ptr %v3614
}

define private ptr @mlf.code.3224(ptr %env, ptr %arg) {
entry:
  %v3225 = getelementptr i8, ptr %env, i64 24
  %v3226 = load ptr, ptr %v3225, align 8, !tbaa !3
  %v3227 = getelementptr i8, ptr %env, i64 32
  %v3228 = load ptr, ptr %v3227, align 8, !tbaa !3
  %v3229 = getelementptr i8, ptr %env, i64 40
  %v3230 = load ptr, ptr %v3229, align 8, !tbaa !3
  %v3231 = getelementptr i8, ptr %env, i64 48
  %v3232 = load ptr, ptr %v3231, align 8, !tbaa !3
  %v3233 = getelementptr i8, ptr %env, i64 56
  %v3234 = load ptr, ptr %v3233, align 8, !tbaa !3
  %v3235 = getelementptr i8, ptr %env, i64 64
  %v3236 = load ptr, ptr %v3235, align 8, !tbaa !3
  %v3237 = getelementptr i8, ptr %env, i64 72
  %v3238 = load ptr, ptr %v3237, align 8, !tbaa !3
  %v3239 = getelementptr i8, ptr %env, i64 80
  %v3240 = load ptr, ptr %v3239, align 8, !tbaa !3
  %v3241 = getelementptr i8, ptr %env, i64 88
  %v3242 = load ptr, ptr %v3241, align 8, !tbaa !3
  %v3243 = getelementptr i8, ptr %env, i64 96
  %v3244 = load ptr, ptr %v3243, align 8, !tbaa !3
  %v3245 = getelementptr i8, ptr %env, i64 104
  %v3246 = load ptr, ptr %v3245, align 8, !tbaa !3
  %v3263 = call ptr @mlf_env_new(i64 2)
  %v3264 = getelementptr i8, ptr %v3263, i64 24
  store ptr %v3232, ptr %v3264, align 8, !tbaa !3
  %v3265 = getelementptr i8, ptr %v3263, i64 32
  store ptr %v3246, ptr %v3265, align 8, !tbaa !3
  %v3266 = call ptr @mlf_thunk(ptr @mlf.code.3247, ptr %v3263)
  %v3615 = call ptr @mlf_env_new(i64 10)
  %v3616 = getelementptr i8, ptr %v3615, i64 24
  store ptr %v3226, ptr %v3616, align 8, !tbaa !3
  %v3617 = getelementptr i8, ptr %v3615, i64 32
  store ptr %v3228, ptr %v3617, align 8, !tbaa !3
  %v3618 = getelementptr i8, ptr %v3615, i64 40
  store ptr %v3230, ptr %v3618, align 8, !tbaa !3
  %v3619 = getelementptr i8, ptr %v3615, i64 48
  store ptr %v3232, ptr %v3619, align 8, !tbaa !3
  %v3620 = getelementptr i8, ptr %v3615, i64 56
  store ptr %v3234, ptr %v3620, align 8, !tbaa !3
  %v3621 = getelementptr i8, ptr %v3615, i64 64
  store ptr %v3236, ptr %v3621, align 8, !tbaa !3
  %v3622 = getelementptr i8, ptr %v3615, i64 72
  store ptr %v3238, ptr %v3622, align 8, !tbaa !3
  %v3623 = getelementptr i8, ptr %v3615, i64 80
  store ptr %v3240, ptr %v3623, align 8, !tbaa !3
  %v3624 = getelementptr i8, ptr %v3615, i64 88
  store ptr %v3242, ptr %v3624, align 8, !tbaa !3
  %v3625 = getelementptr i8, ptr %v3615, i64 96
  store ptr %v3244, ptr %v3625, align 8, !tbaa !3
  %v3626 = call ptr @mlf_closure(ptr @mlf.code.3267, ptr %v3615)
  %v3627 = call ptr @mlf_prim2(i64 1, ptr %v3266, ptr %v3626)
  ret ptr %v3627
}

define private ptr @mlf.code.3183(ptr %env, ptr %arg) {
entry:
  %v3184 = getelementptr i8, ptr %env, i64 24
  %v3185 = load ptr, ptr %v3184, align 8, !tbaa !3
  %v3186 = getelementptr i8, ptr %env, i64 32
  %v3187 = load ptr, ptr %v3186, align 8, !tbaa !3
  %v3188 = getelementptr i8, ptr %env, i64 40
  %v3189 = load ptr, ptr %v3188, align 8, !tbaa !3
  %v3190 = getelementptr i8, ptr %env, i64 48
  %v3191 = load ptr, ptr %v3190, align 8, !tbaa !3
  %v3192 = getelementptr i8, ptr %env, i64 56
  %v3193 = load ptr, ptr %v3192, align 8, !tbaa !3
  %v3194 = getelementptr i8, ptr %env, i64 64
  %v3195 = load ptr, ptr %v3194, align 8, !tbaa !3
  %v3196 = getelementptr i8, ptr %env, i64 72
  %v3197 = load ptr, ptr %v3196, align 8, !tbaa !3
  %v3198 = getelementptr i8, ptr %env, i64 80
  %v3199 = load ptr, ptr %v3198, align 8, !tbaa !3
  %v3200 = getelementptr i8, ptr %env, i64 88
  %v3201 = load ptr, ptr %v3200, align 8, !tbaa !3
  %v3202 = getelementptr i8, ptr %env, i64 96
  %v3203 = load ptr, ptr %v3202, align 8, !tbaa !3
  %v3211 = call ptr @mlf_env_new(i64 1)
  %v3212 = getelementptr i8, ptr %v3211, i64 24
  store ptr %arg, ptr %v3212, align 8, !tbaa !3
  %v3213 = call ptr @mlf_thunk(ptr @mlf.code.3204, ptr %v3211)
  %v3220 = call ptr @mlf_env_new(i64 2)
  %v3221 = getelementptr i8, ptr %v3220, i64 24
  store ptr %v3189, ptr %v3221, align 8, !tbaa !3
  %v3222 = getelementptr i8, ptr %v3220, i64 32
  store ptr %v3213, ptr %v3222, align 8, !tbaa !3
  %v3223 = call ptr @mlf_thunk(ptr @mlf.code.3214, ptr %v3220)
  %v3628 = call ptr @mlf_env_new(i64 11)
  %v3629 = getelementptr i8, ptr %v3628, i64 24
  store ptr %v3185, ptr %v3629, align 8, !tbaa !3
  %v3630 = getelementptr i8, ptr %v3628, i64 32
  store ptr %v3187, ptr %v3630, align 8, !tbaa !3
  %v3631 = getelementptr i8, ptr %v3628, i64 40
  store ptr %v3189, ptr %v3631, align 8, !tbaa !3
  %v3632 = getelementptr i8, ptr %v3628, i64 48
  store ptr %v3191, ptr %v3632, align 8, !tbaa !3
  %v3633 = getelementptr i8, ptr %v3628, i64 56
  store ptr %v3193, ptr %v3633, align 8, !tbaa !3
  %v3634 = getelementptr i8, ptr %v3628, i64 64
  store ptr %v3195, ptr %v3634, align 8, !tbaa !3
  %v3635 = getelementptr i8, ptr %v3628, i64 72
  store ptr %v3197, ptr %v3635, align 8, !tbaa !3
  %v3636 = getelementptr i8, ptr %v3628, i64 80
  store ptr %v3199, ptr %v3636, align 8, !tbaa !3
  %v3637 = getelementptr i8, ptr %v3628, i64 88
  store ptr %v3201, ptr %v3637, align 8, !tbaa !3
  %v3638 = getelementptr i8, ptr %v3628, i64 96
  store ptr %v3203, ptr %v3638, align 8, !tbaa !3
  %v3639 = getelementptr i8, ptr %v3628, i64 104
  store ptr %v3213, ptr %v3639, align 8, !tbaa !3
  %v3640 = call ptr @mlf_closure(ptr @mlf.code.3224, ptr %v3628)
  %v3641 = call ptr @mlf_prim2(i64 1, ptr %v3223, ptr %v3640)
  ret ptr %v3641
}

define private ptr @mlf.worker.40(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6, ptr %a7, ptr %a8, ptr %a9) {
entry:
  %v3094 = call ptr @mlf_prim2(i64 8, ptr %a8, ptr %a9)
  %v3095 = call ptr @mlf_prim2(i64 8, ptr %a7, ptr %v3094)
  %v3096 = call ptr @mlf_prim2(i64 10, ptr %v3095, ptr %v3095)
  %v3097 = icmp eq ptr %v3096, inttoptr (i64 6 to ptr)
  br i1 %v3097, label %yes.3098, label %no.3099
yes.3098:
  %v3101 = call ptr @mlf_prim2(i64 10, ptr %a8, ptr inttoptr (i64 121 to ptr))
  %v3102 = icmp eq ptr %v3101, inttoptr (i64 6 to ptr)
  br i1 %v3102, label %yes.3103, label %no.3104
yes.3103:
  %v3112 = call ptr @mlf_env_new(i64 2)
  %v3113 = getelementptr i8, ptr %v3112, i64 24
  store ptr %a4, ptr %v3113, align 8, !tbaa !3
  %v3114 = getelementptr i8, ptr %v3112, i64 32
  store ptr %a9, ptr %v3114, align 8, !tbaa !3
  %v3115 = call ptr @mlf_thunk(ptr @mlf.code.3106, ptr %v3112)
  %v3150 = call ptr @mlf_env_new(i64 9)
  %v3151 = getelementptr i8, ptr %v3150, i64 24
  store ptr %a0, ptr %v3151, align 8, !tbaa !3
  %v3152 = getelementptr i8, ptr %v3150, i64 32
  store ptr %a1, ptr %v3152, align 8, !tbaa !3
  %v3153 = getelementptr i8, ptr %v3150, i64 40
  store ptr %a2, ptr %v3153, align 8, !tbaa !3
  %v3154 = getelementptr i8, ptr %v3150, i64 48
  store ptr %a3, ptr %v3154, align 8, !tbaa !3
  %v3155 = getelementptr i8, ptr %v3150, i64 56
  store ptr %a4, ptr %v3155, align 8, !tbaa !3
  %v3156 = getelementptr i8, ptr %v3150, i64 64
  store ptr %a5, ptr %v3156, align 8, !tbaa !3
  %v3157 = getelementptr i8, ptr %v3150, i64 72
  store ptr %a6, ptr %v3157, align 8, !tbaa !3
  %v3158 = getelementptr i8, ptr %v3150, i64 80
  store ptr %a7, ptr %v3158, align 8, !tbaa !3
  %v3159 = getelementptr i8, ptr %v3150, i64 88
  store ptr %a9, ptr %v3159, align 8, !tbaa !3
  %v3160 = call ptr @mlf_closure(ptr @mlf.code.3116, ptr %v3150)
  %v3161 = call ptr @mlf_prim2(i64 1, ptr %v3115, ptr %v3160)
  br label %join.3105
no.3104:
  %v3162 = call ptr @mlf_force(ptr %a6)
  %v3163 = call ptr @mlf_prim2(i64 10, ptr %a7, ptr %v3162)
  %v3164 = icmp eq ptr %v3163, inttoptr (i64 6 to ptr)
  br i1 %v3164, label %yes.3165, label %no.3166
yes.3165:
  %v3168 = call ptr @mlf_prim2(i64 10, ptr %a8, ptr inttoptr (i64 1 to ptr))
  %v3169 = icmp eq ptr %v3168, inttoptr (i64 6 to ptr)
  br i1 %v3169, label %yes.3170, label %no.3171
yes.3170:
  %v3173 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.3172
no.3171:
  %v3174 = call ptr @mlf_prim3(i64 37, ptr %a4, ptr %a9, ptr inttoptr (i64 21 to ptr))
  br label %join.3172
join.3172:
  %v3175 = phi ptr [ %v3173, %yes.3170 ], [ %v3174, %no.3171 ]
  br label %join.3167
no.3166:
  %v3180 = call ptr @mlf_env_new(i64 1)
  %v3181 = getelementptr i8, ptr %v3180, i64 24
  store ptr %a2, ptr %v3181, align 8, !tbaa !3
  %v3182 = call ptr @mlf_thunk(ptr @mlf.code.3176, ptr %v3180)
  %v3642 = call ptr @mlf_env_new(i64 10)
  %v3643 = getelementptr i8, ptr %v3642, i64 24
  store ptr %a0, ptr %v3643, align 8, !tbaa !3
  %v3644 = getelementptr i8, ptr %v3642, i64 32
  store ptr %a1, ptr %v3644, align 8, !tbaa !3
  %v3645 = getelementptr i8, ptr %v3642, i64 40
  store ptr %a2, ptr %v3645, align 8, !tbaa !3
  %v3646 = getelementptr i8, ptr %v3642, i64 48
  store ptr %a3, ptr %v3646, align 8, !tbaa !3
  %v3647 = getelementptr i8, ptr %v3642, i64 56
  store ptr %a4, ptr %v3647, align 8, !tbaa !3
  %v3648 = getelementptr i8, ptr %v3642, i64 64
  store ptr %a5, ptr %v3648, align 8, !tbaa !3
  %v3649 = getelementptr i8, ptr %v3642, i64 72
  store ptr %v3162, ptr %v3649, align 8, !tbaa !3
  %v3650 = getelementptr i8, ptr %v3642, i64 80
  store ptr %a7, ptr %v3650, align 8, !tbaa !3
  %v3651 = getelementptr i8, ptr %v3642, i64 88
  store ptr %a8, ptr %v3651, align 8, !tbaa !3
  %v3652 = getelementptr i8, ptr %v3642, i64 96
  store ptr %a9, ptr %v3652, align 8, !tbaa !3
  %v3653 = call ptr @mlf_closure(ptr @mlf.code.3183, ptr %v3642)
  %v3654 = call ptr @mlf_prim2(i64 1, ptr %v3182, ptr %v3653)
  br label %join.3167
join.3167:
  %v3655 = phi ptr [ %v3175, %join.3172 ], [ %v3654, %no.3166 ]
  br label %join.3105
join.3105:
  %v3656 = phi ptr [ %v3161, %yes.3103 ], [ %v3655, %join.3167 ]
  br label %join.3100
no.3099:
  %v3657 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.3100
join.3100:
  %v3658 = phi ptr [ %v3656, %join.3105 ], [ %v3657, %no.3099 ]
  ret ptr %v3658
}

define private ptr @mlf.numeric.entry.3038(ptr %env, ptr %arg) {
entry:
  %v3039 = getelementptr i8, ptr %env, i64 24
  %v3040 = load ptr, ptr %v3039, align 8, !tbaa !3
  %v3041 = getelementptr i8, ptr %env, i64 32
  %v3042 = load ptr, ptr %v3041, align 8, !tbaa !3
  %v3043 = getelementptr i8, ptr %env, i64 40
  %v3044 = load ptr, ptr %v3043, align 8, !tbaa !3
  %v3045 = getelementptr i8, ptr %env, i64 48
  %v3046 = load ptr, ptr %v3045, align 8, !tbaa !3
  %v3047 = getelementptr i8, ptr %env, i64 56
  %v3048 = load ptr, ptr %v3047, align 8, !tbaa !3
  %v3049 = getelementptr i8, ptr %env, i64 64
  %v3050 = load ptr, ptr %v3049, align 8, !tbaa !3
  %v3051 = getelementptr i8, ptr %env, i64 72
  %v3052 = load ptr, ptr %v3051, align 8, !tbaa !3
  %v3053 = getelementptr i8, ptr %env, i64 80
  %v3054 = load ptr, ptr %v3053, align 8, !tbaa !3
  %v3055 = getelementptr i8, ptr %env, i64 88
  %v3056 = load ptr, ptr %v3055, align 8, !tbaa !3
  %v3057 = getelementptr i8, ptr %env, i64 96
  %v3058 = load ptr, ptr %v3057, align 8, !tbaa !3
  %v3059 = call ptr @mlf_peek(ptr %v3040)
  %v3060 = call ptr @mlf_peek(ptr %v3042)
  %v3061 = call ptr @mlf_peek(ptr %v3044)
  %v3062 = call ptr @mlf_peek(ptr %v3046)
  %v3063 = call ptr @mlf_peek(ptr %v3048)
  %v3064 = call ptr @mlf_peek(ptr %v3050)
  %v3065 = call ptr @mlf_peek(ptr %v3052)
  %v3066 = call ptr @mlf_peek(ptr %v3054)
  %v3067 = call ptr @mlf_peek(ptr %v3056)
  %v3068 = call ptr @mlf_peek(ptr %v3058)
  %v3069 = icmp ne ptr %v3059, null
  %v3070 = icmp ne ptr %v3060, null
  %v3071 = icmp ne ptr %v3061, null
  %v3072 = icmp ne ptr %v3062, null
  %v3073 = icmp ne ptr %v3063, null
  %v3074 = icmp ne ptr %v3064, null
  %v3075 = icmp ne ptr %v3065, null
  %v3076 = icmp ne ptr %v3066, null
  %v3077 = icmp ne ptr %v3067, null
  %v3078 = icmp ne ptr %v3068, null
  %v3079 = and i1 true, %v3069
  %v3080 = and i1 %v3079, %v3070
  %v3081 = and i1 %v3080, %v3071
  %v3082 = and i1 %v3081, %v3072
  %v3083 = and i1 %v3082, %v3073
  %v3084 = and i1 %v3083, %v3074
  %v3085 = and i1 %v3084, %v3075
  %v3086 = and i1 %v3085, %v3076
  %v3087 = and i1 %v3086, %v3077
  %v3088 = and i1 %v3087, %v3078
  br i1 %v3088, label %yes.3089, label %no.3090
yes.3089:
  %v3092 = call ptr @mlf.numeric.40(ptr %v3059, ptr %v3060, ptr %v3061, ptr %v3062, ptr %v3063, ptr %v3064, ptr %v3065, ptr %v3066, ptr %v3067, ptr %v3068)
  %v3093 = call ptr @mlf_prim1(i64 0, ptr %v3092)
  br label %join.3091
no.3090:
  %v3659 = call ptr @mlf_force(ptr %v3054)
  %v3660 = call ptr @mlf_force(ptr %v3056)
  %v3661 = call ptr @mlf_force(ptr %v3058)
  %v3662 = call ptr @mlf.worker.40(ptr %v3040, ptr %v3042, ptr %v3044, ptr %v3046, ptr %v3048, ptr %v3050, ptr %v3052, ptr %v3659, ptr %v3660, ptr %v3661)
  br label %join.3091
join.3091:
  %v3663 = phi ptr [ %v3093, %yes.3089 ], [ %v3662, %no.3090 ]
  ret ptr %v3663
}

define private ptr @mlf.code.3023(ptr %env, ptr %arg) {
entry:
  %v3024 = getelementptr i8, ptr %env, i64 24
  %v3025 = load ptr, ptr %v3024, align 8, !tbaa !3
  %v3026 = getelementptr i8, ptr %env, i64 32
  %v3027 = load ptr, ptr %v3026, align 8, !tbaa !3
  %v3028 = getelementptr i8, ptr %env, i64 40
  %v3029 = load ptr, ptr %v3028, align 8, !tbaa !3
  %v3030 = getelementptr i8, ptr %env, i64 48
  %v3031 = load ptr, ptr %v3030, align 8, !tbaa !3
  %v3032 = getelementptr i8, ptr %env, i64 56
  %v3033 = load ptr, ptr %v3032, align 8, !tbaa !3
  %v3034 = getelementptr i8, ptr %env, i64 64
  %v3035 = load ptr, ptr %v3034, align 8, !tbaa !3
  %v3036 = getelementptr i8, ptr %env, i64 72
  %v3037 = load ptr, ptr %v3036, align 8, !tbaa !3
  %v3664 = call ptr @mlf_env_new(i64 10)
  %v3665 = getelementptr i8, ptr %v3664, i64 24
  store ptr %v3025, ptr %v3665, align 8, !tbaa !3
  %v3666 = getelementptr i8, ptr %v3664, i64 32
  store ptr %v3027, ptr %v3666, align 8, !tbaa !3
  %v3667 = getelementptr i8, ptr %v3664, i64 40
  store ptr %v3029, ptr %v3667, align 8, !tbaa !3
  %v3668 = getelementptr i8, ptr %v3664, i64 48
  store ptr %v3031, ptr %v3668, align 8, !tbaa !3
  %v3669 = getelementptr i8, ptr %v3664, i64 56
  store ptr %v3033, ptr %v3669, align 8, !tbaa !3
  %v3670 = getelementptr i8, ptr %v3664, i64 64
  store ptr %v3035, ptr %v3670, align 8, !tbaa !3
  %v3671 = getelementptr i8, ptr %v3664, i64 72
  store ptr %v3037, ptr %v3671, align 8, !tbaa !3
  %v3672 = getelementptr i8, ptr %v3664, i64 80
  store ptr inttoptr (i64 1 to ptr), ptr %v3672, align 8, !tbaa !3
  %v3673 = getelementptr i8, ptr %v3664, i64 88
  store ptr inttoptr (i64 1 to ptr), ptr %v3673, align 8, !tbaa !3
  %v3674 = getelementptr i8, ptr %v3664, i64 96
  store ptr inttoptr (i64 1 to ptr), ptr %v3674, align 8, !tbaa !3
  %v3675 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.3038, ptr %v3664)
  ret ptr %v3675
}

define private ptr @mlf.code.3707(ptr %env, ptr %arg) {
entry:
  %v3708 = getelementptr i8, ptr %env, i64 24
  %v3709 = load ptr, ptr %v3708, align 8, !tbaa !3
  %v3710 = call ptr @mlf_force(ptr %v3709)
  %v3711 = call ptr @mlf_prim2(i64 8, ptr %v3710, ptr inttoptr (i64 119 to ptr))
  %v3712 = call ptr @mlf_prim2(i64 15, ptr %v3711, ptr inttoptr (i64 121 to ptr))
  %v3713 = call ptr @mlf_prim2(i64 8, ptr %v3710, ptr %v3712)
  ret ptr %v3713
}

define private ptr @mlf.code.3702(ptr %env, ptr %arg) {
entry:
  %v3703 = getelementptr i8, ptr %env, i64 24
  %v3704 = load ptr, ptr %v3703, align 8, !tbaa !3
  %v3705 = getelementptr i8, ptr %env, i64 32
  %v3706 = load ptr, ptr %v3705, align 8, !tbaa !3
  %v3714 = call ptr @mlf_env_new(i64 1)
  %v3715 = getelementptr i8, ptr %v3714, i64 24
  store ptr %v3706, ptr %v3715, align 8, !tbaa !3
  %v3716 = call ptr @mlf_thunk(ptr @mlf.code.3707, ptr %v3714)
  %v3717 = call ptr @mlf_prim3(i64 40, ptr %v3704, ptr inttoptr (i64 1 to ptr), ptr %v3716)
  ret ptr %v3717
}

define private ptr @mlf.code.3722(ptr %env, ptr %arg) {
entry:
  %v3723 = getelementptr i8, ptr %env, i64 24
  %v3724 = load ptr, ptr %v3723, align 8, !tbaa !3
  %v3725 = getelementptr i8, ptr %env, i64 32
  %v3726 = load ptr, ptr %v3725, align 8, !tbaa !3
  %v3727 = getelementptr i8, ptr %env, i64 40
  %v3728 = load ptr, ptr %v3727, align 8, !tbaa !3
  %v3729 = getelementptr i8, ptr %env, i64 48
  %v3730 = load ptr, ptr %v3729, align 8, !tbaa !3
  %v3731 = getelementptr i8, ptr %env, i64 56
  %v3732 = load ptr, ptr %v3731, align 8, !tbaa !3
  %v3733 = getelementptr i8, ptr %env, i64 64
  %v3734 = load ptr, ptr %v3733, align 8, !tbaa !3
  %v3735 = getelementptr i8, ptr %env, i64 72
  %v3736 = load ptr, ptr %v3735, align 8, !tbaa !3
  %v3737 = getelementptr i8, ptr %env, i64 80
  %v3738 = load ptr, ptr %v3737, align 8, !tbaa !3
  %v3739 = call ptr @mlf_force(ptr %v3736)
  %v3740 = call ptr @mlf_force(ptr %v3738)
  %v3741 = call ptr @mlf_prim2(i64 9, ptr %v3739, ptr %v3740)
  %v3742 = call ptr @mlf_env_new(i64 7)
  %v3743 = getelementptr i8, ptr %v3742, i64 24
  store ptr %v3724, ptr %v3743, align 8, !tbaa !3
  %v3744 = getelementptr i8, ptr %v3742, i64 32
  store ptr %v3726, ptr %v3744, align 8, !tbaa !3
  %v3745 = getelementptr i8, ptr %v3742, i64 40
  store ptr %v3728, ptr %v3745, align 8, !tbaa !3
  %v3746 = getelementptr i8, ptr %v3742, i64 48
  store ptr %v3730, ptr %v3746, align 8, !tbaa !3
  %v3747 = getelementptr i8, ptr %v3742, i64 56
  store ptr %v3732, ptr %v3747, align 8, !tbaa !3
  %v3748 = getelementptr i8, ptr %v3742, i64 64
  store ptr %v3734, ptr %v3748, align 8, !tbaa !3
  %v3749 = getelementptr i8, ptr %v3742, i64 72
  store ptr %v3741, ptr %v3749, align 8, !tbaa !3
  %v3750 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1944, ptr %v3742)
  ret ptr %v3750
}

define private ptr @mlf.code.3685(ptr %env, ptr %arg) {
entry:
  %v3686 = getelementptr i8, ptr %env, i64 24
  %v3687 = load ptr, ptr %v3686, align 8, !tbaa !3
  %v3688 = getelementptr i8, ptr %env, i64 32
  %v3689 = load ptr, ptr %v3688, align 8, !tbaa !3
  %v3690 = getelementptr i8, ptr %env, i64 40
  %v3691 = load ptr, ptr %v3690, align 8, !tbaa !3
  %v3692 = getelementptr i8, ptr %env, i64 48
  %v3693 = load ptr, ptr %v3692, align 8, !tbaa !3
  %v3694 = getelementptr i8, ptr %env, i64 56
  %v3695 = load ptr, ptr %v3694, align 8, !tbaa !3
  %v3696 = getelementptr i8, ptr %env, i64 64
  %v3697 = load ptr, ptr %v3696, align 8, !tbaa !3
  %v3698 = getelementptr i8, ptr %env, i64 72
  %v3699 = load ptr, ptr %v3698, align 8, !tbaa !3
  %v3700 = getelementptr i8, ptr %env, i64 80
  %v3701 = load ptr, ptr %v3700, align 8, !tbaa !3
  %v3718 = call ptr @mlf_env_new(i64 2)
  %v3719 = getelementptr i8, ptr %v3718, i64 24
  store ptr %v3695, ptr %v3719, align 8, !tbaa !3
  %v3720 = getelementptr i8, ptr %v3718, i64 32
  store ptr %v3701, ptr %v3720, align 8, !tbaa !3
  %v3721 = call ptr @mlf_thunk(ptr @mlf.code.3702, ptr %v3718)
  %v3751 = call ptr @mlf_env_new(i64 8)
  %v3752 = getelementptr i8, ptr %v3751, i64 24
  store ptr %v3687, ptr %v3752, align 8, !tbaa !3
  %v3753 = getelementptr i8, ptr %v3751, i64 32
  store ptr %v3689, ptr %v3753, align 8, !tbaa !3
  %v3754 = getelementptr i8, ptr %v3751, i64 40
  store ptr %v3691, ptr %v3754, align 8, !tbaa !3
  %v3755 = getelementptr i8, ptr %v3751, i64 48
  store ptr %v3693, ptr %v3755, align 8, !tbaa !3
  %v3756 = getelementptr i8, ptr %v3751, i64 56
  store ptr %v3695, ptr %v3756, align 8, !tbaa !3
  %v3757 = getelementptr i8, ptr %v3751, i64 64
  store ptr %v3697, ptr %v3757, align 8, !tbaa !3
  %v3758 = getelementptr i8, ptr %v3751, i64 72
  store ptr %v3699, ptr %v3758, align 8, !tbaa !3
  %v3759 = getelementptr i8, ptr %v3751, i64 80
  store ptr %v3701, ptr %v3759, align 8, !tbaa !3
  %v3760 = call ptr @mlf_closure(ptr @mlf.code.3722, ptr %v3751)
  %v3761 = call ptr @mlf_prim2(i64 1, ptr %v3721, ptr %v3760)
  ret ptr %v3761
}

define private ptr @mlf.worker.61(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6) {
entry:
  %v3004 = call ptr @mlf_prim2(i64 10, ptr %a6, ptr inttoptr (i64 1 to ptr))
  %v3005 = icmp eq ptr %v3004, inttoptr (i64 6 to ptr)
  br i1 %v3005, label %yes.3006, label %no.3007
yes.3006:
  %v3009 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.3008
no.3007:
  %v3020 = call ptr @mlf_env_new(i64 1)
  %v3021 = getelementptr i8, ptr %v3020, i64 24
  store ptr %a6, ptr %v3021, align 8, !tbaa !3
  %v3022 = call ptr @mlf_thunk(ptr @mlf.code.3010, ptr %v3020)
  %v3676 = call ptr @mlf_env_new(i64 7)
  %v3677 = getelementptr i8, ptr %v3676, i64 24
  store ptr %a0, ptr %v3677, align 8, !tbaa !3
  %v3678 = getelementptr i8, ptr %v3676, i64 32
  store ptr %a1, ptr %v3678, align 8, !tbaa !3
  %v3679 = getelementptr i8, ptr %v3676, i64 40
  store ptr %a2, ptr %v3679, align 8, !tbaa !3
  %v3680 = getelementptr i8, ptr %v3676, i64 48
  store ptr %a3, ptr %v3680, align 8, !tbaa !3
  %v3681 = getelementptr i8, ptr %v3676, i64 56
  store ptr %a4, ptr %v3681, align 8, !tbaa !3
  %v3682 = getelementptr i8, ptr %v3676, i64 64
  store ptr %a5, ptr %v3682, align 8, !tbaa !3
  %v3683 = getelementptr i8, ptr %v3676, i64 72
  store ptr %v3022, ptr %v3683, align 8, !tbaa !3
  %v3684 = call ptr @mlf_thunk(ptr @mlf.code.3023, ptr %v3676)
  %v3762 = call ptr @mlf_env_new(i64 8)
  %v3763 = getelementptr i8, ptr %v3762, i64 24
  store ptr %a0, ptr %v3763, align 8, !tbaa !3
  %v3764 = getelementptr i8, ptr %v3762, i64 32
  store ptr %a1, ptr %v3764, align 8, !tbaa !3
  %v3765 = getelementptr i8, ptr %v3762, i64 40
  store ptr %a2, ptr %v3765, align 8, !tbaa !3
  %v3766 = getelementptr i8, ptr %v3762, i64 48
  store ptr %a3, ptr %v3766, align 8, !tbaa !3
  %v3767 = getelementptr i8, ptr %v3762, i64 56
  store ptr %a4, ptr %v3767, align 8, !tbaa !3
  %v3768 = getelementptr i8, ptr %v3762, i64 64
  store ptr %a5, ptr %v3768, align 8, !tbaa !3
  %v3769 = getelementptr i8, ptr %v3762, i64 72
  store ptr %a6, ptr %v3769, align 8, !tbaa !3
  %v3770 = getelementptr i8, ptr %v3762, i64 80
  store ptr %v3022, ptr %v3770, align 8, !tbaa !3
  %v3771 = call ptr @mlf_closure(ptr @mlf.code.3685, ptr %v3762)
  %v3772 = call ptr @mlf_prim2(i64 1, ptr %v3684, ptr %v3771)
  br label %join.3008
join.3008:
  %v3773 = phi ptr [ %v3009, %yes.3006 ], [ %v3772, %no.3007 ]
  ret ptr %v3773
}

define private ptr @mlf.numeric.entry.1944(ptr %env, ptr %arg) {
entry:
  %v1945 = getelementptr i8, ptr %env, i64 24
  %v1946 = load ptr, ptr %v1945, align 8, !tbaa !3
  %v1947 = getelementptr i8, ptr %env, i64 32
  %v1948 = load ptr, ptr %v1947, align 8, !tbaa !3
  %v1949 = getelementptr i8, ptr %env, i64 40
  %v1950 = load ptr, ptr %v1949, align 8, !tbaa !3
  %v1951 = getelementptr i8, ptr %env, i64 48
  %v1952 = load ptr, ptr %v1951, align 8, !tbaa !3
  %v1953 = getelementptr i8, ptr %env, i64 56
  %v1954 = load ptr, ptr %v1953, align 8, !tbaa !3
  %v1955 = getelementptr i8, ptr %env, i64 64
  %v1956 = load ptr, ptr %v1955, align 8, !tbaa !3
  %v1957 = getelementptr i8, ptr %env, i64 72
  %v1958 = load ptr, ptr %v1957, align 8, !tbaa !3
  %v1959 = call ptr @mlf_peek(ptr %v1946)
  %v1960 = call ptr @mlf_peek(ptr %v1948)
  %v1961 = call ptr @mlf_peek(ptr %v1950)
  %v1962 = call ptr @mlf_peek(ptr %v1952)
  %v1963 = call ptr @mlf_peek(ptr %v1954)
  %v1964 = call ptr @mlf_peek(ptr %v1956)
  %v1965 = call ptr @mlf_peek(ptr %v1958)
  %v1966 = icmp ne ptr %v1959, null
  %v1967 = icmp ne ptr %v1960, null
  %v1968 = icmp ne ptr %v1961, null
  %v1969 = icmp ne ptr %v1962, null
  %v1970 = icmp ne ptr %v1963, null
  %v1971 = icmp ne ptr %v1964, null
  %v1972 = icmp ne ptr %v1965, null
  %v1973 = and i1 true, %v1966
  %v1974 = and i1 %v1973, %v1967
  %v1975 = and i1 %v1974, %v1968
  %v1976 = and i1 %v1975, %v1969
  %v1977 = and i1 %v1976, %v1970
  %v1978 = and i1 %v1977, %v1971
  %v1979 = and i1 %v1978, %v1972
  br i1 %v1979, label %yes.1980, label %no.1981
yes.1980:
  %v3002 = call ptr @mlf.numeric.61(ptr %v1959, ptr %v1960, ptr %v1961, ptr %v1962, ptr %v1963, ptr %v1964, ptr %v1965)
  %v3003 = call ptr @mlf_prim1(i64 0, ptr %v3002)
  br label %join.1982
no.1981:
  %v3774 = call ptr @mlf_force(ptr %v1958)
  %v3775 = call ptr @mlf.worker.61(ptr %v1946, ptr %v1948, ptr %v1950, ptr %v1952, ptr %v1954, ptr %v1956, ptr %v3774)
  br label %join.1982
join.1982:
  %v3776 = phi ptr [ %v3003, %yes.1980 ], [ %v3775, %no.1981 ]
  ret ptr %v3776
}

define private ptr @mlf.code.1931(ptr %env, ptr %arg) {
entry:
  %v1932 = getelementptr i8, ptr %env, i64 24
  %v1933 = load ptr, ptr %v1932, align 8, !tbaa !3
  %v1934 = getelementptr i8, ptr %env, i64 32
  %v1935 = load ptr, ptr %v1934, align 8, !tbaa !3
  %v1936 = getelementptr i8, ptr %env, i64 40
  %v1937 = load ptr, ptr %v1936, align 8, !tbaa !3
  %v1938 = getelementptr i8, ptr %env, i64 48
  %v1939 = load ptr, ptr %v1938, align 8, !tbaa !3
  %v1940 = getelementptr i8, ptr %env, i64 56
  %v1941 = load ptr, ptr %v1940, align 8, !tbaa !3
  %v1942 = getelementptr i8, ptr %env, i64 64
  %v1943 = load ptr, ptr %v1942, align 8, !tbaa !3
  %v3777 = call ptr @mlf_force(ptr %v1933)
  %v3778 = ptrtoint ptr %v3777 to i64
  %v3779 = ptrtoint ptr inttoptr (i64 7 to ptr) to i64
  %v3780 = and i64 %v3778, %v3779
  %v3781 = and i64 %v3780, 1
  %v3782 = icmp ne i64 %v3781, 0
  br i1 %v3782, label %yes.3783, label %no.3784
yes.3783:
  %v3786 = ashr i64 %v3778, 1
  %v3787 = ashr i64 %v3779, 1
  %v3788 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v3786, i64 %v3787)
  %v3789 = extractvalue { i64, i1 } %v3788, 0
  %v3790 = extractvalue { i64, i1 } %v3788, 1
  %v3791 = xor i1 %v3790, true
  %v3792 = icmp sge i64 %v3789, -4611686018427387904
  %v3793 = icmp sle i64 %v3789, 4611686018427387903
  %v3794 = and i1 %v3792, %v3793
  %v3795 = and i1 %v3794, %v3791
  br i1 %v3795, label %yes.3796, label %no.3797
yes.3796:
  %v3799 = shl i64 %v3789, 1
  %v3800 = or i64 %v3799, 1
  %v3801 = inttoptr i64 %v3800 to ptr
  br label %join.3798
no.3797:
  %v3802 = call ptr @mlf_prim2(i64 14, ptr %v3777, ptr inttoptr (i64 7 to ptr))
  br label %join.3798
join.3798:
  %v3803 = phi ptr [ %v3801, %yes.3796 ], [ %v3802, %no.3797 ]
  br label %join.3785
no.3784:
  %v3804 = call ptr @mlf_prim2(i64 14, ptr %v3777, ptr inttoptr (i64 7 to ptr))
  br label %join.3785
join.3785:
  %v3805 = phi ptr [ %v3803, %join.3798 ], [ %v3804, %no.3784 ]
  %v3806 = call ptr @mlf_env_new(i64 7)
  %v3807 = getelementptr i8, ptr %v3806, i64 24
  store ptr %v1935, ptr %v3807, align 8, !tbaa !3
  %v3808 = getelementptr i8, ptr %v3806, i64 32
  store ptr %v1937, ptr %v3808, align 8, !tbaa !3
  %v3809 = getelementptr i8, ptr %v3806, i64 40
  store ptr %v1941, ptr %v3809, align 8, !tbaa !3
  %v3810 = getelementptr i8, ptr %v3806, i64 48
  store ptr %v1943, ptr %v3810, align 8, !tbaa !3
  %v3811 = getelementptr i8, ptr %v3806, i64 56
  store ptr %v1939, ptr %v3811, align 8, !tbaa !3
  %v3812 = getelementptr i8, ptr %v3806, i64 64
  store ptr inttoptr (i64 31 to ptr), ptr %v3812, align 8, !tbaa !3
  %v3813 = getelementptr i8, ptr %v3806, i64 72
  store ptr %v3805, ptr %v3813, align 8, !tbaa !3
  %v3814 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1944, ptr %v3806)
  ret ptr %v3814
}

define private ptr @mlf.code.3836(ptr %env, ptr %arg) {
entry:
  %v3838 = call ptr @mlf_string(ptr @mlf.bytes.3837, i64 29)
  %v3839 = call ptr @mlf_prim1(i64 3, ptr %v3838)
  ret ptr %v3839
}

define private ptr @mlf.code.3841(ptr %env, ptr %arg) {
entry:
  %v3842 = getelementptr i8, ptr %env, i64 24
  %v3843 = load ptr, ptr %v3842, align 8, !tbaa !3
  %v3844 = getelementptr i8, ptr %env, i64 32
  %v3845 = load ptr, ptr %v3844, align 8, !tbaa !3
  %v3846 = getelementptr i8, ptr %env, i64 40
  %v3847 = load ptr, ptr %v3846, align 8, !tbaa !3
  %v3848 = getelementptr i8, ptr %env, i64 48
  %v3849 = load ptr, ptr %v3848, align 8, !tbaa !3
  %v3850 = getelementptr i8, ptr %env, i64 56
  %v3851 = load ptr, ptr %v3850, align 8, !tbaa !3
  %v3852 = getelementptr i8, ptr %env, i64 64
  %v3853 = load ptr, ptr %v3852, align 8, !tbaa !3
  %v3854 = call ptr @mlf_force(ptr %v3843)
  %v3855 = ptrtoint ptr %v3854 to i64
  %v3856 = ptrtoint ptr inttoptr (i64 11 to ptr) to i64
  %v3857 = and i64 %v3855, %v3856
  %v3858 = and i64 %v3857, 1
  %v3859 = icmp ne i64 %v3858, 0
  br i1 %v3859, label %yes.3860, label %no.3861
yes.3860:
  %v3863 = ashr i64 %v3855, 1
  %v3864 = ashr i64 %v3856, 1
  %v3865 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v3863, i64 %v3864)
  %v3866 = extractvalue { i64, i1 } %v3865, 0
  %v3867 = extractvalue { i64, i1 } %v3865, 1
  %v3868 = xor i1 %v3867, true
  %v3869 = icmp sge i64 %v3866, -4611686018427387904
  %v3870 = icmp sle i64 %v3866, 4611686018427387903
  %v3871 = and i1 %v3869, %v3870
  %v3872 = and i1 %v3871, %v3868
  br i1 %v3872, label %yes.3873, label %no.3874
yes.3873:
  %v3876 = shl i64 %v3866, 1
  %v3877 = or i64 %v3876, 1
  %v3878 = inttoptr i64 %v3877 to ptr
  br label %join.3875
no.3874:
  %v3879 = call ptr @mlf_prim2(i64 14, ptr %v3854, ptr inttoptr (i64 11 to ptr))
  br label %join.3875
join.3875:
  %v3880 = phi ptr [ %v3878, %yes.3873 ], [ %v3879, %no.3874 ]
  br label %join.3862
no.3861:
  %v3881 = call ptr @mlf_prim2(i64 14, ptr %v3854, ptr inttoptr (i64 11 to ptr))
  br label %join.3862
join.3862:
  %v3882 = phi ptr [ %v3880, %join.3875 ], [ %v3881, %no.3861 ]
  %v3883 = call ptr @mlf_env_new(i64 7)
  %v3884 = getelementptr i8, ptr %v3883, i64 24
  store ptr %v3845, ptr %v3884, align 8, !tbaa !3
  %v3885 = getelementptr i8, ptr %v3883, i64 32
  store ptr %v3847, ptr %v3885, align 8, !tbaa !3
  %v3886 = getelementptr i8, ptr %v3883, i64 40
  store ptr %v3851, ptr %v3886, align 8, !tbaa !3
  %v3887 = getelementptr i8, ptr %v3883, i64 48
  store ptr %v3853, ptr %v3887, align 8, !tbaa !3
  %v3888 = getelementptr i8, ptr %v3883, i64 56
  store ptr %v3849, ptr %v3888, align 8, !tbaa !3
  %v3889 = getelementptr i8, ptr %v3883, i64 64
  store ptr inttoptr (i64 9 to ptr), ptr %v3889, align 8, !tbaa !3
  %v3890 = getelementptr i8, ptr %v3883, i64 72
  store ptr %v3882, ptr %v3890, align 8, !tbaa !3
  %v3891 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1944, ptr %v3883)
  ret ptr %v3891
}

define private ptr @mlf.code.3823(ptr %env, ptr %arg) {
entry:
  %v3824 = getelementptr i8, ptr %env, i64 24
  %v3825 = load ptr, ptr %v3824, align 8, !tbaa !3
  %v3826 = getelementptr i8, ptr %env, i64 32
  %v3827 = load ptr, ptr %v3826, align 8, !tbaa !3
  %v3828 = getelementptr i8, ptr %env, i64 40
  %v3829 = load ptr, ptr %v3828, align 8, !tbaa !3
  %v3830 = getelementptr i8, ptr %env, i64 48
  %v3831 = load ptr, ptr %v3830, align 8, !tbaa !3
  %v3832 = getelementptr i8, ptr %env, i64 56
  %v3833 = load ptr, ptr %v3832, align 8, !tbaa !3
  %v3834 = getelementptr i8, ptr %env, i64 64
  %v3835 = load ptr, ptr %v3834, align 8, !tbaa !3
  %v3840 = call ptr @mlf_thunk(ptr @mlf.code.3836, ptr null)
  %v3892 = call ptr @mlf_env_new(i64 6)
  %v3893 = getelementptr i8, ptr %v3892, i64 24
  store ptr %v3825, ptr %v3893, align 8, !tbaa !3
  %v3894 = getelementptr i8, ptr %v3892, i64 32
  store ptr %v3827, ptr %v3894, align 8, !tbaa !3
  %v3895 = getelementptr i8, ptr %v3892, i64 40
  store ptr %v3829, ptr %v3895, align 8, !tbaa !3
  %v3896 = getelementptr i8, ptr %v3892, i64 48
  store ptr %v3831, ptr %v3896, align 8, !tbaa !3
  %v3897 = getelementptr i8, ptr %v3892, i64 56
  store ptr %v3833, ptr %v3897, align 8, !tbaa !3
  %v3898 = getelementptr i8, ptr %v3892, i64 64
  store ptr %v3835, ptr %v3898, align 8, !tbaa !3
  %v3899 = call ptr @mlf_closure(ptr @mlf.code.3841, ptr %v3892)
  %v3900 = call ptr @mlf_prim2(i64 1, ptr %v3840, ptr %v3899)
  ret ptr %v3900
}

define private ptr @mlf.code.1914(ptr %env, ptr %arg) {
entry:
  %v1915 = getelementptr i8, ptr %env, i64 24
  %v1916 = load ptr, ptr %v1915, align 8, !tbaa !3
  %v1917 = getelementptr i8, ptr %env, i64 32
  %v1918 = load ptr, ptr %v1917, align 8, !tbaa !3
  %v1919 = getelementptr i8, ptr %env, i64 40
  %v1920 = load ptr, ptr %v1919, align 8, !tbaa !3
  %v1921 = getelementptr i8, ptr %env, i64 48
  %v1922 = load ptr, ptr %v1921, align 8, !tbaa !3
  %v1923 = getelementptr i8, ptr %env, i64 56
  %v1924 = load ptr, ptr %v1923, align 8, !tbaa !3
  %v1925 = getelementptr i8, ptr %env, i64 64
  %v1926 = load ptr, ptr %v1925, align 8, !tbaa !3
  %v1927 = getelementptr i8, ptr %env, i64 72
  %v1928 = load ptr, ptr %v1927, align 8, !tbaa !3
  %v1929 = getelementptr i8, ptr %env, i64 80
  %v1930 = load ptr, ptr %v1929, align 8, !tbaa !3
  %v3815 = call ptr @mlf_env_new(i64 6)
  %v3816 = getelementptr i8, ptr %v3815, i64 24
  store ptr %v1916, ptr %v3816, align 8, !tbaa !3
  %v3817 = getelementptr i8, ptr %v3815, i64 32
  store ptr %v1918, ptr %v3817, align 8, !tbaa !3
  %v3818 = getelementptr i8, ptr %v3815, i64 40
  store ptr %v1922, ptr %v3818, align 8, !tbaa !3
  %v3819 = getelementptr i8, ptr %v3815, i64 48
  store ptr %v1926, ptr %v3819, align 8, !tbaa !3
  %v3820 = getelementptr i8, ptr %v3815, i64 56
  store ptr %v1928, ptr %v3820, align 8, !tbaa !3
  %v3821 = getelementptr i8, ptr %v3815, i64 64
  store ptr %v1930, ptr %v3821, align 8, !tbaa !3
  %v3822 = call ptr @mlf_thunk(ptr @mlf.code.1931, ptr %v3815)
  %v3901 = call ptr @mlf_env_new(i64 6)
  %v3902 = getelementptr i8, ptr %v3901, i64 24
  store ptr %v1916, ptr %v3902, align 8, !tbaa !3
  %v3903 = getelementptr i8, ptr %v3901, i64 32
  store ptr %v1920, ptr %v3903, align 8, !tbaa !3
  %v3904 = getelementptr i8, ptr %v3901, i64 40
  store ptr %v1924, ptr %v3904, align 8, !tbaa !3
  %v3905 = getelementptr i8, ptr %v3901, i64 48
  store ptr %v1926, ptr %v3905, align 8, !tbaa !3
  %v3906 = getelementptr i8, ptr %v3901, i64 56
  store ptr %v1928, ptr %v3906, align 8, !tbaa !3
  %v3907 = getelementptr i8, ptr %v3901, i64 64
  store ptr %v1930, ptr %v3907, align 8, !tbaa !3
  %v3908 = call ptr @mlf_closure(ptr @mlf.code.3823, ptr %v3901)
  %v3909 = call ptr @mlf_prim2(i64 1, ptr %v3822, ptr %v3908)
  ret ptr %v3909
}

define private ptr @mlf.code.1892(ptr %env, ptr %arg) {
entry:
  %v1893 = getelementptr i8, ptr %env, i64 24
  %v1894 = load ptr, ptr %v1893, align 8, !tbaa !3
  %v1895 = getelementptr i8, ptr %env, i64 32
  %v1896 = load ptr, ptr %v1895, align 8, !tbaa !3
  %v1897 = getelementptr i8, ptr %env, i64 40
  %v1898 = load ptr, ptr %v1897, align 8, !tbaa !3
  %v1899 = getelementptr i8, ptr %env, i64 48
  %v1900 = load ptr, ptr %v1899, align 8, !tbaa !3
  %v1901 = getelementptr i8, ptr %env, i64 56
  %v1902 = load ptr, ptr %v1901, align 8, !tbaa !3
  %v1903 = getelementptr i8, ptr %env, i64 64
  %v1904 = load ptr, ptr %v1903, align 8, !tbaa !3
  %v1905 = getelementptr i8, ptr %env, i64 72
  %v1906 = load ptr, ptr %v1905, align 8, !tbaa !3
  %v1907 = getelementptr i8, ptr %env, i64 80
  %v1908 = load ptr, ptr %v1907, align 8, !tbaa !3
  %v1913 = call ptr @mlf_thunk(ptr @mlf.code.1909, ptr null)
  %v3910 = call ptr @mlf_env_new(i64 8)
  %v3911 = getelementptr i8, ptr %v3910, i64 24
  store ptr %v1894, ptr %v3911, align 8, !tbaa !3
  %v3912 = getelementptr i8, ptr %v3910, i64 32
  store ptr %v1896, ptr %v3912, align 8, !tbaa !3
  %v3913 = getelementptr i8, ptr %v3910, i64 40
  store ptr %v1898, ptr %v3913, align 8, !tbaa !3
  %v3914 = getelementptr i8, ptr %v3910, i64 48
  store ptr %v1900, ptr %v3914, align 8, !tbaa !3
  %v3915 = getelementptr i8, ptr %v3910, i64 56
  store ptr %v1902, ptr %v3915, align 8, !tbaa !3
  %v3916 = getelementptr i8, ptr %v3910, i64 64
  store ptr %v1904, ptr %v3916, align 8, !tbaa !3
  %v3917 = getelementptr i8, ptr %v3910, i64 72
  store ptr %v1906, ptr %v3917, align 8, !tbaa !3
  %v3918 = getelementptr i8, ptr %v3910, i64 80
  store ptr %v1908, ptr %v3918, align 8, !tbaa !3
  %v3919 = call ptr @mlf_closure(ptr @mlf.code.1914, ptr %v3910)
  %v3920 = call ptr @mlf_prim2(i64 1, ptr %v1913, ptr %v3919)
  ret ptr %v3920
}

define private ptr @mlf.code.576(ptr %env, ptr %arg) {
entry:
  %v577 = getelementptr i8, ptr %env, i64 24
  %v578 = load ptr, ptr %v577, align 8, !tbaa !3
  %v579 = getelementptr i8, ptr %env, i64 32
  %v580 = load ptr, ptr %v579, align 8, !tbaa !3
  %v581 = getelementptr i8, ptr %env, i64 40
  %v582 = load ptr, ptr %v581, align 8, !tbaa !3
  %v583 = getelementptr i8, ptr %env, i64 48
  %v584 = load ptr, ptr %v583, align 8, !tbaa !3
  %v585 = getelementptr i8, ptr %env, i64 56
  %v586 = load ptr, ptr %v585, align 8, !tbaa !3
  %v587 = getelementptr i8, ptr %env, i64 64
  %v588 = load ptr, ptr %v587, align 8, !tbaa !3
  %v589 = getelementptr i8, ptr %env, i64 72
  %v590 = load ptr, ptr %v589, align 8, !tbaa !3
  %v591 = getelementptr i8, ptr %env, i64 80
  %v592 = load ptr, ptr %v591, align 8, !tbaa !3
  %v593 = getelementptr i8, ptr %env, i64 88
  %v594 = load ptr, ptr %v593, align 8, !tbaa !3
  %v595 = getelementptr i8, ptr %env, i64 96
  %v596 = load ptr, ptr %v595, align 8, !tbaa !3
  %v1886 = call ptr @mlf_env_new(i64 4)
  %v1887 = getelementptr i8, ptr %v1886, i64 24
  store ptr %v578, ptr %v1887, align 8, !tbaa !3
  %v1888 = getelementptr i8, ptr %v1886, i64 32
  store ptr %v580, ptr %v1888, align 8, !tbaa !3
  %v1889 = getelementptr i8, ptr %v1886, i64 40
  store ptr %v590, ptr %v1889, align 8, !tbaa !3
  %v1890 = getelementptr i8, ptr %v1886, i64 48
  store ptr %v596, ptr %v1890, align 8, !tbaa !3
  %v1891 = call ptr @mlf_thunk(ptr @mlf.code.597, ptr %v1886)
  %v3921 = call ptr @mlf_env_new(i64 8)
  %v3922 = getelementptr i8, ptr %v3921, i64 24
  store ptr %v578, ptr %v3922, align 8, !tbaa !3
  %v3923 = getelementptr i8, ptr %v3921, i64 32
  store ptr %v582, ptr %v3923, align 8, !tbaa !3
  %v3924 = getelementptr i8, ptr %v3921, i64 40
  store ptr %v584, ptr %v3924, align 8, !tbaa !3
  %v3925 = getelementptr i8, ptr %v3921, i64 48
  store ptr %v586, ptr %v3925, align 8, !tbaa !3
  %v3926 = getelementptr i8, ptr %v3921, i64 56
  store ptr %v588, ptr %v3926, align 8, !tbaa !3
  %v3927 = getelementptr i8, ptr %v3921, i64 64
  store ptr %v590, ptr %v3927, align 8, !tbaa !3
  %v3928 = getelementptr i8, ptr %v3921, i64 72
  store ptr %v592, ptr %v3928, align 8, !tbaa !3
  %v3929 = getelementptr i8, ptr %v3921, i64 80
  store ptr %v594, ptr %v3929, align 8, !tbaa !3
  %v3930 = call ptr @mlf_closure(ptr @mlf.code.1892, ptr %v3921)
  %v3931 = call ptr @mlf_prim2(i64 1, ptr %v1891, ptr %v3930)
  ret ptr %v3931
}

define private ptr @mlf.code.552(ptr %env, ptr %arg) {
entry:
  %v553 = getelementptr i8, ptr %env, i64 24
  %v554 = load ptr, ptr %v553, align 8, !tbaa !3
  %v555 = getelementptr i8, ptr %env, i64 32
  %v556 = load ptr, ptr %v555, align 8, !tbaa !3
  %v557 = getelementptr i8, ptr %env, i64 40
  %v558 = load ptr, ptr %v557, align 8, !tbaa !3
  %v559 = getelementptr i8, ptr %env, i64 48
  %v560 = load ptr, ptr %v559, align 8, !tbaa !3
  %v561 = getelementptr i8, ptr %env, i64 56
  %v562 = load ptr, ptr %v561, align 8, !tbaa !3
  %v563 = getelementptr i8, ptr %env, i64 64
  %v564 = load ptr, ptr %v563, align 8, !tbaa !3
  %v565 = getelementptr i8, ptr %env, i64 72
  %v566 = load ptr, ptr %v565, align 8, !tbaa !3
  %v567 = getelementptr i8, ptr %env, i64 80
  %v568 = load ptr, ptr %v567, align 8, !tbaa !3
  %v569 = getelementptr i8, ptr %env, i64 88
  %v570 = load ptr, ptr %v569, align 8, !tbaa !3
  %v575 = call ptr @mlf_thunk(ptr @mlf.code.571, ptr null)
  %v3932 = call ptr @mlf_env_new(i64 10)
  %v3933 = getelementptr i8, ptr %v3932, i64 24
  store ptr %v554, ptr %v3933, align 8, !tbaa !3
  %v3934 = getelementptr i8, ptr %v3932, i64 32
  store ptr %v556, ptr %v3934, align 8, !tbaa !3
  %v3935 = getelementptr i8, ptr %v3932, i64 40
  store ptr %v558, ptr %v3935, align 8, !tbaa !3
  %v3936 = getelementptr i8, ptr %v3932, i64 48
  store ptr %v560, ptr %v3936, align 8, !tbaa !3
  %v3937 = getelementptr i8, ptr %v3932, i64 56
  store ptr %v562, ptr %v3937, align 8, !tbaa !3
  %v3938 = getelementptr i8, ptr %v3932, i64 64
  store ptr %v564, ptr %v3938, align 8, !tbaa !3
  %v3939 = getelementptr i8, ptr %v3932, i64 72
  store ptr %v566, ptr %v3939, align 8, !tbaa !3
  %v3940 = getelementptr i8, ptr %v3932, i64 80
  store ptr %v568, ptr %v3940, align 8, !tbaa !3
  %v3941 = getelementptr i8, ptr %v3932, i64 88
  store ptr %v570, ptr %v3941, align 8, !tbaa !3
  %v3942 = getelementptr i8, ptr %v3932, i64 96
  store ptr %arg, ptr %v3942, align 8, !tbaa !3
  %v3943 = call ptr @mlf_closure(ptr @mlf.code.576, ptr %v3932)
  %v3944 = call ptr @mlf_prim2(i64 1, ptr %v575, ptr %v3943)
  ret ptr %v3944
}

define private ptr @mlf.code.528(ptr %env, ptr %arg) {
entry:
  %v529 = getelementptr i8, ptr %env, i64 24
  %v530 = load ptr, ptr %v529, align 8, !tbaa !3
  %v531 = getelementptr i8, ptr %env, i64 32
  %v532 = load ptr, ptr %v531, align 8, !tbaa !3
  %v533 = getelementptr i8, ptr %env, i64 40
  %v534 = load ptr, ptr %v533, align 8, !tbaa !3
  %v535 = getelementptr i8, ptr %env, i64 48
  %v536 = load ptr, ptr %v535, align 8, !tbaa !3
  %v537 = getelementptr i8, ptr %env, i64 56
  %v538 = load ptr, ptr %v537, align 8, !tbaa !3
  %v539 = getelementptr i8, ptr %env, i64 64
  %v540 = load ptr, ptr %v539, align 8, !tbaa !3
  %v541 = getelementptr i8, ptr %env, i64 72
  %v542 = load ptr, ptr %v541, align 8, !tbaa !3
  %v543 = getelementptr i8, ptr %env, i64 80
  %v544 = load ptr, ptr %v543, align 8, !tbaa !3
  %v549 = call ptr @mlf_env_new(i64 1)
  %v550 = getelementptr i8, ptr %v549, i64 24
  store ptr %v532, ptr %v550, align 8, !tbaa !3
  %v551 = call ptr @mlf_thunk(ptr @mlf.code.545, ptr %v549)
  %v3945 = call ptr @mlf_env_new(i64 9)
  %v3946 = getelementptr i8, ptr %v3945, i64 24
  store ptr %v530, ptr %v3946, align 8, !tbaa !3
  %v3947 = getelementptr i8, ptr %v3945, i64 32
  store ptr %v532, ptr %v3947, align 8, !tbaa !3
  %v3948 = getelementptr i8, ptr %v3945, i64 40
  store ptr %v534, ptr %v3948, align 8, !tbaa !3
  %v3949 = getelementptr i8, ptr %v3945, i64 48
  store ptr %v536, ptr %v3949, align 8, !tbaa !3
  %v3950 = getelementptr i8, ptr %v3945, i64 56
  store ptr %v538, ptr %v3950, align 8, !tbaa !3
  %v3951 = getelementptr i8, ptr %v3945, i64 64
  store ptr %v540, ptr %v3951, align 8, !tbaa !3
  %v3952 = getelementptr i8, ptr %v3945, i64 72
  store ptr %v542, ptr %v3952, align 8, !tbaa !3
  %v3953 = getelementptr i8, ptr %v3945, i64 80
  store ptr %v544, ptr %v3953, align 8, !tbaa !3
  %v3954 = getelementptr i8, ptr %v3945, i64 88
  store ptr %arg, ptr %v3954, align 8, !tbaa !3
  %v3955 = call ptr @mlf_closure(ptr @mlf.code.552, ptr %v3945)
  %v3956 = call ptr @mlf_prim2(i64 1, ptr %v551, ptr %v3955)
  ret ptr %v3956
}

define private ptr @mlf.code.509(ptr %env, ptr %arg) {
entry:
  %v510 = getelementptr i8, ptr %env, i64 24
  %v511 = load ptr, ptr %v510, align 8, !tbaa !3
  %v512 = getelementptr i8, ptr %env, i64 32
  %v513 = load ptr, ptr %v512, align 8, !tbaa !3
  %v514 = getelementptr i8, ptr %env, i64 40
  %v515 = load ptr, ptr %v514, align 8, !tbaa !3
  %v516 = getelementptr i8, ptr %env, i64 48
  %v517 = load ptr, ptr %v516, align 8, !tbaa !3
  %v518 = getelementptr i8, ptr %env, i64 56
  %v519 = load ptr, ptr %v518, align 8, !tbaa !3
  %v520 = getelementptr i8, ptr %env, i64 64
  %v521 = load ptr, ptr %v520, align 8, !tbaa !3
  %v522 = getelementptr i8, ptr %env, i64 72
  %v523 = load ptr, ptr %v522, align 8, !tbaa !3
  %v527 = call ptr @mlf_thunk(ptr @mlf.code.524, ptr null)
  %v3957 = call ptr @mlf_env_new(i64 8)
  %v3958 = getelementptr i8, ptr %v3957, i64 24
  store ptr %v511, ptr %v3958, align 8, !tbaa !3
  %v3959 = getelementptr i8, ptr %v3957, i64 32
  store ptr %v513, ptr %v3959, align 8, !tbaa !3
  %v3960 = getelementptr i8, ptr %v3957, i64 40
  store ptr %v515, ptr %v3960, align 8, !tbaa !3
  %v3961 = getelementptr i8, ptr %v3957, i64 48
  store ptr %v517, ptr %v3961, align 8, !tbaa !3
  %v3962 = getelementptr i8, ptr %v3957, i64 56
  store ptr %v519, ptr %v3962, align 8, !tbaa !3
  %v3963 = getelementptr i8, ptr %v3957, i64 64
  store ptr %v521, ptr %v3963, align 8, !tbaa !3
  %v3964 = getelementptr i8, ptr %v3957, i64 72
  store ptr %v523, ptr %v3964, align 8, !tbaa !3
  %v3965 = getelementptr i8, ptr %v3957, i64 80
  store ptr %arg, ptr %v3965, align 8, !tbaa !3
  %v3966 = call ptr @mlf_closure(ptr @mlf.code.528, ptr %v3957)
  %v3967 = call ptr @mlf_prim2(i64 1, ptr %v527, ptr %v3966)
  ret ptr %v3967
}

define private ptr @mlf.code.493(ptr %env, ptr %arg) {
entry:
  %v494 = getelementptr i8, ptr %env, i64 24
  %v495 = load ptr, ptr %v494, align 8, !tbaa !3
  %v496 = getelementptr i8, ptr %env, i64 32
  %v497 = load ptr, ptr %v496, align 8, !tbaa !3
  %v498 = getelementptr i8, ptr %env, i64 40
  %v499 = load ptr, ptr %v498, align 8, !tbaa !3
  %v500 = getelementptr i8, ptr %env, i64 48
  %v501 = load ptr, ptr %v500, align 8, !tbaa !3
  %v502 = getelementptr i8, ptr %env, i64 56
  %v503 = load ptr, ptr %v502, align 8, !tbaa !3
  %v504 = getelementptr i8, ptr %env, i64 64
  %v505 = load ptr, ptr %v504, align 8, !tbaa !3
  %v508 = call ptr @mlf_thunk(ptr @mlf.code.506, ptr null)
  %v3968 = call ptr @mlf_env_new(i64 7)
  %v3969 = getelementptr i8, ptr %v3968, i64 24
  store ptr %v495, ptr %v3969, align 8, !tbaa !3
  %v3970 = getelementptr i8, ptr %v3968, i64 32
  store ptr %v497, ptr %v3970, align 8, !tbaa !3
  %v3971 = getelementptr i8, ptr %v3968, i64 40
  store ptr %v499, ptr %v3971, align 8, !tbaa !3
  %v3972 = getelementptr i8, ptr %v3968, i64 48
  store ptr %v501, ptr %v3972, align 8, !tbaa !3
  %v3973 = getelementptr i8, ptr %v3968, i64 56
  store ptr %v503, ptr %v3973, align 8, !tbaa !3
  %v3974 = getelementptr i8, ptr %v3968, i64 64
  store ptr %v505, ptr %v3974, align 8, !tbaa !3
  %v3975 = getelementptr i8, ptr %v3968, i64 72
  store ptr %arg, ptr %v3975, align 8, !tbaa !3
  %v3976 = call ptr @mlf_closure(ptr @mlf.code.509, ptr %v3968)
  %v3977 = call ptr @mlf_prim2(i64 1, ptr %v508, ptr %v3976)
  ret ptr %v3977
}

define private ptr @mlf.code.477(ptr %env, ptr %arg) {
entry:
  %v478 = getelementptr i8, ptr %env, i64 24
  %v479 = load ptr, ptr %v478, align 8, !tbaa !3
  %v480 = getelementptr i8, ptr %env, i64 32
  %v481 = load ptr, ptr %v480, align 8, !tbaa !3
  %v482 = getelementptr i8, ptr %env, i64 40
  %v483 = load ptr, ptr %v482, align 8, !tbaa !3
  %v484 = getelementptr i8, ptr %env, i64 48
  %v485 = load ptr, ptr %v484, align 8, !tbaa !3
  %v486 = getelementptr i8, ptr %env, i64 56
  %v487 = load ptr, ptr %v486, align 8, !tbaa !3
  %v488 = getelementptr i8, ptr %env, i64 64
  %v489 = load ptr, ptr %v488, align 8, !tbaa !3
  %v492 = call ptr @mlf_thunk(ptr @mlf.code.490, ptr null)
  %v3978 = call ptr @mlf_env_new(i64 6)
  %v3979 = getelementptr i8, ptr %v3978, i64 24
  store ptr %v479, ptr %v3979, align 8, !tbaa !3
  %v3980 = getelementptr i8, ptr %v3978, i64 32
  store ptr %v481, ptr %v3980, align 8, !tbaa !3
  %v3981 = getelementptr i8, ptr %v3978, i64 40
  store ptr %v483, ptr %v3981, align 8, !tbaa !3
  %v3982 = getelementptr i8, ptr %v3978, i64 48
  store ptr %v485, ptr %v3982, align 8, !tbaa !3
  %v3983 = getelementptr i8, ptr %v3978, i64 56
  store ptr %v487, ptr %v3983, align 8, !tbaa !3
  %v3984 = getelementptr i8, ptr %v3978, i64 64
  store ptr %v489, ptr %v3984, align 8, !tbaa !3
  %v3985 = call ptr @mlf_closure(ptr @mlf.code.493, ptr %v3978)
  %v3986 = call ptr @mlf_prim2(i64 1, ptr %v492, ptr %v3985)
  ret ptr %v3986
}

define private ptr @mlf.code.453(ptr %env, ptr %arg) {
entry:
  %v454 = getelementptr i8, ptr %env, i64 24
  %v455 = load ptr, ptr %v454, align 8, !tbaa !3
  %v456 = getelementptr i8, ptr %env, i64 32
  %v457 = load ptr, ptr %v456, align 8, !tbaa !3
  %v458 = getelementptr i8, ptr %env, i64 40
  %v459 = load ptr, ptr %v458, align 8, !tbaa !3
  %v460 = getelementptr i8, ptr %env, i64 48
  %v461 = load ptr, ptr %v460, align 8, !tbaa !3
  %v462 = getelementptr i8, ptr %env, i64 56
  %v463 = load ptr, ptr %v462, align 8, !tbaa !3
  %v464 = getelementptr i8, ptr %env, i64 64
  %v465 = load ptr, ptr %v464, align 8, !tbaa !3
  %v474 = call ptr @mlf_env_new(i64 1)
  %v475 = getelementptr i8, ptr %v474, i64 24
  store ptr %v465, ptr %v475, align 8, !tbaa !3
  %v476 = call ptr @mlf_thunk(ptr @mlf.code.466, ptr %v474)
  %v3987 = call ptr @mlf_env_new(i64 6)
  %v3988 = getelementptr i8, ptr %v3987, i64 24
  store ptr %v455, ptr %v3988, align 8, !tbaa !3
  %v3989 = getelementptr i8, ptr %v3987, i64 32
  store ptr %v457, ptr %v3989, align 8, !tbaa !3
  %v3990 = getelementptr i8, ptr %v3987, i64 40
  store ptr %v459, ptr %v3990, align 8, !tbaa !3
  %v3991 = getelementptr i8, ptr %v3987, i64 48
  store ptr %v461, ptr %v3991, align 8, !tbaa !3
  %v3992 = getelementptr i8, ptr %v3987, i64 56
  store ptr %v463, ptr %v3992, align 8, !tbaa !3
  %v3993 = getelementptr i8, ptr %v3987, i64 64
  store ptr %v465, ptr %v3993, align 8, !tbaa !3
  %v3994 = call ptr @mlf_closure(ptr @mlf.code.477, ptr %v3987)
  %v3995 = call ptr @mlf_prim2(i64 1, ptr %v476, ptr %v3994)
  ret ptr %v3995
}

define private ptr @mlf.code.216(ptr %env, ptr %arg) {
entry:
  %v217 = getelementptr i8, ptr %env, i64 24
  %v218 = load ptr, ptr %v217, align 8, !tbaa !3
  %v219 = getelementptr i8, ptr %env, i64 32
  %v220 = load ptr, ptr %v219, align 8, !tbaa !3
  %v221 = getelementptr i8, ptr %env, i64 40
  %v222 = load ptr, ptr %v221, align 8, !tbaa !3
  %v223 = getelementptr i8, ptr %env, i64 48
  %v224 = load ptr, ptr %v223, align 8, !tbaa !3
  %v225 = getelementptr i8, ptr %env, i64 56
  %v226 = load ptr, ptr %v225, align 8, !tbaa !3
  %v227 = getelementptr i8, ptr %env, i64 64
  %v228 = load ptr, ptr %v227, align 8, !tbaa !3
  %v450 = call ptr @mlf_env_new(i64 1)
  %v451 = getelementptr i8, ptr %v450, i64 24
  store ptr %v226, ptr %v451, align 8, !tbaa !3
  %v452 = call ptr @mlf_thunk(ptr @mlf.code.229, ptr %v450)
  %v3996 = call ptr @mlf_env_new(i64 6)
  %v3997 = getelementptr i8, ptr %v3996, i64 24
  store ptr %v218, ptr %v3997, align 8, !tbaa !3
  %v3998 = getelementptr i8, ptr %v3996, i64 32
  store ptr %v220, ptr %v3998, align 8, !tbaa !3
  %v3999 = getelementptr i8, ptr %v3996, i64 40
  store ptr %v222, ptr %v3999, align 8, !tbaa !3
  %v4000 = getelementptr i8, ptr %v3996, i64 48
  store ptr %v224, ptr %v4000, align 8, !tbaa !3
  %v4001 = getelementptr i8, ptr %v3996, i64 56
  store ptr %v226, ptr %v4001, align 8, !tbaa !3
  %v4002 = getelementptr i8, ptr %v3996, i64 64
  store ptr %v228, ptr %v4002, align 8, !tbaa !3
  %v4003 = call ptr @mlf_closure(ptr @mlf.code.453, ptr %v3996)
  %v4004 = call ptr @mlf_prim2(i64 1, ptr %v452, ptr %v4003)
  ret ptr %v4004
}

define private ptr @mlf.code.195(ptr %env, ptr %arg) {
entry:
  %v196 = getelementptr i8, ptr %env, i64 24
  %v197 = load ptr, ptr %v196, align 8, !tbaa !3
  %v198 = getelementptr i8, ptr %env, i64 32
  %v199 = load ptr, ptr %v198, align 8, !tbaa !3
  %v200 = getelementptr i8, ptr %env, i64 40
  %v201 = load ptr, ptr %v200, align 8, !tbaa !3
  %v202 = getelementptr i8, ptr %env, i64 48
  %v203 = load ptr, ptr %v202, align 8, !tbaa !3
  %v204 = getelementptr i8, ptr %env, i64 56
  %v205 = load ptr, ptr %v204, align 8, !tbaa !3
  %v206 = getelementptr i8, ptr %env, i64 64
  %v207 = load ptr, ptr %v206, align 8, !tbaa !3
  %v213 = call ptr @mlf_env_new(i64 1)
  %v214 = getelementptr i8, ptr %v213, i64 24
  store ptr %v207, ptr %v214, align 8, !tbaa !3
  %v215 = call ptr @mlf_thunk(ptr @mlf.code.208, ptr %v213)
  %v4005 = call ptr @mlf_env_new(i64 6)
  %v4006 = getelementptr i8, ptr %v4005, i64 24
  store ptr %v197, ptr %v4006, align 8, !tbaa !3
  %v4007 = getelementptr i8, ptr %v4005, i64 32
  store ptr %v199, ptr %v4007, align 8, !tbaa !3
  %v4008 = getelementptr i8, ptr %v4005, i64 40
  store ptr %v201, ptr %v4008, align 8, !tbaa !3
  %v4009 = getelementptr i8, ptr %v4005, i64 48
  store ptr %v203, ptr %v4009, align 8, !tbaa !3
  %v4010 = getelementptr i8, ptr %v4005, i64 56
  store ptr %v205, ptr %v4010, align 8, !tbaa !3
  %v4011 = getelementptr i8, ptr %v4005, i64 64
  store ptr %v207, ptr %v4011, align 8, !tbaa !3
  %v4012 = call ptr @mlf_closure(ptr @mlf.code.216, ptr %v4005)
  %v4013 = call ptr @mlf_prim2(i64 1, ptr %v215, ptr %v4012)
  ret ptr %v4013
}

define private ptr @mlf.code.174(ptr %env, ptr %arg) {
entry:
  %v175 = getelementptr i8, ptr %env, i64 24
  %v176 = load ptr, ptr %v175, align 8, !tbaa !3
  %v177 = getelementptr i8, ptr %env, i64 32
  %v178 = load ptr, ptr %v177, align 8, !tbaa !3
  %v179 = getelementptr i8, ptr %env, i64 40
  %v180 = load ptr, ptr %v179, align 8, !tbaa !3
  %v181 = getelementptr i8, ptr %env, i64 48
  %v182 = load ptr, ptr %v181, align 8, !tbaa !3
  %v183 = getelementptr i8, ptr %env, i64 56
  %v184 = load ptr, ptr %v183, align 8, !tbaa !3
  %v185 = getelementptr i8, ptr %env, i64 64
  %v186 = load ptr, ptr %v185, align 8, !tbaa !3
  %v192 = call ptr @mlf_env_new(i64 1)
  %v193 = getelementptr i8, ptr %v192, i64 24
  store ptr %v186, ptr %v193, align 8, !tbaa !3
  %v194 = call ptr @mlf_thunk(ptr @mlf.code.187, ptr %v192)
  %v4014 = call ptr @mlf_env_new(i64 6)
  %v4015 = getelementptr i8, ptr %v4014, i64 24
  store ptr %v176, ptr %v4015, align 8, !tbaa !3
  %v4016 = getelementptr i8, ptr %v4014, i64 32
  store ptr %v178, ptr %v4016, align 8, !tbaa !3
  %v4017 = getelementptr i8, ptr %v4014, i64 40
  store ptr %v180, ptr %v4017, align 8, !tbaa !3
  %v4018 = getelementptr i8, ptr %v4014, i64 48
  store ptr %v182, ptr %v4018, align 8, !tbaa !3
  %v4019 = getelementptr i8, ptr %v4014, i64 56
  store ptr %v184, ptr %v4019, align 8, !tbaa !3
  %v4020 = getelementptr i8, ptr %v4014, i64 64
  store ptr %v186, ptr %v4020, align 8, !tbaa !3
  %v4021 = call ptr @mlf_closure(ptr @mlf.code.195, ptr %v4014)
  %v4022 = call ptr @mlf_prim2(i64 1, ptr %v194, ptr %v4021)
  ret ptr %v4022
}

define private ptr @mlf.code.153(ptr %env, ptr %arg) {
entry:
  %v154 = getelementptr i8, ptr %env, i64 24
  %v155 = load ptr, ptr %v154, align 8, !tbaa !3
  %v156 = getelementptr i8, ptr %env, i64 32
  %v157 = load ptr, ptr %v156, align 8, !tbaa !3
  %v158 = getelementptr i8, ptr %env, i64 40
  %v159 = load ptr, ptr %v158, align 8, !tbaa !3
  %v160 = getelementptr i8, ptr %env, i64 48
  %v161 = load ptr, ptr %v160, align 8, !tbaa !3
  %v162 = getelementptr i8, ptr %env, i64 56
  %v163 = load ptr, ptr %v162, align 8, !tbaa !3
  %v164 = getelementptr i8, ptr %env, i64 64
  %v165 = load ptr, ptr %v164, align 8, !tbaa !3
  %v171 = call ptr @mlf_env_new(i64 1)
  %v172 = getelementptr i8, ptr %v171, i64 24
  store ptr %v165, ptr %v172, align 8, !tbaa !3
  %v173 = call ptr @mlf_thunk(ptr @mlf.code.166, ptr %v171)
  %v4023 = call ptr @mlf_env_new(i64 6)
  %v4024 = getelementptr i8, ptr %v4023, i64 24
  store ptr %v155, ptr %v4024, align 8, !tbaa !3
  %v4025 = getelementptr i8, ptr %v4023, i64 32
  store ptr %v157, ptr %v4025, align 8, !tbaa !3
  %v4026 = getelementptr i8, ptr %v4023, i64 40
  store ptr %v159, ptr %v4026, align 8, !tbaa !3
  %v4027 = getelementptr i8, ptr %v4023, i64 48
  store ptr %v161, ptr %v4027, align 8, !tbaa !3
  %v4028 = getelementptr i8, ptr %v4023, i64 56
  store ptr %v163, ptr %v4028, align 8, !tbaa !3
  %v4029 = getelementptr i8, ptr %v4023, i64 64
  store ptr %v165, ptr %v4029, align 8, !tbaa !3
  %v4030 = call ptr @mlf_closure(ptr @mlf.code.174, ptr %v4023)
  %v4031 = call ptr @mlf_prim2(i64 1, ptr %v173, ptr %v4030)
  ret ptr %v4031
}

define private ptr @mlf.code.134(ptr %env, ptr %arg) {
entry:
  %v135 = getelementptr i8, ptr %env, i64 24
  %v136 = load ptr, ptr %v135, align 8, !tbaa !3
  %v137 = getelementptr i8, ptr %env, i64 32
  %v138 = load ptr, ptr %v137, align 8, !tbaa !3
  %v139 = getelementptr i8, ptr %env, i64 40
  %v140 = load ptr, ptr %v139, align 8, !tbaa !3
  %v141 = getelementptr i8, ptr %env, i64 48
  %v142 = load ptr, ptr %v141, align 8, !tbaa !3
  %v143 = getelementptr i8, ptr %env, i64 56
  %v144 = load ptr, ptr %v143, align 8, !tbaa !3
  %v150 = call ptr @mlf_env_new(i64 1)
  %v151 = getelementptr i8, ptr %v150, i64 24
  store ptr %arg, ptr %v151, align 8, !tbaa !3
  %v152 = call ptr @mlf_thunk(ptr @mlf.code.145, ptr %v150)
  %v4032 = call ptr @mlf_env_new(i64 6)
  %v4033 = getelementptr i8, ptr %v4032, i64 24
  store ptr %v136, ptr %v4033, align 8, !tbaa !3
  %v4034 = getelementptr i8, ptr %v4032, i64 32
  store ptr %v138, ptr %v4034, align 8, !tbaa !3
  %v4035 = getelementptr i8, ptr %v4032, i64 40
  store ptr %v140, ptr %v4035, align 8, !tbaa !3
  %v4036 = getelementptr i8, ptr %v4032, i64 48
  store ptr %v142, ptr %v4036, align 8, !tbaa !3
  %v4037 = getelementptr i8, ptr %v4032, i64 56
  store ptr %v144, ptr %v4037, align 8, !tbaa !3
  %v4038 = getelementptr i8, ptr %v4032, i64 64
  store ptr %arg, ptr %v4038, align 8, !tbaa !3
  %v4039 = call ptr @mlf_closure(ptr @mlf.code.153, ptr %v4032)
  %v4040 = call ptr @mlf_prim2(i64 1, ptr %v152, ptr %v4039)
  ret ptr %v4040
}

define private ptr @mlf.code.119(ptr %env, ptr %arg) {
entry:
  %v120 = getelementptr i8, ptr %env, i64 24
  %v121 = load ptr, ptr %v120, align 8, !tbaa !3
  %v122 = getelementptr i8, ptr %env, i64 32
  %v123 = load ptr, ptr %v122, align 8, !tbaa !3
  %v124 = getelementptr i8, ptr %env, i64 40
  %v125 = load ptr, ptr %v124, align 8, !tbaa !3
  %v126 = getelementptr i8, ptr %env, i64 48
  %v127 = load ptr, ptr %v126, align 8, !tbaa !3
  %v128 = getelementptr i8, ptr %env, i64 56
  %v129 = load ptr, ptr %v128, align 8, !tbaa !3
  %v133 = call ptr @mlf_thunk(ptr @mlf.code.130, ptr null)
  %v4041 = call ptr @mlf_env_new(i64 5)
  %v4042 = getelementptr i8, ptr %v4041, i64 24
  store ptr %v121, ptr %v4042, align 8, !tbaa !3
  %v4043 = getelementptr i8, ptr %v4041, i64 32
  store ptr %v123, ptr %v4043, align 8, !tbaa !3
  %v4044 = getelementptr i8, ptr %v4041, i64 40
  store ptr %v125, ptr %v4044, align 8, !tbaa !3
  %v4045 = getelementptr i8, ptr %v4041, i64 48
  store ptr %v127, ptr %v4045, align 8, !tbaa !3
  %v4046 = getelementptr i8, ptr %v4041, i64 56
  store ptr %v129, ptr %v4046, align 8, !tbaa !3
  %v4047 = call ptr @mlf_closure(ptr @mlf.code.134, ptr %v4041)
  %v4048 = call ptr @mlf_prim2(i64 1, ptr %v133, ptr %v4047)
  ret ptr %v4048
}

define private ptr @mlf.code.100(ptr %env, ptr %arg) {
entry:
  %v101 = getelementptr i8, ptr %env, i64 24
  %v102 = load ptr, ptr %v101, align 8, !tbaa !3
  %v103 = getelementptr i8, ptr %env, i64 32
  %v104 = load ptr, ptr %v103, align 8, !tbaa !3
  %v105 = getelementptr i8, ptr %env, i64 40
  %v106 = load ptr, ptr %v105, align 8, !tbaa !3
  %v107 = getelementptr i8, ptr %env, i64 48
  %v108 = load ptr, ptr %v107, align 8, !tbaa !3
  %v109 = getelementptr i8, ptr %env, i64 56
  %v110 = load ptr, ptr %v109, align 8, !tbaa !3
  %v116 = call ptr @mlf_env_new(i64 1)
  %v117 = getelementptr i8, ptr %v116, i64 24
  store ptr %v110, ptr %v117, align 8, !tbaa !3
  %v118 = call ptr @mlf_thunk(ptr @mlf.code.111, ptr %v116)
  %v4049 = call ptr @mlf_env_new(i64 5)
  %v4050 = getelementptr i8, ptr %v4049, i64 24
  store ptr %v102, ptr %v4050, align 8, !tbaa !3
  %v4051 = getelementptr i8, ptr %v4049, i64 32
  store ptr %v104, ptr %v4051, align 8, !tbaa !3
  %v4052 = getelementptr i8, ptr %v4049, i64 40
  store ptr %v106, ptr %v4052, align 8, !tbaa !3
  %v4053 = getelementptr i8, ptr %v4049, i64 48
  store ptr %v108, ptr %v4053, align 8, !tbaa !3
  %v4054 = getelementptr i8, ptr %v4049, i64 56
  store ptr %v110, ptr %v4054, align 8, !tbaa !3
  %v4055 = call ptr @mlf_closure(ptr @mlf.code.119, ptr %v4049)
  %v4056 = call ptr @mlf_prim2(i64 1, ptr %v118, ptr %v4055)
  ret ptr %v4056
}

define private ptr @mlf.code.81(ptr %env, ptr %arg) {
entry:
  %v82 = getelementptr i8, ptr %env, i64 24
  %v83 = load ptr, ptr %v82, align 8, !tbaa !3
  %v84 = getelementptr i8, ptr %env, i64 32
  %v85 = load ptr, ptr %v84, align 8, !tbaa !3
  %v86 = getelementptr i8, ptr %env, i64 40
  %v87 = load ptr, ptr %v86, align 8, !tbaa !3
  %v88 = getelementptr i8, ptr %env, i64 48
  %v89 = load ptr, ptr %v88, align 8, !tbaa !3
  %v90 = getelementptr i8, ptr %env, i64 56
  %v91 = load ptr, ptr %v90, align 8, !tbaa !3
  %v97 = call ptr @mlf_env_new(i64 1)
  %v98 = getelementptr i8, ptr %v97, i64 24
  store ptr %v91, ptr %v98, align 8, !tbaa !3
  %v99 = call ptr @mlf_thunk(ptr @mlf.code.92, ptr %v97)
  %v4057 = call ptr @mlf_env_new(i64 5)
  %v4058 = getelementptr i8, ptr %v4057, i64 24
  store ptr %v83, ptr %v4058, align 8, !tbaa !3
  %v4059 = getelementptr i8, ptr %v4057, i64 32
  store ptr %v85, ptr %v4059, align 8, !tbaa !3
  %v4060 = getelementptr i8, ptr %v4057, i64 40
  store ptr %v87, ptr %v4060, align 8, !tbaa !3
  %v4061 = getelementptr i8, ptr %v4057, i64 48
  store ptr %v89, ptr %v4061, align 8, !tbaa !3
  %v4062 = getelementptr i8, ptr %v4057, i64 56
  store ptr %v91, ptr %v4062, align 8, !tbaa !3
  %v4063 = call ptr @mlf_closure(ptr @mlf.code.100, ptr %v4057)
  %v4064 = call ptr @mlf_prim2(i64 1, ptr %v99, ptr %v4063)
  ret ptr %v4064
}

define private ptr @mlf.code.62(ptr %env, ptr %arg) {
entry:
  %v63 = getelementptr i8, ptr %env, i64 24
  %v64 = load ptr, ptr %v63, align 8, !tbaa !3
  %v65 = getelementptr i8, ptr %env, i64 32
  %v66 = load ptr, ptr %v65, align 8, !tbaa !3
  %v67 = getelementptr i8, ptr %env, i64 40
  %v68 = load ptr, ptr %v67, align 8, !tbaa !3
  %v69 = getelementptr i8, ptr %env, i64 48
  %v70 = load ptr, ptr %v69, align 8, !tbaa !3
  %v71 = getelementptr i8, ptr %env, i64 56
  %v72 = load ptr, ptr %v71, align 8, !tbaa !3
  %v78 = call ptr @mlf_env_new(i64 1)
  %v79 = getelementptr i8, ptr %v78, i64 24
  store ptr %v72, ptr %v79, align 8, !tbaa !3
  %v80 = call ptr @mlf_thunk(ptr @mlf.code.73, ptr %v78)
  %v4065 = call ptr @mlf_env_new(i64 5)
  %v4066 = getelementptr i8, ptr %v4065, i64 24
  store ptr %v64, ptr %v4066, align 8, !tbaa !3
  %v4067 = getelementptr i8, ptr %v4065, i64 32
  store ptr %v66, ptr %v4067, align 8, !tbaa !3
  %v4068 = getelementptr i8, ptr %v4065, i64 40
  store ptr %v68, ptr %v4068, align 8, !tbaa !3
  %v4069 = getelementptr i8, ptr %v4065, i64 48
  store ptr %v70, ptr %v4069, align 8, !tbaa !3
  %v4070 = getelementptr i8, ptr %v4065, i64 56
  store ptr %v72, ptr %v4070, align 8, !tbaa !3
  %v4071 = call ptr @mlf_closure(ptr @mlf.code.81, ptr %v4065)
  %v4072 = call ptr @mlf_prim2(i64 1, ptr %v80, ptr %v4071)
  ret ptr %v4072
}

define private ptr @mlf.code.45(ptr %env, ptr %arg) {
entry:
  %v46 = getelementptr i8, ptr %env, i64 24
  %v47 = load ptr, ptr %v46, align 8, !tbaa !3
  %v48 = getelementptr i8, ptr %env, i64 32
  %v49 = load ptr, ptr %v48, align 8, !tbaa !3
  %v50 = getelementptr i8, ptr %env, i64 40
  %v51 = load ptr, ptr %v50, align 8, !tbaa !3
  %v52 = getelementptr i8, ptr %env, i64 48
  %v53 = load ptr, ptr %v52, align 8, !tbaa !3
  %v59 = call ptr @mlf_env_new(i64 1)
  %v60 = getelementptr i8, ptr %v59, i64 24
  store ptr %arg, ptr %v60, align 8, !tbaa !3
  %v61 = call ptr @mlf_thunk(ptr @mlf.code.54, ptr %v59)
  %v4073 = call ptr @mlf_env_new(i64 5)
  %v4074 = getelementptr i8, ptr %v4073, i64 24
  store ptr %v47, ptr %v4074, align 8, !tbaa !3
  %v4075 = getelementptr i8, ptr %v4073, i64 32
  store ptr %v49, ptr %v4075, align 8, !tbaa !3
  %v4076 = getelementptr i8, ptr %v4073, i64 40
  store ptr %v51, ptr %v4076, align 8, !tbaa !3
  %v4077 = getelementptr i8, ptr %v4073, i64 48
  store ptr %v53, ptr %v4077, align 8, !tbaa !3
  %v4078 = getelementptr i8, ptr %v4073, i64 56
  store ptr %arg, ptr %v4078, align 8, !tbaa !3
  %v4079 = call ptr @mlf_closure(ptr @mlf.code.62, ptr %v4073)
  %v4080 = call ptr @mlf_prim2(i64 1, ptr %v61, ptr %v4079)
  ret ptr %v4080
}

define private ptr @mlf.code.34(ptr %env, ptr %arg) {
entry:
  %v35 = getelementptr i8, ptr %env, i64 24
  %v36 = load ptr, ptr %v35, align 8, !tbaa !3
  %v37 = getelementptr i8, ptr %env, i64 32
  %v38 = load ptr, ptr %v37, align 8, !tbaa !3
  %v39 = getelementptr i8, ptr %env, i64 40
  %v40 = load ptr, ptr %v39, align 8, !tbaa !3
  %v44 = call ptr @mlf_thunk(ptr @mlf.code.41, ptr null)
  %v4081 = call ptr @mlf_env_new(i64 4)
  %v4082 = getelementptr i8, ptr %v4081, i64 24
  store ptr %v36, ptr %v4082, align 8, !tbaa !3
  %v4083 = getelementptr i8, ptr %v4081, i64 32
  store ptr %v38, ptr %v4083, align 8, !tbaa !3
  %v4084 = getelementptr i8, ptr %v4081, i64 40
  store ptr %v40, ptr %v4084, align 8, !tbaa !3
  %v4085 = getelementptr i8, ptr %v4081, i64 48
  store ptr %arg, ptr %v4085, align 8, !tbaa !3
  %v4086 = call ptr @mlf_closure(ptr @mlf.code.45, ptr %v4081)
  %v4087 = call ptr @mlf_prim2(i64 1, ptr %v44, ptr %v4086)
  ret ptr %v4087
}

define private ptr @mlf.code.24(ptr %env, ptr %arg) {
entry:
  %v25 = getelementptr i8, ptr %env, i64 24
  %v26 = load ptr, ptr %v25, align 8, !tbaa !3
  %v27 = getelementptr i8, ptr %env, i64 32
  %v28 = load ptr, ptr %v27, align 8, !tbaa !3
  %v33 = call ptr @mlf_thunk(ptr @mlf.code.29, ptr null)
  %v4088 = call ptr @mlf_env_new(i64 3)
  %v4089 = getelementptr i8, ptr %v4088, i64 24
  store ptr %v26, ptr %v4089, align 8, !tbaa !3
  %v4090 = getelementptr i8, ptr %v4088, i64 32
  store ptr %v28, ptr %v4090, align 8, !tbaa !3
  %v4091 = getelementptr i8, ptr %v4088, i64 40
  store ptr %arg, ptr %v4091, align 8, !tbaa !3
  %v4092 = call ptr @mlf_closure(ptr @mlf.code.34, ptr %v4088)
  %v4093 = call ptr @mlf_prim2(i64 1, ptr %v33, ptr %v4092)
  ret ptr %v4093
}

define private ptr @mlf.code.16(ptr %env, ptr %arg) {
entry:
  %v17 = getelementptr i8, ptr %env, i64 24
  %v18 = load ptr, ptr %v17, align 8, !tbaa !3
  %v23 = call ptr @mlf_thunk(ptr @mlf.code.19, ptr null)
  %v4094 = call ptr @mlf_env_new(i64 2)
  %v4095 = getelementptr i8, ptr %v4094, i64 24
  store ptr %v18, ptr %v4095, align 8, !tbaa !3
  %v4096 = getelementptr i8, ptr %v4094, i64 32
  store ptr %arg, ptr %v4096, align 8, !tbaa !3
  %v4097 = call ptr @mlf_closure(ptr @mlf.code.24, ptr %v4094)
  %v4098 = call ptr @mlf_prim2(i64 1, ptr %v23, ptr %v4097)
  ret ptr %v4098
}

define private ptr @mlf.code.2(ptr %env, ptr %arg) {
entry:
  %v8 = call ptr @mlf_env_new(i64 1)
  %v9 = getelementptr i8, ptr %v8, i64 24
  store ptr %arg, ptr %v9, align 8, !tbaa !3
  %v10 = call ptr @mlf_thunk(ptr @mlf.code.3, ptr %v8)
  %v15 = call ptr @mlf_thunk(ptr @mlf.code.11, ptr null)
  %v4099 = call ptr @mlf_env_new(i64 1)
  %v4100 = getelementptr i8, ptr %v4099, i64 24
  store ptr %v10, ptr %v4100, align 8, !tbaa !3
  %v4101 = call ptr @mlf_closure(ptr @mlf.code.16, ptr %v4099)
  %v4102 = call ptr @mlf_prim2(i64 1, ptr %v15, ptr %v4101)
  ret ptr %v4102
}

define private ptr @mlf.code.0(ptr %env, ptr %arg) {
entry:
  %v1 = call ptr @mlf_primitive(i64 4)
  %v4103 = call ptr @mlf_closure(ptr @mlf.code.2, ptr null)
  %v4104 = call ptr @mlf_prim2(i64 1, ptr %v1, ptr %v4103)
  ret ptr %v4104
}

declare void @mlf_require_standard_abi()
define ptr @mlf_entry() {
  call void @mlf_require_standard_abi()
  %root = call ptr @mlf.code.0(ptr null, ptr null)
  ret ptr %root
}
define i32 @main(i32 %argc, ptr %argv) {
  call void @mlf_set_args(i32 %argc, ptr %argv)
  %root = call ptr @mlf_entry()
  %status = call i32 @mlf_run(ptr %root, i64 1)
  ret i32 %status
}
