; Generated from independently checked xMLF.
source_filename = "emlf"

declare ptr @mlf_thunk_new(ptr, i64)
declare ptr @mlf_execute_st_lazy(ptr)
declare ptr @mlf_st_new_array(ptr, ptr)
declare ptr @mlf_st_read_array(ptr, ptr)
declare ptr @mlf_st_write_array(ptr, ptr, ptr)
declare ptr @mlf_st_length_array(ptr)
declare void @mlf_set_args(i32, ptr)
declare ptr @mlf_env_new(i64)
declare void @mlf_env_set(ptr, i64, ptr)
declare ptr @mlf_env_get(ptr, i64)
declare ptr @mlf_thunk(ptr, ptr)
declare ptr @mlf_closure(ptr, ptr)
declare ptr @mlf_application(ptr, ptr)
declare ptr @mlf_hole()
declare void @mlf_fill(ptr, ptr)
declare ptr @mlf_integer(ptr)
declare ptr @mlf_string(ptr, i64)
declare ptr @mlf_double(double)
declare double @llvm.sqrt.f64(double)
declare double @mlf_int_to_double(ptr)
declare ptr @mlf_read_int_table(ptr, ptr)
declare ptr @mlf_write_int_table(ptr, ptr, ptr)
declare ptr @mlf_add_int_table(ptr, ptr, ptr)
declare void @mlf_roots_enter(ptr, i64, ptr)
declare void @mlf_roots_leave(ptr)
declare void @mlf_gc_check(i64, ptr)
declare ptr @mlf_get_byte_line()
declare ptr @mlf_new_array(i64, ptr, ptr)
declare ptr @mlf_bytes_from_string(ptr)
declare ptr @mlf_put_bytes(ptr, ptr, ptr)
declare ptr @mlf_new_int_table()
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare i8 @mlf_byte(ptr)
declare ptr @mlf_peek(ptr)
declare ptr @mlf_native_io(ptr, ptr)
declare void @mlf_bounds_failure() noreturn
declare ptr @mlf_primitive(i64)
declare ptr @mlf_prim1(i64, ptr)
declare ptr @mlf_prim2(i64, ptr, ptr)
declare i64 @mlf_truth(ptr)
declare ptr @mlf_prim3(i64, ptr, ptr, ptr)
declare ptr @mlf_force(ptr)
declare ptr @mlf_add_int(ptr, ptr)
declare ptr @mlf_sub_int(ptr, ptr)
declare ptr @mlf_eq_int(ptr, ptr)
declare ptr @mlf_lt_int(ptr, ptr)
declare ptr @mlf_constructor(i64, i64)
declare ptr @mlf_constructor1(i64, ptr)
declare ptr @mlf_constructor2(i64, ptr, ptr)
declare ptr @mlf_constructor_fields(i64, ptr)
declare ptr @mlf_constructor_new(i64, i64)
declare ptr @mlf_field(ptr, i64)
declare void @mlf_match_failure() noreturn
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare i32 @mlf_run(ptr, i64)

@mlf_constructor_pending = external global [33 x ptr]
declare ptr @mlf_constructor_allocate(i64, i64)
define private ptr @mlf.allocate.constructor(i64 %identity, i64 %count, i64 %size) alwaysinline {
entry:
  %small = icmp ule i64 %size, 256
  br i1 %small, label %batch, label %slow
batch:
  %index = lshr i64 %size, 3
  %slot = getelementptr [33 x ptr], ptr @mlf_constructor_pending, i64 0, i64 %index
  %value = load ptr, ptr %slot, align 8
  %empty = icmp eq ptr %value, null
  br i1 %empty, label %slow, label %ready
ready:
  %next = load ptr, ptr %value, align 8
  store ptr %next, ptr %slot, align 8
  store i64 0, ptr %value, align 8
  ret ptr %value
slow:
  %allocated = call ptr @mlf_constructor_allocate(i64 %identity, i64 %count)
  ret ptr %allocated
}
define private ptr @mlf.construct.1(i64 %identity, ptr %a) alwaysinline {
entry:
  %value = call ptr @mlf.allocate.constructor(i64 %identity, i64 1, i64 24)
  store i32 12, ptr %value, align 4
  %id = getelementptr i8, ptr %value, i64 8
  store i64 %identity, ptr %id, align 8
  %first = getelementptr i8, ptr %value, i64 16
  store ptr %a, ptr %first, align 8
  ret ptr %value
}
define private ptr @mlf.construct.2(i64 %identity, ptr %a, ptr %b) alwaysinline {
entry:
  %value = call ptr @mlf.allocate.constructor(i64 %identity, i64 2, i64 32)
  store i32 13, ptr %value, align 4
  %id = getelementptr i8, ptr %value, i64 8
  store i64 %identity, ptr %id, align 8
  %first = getelementptr i8, ptr %value, i64 16
  store ptr %a, ptr %first, align 8
  %second = getelementptr i8, ptr %value, i64 24
  store ptr %b, ptr %second, align 8
  ret ptr %value
}
define private ptr @mlf.construct.wide(i64 %identity, i64 %count) alwaysinline {
entry:
  %fields = mul i64 %count, 8
  %size = add i64 %fields, 24
  %value = call ptr @mlf.allocate.constructor(i64 %identity, i64 %count, i64 %size)
  store i32 28, ptr %value, align 4
  %id = getelementptr i8, ptr %value, i64 8
  store i64 %identity, ptr %id, align 8
  %arity = getelementptr i8, ptr %value, i64 16
  store i64 %count, ptr %arity, align 8
  ret ptr %value
}
@mlf_compact_pending = external global [17 x ptr]
define private ptr @mlf.allocate.thunk(ptr %code, i64 %count) alwaysinline {
entry:
  %words = add i64 %count, 4
  %index = lshr i64 %words, 1
  %slot = getelementptr [17 x ptr], ptr @mlf_compact_pending, i64 0, i64 %index
  %value = load ptr, ptr %slot, align 8
  %empty = icmp eq ptr %value, null
  br i1 %empty, label %slow, label %ready
ready:
  %next = load ptr, ptr %value, align 8
  store ptr %next, ptr %slot, align 8
  store i64 3, ptr %value, align 8
  %function = getelementptr i8, ptr %value, i64 8
  store ptr %code, ptr %function, align 8
  %environment = getelementptr i8, ptr %value, i64 24
  %capture = getelementptr i8, ptr %value, i64 16
  store ptr %environment, ptr %capture, align 8
  store i64 %count, ptr %environment, align 8
  ret ptr %value
slow:
  %allocated = call ptr @mlf_thunk_new(ptr %code, i64 %count)
  ret ptr %allocated
}
define private ptr @mlf.force(ptr %value) alwaysinline {
entry:
  %null = icmp eq ptr %value, null
  br i1 %null, label %slow, label %test
test:
  %bits = ptrtoint ptr %value to i64
  %kind = and i64 %bits, 7
  %immediate = icmp ne i64 %kind, 0
  br i1 %immediate, label %done, label %tagged
tagged:
  %tag = load i32, ptr %value, align 4
  %ready = icmp uge i32 %tag, 5
  br i1 %ready, label %done, label %deferred
deferred:
  %isthunk = icmp eq i32 %tag, 3
  br i1 %isthunk, label %enter, label %indirect
indirect:
  %forwarded = icmp eq i32 %tag, 2
  br i1 %forwarded, label %next, label %slow
next:
  %slot = getelementptr i8, ptr %value, i64 8
  %p = load ptr, ptr %slot, align 8
  %missing = icmp eq ptr %p, null
  br i1 %missing, label %slow, label %nexttest
nexttest:
  %pbits = ptrtoint ptr %p to i64
  %pkind = and i64 %pbits, 7
  %pimm = icmp ne i64 %pkind, 0
  br i1 %pimm, label %forward, label %ptagged
ptagged:
  %ptag = load i32, ptr %p, align 4
  %pready = icmp uge i32 %ptag, 5
  br i1 %pready, label %forward, label %slow
forward:
  ret ptr %p
done:
  ret ptr %value
enter:
  %code.slot = getelementptr i8, ptr %value, i64 8
  %env.slot = getelementptr i8, ptr %value, i64 16
  %code = load ptr, ptr %code.slot, align 8
  %env = load ptr, ptr %env.slot, align 8
  store i32 1, ptr %value, align 4
  store ptr null, ptr %code.slot, align 8
  store ptr null, ptr %env.slot, align 8
  %returned = call ptr %code(ptr %env, ptr null)
  %canonical = call ptr @mlf_force(ptr %returned)
  store i32 2, ptr %value, align 4
  store ptr %canonical, ptr %code.slot, align 8
  ret ptr %canonical
slow:
  %result = tail call ptr @mlf_force(ptr %value)
  ret ptr %result
}
!0 = !{!"MLF storage"}
!1 = !{!"managed object", !0}
!2 = !{!"array cells", !0}
!3 = !{!1, !1, i64 0}
!4 = !{!2, !2, i64 0}
define private ptr @mlf.code.3(ptr %env, ptr %arg) {
entry:
  %v4 = getelementptr i8, ptr %env, i64 8
  %v5 = load ptr, ptr %v4, align 8, !tbaa !3
  %v6 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v6, align 8, !tbaa !3
  %v7 = call ptr @mlf.force(ptr %v5)
  %v8 = call ptr @mlf_prim1(i64 17, ptr %v7)
  ret ptr %v8
}

define private ptr @mlf.code.13(ptr %env, ptr %arg) {
entry:
  %v14 = getelementptr i8, ptr %env, i64 8
  %v15 = load ptr, ptr %v14, align 8, !tbaa !3
  %v16 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v16, align 8, !tbaa !3
  %v17 = call ptr @mlf_double(double 0x3ff0000000000000)
  %v18 = call ptr @mlf_prim2(i64 31, ptr %v15, ptr %v17)
  ret ptr %v18
}

define private ptr @mlf.code.26(ptr %env, ptr %arg) {
entry:
  %v27 = getelementptr i8, ptr %env, i64 8
  %v28 = load ptr, ptr %v27, align 8, !tbaa !3
  %v29 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v29, align 8, !tbaa !3
  %v30 = call ptr @mlf_double(double 0x0000000000000000)
  %v31 = call ptr @mlf_prim2(i64 31, ptr %v28, ptr %v30)
  ret ptr %v31
}

define private ptr @mlf.code.41(ptr %env, ptr %arg) {
entry:
  %v42 = getelementptr i8, ptr %env, i64 8
  %v43 = load ptr, ptr %v42, align 8, !tbaa !3
  %v44 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v44, align 8, !tbaa !3
  %v45 = call ptr @mlf_double(double 0x0000000000000000)
  %v46 = call ptr @mlf_prim2(i64 31, ptr %v43, ptr %v45)
  ret ptr %v46
}

define private ptr @mlf.code.58(ptr %env, ptr %arg) {
entry:
  %v59 = call ptr @mlf_double(double 0x0000000000000000)
  %v60 = call ptr @mlf_prim2(i64 31, ptr inttoptr (i64 5 to ptr), ptr %v59)
  ret ptr %v60
}

define private ptr @mlf.code.127(ptr %env, ptr %arg) {
entry:
  %v128 = getelementptr i8, ptr %env, i64 8
  %v129 = load ptr, ptr %v128, align 8, !tbaa !3
  %v130 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v130, align 8, !tbaa !3
  %v131 = call ptr @mlf.force(ptr %v129)
  %v132 = ptrtoint ptr %v131 to i64
  %v133 = and i64 %v132, 7
  %v134 = icmp eq i64 %v133, 4
  br i1 %v134, label %yes.135, label %no.136
yes.135:
  %v138 = lshr i64 %v132, 3
  br label %join.137
no.136:
  %v139 = getelementptr i8, ptr %v131, i64 8
  %v140 = load i64, ptr %v139, align 8, !tbaa !3
  br label %join.137
join.137:
  %v141 = phi i64 [ %v138, %yes.135 ], [ %v140, %no.136 ]
  switch i64 %v141, label %case.missing.143 [
    i64 1, label %case.142
  ]
case.142:
  %v145 = getelementptr i8, ptr %v131, i64 24
  %v146 = load ptr, ptr %v145, align 8, !tbaa !3
  br label %case.join.144
case.missing.143:
  call void @mlf_match_failure()
  unreachable
case.join.144:
  %v147 = phi ptr [ %v146, %case.142 ]
  ret ptr %v147
}

define private ptr @mlf.numeric.6.pppppd(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, double %a5) alwaysinline {
entry:
  %v201 = ptrtoint ptr %a4 to i64
  %v202 = ptrtoint ptr %a0 to i64
  %v203 = and i64 %v201, %v202
  %v204 = and i64 %v203, 1
  %v205 = icmp ne i64 %v204, 0
  br i1 %v205, label %yes.206, label %no.207
yes.206:
  %v209 = icmp slt i64 %v201, %v202
  %v210 = select i1 %v209, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.208
no.207:
  %v211 = call ptr @mlf_lt_int(ptr %a4, ptr %a0)
  br label %join.208
join.208:
  %v212 = phi ptr [ %v210, %yes.206 ], [ %v211, %no.207 ]
  %v213 = icmp eq ptr %v212, inttoptr (i64 6 to ptr)
  br i1 %v213, label %tail.yes.214, label %tail.no.215
tail.yes.214:
  %v216 = getelementptr i8, ptr %a1, i64 8
  %v217 = load i64, ptr %v216, align 8, !tbaa !3
  %v218 = getelementptr i8, ptr %a1, i64 16
  %v219 = load ptr, ptr %v218, align 8, !tbaa !3
  %v220 = ptrtoint ptr %a4 to i64
  %v221 = ashr i64 %v220, 1
  %v222 = and i64 %v220, 1
  %v223 = icmp ne i64 %v222, 0
  %v224 = icmp ult i64 %v221, %v217
  %v225 = and i1 %v223, %v224
  br i1 %v225, label %array.valid.226, label %array.invalid.227
array.invalid.227:
  call void @mlf_bounds_failure()
  unreachable
array.valid.226:
  %v228 = getelementptr i64, ptr %v219, i64 %v221
  %v229 = load double, ptr %v228, align 8, !tbaa !4
  %v230 = ptrtoint ptr %a4 to i64
  %v231 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v232 = sub i64 %v231, 1
  %v233 = add nsw i64 %v230, %v232
  %v234 = inttoptr i64 %v233 to ptr
  %v235 = ptrtoint ptr %a3 to i64
  %v236 = and i64 %v235, 1
  %v237 = icmp ne i64 %v236, 0
  br i1 %v237, label %yes.238, label %no.239
yes.238:
  %v241 = ashr i64 %v235, 1
  %v242 = sitofp i64 %v241 to double
  br label %join.240
no.239:
  %v243 = call double @mlf_int_to_double(ptr %a3)
  br label %join.240
join.240:
  %v244 = phi double [ %v242, %yes.238 ], [ %v243, %no.239 ]
  %v245 = ptrtoint ptr %a4 to i64
  %v246 = and i64 %v245, 1
  %v247 = icmp ne i64 %v246, 0
  br i1 %v247, label %yes.248, label %no.249
yes.248:
  %v251 = ashr i64 %v245, 1
  %v252 = sitofp i64 %v251 to double
  br label %join.250
no.249:
  %v253 = call double @mlf_int_to_double(ptr %a4)
  br label %join.250
join.250:
  %v254 = phi double [ %v252, %yes.248 ], [ %v253, %no.249 ]
  %v255 = fadd double %v244, %v254
  %v256 = fadd double %v255, 0x3ff0000000000000
  %v257 = fmul double %v255, %v256
  %v258 = fdiv double %v257, 0x4000000000000000
  %v259 = fadd double %v258, %v244
  %v260 = fadd double %v259, 0x3ff0000000000000
  %v261 = fdiv double 0x3ff0000000000000, %v260
  %v262 = fmul double %v261, %v229
  %v263 = fadd double %a5, %v262
  %v264 = musttail call ptr @mlf.numeric.6.pppppd(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %v234, double %v263)
  ret ptr %v264
tail.no.215:
  %v265 = getelementptr i8, ptr %a2, i64 8
  %v266 = load i64, ptr %v265, align 8, !tbaa !3
  %v267 = getelementptr i8, ptr %a2, i64 16
  %v268 = load ptr, ptr %v267, align 8, !tbaa !3
  %v269 = ptrtoint ptr %a3 to i64
  %v270 = ashr i64 %v269, 1
  %v271 = and i64 %v269, 1
  %v272 = icmp ne i64 %v271, 0
  %v273 = icmp ult i64 %v270, %v266
  %v274 = and i1 %v272, %v273
  br i1 %v274, label %array.valid.275, label %array.invalid.276
array.invalid.276:
  call void @mlf_bounds_failure()
  unreachable
array.valid.275:
  %v277 = getelementptr i64, ptr %v268, i64 %v270
  store double %a5, ptr %v277, align 8, !tbaa !4
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.numeric.22(ptr %a0, ptr %a1, ptr %a2, ptr %a3) alwaysinline {
entry:
  %v186 = ptrtoint ptr %a3 to i64
  %v187 = ptrtoint ptr %a0 to i64
  %v188 = and i64 %v186, %v187
  %v189 = and i64 %v188, 1
  %v190 = icmp ne i64 %v189, 0
  br i1 %v190, label %yes.191, label %no.192
yes.191:
  %v194 = icmp slt i64 %v186, %v187
  %v195 = select i1 %v194, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.193
no.192:
  %v196 = call ptr @mlf_lt_int(ptr %a3, ptr %a0)
  br label %join.193
join.193:
  %v197 = phi ptr [ %v195, %yes.191 ], [ %v196, %no.192 ]
  %v198 = icmp eq ptr %v197, inttoptr (i64 6 to ptr)
  br i1 %v198, label %tail.yes.199, label %tail.no.200
tail.yes.199:
  %v278 = call ptr @mlf.numeric.6.pppppd(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr inttoptr (i64 1 to ptr), double 0x0000000000000000)
  %v279 = ptrtoint ptr %a3 to i64
  %v280 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v281 = and i64 %v279, %v280
  %v282 = and i64 %v281, 1
  %v283 = icmp ne i64 %v282, 0
  br i1 %v283, label %yes.284, label %no.285
yes.284:
  %v287 = sub i64 %v280, 1
  %v288 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v279, i64 %v287)
  %v289 = extractvalue { i64, i1 } %v288, 0
  %v290 = extractvalue { i64, i1 } %v288, 1
  br i1 %v290, label %yes.291, label %no.292
yes.291:
  %v294 = call ptr @mlf_add_int(ptr %a3, ptr inttoptr (i64 3 to ptr))
  br label %join.293
no.292:
  %v295 = inttoptr i64 %v289 to ptr
  br label %join.293
join.293:
  %v296 = phi ptr [ %v294, %yes.291 ], [ %v295, %no.292 ]
  br label %join.286
no.285:
  %v297 = call ptr @mlf_add_int(ptr %a3, ptr inttoptr (i64 3 to ptr))
  br label %join.286
join.286:
  %v298 = phi ptr [ %v296, %join.293 ], [ %v297, %no.285 ]
  %v299 = musttail call ptr @mlf.numeric.22(ptr %a0, ptr %a1, ptr %a2, ptr %v298)
  ret ptr %v299
tail.no.200:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.numeric.6(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5) alwaysinline {
entry:
  %v354 = ptrtoint ptr %a4 to i64
  %v355 = ptrtoint ptr %a0 to i64
  %v356 = and i64 %v354, %v355
  %v357 = and i64 %v356, 1
  %v358 = icmp ne i64 %v357, 0
  br i1 %v358, label %yes.359, label %no.360
yes.359:
  %v362 = icmp slt i64 %v354, %v355
  %v363 = select i1 %v362, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.361
no.360:
  %v364 = call ptr @mlf_lt_int(ptr %a4, ptr %a0)
  br label %join.361
join.361:
  %v365 = phi ptr [ %v363, %yes.359 ], [ %v364, %no.360 ]
  %v366 = icmp eq ptr %v365, inttoptr (i64 6 to ptr)
  br i1 %v366, label %tail.yes.367, label %tail.no.368
tail.yes.367:
  %v369 = getelementptr i8, ptr %a1, i64 8
  %v370 = load i64, ptr %v369, align 8, !tbaa !3
  %v371 = getelementptr i8, ptr %a1, i64 16
  %v372 = load ptr, ptr %v371, align 8, !tbaa !3
  %v373 = ptrtoint ptr %a4 to i64
  %v374 = ashr i64 %v373, 1
  %v375 = and i64 %v373, 1
  %v376 = icmp ne i64 %v375, 0
  %v377 = icmp ult i64 %v374, %v370
  %v378 = and i1 %v376, %v377
  br i1 %v378, label %array.valid.379, label %array.invalid.380
array.invalid.380:
  call void @mlf_bounds_failure()
  unreachable
array.valid.379:
  %v381 = getelementptr i64, ptr %v372, i64 %v374
  %v382 = load double, ptr %v381, align 8, !tbaa !4
  %v383 = ptrtoint ptr %a4 to i64
  %v384 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v385 = sub i64 %v384, 1
  %v386 = add nsw i64 %v383, %v385
  %v387 = inttoptr i64 %v386 to ptr
  %v388 = ptrtoint ptr %a3 to i64
  %v389 = and i64 %v388, 1
  %v390 = icmp ne i64 %v389, 0
  br i1 %v390, label %yes.391, label %no.392
yes.391:
  %v394 = ashr i64 %v388, 1
  %v395 = sitofp i64 %v394 to double
  br label %join.393
no.392:
  %v396 = call double @mlf_int_to_double(ptr %a3)
  br label %join.393
join.393:
  %v397 = phi double [ %v395, %yes.391 ], [ %v396, %no.392 ]
  %v398 = ptrtoint ptr %a4 to i64
  %v399 = and i64 %v398, 1
  %v400 = icmp ne i64 %v399, 0
  br i1 %v400, label %yes.401, label %no.402
yes.401:
  %v404 = ashr i64 %v398, 1
  %v405 = sitofp i64 %v404 to double
  br label %join.403
no.402:
  %v406 = call double @mlf_int_to_double(ptr %a4)
  br label %join.403
join.403:
  %v407 = phi double [ %v405, %yes.401 ], [ %v406, %no.402 ]
  %v408 = fadd double %v397, %v407
  %v409 = fadd double %v408, 0x3ff0000000000000
  %v410 = fmul double %v408, %v409
  %v411 = fdiv double %v410, 0x4000000000000000
  %v412 = fadd double %v411, %v397
  %v413 = fadd double %v412, 0x3ff0000000000000
  %v414 = fdiv double 0x3ff0000000000000, %v413
  %v415 = fmul double %v414, %v382
  %v416 = getelementptr i8, ptr %a5, i64 8
  %v417 = load double, ptr %v416, align 8, !tbaa !3
  %v418 = fadd double %v417, %v415
  %v419 = call ptr @mlf.numeric.6.pppppd(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %v387, double %v418)
  ret ptr %v419
tail.no.368:
  %v420 = getelementptr i8, ptr %a2, i64 8
  %v421 = load i64, ptr %v420, align 8, !tbaa !3
  %v422 = getelementptr i8, ptr %a2, i64 16
  %v423 = load ptr, ptr %v422, align 8, !tbaa !3
  %v424 = ptrtoint ptr %a3 to i64
  %v425 = ashr i64 %v424, 1
  %v426 = and i64 %v424, 1
  %v427 = icmp ne i64 %v426, 0
  %v428 = icmp ult i64 %v425, %v421
  %v429 = and i1 %v427, %v428
  br i1 %v429, label %array.valid.430, label %array.invalid.431
array.invalid.431:
  call void @mlf_bounds_failure()
  unreachable
array.valid.430:
  %v432 = getelementptr i64, ptr %v423, i64 %v425
  %v433 = getelementptr i8, ptr %a5, i64 8
  %v434 = load double, ptr %v433, align 8, !tbaa !3
  store double %v434, ptr %v432, align 8, !tbaa !4
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.code.442(ptr %env, ptr %arg) {
entry:
  %v443 = getelementptr i8, ptr %env, i64 8
  %v444 = load ptr, ptr %v443, align 8, !tbaa !3
  %v445 = getelementptr i8, ptr %env, i64 16
  %v446 = load ptr, ptr %v445, align 8, !tbaa !3
  %v447 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v447, align 8, !tbaa !3
  %v448 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v448, align 8, !tbaa !3
  %v449 = call ptr @mlf_prim2(i64 32, ptr %v444, ptr %v446)
  ret ptr %v449
}

define private ptr @mlf.worker.0(ptr %a0, ptr %a1) {
entry:
  %v485 = call ptr @mlf_prim1(i64 25, ptr %a0)
  %v486 = call ptr @mlf_prim1(i64 25, ptr %a1)
  %v487 = call ptr @mlf_prim2(i64 18, ptr %v485, ptr %v486)
  %v488 = call ptr @mlf_double(double 0x3ff0000000000000)
  %v489 = call ptr @mlf_double(double 0x3ff0000000000000)
  %v490 = call ptr @mlf_prim2(i64 18, ptr %v487, ptr %v489)
  %v491 = call ptr @mlf_prim2(i64 20, ptr %v487, ptr %v490)
  %v492 = call ptr @mlf_double(double 0x4000000000000000)
  %v493 = call ptr @mlf_prim2(i64 21, ptr %v491, ptr %v492)
  %v494 = call ptr @mlf_prim2(i64 18, ptr %v493, ptr %v485)
  %v495 = call ptr @mlf_double(double 0x3ff0000000000000)
  %v496 = call ptr @mlf_prim2(i64 18, ptr %v494, ptr %v495)
  %v497 = call ptr @mlf_prim2(i64 21, ptr %v488, ptr %v496)
  ret ptr %v497
}

define private ptr @mlf.code.471(ptr %env, ptr %arg) {
entry:
  %v472 = getelementptr i8, ptr %env, i64 8
  %v473 = load ptr, ptr %v472, align 8, !tbaa !3
  %v474 = getelementptr i8, ptr %env, i64 16
  %v475 = load ptr, ptr %v474, align 8, !tbaa !3
  %v476 = getelementptr i8, ptr %env, i64 24
  %v477 = load ptr, ptr %v476, align 8, !tbaa !3
  %v478 = getelementptr i8, ptr %env, i64 32
  %v479 = load ptr, ptr %v478, align 8, !tbaa !3
  %v480 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v480, align 8, !tbaa !3
  %v481 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v481, align 8, !tbaa !3
  %v482 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v482, align 8, !tbaa !3
  %v483 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v483, align 8, !tbaa !3
  %v484 = call ptr @mlf.force(ptr %v477)
  %v498 = call ptr @mlf.force(ptr %v473)
  %v499 = call ptr @mlf.force(ptr %v475)
  %v500 = call ptr @mlf.worker.0(ptr %v498, ptr %v499)
  %v501 = call ptr @mlf.force(ptr %v479)
  %v502 = call ptr @mlf_prim2(i64 20, ptr %v500, ptr %v501)
  %v503 = call ptr @mlf_prim2(i64 18, ptr %v484, ptr %v502)
  ret ptr %v503
}

define private ptr @mlf.code.455(ptr %env, ptr %arg) {
entry:
  %v456 = getelementptr i8, ptr %env, i64 8
  %v457 = load ptr, ptr %v456, align 8, !tbaa !3
  %v458 = getelementptr i8, ptr %env, i64 16
  %v459 = load ptr, ptr %v458, align 8, !tbaa !3
  %v460 = getelementptr i8, ptr %env, i64 24
  %v461 = load ptr, ptr %v460, align 8, !tbaa !3
  %v462 = getelementptr i8, ptr %env, i64 32
  %v463 = load ptr, ptr %v462, align 8, !tbaa !3
  %v464 = getelementptr i8, ptr %env, i64 40
  %v465 = load ptr, ptr %v464, align 8, !tbaa !3
  %v466 = getelementptr i8, ptr %env, i64 48
  %v467 = load ptr, ptr %v466, align 8, !tbaa !3
  %v468 = call ptr @mlf.force(ptr %v457)
  %v469 = call ptr @mlf.force(ptr %v465)
  %v470 = call ptr @mlf_prim2(i64 8, ptr %v469, ptr inttoptr (i64 3 to ptr))
  %v504 = call ptr @mlf.allocate.thunk(ptr @mlf.code.471, i64 4)
  %v505 = getelementptr i8, ptr %v504, i64 16
  %v506 = load ptr, ptr %v505, align 8, !tbaa !3
  %v507 = getelementptr i8, ptr %v506, i64 8
  store ptr %v463, ptr %v507, align 8, !tbaa !3
  %v508 = getelementptr i8, ptr %v506, i64 16
  store ptr %v469, ptr %v508, align 8, !tbaa !3
  %v509 = getelementptr i8, ptr %v506, i64 24
  store ptr %v467, ptr %v509, align 8, !tbaa !3
  %v510 = getelementptr i8, ptr %v506, i64 32
  store ptr %arg, ptr %v510, align 8, !tbaa !3
  %v511 = call ptr @mlf_env_new(i64 6)
  %v512 = getelementptr i8, ptr %v511, i64 8
  store ptr %v468, ptr %v512, align 8, !tbaa !3
  %v513 = getelementptr i8, ptr %v511, i64 16
  store ptr %v459, ptr %v513, align 8, !tbaa !3
  %v514 = getelementptr i8, ptr %v511, i64 24
  store ptr %v461, ptr %v514, align 8, !tbaa !3
  %v515 = getelementptr i8, ptr %v511, i64 32
  store ptr %v463, ptr %v515, align 8, !tbaa !3
  %v516 = getelementptr i8, ptr %v511, i64 40
  store ptr %v470, ptr %v516, align 8, !tbaa !3
  %v517 = getelementptr i8, ptr %v511, i64 48
  store ptr %v504, ptr %v517, align 8, !tbaa !3
  %v518 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.320, ptr %v511)
  ret ptr %v518
}

define private ptr @mlf.worker.6(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5) {
entry:
  %v437 = call ptr @mlf_prim2(i64 11, ptr %a4, ptr %a0)
  %v438 = icmp eq ptr %v437, inttoptr (i64 6 to ptr)
  br i1 %v438, label %yes.439, label %no.440
yes.439:
  %v450 = call ptr @mlf.allocate.thunk(ptr @mlf.code.442, i64 2)
  %v451 = getelementptr i8, ptr %v450, i64 16
  %v452 = load ptr, ptr %v451, align 8, !tbaa !3
  %v453 = getelementptr i8, ptr %v452, i64 8
  store ptr %a1, ptr %v453, align 8, !tbaa !3
  %v454 = getelementptr i8, ptr %v452, i64 16
  store ptr %a4, ptr %v454, align 8, !tbaa !3
  %v519 = call ptr @mlf_env_new(i64 6)
  %v520 = getelementptr i8, ptr %v519, i64 8
  store ptr %a0, ptr %v520, align 8, !tbaa !3
  %v521 = getelementptr i8, ptr %v519, i64 16
  store ptr %a1, ptr %v521, align 8, !tbaa !3
  %v522 = getelementptr i8, ptr %v519, i64 24
  store ptr %a2, ptr %v522, align 8, !tbaa !3
  %v523 = getelementptr i8, ptr %v519, i64 32
  store ptr %a3, ptr %v523, align 8, !tbaa !3
  %v524 = getelementptr i8, ptr %v519, i64 40
  store ptr %a4, ptr %v524, align 8, !tbaa !3
  %v525 = getelementptr i8, ptr %v519, i64 48
  store ptr %a5, ptr %v525, align 8, !tbaa !3
  %v526 = call ptr @mlf_closure(ptr @mlf.code.455, ptr %v519)
  %v527 = call ptr @mlf_prim2(i64 1, ptr %v450, ptr %v526)
  br label %join.441
no.440:
  %v528 = call ptr @mlf_prim3(i64 33, ptr %a2, ptr %a3, ptr %a5)
  br label %join.441
join.441:
  %v529 = phi ptr [ %v527, %yes.439 ], [ %v528, %no.440 ]
  ret ptr %v529
}

define private ptr @mlf.numeric.entry.320(ptr %env, ptr %arg) {
entry:
  %v321 = getelementptr i8, ptr %env, i64 8
  %v322 = load ptr, ptr %v321, align 8, !tbaa !3
  %v323 = getelementptr i8, ptr %env, i64 16
  %v324 = load ptr, ptr %v323, align 8, !tbaa !3
  %v325 = getelementptr i8, ptr %env, i64 24
  %v326 = load ptr, ptr %v325, align 8, !tbaa !3
  %v327 = getelementptr i8, ptr %env, i64 32
  %v328 = load ptr, ptr %v327, align 8, !tbaa !3
  %v329 = getelementptr i8, ptr %env, i64 40
  %v330 = load ptr, ptr %v329, align 8, !tbaa !3
  %v331 = getelementptr i8, ptr %env, i64 48
  %v332 = load ptr, ptr %v331, align 8, !tbaa !3
  %v333 = call ptr @mlf_peek(ptr %v322)
  %v334 = call ptr @mlf_peek(ptr %v324)
  %v335 = call ptr @mlf_peek(ptr %v326)
  %v336 = call ptr @mlf_peek(ptr %v328)
  %v337 = call ptr @mlf_peek(ptr %v330)
  %v338 = call ptr @mlf_peek(ptr %v332)
  %v339 = icmp ne ptr %v333, null
  %v340 = icmp ne ptr %v334, null
  %v341 = icmp ne ptr %v335, null
  %v342 = icmp ne ptr %v336, null
  %v343 = icmp ne ptr %v337, null
  %v344 = icmp ne ptr %v338, null
  %v345 = and i1 true, %v339
  %v346 = and i1 %v345, %v340
  %v347 = and i1 %v346, %v341
  %v348 = and i1 %v347, %v342
  %v349 = and i1 %v348, %v343
  %v350 = and i1 %v349, %v344
  br i1 %v350, label %yes.351, label %no.352
yes.351:
  %v435 = call ptr @mlf.numeric.6(ptr %v333, ptr %v334, ptr %v335, ptr %v336, ptr %v337, ptr %v338)
  %v436 = call ptr @mlf_prim1(i64 0, ptr %v435)
  br label %join.353
no.352:
  %v530 = call ptr @mlf.force(ptr %v322)
  %v531 = call ptr @mlf.force(ptr %v330)
  %v532 = call ptr @mlf.worker.6(ptr %v530, ptr %v324, ptr %v326, ptr %v328, ptr %v531, ptr %v332)
  br label %join.353
join.353:
  %v533 = phi ptr [ %v436, %yes.351 ], [ %v532, %no.352 ]
  ret ptr %v533
}

define private ptr @mlf.code.307(ptr %env, ptr %arg) {
entry:
  %v308 = getelementptr i8, ptr %env, i64 8
  %v309 = load ptr, ptr %v308, align 8, !tbaa !3
  %v310 = getelementptr i8, ptr %env, i64 16
  %v311 = load ptr, ptr %v310, align 8, !tbaa !3
  %v312 = getelementptr i8, ptr %env, i64 24
  %v313 = load ptr, ptr %v312, align 8, !tbaa !3
  %v314 = getelementptr i8, ptr %env, i64 32
  %v315 = load ptr, ptr %v314, align 8, !tbaa !3
  %v316 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v316, align 8, !tbaa !3
  %v317 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v317, align 8, !tbaa !3
  %v318 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v318, align 8, !tbaa !3
  %v319 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v319, align 8, !tbaa !3
  %v534 = call ptr @mlf.force(ptr %v309)
  %v535 = call ptr @mlf_double(double 0x0000000000000000)
  %v536 = call ptr @mlf_env_new(i64 6)
  %v537 = getelementptr i8, ptr %v536, i64 8
  store ptr %v534, ptr %v537, align 8, !tbaa !3
  %v538 = getelementptr i8, ptr %v536, i64 16
  store ptr %v311, ptr %v538, align 8, !tbaa !3
  %v539 = getelementptr i8, ptr %v536, i64 24
  store ptr %v313, ptr %v539, align 8, !tbaa !3
  %v540 = getelementptr i8, ptr %v536, i64 32
  store ptr %v315, ptr %v540, align 8, !tbaa !3
  %v541 = getelementptr i8, ptr %v536, i64 40
  store ptr inttoptr (i64 1 to ptr), ptr %v541, align 8, !tbaa !3
  %v542 = getelementptr i8, ptr %v536, i64 48
  store ptr %v535, ptr %v542, align 8, !tbaa !3
  %v543 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.320, ptr %v536)
  ret ptr %v543
}

define private ptr @mlf.code.551(ptr %env, ptr %arg) {
entry:
  %v552 = getelementptr i8, ptr %env, i64 8
  %v553 = load ptr, ptr %v552, align 8, !tbaa !3
  %v554 = getelementptr i8, ptr %env, i64 16
  %v555 = load ptr, ptr %v554, align 8, !tbaa !3
  %v556 = getelementptr i8, ptr %env, i64 24
  %v557 = load ptr, ptr %v556, align 8, !tbaa !3
  %v558 = getelementptr i8, ptr %env, i64 32
  %v559 = load ptr, ptr %v558, align 8, !tbaa !3
  %v560 = call ptr @mlf.force(ptr %v553)
  %v561 = call ptr @mlf.force(ptr %v559)
  %v562 = call ptr @mlf_prim2(i64 8, ptr %v561, ptr inttoptr (i64 3 to ptr))
  %v563 = call ptr @mlf_env_new(i64 4)
  %v564 = getelementptr i8, ptr %v563, i64 8
  store ptr %v560, ptr %v564, align 8, !tbaa !3
  %v565 = getelementptr i8, ptr %v563, i64 16
  store ptr %v555, ptr %v565, align 8, !tbaa !3
  %v566 = getelementptr i8, ptr %v563, i64 24
  store ptr %v557, ptr %v566, align 8, !tbaa !3
  %v567 = getelementptr i8, ptr %v563, i64 32
  store ptr %v562, ptr %v567, align 8, !tbaa !3
  %v568 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.162, ptr %v563)
  ret ptr %v568
}

define private ptr @mlf.worker.22(ptr %a0, ptr %a1, ptr %a2, ptr %a3) {
entry:
  %v302 = call ptr @mlf_prim2(i64 11, ptr %a3, ptr %a0)
  %v303 = icmp eq ptr %v302, inttoptr (i64 6 to ptr)
  br i1 %v303, label %yes.304, label %no.305
yes.304:
  %v544 = call ptr @mlf.allocate.thunk(ptr @mlf.code.307, i64 4)
  %v545 = getelementptr i8, ptr %v544, i64 16
  %v546 = load ptr, ptr %v545, align 8, !tbaa !3
  %v547 = getelementptr i8, ptr %v546, i64 8
  store ptr %a0, ptr %v547, align 8, !tbaa !3
  %v548 = getelementptr i8, ptr %v546, i64 16
  store ptr %a1, ptr %v548, align 8, !tbaa !3
  %v549 = getelementptr i8, ptr %v546, i64 24
  store ptr %a2, ptr %v549, align 8, !tbaa !3
  %v550 = getelementptr i8, ptr %v546, i64 32
  store ptr %a3, ptr %v550, align 8, !tbaa !3
  %v569 = call ptr @mlf_env_new(i64 4)
  %v570 = getelementptr i8, ptr %v569, i64 8
  store ptr %a0, ptr %v570, align 8, !tbaa !3
  %v571 = getelementptr i8, ptr %v569, i64 16
  store ptr %a1, ptr %v571, align 8, !tbaa !3
  %v572 = getelementptr i8, ptr %v569, i64 24
  store ptr %a2, ptr %v572, align 8, !tbaa !3
  %v573 = getelementptr i8, ptr %v569, i64 32
  store ptr %a3, ptr %v573, align 8, !tbaa !3
  %v574 = call ptr @mlf_closure(ptr @mlf.code.551, ptr %v569)
  %v575 = call ptr @mlf_prim2(i64 1, ptr %v544, ptr %v574)
  br label %join.306
no.305:
  %v576 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.306
join.306:
  %v577 = phi ptr [ %v575, %yes.304 ], [ %v576, %no.305 ]
  ret ptr %v577
}

define private ptr @mlf.numeric.entry.162(ptr %env, ptr %arg) {
entry:
  %v163 = getelementptr i8, ptr %env, i64 8
  %v164 = load ptr, ptr %v163, align 8, !tbaa !3
  %v165 = getelementptr i8, ptr %env, i64 16
  %v166 = load ptr, ptr %v165, align 8, !tbaa !3
  %v167 = getelementptr i8, ptr %env, i64 24
  %v168 = load ptr, ptr %v167, align 8, !tbaa !3
  %v169 = getelementptr i8, ptr %env, i64 32
  %v170 = load ptr, ptr %v169, align 8, !tbaa !3
  %v171 = call ptr @mlf_peek(ptr %v164)
  %v172 = call ptr @mlf_peek(ptr %v166)
  %v173 = call ptr @mlf_peek(ptr %v168)
  %v174 = call ptr @mlf_peek(ptr %v170)
  %v175 = icmp ne ptr %v171, null
  %v176 = icmp ne ptr %v172, null
  %v177 = icmp ne ptr %v173, null
  %v178 = icmp ne ptr %v174, null
  %v179 = and i1 true, %v175
  %v180 = and i1 %v179, %v176
  %v181 = and i1 %v180, %v177
  %v182 = and i1 %v181, %v178
  br i1 %v182, label %yes.183, label %no.184
yes.183:
  %v300 = call ptr @mlf.numeric.22(ptr %v171, ptr %v172, ptr %v173, ptr %v174)
  %v301 = call ptr @mlf_prim1(i64 0, ptr %v300)
  br label %join.185
no.184:
  %v578 = call ptr @mlf.force(ptr %v164)
  %v579 = call ptr @mlf.force(ptr %v170)
  %v580 = call ptr @mlf.worker.22(ptr %v578, ptr %v166, ptr %v168, ptr %v579)
  br label %join.185
join.185:
  %v581 = phi ptr [ %v301, %yes.183 ], [ %v580, %no.184 ]
  ret ptr %v581
}

define private ptr @mlf.code.152(ptr %env, ptr %arg) {
entry:
  %v153 = getelementptr i8, ptr %env, i64 8
  %v154 = load ptr, ptr %v153, align 8, !tbaa !3
  %v155 = getelementptr i8, ptr %env, i64 16
  %v156 = load ptr, ptr %v155, align 8, !tbaa !3
  %v157 = getelementptr i8, ptr %env, i64 24
  %v158 = load ptr, ptr %v157, align 8, !tbaa !3
  %v159 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v159, align 8, !tbaa !3
  %v160 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v160, align 8, !tbaa !3
  %v161 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v161, align 8, !tbaa !3
  %v582 = call ptr @mlf.force(ptr %v154)
  %v583 = call ptr @mlf_env_new(i64 4)
  %v584 = getelementptr i8, ptr %v583, i64 8
  store ptr %v582, ptr %v584, align 8, !tbaa !3
  %v585 = getelementptr i8, ptr %v583, i64 16
  store ptr %v156, ptr %v585, align 8, !tbaa !3
  %v586 = getelementptr i8, ptr %v583, i64 24
  store ptr %v158, ptr %v586, align 8, !tbaa !3
  %v587 = getelementptr i8, ptr %v583, i64 32
  store ptr inttoptr (i64 1 to ptr), ptr %v587, align 8, !tbaa !3
  %v588 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.162, ptr %v583)
  ret ptr %v588
}

define private ptr @mlf.code.114(ptr %env, ptr %arg) {
entry:
  %v115 = getelementptr i8, ptr %env, i64 8
  %v116 = load ptr, ptr %v115, align 8, !tbaa !3
  %v117 = getelementptr i8, ptr %env, i64 16
  %v118 = load ptr, ptr %v117, align 8, !tbaa !3
  %v119 = getelementptr i8, ptr %env, i64 24
  %v120 = load ptr, ptr %v119, align 8, !tbaa !3
  %v121 = getelementptr i8, ptr %env, i64 32
  %v122 = load ptr, ptr %v121, align 8, !tbaa !3
  %v123 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v123, align 8, !tbaa !3
  %v124 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v124, align 8, !tbaa !3
  %v125 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v125, align 8, !tbaa !3
  %v126 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v126, align 8, !tbaa !3
  %v148 = call ptr @mlf.allocate.thunk(ptr @mlf.code.127, i64 1)
  %v149 = getelementptr i8, ptr %v148, i64 16
  %v150 = load ptr, ptr %v149, align 8, !tbaa !3
  %v151 = getelementptr i8, ptr %v150, i64 8
  store ptr %v116, ptr %v151, align 8, !tbaa !3
  %v589 = call ptr @mlf.allocate.thunk(ptr @mlf.code.152, i64 3)
  %v590 = getelementptr i8, ptr %v589, i64 16
  %v591 = load ptr, ptr %v590, align 8, !tbaa !3
  %v592 = getelementptr i8, ptr %v591, i64 8
  store ptr %v118, ptr %v592, align 8, !tbaa !3
  %v593 = getelementptr i8, ptr %v591, i64 16
  store ptr %v120, ptr %v593, align 8, !tbaa !3
  %v594 = getelementptr i8, ptr %v591, i64 24
  store ptr %v122, ptr %v594, align 8, !tbaa !3
  %v595 = call ptr @mlf_application(ptr %v148, ptr %v589)
  %v596 = call ptr @mlf.force(ptr %v595)
  ret ptr %v596
}

define private ptr @mlf.numeric.14.pppppd(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, double %a5) alwaysinline {
entry:
  %v650 = ptrtoint ptr %a4 to i64
  %v651 = ptrtoint ptr %a0 to i64
  %v652 = and i64 %v650, %v651
  %v653 = and i64 %v652, 1
  %v654 = icmp ne i64 %v653, 0
  br i1 %v654, label %yes.655, label %no.656
yes.655:
  %v658 = icmp slt i64 %v650, %v651
  %v659 = select i1 %v658, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.657
no.656:
  %v660 = call ptr @mlf_lt_int(ptr %a4, ptr %a0)
  br label %join.657
join.657:
  %v661 = phi ptr [ %v659, %yes.655 ], [ %v660, %no.656 ]
  %v662 = icmp eq ptr %v661, inttoptr (i64 6 to ptr)
  br i1 %v662, label %tail.yes.663, label %tail.no.664
tail.yes.663:
  %v665 = getelementptr i8, ptr %a1, i64 8
  %v666 = load i64, ptr %v665, align 8, !tbaa !3
  %v667 = getelementptr i8, ptr %a1, i64 16
  %v668 = load ptr, ptr %v667, align 8, !tbaa !3
  %v669 = ptrtoint ptr %a4 to i64
  %v670 = ashr i64 %v669, 1
  %v671 = and i64 %v669, 1
  %v672 = icmp ne i64 %v671, 0
  %v673 = icmp ult i64 %v670, %v666
  %v674 = and i1 %v672, %v673
  br i1 %v674, label %array.valid.675, label %array.invalid.676
array.invalid.676:
  call void @mlf_bounds_failure()
  unreachable
array.valid.675:
  %v677 = getelementptr i64, ptr %v668, i64 %v670
  %v678 = load double, ptr %v677, align 8, !tbaa !4
  %v679 = ptrtoint ptr %a4 to i64
  %v680 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v681 = sub i64 %v680, 1
  %v682 = add nsw i64 %v679, %v681
  %v683 = inttoptr i64 %v682 to ptr
  %v684 = ptrtoint ptr %a4 to i64
  %v685 = and i64 %v684, 1
  %v686 = icmp ne i64 %v685, 0
  br i1 %v686, label %yes.687, label %no.688
yes.687:
  %v690 = ashr i64 %v684, 1
  %v691 = sitofp i64 %v690 to double
  br label %join.689
no.688:
  %v692 = call double @mlf_int_to_double(ptr %a4)
  br label %join.689
join.689:
  %v693 = phi double [ %v691, %yes.687 ], [ %v692, %no.688 ]
  %v694 = ptrtoint ptr %a3 to i64
  %v695 = and i64 %v694, 1
  %v696 = icmp ne i64 %v695, 0
  br i1 %v696, label %yes.697, label %no.698
yes.697:
  %v700 = ashr i64 %v694, 1
  %v701 = sitofp i64 %v700 to double
  br label %join.699
no.698:
  %v702 = call double @mlf_int_to_double(ptr %a3)
  br label %join.699
join.699:
  %v703 = phi double [ %v701, %yes.697 ], [ %v702, %no.698 ]
  %v704 = fadd double %v693, %v703
  %v705 = fadd double %v704, 0x3ff0000000000000
  %v706 = fmul double %v704, %v705
  %v707 = fdiv double %v706, 0x4000000000000000
  %v708 = fadd double %v707, %v693
  %v709 = fadd double %v708, 0x3ff0000000000000
  %v710 = fdiv double 0x3ff0000000000000, %v709
  %v711 = fmul double %v710, %v678
  %v712 = fadd double %a5, %v711
  %v713 = musttail call ptr @mlf.numeric.14.pppppd(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %v683, double %v712)
  ret ptr %v713
tail.no.664:
  %v714 = getelementptr i8, ptr %a2, i64 8
  %v715 = load i64, ptr %v714, align 8, !tbaa !3
  %v716 = getelementptr i8, ptr %a2, i64 16
  %v717 = load ptr, ptr %v716, align 8, !tbaa !3
  %v718 = ptrtoint ptr %a3 to i64
  %v719 = ashr i64 %v718, 1
  %v720 = and i64 %v718, 1
  %v721 = icmp ne i64 %v720, 0
  %v722 = icmp ult i64 %v719, %v715
  %v723 = and i1 %v721, %v722
  br i1 %v723, label %array.valid.724, label %array.invalid.725
array.invalid.725:
  call void @mlf_bounds_failure()
  unreachable
array.valid.724:
  %v726 = getelementptr i64, ptr %v717, i64 %v719
  store double %a5, ptr %v726, align 8, !tbaa !4
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.numeric.28(ptr %a0, ptr %a1, ptr %a2, ptr %a3) alwaysinline {
entry:
  %v635 = ptrtoint ptr %a3 to i64
  %v636 = ptrtoint ptr %a0 to i64
  %v637 = and i64 %v635, %v636
  %v638 = and i64 %v637, 1
  %v639 = icmp ne i64 %v638, 0
  br i1 %v639, label %yes.640, label %no.641
yes.640:
  %v643 = icmp slt i64 %v635, %v636
  %v644 = select i1 %v643, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.642
no.641:
  %v645 = call ptr @mlf_lt_int(ptr %a3, ptr %a0)
  br label %join.642
join.642:
  %v646 = phi ptr [ %v644, %yes.640 ], [ %v645, %no.641 ]
  %v647 = icmp eq ptr %v646, inttoptr (i64 6 to ptr)
  br i1 %v647, label %tail.yes.648, label %tail.no.649
tail.yes.648:
  %v727 = call ptr @mlf.numeric.14.pppppd(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr inttoptr (i64 1 to ptr), double 0x0000000000000000)
  %v728 = ptrtoint ptr %a3 to i64
  %v729 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v730 = and i64 %v728, %v729
  %v731 = and i64 %v730, 1
  %v732 = icmp ne i64 %v731, 0
  br i1 %v732, label %yes.733, label %no.734
yes.733:
  %v736 = sub i64 %v729, 1
  %v737 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v728, i64 %v736)
  %v738 = extractvalue { i64, i1 } %v737, 0
  %v739 = extractvalue { i64, i1 } %v737, 1
  br i1 %v739, label %yes.740, label %no.741
yes.740:
  %v743 = call ptr @mlf_add_int(ptr %a3, ptr inttoptr (i64 3 to ptr))
  br label %join.742
no.741:
  %v744 = inttoptr i64 %v738 to ptr
  br label %join.742
join.742:
  %v745 = phi ptr [ %v743, %yes.740 ], [ %v744, %no.741 ]
  br label %join.735
no.734:
  %v746 = call ptr @mlf_add_int(ptr %a3, ptr inttoptr (i64 3 to ptr))
  br label %join.735
join.735:
  %v747 = phi ptr [ %v745, %join.742 ], [ %v746, %no.734 ]
  %v748 = musttail call ptr @mlf.numeric.28(ptr %a0, ptr %a1, ptr %a2, ptr %v747)
  ret ptr %v748
tail.no.649:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.numeric.14(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5) alwaysinline {
entry:
  %v803 = ptrtoint ptr %a4 to i64
  %v804 = ptrtoint ptr %a0 to i64
  %v805 = and i64 %v803, %v804
  %v806 = and i64 %v805, 1
  %v807 = icmp ne i64 %v806, 0
  br i1 %v807, label %yes.808, label %no.809
yes.808:
  %v811 = icmp slt i64 %v803, %v804
  %v812 = select i1 %v811, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.810
no.809:
  %v813 = call ptr @mlf_lt_int(ptr %a4, ptr %a0)
  br label %join.810
join.810:
  %v814 = phi ptr [ %v812, %yes.808 ], [ %v813, %no.809 ]
  %v815 = icmp eq ptr %v814, inttoptr (i64 6 to ptr)
  br i1 %v815, label %tail.yes.816, label %tail.no.817
tail.yes.816:
  %v818 = getelementptr i8, ptr %a1, i64 8
  %v819 = load i64, ptr %v818, align 8, !tbaa !3
  %v820 = getelementptr i8, ptr %a1, i64 16
  %v821 = load ptr, ptr %v820, align 8, !tbaa !3
  %v822 = ptrtoint ptr %a4 to i64
  %v823 = ashr i64 %v822, 1
  %v824 = and i64 %v822, 1
  %v825 = icmp ne i64 %v824, 0
  %v826 = icmp ult i64 %v823, %v819
  %v827 = and i1 %v825, %v826
  br i1 %v827, label %array.valid.828, label %array.invalid.829
array.invalid.829:
  call void @mlf_bounds_failure()
  unreachable
array.valid.828:
  %v830 = getelementptr i64, ptr %v821, i64 %v823
  %v831 = load double, ptr %v830, align 8, !tbaa !4
  %v832 = ptrtoint ptr %a4 to i64
  %v833 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v834 = sub i64 %v833, 1
  %v835 = add nsw i64 %v832, %v834
  %v836 = inttoptr i64 %v835 to ptr
  %v837 = ptrtoint ptr %a4 to i64
  %v838 = and i64 %v837, 1
  %v839 = icmp ne i64 %v838, 0
  br i1 %v839, label %yes.840, label %no.841
yes.840:
  %v843 = ashr i64 %v837, 1
  %v844 = sitofp i64 %v843 to double
  br label %join.842
no.841:
  %v845 = call double @mlf_int_to_double(ptr %a4)
  br label %join.842
join.842:
  %v846 = phi double [ %v844, %yes.840 ], [ %v845, %no.841 ]
  %v847 = ptrtoint ptr %a3 to i64
  %v848 = and i64 %v847, 1
  %v849 = icmp ne i64 %v848, 0
  br i1 %v849, label %yes.850, label %no.851
yes.850:
  %v853 = ashr i64 %v847, 1
  %v854 = sitofp i64 %v853 to double
  br label %join.852
no.851:
  %v855 = call double @mlf_int_to_double(ptr %a3)
  br label %join.852
join.852:
  %v856 = phi double [ %v854, %yes.850 ], [ %v855, %no.851 ]
  %v857 = fadd double %v846, %v856
  %v858 = fadd double %v857, 0x3ff0000000000000
  %v859 = fmul double %v857, %v858
  %v860 = fdiv double %v859, 0x4000000000000000
  %v861 = fadd double %v860, %v846
  %v862 = fadd double %v861, 0x3ff0000000000000
  %v863 = fdiv double 0x3ff0000000000000, %v862
  %v864 = fmul double %v863, %v831
  %v865 = getelementptr i8, ptr %a5, i64 8
  %v866 = load double, ptr %v865, align 8, !tbaa !3
  %v867 = fadd double %v866, %v864
  %v868 = call ptr @mlf.numeric.14.pppppd(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %v836, double %v867)
  ret ptr %v868
tail.no.817:
  %v869 = getelementptr i8, ptr %a2, i64 8
  %v870 = load i64, ptr %v869, align 8, !tbaa !3
  %v871 = getelementptr i8, ptr %a2, i64 16
  %v872 = load ptr, ptr %v871, align 8, !tbaa !3
  %v873 = ptrtoint ptr %a3 to i64
  %v874 = ashr i64 %v873, 1
  %v875 = and i64 %v873, 1
  %v876 = icmp ne i64 %v875, 0
  %v877 = icmp ult i64 %v874, %v870
  %v878 = and i1 %v876, %v877
  br i1 %v878, label %array.valid.879, label %array.invalid.880
array.invalid.880:
  call void @mlf_bounds_failure()
  unreachable
array.valid.879:
  %v881 = getelementptr i64, ptr %v872, i64 %v874
  %v882 = getelementptr i8, ptr %a5, i64 8
  %v883 = load double, ptr %v882, align 8, !tbaa !3
  store double %v883, ptr %v881, align 8, !tbaa !4
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.code.891(ptr %env, ptr %arg) {
entry:
  %v892 = getelementptr i8, ptr %env, i64 8
  %v893 = load ptr, ptr %v892, align 8, !tbaa !3
  %v894 = getelementptr i8, ptr %env, i64 16
  %v895 = load ptr, ptr %v894, align 8, !tbaa !3
  %v896 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v896, align 8, !tbaa !3
  %v897 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v897, align 8, !tbaa !3
  %v898 = call ptr @mlf_prim2(i64 32, ptr %v893, ptr %v895)
  ret ptr %v898
}

define private ptr @mlf.code.920(ptr %env, ptr %arg) {
entry:
  %v921 = getelementptr i8, ptr %env, i64 8
  %v922 = load ptr, ptr %v921, align 8, !tbaa !3
  %v923 = getelementptr i8, ptr %env, i64 16
  %v924 = load ptr, ptr %v923, align 8, !tbaa !3
  %v925 = getelementptr i8, ptr %env, i64 24
  %v926 = load ptr, ptr %v925, align 8, !tbaa !3
  %v927 = getelementptr i8, ptr %env, i64 32
  %v928 = load ptr, ptr %v927, align 8, !tbaa !3
  %v929 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v929, align 8, !tbaa !3
  %v930 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v930, align 8, !tbaa !3
  %v931 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v931, align 8, !tbaa !3
  %v932 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v932, align 8, !tbaa !3
  %v933 = call ptr @mlf.force(ptr %v926)
  %v934 = call ptr @mlf.force(ptr %v924)
  %v935 = call ptr @mlf.force(ptr %v922)
  %v936 = call ptr @mlf.worker.0(ptr %v934, ptr %v935)
  %v937 = call ptr @mlf.force(ptr %v928)
  %v938 = call ptr @mlf_prim2(i64 20, ptr %v936, ptr %v937)
  %v939 = call ptr @mlf_prim2(i64 18, ptr %v933, ptr %v938)
  ret ptr %v939
}

define private ptr @mlf.code.904(ptr %env, ptr %arg) {
entry:
  %v905 = getelementptr i8, ptr %env, i64 8
  %v906 = load ptr, ptr %v905, align 8, !tbaa !3
  %v907 = getelementptr i8, ptr %env, i64 16
  %v908 = load ptr, ptr %v907, align 8, !tbaa !3
  %v909 = getelementptr i8, ptr %env, i64 24
  %v910 = load ptr, ptr %v909, align 8, !tbaa !3
  %v911 = getelementptr i8, ptr %env, i64 32
  %v912 = load ptr, ptr %v911, align 8, !tbaa !3
  %v913 = getelementptr i8, ptr %env, i64 40
  %v914 = load ptr, ptr %v913, align 8, !tbaa !3
  %v915 = getelementptr i8, ptr %env, i64 48
  %v916 = load ptr, ptr %v915, align 8, !tbaa !3
  %v917 = call ptr @mlf.force(ptr %v906)
  %v918 = call ptr @mlf.force(ptr %v914)
  %v919 = call ptr @mlf_prim2(i64 8, ptr %v918, ptr inttoptr (i64 3 to ptr))
  %v940 = call ptr @mlf.allocate.thunk(ptr @mlf.code.920, i64 4)
  %v941 = getelementptr i8, ptr %v940, i64 16
  %v942 = load ptr, ptr %v941, align 8, !tbaa !3
  %v943 = getelementptr i8, ptr %v942, i64 8
  store ptr %v912, ptr %v943, align 8, !tbaa !3
  %v944 = getelementptr i8, ptr %v942, i64 16
  store ptr %v918, ptr %v944, align 8, !tbaa !3
  %v945 = getelementptr i8, ptr %v942, i64 24
  store ptr %v916, ptr %v945, align 8, !tbaa !3
  %v946 = getelementptr i8, ptr %v942, i64 32
  store ptr %arg, ptr %v946, align 8, !tbaa !3
  %v947 = call ptr @mlf_env_new(i64 6)
  %v948 = getelementptr i8, ptr %v947, i64 8
  store ptr %v917, ptr %v948, align 8, !tbaa !3
  %v949 = getelementptr i8, ptr %v947, i64 16
  store ptr %v908, ptr %v949, align 8, !tbaa !3
  %v950 = getelementptr i8, ptr %v947, i64 24
  store ptr %v910, ptr %v950, align 8, !tbaa !3
  %v951 = getelementptr i8, ptr %v947, i64 32
  store ptr %v912, ptr %v951, align 8, !tbaa !3
  %v952 = getelementptr i8, ptr %v947, i64 40
  store ptr %v919, ptr %v952, align 8, !tbaa !3
  %v953 = getelementptr i8, ptr %v947, i64 48
  store ptr %v940, ptr %v953, align 8, !tbaa !3
  %v954 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.769, ptr %v947)
  ret ptr %v954
}

define private ptr @mlf.worker.14(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5) {
entry:
  %v886 = call ptr @mlf_prim2(i64 11, ptr %a4, ptr %a0)
  %v887 = icmp eq ptr %v886, inttoptr (i64 6 to ptr)
  br i1 %v887, label %yes.888, label %no.889
yes.888:
  %v899 = call ptr @mlf.allocate.thunk(ptr @mlf.code.891, i64 2)
  %v900 = getelementptr i8, ptr %v899, i64 16
  %v901 = load ptr, ptr %v900, align 8, !tbaa !3
  %v902 = getelementptr i8, ptr %v901, i64 8
  store ptr %a1, ptr %v902, align 8, !tbaa !3
  %v903 = getelementptr i8, ptr %v901, i64 16
  store ptr %a4, ptr %v903, align 8, !tbaa !3
  %v955 = call ptr @mlf_env_new(i64 6)
  %v956 = getelementptr i8, ptr %v955, i64 8
  store ptr %a0, ptr %v956, align 8, !tbaa !3
  %v957 = getelementptr i8, ptr %v955, i64 16
  store ptr %a1, ptr %v957, align 8, !tbaa !3
  %v958 = getelementptr i8, ptr %v955, i64 24
  store ptr %a2, ptr %v958, align 8, !tbaa !3
  %v959 = getelementptr i8, ptr %v955, i64 32
  store ptr %a3, ptr %v959, align 8, !tbaa !3
  %v960 = getelementptr i8, ptr %v955, i64 40
  store ptr %a4, ptr %v960, align 8, !tbaa !3
  %v961 = getelementptr i8, ptr %v955, i64 48
  store ptr %a5, ptr %v961, align 8, !tbaa !3
  %v962 = call ptr @mlf_closure(ptr @mlf.code.904, ptr %v955)
  %v963 = call ptr @mlf_prim2(i64 1, ptr %v899, ptr %v962)
  br label %join.890
no.889:
  %v964 = call ptr @mlf_prim3(i64 33, ptr %a2, ptr %a3, ptr %a5)
  br label %join.890
join.890:
  %v965 = phi ptr [ %v963, %yes.888 ], [ %v964, %no.889 ]
  ret ptr %v965
}

define private ptr @mlf.numeric.entry.769(ptr %env, ptr %arg) {
entry:
  %v770 = getelementptr i8, ptr %env, i64 8
  %v771 = load ptr, ptr %v770, align 8, !tbaa !3
  %v772 = getelementptr i8, ptr %env, i64 16
  %v773 = load ptr, ptr %v772, align 8, !tbaa !3
  %v774 = getelementptr i8, ptr %env, i64 24
  %v775 = load ptr, ptr %v774, align 8, !tbaa !3
  %v776 = getelementptr i8, ptr %env, i64 32
  %v777 = load ptr, ptr %v776, align 8, !tbaa !3
  %v778 = getelementptr i8, ptr %env, i64 40
  %v779 = load ptr, ptr %v778, align 8, !tbaa !3
  %v780 = getelementptr i8, ptr %env, i64 48
  %v781 = load ptr, ptr %v780, align 8, !tbaa !3
  %v782 = call ptr @mlf_peek(ptr %v771)
  %v783 = call ptr @mlf_peek(ptr %v773)
  %v784 = call ptr @mlf_peek(ptr %v775)
  %v785 = call ptr @mlf_peek(ptr %v777)
  %v786 = call ptr @mlf_peek(ptr %v779)
  %v787 = call ptr @mlf_peek(ptr %v781)
  %v788 = icmp ne ptr %v782, null
  %v789 = icmp ne ptr %v783, null
  %v790 = icmp ne ptr %v784, null
  %v791 = icmp ne ptr %v785, null
  %v792 = icmp ne ptr %v786, null
  %v793 = icmp ne ptr %v787, null
  %v794 = and i1 true, %v788
  %v795 = and i1 %v794, %v789
  %v796 = and i1 %v795, %v790
  %v797 = and i1 %v796, %v791
  %v798 = and i1 %v797, %v792
  %v799 = and i1 %v798, %v793
  br i1 %v799, label %yes.800, label %no.801
yes.800:
  %v884 = call ptr @mlf.numeric.14(ptr %v782, ptr %v783, ptr %v784, ptr %v785, ptr %v786, ptr %v787)
  %v885 = call ptr @mlf_prim1(i64 0, ptr %v884)
  br label %join.802
no.801:
  %v966 = call ptr @mlf.force(ptr %v771)
  %v967 = call ptr @mlf.force(ptr %v779)
  %v968 = call ptr @mlf.worker.14(ptr %v966, ptr %v773, ptr %v775, ptr %v777, ptr %v967, ptr %v781)
  br label %join.802
join.802:
  %v969 = phi ptr [ %v885, %yes.800 ], [ %v968, %no.801 ]
  ret ptr %v969
}

define private ptr @mlf.code.756(ptr %env, ptr %arg) {
entry:
  %v757 = getelementptr i8, ptr %env, i64 8
  %v758 = load ptr, ptr %v757, align 8, !tbaa !3
  %v759 = getelementptr i8, ptr %env, i64 16
  %v760 = load ptr, ptr %v759, align 8, !tbaa !3
  %v761 = getelementptr i8, ptr %env, i64 24
  %v762 = load ptr, ptr %v761, align 8, !tbaa !3
  %v763 = getelementptr i8, ptr %env, i64 32
  %v764 = load ptr, ptr %v763, align 8, !tbaa !3
  %v765 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v765, align 8, !tbaa !3
  %v766 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v766, align 8, !tbaa !3
  %v767 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v767, align 8, !tbaa !3
  %v768 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v768, align 8, !tbaa !3
  %v970 = call ptr @mlf.force(ptr %v758)
  %v971 = call ptr @mlf_double(double 0x0000000000000000)
  %v972 = call ptr @mlf_env_new(i64 6)
  %v973 = getelementptr i8, ptr %v972, i64 8
  store ptr %v970, ptr %v973, align 8, !tbaa !3
  %v974 = getelementptr i8, ptr %v972, i64 16
  store ptr %v760, ptr %v974, align 8, !tbaa !3
  %v975 = getelementptr i8, ptr %v972, i64 24
  store ptr %v762, ptr %v975, align 8, !tbaa !3
  %v976 = getelementptr i8, ptr %v972, i64 32
  store ptr %v764, ptr %v976, align 8, !tbaa !3
  %v977 = getelementptr i8, ptr %v972, i64 40
  store ptr inttoptr (i64 1 to ptr), ptr %v977, align 8, !tbaa !3
  %v978 = getelementptr i8, ptr %v972, i64 48
  store ptr %v971, ptr %v978, align 8, !tbaa !3
  %v979 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.769, ptr %v972)
  ret ptr %v979
}

define private ptr @mlf.code.987(ptr %env, ptr %arg) {
entry:
  %v988 = getelementptr i8, ptr %env, i64 8
  %v989 = load ptr, ptr %v988, align 8, !tbaa !3
  %v990 = getelementptr i8, ptr %env, i64 16
  %v991 = load ptr, ptr %v990, align 8, !tbaa !3
  %v992 = getelementptr i8, ptr %env, i64 24
  %v993 = load ptr, ptr %v992, align 8, !tbaa !3
  %v994 = getelementptr i8, ptr %env, i64 32
  %v995 = load ptr, ptr %v994, align 8, !tbaa !3
  %v996 = call ptr @mlf.force(ptr %v989)
  %v997 = call ptr @mlf.force(ptr %v995)
  %v998 = call ptr @mlf_prim2(i64 8, ptr %v997, ptr inttoptr (i64 3 to ptr))
  %v999 = call ptr @mlf_env_new(i64 4)
  %v1000 = getelementptr i8, ptr %v999, i64 8
  store ptr %v996, ptr %v1000, align 8, !tbaa !3
  %v1001 = getelementptr i8, ptr %v999, i64 16
  store ptr %v991, ptr %v1001, align 8, !tbaa !3
  %v1002 = getelementptr i8, ptr %v999, i64 24
  store ptr %v993, ptr %v1002, align 8, !tbaa !3
  %v1003 = getelementptr i8, ptr %v999, i64 32
  store ptr %v998, ptr %v1003, align 8, !tbaa !3
  %v1004 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.611, ptr %v999)
  ret ptr %v1004
}

define private ptr @mlf.worker.28(ptr %a0, ptr %a1, ptr %a2, ptr %a3) {
entry:
  %v751 = call ptr @mlf_prim2(i64 11, ptr %a3, ptr %a0)
  %v752 = icmp eq ptr %v751, inttoptr (i64 6 to ptr)
  br i1 %v752, label %yes.753, label %no.754
yes.753:
  %v980 = call ptr @mlf.allocate.thunk(ptr @mlf.code.756, i64 4)
  %v981 = getelementptr i8, ptr %v980, i64 16
  %v982 = load ptr, ptr %v981, align 8, !tbaa !3
  %v983 = getelementptr i8, ptr %v982, i64 8
  store ptr %a0, ptr %v983, align 8, !tbaa !3
  %v984 = getelementptr i8, ptr %v982, i64 16
  store ptr %a1, ptr %v984, align 8, !tbaa !3
  %v985 = getelementptr i8, ptr %v982, i64 24
  store ptr %a2, ptr %v985, align 8, !tbaa !3
  %v986 = getelementptr i8, ptr %v982, i64 32
  store ptr %a3, ptr %v986, align 8, !tbaa !3
  %v1005 = call ptr @mlf_env_new(i64 4)
  %v1006 = getelementptr i8, ptr %v1005, i64 8
  store ptr %a0, ptr %v1006, align 8, !tbaa !3
  %v1007 = getelementptr i8, ptr %v1005, i64 16
  store ptr %a1, ptr %v1007, align 8, !tbaa !3
  %v1008 = getelementptr i8, ptr %v1005, i64 24
  store ptr %a2, ptr %v1008, align 8, !tbaa !3
  %v1009 = getelementptr i8, ptr %v1005, i64 32
  store ptr %a3, ptr %v1009, align 8, !tbaa !3
  %v1010 = call ptr @mlf_closure(ptr @mlf.code.987, ptr %v1005)
  %v1011 = call ptr @mlf_prim2(i64 1, ptr %v980, ptr %v1010)
  br label %join.755
no.754:
  %v1012 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.755
join.755:
  %v1013 = phi ptr [ %v1011, %yes.753 ], [ %v1012, %no.754 ]
  ret ptr %v1013
}

define private ptr @mlf.numeric.entry.611(ptr %env, ptr %arg) {
entry:
  %v612 = getelementptr i8, ptr %env, i64 8
  %v613 = load ptr, ptr %v612, align 8, !tbaa !3
  %v614 = getelementptr i8, ptr %env, i64 16
  %v615 = load ptr, ptr %v614, align 8, !tbaa !3
  %v616 = getelementptr i8, ptr %env, i64 24
  %v617 = load ptr, ptr %v616, align 8, !tbaa !3
  %v618 = getelementptr i8, ptr %env, i64 32
  %v619 = load ptr, ptr %v618, align 8, !tbaa !3
  %v620 = call ptr @mlf_peek(ptr %v613)
  %v621 = call ptr @mlf_peek(ptr %v615)
  %v622 = call ptr @mlf_peek(ptr %v617)
  %v623 = call ptr @mlf_peek(ptr %v619)
  %v624 = icmp ne ptr %v620, null
  %v625 = icmp ne ptr %v621, null
  %v626 = icmp ne ptr %v622, null
  %v627 = icmp ne ptr %v623, null
  %v628 = and i1 true, %v624
  %v629 = and i1 %v628, %v625
  %v630 = and i1 %v629, %v626
  %v631 = and i1 %v630, %v627
  br i1 %v631, label %yes.632, label %no.633
yes.632:
  %v749 = call ptr @mlf.numeric.28(ptr %v620, ptr %v621, ptr %v622, ptr %v623)
  %v750 = call ptr @mlf_prim1(i64 0, ptr %v749)
  br label %join.634
no.633:
  %v1014 = call ptr @mlf.force(ptr %v613)
  %v1015 = call ptr @mlf.force(ptr %v619)
  %v1016 = call ptr @mlf.worker.28(ptr %v1014, ptr %v615, ptr %v617, ptr %v1015)
  br label %join.634
join.634:
  %v1017 = phi ptr [ %v750, %yes.632 ], [ %v1016, %no.633 ]
  ret ptr %v1017
}

define private ptr @mlf.code.604(ptr %env, ptr %arg) {
entry:
  %v605 = getelementptr i8, ptr %env, i64 8
  %v606 = load ptr, ptr %v605, align 8, !tbaa !3
  %v607 = getelementptr i8, ptr %env, i64 16
  %v608 = load ptr, ptr %v607, align 8, !tbaa !3
  %v609 = getelementptr i8, ptr %env, i64 24
  %v610 = load ptr, ptr %v609, align 8, !tbaa !3
  %v1018 = call ptr @mlf.force(ptr %v606)
  %v1019 = call ptr @mlf_env_new(i64 4)
  %v1020 = getelementptr i8, ptr %v1019, i64 8
  store ptr %v1018, ptr %v1020, align 8, !tbaa !3
  %v1021 = getelementptr i8, ptr %v1019, i64 16
  store ptr %v610, ptr %v1021, align 8, !tbaa !3
  %v1022 = getelementptr i8, ptr %v1019, i64 24
  store ptr %v608, ptr %v1022, align 8, !tbaa !3
  %v1023 = getelementptr i8, ptr %v1019, i64 32
  store ptr inttoptr (i64 1 to ptr), ptr %v1023, align 8, !tbaa !3
  %v1024 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.611, ptr %v1019)
  ret ptr %v1024
}

define private ptr @mlf.worker.34(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) {
entry:
  %v597 = call ptr @mlf.allocate.thunk(ptr @mlf.code.114, i64 4)
  %v598 = getelementptr i8, ptr %v597, i64 16
  %v599 = load ptr, ptr %v598, align 8, !tbaa !3
  %v600 = getelementptr i8, ptr %v599, i64 8
  store ptr %a0, ptr %v600, align 8, !tbaa !3
  %v601 = getelementptr i8, ptr %v599, i64 16
  store ptr %a1, ptr %v601, align 8, !tbaa !3
  %v602 = getelementptr i8, ptr %v599, i64 24
  store ptr %a2, ptr %v602, align 8, !tbaa !3
  %v603 = getelementptr i8, ptr %v599, i64 32
  store ptr %a4, ptr %v603, align 8, !tbaa !3
  %v1025 = call ptr @mlf_env_new(i64 3)
  %v1026 = getelementptr i8, ptr %v1025, i64 8
  store ptr %a1, ptr %v1026, align 8, !tbaa !3
  %v1027 = getelementptr i8, ptr %v1025, i64 16
  store ptr %a3, ptr %v1027, align 8, !tbaa !3
  %v1028 = getelementptr i8, ptr %v1025, i64 24
  store ptr %a4, ptr %v1028, align 8, !tbaa !3
  %v1029 = call ptr @mlf_closure(ptr @mlf.code.604, ptr %v1025)
  %v1030 = call ptr @mlf_application(ptr %v597, ptr %v1029)
  %v1031 = call ptr @mlf.force(ptr %v1030)
  ret ptr %v1031
}

define private ptr @mlf.code.101(ptr %env, ptr %arg) {
entry:
  %v102 = getelementptr i8, ptr %env, i64 8
  %v103 = load ptr, ptr %v102, align 8, !tbaa !3
  %v104 = getelementptr i8, ptr %env, i64 16
  %v105 = load ptr, ptr %v104, align 8, !tbaa !3
  %v106 = getelementptr i8, ptr %env, i64 24
  %v107 = load ptr, ptr %v106, align 8, !tbaa !3
  %v108 = getelementptr i8, ptr %env, i64 32
  %v109 = load ptr, ptr %v108, align 8, !tbaa !3
  %v110 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v110, align 8, !tbaa !3
  %v111 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v111, align 8, !tbaa !3
  %v112 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v112, align 8, !tbaa !3
  %v113 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v113, align 8, !tbaa !3
  %v1032 = call ptr @mlf_primitive(i64 0)
  %v1033 = call ptr @mlf_primitive(i64 1)
  %v1034 = call ptr @mlf.construct.2(i64 1, ptr %v1032, ptr %v1033)
  %v1035 = call ptr @mlf.worker.34(ptr %v1034, ptr %v103, ptr %v105, ptr %v107, ptr %v109)
  ret ptr %v1035
}

define private ptr @mlf.code.1054(ptr %env, ptr %arg) {
entry:
  %v1055 = getelementptr i8, ptr %env, i64 8
  %v1056 = load ptr, ptr %v1055, align 8, !tbaa !3
  %v1057 = getelementptr i8, ptr %env, i64 16
  %v1058 = load ptr, ptr %v1057, align 8, !tbaa !3
  %v1059 = getelementptr i8, ptr %env, i64 24
  %v1060 = load ptr, ptr %v1059, align 8, !tbaa !3
  %v1061 = getelementptr i8, ptr %env, i64 32
  %v1062 = load ptr, ptr %v1061, align 8, !tbaa !3
  %v1063 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1063, align 8, !tbaa !3
  %v1064 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1064, align 8, !tbaa !3
  %v1065 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v1065, align 8, !tbaa !3
  %v1066 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v1066, align 8, !tbaa !3
  %v1067 = call ptr @mlf_primitive(i64 0)
  %v1068 = call ptr @mlf_primitive(i64 1)
  %v1069 = call ptr @mlf.construct.2(i64 1, ptr %v1067, ptr %v1068)
  %v1070 = call ptr @mlf.worker.34(ptr %v1069, ptr %v1056, ptr %v1060, ptr %v1058, ptr %v1062)
  ret ptr %v1070
}

define private ptr @mlf.code.1078(ptr %env, ptr %arg) {
entry:
  %v1079 = getelementptr i8, ptr %env, i64 8
  %v1080 = load ptr, ptr %v1079, align 8, !tbaa !3
  %v1081 = getelementptr i8, ptr %env, i64 16
  %v1082 = load ptr, ptr %v1081, align 8, !tbaa !3
  %v1083 = getelementptr i8, ptr %env, i64 24
  %v1084 = load ptr, ptr %v1083, align 8, !tbaa !3
  %v1085 = getelementptr i8, ptr %env, i64 32
  %v1086 = load ptr, ptr %v1085, align 8, !tbaa !3
  %v1087 = getelementptr i8, ptr %env, i64 40
  %v1088 = load ptr, ptr %v1087, align 8, !tbaa !3
  %v1089 = call ptr @mlf.force(ptr %v1088)
  %v1090 = ptrtoint ptr %v1089 to i64
  %v1091 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1092 = and i64 %v1090, %v1091
  %v1093 = and i64 %v1092, 1
  %v1094 = icmp ne i64 %v1093, 0
  br i1 %v1094, label %yes.1095, label %no.1096
yes.1095:
  %v1098 = sub i64 %v1091, 1
  %v1099 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v1090, i64 %v1098)
  %v1100 = extractvalue { i64, i1 } %v1099, 0
  %v1101 = extractvalue { i64, i1 } %v1099, 1
  br i1 %v1101, label %yes.1102, label %no.1103
yes.1102:
  %v1105 = call ptr @mlf_sub_int(ptr %v1089, ptr inttoptr (i64 3 to ptr))
  br label %join.1104
no.1103:
  %v1106 = inttoptr i64 %v1100 to ptr
  br label %join.1104
join.1104:
  %v1107 = phi ptr [ %v1105, %yes.1102 ], [ %v1106, %no.1103 ]
  br label %join.1097
no.1096:
  %v1108 = call ptr @mlf_sub_int(ptr %v1089, ptr inttoptr (i64 3 to ptr))
  br label %join.1097
join.1097:
  %v1109 = phi ptr [ %v1107, %join.1104 ], [ %v1108, %no.1096 ]
  %v1110 = call ptr @mlf.worker.42(ptr %v1080, ptr %v1082, ptr %v1084, ptr %v1086, ptr %v1109)
  ret ptr %v1110
}

define private ptr @mlf.code.1043(ptr %env, ptr %arg) {
entry:
  %v1044 = getelementptr i8, ptr %env, i64 8
  %v1045 = load ptr, ptr %v1044, align 8, !tbaa !3
  %v1046 = getelementptr i8, ptr %env, i64 16
  %v1047 = load ptr, ptr %v1046, align 8, !tbaa !3
  %v1048 = getelementptr i8, ptr %env, i64 24
  %v1049 = load ptr, ptr %v1048, align 8, !tbaa !3
  %v1050 = getelementptr i8, ptr %env, i64 32
  %v1051 = load ptr, ptr %v1050, align 8, !tbaa !3
  %v1052 = getelementptr i8, ptr %env, i64 40
  %v1053 = load ptr, ptr %v1052, align 8, !tbaa !3
  %v1071 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1054, i64 4)
  %v1072 = getelementptr i8, ptr %v1071, i64 16
  %v1073 = load ptr, ptr %v1072, align 8, !tbaa !3
  %v1074 = getelementptr i8, ptr %v1073, i64 8
  store ptr %v1045, ptr %v1074, align 8, !tbaa !3
  %v1075 = getelementptr i8, ptr %v1073, i64 16
  store ptr %v1047, ptr %v1075, align 8, !tbaa !3
  %v1076 = getelementptr i8, ptr %v1073, i64 24
  store ptr %v1049, ptr %v1076, align 8, !tbaa !3
  %v1077 = getelementptr i8, ptr %v1073, i64 32
  store ptr %v1051, ptr %v1077, align 8, !tbaa !3
  %v1111 = call ptr @mlf_env_new(i64 5)
  %v1112 = getelementptr i8, ptr %v1111, i64 8
  store ptr %v1045, ptr %v1112, align 8, !tbaa !3
  %v1113 = getelementptr i8, ptr %v1111, i64 16
  store ptr %v1047, ptr %v1113, align 8, !tbaa !3
  %v1114 = getelementptr i8, ptr %v1111, i64 24
  store ptr %v1049, ptr %v1114, align 8, !tbaa !3
  %v1115 = getelementptr i8, ptr %v1111, i64 32
  store ptr %v1051, ptr %v1115, align 8, !tbaa !3
  %v1116 = getelementptr i8, ptr %v1111, i64 40
  store ptr %v1053, ptr %v1116, align 8, !tbaa !3
  %v1117 = call ptr @mlf_closure(ptr @mlf.code.1078, ptr %v1111)
  %v1118 = call ptr @mlf_prim2(i64 1, ptr %v1071, ptr %v1117)
  ret ptr %v1118
}

define private ptr @mlf.worker.42(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) {
entry:
  %v84 = ptrtoint ptr %a4 to i64
  %v85 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v86 = and i64 %v84, %v85
  %v87 = and i64 %v86, 1
  %v88 = icmp ne i64 %v87, 0
  br i1 %v88, label %yes.89, label %no.90
yes.89:
  %v92 = icmp eq i64 %v84, %v85
  %v93 = select i1 %v92, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.91
no.90:
  %v94 = call ptr @mlf_eq_int(ptr %a4, ptr inttoptr (i64 1 to ptr))
  br label %join.91
join.91:
  %v95 = phi ptr [ %v93, %yes.89 ], [ %v94, %no.90 ]
  %v96 = icmp eq ptr %v95, inttoptr (i64 6 to ptr)
  br i1 %v96, label %yes.97, label %no.98
yes.97:
  %v100 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.99
no.98:
  %v1036 = call ptr @mlf.allocate.thunk(ptr @mlf.code.101, i64 4)
  %v1037 = getelementptr i8, ptr %v1036, i64 16
  %v1038 = load ptr, ptr %v1037, align 8, !tbaa !3
  %v1039 = getelementptr i8, ptr %v1038, i64 8
  store ptr %a0, ptr %v1039, align 8, !tbaa !3
  %v1040 = getelementptr i8, ptr %v1038, i64 16
  store ptr %a1, ptr %v1040, align 8, !tbaa !3
  %v1041 = getelementptr i8, ptr %v1038, i64 24
  store ptr %a2, ptr %v1041, align 8, !tbaa !3
  %v1042 = getelementptr i8, ptr %v1038, i64 32
  store ptr %a3, ptr %v1042, align 8, !tbaa !3
  %v1119 = call ptr @mlf_env_new(i64 5)
  %v1120 = getelementptr i8, ptr %v1119, i64 8
  store ptr %a0, ptr %v1120, align 8, !tbaa !3
  %v1121 = getelementptr i8, ptr %v1119, i64 16
  store ptr %a1, ptr %v1121, align 8, !tbaa !3
  %v1122 = getelementptr i8, ptr %v1119, i64 24
  store ptr %a2, ptr %v1122, align 8, !tbaa !3
  %v1123 = getelementptr i8, ptr %v1119, i64 32
  store ptr %a3, ptr %v1123, align 8, !tbaa !3
  %v1124 = getelementptr i8, ptr %v1119, i64 40
  store ptr %a4, ptr %v1124, align 8, !tbaa !3
  %v1125 = call ptr @mlf_closure(ptr @mlf.code.1043, ptr %v1119)
  %v1126 = call ptr @mlf_prim2(i64 1, ptr %v1036, ptr %v1125)
  br label %join.99
join.99:
  %v1127 = phi ptr [ %v100, %yes.97 ], [ %v1126, %no.98 ]
  ret ptr %v1127
}

define private ptr @mlf.code.71(ptr %env, ptr %arg) {
entry:
  %v72 = getelementptr i8, ptr %env, i64 8
  %v73 = load ptr, ptr %v72, align 8, !tbaa !3
  %v74 = getelementptr i8, ptr %env, i64 16
  %v75 = load ptr, ptr %v74, align 8, !tbaa !3
  %v76 = getelementptr i8, ptr %env, i64 24
  %v77 = load ptr, ptr %v76, align 8, !tbaa !3
  %v78 = getelementptr i8, ptr %env, i64 32
  %v79 = load ptr, ptr %v78, align 8, !tbaa !3
  %v80 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v80, align 8, !tbaa !3
  %v81 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v81, align 8, !tbaa !3
  %v82 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v82, align 8, !tbaa !3
  %v83 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v83, align 8, !tbaa !3
  %v1128 = call ptr @mlf.worker.42(ptr %v73, ptr %v75, ptr %v77, ptr %v79, ptr inttoptr (i64 21 to ptr))
  ret ptr %v1128
}

define private ptr @mlf.numeric.50(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) alwaysinline {
entry:
  %v1187 = ptrtoint ptr %a4 to i64
  %v1188 = ptrtoint ptr %a0 to i64
  %v1189 = and i64 %v1187, %v1188
  %v1190 = and i64 %v1189, 1
  %v1191 = icmp ne i64 %v1190, 0
  br i1 %v1191, label %yes.1192, label %no.1193
yes.1192:
  %v1195 = icmp slt i64 %v1187, %v1188
  %v1196 = select i1 %v1195, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1194
no.1193:
  %v1197 = call ptr @mlf_lt_int(ptr %a4, ptr %a0)
  br label %join.1194
join.1194:
  %v1198 = phi ptr [ %v1196, %yes.1192 ], [ %v1197, %no.1193 ]
  %v1199 = icmp eq ptr %v1198, inttoptr (i64 6 to ptr)
  br i1 %v1199, label %tail.yes.1200, label %tail.no.1201
tail.yes.1200:
  %v1202 = getelementptr i8, ptr %a1, i64 8
  %v1203 = load i64, ptr %v1202, align 8, !tbaa !3
  %v1204 = getelementptr i8, ptr %a1, i64 16
  %v1205 = load ptr, ptr %v1204, align 8, !tbaa !3
  %v1206 = ptrtoint ptr %a4 to i64
  %v1207 = ashr i64 %v1206, 1
  %v1208 = and i64 %v1206, 1
  %v1209 = icmp ne i64 %v1208, 0
  %v1210 = icmp ult i64 %v1207, %v1203
  %v1211 = and i1 %v1209, %v1210
  br i1 %v1211, label %array.valid.1212, label %array.invalid.1213
array.invalid.1213:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1212:
  %v1214 = getelementptr i64, ptr %v1205, i64 %v1207
  %v1215 = load double, ptr %v1214, align 8, !tbaa !4
  %v1216 = getelementptr i8, ptr %a2, i64 8
  %v1217 = load i64, ptr %v1216, align 8, !tbaa !3
  %v1218 = getelementptr i8, ptr %a2, i64 16
  %v1219 = load ptr, ptr %v1218, align 8, !tbaa !3
  %v1220 = ptrtoint ptr %a4 to i64
  %v1221 = ashr i64 %v1220, 1
  %v1222 = and i64 %v1220, 1
  %v1223 = icmp ne i64 %v1222, 0
  %v1224 = icmp ult i64 %v1221, %v1217
  %v1225 = and i1 %v1223, %v1224
  br i1 %v1225, label %array.valid.1226, label %array.invalid.1227
array.invalid.1227:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1226:
  %v1228 = getelementptr i64, ptr %v1219, i64 %v1221
  %v1229 = load double, ptr %v1228, align 8, !tbaa !4
  %v1230 = getelementptr i8, ptr %a3, i64 8
  %v1231 = load i64, ptr %v1230, align 8, !tbaa !3
  %v1232 = getelementptr i8, ptr %a3, i64 16
  %v1233 = load ptr, ptr %v1232, align 8, !tbaa !3
  %v1234 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v1235 = ashr i64 %v1234, 1
  %v1236 = and i64 %v1234, 1
  %v1237 = icmp ne i64 %v1236, 0
  %v1238 = icmp ult i64 %v1235, %v1231
  %v1239 = and i1 %v1237, %v1238
  br i1 %v1239, label %array.valid.1240, label %array.invalid.1241
array.invalid.1241:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1240:
  %v1242 = getelementptr i64, ptr %v1233, i64 %v1235
  %v1243 = load double, ptr %v1242, align 8, !tbaa !4
  %v1244 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1245 = ashr i64 %v1244, 1
  %v1246 = and i64 %v1244, 1
  %v1247 = icmp ne i64 %v1246, 0
  %v1248 = icmp ult i64 %v1245, %v1231
  %v1249 = and i1 %v1247, %v1248
  br i1 %v1249, label %array.valid.1250, label %array.invalid.1251
array.invalid.1251:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1250:
  %v1252 = getelementptr i64, ptr %v1233, i64 %v1245
  %v1253 = load double, ptr %v1252, align 8, !tbaa !4
  %v1254 = fmul double %v1215, %v1229
  %v1255 = fadd double %v1243, %v1254
  %v1256 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v1257 = ashr i64 %v1256, 1
  %v1258 = and i64 %v1256, 1
  %v1259 = icmp ne i64 %v1258, 0
  %v1260 = icmp ult i64 %v1257, %v1231
  %v1261 = and i1 %v1259, %v1260
  br i1 %v1261, label %array.valid.1262, label %array.invalid.1263
array.invalid.1263:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1262:
  %v1264 = getelementptr i64, ptr %v1233, i64 %v1257
  store double %v1255, ptr %v1264, align 8, !tbaa !4
  %v1265 = fmul double %v1229, %v1229
  %v1266 = fadd double %v1253, %v1265
  %v1267 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1268 = ashr i64 %v1267, 1
  %v1269 = and i64 %v1267, 1
  %v1270 = icmp ne i64 %v1269, 0
  %v1271 = icmp ult i64 %v1268, %v1231
  %v1272 = and i1 %v1270, %v1271
  br i1 %v1272, label %array.valid.1273, label %array.invalid.1274
array.invalid.1274:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1273:
  %v1275 = getelementptr i64, ptr %v1233, i64 %v1268
  store double %v1266, ptr %v1275, align 8, !tbaa !4
  %v1276 = ptrtoint ptr %a4 to i64
  %v1277 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1278 = sub i64 %v1277, 1
  %v1279 = add nsw i64 %v1276, %v1278
  %v1280 = inttoptr i64 %v1279 to ptr
  %v1281 = musttail call ptr @mlf.numeric.50(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %v1280)
  ret ptr %v1281
tail.no.1201:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.code.1289(ptr %env, ptr %arg) {
entry:
  %v1290 = getelementptr i8, ptr %env, i64 8
  %v1291 = load ptr, ptr %v1290, align 8, !tbaa !3
  %v1292 = getelementptr i8, ptr %env, i64 16
  %v1293 = load ptr, ptr %v1292, align 8, !tbaa !3
  %v1294 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1294, align 8, !tbaa !3
  %v1295 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1295, align 8, !tbaa !3
  %v1296 = call ptr @mlf_prim2(i64 32, ptr %v1291, ptr %v1293)
  ret ptr %v1296
}

define private ptr @mlf.code.1313(ptr %env, ptr %arg) {
entry:
  %v1314 = getelementptr i8, ptr %env, i64 8
  %v1315 = load ptr, ptr %v1314, align 8, !tbaa !3
  %v1316 = getelementptr i8, ptr %env, i64 16
  %v1317 = load ptr, ptr %v1316, align 8, !tbaa !3
  %v1318 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1318, align 8, !tbaa !3
  %v1319 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1319, align 8, !tbaa !3
  %v1320 = call ptr @mlf_prim2(i64 32, ptr %v1315, ptr %v1317)
  ret ptr %v1320
}

define private ptr @mlf.code.1339(ptr %env, ptr %arg) {
entry:
  %v1340 = getelementptr i8, ptr %env, i64 8
  %v1341 = load ptr, ptr %v1340, align 8, !tbaa !3
  %v1342 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1342, align 8, !tbaa !3
  %v1343 = call ptr @mlf_prim2(i64 32, ptr %v1341, ptr inttoptr (i64 1 to ptr))
  ret ptr %v1343
}

define private ptr @mlf.code.1363(ptr %env, ptr %arg) {
entry:
  %v1364 = getelementptr i8, ptr %env, i64 8
  %v1365 = load ptr, ptr %v1364, align 8, !tbaa !3
  %v1366 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1366, align 8, !tbaa !3
  %v1367 = call ptr @mlf_prim2(i64 32, ptr %v1365, ptr inttoptr (i64 3 to ptr))
  ret ptr %v1367
}

define private ptr @mlf.code.1402(ptr %env, ptr %arg) {
entry:
  %v1403 = getelementptr i8, ptr %env, i64 8
  %v1404 = load ptr, ptr %v1403, align 8, !tbaa !3
  %v1405 = getelementptr i8, ptr %env, i64 16
  %v1406 = load ptr, ptr %v1405, align 8, !tbaa !3
  %v1407 = getelementptr i8, ptr %env, i64 24
  %v1408 = load ptr, ptr %v1407, align 8, !tbaa !3
  %v1409 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1409, align 8, !tbaa !3
  %v1410 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1410, align 8, !tbaa !3
  %v1411 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v1411, align 8, !tbaa !3
  %v1412 = call ptr @mlf.force(ptr %v1408)
  %v1413 = call ptr @mlf.force(ptr %v1404)
  %v1414 = call ptr @mlf.force(ptr %v1406)
  %v1415 = call ptr @mlf_prim2(i64 20, ptr %v1413, ptr %v1414)
  %v1416 = call ptr @mlf_prim2(i64 18, ptr %v1412, ptr %v1415)
  ret ptr %v1416
}

define private ptr @mlf.code.1389(ptr %env, ptr %arg) {
entry:
  %v1390 = getelementptr i8, ptr %env, i64 8
  %v1391 = load ptr, ptr %v1390, align 8, !tbaa !3
  %v1392 = getelementptr i8, ptr %env, i64 16
  %v1393 = load ptr, ptr %v1392, align 8, !tbaa !3
  %v1394 = getelementptr i8, ptr %env, i64 24
  %v1395 = load ptr, ptr %v1394, align 8, !tbaa !3
  %v1396 = getelementptr i8, ptr %env, i64 32
  %v1397 = load ptr, ptr %v1396, align 8, !tbaa !3
  %v1398 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1398, align 8, !tbaa !3
  %v1399 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1399, align 8, !tbaa !3
  %v1400 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v1400, align 8, !tbaa !3
  %v1401 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v1401, align 8, !tbaa !3
  %v1417 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1402, i64 3)
  %v1418 = getelementptr i8, ptr %v1417, i64 16
  %v1419 = load ptr, ptr %v1418, align 8, !tbaa !3
  %v1420 = getelementptr i8, ptr %v1419, i64 8
  store ptr %v1393, ptr %v1420, align 8, !tbaa !3
  %v1421 = getelementptr i8, ptr %v1419, i64 16
  store ptr %v1395, ptr %v1421, align 8, !tbaa !3
  %v1422 = getelementptr i8, ptr %v1419, i64 24
  store ptr %v1397, ptr %v1422, align 8, !tbaa !3
  %v1423 = call ptr @mlf_prim3(i64 33, ptr %v1391, ptr inttoptr (i64 1 to ptr), ptr %v1417)
  ret ptr %v1423
}

define private ptr @mlf.code.1456(ptr %env, ptr %arg) {
entry:
  %v1457 = getelementptr i8, ptr %env, i64 8
  %v1458 = load ptr, ptr %v1457, align 8, !tbaa !3
  %v1459 = getelementptr i8, ptr %env, i64 16
  %v1460 = load ptr, ptr %v1459, align 8, !tbaa !3
  %v1461 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1461, align 8, !tbaa !3
  %v1462 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1462, align 8, !tbaa !3
  %v1463 = call ptr @mlf.force(ptr %v1460)
  %v1464 = call ptr @mlf.force(ptr %v1458)
  %v1465 = call ptr @mlf_prim2(i64 20, ptr %v1464, ptr %v1464)
  %v1466 = call ptr @mlf_prim2(i64 18, ptr %v1463, ptr %v1465)
  ret ptr %v1466
}

define private ptr @mlf.code.1446(ptr %env, ptr %arg) {
entry:
  %v1447 = getelementptr i8, ptr %env, i64 8
  %v1448 = load ptr, ptr %v1447, align 8, !tbaa !3
  %v1449 = getelementptr i8, ptr %env, i64 16
  %v1450 = load ptr, ptr %v1449, align 8, !tbaa !3
  %v1451 = getelementptr i8, ptr %env, i64 24
  %v1452 = load ptr, ptr %v1451, align 8, !tbaa !3
  %v1453 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1453, align 8, !tbaa !3
  %v1454 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1454, align 8, !tbaa !3
  %v1455 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v1455, align 8, !tbaa !3
  %v1467 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1456, i64 2)
  %v1468 = getelementptr i8, ptr %v1467, i64 16
  %v1469 = load ptr, ptr %v1468, align 8, !tbaa !3
  %v1470 = getelementptr i8, ptr %v1469, i64 8
  store ptr %v1450, ptr %v1470, align 8, !tbaa !3
  %v1471 = getelementptr i8, ptr %v1469, i64 16
  store ptr %v1452, ptr %v1471, align 8, !tbaa !3
  %v1472 = call ptr @mlf_prim3(i64 33, ptr %v1448, ptr inttoptr (i64 3 to ptr), ptr %v1467)
  ret ptr %v1472
}

define private ptr @mlf.code.1479(ptr %env, ptr %arg) {
entry:
  %v1480 = getelementptr i8, ptr %env, i64 8
  %v1481 = load ptr, ptr %v1480, align 8, !tbaa !3
  %v1482 = getelementptr i8, ptr %env, i64 16
  %v1483 = load ptr, ptr %v1482, align 8, !tbaa !3
  %v1484 = getelementptr i8, ptr %env, i64 24
  %v1485 = load ptr, ptr %v1484, align 8, !tbaa !3
  %v1486 = getelementptr i8, ptr %env, i64 32
  %v1487 = load ptr, ptr %v1486, align 8, !tbaa !3
  %v1488 = getelementptr i8, ptr %env, i64 40
  %v1489 = load ptr, ptr %v1488, align 8, !tbaa !3
  %v1490 = call ptr @mlf.force(ptr %v1481)
  %v1491 = call ptr @mlf.force(ptr %v1489)
  %v1492 = call ptr @mlf_prim2(i64 8, ptr %v1491, ptr inttoptr (i64 3 to ptr))
  %v1493 = call ptr @mlf_env_new(i64 5)
  %v1494 = getelementptr i8, ptr %v1493, i64 8
  store ptr %v1490, ptr %v1494, align 8, !tbaa !3
  %v1495 = getelementptr i8, ptr %v1493, i64 16
  store ptr %v1483, ptr %v1495, align 8, !tbaa !3
  %v1496 = getelementptr i8, ptr %v1493, i64 24
  store ptr %v1485, ptr %v1496, align 8, !tbaa !3
  %v1497 = getelementptr i8, ptr %v1493, i64 32
  store ptr %v1487, ptr %v1497, align 8, !tbaa !3
  %v1498 = getelementptr i8, ptr %v1493, i64 40
  store ptr %v1492, ptr %v1498, align 8, !tbaa !3
  %v1499 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1158, ptr %v1493)
  ret ptr %v1499
}

define private ptr @mlf.code.1431(ptr %env, ptr %arg) {
entry:
  %v1432 = getelementptr i8, ptr %env, i64 8
  %v1433 = load ptr, ptr %v1432, align 8, !tbaa !3
  %v1434 = getelementptr i8, ptr %env, i64 16
  %v1435 = load ptr, ptr %v1434, align 8, !tbaa !3
  %v1436 = getelementptr i8, ptr %env, i64 24
  %v1437 = load ptr, ptr %v1436, align 8, !tbaa !3
  %v1438 = getelementptr i8, ptr %env, i64 32
  %v1439 = load ptr, ptr %v1438, align 8, !tbaa !3
  %v1440 = getelementptr i8, ptr %env, i64 40
  %v1441 = load ptr, ptr %v1440, align 8, !tbaa !3
  %v1442 = getelementptr i8, ptr %env, i64 48
  %v1443 = load ptr, ptr %v1442, align 8, !tbaa !3
  %v1444 = getelementptr i8, ptr %env, i64 56
  %v1445 = load ptr, ptr %v1444, align 8, !tbaa !3
  %v1473 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1446, i64 3)
  %v1474 = getelementptr i8, ptr %v1473, i64 16
  %v1475 = load ptr, ptr %v1474, align 8, !tbaa !3
  %v1476 = getelementptr i8, ptr %v1475, i64 8
  store ptr %v1439, ptr %v1476, align 8, !tbaa !3
  %v1477 = getelementptr i8, ptr %v1475, i64 16
  store ptr %v1443, ptr %v1477, align 8, !tbaa !3
  %v1478 = getelementptr i8, ptr %v1475, i64 24
  store ptr %v1445, ptr %v1478, align 8, !tbaa !3
  %v1500 = call ptr @mlf_env_new(i64 5)
  %v1501 = getelementptr i8, ptr %v1500, i64 8
  store ptr %v1433, ptr %v1501, align 8, !tbaa !3
  %v1502 = getelementptr i8, ptr %v1500, i64 16
  store ptr %v1435, ptr %v1502, align 8, !tbaa !3
  %v1503 = getelementptr i8, ptr %v1500, i64 24
  store ptr %v1437, ptr %v1503, align 8, !tbaa !3
  %v1504 = getelementptr i8, ptr %v1500, i64 32
  store ptr %v1439, ptr %v1504, align 8, !tbaa !3
  %v1505 = getelementptr i8, ptr %v1500, i64 40
  store ptr %v1441, ptr %v1505, align 8, !tbaa !3
  %v1506 = call ptr @mlf_closure(ptr @mlf.code.1479, ptr %v1500)
  %v1507 = call ptr @mlf_prim2(i64 1, ptr %v1473, ptr %v1506)
  ret ptr %v1507
}

define private ptr @mlf.code.1372(ptr %env, ptr %arg) {
entry:
  %v1373 = getelementptr i8, ptr %env, i64 8
  %v1374 = load ptr, ptr %v1373, align 8, !tbaa !3
  %v1375 = getelementptr i8, ptr %env, i64 16
  %v1376 = load ptr, ptr %v1375, align 8, !tbaa !3
  %v1377 = getelementptr i8, ptr %env, i64 24
  %v1378 = load ptr, ptr %v1377, align 8, !tbaa !3
  %v1379 = getelementptr i8, ptr %env, i64 32
  %v1380 = load ptr, ptr %v1379, align 8, !tbaa !3
  %v1381 = getelementptr i8, ptr %env, i64 40
  %v1382 = load ptr, ptr %v1381, align 8, !tbaa !3
  %v1383 = getelementptr i8, ptr %env, i64 48
  %v1384 = load ptr, ptr %v1383, align 8, !tbaa !3
  %v1385 = getelementptr i8, ptr %env, i64 56
  %v1386 = load ptr, ptr %v1385, align 8, !tbaa !3
  %v1387 = getelementptr i8, ptr %env, i64 64
  %v1388 = load ptr, ptr %v1387, align 8, !tbaa !3
  %v1424 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1389, i64 4)
  %v1425 = getelementptr i8, ptr %v1424, i64 16
  %v1426 = load ptr, ptr %v1425, align 8, !tbaa !3
  %v1427 = getelementptr i8, ptr %v1426, i64 8
  store ptr %v1380, ptr %v1427, align 8, !tbaa !3
  %v1428 = getelementptr i8, ptr %v1426, i64 16
  store ptr %v1384, ptr %v1428, align 8, !tbaa !3
  %v1429 = getelementptr i8, ptr %v1426, i64 24
  store ptr %v1386, ptr %v1429, align 8, !tbaa !3
  %v1430 = getelementptr i8, ptr %v1426, i64 32
  store ptr %v1388, ptr %v1430, align 8, !tbaa !3
  %v1508 = call ptr @mlf_env_new(i64 7)
  %v1509 = getelementptr i8, ptr %v1508, i64 8
  store ptr %v1374, ptr %v1509, align 8, !tbaa !3
  %v1510 = getelementptr i8, ptr %v1508, i64 16
  store ptr %v1376, ptr %v1510, align 8, !tbaa !3
  %v1511 = getelementptr i8, ptr %v1508, i64 24
  store ptr %v1378, ptr %v1511, align 8, !tbaa !3
  %v1512 = getelementptr i8, ptr %v1508, i64 32
  store ptr %v1380, ptr %v1512, align 8, !tbaa !3
  %v1513 = getelementptr i8, ptr %v1508, i64 40
  store ptr %v1382, ptr %v1513, align 8, !tbaa !3
  %v1514 = getelementptr i8, ptr %v1508, i64 48
  store ptr %v1386, ptr %v1514, align 8, !tbaa !3
  %v1515 = getelementptr i8, ptr %v1508, i64 56
  store ptr %arg, ptr %v1515, align 8, !tbaa !3
  %v1516 = call ptr @mlf_closure(ptr @mlf.code.1431, ptr %v1508)
  %v1517 = call ptr @mlf_prim2(i64 1, ptr %v1424, ptr %v1516)
  ret ptr %v1517
}

define private ptr @mlf.code.1348(ptr %env, ptr %arg) {
entry:
  %v1349 = getelementptr i8, ptr %env, i64 8
  %v1350 = load ptr, ptr %v1349, align 8, !tbaa !3
  %v1351 = getelementptr i8, ptr %env, i64 16
  %v1352 = load ptr, ptr %v1351, align 8, !tbaa !3
  %v1353 = getelementptr i8, ptr %env, i64 24
  %v1354 = load ptr, ptr %v1353, align 8, !tbaa !3
  %v1355 = getelementptr i8, ptr %env, i64 32
  %v1356 = load ptr, ptr %v1355, align 8, !tbaa !3
  %v1357 = getelementptr i8, ptr %env, i64 40
  %v1358 = load ptr, ptr %v1357, align 8, !tbaa !3
  %v1359 = getelementptr i8, ptr %env, i64 48
  %v1360 = load ptr, ptr %v1359, align 8, !tbaa !3
  %v1361 = getelementptr i8, ptr %env, i64 56
  %v1362 = load ptr, ptr %v1361, align 8, !tbaa !3
  %v1368 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1363, i64 1)
  %v1369 = getelementptr i8, ptr %v1368, i64 16
  %v1370 = load ptr, ptr %v1369, align 8, !tbaa !3
  %v1371 = getelementptr i8, ptr %v1370, i64 8
  store ptr %v1356, ptr %v1371, align 8, !tbaa !3
  %v1518 = call ptr @mlf_env_new(i64 8)
  %v1519 = getelementptr i8, ptr %v1518, i64 8
  store ptr %v1350, ptr %v1519, align 8, !tbaa !3
  %v1520 = getelementptr i8, ptr %v1518, i64 16
  store ptr %v1352, ptr %v1520, align 8, !tbaa !3
  %v1521 = getelementptr i8, ptr %v1518, i64 24
  store ptr %v1354, ptr %v1521, align 8, !tbaa !3
  %v1522 = getelementptr i8, ptr %v1518, i64 32
  store ptr %v1356, ptr %v1522, align 8, !tbaa !3
  %v1523 = getelementptr i8, ptr %v1518, i64 40
  store ptr %v1358, ptr %v1523, align 8, !tbaa !3
  %v1524 = getelementptr i8, ptr %v1518, i64 48
  store ptr %v1360, ptr %v1524, align 8, !tbaa !3
  %v1525 = getelementptr i8, ptr %v1518, i64 56
  store ptr %v1362, ptr %v1525, align 8, !tbaa !3
  %v1526 = getelementptr i8, ptr %v1518, i64 64
  store ptr %arg, ptr %v1526, align 8, !tbaa !3
  %v1527 = call ptr @mlf_closure(ptr @mlf.code.1372, ptr %v1518)
  %v1528 = call ptr @mlf_prim2(i64 1, ptr %v1368, ptr %v1527)
  ret ptr %v1528
}

define private ptr @mlf.code.1326(ptr %env, ptr %arg) {
entry:
  %v1327 = getelementptr i8, ptr %env, i64 8
  %v1328 = load ptr, ptr %v1327, align 8, !tbaa !3
  %v1329 = getelementptr i8, ptr %env, i64 16
  %v1330 = load ptr, ptr %v1329, align 8, !tbaa !3
  %v1331 = getelementptr i8, ptr %env, i64 24
  %v1332 = load ptr, ptr %v1331, align 8, !tbaa !3
  %v1333 = getelementptr i8, ptr %env, i64 32
  %v1334 = load ptr, ptr %v1333, align 8, !tbaa !3
  %v1335 = getelementptr i8, ptr %env, i64 40
  %v1336 = load ptr, ptr %v1335, align 8, !tbaa !3
  %v1337 = getelementptr i8, ptr %env, i64 48
  %v1338 = load ptr, ptr %v1337, align 8, !tbaa !3
  %v1344 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1339, i64 1)
  %v1345 = getelementptr i8, ptr %v1344, i64 16
  %v1346 = load ptr, ptr %v1345, align 8, !tbaa !3
  %v1347 = getelementptr i8, ptr %v1346, i64 8
  store ptr %v1334, ptr %v1347, align 8, !tbaa !3
  %v1529 = call ptr @mlf_env_new(i64 7)
  %v1530 = getelementptr i8, ptr %v1529, i64 8
  store ptr %v1328, ptr %v1530, align 8, !tbaa !3
  %v1531 = getelementptr i8, ptr %v1529, i64 16
  store ptr %v1330, ptr %v1531, align 8, !tbaa !3
  %v1532 = getelementptr i8, ptr %v1529, i64 24
  store ptr %v1332, ptr %v1532, align 8, !tbaa !3
  %v1533 = getelementptr i8, ptr %v1529, i64 32
  store ptr %v1334, ptr %v1533, align 8, !tbaa !3
  %v1534 = getelementptr i8, ptr %v1529, i64 40
  store ptr %v1336, ptr %v1534, align 8, !tbaa !3
  %v1535 = getelementptr i8, ptr %v1529, i64 48
  store ptr %v1338, ptr %v1535, align 8, !tbaa !3
  %v1536 = getelementptr i8, ptr %v1529, i64 56
  store ptr %arg, ptr %v1536, align 8, !tbaa !3
  %v1537 = call ptr @mlf_closure(ptr @mlf.code.1348, ptr %v1529)
  %v1538 = call ptr @mlf_prim2(i64 1, ptr %v1344, ptr %v1537)
  ret ptr %v1538
}

define private ptr @mlf.code.1302(ptr %env, ptr %arg) {
entry:
  %v1303 = getelementptr i8, ptr %env, i64 8
  %v1304 = load ptr, ptr %v1303, align 8, !tbaa !3
  %v1305 = getelementptr i8, ptr %env, i64 16
  %v1306 = load ptr, ptr %v1305, align 8, !tbaa !3
  %v1307 = getelementptr i8, ptr %env, i64 24
  %v1308 = load ptr, ptr %v1307, align 8, !tbaa !3
  %v1309 = getelementptr i8, ptr %env, i64 32
  %v1310 = load ptr, ptr %v1309, align 8, !tbaa !3
  %v1311 = getelementptr i8, ptr %env, i64 40
  %v1312 = load ptr, ptr %v1311, align 8, !tbaa !3
  %v1321 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1313, i64 2)
  %v1322 = getelementptr i8, ptr %v1321, i64 16
  %v1323 = load ptr, ptr %v1322, align 8, !tbaa !3
  %v1324 = getelementptr i8, ptr %v1323, i64 8
  store ptr %v1308, ptr %v1324, align 8, !tbaa !3
  %v1325 = getelementptr i8, ptr %v1323, i64 16
  store ptr %v1312, ptr %v1325, align 8, !tbaa !3
  %v1539 = call ptr @mlf_env_new(i64 6)
  %v1540 = getelementptr i8, ptr %v1539, i64 8
  store ptr %v1304, ptr %v1540, align 8, !tbaa !3
  %v1541 = getelementptr i8, ptr %v1539, i64 16
  store ptr %v1306, ptr %v1541, align 8, !tbaa !3
  %v1542 = getelementptr i8, ptr %v1539, i64 24
  store ptr %v1308, ptr %v1542, align 8, !tbaa !3
  %v1543 = getelementptr i8, ptr %v1539, i64 32
  store ptr %v1310, ptr %v1543, align 8, !tbaa !3
  %v1544 = getelementptr i8, ptr %v1539, i64 40
  store ptr %v1312, ptr %v1544, align 8, !tbaa !3
  %v1545 = getelementptr i8, ptr %v1539, i64 48
  store ptr %arg, ptr %v1545, align 8, !tbaa !3
  %v1546 = call ptr @mlf_closure(ptr @mlf.code.1326, ptr %v1539)
  %v1547 = call ptr @mlf_prim2(i64 1, ptr %v1321, ptr %v1546)
  ret ptr %v1547
}

define private ptr @mlf.worker.50(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) {
entry:
  %v1284 = call ptr @mlf_prim2(i64 11, ptr %a4, ptr %a0)
  %v1285 = icmp eq ptr %v1284, inttoptr (i64 6 to ptr)
  br i1 %v1285, label %yes.1286, label %no.1287
yes.1286:
  %v1297 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1289, i64 2)
  %v1298 = getelementptr i8, ptr %v1297, i64 16
  %v1299 = load ptr, ptr %v1298, align 8, !tbaa !3
  %v1300 = getelementptr i8, ptr %v1299, i64 8
  store ptr %a1, ptr %v1300, align 8, !tbaa !3
  %v1301 = getelementptr i8, ptr %v1299, i64 16
  store ptr %a4, ptr %v1301, align 8, !tbaa !3
  %v1548 = call ptr @mlf_env_new(i64 5)
  %v1549 = getelementptr i8, ptr %v1548, i64 8
  store ptr %a0, ptr %v1549, align 8, !tbaa !3
  %v1550 = getelementptr i8, ptr %v1548, i64 16
  store ptr %a1, ptr %v1550, align 8, !tbaa !3
  %v1551 = getelementptr i8, ptr %v1548, i64 24
  store ptr %a2, ptr %v1551, align 8, !tbaa !3
  %v1552 = getelementptr i8, ptr %v1548, i64 32
  store ptr %a3, ptr %v1552, align 8, !tbaa !3
  %v1553 = getelementptr i8, ptr %v1548, i64 40
  store ptr %a4, ptr %v1553, align 8, !tbaa !3
  %v1554 = call ptr @mlf_closure(ptr @mlf.code.1302, ptr %v1548)
  %v1555 = call ptr @mlf_prim2(i64 1, ptr %v1297, ptr %v1554)
  br label %join.1288
no.1287:
  %v1556 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.1288
join.1288:
  %v1557 = phi ptr [ %v1555, %yes.1286 ], [ %v1556, %no.1287 ]
  ret ptr %v1557
}

define private ptr @mlf.numeric.entry.1158(ptr %env, ptr %arg) {
entry:
  %v1159 = getelementptr i8, ptr %env, i64 8
  %v1160 = load ptr, ptr %v1159, align 8, !tbaa !3
  %v1161 = getelementptr i8, ptr %env, i64 16
  %v1162 = load ptr, ptr %v1161, align 8, !tbaa !3
  %v1163 = getelementptr i8, ptr %env, i64 24
  %v1164 = load ptr, ptr %v1163, align 8, !tbaa !3
  %v1165 = getelementptr i8, ptr %env, i64 32
  %v1166 = load ptr, ptr %v1165, align 8, !tbaa !3
  %v1167 = getelementptr i8, ptr %env, i64 40
  %v1168 = load ptr, ptr %v1167, align 8, !tbaa !3
  %v1169 = call ptr @mlf_peek(ptr %v1160)
  %v1170 = call ptr @mlf_peek(ptr %v1162)
  %v1171 = call ptr @mlf_peek(ptr %v1164)
  %v1172 = call ptr @mlf_peek(ptr %v1166)
  %v1173 = call ptr @mlf_peek(ptr %v1168)
  %v1174 = icmp ne ptr %v1169, null
  %v1175 = icmp ne ptr %v1170, null
  %v1176 = icmp ne ptr %v1171, null
  %v1177 = icmp ne ptr %v1172, null
  %v1178 = icmp ne ptr %v1173, null
  %v1179 = and i1 true, %v1174
  %v1180 = and i1 %v1179, %v1175
  %v1181 = and i1 %v1180, %v1176
  %v1182 = and i1 %v1181, %v1177
  %v1183 = and i1 %v1182, %v1178
  br i1 %v1183, label %yes.1184, label %no.1185
yes.1184:
  %v1282 = call ptr @mlf.numeric.50(ptr %v1169, ptr %v1170, ptr %v1171, ptr %v1172, ptr %v1173)
  %v1283 = call ptr @mlf_prim1(i64 0, ptr %v1282)
  br label %join.1186
no.1185:
  %v1558 = call ptr @mlf.force(ptr %v1160)
  %v1559 = call ptr @mlf.force(ptr %v1168)
  %v1560 = call ptr @mlf.worker.50(ptr %v1558, ptr %v1162, ptr %v1164, ptr %v1166, ptr %v1559)
  br label %join.1186
join.1186:
  %v1561 = phi ptr [ %v1283, %yes.1184 ], [ %v1560, %no.1185 ]
  ret ptr %v1561
}

define private ptr @mlf.code.1145(ptr %env, ptr %arg) {
entry:
  %v1146 = getelementptr i8, ptr %env, i64 8
  %v1147 = load ptr, ptr %v1146, align 8, !tbaa !3
  %v1148 = getelementptr i8, ptr %env, i64 16
  %v1149 = load ptr, ptr %v1148, align 8, !tbaa !3
  %v1150 = getelementptr i8, ptr %env, i64 24
  %v1151 = load ptr, ptr %v1150, align 8, !tbaa !3
  %v1152 = getelementptr i8, ptr %env, i64 32
  %v1153 = load ptr, ptr %v1152, align 8, !tbaa !3
  %v1154 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1154, align 8, !tbaa !3
  %v1155 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1155, align 8, !tbaa !3
  %v1156 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v1156, align 8, !tbaa !3
  %v1157 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v1157, align 8, !tbaa !3
  %v1562 = call ptr @mlf.force(ptr %v1147)
  %v1563 = call ptr @mlf_env_new(i64 5)
  %v1564 = getelementptr i8, ptr %v1563, i64 8
  store ptr %v1562, ptr %v1564, align 8, !tbaa !3
  %v1565 = getelementptr i8, ptr %v1563, i64 16
  store ptr %v1149, ptr %v1565, align 8, !tbaa !3
  %v1566 = getelementptr i8, ptr %v1563, i64 24
  store ptr %v1151, ptr %v1566, align 8, !tbaa !3
  %v1567 = getelementptr i8, ptr %v1563, i64 32
  store ptr %v1153, ptr %v1567, align 8, !tbaa !3
  %v1568 = getelementptr i8, ptr %v1563, i64 40
  store ptr inttoptr (i64 1 to ptr), ptr %v1568, align 8, !tbaa !3
  %v1569 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1158, ptr %v1563)
  ret ptr %v1569
}

define private ptr @mlf.code.1580(ptr %env, ptr %arg) {
entry:
  %v1581 = getelementptr i8, ptr %env, i64 8
  %v1582 = load ptr, ptr %v1581, align 8, !tbaa !3
  %v1583 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1583, align 8, !tbaa !3
  %v1584 = call ptr @mlf_prim2(i64 32, ptr %v1582, ptr inttoptr (i64 1 to ptr))
  ret ptr %v1584
}

define private ptr @mlf.code.1592(ptr %env, ptr %arg) {
entry:
  %v1593 = getelementptr i8, ptr %env, i64 8
  %v1594 = load ptr, ptr %v1593, align 8, !tbaa !3
  %v1595 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1595, align 8, !tbaa !3
  %v1596 = call ptr @mlf_prim2(i64 32, ptr %v1594, ptr inttoptr (i64 3 to ptr))
  ret ptr %v1596
}

define private ptr @mlf.code.1604(ptr %env, ptr %arg) {
entry:
  %v1605 = getelementptr i8, ptr %env, i64 8
  %v1606 = load ptr, ptr %v1605, align 8, !tbaa !3
  %v1607 = getelementptr i8, ptr %env, i64 16
  %v1608 = load ptr, ptr %v1607, align 8, !tbaa !3
  %v1609 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1609, align 8, !tbaa !3
  %v1610 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1610, align 8, !tbaa !3
  %v1611 = call ptr @mlf.force(ptr %v1606)
  %v1612 = call ptr @mlf.force(ptr %v1608)
  %v1613 = getelementptr i8, ptr %v1611, i64 8
  %v1614 = load double, ptr %v1613, align 8, !tbaa !3
  %v1615 = getelementptr i8, ptr %v1612, i64 8
  %v1616 = load double, ptr %v1615, align 8, !tbaa !3
  %v1617 = fdiv double %v1614, %v1616
  %v1618 = call ptr @mlf_double(double %v1617)
  %v1619 = getelementptr i8, ptr %v1618, i64 8
  %v1620 = load double, ptr %v1619, align 8, !tbaa !3
  %v1621 = call double @llvm.sqrt.f64(double %v1620)
  %v1622 = call ptr @mlf_double(double %v1621)
  %v1623 = call ptr @mlf_prim2(i64 26, ptr inttoptr (i64 19 to ptr), ptr %v1622)
  ret ptr %v1623
}

define private ptr @mlf.code.1601(ptr %env, ptr %arg) {
entry:
  %v1602 = getelementptr i8, ptr %env, i64 8
  %v1603 = load ptr, ptr %v1602, align 8, !tbaa !3
  %v1624 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1604, i64 2)
  %v1625 = getelementptr i8, ptr %v1624, i64 16
  %v1626 = load ptr, ptr %v1625, align 8, !tbaa !3
  %v1627 = getelementptr i8, ptr %v1626, i64 8
  store ptr %v1603, ptr %v1627, align 8, !tbaa !3
  %v1628 = getelementptr i8, ptr %v1626, i64 16
  store ptr %arg, ptr %v1628, align 8, !tbaa !3
  %v1629 = call ptr @mlf_prim1(i64 3, ptr %v1624)
  ret ptr %v1629
}

define private ptr @mlf.code.1589(ptr %env, ptr %arg) {
entry:
  %v1590 = getelementptr i8, ptr %env, i64 8
  %v1591 = load ptr, ptr %v1590, align 8, !tbaa !3
  %v1597 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1592, i64 1)
  %v1598 = getelementptr i8, ptr %v1597, i64 16
  %v1599 = load ptr, ptr %v1598, align 8, !tbaa !3
  %v1600 = getelementptr i8, ptr %v1599, i64 8
  store ptr %v1591, ptr %v1600, align 8, !tbaa !3
  %v1630 = call ptr @mlf_env_new(i64 1)
  %v1631 = getelementptr i8, ptr %v1630, i64 8
  store ptr %arg, ptr %v1631, align 8, !tbaa !3
  %v1632 = call ptr @mlf_closure(ptr @mlf.code.1601, ptr %v1630)
  %v1633 = call ptr @mlf_prim2(i64 1, ptr %v1597, ptr %v1632)
  ret ptr %v1633
}

define private ptr @mlf.code.1577(ptr %env, ptr %arg) {
entry:
  %v1578 = getelementptr i8, ptr %env, i64 8
  %v1579 = load ptr, ptr %v1578, align 8, !tbaa !3
  %v1585 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1580, i64 1)
  %v1586 = getelementptr i8, ptr %v1585, i64 16
  %v1587 = load ptr, ptr %v1586, align 8, !tbaa !3
  %v1588 = getelementptr i8, ptr %v1587, i64 8
  store ptr %v1579, ptr %v1588, align 8, !tbaa !3
  %v1634 = call ptr @mlf_env_new(i64 1)
  %v1635 = getelementptr i8, ptr %v1634, i64 8
  store ptr %v1579, ptr %v1635, align 8, !tbaa !3
  %v1636 = call ptr @mlf_closure(ptr @mlf.code.1589, ptr %v1634)
  %v1637 = call ptr @mlf_prim2(i64 1, ptr %v1585, ptr %v1636)
  ret ptr %v1637
}

define private ptr @mlf.code.1136(ptr %env, ptr %arg) {
entry:
  %v1137 = getelementptr i8, ptr %env, i64 8
  %v1138 = load ptr, ptr %v1137, align 8, !tbaa !3
  %v1139 = getelementptr i8, ptr %env, i64 16
  %v1140 = load ptr, ptr %v1139, align 8, !tbaa !3
  %v1141 = getelementptr i8, ptr %env, i64 24
  %v1142 = load ptr, ptr %v1141, align 8, !tbaa !3
  %v1143 = getelementptr i8, ptr %env, i64 32
  %v1144 = load ptr, ptr %v1143, align 8, !tbaa !3
  %v1570 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1145, i64 4)
  %v1571 = getelementptr i8, ptr %v1570, i64 16
  %v1572 = load ptr, ptr %v1571, align 8, !tbaa !3
  %v1573 = getelementptr i8, ptr %v1572, i64 8
  store ptr %v1138, ptr %v1573, align 8, !tbaa !3
  %v1574 = getelementptr i8, ptr %v1572, i64 16
  store ptr %v1140, ptr %v1574, align 8, !tbaa !3
  %v1575 = getelementptr i8, ptr %v1572, i64 24
  store ptr %v1142, ptr %v1575, align 8, !tbaa !3
  %v1576 = getelementptr i8, ptr %v1572, i64 32
  store ptr %v1144, ptr %v1576, align 8, !tbaa !3
  %v1638 = call ptr @mlf_env_new(i64 1)
  %v1639 = getelementptr i8, ptr %v1638, i64 8
  store ptr %v1144, ptr %v1639, align 8, !tbaa !3
  %v1640 = call ptr @mlf_closure(ptr @mlf.code.1577, ptr %v1638)
  %v1641 = call ptr @mlf_prim2(i64 1, ptr %v1570, ptr %v1640)
  ret ptr %v1641
}

define private ptr @mlf.code.62(ptr %env, ptr %arg) {
entry:
  %v63 = getelementptr i8, ptr %env, i64 8
  %v64 = load ptr, ptr %v63, align 8, !tbaa !3
  %v65 = getelementptr i8, ptr %env, i64 16
  %v66 = load ptr, ptr %v65, align 8, !tbaa !3
  %v67 = getelementptr i8, ptr %env, i64 24
  %v68 = load ptr, ptr %v67, align 8, !tbaa !3
  %v69 = getelementptr i8, ptr %env, i64 32
  %v70 = load ptr, ptr %v69, align 8, !tbaa !3
  %v1129 = call ptr @mlf.allocate.thunk(ptr @mlf.code.71, i64 4)
  %v1130 = getelementptr i8, ptr %v1129, i64 16
  %v1131 = load ptr, ptr %v1130, align 8, !tbaa !3
  %v1132 = getelementptr i8, ptr %v1131, i64 8
  store ptr %v64, ptr %v1132, align 8, !tbaa !3
  %v1133 = getelementptr i8, ptr %v1131, i64 16
  store ptr %v66, ptr %v1133, align 8, !tbaa !3
  %v1134 = getelementptr i8, ptr %v1131, i64 24
  store ptr %v68, ptr %v1134, align 8, !tbaa !3
  %v1135 = getelementptr i8, ptr %v1131, i64 32
  store ptr %v70, ptr %v1135, align 8, !tbaa !3
  %v1642 = call ptr @mlf_env_new(i64 4)
  %v1643 = getelementptr i8, ptr %v1642, i64 8
  store ptr %v64, ptr %v1643, align 8, !tbaa !3
  %v1644 = getelementptr i8, ptr %v1642, i64 16
  store ptr %v66, ptr %v1644, align 8, !tbaa !3
  %v1645 = getelementptr i8, ptr %v1642, i64 24
  store ptr %v68, ptr %v1645, align 8, !tbaa !3
  %v1646 = getelementptr i8, ptr %v1642, i64 32
  store ptr %arg, ptr %v1646, align 8, !tbaa !3
  %v1647 = call ptr @mlf_closure(ptr @mlf.code.1136, ptr %v1642)
  %v1648 = call ptr @mlf_prim2(i64 1, ptr %v1129, ptr %v1647)
  ret ptr %v1648
}

define private ptr @mlf.code.51(ptr %env, ptr %arg) {
entry:
  %v52 = getelementptr i8, ptr %env, i64 8
  %v53 = load ptr, ptr %v52, align 8, !tbaa !3
  %v54 = getelementptr i8, ptr %env, i64 16
  %v55 = load ptr, ptr %v54, align 8, !tbaa !3
  %v56 = getelementptr i8, ptr %env, i64 24
  %v57 = load ptr, ptr %v56, align 8, !tbaa !3
  %v61 = call ptr @mlf_thunk(ptr @mlf.code.58, ptr null)
  %v1649 = call ptr @mlf_env_new(i64 4)
  %v1650 = getelementptr i8, ptr %v1649, i64 8
  store ptr %v53, ptr %v1650, align 8, !tbaa !3
  %v1651 = getelementptr i8, ptr %v1649, i64 16
  store ptr %v55, ptr %v1651, align 8, !tbaa !3
  %v1652 = getelementptr i8, ptr %v1649, i64 24
  store ptr %v57, ptr %v1652, align 8, !tbaa !3
  %v1653 = getelementptr i8, ptr %v1649, i64 32
  store ptr %arg, ptr %v1653, align 8, !tbaa !3
  %v1654 = call ptr @mlf_closure(ptr @mlf.code.62, ptr %v1649)
  %v1655 = call ptr @mlf_prim2(i64 1, ptr %v61, ptr %v1654)
  ret ptr %v1655
}

define private ptr @mlf.code.36(ptr %env, ptr %arg) {
entry:
  %v37 = getelementptr i8, ptr %env, i64 8
  %v38 = load ptr, ptr %v37, align 8, !tbaa !3
  %v39 = getelementptr i8, ptr %env, i64 16
  %v40 = load ptr, ptr %v39, align 8, !tbaa !3
  %v47 = call ptr @mlf.allocate.thunk(ptr @mlf.code.41, i64 1)
  %v48 = getelementptr i8, ptr %v47, i64 16
  %v49 = load ptr, ptr %v48, align 8, !tbaa !3
  %v50 = getelementptr i8, ptr %v49, i64 8
  store ptr %v38, ptr %v50, align 8, !tbaa !3
  %v1656 = call ptr @mlf_env_new(i64 3)
  %v1657 = getelementptr i8, ptr %v1656, i64 8
  store ptr %v38, ptr %v1657, align 8, !tbaa !3
  %v1658 = getelementptr i8, ptr %v1656, i64 16
  store ptr %v40, ptr %v1658, align 8, !tbaa !3
  %v1659 = getelementptr i8, ptr %v1656, i64 24
  store ptr %arg, ptr %v1659, align 8, !tbaa !3
  %v1660 = call ptr @mlf_closure(ptr @mlf.code.51, ptr %v1656)
  %v1661 = call ptr @mlf_prim2(i64 1, ptr %v47, ptr %v1660)
  ret ptr %v1661
}

define private ptr @mlf.code.23(ptr %env, ptr %arg) {
entry:
  %v24 = getelementptr i8, ptr %env, i64 8
  %v25 = load ptr, ptr %v24, align 8, !tbaa !3
  %v32 = call ptr @mlf.allocate.thunk(ptr @mlf.code.26, i64 1)
  %v33 = getelementptr i8, ptr %v32, i64 16
  %v34 = load ptr, ptr %v33, align 8, !tbaa !3
  %v35 = getelementptr i8, ptr %v34, i64 8
  store ptr %v25, ptr %v35, align 8, !tbaa !3
  %v1662 = call ptr @mlf_env_new(i64 2)
  %v1663 = getelementptr i8, ptr %v1662, i64 8
  store ptr %v25, ptr %v1663, align 8, !tbaa !3
  %v1664 = getelementptr i8, ptr %v1662, i64 16
  store ptr %arg, ptr %v1664, align 8, !tbaa !3
  %v1665 = call ptr @mlf_closure(ptr @mlf.code.36, ptr %v1662)
  %v1666 = call ptr @mlf_prim2(i64 1, ptr %v32, ptr %v1665)
  ret ptr %v1666
}

define private ptr @mlf.code.2(ptr %env, ptr %arg) {
entry:
  %v9 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3, i64 1)
  %v10 = getelementptr i8, ptr %v9, i64 16
  %v11 = load ptr, ptr %v10, align 8, !tbaa !3
  %v12 = getelementptr i8, ptr %v11, i64 8
  store ptr %arg, ptr %v12, align 8, !tbaa !3
  %v19 = call ptr @mlf.allocate.thunk(ptr @mlf.code.13, i64 1)
  %v20 = getelementptr i8, ptr %v19, i64 16
  %v21 = load ptr, ptr %v20, align 8, !tbaa !3
  %v22 = getelementptr i8, ptr %v21, i64 8
  store ptr %v9, ptr %v22, align 8, !tbaa !3
  %v1667 = call ptr @mlf_env_new(i64 1)
  %v1668 = getelementptr i8, ptr %v1667, i64 8
  store ptr %v9, ptr %v1668, align 8, !tbaa !3
  %v1669 = call ptr @mlf_closure(ptr @mlf.code.23, ptr %v1667)
  %v1670 = call ptr @mlf_prim2(i64 1, ptr %v19, ptr %v1669)
  ret ptr %v1670
}

define private ptr @mlf.code.0(ptr %env, ptr %arg) {
entry:
  %v1 = call ptr @mlf_primitive(i64 4)
  %v1671 = call ptr @mlf_closure(ptr @mlf.code.2, ptr null)
  %v1672 = call ptr @mlf_prim2(i64 1, ptr %v1, ptr %v1671)
  ret ptr %v1672
}

declare void @mlf_require_compact_gc_abi()
define ptr @mlf_entry() {
  call void @mlf_require_compact_gc_abi()
  %root = call ptr @mlf.code.0(ptr null, ptr null)
  ret ptr %root
}
define i32 @main(i32 %argc, ptr %argv) {
  call void @mlf_set_args(i32 %argc, ptr %argv)
  %root = call ptr @mlf_entry()
  %status = call i32 @mlf_run(ptr %root, i64 1)
  ret i32 %status
}
