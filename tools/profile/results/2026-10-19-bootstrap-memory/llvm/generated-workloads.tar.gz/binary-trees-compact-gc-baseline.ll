; Generated from independently checked xMLF.
source_filename = "emlf"

declare ptr @mlf_thunk_new(ptr, i64)
declare ptr @mlf_execute_st_lazy(ptr)
declare ptr @mlf_st_new_array(ptr, ptr)
declare ptr @mlf_st_read_array(ptr, ptr)
declare ptr @mlf_st_write_array(ptr, ptr, ptr)
declare ptr @mlf_st_length_array(ptr)
declare void @mlf_set_args(i32, ptr)
declare ptr @mlf_env_new(i64)
declare void @mlf_env_set(ptr, i64, ptr)
declare ptr @mlf_env_get(ptr, i64)
declare ptr @mlf_thunk(ptr, ptr)
declare ptr @mlf_closure(ptr, ptr)
declare ptr @mlf_application(ptr, ptr)
declare ptr @mlf_hole()
declare void @mlf_fill(ptr, ptr)
declare ptr @mlf_integer(ptr)
declare ptr @mlf_string(ptr, i64)
declare ptr @mlf_double(double)
declare double @llvm.sqrt.f64(double)
declare double @mlf_int_to_double(ptr)
declare ptr @mlf_read_int_table(ptr, ptr)
declare ptr @mlf_write_int_table(ptr, ptr, ptr)
declare ptr @mlf_add_int_table(ptr, ptr, ptr)
declare void @mlf_roots_enter(ptr, i64, ptr)
declare void @mlf_roots_leave(ptr)
declare void @mlf_gc_check(i64, ptr)
declare ptr @mlf_get_byte_line()
declare ptr @mlf_new_array(i64, ptr, ptr)
declare ptr @mlf_bytes_from_string(ptr)
declare ptr @mlf_put_bytes(ptr, ptr, ptr)
declare ptr @mlf_new_int_table()
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare i8 @mlf_byte(ptr)
declare ptr @mlf_peek(ptr)
declare ptr @mlf_native_io(ptr, ptr)
declare void @mlf_bounds_failure() noreturn
declare ptr @mlf_primitive(i64)
declare ptr @mlf_prim1(i64, ptr)
declare ptr @mlf_prim2(i64, ptr, ptr)
declare i64 @mlf_truth(ptr)
declare ptr @mlf_prim3(i64, ptr, ptr, ptr)
declare ptr @mlf_force(ptr)
declare ptr @mlf_add_int(ptr, ptr)
declare ptr @mlf_sub_int(ptr, ptr)
declare ptr @mlf_eq_int(ptr, ptr)
declare ptr @mlf_lt_int(ptr, ptr)
declare ptr @mlf_constructor(i64, i64)
declare ptr @mlf_constructor1(i64, ptr)
declare ptr @mlf_constructor2(i64, ptr, ptr)
declare ptr @mlf_constructor_fields(i64, ptr)
declare ptr @mlf_constructor_new(i64, i64)
declare ptr @mlf_field(ptr, i64)
declare void @mlf_match_failure() noreturn
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare i32 @mlf_run(ptr, i64)

@mlf_constructor_pending = external global [33 x ptr]
declare ptr @mlf_constructor_allocate(i64, i64)
define private ptr @mlf.allocate.constructor(i64 %identity, i64 %count, i64 %size) alwaysinline {
entry:
  %small = icmp ule i64 %size, 256
  br i1 %small, label %batch, label %slow
batch:
  %index = lshr i64 %size, 3
  %slot = getelementptr [33 x ptr], ptr @mlf_constructor_pending, i64 0, i64 %index
  %value = load ptr, ptr %slot, align 8
  %empty = icmp eq ptr %value, null
  br i1 %empty, label %slow, label %ready
ready:
  %next = load ptr, ptr %value, align 8
  store ptr %next, ptr %slot, align 8
  store i64 0, ptr %value, align 8
  ret ptr %value
slow:
  %allocated = call ptr @mlf_constructor_allocate(i64 %identity, i64 %count)
  ret ptr %allocated
}
define private ptr @mlf.construct.1(i64 %identity, ptr %a) alwaysinline {
entry:
  %value = call ptr @mlf.allocate.constructor(i64 %identity, i64 1, i64 24)
  store i32 12, ptr %value, align 4
  %id = getelementptr i8, ptr %value, i64 8
  store i64 %identity, ptr %id, align 8
  %first = getelementptr i8, ptr %value, i64 16
  store ptr %a, ptr %first, align 8
  ret ptr %value
}
define private ptr @mlf.construct.2(i64 %identity, ptr %a, ptr %b) alwaysinline {
entry:
  %value = call ptr @mlf.allocate.constructor(i64 %identity, i64 2, i64 32)
  store i32 13, ptr %value, align 4
  %id = getelementptr i8, ptr %value, i64 8
  store i64 %identity, ptr %id, align 8
  %first = getelementptr i8, ptr %value, i64 16
  store ptr %a, ptr %first, align 8
  %second = getelementptr i8, ptr %value, i64 24
  store ptr %b, ptr %second, align 8
  ret ptr %value
}
define private ptr @mlf.construct.wide(i64 %identity, i64 %count) alwaysinline {
entry:
  %fields = mul i64 %count, 8
  %size = add i64 %fields, 24
  %value = call ptr @mlf.allocate.constructor(i64 %identity, i64 %count, i64 %size)
  store i32 28, ptr %value, align 4
  %id = getelementptr i8, ptr %value, i64 8
  store i64 %identity, ptr %id, align 8
  %arity = getelementptr i8, ptr %value, i64 16
  store i64 %count, ptr %arity, align 8
  ret ptr %value
}
@mlf_compact_pending = external global [17 x ptr]
define private ptr @mlf.allocate.thunk(ptr %code, i64 %count) alwaysinline {
entry:
  %words = add i64 %count, 4
  %index = lshr i64 %words, 1
  %slot = getelementptr [17 x ptr], ptr @mlf_compact_pending, i64 0, i64 %index
  %value = load ptr, ptr %slot, align 8
  %empty = icmp eq ptr %value, null
  br i1 %empty, label %slow, label %ready
ready:
  %next = load ptr, ptr %value, align 8
  store ptr %next, ptr %slot, align 8
  store i64 3, ptr %value, align 8
  %function = getelementptr i8, ptr %value, i64 8
  store ptr %code, ptr %function, align 8
  %environment = getelementptr i8, ptr %value, i64 24
  %capture = getelementptr i8, ptr %value, i64 16
  store ptr %environment, ptr %capture, align 8
  store i64 %count, ptr %environment, align 8
  ret ptr %value
slow:
  %allocated = call ptr @mlf_thunk_new(ptr %code, i64 %count)
  ret ptr %allocated
}
define private ptr @mlf.force(ptr %value) alwaysinline {
entry:
  %null = icmp eq ptr %value, null
  br i1 %null, label %slow, label %test
test:
  %bits = ptrtoint ptr %value to i64
  %kind = and i64 %bits, 7
  %immediate = icmp ne i64 %kind, 0
  br i1 %immediate, label %done, label %tagged
tagged:
  %tag = load i32, ptr %value, align 4
  %ready = icmp uge i32 %tag, 5
  br i1 %ready, label %done, label %deferred
deferred:
  %isthunk = icmp eq i32 %tag, 3
  br i1 %isthunk, label %enter, label %indirect
indirect:
  %forwarded = icmp eq i32 %tag, 2
  br i1 %forwarded, label %next, label %slow
next:
  %slot = getelementptr i8, ptr %value, i64 8
  %p = load ptr, ptr %slot, align 8
  %missing = icmp eq ptr %p, null
  br i1 %missing, label %slow, label %nexttest
nexttest:
  %pbits = ptrtoint ptr %p to i64
  %pkind = and i64 %pbits, 7
  %pimm = icmp ne i64 %pkind, 0
  br i1 %pimm, label %forward, label %ptagged
ptagged:
  %ptag = load i32, ptr %p, align 4
  %pready = icmp uge i32 %ptag, 5
  br i1 %pready, label %forward, label %slow
forward:
  ret ptr %p
done:
  ret ptr %value
enter:
  %code.slot = getelementptr i8, ptr %value, i64 8
  %env.slot = getelementptr i8, ptr %value, i64 16
  %code = load ptr, ptr %code.slot, align 8
  %env = load ptr, ptr %env.slot, align 8
  store i32 1, ptr %value, align 4
  store ptr null, ptr %code.slot, align 8
  store ptr null, ptr %env.slot, align 8
  %returned = call ptr %code(ptr %env, ptr null)
  %canonical = call ptr @mlf_force(ptr %returned)
  store i32 2, ptr %value, align 4
  store ptr %canonical, ptr %code.slot, align 8
  ret ptr %canonical
slow:
  %result = tail call ptr @mlf_force(ptr %value)
  ret ptr %result
}
!0 = !{!"MLF storage"}
!1 = !{!"managed object", !0}
!2 = !{!"array cells", !0}
!3 = !{!1, !1, i64 0}
!4 = !{!2, !2, i64 0}
@mlf.bytes.99 = private unnamed_addr constant [11 x i8] c"\20\6f\66\20\64\65\70\74\68\20\00", align 1
@mlf.bytes.99.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 10, ptr @mlf.bytes.99, ptr null }, align 8
@mlf.bytes.102 = private unnamed_addr constant [10 x i8] c"\09\20\63\68\65\63\6b\3a\20\00", align 1
@mlf.bytes.102.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 9, ptr @mlf.bytes.102, ptr null }, align 8
@mlf.bytes.116 = private unnamed_addr constant [13 x i8] c"\73\74\72\65\74\63\68\20\74\72\65\65\00", align 1
@mlf.bytes.116.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 12, ptr @mlf.bytes.116, ptr null }, align 8
@mlf.bytes.353 = private unnamed_addr constant [13 x i8] c"\69\6e\76\61\6c\69\64\20\74\72\65\65\00", align 1
@mlf.bytes.353.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 12, ptr @mlf.bytes.353, ptr null }, align 8
@mlf.bytes.627 = private unnamed_addr constant [8 x i8] c"\09\20\74\72\65\65\73\00", align 1
@mlf.bytes.627.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 7, ptr @mlf.bytes.627, ptr null }, align 8
@mlf.bytes.691 = private unnamed_addr constant [16 x i8] c"\6c\6f\6e\67\20\6c\69\76\65\64\20\74\72\65\65\00", align 1
@mlf.bytes.691.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 15, ptr @mlf.bytes.691, ptr null }, align 8
define private ptr @mlf.worker.29(ptr %a0, ptr %a1) {
entry:
  %v7 = call ptr @mlf_prim1(i64 7, ptr %a1)
  %v8 = call ptr @mlf_prim2(i64 12, ptr %a0, ptr %v7)
  %v9 = icmp eq ptr %v8, inttoptr (i64 6 to ptr)
  br i1 %v9, label %yes.10, label %no.11
yes.10:
  br label %join.12
no.11:
  %v13 = ptrtoint ptr %a1 to i64
  %v14 = ptrtoint ptr inttoptr (i64 41 to ptr) to i64
  %v15 = and i64 %v13, %v14
  %v16 = and i64 %v15, 1
  %v17 = icmp ne i64 %v16, 0
  br i1 %v17, label %yes.18, label %no.19
yes.18:
  %v21 = icmp eq i64 %v13, %v14
  %v22 = select i1 %v21, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.20
no.19:
  %v23 = call ptr @mlf_eq_int(ptr %a1, ptr inttoptr (i64 41 to ptr))
  br label %join.20
join.20:
  %v24 = phi ptr [ %v22, %yes.18 ], [ %v23, %no.19 ]
  %v25 = icmp eq ptr %v24, inttoptr (i64 6 to ptr)
  br i1 %v25, label %yes.26, label %no.27
yes.26:
  br label %join.28
no.27:
  %v29 = ptrtoint ptr %a1 to i64
  %v30 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v31 = and i64 %v29, %v30
  %v32 = and i64 %v31, 1
  %v33 = icmp ne i64 %v32, 0
  br i1 %v33, label %yes.34, label %no.35
yes.34:
  %v37 = sub i64 %v30, 1
  %v38 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v29, i64 %v37)
  %v39 = extractvalue { i64, i1 } %v38, 0
  %v40 = extractvalue { i64, i1 } %v38, 1
  br i1 %v40, label %yes.41, label %no.42
yes.41:
  %v44 = call ptr @mlf_add_int(ptr %a1, ptr inttoptr (i64 3 to ptr))
  br label %join.43
no.42:
  %v45 = inttoptr i64 %v39 to ptr
  br label %join.43
join.43:
  %v46 = phi ptr [ %v44, %yes.41 ], [ %v45, %no.42 ]
  br label %join.36
no.35:
  %v47 = call ptr @mlf_add_int(ptr %a1, ptr inttoptr (i64 3 to ptr))
  br label %join.36
join.36:
  %v48 = phi ptr [ %v46, %join.43 ], [ %v47, %no.35 ]
  %v49 = call ptr @mlf.worker.29(ptr %a0, ptr %v48)
  br label %join.28
join.28:
  %v50 = phi ptr [ inttoptr (i64 1 to ptr), %yes.26 ], [ %v49, %join.36 ]
  br label %join.12
join.12:
  %v51 = phi ptr [ %a1, %yes.10 ], [ %v50, %join.28 ]
  ret ptr %v51
}

define private ptr @mlf.code.3(ptr %env, ptr %arg) {
entry:
  %v4 = getelementptr i8, ptr %env, i64 8
  %v5 = load ptr, ptr %v4, align 8, !tbaa !3
  %v6 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v6, align 8, !tbaa !3
  %v52 = call ptr @mlf.force(ptr %v5)
  %v53 = call ptr @mlf.worker.29(ptr %v52, ptr inttoptr (i64 1 to ptr))
  ret ptr %v53
}

define private ptr @mlf.code.58(ptr %env, ptr %arg) {
entry:
  %v59 = getelementptr i8, ptr %env, i64 8
  %v60 = load ptr, ptr %v59, align 8, !tbaa !3
  %v61 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v61, align 8, !tbaa !3
  %v62 = call ptr @mlf.force(ptr %v60)
  %v63 = ptrtoint ptr %v62 to i64
  %v64 = ptrtoint ptr inttoptr (i64 13 to ptr) to i64
  %v65 = and i64 %v63, %v64
  %v66 = and i64 %v65, 1
  %v67 = icmp ne i64 %v66, 0
  br i1 %v67, label %yes.68, label %no.69
yes.68:
  %v71 = icmp slt i64 %v63, %v64
  %v72 = select i1 %v71, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.70
no.69:
  %v73 = call ptr @mlf_lt_int(ptr %v62, ptr inttoptr (i64 13 to ptr))
  br label %join.70
join.70:
  %v74 = phi ptr [ %v72, %yes.68 ], [ %v73, %no.69 ]
  %v75 = icmp eq ptr %v74, inttoptr (i64 6 to ptr)
  br i1 %v75, label %yes.76, label %no.77
yes.76:
  br label %join.78
no.77:
  br label %join.78
join.78:
  %v79 = phi ptr [ inttoptr (i64 13 to ptr), %yes.76 ], [ %v62, %no.77 ]
  ret ptr %v79
}

define private ptr @mlf.code.88(ptr %env, ptr %arg) {
entry:
  %v89 = getelementptr i8, ptr %env, i64 8
  %v90 = load ptr, ptr %v89, align 8, !tbaa !3
  %v91 = getelementptr i8, ptr %env, i64 16
  %v92 = load ptr, ptr %v91, align 8, !tbaa !3
  %v93 = getelementptr i8, ptr %env, i64 24
  %v94 = load ptr, ptr %v93, align 8, !tbaa !3
  %v95 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v95, align 8, !tbaa !3
  %v96 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v96, align 8, !tbaa !3
  %v97 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v97, align 8, !tbaa !3
  %v98 = call ptr @mlf.force(ptr %v90)
  %v100 = call ptr @mlf.force(ptr %v92)
  %v101 = call ptr @mlf_prim1(i64 7, ptr %v100)
  %v103 = call ptr @mlf.force(ptr %v94)
  %v104 = call ptr @mlf_prim1(i64 7, ptr %v103)
  %v105 = call ptr @mlf_prim2(i64 6, ptr @mlf.bytes.102.value, ptr %v104)
  %v106 = call ptr @mlf_prim2(i64 6, ptr %v101, ptr %v105)
  %v107 = call ptr @mlf_prim2(i64 6, ptr @mlf.bytes.99.value, ptr %v106)
  %v108 = call ptr @mlf_prim2(i64 6, ptr %v98, ptr %v107)
  ret ptr %v108
}

define private ptr @mlf.worker.11(ptr %a0, ptr %a1, ptr %a2) {
entry:
  %v109 = call ptr @mlf.allocate.thunk(ptr @mlf.code.88, i64 3)
  %v110 = getelementptr i8, ptr %v109, i64 16
  %v111 = load ptr, ptr %v110, align 8, !tbaa !3
  %v112 = getelementptr i8, ptr %v111, i64 8
  store ptr %a0, ptr %v112, align 8, !tbaa !3
  %v113 = getelementptr i8, ptr %v111, i64 16
  store ptr %a1, ptr %v113, align 8, !tbaa !3
  %v114 = getelementptr i8, ptr %v111, i64 24
  store ptr %a2, ptr %v114, align 8, !tbaa !3
  %v115 = call ptr @mlf_prim1(i64 3, ptr %v109)
  ret ptr %v115
}

define private ptr @mlf.code.117(ptr %env, ptr %arg) {
entry:
  %v118 = getelementptr i8, ptr %env, i64 8
  %v119 = load ptr, ptr %v118, align 8, !tbaa !3
  %v120 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v120, align 8, !tbaa !3
  %v121 = call ptr @mlf.force(ptr %v119)
  %v122 = ptrtoint ptr %v121 to i64
  %v123 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v124 = and i64 %v122, %v123
  %v125 = and i64 %v124, 1
  %v126 = icmp ne i64 %v125, 0
  br i1 %v126, label %yes.127, label %no.128
yes.127:
  %v130 = sub i64 %v123, 1
  %v131 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v122, i64 %v130)
  %v132 = extractvalue { i64, i1 } %v131, 0
  %v133 = extractvalue { i64, i1 } %v131, 1
  br i1 %v133, label %yes.134, label %no.135
yes.134:
  %v137 = call ptr @mlf_add_int(ptr %v121, ptr inttoptr (i64 3 to ptr))
  br label %join.136
no.135:
  %v138 = inttoptr i64 %v132 to ptr
  br label %join.136
join.136:
  %v139 = phi ptr [ %v137, %yes.134 ], [ %v138, %no.135 ]
  br label %join.129
no.128:
  %v140 = call ptr @mlf_add_int(ptr %v121, ptr inttoptr (i64 3 to ptr))
  br label %join.129
join.129:
  %v141 = phi ptr [ %v139, %join.136 ], [ %v140, %no.128 ]
  ret ptr %v141
}

define private ptr @mlf.worker.7(ptr %a0) {
entry:
  %v150 = ptrtoint ptr %a0 to i64
  %v151 = and i64 %v150, 7
  %v152 = icmp eq i64 %v151, 4
  br i1 %v152, label %yes.153, label %no.154
yes.153:
  %v156 = lshr i64 %v150, 3
  br label %join.155
no.154:
  %v157 = getelementptr i8, ptr %a0, i64 8
  %v158 = load i64, ptr %v157, align 8, !tbaa !3
  br label %join.155
join.155:
  %v159 = phi i64 [ %v156, %yes.153 ], [ %v158, %no.154 ]
  switch i64 %v159, label %case.missing.162 [
    i64 1, label %case.160
    i64 2, label %case.161
  ]
case.160:
  br label %case.join.163
case.161:
  %v164 = getelementptr i8, ptr %a0, i64 16
  %v165 = load ptr, ptr %v164, align 8, !tbaa !3
  %v166 = getelementptr i8, ptr %a0, i64 24
  %v167 = load ptr, ptr %v166, align 8, !tbaa !3
  %v168 = call ptr @mlf.worker.7(ptr %v165)
  %v169 = call ptr @mlf.worker.7(ptr %v167)
  %v170 = ptrtoint ptr %v168 to i64
  %v171 = ptrtoint ptr %v169 to i64
  %v172 = and i64 %v170, %v171
  %v173 = and i64 %v172, 1
  %v174 = icmp ne i64 %v173, 0
  br i1 %v174, label %yes.175, label %no.176
yes.175:
  %v178 = sub i64 %v171, 1
  %v179 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v170, i64 %v178)
  %v180 = extractvalue { i64, i1 } %v179, 0
  %v181 = extractvalue { i64, i1 } %v179, 1
  br i1 %v181, label %yes.182, label %no.183
yes.182:
  %v185 = call ptr @mlf_add_int(ptr %v168, ptr %v169)
  br label %join.184
no.183:
  %v186 = inttoptr i64 %v180 to ptr
  br label %join.184
join.184:
  %v187 = phi ptr [ %v185, %yes.182 ], [ %v186, %no.183 ]
  br label %join.177
no.176:
  %v188 = call ptr @mlf_add_int(ptr %v168, ptr %v169)
  br label %join.177
join.177:
  %v189 = phi ptr [ %v187, %join.184 ], [ %v188, %no.176 ]
  %v190 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v191 = ptrtoint ptr %v189 to i64
  %v192 = and i64 %v190, %v191
  %v193 = and i64 %v192, 1
  %v194 = icmp ne i64 %v193, 0
  br i1 %v194, label %yes.195, label %no.196
yes.195:
  %v198 = sub i64 %v191, 1
  %v199 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v190, i64 %v198)
  %v200 = extractvalue { i64, i1 } %v199, 0
  %v201 = extractvalue { i64, i1 } %v199, 1
  br i1 %v201, label %yes.202, label %no.203
yes.202:
  %v205 = call ptr @mlf_add_int(ptr inttoptr (i64 3 to ptr), ptr %v189)
  br label %join.204
no.203:
  %v206 = inttoptr i64 %v200 to ptr
  br label %join.204
join.204:
  %v207 = phi ptr [ %v205, %yes.202 ], [ %v206, %no.203 ]
  br label %join.197
no.196:
  %v208 = call ptr @mlf_add_int(ptr inttoptr (i64 3 to ptr), ptr %v189)
  br label %join.197
join.197:
  %v209 = phi ptr [ %v207, %join.204 ], [ %v208, %no.196 ]
  br label %case.join.163
case.missing.162:
  call void @mlf_match_failure()
  unreachable
case.join.163:
  %v210 = phi ptr [ inttoptr (i64 1 to ptr), %case.160 ], [ %v209, %join.197 ]
  ret ptr %v210
}

define private ptr @mlf.worker.3(ptr %a0) {
entry:
  %v211 = ptrtoint ptr %a0 to i64
  %v212 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v213 = and i64 %v211, %v212
  %v214 = and i64 %v213, 1
  %v215 = icmp ne i64 %v214, 0
  br i1 %v215, label %yes.216, label %no.217
yes.216:
  %v219 = icmp eq i64 %v211, %v212
  %v220 = select i1 %v219, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.218
no.217:
  %v221 = call ptr @mlf_eq_int(ptr %a0, ptr inttoptr (i64 1 to ptr))
  br label %join.218
join.218:
  %v222 = phi ptr [ %v220, %yes.216 ], [ %v221, %no.217 ]
  %v223 = icmp eq ptr %v222, inttoptr (i64 6 to ptr)
  br i1 %v223, label %yes.224, label %no.225
yes.224:
  %v227 = call ptr @mlf.construct.2(i64 2, ptr inttoptr (i64 12 to ptr), ptr inttoptr (i64 12 to ptr))
  br label %join.226
no.225:
  %v228 = ptrtoint ptr %a0 to i64
  %v229 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v230 = and i64 %v228, %v229
  %v231 = and i64 %v230, 1
  %v232 = icmp ne i64 %v231, 0
  br i1 %v232, label %yes.233, label %no.234
yes.233:
  %v236 = sub i64 %v229, 1
  %v237 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v228, i64 %v236)
  %v238 = extractvalue { i64, i1 } %v237, 0
  %v239 = extractvalue { i64, i1 } %v237, 1
  br i1 %v239, label %yes.240, label %no.241
yes.240:
  %v243 = call ptr @mlf_sub_int(ptr %a0, ptr inttoptr (i64 3 to ptr))
  br label %join.242
no.241:
  %v244 = inttoptr i64 %v238 to ptr
  br label %join.242
join.242:
  %v245 = phi ptr [ %v243, %yes.240 ], [ %v244, %no.241 ]
  br label %join.235
no.234:
  %v246 = call ptr @mlf_sub_int(ptr %a0, ptr inttoptr (i64 3 to ptr))
  br label %join.235
join.235:
  %v247 = phi ptr [ %v245, %join.242 ], [ %v246, %no.234 ]
  %v248 = call ptr @mlf.worker.3(ptr %v247)
  %v249 = ptrtoint ptr %v248 to i64
  %v250 = and i64 %v249, 7
  %v251 = icmp eq i64 %v250, 4
  br i1 %v251, label %yes.252, label %no.253
yes.252:
  %v255 = lshr i64 %v249, 3
  br label %join.254
no.253:
  %v256 = getelementptr i8, ptr %v248, i64 8
  %v257 = load i64, ptr %v256, align 8, !tbaa !3
  br label %join.254
join.254:
  %v258 = phi i64 [ %v255, %yes.252 ], [ %v257, %no.253 ]
  switch i64 %v258, label %case.missing.261 [
    i64 1, label %case.259
    i64 2, label %case.260
  ]
case.259:
  br label %case.join.262
case.260:
  %v263 = ptrtoint ptr %a0 to i64
  %v264 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v265 = and i64 %v263, %v264
  %v266 = and i64 %v265, 1
  %v267 = icmp ne i64 %v266, 0
  br i1 %v267, label %yes.268, label %no.269
yes.268:
  %v271 = sub i64 %v264, 1
  %v272 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v263, i64 %v271)
  %v273 = extractvalue { i64, i1 } %v272, 0
  %v274 = extractvalue { i64, i1 } %v272, 1
  br i1 %v274, label %yes.275, label %no.276
yes.275:
  %v278 = call ptr @mlf_sub_int(ptr %a0, ptr inttoptr (i64 3 to ptr))
  br label %join.277
no.276:
  %v279 = inttoptr i64 %v273 to ptr
  br label %join.277
join.277:
  %v280 = phi ptr [ %v278, %yes.275 ], [ %v279, %no.276 ]
  br label %join.270
no.269:
  %v281 = call ptr @mlf_sub_int(ptr %a0, ptr inttoptr (i64 3 to ptr))
  br label %join.270
join.270:
  %v282 = phi ptr [ %v280, %join.277 ], [ %v281, %no.269 ]
  %v283 = call ptr @mlf.worker.3(ptr %v282)
  %v284 = ptrtoint ptr %v283 to i64
  %v285 = and i64 %v284, 7
  %v286 = icmp eq i64 %v285, 4
  br i1 %v286, label %yes.287, label %no.288
yes.287:
  %v290 = lshr i64 %v284, 3
  br label %join.289
no.288:
  %v291 = getelementptr i8, ptr %v283, i64 8
  %v292 = load i64, ptr %v291, align 8, !tbaa !3
  br label %join.289
join.289:
  %v293 = phi i64 [ %v290, %yes.287 ], [ %v292, %no.288 ]
  switch i64 %v293, label %case.missing.296 [
    i64 1, label %case.294
    i64 2, label %case.295
  ]
case.294:
  br label %case.join.297
case.295:
  %v298 = call ptr @mlf.construct.2(i64 2, ptr %v248, ptr %v283)
  br label %case.join.297
case.missing.296:
  call void @mlf_match_failure()
  unreachable
case.join.297:
  %v299 = phi ptr [ inttoptr (i64 12 to ptr), %case.294 ], [ %v298, %case.295 ]
  br label %case.join.262
case.missing.261:
  call void @mlf_match_failure()
  unreachable
case.join.262:
  %v300 = phi ptr [ inttoptr (i64 12 to ptr), %case.259 ], [ %v299, %case.join.297 ]
  br label %join.226
join.226:
  %v301 = phi ptr [ %v227, %yes.224 ], [ %v300, %case.join.262 ]
  ret ptr %v301
}

define private ptr @mlf.code.146(ptr %env, ptr %arg) {
entry:
  %v147 = getelementptr i8, ptr %env, i64 8
  %v148 = load ptr, ptr %v147, align 8, !tbaa !3
  %v149 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v149, align 8, !tbaa !3
  %v302 = call ptr @mlf.force(ptr %v148)
  %v303 = ptrtoint ptr %v302 to i64
  %v304 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v305 = and i64 %v303, %v304
  %v306 = and i64 %v305, 1
  %v307 = icmp ne i64 %v306, 0
  br i1 %v307, label %yes.308, label %no.309
yes.308:
  %v311 = sub i64 %v304, 1
  %v312 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v303, i64 %v311)
  %v313 = extractvalue { i64, i1 } %v312, 0
  %v314 = extractvalue { i64, i1 } %v312, 1
  br i1 %v314, label %yes.315, label %no.316
yes.315:
  %v318 = call ptr @mlf_add_int(ptr %v302, ptr inttoptr (i64 3 to ptr))
  br label %join.317
no.316:
  %v319 = inttoptr i64 %v313 to ptr
  br label %join.317
join.317:
  %v320 = phi ptr [ %v318, %yes.315 ], [ %v319, %no.316 ]
  br label %join.310
no.309:
  %v321 = call ptr @mlf_add_int(ptr %v302, ptr inttoptr (i64 3 to ptr))
  br label %join.310
join.310:
  %v322 = phi ptr [ %v320, %join.317 ], [ %v321, %no.309 ]
  %v323 = call ptr @mlf.worker.3(ptr %v322)
  %v324 = call ptr @mlf.worker.7(ptr %v323)
  ret ptr %v324
}

define private ptr @mlf.code.84(ptr %env, ptr %arg) {
entry:
  %v85 = getelementptr i8, ptr %env, i64 8
  %v86 = load ptr, ptr %v85, align 8, !tbaa !3
  %v87 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v87, align 8, !tbaa !3
  %v142 = call ptr @mlf.allocate.thunk(ptr @mlf.code.117, i64 1)
  %v143 = getelementptr i8, ptr %v142, i64 16
  %v144 = load ptr, ptr %v143, align 8, !tbaa !3
  %v145 = getelementptr i8, ptr %v144, i64 8
  store ptr %v86, ptr %v145, align 8, !tbaa !3
  %v325 = call ptr @mlf.allocate.thunk(ptr @mlf.code.146, i64 1)
  %v326 = getelementptr i8, ptr %v325, i64 16
  %v327 = load ptr, ptr %v326, align 8, !tbaa !3
  %v328 = getelementptr i8, ptr %v327, i64 8
  store ptr %v86, ptr %v328, align 8, !tbaa !3
  %v329 = call ptr @mlf.worker.11(ptr @mlf.bytes.116.value, ptr %v142, ptr %v325)
  ret ptr %v329
}

define private ptr @mlf.worker.0(ptr %a0) {
entry:
  %v383 = ptrtoint ptr %a0 to i64
  %v384 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v385 = and i64 %v383, %v384
  %v386 = and i64 %v385, 1
  %v387 = icmp ne i64 %v386, 0
  br i1 %v387, label %yes.388, label %no.389
yes.388:
  %v391 = icmp eq i64 %v383, %v384
  %v392 = select i1 %v391, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.390
no.389:
  %v393 = call ptr @mlf_eq_int(ptr %a0, ptr inttoptr (i64 1 to ptr))
  br label %join.390
join.390:
  %v394 = phi ptr [ %v392, %yes.388 ], [ %v393, %no.389 ]
  %v395 = icmp eq ptr %v394, inttoptr (i64 6 to ptr)
  br i1 %v395, label %yes.396, label %no.397
yes.396:
  br label %join.398
no.397:
  %v399 = ptrtoint ptr %a0 to i64
  %v400 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v401 = and i64 %v399, %v400
  %v402 = and i64 %v401, 1
  %v403 = icmp ne i64 %v402, 0
  br i1 %v403, label %yes.404, label %no.405
yes.404:
  %v407 = sub i64 %v400, 1
  %v408 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v399, i64 %v407)
  %v409 = extractvalue { i64, i1 } %v408, 0
  %v410 = extractvalue { i64, i1 } %v408, 1
  br i1 %v410, label %yes.411, label %no.412
yes.411:
  %v414 = call ptr @mlf_sub_int(ptr %a0, ptr inttoptr (i64 3 to ptr))
  br label %join.413
no.412:
  %v415 = inttoptr i64 %v409 to ptr
  br label %join.413
join.413:
  %v416 = phi ptr [ %v414, %yes.411 ], [ %v415, %no.412 ]
  br label %join.406
no.405:
  %v417 = call ptr @mlf_sub_int(ptr %a0, ptr inttoptr (i64 3 to ptr))
  br label %join.406
join.406:
  %v418 = phi ptr [ %v416, %join.413 ], [ %v417, %no.405 ]
  %v419 = call ptr @mlf.worker.0(ptr %v418)
  %v420 = ptrtoint ptr %v419 to i64
  %v421 = ptrtoint ptr %v419 to i64
  %v422 = and i64 %v420, %v421
  %v423 = and i64 %v422, 1
  %v424 = icmp ne i64 %v423, 0
  br i1 %v424, label %yes.425, label %no.426
yes.425:
  %v428 = sub i64 %v421, 1
  %v429 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v420, i64 %v428)
  %v430 = extractvalue { i64, i1 } %v429, 0
  %v431 = extractvalue { i64, i1 } %v429, 1
  br i1 %v431, label %yes.432, label %no.433
yes.432:
  %v435 = call ptr @mlf_add_int(ptr %v419, ptr %v419)
  br label %join.434
no.433:
  %v436 = inttoptr i64 %v430 to ptr
  br label %join.434
join.434:
  %v437 = phi ptr [ %v435, %yes.432 ], [ %v436, %no.433 ]
  br label %join.427
no.426:
  %v438 = call ptr @mlf_add_int(ptr %v419, ptr %v419)
  br label %join.427
join.427:
  %v439 = phi ptr [ %v437, %join.434 ], [ %v438, %no.426 ]
  br label %join.398
join.398:
  %v440 = phi ptr [ inttoptr (i64 3 to ptr), %yes.396 ], [ %v439, %join.427 ]
  ret ptr %v440
}

define private ptr @mlf.code.376(ptr %env, ptr %arg) {
entry:
  %v377 = getelementptr i8, ptr %env, i64 8
  %v378 = load ptr, ptr %v377, align 8, !tbaa !3
  %v379 = getelementptr i8, ptr %env, i64 16
  %v380 = load ptr, ptr %v379, align 8, !tbaa !3
  %v381 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v381, align 8, !tbaa !3
  %v382 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v382, align 8, !tbaa !3
  %v441 = call ptr @mlf.force(ptr %v378)
  %v442 = call ptr @mlf.force(ptr %v380)
  %v443 = ptrtoint ptr %v441 to i64
  %v444 = ptrtoint ptr %v442 to i64
  %v445 = and i64 %v443, %v444
  %v446 = and i64 %v445, 1
  %v447 = icmp ne i64 %v446, 0
  br i1 %v447, label %yes.448, label %no.449
yes.448:
  %v451 = sub i64 %v444, 1
  %v452 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v443, i64 %v451)
  %v453 = extractvalue { i64, i1 } %v452, 0
  %v454 = extractvalue { i64, i1 } %v452, 1
  br i1 %v454, label %yes.455, label %no.456
yes.455:
  %v458 = call ptr @mlf_sub_int(ptr %v441, ptr %v442)
  br label %join.457
no.456:
  %v459 = inttoptr i64 %v453 to ptr
  br label %join.457
join.457:
  %v460 = phi ptr [ %v458, %yes.455 ], [ %v459, %no.456 ]
  br label %join.450
no.449:
  %v461 = call ptr @mlf_sub_int(ptr %v441, ptr %v442)
  br label %join.450
join.450:
  %v462 = phi ptr [ %v460, %join.457 ], [ %v461, %no.449 ]
  %v463 = ptrtoint ptr %v462 to i64
  %v464 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v465 = and i64 %v463, %v464
  %v466 = and i64 %v465, 1
  %v467 = icmp ne i64 %v466, 0
  br i1 %v467, label %yes.468, label %no.469
yes.468:
  %v471 = sub i64 %v464, 1
  %v472 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v463, i64 %v471)
  %v473 = extractvalue { i64, i1 } %v472, 0
  %v474 = extractvalue { i64, i1 } %v472, 1
  br i1 %v474, label %yes.475, label %no.476
yes.475:
  %v478 = call ptr @mlf_add_int(ptr %v462, ptr inttoptr (i64 9 to ptr))
  br label %join.477
no.476:
  %v479 = inttoptr i64 %v473 to ptr
  br label %join.477
join.477:
  %v480 = phi ptr [ %v478, %yes.475 ], [ %v479, %no.476 ]
  br label %join.470
no.469:
  %v481 = call ptr @mlf_add_int(ptr %v462, ptr inttoptr (i64 9 to ptr))
  br label %join.470
join.470:
  %v482 = phi ptr [ %v480, %join.477 ], [ %v481, %no.469 ]
  %v483 = call ptr @mlf.worker.0(ptr %v482)
  ret ptr %v483
}

define private ptr @mlf.code.553(ptr %env, ptr %arg) {
entry:
  %v554 = getelementptr i8, ptr %env, i64 8
  %v555 = load ptr, ptr %v554, align 8, !tbaa !3
  %v556 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v556, align 8, !tbaa !3
  %v557 = call ptr @mlf_prim1(i64 0, ptr %v555)
  ret ptr %v557
}

define private ptr @mlf.code.562(ptr %env, ptr %arg) {
entry:
  %v563 = getelementptr i8, ptr %env, i64 8
  %v564 = load ptr, ptr %v563, align 8, !tbaa !3
  %v565 = getelementptr i8, ptr %env, i64 16
  %v566 = load ptr, ptr %v565, align 8, !tbaa !3
  %v567 = call ptr @mlf.force(ptr %v566)
  %v568 = ptrtoint ptr %v567 to i64
  %v569 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v570 = and i64 %v568, %v569
  %v571 = and i64 %v570, 1
  %v572 = icmp ne i64 %v571, 0
  br i1 %v572, label %yes.573, label %no.574
yes.573:
  %v576 = sub i64 %v569, 1
  %v577 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v568, i64 %v576)
  %v578 = extractvalue { i64, i1 } %v577, 0
  %v579 = extractvalue { i64, i1 } %v577, 1
  br i1 %v579, label %yes.580, label %no.581
yes.580:
  %v583 = call ptr @mlf_sub_int(ptr %v567, ptr inttoptr (i64 3 to ptr))
  br label %join.582
no.581:
  %v584 = inttoptr i64 %v578 to ptr
  br label %join.582
join.582:
  %v585 = phi ptr [ %v583, %yes.580 ], [ %v584, %no.581 ]
  br label %join.575
no.574:
  %v586 = call ptr @mlf_sub_int(ptr %v567, ptr inttoptr (i64 3 to ptr))
  br label %join.575
join.575:
  %v587 = phi ptr [ %v585, %join.582 ], [ %v586, %no.574 ]
  %v588 = call ptr @mlf.worker.15(ptr %v564, ptr %v587, ptr %arg)
  ret ptr %v588
}

define private ptr @mlf.worker.15(ptr %a0, ptr %a1, ptr %a2) {
entry:
  %v496 = ptrtoint ptr %a1 to i64
  %v497 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v498 = and i64 %v496, %v497
  %v499 = and i64 %v498, 1
  %v500 = icmp ne i64 %v499, 0
  br i1 %v500, label %yes.501, label %no.502
yes.501:
  %v504 = icmp eq i64 %v496, %v497
  %v505 = select i1 %v504, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.503
no.502:
  %v506 = call ptr @mlf_eq_int(ptr %a1, ptr inttoptr (i64 1 to ptr))
  br label %join.503
join.503:
  %v507 = phi ptr [ %v505, %yes.501 ], [ %v506, %no.502 ]
  %v508 = icmp eq ptr %v507, inttoptr (i64 6 to ptr)
  br i1 %v508, label %yes.509, label %no.510
yes.509:
  %v512 = call ptr @mlf_prim1(i64 0, ptr %a2)
  br label %join.511
no.510:
  %v513 = call ptr @mlf.force(ptr %a2)
  %v514 = call ptr @mlf.force(ptr %a0)
  %v515 = call ptr @mlf.worker.3(ptr %v514)
  %v516 = call ptr @mlf.worker.7(ptr %v515)
  %v517 = ptrtoint ptr %v513 to i64
  %v518 = ptrtoint ptr %v516 to i64
  %v519 = and i64 %v517, %v518
  %v520 = and i64 %v519, 1
  %v521 = icmp ne i64 %v520, 0
  br i1 %v521, label %yes.522, label %no.523
yes.522:
  %v525 = sub i64 %v518, 1
  %v526 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v517, i64 %v525)
  %v527 = extractvalue { i64, i1 } %v526, 0
  %v528 = extractvalue { i64, i1 } %v526, 1
  br i1 %v528, label %yes.529, label %no.530
yes.529:
  %v532 = call ptr @mlf_add_int(ptr %v513, ptr %v516)
  br label %join.531
no.530:
  %v533 = inttoptr i64 %v527 to ptr
  br label %join.531
join.531:
  %v534 = phi ptr [ %v532, %yes.529 ], [ %v533, %no.530 ]
  br label %join.524
no.523:
  %v535 = call ptr @mlf_add_int(ptr %v513, ptr %v516)
  br label %join.524
join.524:
  %v536 = phi ptr [ %v534, %join.531 ], [ %v535, %no.523 ]
  %v537 = ptrtoint ptr %v536 to i64
  %v538 = ptrtoint ptr %v536 to i64
  %v539 = and i64 %v537, %v538
  %v540 = and i64 %v539, 1
  %v541 = icmp ne i64 %v540, 0
  br i1 %v541, label %yes.542, label %no.543
yes.542:
  %v545 = icmp eq i64 %v537, %v538
  %v546 = select i1 %v545, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.544
no.543:
  %v547 = call ptr @mlf_eq_int(ptr %v536, ptr %v536)
  br label %join.544
join.544:
  %v548 = phi ptr [ %v546, %yes.542 ], [ %v547, %no.543 ]
  %v549 = icmp eq ptr %v548, inttoptr (i64 6 to ptr)
  br i1 %v549, label %yes.550, label %no.551
yes.550:
  %v558 = call ptr @mlf.allocate.thunk(ptr @mlf.code.553, i64 1)
  %v559 = getelementptr i8, ptr %v558, i64 16
  %v560 = load ptr, ptr %v559, align 8, !tbaa !3
  %v561 = getelementptr i8, ptr %v560, i64 8
  store ptr %v536, ptr %v561, align 8, !tbaa !3
  %v589 = call ptr @mlf_env_new(i64 2)
  %v590 = getelementptr i8, ptr %v589, i64 8
  store ptr %v514, ptr %v590, align 8, !tbaa !3
  %v591 = getelementptr i8, ptr %v589, i64 16
  store ptr %a1, ptr %v591, align 8, !tbaa !3
  %v592 = call ptr @mlf_closure(ptr @mlf.code.562, ptr %v589)
  %v593 = call ptr @mlf_prim2(i64 1, ptr %v558, ptr %v592)
  br label %join.552
no.551:
  %v594 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 1 to ptr))
  br label %join.552
join.552:
  %v595 = phi ptr [ %v593, %yes.550 ], [ %v594, %no.551 ]
  br label %join.511
join.511:
  %v596 = phi ptr [ %v512, %yes.509 ], [ %v595, %join.552 ]
  ret ptr %v596
}

define private ptr @mlf.code.489(ptr %env, ptr %arg) {
entry:
  %v490 = getelementptr i8, ptr %env, i64 8
  %v491 = load ptr, ptr %v490, align 8, !tbaa !3
  %v492 = getelementptr i8, ptr %env, i64 16
  %v493 = load ptr, ptr %v492, align 8, !tbaa !3
  %v494 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v494, align 8, !tbaa !3
  %v495 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v495, align 8, !tbaa !3
  %v597 = call ptr @mlf.force(ptr %v493)
  %v598 = call ptr @mlf.worker.15(ptr %v491, ptr %v597, ptr inttoptr (i64 1 to ptr))
  ret ptr %v598
}

define private ptr @mlf.code.621(ptr %env, ptr %arg) {
entry:
  %v622 = getelementptr i8, ptr %env, i64 8
  %v623 = load ptr, ptr %v622, align 8, !tbaa !3
  %v624 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v624, align 8, !tbaa !3
  %v625 = call ptr @mlf.force(ptr %v623)
  %v626 = call ptr @mlf_prim1(i64 7, ptr %v625)
  %v628 = call ptr @mlf_prim2(i64 6, ptr %v626, ptr @mlf.bytes.627.value)
  ret ptr %v628
}

define private ptr @mlf.code.611(ptr %env, ptr %arg) {
entry:
  %v612 = getelementptr i8, ptr %env, i64 8
  %v613 = load ptr, ptr %v612, align 8, !tbaa !3
  %v614 = getelementptr i8, ptr %env, i64 16
  %v615 = load ptr, ptr %v614, align 8, !tbaa !3
  %v616 = getelementptr i8, ptr %env, i64 24
  %v617 = load ptr, ptr %v616, align 8, !tbaa !3
  %v618 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v618, align 8, !tbaa !3
  %v619 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v619, align 8, !tbaa !3
  %v620 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v620, align 8, !tbaa !3
  %v629 = call ptr @mlf.allocate.thunk(ptr @mlf.code.621, i64 1)
  %v630 = getelementptr i8, ptr %v629, i64 16
  %v631 = load ptr, ptr %v630, align 8, !tbaa !3
  %v632 = getelementptr i8, ptr %v631, i64 8
  store ptr %v615, ptr %v632, align 8, !tbaa !3
  %v633 = call ptr @mlf.worker.11(ptr %v629, ptr %v613, ptr %v617)
  ret ptr %v633
}

define private ptr @mlf.code.640(ptr %env, ptr %arg) {
entry:
  %v641 = getelementptr i8, ptr %env, i64 8
  %v642 = load ptr, ptr %v641, align 8, !tbaa !3
  %v643 = getelementptr i8, ptr %env, i64 16
  %v644 = load ptr, ptr %v643, align 8, !tbaa !3
  %v645 = call ptr @mlf.force(ptr %v642)
  %v646 = call ptr @mlf.force(ptr %v644)
  %v647 = ptrtoint ptr %v646 to i64
  %v648 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v649 = and i64 %v647, %v648
  %v650 = and i64 %v649, 1
  %v651 = icmp ne i64 %v650, 0
  br i1 %v651, label %yes.652, label %no.653
yes.652:
  %v655 = sub i64 %v648, 1
  %v656 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v647, i64 %v655)
  %v657 = extractvalue { i64, i1 } %v656, 0
  %v658 = extractvalue { i64, i1 } %v656, 1
  br i1 %v658, label %yes.659, label %no.660
yes.659:
  %v662 = call ptr @mlf_add_int(ptr %v646, ptr inttoptr (i64 5 to ptr))
  br label %join.661
no.660:
  %v663 = inttoptr i64 %v657 to ptr
  br label %join.661
join.661:
  %v664 = phi ptr [ %v662, %yes.659 ], [ %v663, %no.660 ]
  br label %join.654
no.653:
  %v665 = call ptr @mlf_add_int(ptr %v646, ptr inttoptr (i64 5 to ptr))
  br label %join.654
join.654:
  %v666 = phi ptr [ %v664, %join.661 ], [ %v665, %no.653 ]
  %v667 = call ptr @mlf.worker.21(ptr %v645, ptr %v666)
  ret ptr %v667
}

define private ptr @mlf.code.604(ptr %env, ptr %arg) {
entry:
  %v605 = getelementptr i8, ptr %env, i64 8
  %v606 = load ptr, ptr %v605, align 8, !tbaa !3
  %v607 = getelementptr i8, ptr %env, i64 16
  %v608 = load ptr, ptr %v607, align 8, !tbaa !3
  %v609 = getelementptr i8, ptr %env, i64 24
  %v610 = load ptr, ptr %v609, align 8, !tbaa !3
  %v634 = call ptr @mlf.allocate.thunk(ptr @mlf.code.611, i64 3)
  %v635 = getelementptr i8, ptr %v634, i64 16
  %v636 = load ptr, ptr %v635, align 8, !tbaa !3
  %v637 = getelementptr i8, ptr %v636, i64 8
  store ptr %v608, ptr %v637, align 8, !tbaa !3
  %v638 = getelementptr i8, ptr %v636, i64 16
  store ptr %v610, ptr %v638, align 8, !tbaa !3
  %v639 = getelementptr i8, ptr %v636, i64 24
  store ptr %arg, ptr %v639, align 8, !tbaa !3
  %v668 = call ptr @mlf_env_new(i64 2)
  %v669 = getelementptr i8, ptr %v668, i64 8
  store ptr %v606, ptr %v669, align 8, !tbaa !3
  %v670 = getelementptr i8, ptr %v668, i64 16
  store ptr %v608, ptr %v670, align 8, !tbaa !3
  %v671 = call ptr @mlf_closure(ptr @mlf.code.640, ptr %v668)
  %v672 = call ptr @mlf_prim2(i64 1, ptr %v634, ptr %v671)
  ret ptr %v672
}

define private ptr @mlf.worker.21(ptr %a0, ptr %a1) {
entry:
  %v359 = ptrtoint ptr %a0 to i64
  %v360 = ptrtoint ptr %a1 to i64
  %v361 = and i64 %v359, %v360
  %v362 = and i64 %v361, 1
  %v363 = icmp ne i64 %v362, 0
  br i1 %v363, label %yes.364, label %no.365
yes.364:
  %v367 = icmp slt i64 %v359, %v360
  %v368 = select i1 %v367, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.366
no.365:
  %v369 = call ptr @mlf_lt_int(ptr %a0, ptr %a1)
  br label %join.366
join.366:
  %v370 = phi ptr [ %v368, %yes.364 ], [ %v369, %no.365 ]
  %v371 = icmp eq ptr %v370, inttoptr (i64 6 to ptr)
  br i1 %v371, label %yes.372, label %no.373
yes.372:
  %v375 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.374
no.373:
  %v484 = call ptr @mlf.allocate.thunk(ptr @mlf.code.376, i64 2)
  %v485 = getelementptr i8, ptr %v484, i64 16
  %v486 = load ptr, ptr %v485, align 8, !tbaa !3
  %v487 = getelementptr i8, ptr %v486, i64 8
  store ptr %a0, ptr %v487, align 8, !tbaa !3
  %v488 = getelementptr i8, ptr %v486, i64 16
  store ptr %a1, ptr %v488, align 8, !tbaa !3
  %v599 = call ptr @mlf.allocate.thunk(ptr @mlf.code.489, i64 2)
  %v600 = getelementptr i8, ptr %v599, i64 16
  %v601 = load ptr, ptr %v600, align 8, !tbaa !3
  %v602 = getelementptr i8, ptr %v601, i64 8
  store ptr %a1, ptr %v602, align 8, !tbaa !3
  %v603 = getelementptr i8, ptr %v601, i64 16
  store ptr %v484, ptr %v603, align 8, !tbaa !3
  %v673 = call ptr @mlf_env_new(i64 3)
  %v674 = getelementptr i8, ptr %v673, i64 8
  store ptr %a0, ptr %v674, align 8, !tbaa !3
  %v675 = getelementptr i8, ptr %v673, i64 16
  store ptr %a1, ptr %v675, align 8, !tbaa !3
  %v676 = getelementptr i8, ptr %v673, i64 24
  store ptr %v484, ptr %v676, align 8, !tbaa !3
  %v677 = call ptr @mlf_closure(ptr @mlf.code.604, ptr %v673)
  %v678 = call ptr @mlf_prim2(i64 1, ptr %v599, ptr %v677)
  br label %join.374
join.374:
  %v679 = phi ptr [ %v375, %yes.372 ], [ %v678, %no.373 ]
  ret ptr %v679
}

define private ptr @mlf.code.355(ptr %env, ptr %arg) {
entry:
  %v356 = getelementptr i8, ptr %env, i64 8
  %v357 = load ptr, ptr %v356, align 8, !tbaa !3
  %v358 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v358, align 8, !tbaa !3
  %v680 = call ptr @mlf.force(ptr %v357)
  %v681 = call ptr @mlf.worker.21(ptr %v680, ptr inttoptr (i64 9 to ptr))
  ret ptr %v681
}

define private ptr @mlf.code.692(ptr %env, ptr %arg) {
entry:
  %v693 = getelementptr i8, ptr %env, i64 8
  %v694 = load ptr, ptr %v693, align 8, !tbaa !3
  %v695 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v695, align 8, !tbaa !3
  %v696 = call ptr @mlf.force(ptr %v694)
  %v697 = call ptr @mlf.worker.7(ptr %v696)
  ret ptr %v697
}

define private ptr @mlf.code.686(ptr %env, ptr %arg) {
entry:
  %v687 = getelementptr i8, ptr %env, i64 8
  %v688 = load ptr, ptr %v687, align 8, !tbaa !3
  %v689 = getelementptr i8, ptr %env, i64 16
  %v690 = load ptr, ptr %v689, align 8, !tbaa !3
  %v698 = call ptr @mlf.allocate.thunk(ptr @mlf.code.692, i64 1)
  %v699 = getelementptr i8, ptr %v698, i64 16
  %v700 = load ptr, ptr %v699, align 8, !tbaa !3
  %v701 = getelementptr i8, ptr %v700, i64 8
  store ptr %v690, ptr %v701, align 8, !tbaa !3
  %v702 = call ptr @mlf.worker.11(ptr @mlf.bytes.691.value, ptr %v688, ptr %v698)
  ret ptr %v702
}

define private ptr @mlf.code.334(ptr %env, ptr %arg) {
entry:
  %v335 = getelementptr i8, ptr %env, i64 8
  %v336 = load ptr, ptr %v335, align 8, !tbaa !3
  %v337 = call ptr @mlf.force(ptr %v336)
  %v338 = call ptr @mlf.worker.3(ptr %v337)
  %v339 = ptrtoint ptr %v338 to i64
  %v340 = and i64 %v339, 7
  %v341 = icmp eq i64 %v340, 4
  br i1 %v341, label %yes.342, label %no.343
yes.342:
  %v345 = lshr i64 %v339, 3
  br label %join.344
no.343:
  %v346 = getelementptr i8, ptr %v338, i64 8
  %v347 = load i64, ptr %v346, align 8, !tbaa !3
  br label %join.344
join.344:
  %v348 = phi i64 [ %v345, %yes.342 ], [ %v347, %no.343 ]
  switch i64 %v348, label %case.missing.351 [
    i64 1, label %case.349
    i64 2, label %case.350
  ]
case.349:
  %v354 = call ptr @mlf_prim1(i64 3, ptr @mlf.bytes.353.value)
  br label %case.join.352
case.350:
  %v682 = call ptr @mlf.allocate.thunk(ptr @mlf.code.355, i64 1)
  %v683 = getelementptr i8, ptr %v682, i64 16
  %v684 = load ptr, ptr %v683, align 8, !tbaa !3
  %v685 = getelementptr i8, ptr %v684, i64 8
  store ptr %v337, ptr %v685, align 8, !tbaa !3
  %v703 = call ptr @mlf_env_new(i64 2)
  %v704 = getelementptr i8, ptr %v703, i64 8
  store ptr %v337, ptr %v704, align 8, !tbaa !3
  %v705 = getelementptr i8, ptr %v703, i64 16
  store ptr %v338, ptr %v705, align 8, !tbaa !3
  %v706 = call ptr @mlf_closure(ptr @mlf.code.686, ptr %v703)
  %v707 = call ptr @mlf_prim2(i64 1, ptr %v682, ptr %v706)
  br label %case.join.352
case.missing.351:
  call void @mlf_match_failure()
  unreachable
case.join.352:
  %v708 = phi ptr [ %v354, %case.349 ], [ %v707, %case.350 ]
  ret ptr %v708
}

define private ptr @mlf.code.2(ptr %env, ptr %arg) {
entry:
  %v54 = call ptr @mlf.allocate.thunk(ptr @mlf.code.3, i64 1)
  %v55 = getelementptr i8, ptr %v54, i64 16
  %v56 = load ptr, ptr %v55, align 8, !tbaa !3
  %v57 = getelementptr i8, ptr %v56, i64 8
  store ptr %arg, ptr %v57, align 8, !tbaa !3
  %v80 = call ptr @mlf.allocate.thunk(ptr @mlf.code.58, i64 1)
  %v81 = getelementptr i8, ptr %v80, i64 16
  %v82 = load ptr, ptr %v81, align 8, !tbaa !3
  %v83 = getelementptr i8, ptr %v82, i64 8
  store ptr %v54, ptr %v83, align 8, !tbaa !3
  %v330 = call ptr @mlf.allocate.thunk(ptr @mlf.code.84, i64 1)
  %v331 = getelementptr i8, ptr %v330, i64 16
  %v332 = load ptr, ptr %v331, align 8, !tbaa !3
  %v333 = getelementptr i8, ptr %v332, i64 8
  store ptr %v80, ptr %v333, align 8, !tbaa !3
  %v709 = call ptr @mlf_env_new(i64 1)
  %v710 = getelementptr i8, ptr %v709, i64 8
  store ptr %v80, ptr %v710, align 8, !tbaa !3
  %v711 = call ptr @mlf_closure(ptr @mlf.code.334, ptr %v709)
  %v712 = call ptr @mlf_prim2(i64 1, ptr %v330, ptr %v711)
  ret ptr %v712
}

define private ptr @mlf.code.0(ptr %env, ptr %arg) {
entry:
  %v1 = call ptr @mlf_primitive(i64 4)
  %v713 = call ptr @mlf_closure(ptr @mlf.code.2, ptr null)
  %v714 = call ptr @mlf_prim2(i64 1, ptr %v1, ptr %v713)
  ret ptr %v714
}

declare void @mlf_require_compact_gc_abi()
define ptr @mlf_entry() {
  call void @mlf_require_compact_gc_abi()
  %root = call ptr @mlf.code.0(ptr null, ptr null)
  ret ptr %root
}
define i32 @main(i32 %argc, ptr %argv) {
  call void @mlf_set_args(i32 %argc, ptr %argv)
  %root = call ptr @mlf_entry()
  %status = call i32 @mlf_run(ptr %root, i64 1)
  ret i32 %status
}
