; Generated from independently checked xMLF.
source_filename = "emlf"

declare ptr @mlf_execute_st_lazy(ptr)
declare ptr @mlf_st_new_array(ptr, ptr)
declare ptr @mlf_st_read_array(ptr, ptr)
declare ptr @mlf_st_write_array(ptr, ptr, ptr)
declare ptr @mlf_st_length_array(ptr)
declare void @mlf_set_args(i32, ptr)
declare ptr @mlf_env_new(i64)
declare void @mlf_env_set(ptr, i64, ptr)
declare ptr @mlf_env_get(ptr, i64)
declare ptr @mlf_thunk(ptr, ptr)
declare ptr @mlf_closure(ptr, ptr)
declare ptr @mlf_application(ptr, ptr)
declare ptr @mlf_hole()
declare void @mlf_fill(ptr, ptr)
declare ptr @mlf_integer(ptr)
declare ptr @mlf_string(ptr, i64)
declare ptr @mlf_double(double)
declare double @llvm.sqrt.f64(double)
declare double @mlf_int_to_double(ptr)
declare ptr @mlf_read_int_table(ptr, ptr)
declare ptr @mlf_write_int_table(ptr, ptr, ptr)
declare ptr @mlf_add_int_table(ptr, ptr, ptr)
declare void @mlf_roots_enter(ptr, i64, ptr)
declare void @mlf_roots_leave(ptr)
declare void @mlf_gc_check(i64, ptr)
declare ptr @mlf_get_byte_line()
declare ptr @mlf_new_array(i64, ptr, ptr)
declare ptr @mlf_bytes_from_string(ptr)
declare ptr @mlf_put_bytes(ptr, ptr, ptr)
declare ptr @mlf_new_int_table()
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare i8 @mlf_byte(ptr)
declare ptr @mlf_peek(ptr)
declare ptr @mlf_native_io(ptr, ptr)
declare void @mlf_bounds_failure() noreturn
declare ptr @mlf_primitive(i64)
declare ptr @mlf_prim1(i64, ptr)
declare ptr @mlf_prim2(i64, ptr, ptr)
declare i64 @mlf_truth(ptr)
declare ptr @mlf_prim3(i64, ptr, ptr, ptr)
declare ptr @mlf_force(ptr)
declare ptr @mlf_add_int(ptr, ptr)
declare ptr @mlf_sub_int(ptr, ptr)
declare ptr @mlf_eq_int(ptr, ptr)
declare ptr @mlf_lt_int(ptr, ptr)
declare ptr @mlf_constructor(i64, i64)
declare ptr @mlf_constructor1(i64, ptr)
declare ptr @mlf_constructor2(i64, ptr, ptr)
declare ptr @mlf_constructor_fields(i64, ptr)
declare ptr @mlf_constructor_new(i64, i64)
declare ptr @mlf_field(ptr, i64)
declare void @mlf_match_failure() noreturn
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare i32 @mlf_run(ptr, i64)

!0 = !{!"MLF storage"}
!1 = !{!"managed object", !0}
!2 = !{!"array cells", !0}
!3 = !{!1, !1, i64 0}
!4 = !{!2, !2, i64 0}
define private ptr @mlf.code.3(ptr %env, ptr %arg) {
entry:
  %v4 = getelementptr i8, ptr %env, i64 24
  %v5 = load ptr, ptr %v4, align 8, !tbaa !3
  %v6 = call ptr @mlf_force(ptr %v5)
  %v7 = call ptr @mlf_prim1(i64 17, ptr %v6)
  ret ptr %v7
}

define private ptr @mlf.code.11(ptr %env, ptr %arg) {
entry:
  %v12 = getelementptr i8, ptr %env, i64 24
  %v13 = load ptr, ptr %v12, align 8, !tbaa !3
  %v14 = call ptr @mlf_double(double 0x3ff0000000000000)
  %v15 = call ptr @mlf_prim2(i64 31, ptr %v13, ptr %v14)
  ret ptr %v15
}

define private ptr @mlf.code.22(ptr %env, ptr %arg) {
entry:
  %v23 = getelementptr i8, ptr %env, i64 24
  %v24 = load ptr, ptr %v23, align 8, !tbaa !3
  %v25 = call ptr @mlf_double(double 0x0000000000000000)
  %v26 = call ptr @mlf_prim2(i64 31, ptr %v24, ptr %v25)
  ret ptr %v26
}

define private ptr @mlf.code.35(ptr %env, ptr %arg) {
entry:
  %v36 = getelementptr i8, ptr %env, i64 24
  %v37 = load ptr, ptr %v36, align 8, !tbaa !3
  %v38 = call ptr @mlf_double(double 0x0000000000000000)
  %v39 = call ptr @mlf_prim2(i64 31, ptr %v37, ptr %v38)
  ret ptr %v39
}

define private ptr @mlf.code.50(ptr %env, ptr %arg) {
entry:
  %v51 = call ptr @mlf_double(double 0x0000000000000000)
  %v52 = call ptr @mlf_prim2(i64 31, ptr inttoptr (i64 5 to ptr), ptr %v51)
  ret ptr %v52
}

define private ptr @mlf.code.107(ptr %env, ptr %arg) {
entry:
  %v108 = getelementptr i8, ptr %env, i64 24
  %v109 = load ptr, ptr %v108, align 8, !tbaa !3
  %v110 = call ptr @mlf_force(ptr %v109)
  %v111 = ptrtoint ptr %v110 to i64
  %v112 = and i64 %v111, 7
  %v113 = icmp eq i64 %v112, 4
  br i1 %v113, label %yes.114, label %no.115
yes.114:
  %v117 = lshr i64 %v111, 3
  br label %join.116
no.115:
  %v118 = getelementptr i8, ptr %v110, i64 24
  %v119 = load i64, ptr %v118, align 8, !tbaa !3
  br label %join.116
join.116:
  %v120 = phi i64 [ %v117, %yes.114 ], [ %v119, %no.115 ]
  switch i64 %v120, label %case.missing.122 [
    i64 1, label %case.121
  ]
case.121:
  %v124 = getelementptr i8, ptr %v110, i64 40
  %v125 = load ptr, ptr %v124, align 8, !tbaa !3
  br label %case.join.123
case.missing.122:
  call void @mlf_match_failure()
  unreachable
case.join.123:
  %v126 = phi ptr [ %v125, %case.121 ]
  ret ptr %v126
}

define private ptr @mlf.numeric.6.pppppd(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, double %a5) alwaysinline {
entry:
  %v176 = ptrtoint ptr %a4 to i64
  %v177 = ptrtoint ptr %a0 to i64
  %v178 = and i64 %v176, %v177
  %v179 = and i64 %v178, 1
  %v180 = icmp ne i64 %v179, 0
  br i1 %v180, label %yes.181, label %no.182
yes.181:
  %v184 = icmp slt i64 %v176, %v177
  %v185 = select i1 %v184, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.183
no.182:
  %v186 = call ptr @mlf_lt_int(ptr %a4, ptr %a0)
  br label %join.183
join.183:
  %v187 = phi ptr [ %v185, %yes.181 ], [ %v186, %no.182 ]
  %v188 = icmp eq ptr %v187, inttoptr (i64 6 to ptr)
  br i1 %v188, label %tail.yes.189, label %tail.no.190
tail.yes.189:
  %v191 = getelementptr i8, ptr %a1, i64 24
  %v192 = load i64, ptr %v191, align 8, !tbaa !3
  %v193 = getelementptr i8, ptr %a1, i64 32
  %v194 = load ptr, ptr %v193, align 8, !tbaa !3
  %v195 = ptrtoint ptr %a4 to i64
  %v196 = ashr i64 %v195, 1
  %v197 = and i64 %v195, 1
  %v198 = icmp ne i64 %v197, 0
  %v199 = icmp ult i64 %v196, %v192
  %v200 = and i1 %v198, %v199
  br i1 %v200, label %array.valid.201, label %array.invalid.202
array.invalid.202:
  call void @mlf_bounds_failure()
  unreachable
array.valid.201:
  %v203 = getelementptr i64, ptr %v194, i64 %v196
  %v204 = load double, ptr %v203, align 8, !tbaa !4
  %v205 = ptrtoint ptr %a4 to i64
  %v206 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v207 = sub i64 %v206, 1
  %v208 = add nsw i64 %v205, %v207
  %v209 = inttoptr i64 %v208 to ptr
  %v210 = ptrtoint ptr %a3 to i64
  %v211 = and i64 %v210, 1
  %v212 = icmp ne i64 %v211, 0
  br i1 %v212, label %yes.213, label %no.214
yes.213:
  %v216 = ashr i64 %v210, 1
  %v217 = sitofp i64 %v216 to double
  br label %join.215
no.214:
  %v218 = call double @mlf_int_to_double(ptr %a3)
  br label %join.215
join.215:
  %v219 = phi double [ %v217, %yes.213 ], [ %v218, %no.214 ]
  %v220 = ptrtoint ptr %a4 to i64
  %v221 = and i64 %v220, 1
  %v222 = icmp ne i64 %v221, 0
  br i1 %v222, label %yes.223, label %no.224
yes.223:
  %v226 = ashr i64 %v220, 1
  %v227 = sitofp i64 %v226 to double
  br label %join.225
no.224:
  %v228 = call double @mlf_int_to_double(ptr %a4)
  br label %join.225
join.225:
  %v229 = phi double [ %v227, %yes.223 ], [ %v228, %no.224 ]
  %v230 = fadd double %v219, %v229
  %v231 = fadd double %v230, 0x3ff0000000000000
  %v232 = fmul double %v230, %v231
  %v233 = fdiv double %v232, 0x4000000000000000
  %v234 = fadd double %v233, %v219
  %v235 = fadd double %v234, 0x3ff0000000000000
  %v236 = fdiv double 0x3ff0000000000000, %v235
  %v237 = fmul double %v236, %v204
  %v238 = fadd double %a5, %v237
  %v239 = musttail call ptr @mlf.numeric.6.pppppd(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %v209, double %v238)
  ret ptr %v239
tail.no.190:
  %v240 = getelementptr i8, ptr %a2, i64 24
  %v241 = load i64, ptr %v240, align 8, !tbaa !3
  %v242 = getelementptr i8, ptr %a2, i64 32
  %v243 = load ptr, ptr %v242, align 8, !tbaa !3
  %v244 = ptrtoint ptr %a3 to i64
  %v245 = ashr i64 %v244, 1
  %v246 = and i64 %v244, 1
  %v247 = icmp ne i64 %v246, 0
  %v248 = icmp ult i64 %v245, %v241
  %v249 = and i1 %v247, %v248
  br i1 %v249, label %array.valid.250, label %array.invalid.251
array.invalid.251:
  call void @mlf_bounds_failure()
  unreachable
array.valid.250:
  %v252 = getelementptr i64, ptr %v243, i64 %v245
  store double %a5, ptr %v252, align 8, !tbaa !4
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.numeric.22(ptr %a0, ptr %a1, ptr %a2, ptr %a3) alwaysinline {
entry:
  %v161 = ptrtoint ptr %a3 to i64
  %v162 = ptrtoint ptr %a0 to i64
  %v163 = and i64 %v161, %v162
  %v164 = and i64 %v163, 1
  %v165 = icmp ne i64 %v164, 0
  br i1 %v165, label %yes.166, label %no.167
yes.166:
  %v169 = icmp slt i64 %v161, %v162
  %v170 = select i1 %v169, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.168
no.167:
  %v171 = call ptr @mlf_lt_int(ptr %a3, ptr %a0)
  br label %join.168
join.168:
  %v172 = phi ptr [ %v170, %yes.166 ], [ %v171, %no.167 ]
  %v173 = icmp eq ptr %v172, inttoptr (i64 6 to ptr)
  br i1 %v173, label %tail.yes.174, label %tail.no.175
tail.yes.174:
  %v253 = call ptr @mlf.numeric.6.pppppd(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr inttoptr (i64 1 to ptr), double 0x0000000000000000)
  %v254 = ptrtoint ptr %a3 to i64
  %v255 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v256 = and i64 %v254, %v255
  %v257 = and i64 %v256, 1
  %v258 = icmp ne i64 %v257, 0
  br i1 %v258, label %yes.259, label %no.260
yes.259:
  %v262 = sub i64 %v255, 1
  %v263 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v254, i64 %v262)
  %v264 = extractvalue { i64, i1 } %v263, 0
  %v265 = extractvalue { i64, i1 } %v263, 1
  br i1 %v265, label %yes.266, label %no.267
yes.266:
  %v269 = call ptr @mlf_add_int(ptr %a3, ptr inttoptr (i64 3 to ptr))
  br label %join.268
no.267:
  %v270 = inttoptr i64 %v264 to ptr
  br label %join.268
join.268:
  %v271 = phi ptr [ %v269, %yes.266 ], [ %v270, %no.267 ]
  br label %join.261
no.260:
  %v272 = call ptr @mlf_add_int(ptr %a3, ptr inttoptr (i64 3 to ptr))
  br label %join.261
join.261:
  %v273 = phi ptr [ %v271, %join.268 ], [ %v272, %no.260 ]
  %v274 = musttail call ptr @mlf.numeric.22(ptr %a0, ptr %a1, ptr %a2, ptr %v273)
  ret ptr %v274
tail.no.175:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.numeric.6(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5) alwaysinline {
entry:
  %v325 = ptrtoint ptr %a4 to i64
  %v326 = ptrtoint ptr %a0 to i64
  %v327 = and i64 %v325, %v326
  %v328 = and i64 %v327, 1
  %v329 = icmp ne i64 %v328, 0
  br i1 %v329, label %yes.330, label %no.331
yes.330:
  %v333 = icmp slt i64 %v325, %v326
  %v334 = select i1 %v333, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.332
no.331:
  %v335 = call ptr @mlf_lt_int(ptr %a4, ptr %a0)
  br label %join.332
join.332:
  %v336 = phi ptr [ %v334, %yes.330 ], [ %v335, %no.331 ]
  %v337 = icmp eq ptr %v336, inttoptr (i64 6 to ptr)
  br i1 %v337, label %tail.yes.338, label %tail.no.339
tail.yes.338:
  %v340 = getelementptr i8, ptr %a1, i64 24
  %v341 = load i64, ptr %v340, align 8, !tbaa !3
  %v342 = getelementptr i8, ptr %a1, i64 32
  %v343 = load ptr, ptr %v342, align 8, !tbaa !3
  %v344 = ptrtoint ptr %a4 to i64
  %v345 = ashr i64 %v344, 1
  %v346 = and i64 %v344, 1
  %v347 = icmp ne i64 %v346, 0
  %v348 = icmp ult i64 %v345, %v341
  %v349 = and i1 %v347, %v348
  br i1 %v349, label %array.valid.350, label %array.invalid.351
array.invalid.351:
  call void @mlf_bounds_failure()
  unreachable
array.valid.350:
  %v352 = getelementptr i64, ptr %v343, i64 %v345
  %v353 = load double, ptr %v352, align 8, !tbaa !4
  %v354 = ptrtoint ptr %a4 to i64
  %v355 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v356 = sub i64 %v355, 1
  %v357 = add nsw i64 %v354, %v356
  %v358 = inttoptr i64 %v357 to ptr
  %v359 = ptrtoint ptr %a3 to i64
  %v360 = and i64 %v359, 1
  %v361 = icmp ne i64 %v360, 0
  br i1 %v361, label %yes.362, label %no.363
yes.362:
  %v365 = ashr i64 %v359, 1
  %v366 = sitofp i64 %v365 to double
  br label %join.364
no.363:
  %v367 = call double @mlf_int_to_double(ptr %a3)
  br label %join.364
join.364:
  %v368 = phi double [ %v366, %yes.362 ], [ %v367, %no.363 ]
  %v369 = ptrtoint ptr %a4 to i64
  %v370 = and i64 %v369, 1
  %v371 = icmp ne i64 %v370, 0
  br i1 %v371, label %yes.372, label %no.373
yes.372:
  %v375 = ashr i64 %v369, 1
  %v376 = sitofp i64 %v375 to double
  br label %join.374
no.373:
  %v377 = call double @mlf_int_to_double(ptr %a4)
  br label %join.374
join.374:
  %v378 = phi double [ %v376, %yes.372 ], [ %v377, %no.373 ]
  %v379 = fadd double %v368, %v378
  %v380 = fadd double %v379, 0x3ff0000000000000
  %v381 = fmul double %v379, %v380
  %v382 = fdiv double %v381, 0x4000000000000000
  %v383 = fadd double %v382, %v368
  %v384 = fadd double %v383, 0x3ff0000000000000
  %v385 = fdiv double 0x3ff0000000000000, %v384
  %v386 = fmul double %v385, %v353
  %v387 = getelementptr i8, ptr %a5, i64 24
  %v388 = load double, ptr %v387, align 8, !tbaa !3
  %v389 = fadd double %v388, %v386
  %v390 = call ptr @mlf.numeric.6.pppppd(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %v358, double %v389)
  ret ptr %v390
tail.no.339:
  %v391 = getelementptr i8, ptr %a2, i64 24
  %v392 = load i64, ptr %v391, align 8, !tbaa !3
  %v393 = getelementptr i8, ptr %a2, i64 32
  %v394 = load ptr, ptr %v393, align 8, !tbaa !3
  %v395 = ptrtoint ptr %a3 to i64
  %v396 = ashr i64 %v395, 1
  %v397 = and i64 %v395, 1
  %v398 = icmp ne i64 %v397, 0
  %v399 = icmp ult i64 %v396, %v392
  %v400 = and i1 %v398, %v399
  br i1 %v400, label %array.valid.401, label %array.invalid.402
array.invalid.402:
  call void @mlf_bounds_failure()
  unreachable
array.valid.401:
  %v403 = getelementptr i64, ptr %v394, i64 %v396
  %v404 = getelementptr i8, ptr %a5, i64 24
  %v405 = load double, ptr %v404, align 8, !tbaa !3
  store double %v405, ptr %v403, align 8, !tbaa !4
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.code.413(ptr %env, ptr %arg) {
entry:
  %v414 = getelementptr i8, ptr %env, i64 24
  %v415 = load ptr, ptr %v414, align 8, !tbaa !3
  %v416 = getelementptr i8, ptr %env, i64 32
  %v417 = load ptr, ptr %v416, align 8, !tbaa !3
  %v418 = call ptr @mlf_prim2(i64 32, ptr %v415, ptr %v417)
  ret ptr %v418
}

define private ptr @mlf.worker.0(ptr %a0, ptr %a1) {
entry:
  %v449 = call ptr @mlf_prim1(i64 25, ptr %a0)
  %v450 = call ptr @mlf_prim1(i64 25, ptr %a1)
  %v451 = call ptr @mlf_prim2(i64 18, ptr %v449, ptr %v450)
  %v452 = call ptr @mlf_double(double 0x3ff0000000000000)
  %v453 = call ptr @mlf_double(double 0x3ff0000000000000)
  %v454 = call ptr @mlf_prim2(i64 18, ptr %v451, ptr %v453)
  %v455 = call ptr @mlf_prim2(i64 20, ptr %v451, ptr %v454)
  %v456 = call ptr @mlf_double(double 0x4000000000000000)
  %v457 = call ptr @mlf_prim2(i64 21, ptr %v455, ptr %v456)
  %v458 = call ptr @mlf_prim2(i64 18, ptr %v457, ptr %v449)
  %v459 = call ptr @mlf_double(double 0x3ff0000000000000)
  %v460 = call ptr @mlf_prim2(i64 18, ptr %v458, ptr %v459)
  %v461 = call ptr @mlf_prim2(i64 21, ptr %v452, ptr %v460)
  ret ptr %v461
}

define private ptr @mlf.code.439(ptr %env, ptr %arg) {
entry:
  %v440 = getelementptr i8, ptr %env, i64 24
  %v441 = load ptr, ptr %v440, align 8, !tbaa !3
  %v442 = getelementptr i8, ptr %env, i64 32
  %v443 = load ptr, ptr %v442, align 8, !tbaa !3
  %v444 = getelementptr i8, ptr %env, i64 40
  %v445 = load ptr, ptr %v444, align 8, !tbaa !3
  %v446 = getelementptr i8, ptr %env, i64 48
  %v447 = load ptr, ptr %v446, align 8, !tbaa !3
  %v448 = call ptr @mlf_force(ptr %v445)
  %v462 = call ptr @mlf_force(ptr %v441)
  %v463 = call ptr @mlf_force(ptr %v443)
  %v464 = call ptr @mlf.worker.0(ptr %v462, ptr %v463)
  %v465 = call ptr @mlf_force(ptr %v447)
  %v466 = call ptr @mlf_prim2(i64 20, ptr %v464, ptr %v465)
  %v467 = call ptr @mlf_prim2(i64 18, ptr %v448, ptr %v466)
  ret ptr %v467
}

define private ptr @mlf.code.423(ptr %env, ptr %arg) {
entry:
  %v424 = getelementptr i8, ptr %env, i64 24
  %v425 = load ptr, ptr %v424, align 8, !tbaa !3
  %v426 = getelementptr i8, ptr %env, i64 32
  %v427 = load ptr, ptr %v426, align 8, !tbaa !3
  %v428 = getelementptr i8, ptr %env, i64 40
  %v429 = load ptr, ptr %v428, align 8, !tbaa !3
  %v430 = getelementptr i8, ptr %env, i64 48
  %v431 = load ptr, ptr %v430, align 8, !tbaa !3
  %v432 = getelementptr i8, ptr %env, i64 56
  %v433 = load ptr, ptr %v432, align 8, !tbaa !3
  %v434 = getelementptr i8, ptr %env, i64 64
  %v435 = load ptr, ptr %v434, align 8, !tbaa !3
  %v436 = call ptr @mlf_force(ptr %v425)
  %v437 = call ptr @mlf_force(ptr %v433)
  %v438 = call ptr @mlf_prim2(i64 8, ptr %v437, ptr inttoptr (i64 3 to ptr))
  %v468 = call ptr @mlf_env_new(i64 4)
  %v469 = getelementptr i8, ptr %v468, i64 24
  store ptr %v431, ptr %v469, align 8, !tbaa !3
  %v470 = getelementptr i8, ptr %v468, i64 32
  store ptr %v437, ptr %v470, align 8, !tbaa !3
  %v471 = getelementptr i8, ptr %v468, i64 40
  store ptr %v435, ptr %v471, align 8, !tbaa !3
  %v472 = getelementptr i8, ptr %v468, i64 48
  store ptr %arg, ptr %v472, align 8, !tbaa !3
  %v473 = call ptr @mlf_thunk(ptr @mlf.code.439, ptr %v468)
  %v474 = call ptr @mlf_env_new(i64 6)
  %v475 = getelementptr i8, ptr %v474, i64 24
  store ptr %v436, ptr %v475, align 8, !tbaa !3
  %v476 = getelementptr i8, ptr %v474, i64 32
  store ptr %v427, ptr %v476, align 8, !tbaa !3
  %v477 = getelementptr i8, ptr %v474, i64 40
  store ptr %v429, ptr %v477, align 8, !tbaa !3
  %v478 = getelementptr i8, ptr %v474, i64 48
  store ptr %v431, ptr %v478, align 8, !tbaa !3
  %v479 = getelementptr i8, ptr %v474, i64 56
  store ptr %v438, ptr %v479, align 8, !tbaa !3
  %v480 = getelementptr i8, ptr %v474, i64 64
  store ptr %v473, ptr %v480, align 8, !tbaa !3
  %v481 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.291, ptr %v474)
  ret ptr %v481
}

define private ptr @mlf.worker.6(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5) {
entry:
  %v408 = call ptr @mlf_prim2(i64 11, ptr %a4, ptr %a0)
  %v409 = icmp eq ptr %v408, inttoptr (i64 6 to ptr)
  br i1 %v409, label %yes.410, label %no.411
yes.410:
  %v419 = call ptr @mlf_env_new(i64 2)
  %v420 = getelementptr i8, ptr %v419, i64 24
  store ptr %a1, ptr %v420, align 8, !tbaa !3
  %v421 = getelementptr i8, ptr %v419, i64 32
  store ptr %a4, ptr %v421, align 8, !tbaa !3
  %v422 = call ptr @mlf_thunk(ptr @mlf.code.413, ptr %v419)
  %v482 = call ptr @mlf_env_new(i64 6)
  %v483 = getelementptr i8, ptr %v482, i64 24
  store ptr %a0, ptr %v483, align 8, !tbaa !3
  %v484 = getelementptr i8, ptr %v482, i64 32
  store ptr %a1, ptr %v484, align 8, !tbaa !3
  %v485 = getelementptr i8, ptr %v482, i64 40
  store ptr %a2, ptr %v485, align 8, !tbaa !3
  %v486 = getelementptr i8, ptr %v482, i64 48
  store ptr %a3, ptr %v486, align 8, !tbaa !3
  %v487 = getelementptr i8, ptr %v482, i64 56
  store ptr %a4, ptr %v487, align 8, !tbaa !3
  %v488 = getelementptr i8, ptr %v482, i64 64
  store ptr %a5, ptr %v488, align 8, !tbaa !3
  %v489 = call ptr @mlf_closure(ptr @mlf.code.423, ptr %v482)
  %v490 = call ptr @mlf_prim2(i64 1, ptr %v422, ptr %v489)
  br label %join.412
no.411:
  %v491 = call ptr @mlf_prim3(i64 33, ptr %a2, ptr %a3, ptr %a5)
  br label %join.412
join.412:
  %v492 = phi ptr [ %v490, %yes.410 ], [ %v491, %no.411 ]
  ret ptr %v492
}

define private ptr @mlf.numeric.entry.291(ptr %env, ptr %arg) {
entry:
  %v292 = getelementptr i8, ptr %env, i64 24
  %v293 = load ptr, ptr %v292, align 8, !tbaa !3
  %v294 = getelementptr i8, ptr %env, i64 32
  %v295 = load ptr, ptr %v294, align 8, !tbaa !3
  %v296 = getelementptr i8, ptr %env, i64 40
  %v297 = load ptr, ptr %v296, align 8, !tbaa !3
  %v298 = getelementptr i8, ptr %env, i64 48
  %v299 = load ptr, ptr %v298, align 8, !tbaa !3
  %v300 = getelementptr i8, ptr %env, i64 56
  %v301 = load ptr, ptr %v300, align 8, !tbaa !3
  %v302 = getelementptr i8, ptr %env, i64 64
  %v303 = load ptr, ptr %v302, align 8, !tbaa !3
  %v304 = call ptr @mlf_peek(ptr %v293)
  %v305 = call ptr @mlf_peek(ptr %v295)
  %v306 = call ptr @mlf_peek(ptr %v297)
  %v307 = call ptr @mlf_peek(ptr %v299)
  %v308 = call ptr @mlf_peek(ptr %v301)
  %v309 = call ptr @mlf_peek(ptr %v303)
  %v310 = icmp ne ptr %v304, null
  %v311 = icmp ne ptr %v305, null
  %v312 = icmp ne ptr %v306, null
  %v313 = icmp ne ptr %v307, null
  %v314 = icmp ne ptr %v308, null
  %v315 = icmp ne ptr %v309, null
  %v316 = and i1 true, %v310
  %v317 = and i1 %v316, %v311
  %v318 = and i1 %v317, %v312
  %v319 = and i1 %v318, %v313
  %v320 = and i1 %v319, %v314
  %v321 = and i1 %v320, %v315
  br i1 %v321, label %yes.322, label %no.323
yes.322:
  %v406 = call ptr @mlf.numeric.6(ptr %v304, ptr %v305, ptr %v306, ptr %v307, ptr %v308, ptr %v309)
  %v407 = call ptr @mlf_prim1(i64 0, ptr %v406)
  br label %join.324
no.323:
  %v493 = call ptr @mlf_force(ptr %v293)
  %v494 = call ptr @mlf_force(ptr %v301)
  %v495 = call ptr @mlf.worker.6(ptr %v493, ptr %v295, ptr %v297, ptr %v299, ptr %v494, ptr %v303)
  br label %join.324
join.324:
  %v496 = phi ptr [ %v407, %yes.322 ], [ %v495, %no.323 ]
  ret ptr %v496
}

define private ptr @mlf.code.282(ptr %env, ptr %arg) {
entry:
  %v283 = getelementptr i8, ptr %env, i64 24
  %v284 = load ptr, ptr %v283, align 8, !tbaa !3
  %v285 = getelementptr i8, ptr %env, i64 32
  %v286 = load ptr, ptr %v285, align 8, !tbaa !3
  %v287 = getelementptr i8, ptr %env, i64 40
  %v288 = load ptr, ptr %v287, align 8, !tbaa !3
  %v289 = getelementptr i8, ptr %env, i64 48
  %v290 = load ptr, ptr %v289, align 8, !tbaa !3
  %v497 = call ptr @mlf_force(ptr %v284)
  %v498 = call ptr @mlf_double(double 0x0000000000000000)
  %v499 = call ptr @mlf_env_new(i64 6)
  %v500 = getelementptr i8, ptr %v499, i64 24
  store ptr %v497, ptr %v500, align 8, !tbaa !3
  %v501 = getelementptr i8, ptr %v499, i64 32
  store ptr %v286, ptr %v501, align 8, !tbaa !3
  %v502 = getelementptr i8, ptr %v499, i64 40
  store ptr %v288, ptr %v502, align 8, !tbaa !3
  %v503 = getelementptr i8, ptr %v499, i64 48
  store ptr %v290, ptr %v503, align 8, !tbaa !3
  %v504 = getelementptr i8, ptr %v499, i64 56
  store ptr inttoptr (i64 1 to ptr), ptr %v504, align 8, !tbaa !3
  %v505 = getelementptr i8, ptr %v499, i64 64
  store ptr %v498, ptr %v505, align 8, !tbaa !3
  %v506 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.291, ptr %v499)
  ret ptr %v506
}

define private ptr @mlf.code.513(ptr %env, ptr %arg) {
entry:
  %v514 = getelementptr i8, ptr %env, i64 24
  %v515 = load ptr, ptr %v514, align 8, !tbaa !3
  %v516 = getelementptr i8, ptr %env, i64 32
  %v517 = load ptr, ptr %v516, align 8, !tbaa !3
  %v518 = getelementptr i8, ptr %env, i64 40
  %v519 = load ptr, ptr %v518, align 8, !tbaa !3
  %v520 = getelementptr i8, ptr %env, i64 48
  %v521 = load ptr, ptr %v520, align 8, !tbaa !3
  %v522 = call ptr @mlf_force(ptr %v515)
  %v523 = call ptr @mlf_force(ptr %v521)
  %v524 = call ptr @mlf_prim2(i64 8, ptr %v523, ptr inttoptr (i64 3 to ptr))
  %v525 = call ptr @mlf_env_new(i64 4)
  %v526 = getelementptr i8, ptr %v525, i64 24
  store ptr %v522, ptr %v526, align 8, !tbaa !3
  %v527 = getelementptr i8, ptr %v525, i64 32
  store ptr %v517, ptr %v527, align 8, !tbaa !3
  %v528 = getelementptr i8, ptr %v525, i64 40
  store ptr %v519, ptr %v528, align 8, !tbaa !3
  %v529 = getelementptr i8, ptr %v525, i64 48
  store ptr %v524, ptr %v529, align 8, !tbaa !3
  %v530 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.137, ptr %v525)
  ret ptr %v530
}

define private ptr @mlf.worker.22(ptr %a0, ptr %a1, ptr %a2, ptr %a3) {
entry:
  %v277 = call ptr @mlf_prim2(i64 11, ptr %a3, ptr %a0)
  %v278 = icmp eq ptr %v277, inttoptr (i64 6 to ptr)
  br i1 %v278, label %yes.279, label %no.280
yes.279:
  %v507 = call ptr @mlf_env_new(i64 4)
  %v508 = getelementptr i8, ptr %v507, i64 24
  store ptr %a0, ptr %v508, align 8, !tbaa !3
  %v509 = getelementptr i8, ptr %v507, i64 32
  store ptr %a1, ptr %v509, align 8, !tbaa !3
  %v510 = getelementptr i8, ptr %v507, i64 40
  store ptr %a2, ptr %v510, align 8, !tbaa !3
  %v511 = getelementptr i8, ptr %v507, i64 48
  store ptr %a3, ptr %v511, align 8, !tbaa !3
  %v512 = call ptr @mlf_thunk(ptr @mlf.code.282, ptr %v507)
  %v531 = call ptr @mlf_env_new(i64 4)
  %v532 = getelementptr i8, ptr %v531, i64 24
  store ptr %a0, ptr %v532, align 8, !tbaa !3
  %v533 = getelementptr i8, ptr %v531, i64 32
  store ptr %a1, ptr %v533, align 8, !tbaa !3
  %v534 = getelementptr i8, ptr %v531, i64 40
  store ptr %a2, ptr %v534, align 8, !tbaa !3
  %v535 = getelementptr i8, ptr %v531, i64 48
  store ptr %a3, ptr %v535, align 8, !tbaa !3
  %v536 = call ptr @mlf_closure(ptr @mlf.code.513, ptr %v531)
  %v537 = call ptr @mlf_prim2(i64 1, ptr %v512, ptr %v536)
  br label %join.281
no.280:
  %v538 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.281
join.281:
  %v539 = phi ptr [ %v537, %yes.279 ], [ %v538, %no.280 ]
  ret ptr %v539
}

define private ptr @mlf.numeric.entry.137(ptr %env, ptr %arg) {
entry:
  %v138 = getelementptr i8, ptr %env, i64 24
  %v139 = load ptr, ptr %v138, align 8, !tbaa !3
  %v140 = getelementptr i8, ptr %env, i64 32
  %v141 = load ptr, ptr %v140, align 8, !tbaa !3
  %v142 = getelementptr i8, ptr %env, i64 40
  %v143 = load ptr, ptr %v142, align 8, !tbaa !3
  %v144 = getelementptr i8, ptr %env, i64 48
  %v145 = load ptr, ptr %v144, align 8, !tbaa !3
  %v146 = call ptr @mlf_peek(ptr %v139)
  %v147 = call ptr @mlf_peek(ptr %v141)
  %v148 = call ptr @mlf_peek(ptr %v143)
  %v149 = call ptr @mlf_peek(ptr %v145)
  %v150 = icmp ne ptr %v146, null
  %v151 = icmp ne ptr %v147, null
  %v152 = icmp ne ptr %v148, null
  %v153 = icmp ne ptr %v149, null
  %v154 = and i1 true, %v150
  %v155 = and i1 %v154, %v151
  %v156 = and i1 %v155, %v152
  %v157 = and i1 %v156, %v153
  br i1 %v157, label %yes.158, label %no.159
yes.158:
  %v275 = call ptr @mlf.numeric.22(ptr %v146, ptr %v147, ptr %v148, ptr %v149)
  %v276 = call ptr @mlf_prim1(i64 0, ptr %v275)
  br label %join.160
no.159:
  %v540 = call ptr @mlf_force(ptr %v139)
  %v541 = call ptr @mlf_force(ptr %v145)
  %v542 = call ptr @mlf.worker.22(ptr %v540, ptr %v141, ptr %v143, ptr %v541)
  br label %join.160
join.160:
  %v543 = phi ptr [ %v276, %yes.158 ], [ %v542, %no.159 ]
  ret ptr %v543
}

define private ptr @mlf.code.130(ptr %env, ptr %arg) {
entry:
  %v131 = getelementptr i8, ptr %env, i64 24
  %v132 = load ptr, ptr %v131, align 8, !tbaa !3
  %v133 = getelementptr i8, ptr %env, i64 32
  %v134 = load ptr, ptr %v133, align 8, !tbaa !3
  %v135 = getelementptr i8, ptr %env, i64 40
  %v136 = load ptr, ptr %v135, align 8, !tbaa !3
  %v544 = call ptr @mlf_force(ptr %v132)
  %v545 = call ptr @mlf_env_new(i64 4)
  %v546 = getelementptr i8, ptr %v545, i64 24
  store ptr %v544, ptr %v546, align 8, !tbaa !3
  %v547 = getelementptr i8, ptr %v545, i64 32
  store ptr %v134, ptr %v547, align 8, !tbaa !3
  %v548 = getelementptr i8, ptr %v545, i64 40
  store ptr %v136, ptr %v548, align 8, !tbaa !3
  %v549 = getelementptr i8, ptr %v545, i64 48
  store ptr inttoptr (i64 1 to ptr), ptr %v549, align 8, !tbaa !3
  %v550 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.137, ptr %v545)
  ret ptr %v550
}

define private ptr @mlf.code.98(ptr %env, ptr %arg) {
entry:
  %v99 = getelementptr i8, ptr %env, i64 24
  %v100 = load ptr, ptr %v99, align 8, !tbaa !3
  %v101 = getelementptr i8, ptr %env, i64 32
  %v102 = load ptr, ptr %v101, align 8, !tbaa !3
  %v103 = getelementptr i8, ptr %env, i64 40
  %v104 = load ptr, ptr %v103, align 8, !tbaa !3
  %v105 = getelementptr i8, ptr %env, i64 48
  %v106 = load ptr, ptr %v105, align 8, !tbaa !3
  %v127 = call ptr @mlf_env_new(i64 1)
  %v128 = getelementptr i8, ptr %v127, i64 24
  store ptr %v100, ptr %v128, align 8, !tbaa !3
  %v129 = call ptr @mlf_thunk(ptr @mlf.code.107, ptr %v127)
  %v551 = call ptr @mlf_env_new(i64 3)
  %v552 = getelementptr i8, ptr %v551, i64 24
  store ptr %v102, ptr %v552, align 8, !tbaa !3
  %v553 = getelementptr i8, ptr %v551, i64 32
  store ptr %v104, ptr %v553, align 8, !tbaa !3
  %v554 = getelementptr i8, ptr %v551, i64 40
  store ptr %v106, ptr %v554, align 8, !tbaa !3
  %v555 = call ptr @mlf_thunk(ptr @mlf.code.130, ptr %v551)
  %v556 = call ptr @mlf_application(ptr %v129, ptr %v555)
  %v557 = call ptr @mlf_force(ptr %v556)
  ret ptr %v557
}

define private ptr @mlf.numeric.14.pppppd(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, double %a5) alwaysinline {
entry:
  %v610 = ptrtoint ptr %a4 to i64
  %v611 = ptrtoint ptr %a0 to i64
  %v612 = and i64 %v610, %v611
  %v613 = and i64 %v612, 1
  %v614 = icmp ne i64 %v613, 0
  br i1 %v614, label %yes.615, label %no.616
yes.615:
  %v618 = icmp slt i64 %v610, %v611
  %v619 = select i1 %v618, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.617
no.616:
  %v620 = call ptr @mlf_lt_int(ptr %a4, ptr %a0)
  br label %join.617
join.617:
  %v621 = phi ptr [ %v619, %yes.615 ], [ %v620, %no.616 ]
  %v622 = icmp eq ptr %v621, inttoptr (i64 6 to ptr)
  br i1 %v622, label %tail.yes.623, label %tail.no.624
tail.yes.623:
  %v625 = getelementptr i8, ptr %a1, i64 24
  %v626 = load i64, ptr %v625, align 8, !tbaa !3
  %v627 = getelementptr i8, ptr %a1, i64 32
  %v628 = load ptr, ptr %v627, align 8, !tbaa !3
  %v629 = ptrtoint ptr %a4 to i64
  %v630 = ashr i64 %v629, 1
  %v631 = and i64 %v629, 1
  %v632 = icmp ne i64 %v631, 0
  %v633 = icmp ult i64 %v630, %v626
  %v634 = and i1 %v632, %v633
  br i1 %v634, label %array.valid.635, label %array.invalid.636
array.invalid.636:
  call void @mlf_bounds_failure()
  unreachable
array.valid.635:
  %v637 = getelementptr i64, ptr %v628, i64 %v630
  %v638 = load double, ptr %v637, align 8, !tbaa !4
  %v639 = ptrtoint ptr %a4 to i64
  %v640 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v641 = sub i64 %v640, 1
  %v642 = add nsw i64 %v639, %v641
  %v643 = inttoptr i64 %v642 to ptr
  %v644 = ptrtoint ptr %a4 to i64
  %v645 = and i64 %v644, 1
  %v646 = icmp ne i64 %v645, 0
  br i1 %v646, label %yes.647, label %no.648
yes.647:
  %v650 = ashr i64 %v644, 1
  %v651 = sitofp i64 %v650 to double
  br label %join.649
no.648:
  %v652 = call double @mlf_int_to_double(ptr %a4)
  br label %join.649
join.649:
  %v653 = phi double [ %v651, %yes.647 ], [ %v652, %no.648 ]
  %v654 = ptrtoint ptr %a3 to i64
  %v655 = and i64 %v654, 1
  %v656 = icmp ne i64 %v655, 0
  br i1 %v656, label %yes.657, label %no.658
yes.657:
  %v660 = ashr i64 %v654, 1
  %v661 = sitofp i64 %v660 to double
  br label %join.659
no.658:
  %v662 = call double @mlf_int_to_double(ptr %a3)
  br label %join.659
join.659:
  %v663 = phi double [ %v661, %yes.657 ], [ %v662, %no.658 ]
  %v664 = fadd double %v653, %v663
  %v665 = fadd double %v664, 0x3ff0000000000000
  %v666 = fmul double %v664, %v665
  %v667 = fdiv double %v666, 0x4000000000000000
  %v668 = fadd double %v667, %v653
  %v669 = fadd double %v668, 0x3ff0000000000000
  %v670 = fdiv double 0x3ff0000000000000, %v669
  %v671 = fmul double %v670, %v638
  %v672 = fadd double %a5, %v671
  %v673 = musttail call ptr @mlf.numeric.14.pppppd(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %v643, double %v672)
  ret ptr %v673
tail.no.624:
  %v674 = getelementptr i8, ptr %a2, i64 24
  %v675 = load i64, ptr %v674, align 8, !tbaa !3
  %v676 = getelementptr i8, ptr %a2, i64 32
  %v677 = load ptr, ptr %v676, align 8, !tbaa !3
  %v678 = ptrtoint ptr %a3 to i64
  %v679 = ashr i64 %v678, 1
  %v680 = and i64 %v678, 1
  %v681 = icmp ne i64 %v680, 0
  %v682 = icmp ult i64 %v679, %v675
  %v683 = and i1 %v681, %v682
  br i1 %v683, label %array.valid.684, label %array.invalid.685
array.invalid.685:
  call void @mlf_bounds_failure()
  unreachable
array.valid.684:
  %v686 = getelementptr i64, ptr %v677, i64 %v679
  store double %a5, ptr %v686, align 8, !tbaa !4
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.numeric.28(ptr %a0, ptr %a1, ptr %a2, ptr %a3) alwaysinline {
entry:
  %v595 = ptrtoint ptr %a3 to i64
  %v596 = ptrtoint ptr %a0 to i64
  %v597 = and i64 %v595, %v596
  %v598 = and i64 %v597, 1
  %v599 = icmp ne i64 %v598, 0
  br i1 %v599, label %yes.600, label %no.601
yes.600:
  %v603 = icmp slt i64 %v595, %v596
  %v604 = select i1 %v603, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.602
no.601:
  %v605 = call ptr @mlf_lt_int(ptr %a3, ptr %a0)
  br label %join.602
join.602:
  %v606 = phi ptr [ %v604, %yes.600 ], [ %v605, %no.601 ]
  %v607 = icmp eq ptr %v606, inttoptr (i64 6 to ptr)
  br i1 %v607, label %tail.yes.608, label %tail.no.609
tail.yes.608:
  %v687 = call ptr @mlf.numeric.14.pppppd(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr inttoptr (i64 1 to ptr), double 0x0000000000000000)
  %v688 = ptrtoint ptr %a3 to i64
  %v689 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v690 = and i64 %v688, %v689
  %v691 = and i64 %v690, 1
  %v692 = icmp ne i64 %v691, 0
  br i1 %v692, label %yes.693, label %no.694
yes.693:
  %v696 = sub i64 %v689, 1
  %v697 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v688, i64 %v696)
  %v698 = extractvalue { i64, i1 } %v697, 0
  %v699 = extractvalue { i64, i1 } %v697, 1
  br i1 %v699, label %yes.700, label %no.701
yes.700:
  %v703 = call ptr @mlf_add_int(ptr %a3, ptr inttoptr (i64 3 to ptr))
  br label %join.702
no.701:
  %v704 = inttoptr i64 %v698 to ptr
  br label %join.702
join.702:
  %v705 = phi ptr [ %v703, %yes.700 ], [ %v704, %no.701 ]
  br label %join.695
no.694:
  %v706 = call ptr @mlf_add_int(ptr %a3, ptr inttoptr (i64 3 to ptr))
  br label %join.695
join.695:
  %v707 = phi ptr [ %v705, %join.702 ], [ %v706, %no.694 ]
  %v708 = musttail call ptr @mlf.numeric.28(ptr %a0, ptr %a1, ptr %a2, ptr %v707)
  ret ptr %v708
tail.no.609:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.numeric.14(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5) alwaysinline {
entry:
  %v759 = ptrtoint ptr %a4 to i64
  %v760 = ptrtoint ptr %a0 to i64
  %v761 = and i64 %v759, %v760
  %v762 = and i64 %v761, 1
  %v763 = icmp ne i64 %v762, 0
  br i1 %v763, label %yes.764, label %no.765
yes.764:
  %v767 = icmp slt i64 %v759, %v760
  %v768 = select i1 %v767, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.766
no.765:
  %v769 = call ptr @mlf_lt_int(ptr %a4, ptr %a0)
  br label %join.766
join.766:
  %v770 = phi ptr [ %v768, %yes.764 ], [ %v769, %no.765 ]
  %v771 = icmp eq ptr %v770, inttoptr (i64 6 to ptr)
  br i1 %v771, label %tail.yes.772, label %tail.no.773
tail.yes.772:
  %v774 = getelementptr i8, ptr %a1, i64 24
  %v775 = load i64, ptr %v774, align 8, !tbaa !3
  %v776 = getelementptr i8, ptr %a1, i64 32
  %v777 = load ptr, ptr %v776, align 8, !tbaa !3
  %v778 = ptrtoint ptr %a4 to i64
  %v779 = ashr i64 %v778, 1
  %v780 = and i64 %v778, 1
  %v781 = icmp ne i64 %v780, 0
  %v782 = icmp ult i64 %v779, %v775
  %v783 = and i1 %v781, %v782
  br i1 %v783, label %array.valid.784, label %array.invalid.785
array.invalid.785:
  call void @mlf_bounds_failure()
  unreachable
array.valid.784:
  %v786 = getelementptr i64, ptr %v777, i64 %v779
  %v787 = load double, ptr %v786, align 8, !tbaa !4
  %v788 = ptrtoint ptr %a4 to i64
  %v789 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v790 = sub i64 %v789, 1
  %v791 = add nsw i64 %v788, %v790
  %v792 = inttoptr i64 %v791 to ptr
  %v793 = ptrtoint ptr %a4 to i64
  %v794 = and i64 %v793, 1
  %v795 = icmp ne i64 %v794, 0
  br i1 %v795, label %yes.796, label %no.797
yes.796:
  %v799 = ashr i64 %v793, 1
  %v800 = sitofp i64 %v799 to double
  br label %join.798
no.797:
  %v801 = call double @mlf_int_to_double(ptr %a4)
  br label %join.798
join.798:
  %v802 = phi double [ %v800, %yes.796 ], [ %v801, %no.797 ]
  %v803 = ptrtoint ptr %a3 to i64
  %v804 = and i64 %v803, 1
  %v805 = icmp ne i64 %v804, 0
  br i1 %v805, label %yes.806, label %no.807
yes.806:
  %v809 = ashr i64 %v803, 1
  %v810 = sitofp i64 %v809 to double
  br label %join.808
no.807:
  %v811 = call double @mlf_int_to_double(ptr %a3)
  br label %join.808
join.808:
  %v812 = phi double [ %v810, %yes.806 ], [ %v811, %no.807 ]
  %v813 = fadd double %v802, %v812
  %v814 = fadd double %v813, 0x3ff0000000000000
  %v815 = fmul double %v813, %v814
  %v816 = fdiv double %v815, 0x4000000000000000
  %v817 = fadd double %v816, %v802
  %v818 = fadd double %v817, 0x3ff0000000000000
  %v819 = fdiv double 0x3ff0000000000000, %v818
  %v820 = fmul double %v819, %v787
  %v821 = getelementptr i8, ptr %a5, i64 24
  %v822 = load double, ptr %v821, align 8, !tbaa !3
  %v823 = fadd double %v822, %v820
  %v824 = call ptr @mlf.numeric.14.pppppd(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %v792, double %v823)
  ret ptr %v824
tail.no.773:
  %v825 = getelementptr i8, ptr %a2, i64 24
  %v826 = load i64, ptr %v825, align 8, !tbaa !3
  %v827 = getelementptr i8, ptr %a2, i64 32
  %v828 = load ptr, ptr %v827, align 8, !tbaa !3
  %v829 = ptrtoint ptr %a3 to i64
  %v830 = ashr i64 %v829, 1
  %v831 = and i64 %v829, 1
  %v832 = icmp ne i64 %v831, 0
  %v833 = icmp ult i64 %v830, %v826
  %v834 = and i1 %v832, %v833
  br i1 %v834, label %array.valid.835, label %array.invalid.836
array.invalid.836:
  call void @mlf_bounds_failure()
  unreachable
array.valid.835:
  %v837 = getelementptr i64, ptr %v828, i64 %v830
  %v838 = getelementptr i8, ptr %a5, i64 24
  %v839 = load double, ptr %v838, align 8, !tbaa !3
  store double %v839, ptr %v837, align 8, !tbaa !4
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.code.847(ptr %env, ptr %arg) {
entry:
  %v848 = getelementptr i8, ptr %env, i64 24
  %v849 = load ptr, ptr %v848, align 8, !tbaa !3
  %v850 = getelementptr i8, ptr %env, i64 32
  %v851 = load ptr, ptr %v850, align 8, !tbaa !3
  %v852 = call ptr @mlf_prim2(i64 32, ptr %v849, ptr %v851)
  ret ptr %v852
}

define private ptr @mlf.code.873(ptr %env, ptr %arg) {
entry:
  %v874 = getelementptr i8, ptr %env, i64 24
  %v875 = load ptr, ptr %v874, align 8, !tbaa !3
  %v876 = getelementptr i8, ptr %env, i64 32
  %v877 = load ptr, ptr %v876, align 8, !tbaa !3
  %v878 = getelementptr i8, ptr %env, i64 40
  %v879 = load ptr, ptr %v878, align 8, !tbaa !3
  %v880 = getelementptr i8, ptr %env, i64 48
  %v881 = load ptr, ptr %v880, align 8, !tbaa !3
  %v882 = call ptr @mlf_force(ptr %v879)
  %v883 = call ptr @mlf_force(ptr %v877)
  %v884 = call ptr @mlf_force(ptr %v875)
  %v885 = call ptr @mlf.worker.0(ptr %v883, ptr %v884)
  %v886 = call ptr @mlf_force(ptr %v881)
  %v887 = call ptr @mlf_prim2(i64 20, ptr %v885, ptr %v886)
  %v888 = call ptr @mlf_prim2(i64 18, ptr %v882, ptr %v887)
  ret ptr %v888
}

define private ptr @mlf.code.857(ptr %env, ptr %arg) {
entry:
  %v858 = getelementptr i8, ptr %env, i64 24
  %v859 = load ptr, ptr %v858, align 8, !tbaa !3
  %v860 = getelementptr i8, ptr %env, i64 32
  %v861 = load ptr, ptr %v860, align 8, !tbaa !3
  %v862 = getelementptr i8, ptr %env, i64 40
  %v863 = load ptr, ptr %v862, align 8, !tbaa !3
  %v864 = getelementptr i8, ptr %env, i64 48
  %v865 = load ptr, ptr %v864, align 8, !tbaa !3
  %v866 = getelementptr i8, ptr %env, i64 56
  %v867 = load ptr, ptr %v866, align 8, !tbaa !3
  %v868 = getelementptr i8, ptr %env, i64 64
  %v869 = load ptr, ptr %v868, align 8, !tbaa !3
  %v870 = call ptr @mlf_force(ptr %v859)
  %v871 = call ptr @mlf_force(ptr %v867)
  %v872 = call ptr @mlf_prim2(i64 8, ptr %v871, ptr inttoptr (i64 3 to ptr))
  %v889 = call ptr @mlf_env_new(i64 4)
  %v890 = getelementptr i8, ptr %v889, i64 24
  store ptr %v865, ptr %v890, align 8, !tbaa !3
  %v891 = getelementptr i8, ptr %v889, i64 32
  store ptr %v871, ptr %v891, align 8, !tbaa !3
  %v892 = getelementptr i8, ptr %v889, i64 40
  store ptr %v869, ptr %v892, align 8, !tbaa !3
  %v893 = getelementptr i8, ptr %v889, i64 48
  store ptr %arg, ptr %v893, align 8, !tbaa !3
  %v894 = call ptr @mlf_thunk(ptr @mlf.code.873, ptr %v889)
  %v895 = call ptr @mlf_env_new(i64 6)
  %v896 = getelementptr i8, ptr %v895, i64 24
  store ptr %v870, ptr %v896, align 8, !tbaa !3
  %v897 = getelementptr i8, ptr %v895, i64 32
  store ptr %v861, ptr %v897, align 8, !tbaa !3
  %v898 = getelementptr i8, ptr %v895, i64 40
  store ptr %v863, ptr %v898, align 8, !tbaa !3
  %v899 = getelementptr i8, ptr %v895, i64 48
  store ptr %v865, ptr %v899, align 8, !tbaa !3
  %v900 = getelementptr i8, ptr %v895, i64 56
  store ptr %v872, ptr %v900, align 8, !tbaa !3
  %v901 = getelementptr i8, ptr %v895, i64 64
  store ptr %v894, ptr %v901, align 8, !tbaa !3
  %v902 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.725, ptr %v895)
  ret ptr %v902
}

define private ptr @mlf.worker.14(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5) {
entry:
  %v842 = call ptr @mlf_prim2(i64 11, ptr %a4, ptr %a0)
  %v843 = icmp eq ptr %v842, inttoptr (i64 6 to ptr)
  br i1 %v843, label %yes.844, label %no.845
yes.844:
  %v853 = call ptr @mlf_env_new(i64 2)
  %v854 = getelementptr i8, ptr %v853, i64 24
  store ptr %a1, ptr %v854, align 8, !tbaa !3
  %v855 = getelementptr i8, ptr %v853, i64 32
  store ptr %a4, ptr %v855, align 8, !tbaa !3
  %v856 = call ptr @mlf_thunk(ptr @mlf.code.847, ptr %v853)
  %v903 = call ptr @mlf_env_new(i64 6)
  %v904 = getelementptr i8, ptr %v903, i64 24
  store ptr %a0, ptr %v904, align 8, !tbaa !3
  %v905 = getelementptr i8, ptr %v903, i64 32
  store ptr %a1, ptr %v905, align 8, !tbaa !3
  %v906 = getelementptr i8, ptr %v903, i64 40
  store ptr %a2, ptr %v906, align 8, !tbaa !3
  %v907 = getelementptr i8, ptr %v903, i64 48
  store ptr %a3, ptr %v907, align 8, !tbaa !3
  %v908 = getelementptr i8, ptr %v903, i64 56
  store ptr %a4, ptr %v908, align 8, !tbaa !3
  %v909 = getelementptr i8, ptr %v903, i64 64
  store ptr %a5, ptr %v909, align 8, !tbaa !3
  %v910 = call ptr @mlf_closure(ptr @mlf.code.857, ptr %v903)
  %v911 = call ptr @mlf_prim2(i64 1, ptr %v856, ptr %v910)
  br label %join.846
no.845:
  %v912 = call ptr @mlf_prim3(i64 33, ptr %a2, ptr %a3, ptr %a5)
  br label %join.846
join.846:
  %v913 = phi ptr [ %v911, %yes.844 ], [ %v912, %no.845 ]
  ret ptr %v913
}

define private ptr @mlf.numeric.entry.725(ptr %env, ptr %arg) {
entry:
  %v726 = getelementptr i8, ptr %env, i64 24
  %v727 = load ptr, ptr %v726, align 8, !tbaa !3
  %v728 = getelementptr i8, ptr %env, i64 32
  %v729 = load ptr, ptr %v728, align 8, !tbaa !3
  %v730 = getelementptr i8, ptr %env, i64 40
  %v731 = load ptr, ptr %v730, align 8, !tbaa !3
  %v732 = getelementptr i8, ptr %env, i64 48
  %v733 = load ptr, ptr %v732, align 8, !tbaa !3
  %v734 = getelementptr i8, ptr %env, i64 56
  %v735 = load ptr, ptr %v734, align 8, !tbaa !3
  %v736 = getelementptr i8, ptr %env, i64 64
  %v737 = load ptr, ptr %v736, align 8, !tbaa !3
  %v738 = call ptr @mlf_peek(ptr %v727)
  %v739 = call ptr @mlf_peek(ptr %v729)
  %v740 = call ptr @mlf_peek(ptr %v731)
  %v741 = call ptr @mlf_peek(ptr %v733)
  %v742 = call ptr @mlf_peek(ptr %v735)
  %v743 = call ptr @mlf_peek(ptr %v737)
  %v744 = icmp ne ptr %v738, null
  %v745 = icmp ne ptr %v739, null
  %v746 = icmp ne ptr %v740, null
  %v747 = icmp ne ptr %v741, null
  %v748 = icmp ne ptr %v742, null
  %v749 = icmp ne ptr %v743, null
  %v750 = and i1 true, %v744
  %v751 = and i1 %v750, %v745
  %v752 = and i1 %v751, %v746
  %v753 = and i1 %v752, %v747
  %v754 = and i1 %v753, %v748
  %v755 = and i1 %v754, %v749
  br i1 %v755, label %yes.756, label %no.757
yes.756:
  %v840 = call ptr @mlf.numeric.14(ptr %v738, ptr %v739, ptr %v740, ptr %v741, ptr %v742, ptr %v743)
  %v841 = call ptr @mlf_prim1(i64 0, ptr %v840)
  br label %join.758
no.757:
  %v914 = call ptr @mlf_force(ptr %v727)
  %v915 = call ptr @mlf_force(ptr %v735)
  %v916 = call ptr @mlf.worker.14(ptr %v914, ptr %v729, ptr %v731, ptr %v733, ptr %v915, ptr %v737)
  br label %join.758
join.758:
  %v917 = phi ptr [ %v841, %yes.756 ], [ %v916, %no.757 ]
  ret ptr %v917
}

define private ptr @mlf.code.716(ptr %env, ptr %arg) {
entry:
  %v717 = getelementptr i8, ptr %env, i64 24
  %v718 = load ptr, ptr %v717, align 8, !tbaa !3
  %v719 = getelementptr i8, ptr %env, i64 32
  %v720 = load ptr, ptr %v719, align 8, !tbaa !3
  %v721 = getelementptr i8, ptr %env, i64 40
  %v722 = load ptr, ptr %v721, align 8, !tbaa !3
  %v723 = getelementptr i8, ptr %env, i64 48
  %v724 = load ptr, ptr %v723, align 8, !tbaa !3
  %v918 = call ptr @mlf_force(ptr %v718)
  %v919 = call ptr @mlf_double(double 0x0000000000000000)
  %v920 = call ptr @mlf_env_new(i64 6)
  %v921 = getelementptr i8, ptr %v920, i64 24
  store ptr %v918, ptr %v921, align 8, !tbaa !3
  %v922 = getelementptr i8, ptr %v920, i64 32
  store ptr %v720, ptr %v922, align 8, !tbaa !3
  %v923 = getelementptr i8, ptr %v920, i64 40
  store ptr %v722, ptr %v923, align 8, !tbaa !3
  %v924 = getelementptr i8, ptr %v920, i64 48
  store ptr %v724, ptr %v924, align 8, !tbaa !3
  %v925 = getelementptr i8, ptr %v920, i64 56
  store ptr inttoptr (i64 1 to ptr), ptr %v925, align 8, !tbaa !3
  %v926 = getelementptr i8, ptr %v920, i64 64
  store ptr %v919, ptr %v926, align 8, !tbaa !3
  %v927 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.725, ptr %v920)
  ret ptr %v927
}

define private ptr @mlf.code.934(ptr %env, ptr %arg) {
entry:
  %v935 = getelementptr i8, ptr %env, i64 24
  %v936 = load ptr, ptr %v935, align 8, !tbaa !3
  %v937 = getelementptr i8, ptr %env, i64 32
  %v938 = load ptr, ptr %v937, align 8, !tbaa !3
  %v939 = getelementptr i8, ptr %env, i64 40
  %v940 = load ptr, ptr %v939, align 8, !tbaa !3
  %v941 = getelementptr i8, ptr %env, i64 48
  %v942 = load ptr, ptr %v941, align 8, !tbaa !3
  %v943 = call ptr @mlf_force(ptr %v936)
  %v944 = call ptr @mlf_force(ptr %v942)
  %v945 = call ptr @mlf_prim2(i64 8, ptr %v944, ptr inttoptr (i64 3 to ptr))
  %v946 = call ptr @mlf_env_new(i64 4)
  %v947 = getelementptr i8, ptr %v946, i64 24
  store ptr %v943, ptr %v947, align 8, !tbaa !3
  %v948 = getelementptr i8, ptr %v946, i64 32
  store ptr %v938, ptr %v948, align 8, !tbaa !3
  %v949 = getelementptr i8, ptr %v946, i64 40
  store ptr %v940, ptr %v949, align 8, !tbaa !3
  %v950 = getelementptr i8, ptr %v946, i64 48
  store ptr %v945, ptr %v950, align 8, !tbaa !3
  %v951 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.571, ptr %v946)
  ret ptr %v951
}

define private ptr @mlf.worker.28(ptr %a0, ptr %a1, ptr %a2, ptr %a3) {
entry:
  %v711 = call ptr @mlf_prim2(i64 11, ptr %a3, ptr %a0)
  %v712 = icmp eq ptr %v711, inttoptr (i64 6 to ptr)
  br i1 %v712, label %yes.713, label %no.714
yes.713:
  %v928 = call ptr @mlf_env_new(i64 4)
  %v929 = getelementptr i8, ptr %v928, i64 24
  store ptr %a0, ptr %v929, align 8, !tbaa !3
  %v930 = getelementptr i8, ptr %v928, i64 32
  store ptr %a1, ptr %v930, align 8, !tbaa !3
  %v931 = getelementptr i8, ptr %v928, i64 40
  store ptr %a2, ptr %v931, align 8, !tbaa !3
  %v932 = getelementptr i8, ptr %v928, i64 48
  store ptr %a3, ptr %v932, align 8, !tbaa !3
  %v933 = call ptr @mlf_thunk(ptr @mlf.code.716, ptr %v928)
  %v952 = call ptr @mlf_env_new(i64 4)
  %v953 = getelementptr i8, ptr %v952, i64 24
  store ptr %a0, ptr %v953, align 8, !tbaa !3
  %v954 = getelementptr i8, ptr %v952, i64 32
  store ptr %a1, ptr %v954, align 8, !tbaa !3
  %v955 = getelementptr i8, ptr %v952, i64 40
  store ptr %a2, ptr %v955, align 8, !tbaa !3
  %v956 = getelementptr i8, ptr %v952, i64 48
  store ptr %a3, ptr %v956, align 8, !tbaa !3
  %v957 = call ptr @mlf_closure(ptr @mlf.code.934, ptr %v952)
  %v958 = call ptr @mlf_prim2(i64 1, ptr %v933, ptr %v957)
  br label %join.715
no.714:
  %v959 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.715
join.715:
  %v960 = phi ptr [ %v958, %yes.713 ], [ %v959, %no.714 ]
  ret ptr %v960
}

define private ptr @mlf.numeric.entry.571(ptr %env, ptr %arg) {
entry:
  %v572 = getelementptr i8, ptr %env, i64 24
  %v573 = load ptr, ptr %v572, align 8, !tbaa !3
  %v574 = getelementptr i8, ptr %env, i64 32
  %v575 = load ptr, ptr %v574, align 8, !tbaa !3
  %v576 = getelementptr i8, ptr %env, i64 40
  %v577 = load ptr, ptr %v576, align 8, !tbaa !3
  %v578 = getelementptr i8, ptr %env, i64 48
  %v579 = load ptr, ptr %v578, align 8, !tbaa !3
  %v580 = call ptr @mlf_peek(ptr %v573)
  %v581 = call ptr @mlf_peek(ptr %v575)
  %v582 = call ptr @mlf_peek(ptr %v577)
  %v583 = call ptr @mlf_peek(ptr %v579)
  %v584 = icmp ne ptr %v580, null
  %v585 = icmp ne ptr %v581, null
  %v586 = icmp ne ptr %v582, null
  %v587 = icmp ne ptr %v583, null
  %v588 = and i1 true, %v584
  %v589 = and i1 %v588, %v585
  %v590 = and i1 %v589, %v586
  %v591 = and i1 %v590, %v587
  br i1 %v591, label %yes.592, label %no.593
yes.592:
  %v709 = call ptr @mlf.numeric.28(ptr %v580, ptr %v581, ptr %v582, ptr %v583)
  %v710 = call ptr @mlf_prim1(i64 0, ptr %v709)
  br label %join.594
no.593:
  %v961 = call ptr @mlf_force(ptr %v573)
  %v962 = call ptr @mlf_force(ptr %v579)
  %v963 = call ptr @mlf.worker.28(ptr %v961, ptr %v575, ptr %v577, ptr %v962)
  br label %join.594
join.594:
  %v964 = phi ptr [ %v710, %yes.592 ], [ %v963, %no.593 ]
  ret ptr %v964
}

define private ptr @mlf.code.564(ptr %env, ptr %arg) {
entry:
  %v565 = getelementptr i8, ptr %env, i64 24
  %v566 = load ptr, ptr %v565, align 8, !tbaa !3
  %v567 = getelementptr i8, ptr %env, i64 32
  %v568 = load ptr, ptr %v567, align 8, !tbaa !3
  %v569 = getelementptr i8, ptr %env, i64 40
  %v570 = load ptr, ptr %v569, align 8, !tbaa !3
  %v965 = call ptr @mlf_force(ptr %v566)
  %v966 = call ptr @mlf_env_new(i64 4)
  %v967 = getelementptr i8, ptr %v966, i64 24
  store ptr %v965, ptr %v967, align 8, !tbaa !3
  %v968 = getelementptr i8, ptr %v966, i64 32
  store ptr %v570, ptr %v968, align 8, !tbaa !3
  %v969 = getelementptr i8, ptr %v966, i64 40
  store ptr %v568, ptr %v969, align 8, !tbaa !3
  %v970 = getelementptr i8, ptr %v966, i64 48
  store ptr inttoptr (i64 1 to ptr), ptr %v970, align 8, !tbaa !3
  %v971 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.571, ptr %v966)
  ret ptr %v971
}

define private ptr @mlf.worker.34(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) {
entry:
  %v558 = call ptr @mlf_env_new(i64 4)
  %v559 = getelementptr i8, ptr %v558, i64 24
  store ptr %a0, ptr %v559, align 8, !tbaa !3
  %v560 = getelementptr i8, ptr %v558, i64 32
  store ptr %a1, ptr %v560, align 8, !tbaa !3
  %v561 = getelementptr i8, ptr %v558, i64 40
  store ptr %a2, ptr %v561, align 8, !tbaa !3
  %v562 = getelementptr i8, ptr %v558, i64 48
  store ptr %a4, ptr %v562, align 8, !tbaa !3
  %v563 = call ptr @mlf_thunk(ptr @mlf.code.98, ptr %v558)
  %v972 = call ptr @mlf_env_new(i64 3)
  %v973 = getelementptr i8, ptr %v972, i64 24
  store ptr %a1, ptr %v973, align 8, !tbaa !3
  %v974 = getelementptr i8, ptr %v972, i64 32
  store ptr %a3, ptr %v974, align 8, !tbaa !3
  %v975 = getelementptr i8, ptr %v972, i64 40
  store ptr %a4, ptr %v975, align 8, !tbaa !3
  %v976 = call ptr @mlf_closure(ptr @mlf.code.564, ptr %v972)
  %v977 = call ptr @mlf_application(ptr %v563, ptr %v976)
  %v978 = call ptr @mlf_force(ptr %v977)
  ret ptr %v978
}

define private ptr @mlf.code.89(ptr %env, ptr %arg) {
entry:
  %v90 = getelementptr i8, ptr %env, i64 24
  %v91 = load ptr, ptr %v90, align 8, !tbaa !3
  %v92 = getelementptr i8, ptr %env, i64 32
  %v93 = load ptr, ptr %v92, align 8, !tbaa !3
  %v94 = getelementptr i8, ptr %env, i64 40
  %v95 = load ptr, ptr %v94, align 8, !tbaa !3
  %v96 = getelementptr i8, ptr %env, i64 48
  %v97 = load ptr, ptr %v96, align 8, !tbaa !3
  %v979 = call ptr @mlf_primitive(i64 0)
  %v980 = call ptr @mlf_primitive(i64 1)
  %v981 = call ptr @mlf_constructor2(i64 1, ptr %v979, ptr %v980)
  %v982 = call ptr @mlf.worker.34(ptr %v981, ptr %v91, ptr %v93, ptr %v95, ptr %v97)
  ret ptr %v982
}

define private ptr @mlf.code.1000(ptr %env, ptr %arg) {
entry:
  %v1001 = getelementptr i8, ptr %env, i64 24
  %v1002 = load ptr, ptr %v1001, align 8, !tbaa !3
  %v1003 = getelementptr i8, ptr %env, i64 32
  %v1004 = load ptr, ptr %v1003, align 8, !tbaa !3
  %v1005 = getelementptr i8, ptr %env, i64 40
  %v1006 = load ptr, ptr %v1005, align 8, !tbaa !3
  %v1007 = getelementptr i8, ptr %env, i64 48
  %v1008 = load ptr, ptr %v1007, align 8, !tbaa !3
  %v1009 = call ptr @mlf_primitive(i64 0)
  %v1010 = call ptr @mlf_primitive(i64 1)
  %v1011 = call ptr @mlf_constructor2(i64 1, ptr %v1009, ptr %v1010)
  %v1012 = call ptr @mlf.worker.34(ptr %v1011, ptr %v1002, ptr %v1006, ptr %v1004, ptr %v1008)
  ret ptr %v1012
}

define private ptr @mlf.code.1019(ptr %env, ptr %arg) {
entry:
  %v1020 = getelementptr i8, ptr %env, i64 24
  %v1021 = load ptr, ptr %v1020, align 8, !tbaa !3
  %v1022 = getelementptr i8, ptr %env, i64 32
  %v1023 = load ptr, ptr %v1022, align 8, !tbaa !3
  %v1024 = getelementptr i8, ptr %env, i64 40
  %v1025 = load ptr, ptr %v1024, align 8, !tbaa !3
  %v1026 = getelementptr i8, ptr %env, i64 48
  %v1027 = load ptr, ptr %v1026, align 8, !tbaa !3
  %v1028 = getelementptr i8, ptr %env, i64 56
  %v1029 = load ptr, ptr %v1028, align 8, !tbaa !3
  %v1030 = call ptr @mlf_force(ptr %v1029)
  %v1031 = ptrtoint ptr %v1030 to i64
  %v1032 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1033 = and i64 %v1031, %v1032
  %v1034 = and i64 %v1033, 1
  %v1035 = icmp ne i64 %v1034, 0
  br i1 %v1035, label %yes.1036, label %no.1037
yes.1036:
  %v1039 = sub i64 %v1032, 1
  %v1040 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v1031, i64 %v1039)
  %v1041 = extractvalue { i64, i1 } %v1040, 0
  %v1042 = extractvalue { i64, i1 } %v1040, 1
  br i1 %v1042, label %yes.1043, label %no.1044
yes.1043:
  %v1046 = call ptr @mlf_sub_int(ptr %v1030, ptr inttoptr (i64 3 to ptr))
  br label %join.1045
no.1044:
  %v1047 = inttoptr i64 %v1041 to ptr
  br label %join.1045
join.1045:
  %v1048 = phi ptr [ %v1046, %yes.1043 ], [ %v1047, %no.1044 ]
  br label %join.1038
no.1037:
  %v1049 = call ptr @mlf_sub_int(ptr %v1030, ptr inttoptr (i64 3 to ptr))
  br label %join.1038
join.1038:
  %v1050 = phi ptr [ %v1048, %join.1045 ], [ %v1049, %no.1037 ]
  %v1051 = call ptr @mlf.worker.42(ptr %v1021, ptr %v1023, ptr %v1025, ptr %v1027, ptr %v1050)
  ret ptr %v1051
}

define private ptr @mlf.code.989(ptr %env, ptr %arg) {
entry:
  %v990 = getelementptr i8, ptr %env, i64 24
  %v991 = load ptr, ptr %v990, align 8, !tbaa !3
  %v992 = getelementptr i8, ptr %env, i64 32
  %v993 = load ptr, ptr %v992, align 8, !tbaa !3
  %v994 = getelementptr i8, ptr %env, i64 40
  %v995 = load ptr, ptr %v994, align 8, !tbaa !3
  %v996 = getelementptr i8, ptr %env, i64 48
  %v997 = load ptr, ptr %v996, align 8, !tbaa !3
  %v998 = getelementptr i8, ptr %env, i64 56
  %v999 = load ptr, ptr %v998, align 8, !tbaa !3
  %v1013 = call ptr @mlf_env_new(i64 4)
  %v1014 = getelementptr i8, ptr %v1013, i64 24
  store ptr %v991, ptr %v1014, align 8, !tbaa !3
  %v1015 = getelementptr i8, ptr %v1013, i64 32
  store ptr %v993, ptr %v1015, align 8, !tbaa !3
  %v1016 = getelementptr i8, ptr %v1013, i64 40
  store ptr %v995, ptr %v1016, align 8, !tbaa !3
  %v1017 = getelementptr i8, ptr %v1013, i64 48
  store ptr %v997, ptr %v1017, align 8, !tbaa !3
  %v1018 = call ptr @mlf_thunk(ptr @mlf.code.1000, ptr %v1013)
  %v1052 = call ptr @mlf_env_new(i64 5)
  %v1053 = getelementptr i8, ptr %v1052, i64 24
  store ptr %v991, ptr %v1053, align 8, !tbaa !3
  %v1054 = getelementptr i8, ptr %v1052, i64 32
  store ptr %v993, ptr %v1054, align 8, !tbaa !3
  %v1055 = getelementptr i8, ptr %v1052, i64 40
  store ptr %v995, ptr %v1055, align 8, !tbaa !3
  %v1056 = getelementptr i8, ptr %v1052, i64 48
  store ptr %v997, ptr %v1056, align 8, !tbaa !3
  %v1057 = getelementptr i8, ptr %v1052, i64 56
  store ptr %v999, ptr %v1057, align 8, !tbaa !3
  %v1058 = call ptr @mlf_closure(ptr @mlf.code.1019, ptr %v1052)
  %v1059 = call ptr @mlf_prim2(i64 1, ptr %v1018, ptr %v1058)
  ret ptr %v1059
}

define private ptr @mlf.worker.42(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) {
entry:
  %v72 = ptrtoint ptr %a4 to i64
  %v73 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v74 = and i64 %v72, %v73
  %v75 = and i64 %v74, 1
  %v76 = icmp ne i64 %v75, 0
  br i1 %v76, label %yes.77, label %no.78
yes.77:
  %v80 = icmp eq i64 %v72, %v73
  %v81 = select i1 %v80, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.79
no.78:
  %v82 = call ptr @mlf_eq_int(ptr %a4, ptr inttoptr (i64 1 to ptr))
  br label %join.79
join.79:
  %v83 = phi ptr [ %v81, %yes.77 ], [ %v82, %no.78 ]
  %v84 = icmp eq ptr %v83, inttoptr (i64 6 to ptr)
  br i1 %v84, label %yes.85, label %no.86
yes.85:
  %v88 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.87
no.86:
  %v983 = call ptr @mlf_env_new(i64 4)
  %v984 = getelementptr i8, ptr %v983, i64 24
  store ptr %a0, ptr %v984, align 8, !tbaa !3
  %v985 = getelementptr i8, ptr %v983, i64 32
  store ptr %a1, ptr %v985, align 8, !tbaa !3
  %v986 = getelementptr i8, ptr %v983, i64 40
  store ptr %a2, ptr %v986, align 8, !tbaa !3
  %v987 = getelementptr i8, ptr %v983, i64 48
  store ptr %a3, ptr %v987, align 8, !tbaa !3
  %v988 = call ptr @mlf_thunk(ptr @mlf.code.89, ptr %v983)
  %v1060 = call ptr @mlf_env_new(i64 5)
  %v1061 = getelementptr i8, ptr %v1060, i64 24
  store ptr %a0, ptr %v1061, align 8, !tbaa !3
  %v1062 = getelementptr i8, ptr %v1060, i64 32
  store ptr %a1, ptr %v1062, align 8, !tbaa !3
  %v1063 = getelementptr i8, ptr %v1060, i64 40
  store ptr %a2, ptr %v1063, align 8, !tbaa !3
  %v1064 = getelementptr i8, ptr %v1060, i64 48
  store ptr %a3, ptr %v1064, align 8, !tbaa !3
  %v1065 = getelementptr i8, ptr %v1060, i64 56
  store ptr %a4, ptr %v1065, align 8, !tbaa !3
  %v1066 = call ptr @mlf_closure(ptr @mlf.code.989, ptr %v1060)
  %v1067 = call ptr @mlf_prim2(i64 1, ptr %v988, ptr %v1066)
  br label %join.87
join.87:
  %v1068 = phi ptr [ %v88, %yes.85 ], [ %v1067, %no.86 ]
  ret ptr %v1068
}

define private ptr @mlf.code.63(ptr %env, ptr %arg) {
entry:
  %v64 = getelementptr i8, ptr %env, i64 24
  %v65 = load ptr, ptr %v64, align 8, !tbaa !3
  %v66 = getelementptr i8, ptr %env, i64 32
  %v67 = load ptr, ptr %v66, align 8, !tbaa !3
  %v68 = getelementptr i8, ptr %env, i64 40
  %v69 = load ptr, ptr %v68, align 8, !tbaa !3
  %v70 = getelementptr i8, ptr %env, i64 48
  %v71 = load ptr, ptr %v70, align 8, !tbaa !3
  %v1069 = call ptr @mlf.worker.42(ptr %v65, ptr %v67, ptr %v69, ptr %v71, ptr inttoptr (i64 21 to ptr))
  ret ptr %v1069
}

define private ptr @mlf.numeric.50(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) alwaysinline {
entry:
  %v1123 = ptrtoint ptr %a4 to i64
  %v1124 = ptrtoint ptr %a0 to i64
  %v1125 = and i64 %v1123, %v1124
  %v1126 = and i64 %v1125, 1
  %v1127 = icmp ne i64 %v1126, 0
  br i1 %v1127, label %yes.1128, label %no.1129
yes.1128:
  %v1131 = icmp slt i64 %v1123, %v1124
  %v1132 = select i1 %v1131, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1130
no.1129:
  %v1133 = call ptr @mlf_lt_int(ptr %a4, ptr %a0)
  br label %join.1130
join.1130:
  %v1134 = phi ptr [ %v1132, %yes.1128 ], [ %v1133, %no.1129 ]
  %v1135 = icmp eq ptr %v1134, inttoptr (i64 6 to ptr)
  br i1 %v1135, label %tail.yes.1136, label %tail.no.1137
tail.yes.1136:
  %v1138 = getelementptr i8, ptr %a1, i64 24
  %v1139 = load i64, ptr %v1138, align 8, !tbaa !3
  %v1140 = getelementptr i8, ptr %a1, i64 32
  %v1141 = load ptr, ptr %v1140, align 8, !tbaa !3
  %v1142 = ptrtoint ptr %a4 to i64
  %v1143 = ashr i64 %v1142, 1
  %v1144 = and i64 %v1142, 1
  %v1145 = icmp ne i64 %v1144, 0
  %v1146 = icmp ult i64 %v1143, %v1139
  %v1147 = and i1 %v1145, %v1146
  br i1 %v1147, label %array.valid.1148, label %array.invalid.1149
array.invalid.1149:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1148:
  %v1150 = getelementptr i64, ptr %v1141, i64 %v1143
  %v1151 = load double, ptr %v1150, align 8, !tbaa !4
  %v1152 = getelementptr i8, ptr %a2, i64 24
  %v1153 = load i64, ptr %v1152, align 8, !tbaa !3
  %v1154 = getelementptr i8, ptr %a2, i64 32
  %v1155 = load ptr, ptr %v1154, align 8, !tbaa !3
  %v1156 = ptrtoint ptr %a4 to i64
  %v1157 = ashr i64 %v1156, 1
  %v1158 = and i64 %v1156, 1
  %v1159 = icmp ne i64 %v1158, 0
  %v1160 = icmp ult i64 %v1157, %v1153
  %v1161 = and i1 %v1159, %v1160
  br i1 %v1161, label %array.valid.1162, label %array.invalid.1163
array.invalid.1163:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1162:
  %v1164 = getelementptr i64, ptr %v1155, i64 %v1157
  %v1165 = load double, ptr %v1164, align 8, !tbaa !4
  %v1166 = getelementptr i8, ptr %a3, i64 24
  %v1167 = load i64, ptr %v1166, align 8, !tbaa !3
  %v1168 = getelementptr i8, ptr %a3, i64 32
  %v1169 = load ptr, ptr %v1168, align 8, !tbaa !3
  %v1170 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v1171 = ashr i64 %v1170, 1
  %v1172 = and i64 %v1170, 1
  %v1173 = icmp ne i64 %v1172, 0
  %v1174 = icmp ult i64 %v1171, %v1167
  %v1175 = and i1 %v1173, %v1174
  br i1 %v1175, label %array.valid.1176, label %array.invalid.1177
array.invalid.1177:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1176:
  %v1178 = getelementptr i64, ptr %v1169, i64 %v1171
  %v1179 = load double, ptr %v1178, align 8, !tbaa !4
  %v1180 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1181 = ashr i64 %v1180, 1
  %v1182 = and i64 %v1180, 1
  %v1183 = icmp ne i64 %v1182, 0
  %v1184 = icmp ult i64 %v1181, %v1167
  %v1185 = and i1 %v1183, %v1184
  br i1 %v1185, label %array.valid.1186, label %array.invalid.1187
array.invalid.1187:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1186:
  %v1188 = getelementptr i64, ptr %v1169, i64 %v1181
  %v1189 = load double, ptr %v1188, align 8, !tbaa !4
  %v1190 = fmul double %v1151, %v1165
  %v1191 = fadd double %v1179, %v1190
  %v1192 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v1193 = ashr i64 %v1192, 1
  %v1194 = and i64 %v1192, 1
  %v1195 = icmp ne i64 %v1194, 0
  %v1196 = icmp ult i64 %v1193, %v1167
  %v1197 = and i1 %v1195, %v1196
  br i1 %v1197, label %array.valid.1198, label %array.invalid.1199
array.invalid.1199:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1198:
  %v1200 = getelementptr i64, ptr %v1169, i64 %v1193
  store double %v1191, ptr %v1200, align 8, !tbaa !4
  %v1201 = fmul double %v1165, %v1165
  %v1202 = fadd double %v1189, %v1201
  %v1203 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1204 = ashr i64 %v1203, 1
  %v1205 = and i64 %v1203, 1
  %v1206 = icmp ne i64 %v1205, 0
  %v1207 = icmp ult i64 %v1204, %v1167
  %v1208 = and i1 %v1206, %v1207
  br i1 %v1208, label %array.valid.1209, label %array.invalid.1210
array.invalid.1210:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1209:
  %v1211 = getelementptr i64, ptr %v1169, i64 %v1204
  store double %v1202, ptr %v1211, align 8, !tbaa !4
  %v1212 = ptrtoint ptr %a4 to i64
  %v1213 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1214 = sub i64 %v1213, 1
  %v1215 = add nsw i64 %v1212, %v1214
  %v1216 = inttoptr i64 %v1215 to ptr
  %v1217 = musttail call ptr @mlf.numeric.50(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %v1216)
  ret ptr %v1217
tail.no.1137:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.code.1225(ptr %env, ptr %arg) {
entry:
  %v1226 = getelementptr i8, ptr %env, i64 24
  %v1227 = load ptr, ptr %v1226, align 8, !tbaa !3
  %v1228 = getelementptr i8, ptr %env, i64 32
  %v1229 = load ptr, ptr %v1228, align 8, !tbaa !3
  %v1230 = call ptr @mlf_prim2(i64 32, ptr %v1227, ptr %v1229)
  ret ptr %v1230
}

define private ptr @mlf.code.1246(ptr %env, ptr %arg) {
entry:
  %v1247 = getelementptr i8, ptr %env, i64 24
  %v1248 = load ptr, ptr %v1247, align 8, !tbaa !3
  %v1249 = getelementptr i8, ptr %env, i64 32
  %v1250 = load ptr, ptr %v1249, align 8, !tbaa !3
  %v1251 = call ptr @mlf_prim2(i64 32, ptr %v1248, ptr %v1250)
  ret ptr %v1251
}

define private ptr @mlf.code.1269(ptr %env, ptr %arg) {
entry:
  %v1270 = getelementptr i8, ptr %env, i64 24
  %v1271 = load ptr, ptr %v1270, align 8, !tbaa !3
  %v1272 = call ptr @mlf_prim2(i64 32, ptr %v1271, ptr inttoptr (i64 1 to ptr))
  ret ptr %v1272
}

define private ptr @mlf.code.1291(ptr %env, ptr %arg) {
entry:
  %v1292 = getelementptr i8, ptr %env, i64 24
  %v1293 = load ptr, ptr %v1292, align 8, !tbaa !3
  %v1294 = call ptr @mlf_prim2(i64 32, ptr %v1293, ptr inttoptr (i64 3 to ptr))
  ret ptr %v1294
}

define private ptr @mlf.code.1324(ptr %env, ptr %arg) {
entry:
  %v1325 = getelementptr i8, ptr %env, i64 24
  %v1326 = load ptr, ptr %v1325, align 8, !tbaa !3
  %v1327 = getelementptr i8, ptr %env, i64 32
  %v1328 = load ptr, ptr %v1327, align 8, !tbaa !3
  %v1329 = getelementptr i8, ptr %env, i64 40
  %v1330 = load ptr, ptr %v1329, align 8, !tbaa !3
  %v1331 = call ptr @mlf_force(ptr %v1330)
  %v1332 = call ptr @mlf_force(ptr %v1326)
  %v1333 = call ptr @mlf_force(ptr %v1328)
  %v1334 = call ptr @mlf_prim2(i64 20, ptr %v1332, ptr %v1333)
  %v1335 = call ptr @mlf_prim2(i64 18, ptr %v1331, ptr %v1334)
  ret ptr %v1335
}

define private ptr @mlf.code.1315(ptr %env, ptr %arg) {
entry:
  %v1316 = getelementptr i8, ptr %env, i64 24
  %v1317 = load ptr, ptr %v1316, align 8, !tbaa !3
  %v1318 = getelementptr i8, ptr %env, i64 32
  %v1319 = load ptr, ptr %v1318, align 8, !tbaa !3
  %v1320 = getelementptr i8, ptr %env, i64 40
  %v1321 = load ptr, ptr %v1320, align 8, !tbaa !3
  %v1322 = getelementptr i8, ptr %env, i64 48
  %v1323 = load ptr, ptr %v1322, align 8, !tbaa !3
  %v1336 = call ptr @mlf_env_new(i64 3)
  %v1337 = getelementptr i8, ptr %v1336, i64 24
  store ptr %v1319, ptr %v1337, align 8, !tbaa !3
  %v1338 = getelementptr i8, ptr %v1336, i64 32
  store ptr %v1321, ptr %v1338, align 8, !tbaa !3
  %v1339 = getelementptr i8, ptr %v1336, i64 40
  store ptr %v1323, ptr %v1339, align 8, !tbaa !3
  %v1340 = call ptr @mlf_thunk(ptr @mlf.code.1324, ptr %v1336)
  %v1341 = call ptr @mlf_prim3(i64 33, ptr %v1317, ptr inttoptr (i64 1 to ptr), ptr %v1340)
  ret ptr %v1341
}

define private ptr @mlf.code.1370(ptr %env, ptr %arg) {
entry:
  %v1371 = getelementptr i8, ptr %env, i64 24
  %v1372 = load ptr, ptr %v1371, align 8, !tbaa !3
  %v1373 = getelementptr i8, ptr %env, i64 32
  %v1374 = load ptr, ptr %v1373, align 8, !tbaa !3
  %v1375 = call ptr @mlf_force(ptr %v1374)
  %v1376 = call ptr @mlf_force(ptr %v1372)
  %v1377 = call ptr @mlf_prim2(i64 20, ptr %v1376, ptr %v1376)
  %v1378 = call ptr @mlf_prim2(i64 18, ptr %v1375, ptr %v1377)
  ret ptr %v1378
}

define private ptr @mlf.code.1363(ptr %env, ptr %arg) {
entry:
  %v1364 = getelementptr i8, ptr %env, i64 24
  %v1365 = load ptr, ptr %v1364, align 8, !tbaa !3
  %v1366 = getelementptr i8, ptr %env, i64 32
  %v1367 = load ptr, ptr %v1366, align 8, !tbaa !3
  %v1368 = getelementptr i8, ptr %env, i64 40
  %v1369 = load ptr, ptr %v1368, align 8, !tbaa !3
  %v1379 = call ptr @mlf_env_new(i64 2)
  %v1380 = getelementptr i8, ptr %v1379, i64 24
  store ptr %v1367, ptr %v1380, align 8, !tbaa !3
  %v1381 = getelementptr i8, ptr %v1379, i64 32
  store ptr %v1369, ptr %v1381, align 8, !tbaa !3
  %v1382 = call ptr @mlf_thunk(ptr @mlf.code.1370, ptr %v1379)
  %v1383 = call ptr @mlf_prim3(i64 33, ptr %v1365, ptr inttoptr (i64 3 to ptr), ptr %v1382)
  ret ptr %v1383
}

define private ptr @mlf.code.1389(ptr %env, ptr %arg) {
entry:
  %v1390 = getelementptr i8, ptr %env, i64 24
  %v1391 = load ptr, ptr %v1390, align 8, !tbaa !3
  %v1392 = getelementptr i8, ptr %env, i64 32
  %v1393 = load ptr, ptr %v1392, align 8, !tbaa !3
  %v1394 = getelementptr i8, ptr %env, i64 40
  %v1395 = load ptr, ptr %v1394, align 8, !tbaa !3
  %v1396 = getelementptr i8, ptr %env, i64 48
  %v1397 = load ptr, ptr %v1396, align 8, !tbaa !3
  %v1398 = getelementptr i8, ptr %env, i64 56
  %v1399 = load ptr, ptr %v1398, align 8, !tbaa !3
  %v1400 = call ptr @mlf_force(ptr %v1391)
  %v1401 = call ptr @mlf_force(ptr %v1399)
  %v1402 = call ptr @mlf_prim2(i64 8, ptr %v1401, ptr inttoptr (i64 3 to ptr))
  %v1403 = call ptr @mlf_env_new(i64 5)
  %v1404 = getelementptr i8, ptr %v1403, i64 24
  store ptr %v1400, ptr %v1404, align 8, !tbaa !3
  %v1405 = getelementptr i8, ptr %v1403, i64 32
  store ptr %v1393, ptr %v1405, align 8, !tbaa !3
  %v1406 = getelementptr i8, ptr %v1403, i64 40
  store ptr %v1395, ptr %v1406, align 8, !tbaa !3
  %v1407 = getelementptr i8, ptr %v1403, i64 48
  store ptr %v1397, ptr %v1407, align 8, !tbaa !3
  %v1408 = getelementptr i8, ptr %v1403, i64 56
  store ptr %v1402, ptr %v1408, align 8, !tbaa !3
  %v1409 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1094, ptr %v1403)
  ret ptr %v1409
}

define private ptr @mlf.code.1348(ptr %env, ptr %arg) {
entry:
  %v1349 = getelementptr i8, ptr %env, i64 24
  %v1350 = load ptr, ptr %v1349, align 8, !tbaa !3
  %v1351 = getelementptr i8, ptr %env, i64 32
  %v1352 = load ptr, ptr %v1351, align 8, !tbaa !3
  %v1353 = getelementptr i8, ptr %env, i64 40
  %v1354 = load ptr, ptr %v1353, align 8, !tbaa !3
  %v1355 = getelementptr i8, ptr %env, i64 48
  %v1356 = load ptr, ptr %v1355, align 8, !tbaa !3
  %v1357 = getelementptr i8, ptr %env, i64 56
  %v1358 = load ptr, ptr %v1357, align 8, !tbaa !3
  %v1359 = getelementptr i8, ptr %env, i64 64
  %v1360 = load ptr, ptr %v1359, align 8, !tbaa !3
  %v1361 = getelementptr i8, ptr %env, i64 72
  %v1362 = load ptr, ptr %v1361, align 8, !tbaa !3
  %v1384 = call ptr @mlf_env_new(i64 3)
  %v1385 = getelementptr i8, ptr %v1384, i64 24
  store ptr %v1356, ptr %v1385, align 8, !tbaa !3
  %v1386 = getelementptr i8, ptr %v1384, i64 32
  store ptr %v1360, ptr %v1386, align 8, !tbaa !3
  %v1387 = getelementptr i8, ptr %v1384, i64 40
  store ptr %v1362, ptr %v1387, align 8, !tbaa !3
  %v1388 = call ptr @mlf_thunk(ptr @mlf.code.1363, ptr %v1384)
  %v1410 = call ptr @mlf_env_new(i64 5)
  %v1411 = getelementptr i8, ptr %v1410, i64 24
  store ptr %v1350, ptr %v1411, align 8, !tbaa !3
  %v1412 = getelementptr i8, ptr %v1410, i64 32
  store ptr %v1352, ptr %v1412, align 8, !tbaa !3
  %v1413 = getelementptr i8, ptr %v1410, i64 40
  store ptr %v1354, ptr %v1413, align 8, !tbaa !3
  %v1414 = getelementptr i8, ptr %v1410, i64 48
  store ptr %v1356, ptr %v1414, align 8, !tbaa !3
  %v1415 = getelementptr i8, ptr %v1410, i64 56
  store ptr %v1358, ptr %v1415, align 8, !tbaa !3
  %v1416 = call ptr @mlf_closure(ptr @mlf.code.1389, ptr %v1410)
  %v1417 = call ptr @mlf_prim2(i64 1, ptr %v1388, ptr %v1416)
  ret ptr %v1417
}

define private ptr @mlf.code.1298(ptr %env, ptr %arg) {
entry:
  %v1299 = getelementptr i8, ptr %env, i64 24
  %v1300 = load ptr, ptr %v1299, align 8, !tbaa !3
  %v1301 = getelementptr i8, ptr %env, i64 32
  %v1302 = load ptr, ptr %v1301, align 8, !tbaa !3
  %v1303 = getelementptr i8, ptr %env, i64 40
  %v1304 = load ptr, ptr %v1303, align 8, !tbaa !3
  %v1305 = getelementptr i8, ptr %env, i64 48
  %v1306 = load ptr, ptr %v1305, align 8, !tbaa !3
  %v1307 = getelementptr i8, ptr %env, i64 56
  %v1308 = load ptr, ptr %v1307, align 8, !tbaa !3
  %v1309 = getelementptr i8, ptr %env, i64 64
  %v1310 = load ptr, ptr %v1309, align 8, !tbaa !3
  %v1311 = getelementptr i8, ptr %env, i64 72
  %v1312 = load ptr, ptr %v1311, align 8, !tbaa !3
  %v1313 = getelementptr i8, ptr %env, i64 80
  %v1314 = load ptr, ptr %v1313, align 8, !tbaa !3
  %v1342 = call ptr @mlf_env_new(i64 4)
  %v1343 = getelementptr i8, ptr %v1342, i64 24
  store ptr %v1306, ptr %v1343, align 8, !tbaa !3
  %v1344 = getelementptr i8, ptr %v1342, i64 32
  store ptr %v1310, ptr %v1344, align 8, !tbaa !3
  %v1345 = getelementptr i8, ptr %v1342, i64 40
  store ptr %v1312, ptr %v1345, align 8, !tbaa !3
  %v1346 = getelementptr i8, ptr %v1342, i64 48
  store ptr %v1314, ptr %v1346, align 8, !tbaa !3
  %v1347 = call ptr @mlf_thunk(ptr @mlf.code.1315, ptr %v1342)
  %v1418 = call ptr @mlf_env_new(i64 7)
  %v1419 = getelementptr i8, ptr %v1418, i64 24
  store ptr %v1300, ptr %v1419, align 8, !tbaa !3
  %v1420 = getelementptr i8, ptr %v1418, i64 32
  store ptr %v1302, ptr %v1420, align 8, !tbaa !3
  %v1421 = getelementptr i8, ptr %v1418, i64 40
  store ptr %v1304, ptr %v1421, align 8, !tbaa !3
  %v1422 = getelementptr i8, ptr %v1418, i64 48
  store ptr %v1306, ptr %v1422, align 8, !tbaa !3
  %v1423 = getelementptr i8, ptr %v1418, i64 56
  store ptr %v1308, ptr %v1423, align 8, !tbaa !3
  %v1424 = getelementptr i8, ptr %v1418, i64 64
  store ptr %v1312, ptr %v1424, align 8, !tbaa !3
  %v1425 = getelementptr i8, ptr %v1418, i64 72
  store ptr %arg, ptr %v1425, align 8, !tbaa !3
  %v1426 = call ptr @mlf_closure(ptr @mlf.code.1348, ptr %v1418)
  %v1427 = call ptr @mlf_prim2(i64 1, ptr %v1347, ptr %v1426)
  ret ptr %v1427
}

define private ptr @mlf.code.1276(ptr %env, ptr %arg) {
entry:
  %v1277 = getelementptr i8, ptr %env, i64 24
  %v1278 = load ptr, ptr %v1277, align 8, !tbaa !3
  %v1279 = getelementptr i8, ptr %env, i64 32
  %v1280 = load ptr, ptr %v1279, align 8, !tbaa !3
  %v1281 = getelementptr i8, ptr %env, i64 40
  %v1282 = load ptr, ptr %v1281, align 8, !tbaa !3
  %v1283 = getelementptr i8, ptr %env, i64 48
  %v1284 = load ptr, ptr %v1283, align 8, !tbaa !3
  %v1285 = getelementptr i8, ptr %env, i64 56
  %v1286 = load ptr, ptr %v1285, align 8, !tbaa !3
  %v1287 = getelementptr i8, ptr %env, i64 64
  %v1288 = load ptr, ptr %v1287, align 8, !tbaa !3
  %v1289 = getelementptr i8, ptr %env, i64 72
  %v1290 = load ptr, ptr %v1289, align 8, !tbaa !3
  %v1295 = call ptr @mlf_env_new(i64 1)
  %v1296 = getelementptr i8, ptr %v1295, i64 24
  store ptr %v1284, ptr %v1296, align 8, !tbaa !3
  %v1297 = call ptr @mlf_thunk(ptr @mlf.code.1291, ptr %v1295)
  %v1428 = call ptr @mlf_env_new(i64 8)
  %v1429 = getelementptr i8, ptr %v1428, i64 24
  store ptr %v1278, ptr %v1429, align 8, !tbaa !3
  %v1430 = getelementptr i8, ptr %v1428, i64 32
  store ptr %v1280, ptr %v1430, align 8, !tbaa !3
  %v1431 = getelementptr i8, ptr %v1428, i64 40
  store ptr %v1282, ptr %v1431, align 8, !tbaa !3
  %v1432 = getelementptr i8, ptr %v1428, i64 48
  store ptr %v1284, ptr %v1432, align 8, !tbaa !3
  %v1433 = getelementptr i8, ptr %v1428, i64 56
  store ptr %v1286, ptr %v1433, align 8, !tbaa !3
  %v1434 = getelementptr i8, ptr %v1428, i64 64
  store ptr %v1288, ptr %v1434, align 8, !tbaa !3
  %v1435 = getelementptr i8, ptr %v1428, i64 72
  store ptr %v1290, ptr %v1435, align 8, !tbaa !3
  %v1436 = getelementptr i8, ptr %v1428, i64 80
  store ptr %arg, ptr %v1436, align 8, !tbaa !3
  %v1437 = call ptr @mlf_closure(ptr @mlf.code.1298, ptr %v1428)
  %v1438 = call ptr @mlf_prim2(i64 1, ptr %v1297, ptr %v1437)
  ret ptr %v1438
}

define private ptr @mlf.code.1256(ptr %env, ptr %arg) {
entry:
  %v1257 = getelementptr i8, ptr %env, i64 24
  %v1258 = load ptr, ptr %v1257, align 8, !tbaa !3
  %v1259 = getelementptr i8, ptr %env, i64 32
  %v1260 = load ptr, ptr %v1259, align 8, !tbaa !3
  %v1261 = getelementptr i8, ptr %env, i64 40
  %v1262 = load ptr, ptr %v1261, align 8, !tbaa !3
  %v1263 = getelementptr i8, ptr %env, i64 48
  %v1264 = load ptr, ptr %v1263, align 8, !tbaa !3
  %v1265 = getelementptr i8, ptr %env, i64 56
  %v1266 = load ptr, ptr %v1265, align 8, !tbaa !3
  %v1267 = getelementptr i8, ptr %env, i64 64
  %v1268 = load ptr, ptr %v1267, align 8, !tbaa !3
  %v1273 = call ptr @mlf_env_new(i64 1)
  %v1274 = getelementptr i8, ptr %v1273, i64 24
  store ptr %v1264, ptr %v1274, align 8, !tbaa !3
  %v1275 = call ptr @mlf_thunk(ptr @mlf.code.1269, ptr %v1273)
  %v1439 = call ptr @mlf_env_new(i64 7)
  %v1440 = getelementptr i8, ptr %v1439, i64 24
  store ptr %v1258, ptr %v1440, align 8, !tbaa !3
  %v1441 = getelementptr i8, ptr %v1439, i64 32
  store ptr %v1260, ptr %v1441, align 8, !tbaa !3
  %v1442 = getelementptr i8, ptr %v1439, i64 40
  store ptr %v1262, ptr %v1442, align 8, !tbaa !3
  %v1443 = getelementptr i8, ptr %v1439, i64 48
  store ptr %v1264, ptr %v1443, align 8, !tbaa !3
  %v1444 = getelementptr i8, ptr %v1439, i64 56
  store ptr %v1266, ptr %v1444, align 8, !tbaa !3
  %v1445 = getelementptr i8, ptr %v1439, i64 64
  store ptr %v1268, ptr %v1445, align 8, !tbaa !3
  %v1446 = getelementptr i8, ptr %v1439, i64 72
  store ptr %arg, ptr %v1446, align 8, !tbaa !3
  %v1447 = call ptr @mlf_closure(ptr @mlf.code.1276, ptr %v1439)
  %v1448 = call ptr @mlf_prim2(i64 1, ptr %v1275, ptr %v1447)
  ret ptr %v1448
}

define private ptr @mlf.code.1235(ptr %env, ptr %arg) {
entry:
  %v1236 = getelementptr i8, ptr %env, i64 24
  %v1237 = load ptr, ptr %v1236, align 8, !tbaa !3
  %v1238 = getelementptr i8, ptr %env, i64 32
  %v1239 = load ptr, ptr %v1238, align 8, !tbaa !3
  %v1240 = getelementptr i8, ptr %env, i64 40
  %v1241 = load ptr, ptr %v1240, align 8, !tbaa !3
  %v1242 = getelementptr i8, ptr %env, i64 48
  %v1243 = load ptr, ptr %v1242, align 8, !tbaa !3
  %v1244 = getelementptr i8, ptr %env, i64 56
  %v1245 = load ptr, ptr %v1244, align 8, !tbaa !3
  %v1252 = call ptr @mlf_env_new(i64 2)
  %v1253 = getelementptr i8, ptr %v1252, i64 24
  store ptr %v1241, ptr %v1253, align 8, !tbaa !3
  %v1254 = getelementptr i8, ptr %v1252, i64 32
  store ptr %v1245, ptr %v1254, align 8, !tbaa !3
  %v1255 = call ptr @mlf_thunk(ptr @mlf.code.1246, ptr %v1252)
  %v1449 = call ptr @mlf_env_new(i64 6)
  %v1450 = getelementptr i8, ptr %v1449, i64 24
  store ptr %v1237, ptr %v1450, align 8, !tbaa !3
  %v1451 = getelementptr i8, ptr %v1449, i64 32
  store ptr %v1239, ptr %v1451, align 8, !tbaa !3
  %v1452 = getelementptr i8, ptr %v1449, i64 40
  store ptr %v1241, ptr %v1452, align 8, !tbaa !3
  %v1453 = getelementptr i8, ptr %v1449, i64 48
  store ptr %v1243, ptr %v1453, align 8, !tbaa !3
  %v1454 = getelementptr i8, ptr %v1449, i64 56
  store ptr %v1245, ptr %v1454, align 8, !tbaa !3
  %v1455 = getelementptr i8, ptr %v1449, i64 64
  store ptr %arg, ptr %v1455, align 8, !tbaa !3
  %v1456 = call ptr @mlf_closure(ptr @mlf.code.1256, ptr %v1449)
  %v1457 = call ptr @mlf_prim2(i64 1, ptr %v1255, ptr %v1456)
  ret ptr %v1457
}

define private ptr @mlf.worker.50(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) {
entry:
  %v1220 = call ptr @mlf_prim2(i64 11, ptr %a4, ptr %a0)
  %v1221 = icmp eq ptr %v1220, inttoptr (i64 6 to ptr)
  br i1 %v1221, label %yes.1222, label %no.1223
yes.1222:
  %v1231 = call ptr @mlf_env_new(i64 2)
  %v1232 = getelementptr i8, ptr %v1231, i64 24
  store ptr %a1, ptr %v1232, align 8, !tbaa !3
  %v1233 = getelementptr i8, ptr %v1231, i64 32
  store ptr %a4, ptr %v1233, align 8, !tbaa !3
  %v1234 = call ptr @mlf_thunk(ptr @mlf.code.1225, ptr %v1231)
  %v1458 = call ptr @mlf_env_new(i64 5)
  %v1459 = getelementptr i8, ptr %v1458, i64 24
  store ptr %a0, ptr %v1459, align 8, !tbaa !3
  %v1460 = getelementptr i8, ptr %v1458, i64 32
  store ptr %a1, ptr %v1460, align 8, !tbaa !3
  %v1461 = getelementptr i8, ptr %v1458, i64 40
  store ptr %a2, ptr %v1461, align 8, !tbaa !3
  %v1462 = getelementptr i8, ptr %v1458, i64 48
  store ptr %a3, ptr %v1462, align 8, !tbaa !3
  %v1463 = getelementptr i8, ptr %v1458, i64 56
  store ptr %a4, ptr %v1463, align 8, !tbaa !3
  %v1464 = call ptr @mlf_closure(ptr @mlf.code.1235, ptr %v1458)
  %v1465 = call ptr @mlf_prim2(i64 1, ptr %v1234, ptr %v1464)
  br label %join.1224
no.1223:
  %v1466 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.1224
join.1224:
  %v1467 = phi ptr [ %v1465, %yes.1222 ], [ %v1466, %no.1223 ]
  ret ptr %v1467
}

define private ptr @mlf.numeric.entry.1094(ptr %env, ptr %arg) {
entry:
  %v1095 = getelementptr i8, ptr %env, i64 24
  %v1096 = load ptr, ptr %v1095, align 8, !tbaa !3
  %v1097 = getelementptr i8, ptr %env, i64 32
  %v1098 = load ptr, ptr %v1097, align 8, !tbaa !3
  %v1099 = getelementptr i8, ptr %env, i64 40
  %v1100 = load ptr, ptr %v1099, align 8, !tbaa !3
  %v1101 = getelementptr i8, ptr %env, i64 48
  %v1102 = load ptr, ptr %v1101, align 8, !tbaa !3
  %v1103 = getelementptr i8, ptr %env, i64 56
  %v1104 = load ptr, ptr %v1103, align 8, !tbaa !3
  %v1105 = call ptr @mlf_peek(ptr %v1096)
  %v1106 = call ptr @mlf_peek(ptr %v1098)
  %v1107 = call ptr @mlf_peek(ptr %v1100)
  %v1108 = call ptr @mlf_peek(ptr %v1102)
  %v1109 = call ptr @mlf_peek(ptr %v1104)
  %v1110 = icmp ne ptr %v1105, null
  %v1111 = icmp ne ptr %v1106, null
  %v1112 = icmp ne ptr %v1107, null
  %v1113 = icmp ne ptr %v1108, null
  %v1114 = icmp ne ptr %v1109, null
  %v1115 = and i1 true, %v1110
  %v1116 = and i1 %v1115, %v1111
  %v1117 = and i1 %v1116, %v1112
  %v1118 = and i1 %v1117, %v1113
  %v1119 = and i1 %v1118, %v1114
  br i1 %v1119, label %yes.1120, label %no.1121
yes.1120:
  %v1218 = call ptr @mlf.numeric.50(ptr %v1105, ptr %v1106, ptr %v1107, ptr %v1108, ptr %v1109)
  %v1219 = call ptr @mlf_prim1(i64 0, ptr %v1218)
  br label %join.1122
no.1121:
  %v1468 = call ptr @mlf_force(ptr %v1096)
  %v1469 = call ptr @mlf_force(ptr %v1104)
  %v1470 = call ptr @mlf.worker.50(ptr %v1468, ptr %v1098, ptr %v1100, ptr %v1102, ptr %v1469)
  br label %join.1122
join.1122:
  %v1471 = phi ptr [ %v1219, %yes.1120 ], [ %v1470, %no.1121 ]
  ret ptr %v1471
}

define private ptr @mlf.code.1085(ptr %env, ptr %arg) {
entry:
  %v1086 = getelementptr i8, ptr %env, i64 24
  %v1087 = load ptr, ptr %v1086, align 8, !tbaa !3
  %v1088 = getelementptr i8, ptr %env, i64 32
  %v1089 = load ptr, ptr %v1088, align 8, !tbaa !3
  %v1090 = getelementptr i8, ptr %env, i64 40
  %v1091 = load ptr, ptr %v1090, align 8, !tbaa !3
  %v1092 = getelementptr i8, ptr %env, i64 48
  %v1093 = load ptr, ptr %v1092, align 8, !tbaa !3
  %v1472 = call ptr @mlf_force(ptr %v1087)
  %v1473 = call ptr @mlf_env_new(i64 5)
  %v1474 = getelementptr i8, ptr %v1473, i64 24
  store ptr %v1472, ptr %v1474, align 8, !tbaa !3
  %v1475 = getelementptr i8, ptr %v1473, i64 32
  store ptr %v1089, ptr %v1475, align 8, !tbaa !3
  %v1476 = getelementptr i8, ptr %v1473, i64 40
  store ptr %v1091, ptr %v1476, align 8, !tbaa !3
  %v1477 = getelementptr i8, ptr %v1473, i64 48
  store ptr %v1093, ptr %v1477, align 8, !tbaa !3
  %v1478 = getelementptr i8, ptr %v1473, i64 56
  store ptr inttoptr (i64 1 to ptr), ptr %v1478, align 8, !tbaa !3
  %v1479 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1094, ptr %v1473)
  ret ptr %v1479
}

define private ptr @mlf.code.1489(ptr %env, ptr %arg) {
entry:
  %v1490 = getelementptr i8, ptr %env, i64 24
  %v1491 = load ptr, ptr %v1490, align 8, !tbaa !3
  %v1492 = call ptr @mlf_prim2(i64 32, ptr %v1491, ptr inttoptr (i64 1 to ptr))
  ret ptr %v1492
}

define private ptr @mlf.code.1499(ptr %env, ptr %arg) {
entry:
  %v1500 = getelementptr i8, ptr %env, i64 24
  %v1501 = load ptr, ptr %v1500, align 8, !tbaa !3
  %v1502 = call ptr @mlf_prim2(i64 32, ptr %v1501, ptr inttoptr (i64 3 to ptr))
  ret ptr %v1502
}

define private ptr @mlf.code.1509(ptr %env, ptr %arg) {
entry:
  %v1510 = getelementptr i8, ptr %env, i64 24
  %v1511 = load ptr, ptr %v1510, align 8, !tbaa !3
  %v1512 = getelementptr i8, ptr %env, i64 32
  %v1513 = load ptr, ptr %v1512, align 8, !tbaa !3
  %v1514 = call ptr @mlf_force(ptr %v1511)
  %v1515 = call ptr @mlf_force(ptr %v1513)
  %v1516 = getelementptr i8, ptr %v1514, i64 24
  %v1517 = load double, ptr %v1516, align 8, !tbaa !3
  %v1518 = getelementptr i8, ptr %v1515, i64 24
  %v1519 = load double, ptr %v1518, align 8, !tbaa !3
  %v1520 = fdiv double %v1517, %v1519
  %v1521 = call ptr @mlf_double(double %v1520)
  %v1522 = getelementptr i8, ptr %v1521, i64 24
  %v1523 = load double, ptr %v1522, align 8, !tbaa !3
  %v1524 = call double @llvm.sqrt.f64(double %v1523)
  %v1525 = call ptr @mlf_double(double %v1524)
  %v1526 = call ptr @mlf_prim2(i64 26, ptr inttoptr (i64 19 to ptr), ptr %v1525)
  ret ptr %v1526
}

define private ptr @mlf.code.1506(ptr %env, ptr %arg) {
entry:
  %v1507 = getelementptr i8, ptr %env, i64 24
  %v1508 = load ptr, ptr %v1507, align 8, !tbaa !3
  %v1527 = call ptr @mlf_env_new(i64 2)
  %v1528 = getelementptr i8, ptr %v1527, i64 24
  store ptr %v1508, ptr %v1528, align 8, !tbaa !3
  %v1529 = getelementptr i8, ptr %v1527, i64 32
  store ptr %arg, ptr %v1529, align 8, !tbaa !3
  %v1530 = call ptr @mlf_thunk(ptr @mlf.code.1509, ptr %v1527)
  %v1531 = call ptr @mlf_prim1(i64 3, ptr %v1530)
  ret ptr %v1531
}

define private ptr @mlf.code.1496(ptr %env, ptr %arg) {
entry:
  %v1497 = getelementptr i8, ptr %env, i64 24
  %v1498 = load ptr, ptr %v1497, align 8, !tbaa !3
  %v1503 = call ptr @mlf_env_new(i64 1)
  %v1504 = getelementptr i8, ptr %v1503, i64 24
  store ptr %v1498, ptr %v1504, align 8, !tbaa !3
  %v1505 = call ptr @mlf_thunk(ptr @mlf.code.1499, ptr %v1503)
  %v1532 = call ptr @mlf_env_new(i64 1)
  %v1533 = getelementptr i8, ptr %v1532, i64 24
  store ptr %arg, ptr %v1533, align 8, !tbaa !3
  %v1534 = call ptr @mlf_closure(ptr @mlf.code.1506, ptr %v1532)
  %v1535 = call ptr @mlf_prim2(i64 1, ptr %v1505, ptr %v1534)
  ret ptr %v1535
}

define private ptr @mlf.code.1486(ptr %env, ptr %arg) {
entry:
  %v1487 = getelementptr i8, ptr %env, i64 24
  %v1488 = load ptr, ptr %v1487, align 8, !tbaa !3
  %v1493 = call ptr @mlf_env_new(i64 1)
  %v1494 = getelementptr i8, ptr %v1493, i64 24
  store ptr %v1488, ptr %v1494, align 8, !tbaa !3
  %v1495 = call ptr @mlf_thunk(ptr @mlf.code.1489, ptr %v1493)
  %v1536 = call ptr @mlf_env_new(i64 1)
  %v1537 = getelementptr i8, ptr %v1536, i64 24
  store ptr %v1488, ptr %v1537, align 8, !tbaa !3
  %v1538 = call ptr @mlf_closure(ptr @mlf.code.1496, ptr %v1536)
  %v1539 = call ptr @mlf_prim2(i64 1, ptr %v1495, ptr %v1538)
  ret ptr %v1539
}

define private ptr @mlf.code.1076(ptr %env, ptr %arg) {
entry:
  %v1077 = getelementptr i8, ptr %env, i64 24
  %v1078 = load ptr, ptr %v1077, align 8, !tbaa !3
  %v1079 = getelementptr i8, ptr %env, i64 32
  %v1080 = load ptr, ptr %v1079, align 8, !tbaa !3
  %v1081 = getelementptr i8, ptr %env, i64 40
  %v1082 = load ptr, ptr %v1081, align 8, !tbaa !3
  %v1083 = getelementptr i8, ptr %env, i64 48
  %v1084 = load ptr, ptr %v1083, align 8, !tbaa !3
  %v1480 = call ptr @mlf_env_new(i64 4)
  %v1481 = getelementptr i8, ptr %v1480, i64 24
  store ptr %v1078, ptr %v1481, align 8, !tbaa !3
  %v1482 = getelementptr i8, ptr %v1480, i64 32
  store ptr %v1080, ptr %v1482, align 8, !tbaa !3
  %v1483 = getelementptr i8, ptr %v1480, i64 40
  store ptr %v1082, ptr %v1483, align 8, !tbaa !3
  %v1484 = getelementptr i8, ptr %v1480, i64 48
  store ptr %v1084, ptr %v1484, align 8, !tbaa !3
  %v1485 = call ptr @mlf_thunk(ptr @mlf.code.1085, ptr %v1480)
  %v1540 = call ptr @mlf_env_new(i64 1)
  %v1541 = getelementptr i8, ptr %v1540, i64 24
  store ptr %v1084, ptr %v1541, align 8, !tbaa !3
  %v1542 = call ptr @mlf_closure(ptr @mlf.code.1486, ptr %v1540)
  %v1543 = call ptr @mlf_prim2(i64 1, ptr %v1485, ptr %v1542)
  ret ptr %v1543
}

define private ptr @mlf.code.54(ptr %env, ptr %arg) {
entry:
  %v55 = getelementptr i8, ptr %env, i64 24
  %v56 = load ptr, ptr %v55, align 8, !tbaa !3
  %v57 = getelementptr i8, ptr %env, i64 32
  %v58 = load ptr, ptr %v57, align 8, !tbaa !3
  %v59 = getelementptr i8, ptr %env, i64 40
  %v60 = load ptr, ptr %v59, align 8, !tbaa !3
  %v61 = getelementptr i8, ptr %env, i64 48
  %v62 = load ptr, ptr %v61, align 8, !tbaa !3
  %v1070 = call ptr @mlf_env_new(i64 4)
  %v1071 = getelementptr i8, ptr %v1070, i64 24
  store ptr %v56, ptr %v1071, align 8, !tbaa !3
  %v1072 = getelementptr i8, ptr %v1070, i64 32
  store ptr %v58, ptr %v1072, align 8, !tbaa !3
  %v1073 = getelementptr i8, ptr %v1070, i64 40
  store ptr %v60, ptr %v1073, align 8, !tbaa !3
  %v1074 = getelementptr i8, ptr %v1070, i64 48
  store ptr %v62, ptr %v1074, align 8, !tbaa !3
  %v1075 = call ptr @mlf_thunk(ptr @mlf.code.63, ptr %v1070)
  %v1544 = call ptr @mlf_env_new(i64 4)
  %v1545 = getelementptr i8, ptr %v1544, i64 24
  store ptr %v56, ptr %v1545, align 8, !tbaa !3
  %v1546 = getelementptr i8, ptr %v1544, i64 32
  store ptr %v58, ptr %v1546, align 8, !tbaa !3
  %v1547 = getelementptr i8, ptr %v1544, i64 40
  store ptr %v60, ptr %v1547, align 8, !tbaa !3
  %v1548 = getelementptr i8, ptr %v1544, i64 48
  store ptr %arg, ptr %v1548, align 8, !tbaa !3
  %v1549 = call ptr @mlf_closure(ptr @mlf.code.1076, ptr %v1544)
  %v1550 = call ptr @mlf_prim2(i64 1, ptr %v1075, ptr %v1549)
  ret ptr %v1550
}

define private ptr @mlf.code.43(ptr %env, ptr %arg) {
entry:
  %v44 = getelementptr i8, ptr %env, i64 24
  %v45 = load ptr, ptr %v44, align 8, !tbaa !3
  %v46 = getelementptr i8, ptr %env, i64 32
  %v47 = load ptr, ptr %v46, align 8, !tbaa !3
  %v48 = getelementptr i8, ptr %env, i64 40
  %v49 = load ptr, ptr %v48, align 8, !tbaa !3
  %v53 = call ptr @mlf_thunk(ptr @mlf.code.50, ptr null)
  %v1551 = call ptr @mlf_env_new(i64 4)
  %v1552 = getelementptr i8, ptr %v1551, i64 24
  store ptr %v45, ptr %v1552, align 8, !tbaa !3
  %v1553 = getelementptr i8, ptr %v1551, i64 32
  store ptr %v47, ptr %v1553, align 8, !tbaa !3
  %v1554 = getelementptr i8, ptr %v1551, i64 40
  store ptr %v49, ptr %v1554, align 8, !tbaa !3
  %v1555 = getelementptr i8, ptr %v1551, i64 48
  store ptr %arg, ptr %v1555, align 8, !tbaa !3
  %v1556 = call ptr @mlf_closure(ptr @mlf.code.54, ptr %v1551)
  %v1557 = call ptr @mlf_prim2(i64 1, ptr %v53, ptr %v1556)
  ret ptr %v1557
}

define private ptr @mlf.code.30(ptr %env, ptr %arg) {
entry:
  %v31 = getelementptr i8, ptr %env, i64 24
  %v32 = load ptr, ptr %v31, align 8, !tbaa !3
  %v33 = getelementptr i8, ptr %env, i64 32
  %v34 = load ptr, ptr %v33, align 8, !tbaa !3
  %v40 = call ptr @mlf_env_new(i64 1)
  %v41 = getelementptr i8, ptr %v40, i64 24
  store ptr %v32, ptr %v41, align 8, !tbaa !3
  %v42 = call ptr @mlf_thunk(ptr @mlf.code.35, ptr %v40)
  %v1558 = call ptr @mlf_env_new(i64 3)
  %v1559 = getelementptr i8, ptr %v1558, i64 24
  store ptr %v32, ptr %v1559, align 8, !tbaa !3
  %v1560 = getelementptr i8, ptr %v1558, i64 32
  store ptr %v34, ptr %v1560, align 8, !tbaa !3
  %v1561 = getelementptr i8, ptr %v1558, i64 40
  store ptr %arg, ptr %v1561, align 8, !tbaa !3
  %v1562 = call ptr @mlf_closure(ptr @mlf.code.43, ptr %v1558)
  %v1563 = call ptr @mlf_prim2(i64 1, ptr %v42, ptr %v1562)
  ret ptr %v1563
}

define private ptr @mlf.code.19(ptr %env, ptr %arg) {
entry:
  %v20 = getelementptr i8, ptr %env, i64 24
  %v21 = load ptr, ptr %v20, align 8, !tbaa !3
  %v27 = call ptr @mlf_env_new(i64 1)
  %v28 = getelementptr i8, ptr %v27, i64 24
  store ptr %v21, ptr %v28, align 8, !tbaa !3
  %v29 = call ptr @mlf_thunk(ptr @mlf.code.22, ptr %v27)
  %v1564 = call ptr @mlf_env_new(i64 2)
  %v1565 = getelementptr i8, ptr %v1564, i64 24
  store ptr %v21, ptr %v1565, align 8, !tbaa !3
  %v1566 = getelementptr i8, ptr %v1564, i64 32
  store ptr %arg, ptr %v1566, align 8, !tbaa !3
  %v1567 = call ptr @mlf_closure(ptr @mlf.code.30, ptr %v1564)
  %v1568 = call ptr @mlf_prim2(i64 1, ptr %v29, ptr %v1567)
  ret ptr %v1568
}

define private ptr @mlf.code.2(ptr %env, ptr %arg) {
entry:
  %v8 = call ptr @mlf_env_new(i64 1)
  %v9 = getelementptr i8, ptr %v8, i64 24
  store ptr %arg, ptr %v9, align 8, !tbaa !3
  %v10 = call ptr @mlf_thunk(ptr @mlf.code.3, ptr %v8)
  %v16 = call ptr @mlf_env_new(i64 1)
  %v17 = getelementptr i8, ptr %v16, i64 24
  store ptr %v10, ptr %v17, align 8, !tbaa !3
  %v18 = call ptr @mlf_thunk(ptr @mlf.code.11, ptr %v16)
  %v1569 = call ptr @mlf_env_new(i64 1)
  %v1570 = getelementptr i8, ptr %v1569, i64 24
  store ptr %v10, ptr %v1570, align 8, !tbaa !3
  %v1571 = call ptr @mlf_closure(ptr @mlf.code.19, ptr %v1569)
  %v1572 = call ptr @mlf_prim2(i64 1, ptr %v18, ptr %v1571)
  ret ptr %v1572
}

define private ptr @mlf.code.0(ptr %env, ptr %arg) {
entry:
  %v1 = call ptr @mlf_primitive(i64 4)
  %v1573 = call ptr @mlf_closure(ptr @mlf.code.2, ptr null)
  %v1574 = call ptr @mlf_prim2(i64 1, ptr %v1, ptr %v1573)
  ret ptr %v1574
}

declare void @mlf_require_standard_abi()
define ptr @mlf_entry() {
  call void @mlf_require_standard_abi()
  %root = call ptr @mlf.code.0(ptr null, ptr null)
  ret ptr %root
}
define i32 @main(i32 %argc, ptr %argv) {
  call void @mlf_set_args(i32 %argc, ptr %argv)
  %root = call ptr @mlf_entry()
  %status = call i32 @mlf_run(ptr %root, i64 1)
  ret i32 %status
}
