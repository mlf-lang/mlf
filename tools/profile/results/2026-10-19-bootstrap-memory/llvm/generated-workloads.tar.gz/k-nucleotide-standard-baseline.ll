; Generated from independently checked xMLF.
source_filename = "emlf"

declare ptr @mlf_execute_st_lazy(ptr)
declare ptr @mlf_st_new_array(ptr, ptr)
declare ptr @mlf_st_read_array(ptr, ptr)
declare ptr @mlf_st_write_array(ptr, ptr, ptr)
declare ptr @mlf_st_length_array(ptr)
declare void @mlf_set_args(i32, ptr)
declare ptr @mlf_env_new(i64)
declare void @mlf_env_set(ptr, i64, ptr)
declare ptr @mlf_env_get(ptr, i64)
declare ptr @mlf_thunk(ptr, ptr)
declare ptr @mlf_closure(ptr, ptr)
declare ptr @mlf_application(ptr, ptr)
declare ptr @mlf_hole()
declare void @mlf_fill(ptr, ptr)
declare ptr @mlf_integer(ptr)
declare ptr @mlf_string(ptr, i64)
declare ptr @mlf_double(double)
declare double @llvm.sqrt.f64(double)
declare double @mlf_int_to_double(ptr)
declare ptr @mlf_read_int_table(ptr, ptr)
declare ptr @mlf_write_int_table(ptr, ptr, ptr)
declare ptr @mlf_add_int_table(ptr, ptr, ptr)
declare void @mlf_roots_enter(ptr, i64, ptr)
declare void @mlf_roots_leave(ptr)
declare void @mlf_gc_check(i64, ptr)
declare ptr @mlf_get_byte_line()
declare ptr @mlf_new_array(i64, ptr, ptr)
declare ptr @mlf_bytes_from_string(ptr)
declare ptr @mlf_put_bytes(ptr, ptr, ptr)
declare ptr @mlf_new_int_table()
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare i8 @mlf_byte(ptr)
declare ptr @mlf_peek(ptr)
declare ptr @mlf_native_io(ptr, ptr)
declare void @mlf_bounds_failure() noreturn
declare ptr @mlf_primitive(i64)
declare ptr @mlf_prim1(i64, ptr)
declare ptr @mlf_prim2(i64, ptr, ptr)
declare i64 @mlf_truth(ptr)
declare ptr @mlf_prim3(i64, ptr, ptr, ptr)
declare ptr @mlf_force(ptr)
declare ptr @mlf_add_int(ptr, ptr)
declare ptr @mlf_sub_int(ptr, ptr)
declare ptr @mlf_eq_int(ptr, ptr)
declare ptr @mlf_lt_int(ptr, ptr)
declare ptr @mlf_constructor(i64, i64)
declare ptr @mlf_constructor1(i64, ptr)
declare ptr @mlf_constructor2(i64, ptr, ptr)
declare ptr @mlf_constructor_fields(i64, ptr)
declare ptr @mlf_constructor_new(i64, i64)
declare ptr @mlf_field(ptr, i64)
declare void @mlf_match_failure() noreturn
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare i32 @mlf_run(ptr, i64)

!0 = !{!"MLF storage"}
!1 = !{!"managed object", !0}
!2 = !{!"array cells", !0}
!3 = !{!1, !1, i64 0}
!4 = !{!2, !2, i64 0}
@mlf.bytes.2948 = private unnamed_addr constant [1 x i8] c"\00", align 1
@mlf.bytes.3191 = private unnamed_addr constant [1 x i8] c"\00", align 1
@mlf.bytes.3311 = private unnamed_addr constant [2 x i8] c"\41\00", align 1
@mlf.bytes.3329 = private unnamed_addr constant [2 x i8] c"\43\00", align 1
@mlf.bytes.3347 = private unnamed_addr constant [2 x i8] c"\47\00", align 1
@mlf.bytes.3349 = private unnamed_addr constant [2 x i8] c"\54\00", align 1
@mlf.bytes.3415 = private unnamed_addr constant [2 x i8] c"\20\00", align 1
@mlf.bytes.4016 = private unnamed_addr constant [2 x i8] c"\09\00", align 1
@mlf.bytes.4055 = private unnamed_addr constant [4 x i8] c"\47\47\54\00", align 1
@mlf.bytes.4072 = private unnamed_addr constant [5 x i8] c"\47\47\54\41\00", align 1
@mlf.bytes.4089 = private unnamed_addr constant [7 x i8] c"\47\47\54\41\54\54\00", align 1
@mlf.bytes.4106 = private unnamed_addr constant [13 x i8] c"\47\47\54\41\54\54\54\54\41\41\54\54\00", align 1
@mlf.bytes.4118 = private unnamed_addr constant [19 x i8] c"\47\47\54\41\54\54\54\54\41\41\54\54\54\41\54\41\47\54\00", align 1
define private ptr @mlf.numeric.25(ptr %a0) {
entry:
  %v11 = alloca [1 x ptr], align 8
  %v12 = getelementptr ptr, ptr %v11, i64 0
  store ptr %a0, ptr %v12, align 8
  call void @mlf_gc_check(i64 1, ptr %v11)
  %v13 = call ptr @mlf_get_byte_line()
  %v14 = getelementptr i8, ptr %v13, i64 24
  %v15 = load i64, ptr %v14, align 8, !tbaa !3
  %v16 = getelementptr i8, ptr %v13, i64 32
  %v17 = load ptr, ptr %v16, align 8, !tbaa !3
  %v18 = shl i64 %v15, 1
  %v19 = or i64 %v18, 1
  %v20 = inttoptr i64 %v19 to ptr
  %v21 = ptrtoint ptr %v20 to i64
  %v22 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v23 = and i64 %v21, %v22
  %v24 = and i64 %v23, 1
  %v25 = icmp ne i64 %v24, 0
  br i1 %v25, label %yes.26, label %no.27
yes.26:
  %v29 = icmp eq i64 %v21, %v22
  %v30 = select i1 %v29, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.28
no.27:
  %v31 = call ptr @mlf_eq_int(ptr %v20, ptr inttoptr (i64 1 to ptr))
  br label %join.28
join.28:
  %v32 = phi ptr [ %v30, %yes.26 ], [ %v31, %no.27 ]
  %v33 = icmp eq ptr %v32, inttoptr (i64 6 to ptr)
  br i1 %v33, label %tail.yes.34, label %tail.no.35
tail.yes.34:
  ret ptr inttoptr (i64 4 to ptr)
tail.no.35:
  %v36 = ptrtoint ptr %v20 to i64
  %v37 = ptrtoint ptr inttoptr (i64 13 to ptr) to i64
  %v38 = and i64 %v36, %v37
  %v39 = and i64 %v38, 1
  %v40 = icmp ne i64 %v39, 0
  br i1 %v40, label %yes.41, label %no.42
yes.41:
  %v44 = icmp slt i64 %v36, %v37
  %v45 = select i1 %v44, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.43
no.42:
  %v46 = call ptr @mlf_lt_int(ptr %v20, ptr inttoptr (i64 13 to ptr))
  br label %join.43
join.43:
  %v47 = phi ptr [ %v45, %yes.41 ], [ %v46, %no.42 ]
  %v48 = icmp eq ptr %v47, inttoptr (i64 6 to ptr)
  br i1 %v48, label %yes.49, label %no.50
yes.49:
  br label %join.51
no.50:
  %v52 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v53 = ashr i64 %v52, 1
  %v54 = and i64 %v52, 1
  %v55 = icmp ne i64 %v54, 0
  %v56 = icmp ult i64 %v53, %v15
  %v57 = and i1 %v55, %v56
  br i1 %v57, label %array.valid.58, label %array.invalid.59
array.invalid.59:
  call void @mlf_bounds_failure()
  unreachable
array.valid.58:
  %v60 = getelementptr i8, ptr %v17, i64 %v53
  %v61 = load i8, ptr %v60, align 1, !tbaa !4
  %v62 = zext i8 %v61 to i64
  %v63 = shl i64 %v62, 1
  %v64 = or i64 %v63, 1
  %v65 = inttoptr i64 %v64 to ptr
  %v66 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v67 = ashr i64 %v66, 1
  %v68 = and i64 %v66, 1
  %v69 = icmp ne i64 %v68, 0
  %v70 = icmp ult i64 %v67, %v15
  %v71 = and i1 %v69, %v70
  br i1 %v71, label %array.valid.72, label %array.invalid.73
array.invalid.73:
  call void @mlf_bounds_failure()
  unreachable
array.valid.72:
  %v74 = getelementptr i8, ptr %v17, i64 %v67
  %v75 = load i8, ptr %v74, align 1, !tbaa !4
  %v76 = zext i8 %v75 to i64
  %v77 = shl i64 %v76, 1
  %v78 = or i64 %v77, 1
  %v79 = inttoptr i64 %v78 to ptr
  %v80 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v81 = ashr i64 %v80, 1
  %v82 = and i64 %v80, 1
  %v83 = icmp ne i64 %v82, 0
  %v84 = icmp ult i64 %v81, %v15
  %v85 = and i1 %v83, %v84
  br i1 %v85, label %array.valid.86, label %array.invalid.87
array.invalid.87:
  call void @mlf_bounds_failure()
  unreachable
array.valid.86:
  %v88 = getelementptr i8, ptr %v17, i64 %v81
  %v89 = load i8, ptr %v88, align 1, !tbaa !4
  %v90 = zext i8 %v89 to i64
  %v91 = shl i64 %v90, 1
  %v92 = or i64 %v91, 1
  %v93 = inttoptr i64 %v92 to ptr
  %v94 = ptrtoint ptr inttoptr (i64 7 to ptr) to i64
  %v95 = ashr i64 %v94, 1
  %v96 = and i64 %v94, 1
  %v97 = icmp ne i64 %v96, 0
  %v98 = icmp ult i64 %v95, %v15
  %v99 = and i1 %v97, %v98
  br i1 %v99, label %array.valid.100, label %array.invalid.101
array.invalid.101:
  call void @mlf_bounds_failure()
  unreachable
array.valid.100:
  %v102 = getelementptr i8, ptr %v17, i64 %v95
  %v103 = load i8, ptr %v102, align 1, !tbaa !4
  %v104 = zext i8 %v103 to i64
  %v105 = shl i64 %v104, 1
  %v106 = or i64 %v105, 1
  %v107 = inttoptr i64 %v106 to ptr
  %v108 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v109 = ashr i64 %v108, 1
  %v110 = and i64 %v108, 1
  %v111 = icmp ne i64 %v110, 0
  %v112 = icmp ult i64 %v109, %v15
  %v113 = and i1 %v111, %v112
  br i1 %v113, label %array.valid.114, label %array.invalid.115
array.invalid.115:
  call void @mlf_bounds_failure()
  unreachable
array.valid.114:
  %v116 = getelementptr i8, ptr %v17, i64 %v109
  %v117 = load i8, ptr %v116, align 1, !tbaa !4
  %v118 = zext i8 %v117 to i64
  %v119 = shl i64 %v118, 1
  %v120 = or i64 %v119, 1
  %v121 = inttoptr i64 %v120 to ptr
  %v122 = ptrtoint ptr inttoptr (i64 11 to ptr) to i64
  %v123 = ashr i64 %v122, 1
  %v124 = and i64 %v122, 1
  %v125 = icmp ne i64 %v124, 0
  %v126 = icmp ult i64 %v123, %v15
  %v127 = and i1 %v125, %v126
  br i1 %v127, label %array.valid.128, label %array.invalid.129
array.invalid.129:
  call void @mlf_bounds_failure()
  unreachable
array.valid.128:
  %v130 = getelementptr i8, ptr %v17, i64 %v123
  %v131 = load i8, ptr %v130, align 1, !tbaa !4
  %v132 = zext i8 %v131 to i64
  %v133 = shl i64 %v132, 1
  %v134 = or i64 %v133, 1
  %v135 = inttoptr i64 %v134 to ptr
  %v136 = ptrtoint ptr %v65 to i64
  %v137 = ptrtoint ptr inttoptr (i64 125 to ptr) to i64
  %v138 = icmp eq i64 %v136, %v137
  %v139 = select i1 %v138, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v140 = icmp eq ptr %v139, inttoptr (i64 6 to ptr)
  br i1 %v140, label %yes.141, label %no.142
yes.141:
  %v144 = ptrtoint ptr %v79 to i64
  %v145 = ptrtoint ptr inttoptr (i64 169 to ptr) to i64
  %v146 = icmp eq i64 %v144, %v145
  %v147 = select i1 %v146, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v148 = icmp eq ptr %v147, inttoptr (i64 6 to ptr)
  br i1 %v148, label %yes.149, label %no.150
yes.149:
  %v152 = ptrtoint ptr %v93 to i64
  %v153 = ptrtoint ptr inttoptr (i64 145 to ptr) to i64
  %v154 = icmp eq i64 %v152, %v153
  %v155 = select i1 %v154, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v156 = icmp eq ptr %v155, inttoptr (i64 6 to ptr)
  br i1 %v156, label %yes.157, label %no.158
yes.157:
  %v160 = ptrtoint ptr %v107 to i64
  %v161 = ptrtoint ptr inttoptr (i64 165 to ptr) to i64
  %v162 = icmp eq i64 %v160, %v161
  %v163 = select i1 %v162, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v164 = icmp eq ptr %v163, inttoptr (i64 6 to ptr)
  br i1 %v164, label %yes.165, label %no.166
yes.165:
  %v168 = ptrtoint ptr %v121 to i64
  %v169 = ptrtoint ptr inttoptr (i64 139 to ptr) to i64
  %v170 = icmp eq i64 %v168, %v169
  %v171 = select i1 %v170, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v172 = icmp eq ptr %v171, inttoptr (i64 6 to ptr)
  br i1 %v172, label %yes.173, label %no.174
yes.173:
  %v176 = ptrtoint ptr %v135 to i64
  %v177 = ptrtoint ptr inttoptr (i64 139 to ptr) to i64
  %v178 = icmp eq i64 %v176, %v177
  %v179 = select i1 %v178, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.175
no.174:
  br label %join.175
join.175:
  %v180 = phi ptr [ %v179, %yes.173 ], [ inttoptr (i64 2 to ptr), %no.174 ]
  br label %join.167
no.166:
  br label %join.167
join.167:
  %v181 = phi ptr [ %v180, %join.175 ], [ inttoptr (i64 2 to ptr), %no.166 ]
  br label %join.159
no.158:
  br label %join.159
join.159:
  %v182 = phi ptr [ %v181, %join.167 ], [ inttoptr (i64 2 to ptr), %no.158 ]
  br label %join.151
no.150:
  br label %join.151
join.151:
  %v183 = phi ptr [ %v182, %join.159 ], [ inttoptr (i64 2 to ptr), %no.150 ]
  br label %join.143
no.142:
  br label %join.143
join.143:
  %v184 = phi ptr [ %v183, %join.151 ], [ inttoptr (i64 2 to ptr), %no.142 ]
  %v185 = icmp eq ptr %v184, inttoptr (i64 6 to ptr)
  br i1 %v185, label %yes.186, label %no.187
yes.186:
  %v189 = ptrtoint ptr %v20 to i64
  %v190 = ptrtoint ptr inttoptr (i64 13 to ptr) to i64
  %v191 = and i64 %v189, %v190
  %v192 = and i64 %v191, 1
  %v193 = icmp ne i64 %v192, 0
  br i1 %v193, label %yes.194, label %no.195
yes.194:
  %v197 = icmp eq i64 %v189, %v190
  %v198 = select i1 %v197, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.196
no.195:
  %v199 = call ptr @mlf_eq_int(ptr %v20, ptr inttoptr (i64 13 to ptr))
  br label %join.196
join.196:
  %v200 = phi ptr [ %v198, %yes.194 ], [ %v199, %no.195 ]
  %v201 = icmp eq ptr %v200, inttoptr (i64 6 to ptr)
  br i1 %v201, label %yes.202, label %no.203
yes.202:
  br label %join.204
no.203:
  %v205 = ptrtoint ptr inttoptr (i64 13 to ptr) to i64
  %v206 = ashr i64 %v205, 1
  %v207 = and i64 %v205, 1
  %v208 = icmp ne i64 %v207, 0
  %v209 = icmp ult i64 %v206, %v15
  %v210 = and i1 %v208, %v209
  br i1 %v210, label %array.valid.211, label %array.invalid.212
array.invalid.212:
  call void @mlf_bounds_failure()
  unreachable
array.valid.211:
  %v213 = getelementptr i8, ptr %v17, i64 %v206
  %v214 = load i8, ptr %v213, align 1, !tbaa !4
  %v215 = zext i8 %v214 to i64
  %v216 = shl i64 %v215, 1
  %v217 = or i64 %v216, 1
  %v218 = inttoptr i64 %v217 to ptr
  %v219 = ptrtoint ptr %v218 to i64
  %v220 = ptrtoint ptr inttoptr (i64 65 to ptr) to i64
  %v221 = icmp eq i64 %v219, %v220
  %v222 = select i1 %v221, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v223 = icmp eq ptr %v222, inttoptr (i64 6 to ptr)
  br i1 %v223, label %yes.224, label %no.225
yes.224:
  br label %join.226
no.225:
  %v227 = ptrtoint ptr %v218 to i64
  %v228 = ptrtoint ptr inttoptr (i64 19 to ptr) to i64
  %v229 = icmp eq i64 %v227, %v228
  %v230 = select i1 %v229, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v231 = icmp eq ptr %v230, inttoptr (i64 6 to ptr)
  br i1 %v231, label %yes.232, label %no.233
yes.232:
  br label %join.234
no.233:
  %v235 = ptrtoint ptr %v218 to i64
  %v236 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v237 = icmp eq i64 %v235, %v236
  %v238 = select i1 %v237, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v239 = icmp eq ptr %v238, inttoptr (i64 6 to ptr)
  br i1 %v239, label %yes.240, label %no.241
yes.240:
  br label %join.242
no.241:
  %v243 = ptrtoint ptr %v218 to i64
  %v244 = ptrtoint ptr inttoptr (i64 27 to ptr) to i64
  %v245 = icmp eq i64 %v243, %v244
  %v246 = select i1 %v245, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.242
join.242:
  %v247 = phi ptr [ inttoptr (i64 6 to ptr), %yes.240 ], [ %v246, %no.241 ]
  br label %join.234
join.234:
  %v248 = phi ptr [ inttoptr (i64 6 to ptr), %yes.232 ], [ %v247, %join.242 ]
  br label %join.226
join.226:
  %v249 = phi ptr [ inttoptr (i64 6 to ptr), %yes.224 ], [ %v248, %join.234 ]
  br label %join.204
join.204:
  %v250 = phi ptr [ inttoptr (i64 6 to ptr), %yes.202 ], [ %v249, %join.226 ]
  br label %join.188
no.187:
  br label %join.188
join.188:
  %v251 = phi ptr [ %v250, %join.204 ], [ inttoptr (i64 2 to ptr), %no.187 ]
  br label %join.51
join.51:
  %v252 = phi ptr [ inttoptr (i64 2 to ptr), %yes.49 ], [ %v251, %join.188 ]
  %v253 = icmp eq ptr %v252, inttoptr (i64 6 to ptr)
  br i1 %v253, label %tail.yes.254, label %tail.no.255
tail.yes.254:
  ret ptr inttoptr (i64 4 to ptr)
tail.no.255:
  %v256 = musttail call ptr @mlf.numeric.25(ptr inttoptr (i64 4 to ptr))
  ret ptr %v256
}

define private ptr @mlf.code.261(ptr %env, ptr %arg) {
entry:
  %v262 = getelementptr i8, ptr %env, i64 24
  %v263 = load ptr, ptr %v262, align 8, !tbaa !3
  %v264 = call ptr @mlf_prim1(i64 38, ptr %v263)
  ret ptr %v264
}

define private ptr @mlf.code.290(ptr %env, ptr %arg) {
entry:
  %v291 = getelementptr i8, ptr %env, i64 24
  %v292 = load ptr, ptr %v291, align 8, !tbaa !3
  %v293 = call ptr @mlf_prim2(i64 36, ptr %v292, ptr inttoptr (i64 1 to ptr))
  ret ptr %v293
}

define private ptr @mlf.code.302(ptr %env, ptr %arg) {
entry:
  %v303 = getelementptr i8, ptr %env, i64 24
  %v304 = load ptr, ptr %v303, align 8, !tbaa !3
  %v305 = call ptr @mlf_prim2(i64 36, ptr %v304, ptr inttoptr (i64 3 to ptr))
  ret ptr %v305
}

define private ptr @mlf.code.316(ptr %env, ptr %arg) {
entry:
  %v317 = getelementptr i8, ptr %env, i64 24
  %v318 = load ptr, ptr %v317, align 8, !tbaa !3
  %v319 = call ptr @mlf_prim2(i64 36, ptr %v318, ptr inttoptr (i64 5 to ptr))
  ret ptr %v319
}

define private ptr @mlf.code.332(ptr %env, ptr %arg) {
entry:
  %v333 = getelementptr i8, ptr %env, i64 24
  %v334 = load ptr, ptr %v333, align 8, !tbaa !3
  %v335 = call ptr @mlf_prim2(i64 36, ptr %v334, ptr inttoptr (i64 7 to ptr))
  ret ptr %v335
}

define private ptr @mlf.code.350(ptr %env, ptr %arg) {
entry:
  %v351 = getelementptr i8, ptr %env, i64 24
  %v352 = load ptr, ptr %v351, align 8, !tbaa !3
  %v353 = call ptr @mlf_prim2(i64 36, ptr %v352, ptr inttoptr (i64 9 to ptr))
  ret ptr %v353
}

define private ptr @mlf.code.370(ptr %env, ptr %arg) {
entry:
  %v371 = getelementptr i8, ptr %env, i64 24
  %v372 = load ptr, ptr %v371, align 8, !tbaa !3
  %v373 = call ptr @mlf_prim2(i64 36, ptr %v372, ptr inttoptr (i64 11 to ptr))
  ret ptr %v373
}

define private ptr @mlf.code.440(ptr %env, ptr %arg) {
entry:
  %v441 = getelementptr i8, ptr %env, i64 24
  %v442 = load ptr, ptr %v441, align 8, !tbaa !3
  %v443 = call ptr @mlf_prim2(i64 36, ptr %v442, ptr inttoptr (i64 13 to ptr))
  ret ptr %v443
}

define private ptr @mlf.code.448(ptr %env, ptr %arg) {
entry:
  %v449 = getelementptr i8, ptr %env, i64 24
  %v450 = load ptr, ptr %v449, align 8, !tbaa !3
  %v451 = call ptr @mlf_force(ptr %v450)
  %v452 = call ptr @mlf_prim2(i64 10, ptr %v451, ptr inttoptr (i64 65 to ptr))
  %v453 = icmp eq ptr %v452, inttoptr (i64 6 to ptr)
  br i1 %v453, label %yes.454, label %no.455
yes.454:
  br label %join.456
no.455:
  %v457 = call ptr @mlf_prim2(i64 10, ptr %v451, ptr inttoptr (i64 19 to ptr))
  %v458 = icmp eq ptr %v457, inttoptr (i64 6 to ptr)
  br i1 %v458, label %yes.459, label %no.460
yes.459:
  br label %join.461
no.460:
  %v462 = call ptr @mlf_prim2(i64 10, ptr %v451, ptr inttoptr (i64 21 to ptr))
  %v463 = icmp eq ptr %v462, inttoptr (i64 6 to ptr)
  br i1 %v463, label %yes.464, label %no.465
yes.464:
  br label %join.466
no.465:
  %v467 = call ptr @mlf_prim2(i64 10, ptr %v451, ptr inttoptr (i64 27 to ptr))
  br label %join.466
join.466:
  %v468 = phi ptr [ inttoptr (i64 6 to ptr), %yes.464 ], [ %v467, %no.465 ]
  br label %join.461
join.461:
  %v469 = phi ptr [ inttoptr (i64 6 to ptr), %yes.459 ], [ %v468, %join.466 ]
  br label %join.456
join.456:
  %v470 = phi ptr [ inttoptr (i64 6 to ptr), %yes.454 ], [ %v469, %join.461 ]
  ret ptr %v470
}

define private ptr @mlf.code.447(ptr %env, ptr %arg) {
entry:
  %v471 = call ptr @mlf_env_new(i64 1)
  %v472 = getelementptr i8, ptr %v471, i64 24
  store ptr %arg, ptr %v472, align 8, !tbaa !3
  %v473 = call ptr @mlf_thunk(ptr @mlf.code.448, ptr %v471)
  %v474 = call ptr @mlf_prim1(i64 0, ptr %v473)
  ret ptr %v474
}

define private ptr @mlf.code.377(ptr %env, ptr %arg) {
entry:
  %v378 = getelementptr i8, ptr %env, i64 24
  %v379 = load ptr, ptr %v378, align 8, !tbaa !3
  %v380 = getelementptr i8, ptr %env, i64 32
  %v381 = load ptr, ptr %v380, align 8, !tbaa !3
  %v382 = getelementptr i8, ptr %env, i64 40
  %v383 = load ptr, ptr %v382, align 8, !tbaa !3
  %v384 = getelementptr i8, ptr %env, i64 48
  %v385 = load ptr, ptr %v384, align 8, !tbaa !3
  %v386 = getelementptr i8, ptr %env, i64 56
  %v387 = load ptr, ptr %v386, align 8, !tbaa !3
  %v388 = getelementptr i8, ptr %env, i64 64
  %v389 = load ptr, ptr %v388, align 8, !tbaa !3
  %v390 = getelementptr i8, ptr %env, i64 72
  %v391 = load ptr, ptr %v390, align 8, !tbaa !3
  %v392 = call ptr @mlf_force(ptr %v383)
  %v393 = call ptr @mlf_prim2(i64 10, ptr %v392, ptr inttoptr (i64 125 to ptr))
  %v394 = icmp eq ptr %v393, inttoptr (i64 6 to ptr)
  br i1 %v394, label %yes.395, label %no.396
yes.395:
  %v398 = call ptr @mlf_force(ptr %v385)
  %v399 = call ptr @mlf_prim2(i64 10, ptr %v398, ptr inttoptr (i64 169 to ptr))
  %v400 = icmp eq ptr %v399, inttoptr (i64 6 to ptr)
  br i1 %v400, label %yes.401, label %no.402
yes.401:
  %v404 = call ptr @mlf_force(ptr %v387)
  %v405 = call ptr @mlf_prim2(i64 10, ptr %v404, ptr inttoptr (i64 145 to ptr))
  %v406 = icmp eq ptr %v405, inttoptr (i64 6 to ptr)
  br i1 %v406, label %yes.407, label %no.408
yes.407:
  %v410 = call ptr @mlf_force(ptr %v389)
  %v411 = call ptr @mlf_prim2(i64 10, ptr %v410, ptr inttoptr (i64 165 to ptr))
  %v412 = icmp eq ptr %v411, inttoptr (i64 6 to ptr)
  br i1 %v412, label %yes.413, label %no.414
yes.413:
  %v416 = call ptr @mlf_force(ptr %v391)
  %v417 = call ptr @mlf_prim2(i64 10, ptr %v416, ptr inttoptr (i64 139 to ptr))
  %v418 = icmp eq ptr %v417, inttoptr (i64 6 to ptr)
  br i1 %v418, label %yes.419, label %no.420
yes.419:
  %v422 = call ptr @mlf_force(ptr %arg)
  %v423 = call ptr @mlf_prim2(i64 10, ptr %v422, ptr inttoptr (i64 139 to ptr))
  br label %join.421
no.420:
  br label %join.421
join.421:
  %v424 = phi ptr [ %v423, %yes.419 ], [ inttoptr (i64 2 to ptr), %no.420 ]
  br label %join.415
no.414:
  br label %join.415
join.415:
  %v425 = phi ptr [ %v424, %join.421 ], [ inttoptr (i64 2 to ptr), %no.414 ]
  br label %join.409
no.408:
  br label %join.409
join.409:
  %v426 = phi ptr [ %v425, %join.415 ], [ inttoptr (i64 2 to ptr), %no.408 ]
  br label %join.403
no.402:
  br label %join.403
join.403:
  %v427 = phi ptr [ %v426, %join.409 ], [ inttoptr (i64 2 to ptr), %no.402 ]
  br label %join.397
no.396:
  br label %join.397
join.397:
  %v428 = phi ptr [ %v427, %join.403 ], [ inttoptr (i64 2 to ptr), %no.396 ]
  %v429 = icmp eq ptr %v428, inttoptr (i64 6 to ptr)
  br i1 %v429, label %yes.430, label %no.431
yes.430:
  %v433 = call ptr @mlf_force(ptr %v381)
  %v434 = call ptr @mlf_prim2(i64 10, ptr %v433, ptr inttoptr (i64 13 to ptr))
  %v435 = icmp eq ptr %v434, inttoptr (i64 6 to ptr)
  br i1 %v435, label %yes.436, label %no.437
yes.436:
  %v439 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 6 to ptr))
  br label %join.438
no.437:
  %v444 = call ptr @mlf_env_new(i64 1)
  %v445 = getelementptr i8, ptr %v444, i64 24
  store ptr %v379, ptr %v445, align 8, !tbaa !3
  %v446 = call ptr @mlf_thunk(ptr @mlf.code.440, ptr %v444)
  %v475 = call ptr @mlf_closure(ptr @mlf.code.447, ptr null)
  %v476 = call ptr @mlf_prim2(i64 1, ptr %v446, ptr %v475)
  br label %join.438
join.438:
  %v477 = phi ptr [ %v439, %yes.436 ], [ %v476, %no.437 ]
  br label %join.432
no.431:
  %v478 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 2 to ptr))
  br label %join.432
join.432:
  %v479 = phi ptr [ %v477, %join.438 ], [ %v478, %no.431 ]
  ret ptr %v479
}

define private ptr @mlf.code.357(ptr %env, ptr %arg) {
entry:
  %v358 = getelementptr i8, ptr %env, i64 24
  %v359 = load ptr, ptr %v358, align 8, !tbaa !3
  %v360 = getelementptr i8, ptr %env, i64 32
  %v361 = load ptr, ptr %v360, align 8, !tbaa !3
  %v362 = getelementptr i8, ptr %env, i64 40
  %v363 = load ptr, ptr %v362, align 8, !tbaa !3
  %v364 = getelementptr i8, ptr %env, i64 48
  %v365 = load ptr, ptr %v364, align 8, !tbaa !3
  %v366 = getelementptr i8, ptr %env, i64 56
  %v367 = load ptr, ptr %v366, align 8, !tbaa !3
  %v368 = getelementptr i8, ptr %env, i64 64
  %v369 = load ptr, ptr %v368, align 8, !tbaa !3
  %v374 = call ptr @mlf_env_new(i64 1)
  %v375 = getelementptr i8, ptr %v374, i64 24
  store ptr %v359, ptr %v375, align 8, !tbaa !3
  %v376 = call ptr @mlf_thunk(ptr @mlf.code.370, ptr %v374)
  %v480 = call ptr @mlf_env_new(i64 7)
  %v481 = getelementptr i8, ptr %v480, i64 24
  store ptr %v359, ptr %v481, align 8, !tbaa !3
  %v482 = getelementptr i8, ptr %v480, i64 32
  store ptr %v361, ptr %v482, align 8, !tbaa !3
  %v483 = getelementptr i8, ptr %v480, i64 40
  store ptr %v363, ptr %v483, align 8, !tbaa !3
  %v484 = getelementptr i8, ptr %v480, i64 48
  store ptr %v365, ptr %v484, align 8, !tbaa !3
  %v485 = getelementptr i8, ptr %v480, i64 56
  store ptr %v367, ptr %v485, align 8, !tbaa !3
  %v486 = getelementptr i8, ptr %v480, i64 64
  store ptr %v369, ptr %v486, align 8, !tbaa !3
  %v487 = getelementptr i8, ptr %v480, i64 72
  store ptr %arg, ptr %v487, align 8, !tbaa !3
  %v488 = call ptr @mlf_closure(ptr @mlf.code.377, ptr %v480)
  %v489 = call ptr @mlf_prim2(i64 1, ptr %v376, ptr %v488)
  ret ptr %v489
}

define private ptr @mlf.code.339(ptr %env, ptr %arg) {
entry:
  %v340 = getelementptr i8, ptr %env, i64 24
  %v341 = load ptr, ptr %v340, align 8, !tbaa !3
  %v342 = getelementptr i8, ptr %env, i64 32
  %v343 = load ptr, ptr %v342, align 8, !tbaa !3
  %v344 = getelementptr i8, ptr %env, i64 40
  %v345 = load ptr, ptr %v344, align 8, !tbaa !3
  %v346 = getelementptr i8, ptr %env, i64 48
  %v347 = load ptr, ptr %v346, align 8, !tbaa !3
  %v348 = getelementptr i8, ptr %env, i64 56
  %v349 = load ptr, ptr %v348, align 8, !tbaa !3
  %v354 = call ptr @mlf_env_new(i64 1)
  %v355 = getelementptr i8, ptr %v354, i64 24
  store ptr %v341, ptr %v355, align 8, !tbaa !3
  %v356 = call ptr @mlf_thunk(ptr @mlf.code.350, ptr %v354)
  %v490 = call ptr @mlf_env_new(i64 6)
  %v491 = getelementptr i8, ptr %v490, i64 24
  store ptr %v341, ptr %v491, align 8, !tbaa !3
  %v492 = getelementptr i8, ptr %v490, i64 32
  store ptr %v343, ptr %v492, align 8, !tbaa !3
  %v493 = getelementptr i8, ptr %v490, i64 40
  store ptr %v345, ptr %v493, align 8, !tbaa !3
  %v494 = getelementptr i8, ptr %v490, i64 48
  store ptr %v347, ptr %v494, align 8, !tbaa !3
  %v495 = getelementptr i8, ptr %v490, i64 56
  store ptr %v349, ptr %v495, align 8, !tbaa !3
  %v496 = getelementptr i8, ptr %v490, i64 64
  store ptr %arg, ptr %v496, align 8, !tbaa !3
  %v497 = call ptr @mlf_closure(ptr @mlf.code.357, ptr %v490)
  %v498 = call ptr @mlf_prim2(i64 1, ptr %v356, ptr %v497)
  ret ptr %v498
}

define private ptr @mlf.code.323(ptr %env, ptr %arg) {
entry:
  %v324 = getelementptr i8, ptr %env, i64 24
  %v325 = load ptr, ptr %v324, align 8, !tbaa !3
  %v326 = getelementptr i8, ptr %env, i64 32
  %v327 = load ptr, ptr %v326, align 8, !tbaa !3
  %v328 = getelementptr i8, ptr %env, i64 40
  %v329 = load ptr, ptr %v328, align 8, !tbaa !3
  %v330 = getelementptr i8, ptr %env, i64 48
  %v331 = load ptr, ptr %v330, align 8, !tbaa !3
  %v336 = call ptr @mlf_env_new(i64 1)
  %v337 = getelementptr i8, ptr %v336, i64 24
  store ptr %v325, ptr %v337, align 8, !tbaa !3
  %v338 = call ptr @mlf_thunk(ptr @mlf.code.332, ptr %v336)
  %v499 = call ptr @mlf_env_new(i64 5)
  %v500 = getelementptr i8, ptr %v499, i64 24
  store ptr %v325, ptr %v500, align 8, !tbaa !3
  %v501 = getelementptr i8, ptr %v499, i64 32
  store ptr %v327, ptr %v501, align 8, !tbaa !3
  %v502 = getelementptr i8, ptr %v499, i64 40
  store ptr %v329, ptr %v502, align 8, !tbaa !3
  %v503 = getelementptr i8, ptr %v499, i64 48
  store ptr %v331, ptr %v503, align 8, !tbaa !3
  %v504 = getelementptr i8, ptr %v499, i64 56
  store ptr %arg, ptr %v504, align 8, !tbaa !3
  %v505 = call ptr @mlf_closure(ptr @mlf.code.339, ptr %v499)
  %v506 = call ptr @mlf_prim2(i64 1, ptr %v338, ptr %v505)
  ret ptr %v506
}

define private ptr @mlf.code.309(ptr %env, ptr %arg) {
entry:
  %v310 = getelementptr i8, ptr %env, i64 24
  %v311 = load ptr, ptr %v310, align 8, !tbaa !3
  %v312 = getelementptr i8, ptr %env, i64 32
  %v313 = load ptr, ptr %v312, align 8, !tbaa !3
  %v314 = getelementptr i8, ptr %env, i64 40
  %v315 = load ptr, ptr %v314, align 8, !tbaa !3
  %v320 = call ptr @mlf_env_new(i64 1)
  %v321 = getelementptr i8, ptr %v320, i64 24
  store ptr %v311, ptr %v321, align 8, !tbaa !3
  %v322 = call ptr @mlf_thunk(ptr @mlf.code.316, ptr %v320)
  %v507 = call ptr @mlf_env_new(i64 4)
  %v508 = getelementptr i8, ptr %v507, i64 24
  store ptr %v311, ptr %v508, align 8, !tbaa !3
  %v509 = getelementptr i8, ptr %v507, i64 32
  store ptr %v313, ptr %v509, align 8, !tbaa !3
  %v510 = getelementptr i8, ptr %v507, i64 40
  store ptr %v315, ptr %v510, align 8, !tbaa !3
  %v511 = getelementptr i8, ptr %v507, i64 48
  store ptr %arg, ptr %v511, align 8, !tbaa !3
  %v512 = call ptr @mlf_closure(ptr @mlf.code.323, ptr %v507)
  %v513 = call ptr @mlf_prim2(i64 1, ptr %v322, ptr %v512)
  ret ptr %v513
}

define private ptr @mlf.code.297(ptr %env, ptr %arg) {
entry:
  %v298 = getelementptr i8, ptr %env, i64 24
  %v299 = load ptr, ptr %v298, align 8, !tbaa !3
  %v300 = getelementptr i8, ptr %env, i64 32
  %v301 = load ptr, ptr %v300, align 8, !tbaa !3
  %v306 = call ptr @mlf_env_new(i64 1)
  %v307 = getelementptr i8, ptr %v306, i64 24
  store ptr %v299, ptr %v307, align 8, !tbaa !3
  %v308 = call ptr @mlf_thunk(ptr @mlf.code.302, ptr %v306)
  %v514 = call ptr @mlf_env_new(i64 3)
  %v515 = getelementptr i8, ptr %v514, i64 24
  store ptr %v299, ptr %v515, align 8, !tbaa !3
  %v516 = getelementptr i8, ptr %v514, i64 32
  store ptr %v301, ptr %v516, align 8, !tbaa !3
  %v517 = getelementptr i8, ptr %v514, i64 40
  store ptr %arg, ptr %v517, align 8, !tbaa !3
  %v518 = call ptr @mlf_closure(ptr @mlf.code.309, ptr %v514)
  %v519 = call ptr @mlf_prim2(i64 1, ptr %v308, ptr %v518)
  ret ptr %v519
}

define private ptr @mlf.code.278(ptr %env, ptr %arg) {
entry:
  %v279 = getelementptr i8, ptr %env, i64 24
  %v280 = load ptr, ptr %v279, align 8, !tbaa !3
  %v281 = getelementptr i8, ptr %env, i64 32
  %v282 = load ptr, ptr %v281, align 8, !tbaa !3
  %v283 = call ptr @mlf_force(ptr %v282)
  %v284 = call ptr @mlf_prim2(i64 11, ptr %v283, ptr inttoptr (i64 13 to ptr))
  %v285 = icmp eq ptr %v284, inttoptr (i64 6 to ptr)
  br i1 %v285, label %yes.286, label %no.287
yes.286:
  %v289 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 2 to ptr))
  br label %join.288
no.287:
  %v294 = call ptr @mlf_env_new(i64 1)
  %v295 = getelementptr i8, ptr %v294, i64 24
  store ptr %v280, ptr %v295, align 8, !tbaa !3
  %v296 = call ptr @mlf_thunk(ptr @mlf.code.290, ptr %v294)
  %v520 = call ptr @mlf_env_new(i64 2)
  %v521 = getelementptr i8, ptr %v520, i64 24
  store ptr %v280, ptr %v521, align 8, !tbaa !3
  %v522 = getelementptr i8, ptr %v520, i64 32
  store ptr %v283, ptr %v522, align 8, !tbaa !3
  %v523 = call ptr @mlf_closure(ptr @mlf.code.297, ptr %v520)
  %v524 = call ptr @mlf_prim2(i64 1, ptr %v296, ptr %v523)
  br label %join.288
join.288:
  %v525 = phi ptr [ %v289, %yes.286 ], [ %v524, %no.287 ]
  ret ptr %v525
}

define private ptr @mlf.code.530(ptr %env, ptr %arg) {
entry:
  %v531 = call ptr @mlf_force(ptr %arg)
  %v532 = icmp eq ptr %v531, inttoptr (i64 6 to ptr)
  br i1 %v532, label %yes.533, label %no.534
yes.533:
  %v536 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.535
no.534:
  %v537 = call ptr @mlf_env_new(i64 1)
  %v538 = getelementptr i8, ptr %v537, i64 24
  store ptr inttoptr (i64 4 to ptr), ptr %v538, align 8, !tbaa !3
  %v539 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2, ptr %v537)
  br label %join.535
join.535:
  %v540 = phi ptr [ %v536, %yes.533 ], [ %v539, %no.534 ]
  ret ptr %v540
}

define private ptr @mlf.code.268(ptr %env, ptr %arg) {
entry:
  %v269 = getelementptr i8, ptr %env, i64 24
  %v270 = load ptr, ptr %v269, align 8, !tbaa !3
  %v271 = call ptr @mlf_force(ptr %arg)
  %v272 = call ptr @mlf_prim2(i64 10, ptr %v271, ptr inttoptr (i64 1 to ptr))
  %v273 = icmp eq ptr %v272, inttoptr (i64 6 to ptr)
  br i1 %v273, label %yes.274, label %no.275
yes.274:
  %v277 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.276
no.275:
  %v526 = call ptr @mlf_env_new(i64 2)
  %v527 = getelementptr i8, ptr %v526, i64 24
  store ptr %v270, ptr %v527, align 8, !tbaa !3
  %v528 = getelementptr i8, ptr %v526, i64 32
  store ptr %v271, ptr %v528, align 8, !tbaa !3
  %v529 = call ptr @mlf_thunk(ptr @mlf.code.278, ptr %v526)
  %v541 = call ptr @mlf_closure(ptr @mlf.code.530, ptr null)
  %v542 = call ptr @mlf_prim2(i64 1, ptr %v529, ptr %v541)
  br label %join.276
join.276:
  %v543 = phi ptr [ %v277, %yes.274 ], [ %v542, %no.275 ]
  ret ptr %v543
}

define private ptr @mlf.code.260(ptr %env, ptr %arg) {
entry:
  %v265 = call ptr @mlf_env_new(i64 1)
  %v266 = getelementptr i8, ptr %v265, i64 24
  store ptr %arg, ptr %v266, align 8, !tbaa !3
  %v267 = call ptr @mlf_thunk(ptr @mlf.code.261, ptr %v265)
  %v544 = call ptr @mlf_env_new(i64 1)
  %v545 = getelementptr i8, ptr %v544, i64 24
  store ptr %arg, ptr %v545, align 8, !tbaa !3
  %v546 = call ptr @mlf_closure(ptr @mlf.code.268, ptr %v544)
  %v547 = call ptr @mlf_prim2(i64 1, ptr %v267, ptr %v546)
  ret ptr %v547
}

define private ptr @mlf.worker.25(ptr %a0) {
entry:
  %v259 = call ptr @mlf_primitive(i64 41)
  %v548 = call ptr @mlf_closure(ptr @mlf.code.260, ptr null)
  %v549 = call ptr @mlf_prim2(i64 1, ptr %v259, ptr %v548)
  ret ptr %v549
}

define private ptr @mlf.numeric.entry.2(ptr %env, ptr %arg) {
entry:
  %v3 = getelementptr i8, ptr %env, i64 24
  %v4 = load ptr, ptr %v3, align 8, !tbaa !3
  %v5 = call ptr @mlf_peek(ptr %v4)
  %v6 = icmp ne ptr %v5, null
  %v7 = and i1 true, %v6
  br i1 %v7, label %yes.8, label %no.9
yes.8:
  %v257 = call ptr @mlf.numeric.25(ptr %v5)
  %v258 = call ptr @mlf_prim1(i64 0, ptr %v257)
  br label %join.10
no.9:
  %v550 = call ptr @mlf.worker.25(ptr %v4)
  br label %join.10
join.10:
  %v551 = phi ptr [ %v258, %yes.8 ], [ %v550, %no.9 ]
  ret ptr %v551
}

define private ptr @mlf.code.1(ptr %env, ptr %arg) {
entry:
  %v552 = call ptr @mlf_env_new(i64 1)
  %v553 = getelementptr i8, ptr %v552, i64 24
  store ptr inttoptr (i64 4 to ptr), ptr %v553, align 8, !tbaa !3
  %v554 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2, ptr %v552)
  ret ptr %v554
}

define private ptr @mlf.code.557(ptr %env, ptr %arg) {
entry:
  %v558 = call ptr @mlf_prim2(i64 35, ptr inttoptr (i64 2049 to ptr), ptr inttoptr (i64 1 to ptr))
  ret ptr %v558
}

define private ptr @mlf.numeric.11.pi(ptr %a0, ptr %a1) alwaysinline {
entry:
  %v651 = ptrtoint ptr %a1 to i64
  %v652 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v653 = icmp eq i64 %v651, %v652
  %v654 = select i1 %v653, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v655 = icmp eq ptr %v654, inttoptr (i64 6 to ptr)
  br i1 %v655, label %tail.yes.656, label %tail.no.657
tail.yes.656:
  ret ptr inttoptr (i64 1 to ptr)
tail.no.657:
  %v658 = ptrtoint ptr %a1 to i64
  %v659 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v660 = sub i64 %v659, 1
  %v661 = sub nsw i64 %v658, %v660
  %v662 = inttoptr i64 %v661 to ptr
  %v663 = getelementptr i8, ptr %a0, i64 24
  %v664 = load i64, ptr %v663, align 8, !tbaa !3
  %v665 = getelementptr i8, ptr %a0, i64 32
  %v666 = load ptr, ptr %v665, align 8, !tbaa !3
  %v667 = ptrtoint ptr %v662 to i64
  %v668 = ashr i64 %v667, 1
  %v669 = and i64 %v667, 1
  %v670 = icmp ne i64 %v669, 0
  %v671 = icmp ult i64 %v668, %v664
  %v672 = and i1 %v670, %v671
  br i1 %v672, label %array.valid.673, label %array.invalid.674
array.invalid.674:
  call void @mlf_bounds_failure()
  unreachable
array.valid.673:
  %v675 = getelementptr i8, ptr %v666, i64 %v668
  %v676 = load i8, ptr %v675, align 1, !tbaa !4
  %v677 = zext i8 %v676 to i64
  %v678 = shl i64 %v677, 1
  %v679 = or i64 %v678, 1
  %v680 = inttoptr i64 %v679 to ptr
  %v681 = ptrtoint ptr %v680 to i64
  %v682 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v683 = icmp eq i64 %v681, %v682
  %v684 = select i1 %v683, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v685 = icmp eq ptr %v684, inttoptr (i64 6 to ptr)
  br i1 %v685, label %tail.yes.686, label %tail.no.687
tail.yes.686:
  %v688 = ptrtoint ptr %a1 to i64
  %v689 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v690 = sub i64 %v689, 1
  %v691 = sub nsw i64 %v688, %v690
  %v692 = inttoptr i64 %v691 to ptr
  %v693 = musttail call ptr @mlf.numeric.11.pi(ptr %a0, ptr %v692)
  ret ptr %v693
tail.no.687:
  %v694 = ptrtoint ptr %v680 to i64
  %v695 = ptrtoint ptr inttoptr (i64 27 to ptr) to i64
  %v696 = icmp eq i64 %v694, %v695
  %v697 = select i1 %v696, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v698 = icmp eq ptr %v697, inttoptr (i64 6 to ptr)
  br i1 %v698, label %tail.yes.699, label %tail.no.700
tail.yes.699:
  %v701 = ptrtoint ptr %a1 to i64
  %v702 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v703 = sub i64 %v702, 1
  %v704 = sub nsw i64 %v701, %v703
  %v705 = inttoptr i64 %v704 to ptr
  %v706 = musttail call ptr @mlf.numeric.11.pi(ptr %a0, ptr %v705)
  ret ptr %v706
tail.no.700:
  ret ptr %a1
}

define private ptr @mlf.numeric.11(ptr %a0, ptr %a1) alwaysinline {
entry:
  %v643 = ptrtoint ptr %a1 to i64
  %v644 = and i64 %v643, 1
  %v645 = icmp ne i64 %v644, 0
  %v646 = icmp ult i64 %v643, 4294967296
  %v647 = and i1 %v645, %v646
  %v648 = and i1 true, %v647
  br i1 %v648, label %range.fast.649, label %range.general.650
range.fast.649:
  %v707 = musttail call ptr @mlf.numeric.11.pi(ptr %a0, ptr %a1)
  ret ptr %v707
range.general.650:
  %v708 = ptrtoint ptr %a1 to i64
  %v709 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v710 = and i64 %v708, %v709
  %v711 = and i64 %v710, 1
  %v712 = icmp ne i64 %v711, 0
  br i1 %v712, label %yes.713, label %no.714
yes.713:
  %v716 = icmp eq i64 %v708, %v709
  %v717 = select i1 %v716, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.715
no.714:
  %v718 = call ptr @mlf_eq_int(ptr %a1, ptr inttoptr (i64 1 to ptr))
  br label %join.715
join.715:
  %v719 = phi ptr [ %v717, %yes.713 ], [ %v718, %no.714 ]
  %v720 = icmp eq ptr %v719, inttoptr (i64 6 to ptr)
  br i1 %v720, label %tail.yes.721, label %tail.no.722
tail.yes.721:
  ret ptr inttoptr (i64 1 to ptr)
tail.no.722:
  %v723 = ptrtoint ptr %a1 to i64
  %v724 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v725 = and i64 %v723, %v724
  %v726 = and i64 %v725, 1
  %v727 = icmp ne i64 %v726, 0
  br i1 %v727, label %yes.728, label %no.729
yes.728:
  %v731 = sub i64 %v724, 1
  %v732 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v723, i64 %v731)
  %v733 = extractvalue { i64, i1 } %v732, 0
  %v734 = extractvalue { i64, i1 } %v732, 1
  br i1 %v734, label %yes.735, label %no.736
yes.735:
  %v738 = call ptr @mlf_sub_int(ptr %a1, ptr inttoptr (i64 3 to ptr))
  br label %join.737
no.736:
  %v739 = inttoptr i64 %v733 to ptr
  br label %join.737
join.737:
  %v740 = phi ptr [ %v738, %yes.735 ], [ %v739, %no.736 ]
  br label %join.730
no.729:
  %v741 = call ptr @mlf_sub_int(ptr %a1, ptr inttoptr (i64 3 to ptr))
  br label %join.730
join.730:
  %v742 = phi ptr [ %v740, %join.737 ], [ %v741, %no.729 ]
  %v743 = getelementptr i8, ptr %a0, i64 24
  %v744 = load i64, ptr %v743, align 8, !tbaa !3
  %v745 = getelementptr i8, ptr %a0, i64 32
  %v746 = load ptr, ptr %v745, align 8, !tbaa !3
  %v747 = ptrtoint ptr %v742 to i64
  %v748 = ashr i64 %v747, 1
  %v749 = and i64 %v747, 1
  %v750 = icmp ne i64 %v749, 0
  %v751 = icmp ult i64 %v748, %v744
  %v752 = and i1 %v750, %v751
  br i1 %v752, label %array.valid.753, label %array.invalid.754
array.invalid.754:
  call void @mlf_bounds_failure()
  unreachable
array.valid.753:
  %v755 = getelementptr i8, ptr %v746, i64 %v748
  %v756 = load i8, ptr %v755, align 1, !tbaa !4
  %v757 = zext i8 %v756 to i64
  %v758 = shl i64 %v757, 1
  %v759 = or i64 %v758, 1
  %v760 = inttoptr i64 %v759 to ptr
  %v761 = ptrtoint ptr %v760 to i64
  %v762 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v763 = icmp eq i64 %v761, %v762
  %v764 = select i1 %v763, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v765 = icmp eq ptr %v764, inttoptr (i64 6 to ptr)
  br i1 %v765, label %tail.yes.766, label %tail.no.767
tail.yes.766:
  %v768 = ptrtoint ptr %a1 to i64
  %v769 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v770 = and i64 %v768, %v769
  %v771 = and i64 %v770, 1
  %v772 = icmp ne i64 %v771, 0
  br i1 %v772, label %yes.773, label %no.774
yes.773:
  %v776 = sub i64 %v769, 1
  %v777 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v768, i64 %v776)
  %v778 = extractvalue { i64, i1 } %v777, 0
  %v779 = extractvalue { i64, i1 } %v777, 1
  br i1 %v779, label %yes.780, label %no.781
yes.780:
  %v783 = call ptr @mlf_sub_int(ptr %a1, ptr inttoptr (i64 3 to ptr))
  br label %join.782
no.781:
  %v784 = inttoptr i64 %v778 to ptr
  br label %join.782
join.782:
  %v785 = phi ptr [ %v783, %yes.780 ], [ %v784, %no.781 ]
  br label %join.775
no.774:
  %v786 = call ptr @mlf_sub_int(ptr %a1, ptr inttoptr (i64 3 to ptr))
  br label %join.775
join.775:
  %v787 = phi ptr [ %v785, %join.782 ], [ %v786, %no.774 ]
  %v788 = musttail call ptr @mlf.numeric.11(ptr %a0, ptr %v787)
  ret ptr %v788
tail.no.767:
  %v789 = ptrtoint ptr %v760 to i64
  %v790 = ptrtoint ptr inttoptr (i64 27 to ptr) to i64
  %v791 = icmp eq i64 %v789, %v790
  %v792 = select i1 %v791, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v793 = icmp eq ptr %v792, inttoptr (i64 6 to ptr)
  br i1 %v793, label %tail.yes.794, label %tail.no.795
tail.yes.794:
  %v796 = ptrtoint ptr %a1 to i64
  %v797 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v798 = and i64 %v796, %v797
  %v799 = and i64 %v798, 1
  %v800 = icmp ne i64 %v799, 0
  br i1 %v800, label %yes.801, label %no.802
yes.801:
  %v804 = sub i64 %v797, 1
  %v805 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v796, i64 %v804)
  %v806 = extractvalue { i64, i1 } %v805, 0
  %v807 = extractvalue { i64, i1 } %v805, 1
  br i1 %v807, label %yes.808, label %no.809
yes.808:
  %v811 = call ptr @mlf_sub_int(ptr %a1, ptr inttoptr (i64 3 to ptr))
  br label %join.810
no.809:
  %v812 = inttoptr i64 %v806 to ptr
  br label %join.810
join.810:
  %v813 = phi ptr [ %v811, %yes.808 ], [ %v812, %no.809 ]
  br label %join.803
no.802:
  %v814 = call ptr @mlf_sub_int(ptr %a1, ptr inttoptr (i64 3 to ptr))
  br label %join.803
join.803:
  %v815 = phi ptr [ %v813, %join.810 ], [ %v814, %no.802 ]
  %v816 = musttail call ptr @mlf.numeric.11(ptr %a0, ptr %v815)
  ret ptr %v816
tail.no.795:
  ret ptr %a1
}

define private ptr @mlf.numeric.8(ptr %a0, ptr %a1) alwaysinline {
entry:
  %v853 = ptrtoint ptr %a0 to i64
  %v854 = ptrtoint ptr %a1 to i64
  %v855 = and i64 %v853, %v854
  %v856 = and i64 %v855, 1
  %v857 = icmp ne i64 %v856, 0
  br i1 %v857, label %yes.858, label %no.859
yes.858:
  %v861 = icmp slt i64 %v853, %v854
  %v862 = select i1 %v861, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.860
no.859:
  %v863 = call ptr @mlf_lt_int(ptr %a0, ptr %a1)
  br label %join.860
join.860:
  %v864 = phi ptr [ %v862, %yes.858 ], [ %v863, %no.859 ]
  %v865 = icmp eq ptr %v864, inttoptr (i64 6 to ptr)
  br i1 %v865, label %tail.yes.866, label %tail.no.867
tail.yes.866:
  %v868 = ptrtoint ptr %a0 to i64
  %v869 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v870 = and i64 %v868, %v869
  %v871 = and i64 %v870, 1
  %v872 = icmp ne i64 %v871, 0
  br i1 %v872, label %yes.873, label %no.874
yes.873:
  %v876 = ashr i64 %v868, 1
  %v877 = ashr i64 %v869, 1
  %v878 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v876, i64 %v877)
  %v879 = extractvalue { i64, i1 } %v878, 0
  %v880 = extractvalue { i64, i1 } %v878, 1
  %v881 = xor i1 %v880, true
  %v882 = icmp sge i64 %v879, -4611686018427387904
  %v883 = icmp sle i64 %v879, 4611686018427387903
  %v884 = and i1 %v882, %v883
  %v885 = and i1 %v884, %v881
  br i1 %v885, label %yes.886, label %no.887
yes.886:
  %v889 = shl i64 %v879, 1
  %v890 = or i64 %v889, 1
  %v891 = inttoptr i64 %v890 to ptr
  br label %join.888
no.887:
  %v892 = call ptr @mlf_prim2(i64 14, ptr %a0, ptr inttoptr (i64 5 to ptr))
  br label %join.888
join.888:
  %v893 = phi ptr [ %v891, %yes.886 ], [ %v892, %no.887 ]
  br label %join.875
no.874:
  %v894 = call ptr @mlf_prim2(i64 14, ptr %a0, ptr inttoptr (i64 5 to ptr))
  br label %join.875
join.875:
  %v895 = phi ptr [ %v893, %join.888 ], [ %v894, %no.874 ]
  %v896 = musttail call ptr @mlf.numeric.8(ptr %v895, ptr %a1)
  ret ptr %v896
tail.no.867:
  ret ptr %a0
}

define private ptr @mlf.numeric.0(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) alwaysinline {
entry:
  %v899 = getelementptr i8, ptr %a0, i64 24
  %v900 = load i64, ptr %v899, align 8, !tbaa !3
  %v901 = getelementptr i8, ptr %a0, i64 32
  %v902 = load ptr, ptr %v901, align 8, !tbaa !3
  %v903 = getelementptr i8, ptr %a1, i64 24
  %v904 = load i64, ptr %v903, align 8, !tbaa !3
  %v905 = getelementptr i8, ptr %a1, i64 32
  %v906 = load ptr, ptr %v905, align 8, !tbaa !3
  %v907 = ptrtoint ptr %a2 to i64
  %v908 = ptrtoint ptr %a3 to i64
  %v909 = ptrtoint ptr %a4 to i64
  %v910 = and i64 %v907, 1
  %v911 = icmp ne i64 %v910, 0
  %v912 = and i64 %v908, 1
  %v913 = icmp ne i64 %v912, 0
  %v914 = and i64 %v909, 1
  %v915 = icmp ne i64 %v914, 0
  %v916 = ashr i64 %v907, 1
  %v917 = ashr i64 %v908, 1
  %v918 = ashr i64 %v909, 1
  %v919 = icmp sge i64 %v918, 0
  %v920 = icmp sge i64 %v916, %v918
  %v921 = icmp ule i64 %v916, %v900
  %v922 = icmp ule i64 %v917, %v904
  %v923 = sub i64 %v904, %v917
  %v924 = icmp ule i64 %v916, %v923
  %v925 = sub i64 %v916, %v918
  %v926 = icmp ne ptr %v902, %v906
  %v927 = icmp eq i64 %v917, 0
  %v928 = icmp uge i64 %v917, %v925
  %v929 = or i1 %v926, %v927
  %v930 = or i1 %v929, %v928
  %v931 = and i1 true, %v911
  %v932 = and i1 %v931, %v913
  %v933 = and i1 %v932, %v915
  %v934 = and i1 %v933, %v919
  %v935 = and i1 %v934, %v920
  %v936 = and i1 %v935, %v921
  %v937 = and i1 %v936, %v922
  %v938 = and i1 %v937, %v924
  %v939 = and i1 %v938, %v930
  br i1 %v939, label %copy.bulk.940, label %copy.scalar.941
copy.bulk.940:
  %v942 = getelementptr i8, ptr %v902, i64 %v918
  %v943 = add i64 %v917, %v918
  %v944 = getelementptr i8, ptr %v906, i64 %v943
  call void @llvm.memmove.p0.p0.i64(ptr %v944, ptr %v942, i64 %v925, i1 false)
  ret ptr inttoptr (i64 4 to ptr)
copy.scalar.941:
  %v945 = ptrtoint ptr %a4 to i64
  %v946 = ptrtoint ptr %a2 to i64
  %v947 = and i64 %v945, %v946
  %v948 = and i64 %v947, 1
  %v949 = icmp ne i64 %v948, 0
  br i1 %v949, label %yes.950, label %no.951
yes.950:
  %v953 = icmp slt i64 %v945, %v946
  %v954 = select i1 %v953, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.952
no.951:
  %v955 = call ptr @mlf_lt_int(ptr %a4, ptr %a2)
  br label %join.952
join.952:
  %v956 = phi ptr [ %v954, %yes.950 ], [ %v955, %no.951 ]
  %v957 = icmp eq ptr %v956, inttoptr (i64 6 to ptr)
  br i1 %v957, label %tail.yes.958, label %tail.no.959
tail.yes.958:
  %v960 = ptrtoint ptr %a4 to i64
  %v961 = ashr i64 %v960, 1
  %v962 = and i64 %v960, 1
  %v963 = icmp ne i64 %v962, 0
  %v964 = icmp ult i64 %v961, %v900
  %v965 = and i1 %v963, %v964
  br i1 %v965, label %array.valid.966, label %array.invalid.967
array.invalid.967:
  call void @mlf_bounds_failure()
  unreachable
array.valid.966:
  %v968 = getelementptr i8, ptr %v902, i64 %v961
  %v969 = load i8, ptr %v968, align 1, !tbaa !4
  %v970 = zext i8 %v969 to i64
  %v971 = shl i64 %v970, 1
  %v972 = or i64 %v971, 1
  %v973 = inttoptr i64 %v972 to ptr
  %v974 = ptrtoint ptr %a3 to i64
  %v975 = ptrtoint ptr %a4 to i64
  %v976 = and i64 %v974, %v975
  %v977 = and i64 %v976, 1
  %v978 = icmp ne i64 %v977, 0
  br i1 %v978, label %yes.979, label %no.980
yes.979:
  %v982 = sub i64 %v975, 1
  %v983 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v974, i64 %v982)
  %v984 = extractvalue { i64, i1 } %v983, 0
  %v985 = extractvalue { i64, i1 } %v983, 1
  br i1 %v985, label %yes.986, label %no.987
yes.986:
  %v989 = call ptr @mlf_add_int(ptr %a3, ptr %a4)
  br label %join.988
no.987:
  %v990 = inttoptr i64 %v984 to ptr
  br label %join.988
join.988:
  %v991 = phi ptr [ %v989, %yes.986 ], [ %v990, %no.987 ]
  br label %join.981
no.980:
  %v992 = call ptr @mlf_add_int(ptr %a3, ptr %a4)
  br label %join.981
join.981:
  %v993 = phi ptr [ %v991, %join.988 ], [ %v992, %no.980 ]
  %v994 = ptrtoint ptr %v993 to i64
  %v995 = ashr i64 %v994, 1
  %v996 = and i64 %v994, 1
  %v997 = icmp ne i64 %v996, 0
  %v998 = icmp ult i64 %v995, %v904
  %v999 = and i1 %v997, %v998
  br i1 %v999, label %array.valid.1000, label %array.invalid.1001
array.invalid.1001:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1000:
  %v1002 = getelementptr i8, ptr %v906, i64 %v995
  %v1003 = ptrtoint ptr %v973 to i64
  %v1004 = ashr i64 %v1003, 1
  %v1005 = trunc i64 %v1004 to i8
  store i8 %v1005, ptr %v1002, align 1, !tbaa !4
  %v1006 = ptrtoint ptr %a4 to i64
  %v1007 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1008 = sub i64 %v1007, 1
  %v1009 = add nsw i64 %v1006, %v1008
  %v1010 = inttoptr i64 %v1009 to ptr
  %v1011 = musttail call ptr @mlf.numeric.0(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %v1010)
  ret ptr %v1011
tail.no.959:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.numeric.17.ppiii(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) alwaysinline {
entry:
  %v1033 = ptrtoint ptr %a4 to i64
  %v1034 = ptrtoint ptr %a2 to i64
  %v1035 = icmp slt i64 %v1033, %v1034
  %v1036 = select i1 %v1035, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1037 = icmp eq ptr %v1036, inttoptr (i64 6 to ptr)
  br i1 %v1037, label %tail.yes.1038, label %tail.no.1039
tail.yes.1038:
  %v1040 = getelementptr i8, ptr %a0, i64 24
  %v1041 = load i64, ptr %v1040, align 8, !tbaa !3
  %v1042 = getelementptr i8, ptr %a0, i64 32
  %v1043 = load ptr, ptr %v1042, align 8, !tbaa !3
  %v1044 = ptrtoint ptr %a4 to i64
  %v1045 = ashr i64 %v1044, 1
  %v1046 = and i64 %v1044, 1
  %v1047 = icmp ne i64 %v1046, 0
  %v1048 = icmp ult i64 %v1045, %v1041
  %v1049 = and i1 %v1047, %v1048
  br i1 %v1049, label %array.valid.1050, label %array.invalid.1051
array.invalid.1051:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1050:
  %v1052 = getelementptr i8, ptr %v1043, i64 %v1045
  %v1053 = load i8, ptr %v1052, align 1, !tbaa !4
  %v1054 = zext i8 %v1053 to i64
  %v1055 = shl i64 %v1054, 1
  %v1056 = or i64 %v1055, 1
  %v1057 = inttoptr i64 %v1056 to ptr
  %v1058 = ptrtoint ptr %a3 to i64
  %v1059 = ptrtoint ptr %a4 to i64
  %v1060 = sub i64 %v1059, 1
  %v1061 = add nsw i64 %v1058, %v1060
  %v1062 = inttoptr i64 %v1061 to ptr
  %v1063 = ptrtoint ptr %v1057 to i64
  %v1064 = ptrtoint ptr inttoptr (i64 131 to ptr) to i64
  %v1065 = icmp eq i64 %v1063, %v1064
  %v1066 = select i1 %v1065, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1067 = icmp eq ptr %v1066, inttoptr (i64 6 to ptr)
  br i1 %v1067, label %yes.1068, label %no.1069
yes.1068:
  br label %join.1070
no.1069:
  %v1071 = ptrtoint ptr %v1057 to i64
  %v1072 = ptrtoint ptr inttoptr (i64 195 to ptr) to i64
  %v1073 = icmp eq i64 %v1071, %v1072
  %v1074 = select i1 %v1073, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1075 = icmp eq ptr %v1074, inttoptr (i64 6 to ptr)
  br i1 %v1075, label %yes.1076, label %no.1077
yes.1076:
  br label %join.1078
no.1077:
  %v1079 = ptrtoint ptr %v1057 to i64
  %v1080 = ptrtoint ptr inttoptr (i64 135 to ptr) to i64
  %v1081 = icmp eq i64 %v1079, %v1080
  %v1082 = select i1 %v1081, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1083 = icmp eq ptr %v1082, inttoptr (i64 6 to ptr)
  br i1 %v1083, label %yes.1084, label %no.1085
yes.1084:
  br label %join.1086
no.1085:
  %v1087 = ptrtoint ptr %v1057 to i64
  %v1088 = ptrtoint ptr inttoptr (i64 199 to ptr) to i64
  %v1089 = icmp eq i64 %v1087, %v1088
  %v1090 = select i1 %v1089, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1091 = icmp eq ptr %v1090, inttoptr (i64 6 to ptr)
  br i1 %v1091, label %yes.1092, label %no.1093
yes.1092:
  br label %join.1094
no.1093:
  %v1095 = ptrtoint ptr %v1057 to i64
  %v1096 = ptrtoint ptr inttoptr (i64 143 to ptr) to i64
  %v1097 = icmp eq i64 %v1095, %v1096
  %v1098 = select i1 %v1097, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1099 = icmp eq ptr %v1098, inttoptr (i64 6 to ptr)
  br i1 %v1099, label %yes.1100, label %no.1101
yes.1100:
  br label %join.1102
no.1101:
  %v1103 = ptrtoint ptr %v1057 to i64
  %v1104 = ptrtoint ptr inttoptr (i64 207 to ptr) to i64
  %v1105 = icmp eq i64 %v1103, %v1104
  %v1106 = select i1 %v1105, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1107 = icmp eq ptr %v1106, inttoptr (i64 6 to ptr)
  br i1 %v1107, label %yes.1108, label %no.1109
yes.1108:
  br label %join.1110
no.1109:
  br label %join.1110
join.1110:
  %v1111 = phi ptr [ inttoptr (i64 5 to ptr), %yes.1108 ], [ inttoptr (i64 7 to ptr), %no.1109 ]
  br label %join.1102
join.1102:
  %v1112 = phi ptr [ inttoptr (i64 5 to ptr), %yes.1100 ], [ %v1111, %join.1110 ]
  br label %join.1094
join.1094:
  %v1113 = phi ptr [ inttoptr (i64 3 to ptr), %yes.1092 ], [ %v1112, %join.1102 ]
  br label %join.1086
join.1086:
  %v1114 = phi ptr [ inttoptr (i64 3 to ptr), %yes.1084 ], [ %v1113, %join.1094 ]
  br label %join.1078
join.1078:
  %v1115 = phi ptr [ inttoptr (i64 1 to ptr), %yes.1076 ], [ %v1114, %join.1086 ]
  br label %join.1070
join.1070:
  %v1116 = phi ptr [ inttoptr (i64 1 to ptr), %yes.1068 ], [ %v1115, %join.1078 ]
  %v1117 = getelementptr i8, ptr %a1, i64 24
  %v1118 = load i64, ptr %v1117, align 8, !tbaa !3
  %v1119 = getelementptr i8, ptr %a1, i64 32
  %v1120 = load ptr, ptr %v1119, align 8, !tbaa !3
  %v1121 = ptrtoint ptr %v1062 to i64
  %v1122 = ashr i64 %v1121, 1
  %v1123 = and i64 %v1121, 1
  %v1124 = icmp ne i64 %v1123, 0
  %v1125 = icmp ult i64 %v1122, %v1118
  %v1126 = and i1 %v1124, %v1125
  br i1 %v1126, label %array.valid.1127, label %array.invalid.1128
array.invalid.1128:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1127:
  %v1129 = getelementptr i8, ptr %v1120, i64 %v1122
  %v1130 = ptrtoint ptr %v1116 to i64
  %v1131 = ashr i64 %v1130, 1
  %v1132 = trunc i64 %v1131 to i8
  store i8 %v1132, ptr %v1129, align 1, !tbaa !4
  %v1133 = ptrtoint ptr %a4 to i64
  %v1134 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1135 = sub i64 %v1134, 1
  %v1136 = add nsw i64 %v1133, %v1135
  %v1137 = inttoptr i64 %v1136 to ptr
  %v1138 = musttail call ptr @mlf.numeric.17.ppiii(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %v1137)
  ret ptr %v1138
tail.no.1039:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.numeric.17(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) alwaysinline {
entry:
  %v1013 = ptrtoint ptr %a2 to i64
  %v1014 = and i64 %v1013, 1
  %v1015 = icmp ne i64 %v1014, 0
  %v1016 = icmp ult i64 %v1013, 4294967296
  %v1017 = and i1 %v1015, %v1016
  %v1018 = ptrtoint ptr %a3 to i64
  %v1019 = and i64 %v1018, 1
  %v1020 = icmp ne i64 %v1019, 0
  %v1021 = icmp ult i64 %v1018, 4294967296
  %v1022 = and i1 %v1020, %v1021
  %v1023 = ptrtoint ptr %a4 to i64
  %v1024 = and i64 %v1023, 1
  %v1025 = icmp ne i64 %v1024, 0
  %v1026 = icmp ult i64 %v1023, 4294967296
  %v1027 = and i1 %v1025, %v1026
  %v1028 = and i1 true, %v1017
  %v1029 = and i1 %v1028, %v1022
  %v1030 = and i1 %v1029, %v1027
  br i1 %v1030, label %range.fast.1031, label %range.general.1032
range.fast.1031:
  %v1139 = musttail call ptr @mlf.numeric.17.ppiii(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4)
  ret ptr %v1139
range.general.1032:
  %v1140 = ptrtoint ptr %a4 to i64
  %v1141 = ptrtoint ptr %a2 to i64
  %v1142 = and i64 %v1140, %v1141
  %v1143 = and i64 %v1142, 1
  %v1144 = icmp ne i64 %v1143, 0
  br i1 %v1144, label %yes.1145, label %no.1146
yes.1145:
  %v1148 = icmp slt i64 %v1140, %v1141
  %v1149 = select i1 %v1148, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1147
no.1146:
  %v1150 = call ptr @mlf_lt_int(ptr %a4, ptr %a2)
  br label %join.1147
join.1147:
  %v1151 = phi ptr [ %v1149, %yes.1145 ], [ %v1150, %no.1146 ]
  %v1152 = icmp eq ptr %v1151, inttoptr (i64 6 to ptr)
  br i1 %v1152, label %tail.yes.1153, label %tail.no.1154
tail.yes.1153:
  %v1155 = getelementptr i8, ptr %a0, i64 24
  %v1156 = load i64, ptr %v1155, align 8, !tbaa !3
  %v1157 = getelementptr i8, ptr %a0, i64 32
  %v1158 = load ptr, ptr %v1157, align 8, !tbaa !3
  %v1159 = ptrtoint ptr %a4 to i64
  %v1160 = ashr i64 %v1159, 1
  %v1161 = and i64 %v1159, 1
  %v1162 = icmp ne i64 %v1161, 0
  %v1163 = icmp ult i64 %v1160, %v1156
  %v1164 = and i1 %v1162, %v1163
  br i1 %v1164, label %array.valid.1165, label %array.invalid.1166
array.invalid.1166:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1165:
  %v1167 = getelementptr i8, ptr %v1158, i64 %v1160
  %v1168 = load i8, ptr %v1167, align 1, !tbaa !4
  %v1169 = zext i8 %v1168 to i64
  %v1170 = shl i64 %v1169, 1
  %v1171 = or i64 %v1170, 1
  %v1172 = inttoptr i64 %v1171 to ptr
  %v1173 = ptrtoint ptr %a3 to i64
  %v1174 = ptrtoint ptr %a4 to i64
  %v1175 = and i64 %v1173, %v1174
  %v1176 = and i64 %v1175, 1
  %v1177 = icmp ne i64 %v1176, 0
  br i1 %v1177, label %yes.1178, label %no.1179
yes.1178:
  %v1181 = sub i64 %v1174, 1
  %v1182 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1173, i64 %v1181)
  %v1183 = extractvalue { i64, i1 } %v1182, 0
  %v1184 = extractvalue { i64, i1 } %v1182, 1
  br i1 %v1184, label %yes.1185, label %no.1186
yes.1185:
  %v1188 = call ptr @mlf_add_int(ptr %a3, ptr %a4)
  br label %join.1187
no.1186:
  %v1189 = inttoptr i64 %v1183 to ptr
  br label %join.1187
join.1187:
  %v1190 = phi ptr [ %v1188, %yes.1185 ], [ %v1189, %no.1186 ]
  br label %join.1180
no.1179:
  %v1191 = call ptr @mlf_add_int(ptr %a3, ptr %a4)
  br label %join.1180
join.1180:
  %v1192 = phi ptr [ %v1190, %join.1187 ], [ %v1191, %no.1179 ]
  %v1193 = ptrtoint ptr %v1172 to i64
  %v1194 = ptrtoint ptr inttoptr (i64 131 to ptr) to i64
  %v1195 = icmp eq i64 %v1193, %v1194
  %v1196 = select i1 %v1195, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1197 = icmp eq ptr %v1196, inttoptr (i64 6 to ptr)
  br i1 %v1197, label %yes.1198, label %no.1199
yes.1198:
  br label %join.1200
no.1199:
  %v1201 = ptrtoint ptr %v1172 to i64
  %v1202 = ptrtoint ptr inttoptr (i64 195 to ptr) to i64
  %v1203 = icmp eq i64 %v1201, %v1202
  %v1204 = select i1 %v1203, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1205 = icmp eq ptr %v1204, inttoptr (i64 6 to ptr)
  br i1 %v1205, label %yes.1206, label %no.1207
yes.1206:
  br label %join.1208
no.1207:
  %v1209 = ptrtoint ptr %v1172 to i64
  %v1210 = ptrtoint ptr inttoptr (i64 135 to ptr) to i64
  %v1211 = icmp eq i64 %v1209, %v1210
  %v1212 = select i1 %v1211, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1213 = icmp eq ptr %v1212, inttoptr (i64 6 to ptr)
  br i1 %v1213, label %yes.1214, label %no.1215
yes.1214:
  br label %join.1216
no.1215:
  %v1217 = ptrtoint ptr %v1172 to i64
  %v1218 = ptrtoint ptr inttoptr (i64 199 to ptr) to i64
  %v1219 = icmp eq i64 %v1217, %v1218
  %v1220 = select i1 %v1219, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1221 = icmp eq ptr %v1220, inttoptr (i64 6 to ptr)
  br i1 %v1221, label %yes.1222, label %no.1223
yes.1222:
  br label %join.1224
no.1223:
  %v1225 = ptrtoint ptr %v1172 to i64
  %v1226 = ptrtoint ptr inttoptr (i64 143 to ptr) to i64
  %v1227 = icmp eq i64 %v1225, %v1226
  %v1228 = select i1 %v1227, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1229 = icmp eq ptr %v1228, inttoptr (i64 6 to ptr)
  br i1 %v1229, label %yes.1230, label %no.1231
yes.1230:
  br label %join.1232
no.1231:
  %v1233 = ptrtoint ptr %v1172 to i64
  %v1234 = ptrtoint ptr inttoptr (i64 207 to ptr) to i64
  %v1235 = icmp eq i64 %v1233, %v1234
  %v1236 = select i1 %v1235, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1237 = icmp eq ptr %v1236, inttoptr (i64 6 to ptr)
  br i1 %v1237, label %yes.1238, label %no.1239
yes.1238:
  br label %join.1240
no.1239:
  br label %join.1240
join.1240:
  %v1241 = phi ptr [ inttoptr (i64 5 to ptr), %yes.1238 ], [ inttoptr (i64 7 to ptr), %no.1239 ]
  br label %join.1232
join.1232:
  %v1242 = phi ptr [ inttoptr (i64 5 to ptr), %yes.1230 ], [ %v1241, %join.1240 ]
  br label %join.1224
join.1224:
  %v1243 = phi ptr [ inttoptr (i64 3 to ptr), %yes.1222 ], [ %v1242, %join.1232 ]
  br label %join.1216
join.1216:
  %v1244 = phi ptr [ inttoptr (i64 3 to ptr), %yes.1214 ], [ %v1243, %join.1224 ]
  br label %join.1208
join.1208:
  %v1245 = phi ptr [ inttoptr (i64 1 to ptr), %yes.1206 ], [ %v1244, %join.1216 ]
  br label %join.1200
join.1200:
  %v1246 = phi ptr [ inttoptr (i64 1 to ptr), %yes.1198 ], [ %v1245, %join.1208 ]
  %v1247 = getelementptr i8, ptr %a1, i64 24
  %v1248 = load i64, ptr %v1247, align 8, !tbaa !3
  %v1249 = getelementptr i8, ptr %a1, i64 32
  %v1250 = load ptr, ptr %v1249, align 8, !tbaa !3
  %v1251 = ptrtoint ptr %v1192 to i64
  %v1252 = ashr i64 %v1251, 1
  %v1253 = and i64 %v1251, 1
  %v1254 = icmp ne i64 %v1253, 0
  %v1255 = icmp ult i64 %v1252, %v1248
  %v1256 = and i1 %v1254, %v1255
  br i1 %v1256, label %array.valid.1257, label %array.invalid.1258
array.invalid.1258:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1257:
  %v1259 = getelementptr i8, ptr %v1250, i64 %v1252
  %v1260 = ptrtoint ptr %v1246 to i64
  %v1261 = ashr i64 %v1260, 1
  %v1262 = trunc i64 %v1261 to i8
  store i8 %v1262, ptr %v1259, align 1, !tbaa !4
  %v1263 = ptrtoint ptr %a4 to i64
  %v1264 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1265 = sub i64 %v1264, 1
  %v1266 = add nsw i64 %v1263, %v1265
  %v1267 = inttoptr i64 %v1266 to ptr
  %v1268 = musttail call ptr @mlf.numeric.17(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %v1267)
  ret ptr %v1268
tail.no.1154:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.numeric.38(ptr %a0, ptr %a1, ptr %a2) {
entry:
  %v583 = alloca [3 x ptr], align 8
  %v584 = getelementptr ptr, ptr %v583, i64 0
  store ptr %a0, ptr %v584, align 8
  %v585 = getelementptr ptr, ptr %v583, i64 1
  store ptr %a1, ptr %v585, align 8
  %v586 = getelementptr ptr, ptr %v583, i64 2
  store ptr %a2, ptr %v586, align 8
  call void @mlf_gc_check(i64 3, ptr %v583)
  %v587 = call ptr @mlf_get_byte_line()
  %v588 = getelementptr i8, ptr %v587, i64 24
  %v589 = load i64, ptr %v588, align 8, !tbaa !3
  %v590 = getelementptr i8, ptr %v587, i64 32
  %v591 = load ptr, ptr %v590, align 8, !tbaa !3
  %v592 = shl i64 %v589, 1
  %v593 = or i64 %v592, 1
  %v594 = inttoptr i64 %v593 to ptr
  %v595 = ptrtoint ptr %v594 to i64
  %v596 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v597 = and i64 %v595, %v596
  %v598 = and i64 %v597, 1
  %v599 = icmp ne i64 %v598, 0
  br i1 %v599, label %yes.600, label %no.601
yes.600:
  %v603 = icmp eq i64 %v595, %v596
  %v604 = select i1 %v603, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.602
no.601:
  %v605 = call ptr @mlf_eq_int(ptr %v594, ptr inttoptr (i64 1 to ptr))
  br label %join.602
join.602:
  %v606 = phi ptr [ %v604, %yes.600 ], [ %v605, %no.601 ]
  %v607 = icmp eq ptr %v606, inttoptr (i64 6 to ptr)
  br i1 %v607, label %tail.yes.608, label %tail.no.609
tail.yes.608:
  %v610 = call ptr @mlf_constructor_new(i64 1, i64 3)
  %v611 = getelementptr i8, ptr %v610, i64 40
  %v612 = load ptr, ptr %v611, align 8, !tbaa !3
  %v613 = getelementptr i8, ptr %v612, i64 24
  store ptr %a0, ptr %v613, align 8, !tbaa !3
  %v614 = getelementptr i8, ptr %v612, i64 32
  store ptr %a1, ptr %v614, align 8, !tbaa !3
  %v615 = getelementptr i8, ptr %v612, i64 40
  store ptr %a2, ptr %v615, align 8, !tbaa !3
  ret ptr %v610
tail.no.609:
  %v616 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v617 = ashr i64 %v616, 1
  %v618 = and i64 %v616, 1
  %v619 = icmp ne i64 %v618, 0
  %v620 = icmp ult i64 %v617, %v589
  %v621 = and i1 %v619, %v620
  br i1 %v621, label %array.valid.622, label %array.invalid.623
array.invalid.623:
  call void @mlf_bounds_failure()
  unreachable
array.valid.622:
  %v624 = getelementptr i8, ptr %v591, i64 %v617
  %v625 = load i8, ptr %v624, align 1, !tbaa !4
  %v626 = zext i8 %v625 to i64
  %v627 = shl i64 %v626, 1
  %v628 = or i64 %v627, 1
  %v629 = inttoptr i64 %v628 to ptr
  %v630 = ptrtoint ptr %v629 to i64
  %v631 = ptrtoint ptr inttoptr (i64 125 to ptr) to i64
  %v632 = icmp eq i64 %v630, %v631
  %v633 = select i1 %v632, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v634 = icmp eq ptr %v633, inttoptr (i64 6 to ptr)
  br i1 %v634, label %tail.yes.635, label %tail.no.636
tail.yes.635:
  %v637 = call ptr @mlf_constructor_new(i64 1, i64 3)
  %v638 = getelementptr i8, ptr %v637, i64 40
  %v639 = load ptr, ptr %v638, align 8, !tbaa !3
  %v640 = getelementptr i8, ptr %v639, i64 24
  store ptr %a0, ptr %v640, align 8, !tbaa !3
  %v641 = getelementptr i8, ptr %v639, i64 32
  store ptr %a1, ptr %v641, align 8, !tbaa !3
  %v642 = getelementptr i8, ptr %v639, i64 40
  store ptr %a2, ptr %v642, align 8, !tbaa !3
  ret ptr %v637
tail.no.636:
  %v817 = call ptr @mlf.numeric.11(ptr %v587, ptr %v594)
  %v818 = ptrtoint ptr %a1 to i64
  %v819 = ptrtoint ptr %v817 to i64
  %v820 = and i64 %v818, %v819
  %v821 = and i64 %v820, 1
  %v822 = icmp ne i64 %v821, 0
  br i1 %v822, label %yes.823, label %no.824
yes.823:
  %v826 = sub i64 %v819, 1
  %v827 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v818, i64 %v826)
  %v828 = extractvalue { i64, i1 } %v827, 0
  %v829 = extractvalue { i64, i1 } %v827, 1
  br i1 %v829, label %yes.830, label %no.831
yes.830:
  %v833 = call ptr @mlf_add_int(ptr %a1, ptr %v817)
  br label %join.832
no.831:
  %v834 = inttoptr i64 %v828 to ptr
  br label %join.832
join.832:
  %v835 = phi ptr [ %v833, %yes.830 ], [ %v834, %no.831 ]
  br label %join.825
no.824:
  %v836 = call ptr @mlf_add_int(ptr %a1, ptr %v817)
  br label %join.825
join.825:
  %v837 = phi ptr [ %v835, %join.832 ], [ %v836, %no.824 ]
  %v838 = ptrtoint ptr %a2 to i64
  %v839 = ptrtoint ptr %v837 to i64
  %v840 = and i64 %v838, %v839
  %v841 = and i64 %v840, 1
  %v842 = icmp ne i64 %v841, 0
  br i1 %v842, label %yes.843, label %no.844
yes.843:
  %v846 = icmp slt i64 %v838, %v839
  %v847 = select i1 %v846, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.845
no.844:
  %v848 = call ptr @mlf_lt_int(ptr %a2, ptr %v837)
  br label %join.845
join.845:
  %v849 = phi ptr [ %v847, %yes.843 ], [ %v848, %no.844 ]
  %v850 = icmp eq ptr %v849, inttoptr (i64 6 to ptr)
  br i1 %v850, label %tail.yes.851, label %tail.no.852
tail.yes.851:
  %v897 = call ptr @mlf.numeric.8(ptr %a2, ptr %v837)
  %v898 = call ptr @mlf_new_array(i64 35, ptr %v897, ptr inttoptr (i64 1 to ptr))
  %v1012 = call ptr @mlf.numeric.0(ptr %a0, ptr %v898, ptr %a1, ptr inttoptr (i64 1 to ptr), ptr inttoptr (i64 1 to ptr))
  %v1269 = call ptr @mlf.numeric.17(ptr %v587, ptr %v898, ptr %v817, ptr %a1, ptr inttoptr (i64 1 to ptr))
  %v1270 = musttail call ptr @mlf.numeric.38(ptr %v898, ptr %v837, ptr %v897)
  ret ptr %v1270
tail.no.852:
  %v1271 = call ptr @mlf.numeric.17(ptr %v587, ptr %a0, ptr %v817, ptr %a1, ptr inttoptr (i64 1 to ptr))
  %v1272 = musttail call ptr @mlf.numeric.38(ptr %a0, ptr %v837, ptr %a2)
  ret ptr %v1272
}

define private ptr @mlf.code.1283(ptr %env, ptr %arg) {
entry:
  %v1284 = getelementptr i8, ptr %env, i64 24
  %v1285 = load ptr, ptr %v1284, align 8, !tbaa !3
  %v1286 = call ptr @mlf_prim1(i64 38, ptr %v1285)
  ret ptr %v1286
}

define private ptr @mlf.code.1312(ptr %env, ptr %arg) {
entry:
  %v1313 = getelementptr i8, ptr %env, i64 24
  %v1314 = load ptr, ptr %v1313, align 8, !tbaa !3
  %v1315 = call ptr @mlf_prim2(i64 36, ptr %v1314, ptr inttoptr (i64 1 to ptr))
  ret ptr %v1315
}

define private ptr @mlf.code.1375(ptr %env, ptr %arg) {
entry:
  %v1376 = getelementptr i8, ptr %env, i64 24
  %v1377 = load ptr, ptr %v1376, align 8, !tbaa !3
  %v1378 = call ptr @mlf_force(ptr %v1377)
  %v1379 = call ptr @mlf_prim2(i64 9, ptr %v1378, ptr inttoptr (i64 3 to ptr))
  ret ptr %v1379
}

define private ptr @mlf.code.1370(ptr %env, ptr %arg) {
entry:
  %v1371 = getelementptr i8, ptr %env, i64 24
  %v1372 = load ptr, ptr %v1371, align 8, !tbaa !3
  %v1373 = getelementptr i8, ptr %env, i64 32
  %v1374 = load ptr, ptr %v1373, align 8, !tbaa !3
  %v1380 = call ptr @mlf_env_new(i64 1)
  %v1381 = getelementptr i8, ptr %v1380, i64 24
  store ptr %v1374, ptr %v1381, align 8, !tbaa !3
  %v1382 = call ptr @mlf_thunk(ptr @mlf.code.1375, ptr %v1380)
  %v1383 = call ptr @mlf_prim2(i64 36, ptr %v1372, ptr %v1382)
  ret ptr %v1383
}

define private ptr @mlf.code.1388(ptr %env, ptr %arg) {
entry:
  %v1389 = getelementptr i8, ptr %env, i64 24
  %v1390 = load ptr, ptr %v1389, align 8, !tbaa !3
  %v1391 = getelementptr i8, ptr %env, i64 32
  %v1392 = load ptr, ptr %v1391, align 8, !tbaa !3
  %v1393 = call ptr @mlf_force(ptr %arg)
  %v1394 = call ptr @mlf_prim2(i64 10, ptr %v1393, ptr inttoptr (i64 21 to ptr))
  %v1395 = icmp eq ptr %v1394, inttoptr (i64 6 to ptr)
  br i1 %v1395, label %yes.1396, label %no.1397
yes.1396:
  %v1399 = call ptr @mlf_force(ptr %v1392)
  %v1400 = call ptr @mlf_prim2(i64 9, ptr %v1399, ptr inttoptr (i64 3 to ptr))
  %v1401 = call ptr @mlf_env_new(i64 2)
  %v1402 = getelementptr i8, ptr %v1401, i64 24
  store ptr %v1390, ptr %v1402, align 8, !tbaa !3
  %v1403 = getelementptr i8, ptr %v1401, i64 32
  store ptr %v1400, ptr %v1403, align 8, !tbaa !3
  %v1404 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1348, ptr %v1401)
  br label %join.1398
no.1397:
  %v1405 = call ptr @mlf_prim2(i64 10, ptr %v1393, ptr inttoptr (i64 27 to ptr))
  %v1406 = icmp eq ptr %v1405, inttoptr (i64 6 to ptr)
  br i1 %v1406, label %yes.1407, label %no.1408
yes.1407:
  %v1410 = call ptr @mlf_force(ptr %v1392)
  %v1411 = call ptr @mlf_prim2(i64 9, ptr %v1410, ptr inttoptr (i64 3 to ptr))
  %v1412 = call ptr @mlf_env_new(i64 2)
  %v1413 = getelementptr i8, ptr %v1412, i64 24
  store ptr %v1390, ptr %v1413, align 8, !tbaa !3
  %v1414 = getelementptr i8, ptr %v1412, i64 32
  store ptr %v1411, ptr %v1414, align 8, !tbaa !3
  %v1415 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1348, ptr %v1412)
  br label %join.1409
no.1408:
  %v1416 = call ptr @mlf_prim1(i64 0, ptr %v1392)
  br label %join.1409
join.1409:
  %v1417 = phi ptr [ %v1415, %yes.1407 ], [ %v1416, %no.1408 ]
  br label %join.1398
join.1398:
  %v1418 = phi ptr [ %v1404, %yes.1396 ], [ %v1417, %join.1409 ]
  ret ptr %v1418
}

define private ptr @mlf.worker.11(ptr %a0, ptr %a1) {
entry:
  %v1364 = call ptr @mlf_prim2(i64 10, ptr %a1, ptr inttoptr (i64 1 to ptr))
  %v1365 = icmp eq ptr %v1364, inttoptr (i64 6 to ptr)
  br i1 %v1365, label %yes.1366, label %no.1367
yes.1366:
  %v1369 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 1 to ptr))
  br label %join.1368
no.1367:
  %v1384 = call ptr @mlf_env_new(i64 2)
  %v1385 = getelementptr i8, ptr %v1384, i64 24
  store ptr %a0, ptr %v1385, align 8, !tbaa !3
  %v1386 = getelementptr i8, ptr %v1384, i64 32
  store ptr %a1, ptr %v1386, align 8, !tbaa !3
  %v1387 = call ptr @mlf_thunk(ptr @mlf.code.1370, ptr %v1384)
  %v1419 = call ptr @mlf_env_new(i64 2)
  %v1420 = getelementptr i8, ptr %v1419, i64 24
  store ptr %a0, ptr %v1420, align 8, !tbaa !3
  %v1421 = getelementptr i8, ptr %v1419, i64 32
  store ptr %a1, ptr %v1421, align 8, !tbaa !3
  %v1422 = call ptr @mlf_closure(ptr @mlf.code.1388, ptr %v1419)
  %v1423 = call ptr @mlf_prim2(i64 1, ptr %v1387, ptr %v1422)
  br label %join.1368
join.1368:
  %v1424 = phi ptr [ %v1369, %yes.1366 ], [ %v1423, %no.1367 ]
  ret ptr %v1424
}

define private ptr @mlf.numeric.entry.1348(ptr %env, ptr %arg) {
entry:
  %v1349 = getelementptr i8, ptr %env, i64 24
  %v1350 = load ptr, ptr %v1349, align 8, !tbaa !3
  %v1351 = getelementptr i8, ptr %env, i64 32
  %v1352 = load ptr, ptr %v1351, align 8, !tbaa !3
  %v1353 = call ptr @mlf_peek(ptr %v1350)
  %v1354 = call ptr @mlf_peek(ptr %v1352)
  %v1355 = icmp ne ptr %v1353, null
  %v1356 = icmp ne ptr %v1354, null
  %v1357 = and i1 true, %v1355
  %v1358 = and i1 %v1357, %v1356
  br i1 %v1358, label %yes.1359, label %no.1360
yes.1359:
  %v1362 = call ptr @mlf.numeric.11(ptr %v1353, ptr %v1354)
  %v1363 = call ptr @mlf_prim1(i64 0, ptr %v1362)
  br label %join.1361
no.1360:
  %v1425 = call ptr @mlf_force(ptr %v1352)
  %v1426 = call ptr @mlf.worker.11(ptr %v1350, ptr %v1425)
  br label %join.1361
join.1361:
  %v1427 = phi ptr [ %v1363, %yes.1359 ], [ %v1426, %no.1360 ]
  ret ptr %v1427
}

define private ptr @mlf.code.1343(ptr %env, ptr %arg) {
entry:
  %v1344 = getelementptr i8, ptr %env, i64 24
  %v1345 = load ptr, ptr %v1344, align 8, !tbaa !3
  %v1346 = getelementptr i8, ptr %env, i64 32
  %v1347 = load ptr, ptr %v1346, align 8, !tbaa !3
  %v1428 = call ptr @mlf_force(ptr %v1347)
  %v1429 = call ptr @mlf_env_new(i64 2)
  %v1430 = getelementptr i8, ptr %v1429, i64 24
  store ptr %v1345, ptr %v1430, align 8, !tbaa !3
  %v1431 = getelementptr i8, ptr %v1429, i64 32
  store ptr %v1428, ptr %v1431, align 8, !tbaa !3
  %v1432 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1348, ptr %v1429)
  ret ptr %v1432
}

define private ptr @mlf.worker.8(ptr %a0, ptr %a1) {
entry:
  %v1476 = call ptr @mlf_prim2(i64 11, ptr %a0, ptr %a1)
  %v1477 = icmp eq ptr %v1476, inttoptr (i64 6 to ptr)
  br i1 %v1477, label %yes.1478, label %no.1479
yes.1478:
  %v1481 = call ptr @mlf_prim2(i64 14, ptr %a0, ptr inttoptr (i64 5 to ptr))
  %v1482 = call ptr @mlf_env_new(i64 2)
  %v1483 = getelementptr i8, ptr %v1482, i64 24
  store ptr %v1481, ptr %v1483, align 8, !tbaa !3
  %v1484 = getelementptr i8, ptr %v1482, i64 32
  store ptr %a1, ptr %v1484, align 8, !tbaa !3
  %v1485 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1460, ptr %v1482)
  br label %join.1480
no.1479:
  %v1486 = call ptr @mlf_prim1(i64 0, ptr %a0)
  br label %join.1480
join.1480:
  %v1487 = phi ptr [ %v1485, %yes.1478 ], [ %v1486, %no.1479 ]
  ret ptr %v1487
}

define private ptr @mlf.numeric.entry.1460(ptr %env, ptr %arg) {
entry:
  %v1461 = getelementptr i8, ptr %env, i64 24
  %v1462 = load ptr, ptr %v1461, align 8, !tbaa !3
  %v1463 = getelementptr i8, ptr %env, i64 32
  %v1464 = load ptr, ptr %v1463, align 8, !tbaa !3
  %v1465 = call ptr @mlf_peek(ptr %v1462)
  %v1466 = call ptr @mlf_peek(ptr %v1464)
  %v1467 = icmp ne ptr %v1465, null
  %v1468 = icmp ne ptr %v1466, null
  %v1469 = and i1 true, %v1467
  %v1470 = and i1 %v1469, %v1468
  br i1 %v1470, label %yes.1471, label %no.1472
yes.1471:
  %v1474 = call ptr @mlf.numeric.8(ptr %v1465, ptr %v1466)
  %v1475 = call ptr @mlf_prim1(i64 0, ptr %v1474)
  br label %join.1473
no.1472:
  %v1488 = call ptr @mlf_force(ptr %v1462)
  %v1489 = call ptr @mlf_force(ptr %v1464)
  %v1490 = call ptr @mlf.worker.8(ptr %v1488, ptr %v1489)
  br label %join.1473
join.1473:
  %v1491 = phi ptr [ %v1475, %yes.1471 ], [ %v1490, %no.1472 ]
  ret ptr %v1491
}

define private ptr @mlf.code.1455(ptr %env, ptr %arg) {
entry:
  %v1456 = getelementptr i8, ptr %env, i64 24
  %v1457 = load ptr, ptr %v1456, align 8, !tbaa !3
  %v1458 = getelementptr i8, ptr %env, i64 32
  %v1459 = load ptr, ptr %v1458, align 8, !tbaa !3
  %v1492 = call ptr @mlf_force(ptr %v1457)
  %v1493 = call ptr @mlf_force(ptr %v1459)
  %v1494 = call ptr @mlf_env_new(i64 2)
  %v1495 = getelementptr i8, ptr %v1494, i64 24
  store ptr %v1492, ptr %v1495, align 8, !tbaa !3
  %v1496 = getelementptr i8, ptr %v1494, i64 32
  store ptr %v1493, ptr %v1496, align 8, !tbaa !3
  %v1497 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1460, ptr %v1494)
  ret ptr %v1497
}

define private ptr @mlf.code.1513(ptr %env, ptr %arg) {
entry:
  %v1514 = getelementptr i8, ptr %env, i64 24
  %v1515 = load ptr, ptr %v1514, align 8, !tbaa !3
  %v1516 = call ptr @mlf_prim2(i64 35, ptr %v1515, ptr inttoptr (i64 1 to ptr))
  ret ptr %v1516
}

define private ptr @mlf.code.1576(ptr %env, ptr %arg) {
entry:
  %v1577 = getelementptr i8, ptr %env, i64 24
  %v1578 = load ptr, ptr %v1577, align 8, !tbaa !3
  %v1579 = getelementptr i8, ptr %env, i64 32
  %v1580 = load ptr, ptr %v1579, align 8, !tbaa !3
  %v1581 = call ptr @mlf_prim2(i64 36, ptr %v1578, ptr %v1580)
  ret ptr %v1581
}

define private ptr @mlf.code.1606(ptr %env, ptr %arg) {
entry:
  %v1607 = getelementptr i8, ptr %env, i64 24
  %v1608 = load ptr, ptr %v1607, align 8, !tbaa !3
  %v1609 = getelementptr i8, ptr %env, i64 32
  %v1610 = load ptr, ptr %v1609, align 8, !tbaa !3
  %v1611 = call ptr @mlf_force(ptr %v1608)
  %v1612 = call ptr @mlf_force(ptr %v1610)
  %v1613 = call ptr @mlf_prim2(i64 8, ptr %v1611, ptr %v1612)
  ret ptr %v1613
}

define private ptr @mlf.code.1597(ptr %env, ptr %arg) {
entry:
  %v1598 = getelementptr i8, ptr %env, i64 24
  %v1599 = load ptr, ptr %v1598, align 8, !tbaa !3
  %v1600 = getelementptr i8, ptr %env, i64 32
  %v1601 = load ptr, ptr %v1600, align 8, !tbaa !3
  %v1602 = getelementptr i8, ptr %env, i64 40
  %v1603 = load ptr, ptr %v1602, align 8, !tbaa !3
  %v1604 = getelementptr i8, ptr %env, i64 48
  %v1605 = load ptr, ptr %v1604, align 8, !tbaa !3
  %v1614 = call ptr @mlf_env_new(i64 2)
  %v1615 = getelementptr i8, ptr %v1614, i64 24
  store ptr %v1601, ptr %v1615, align 8, !tbaa !3
  %v1616 = getelementptr i8, ptr %v1614, i64 32
  store ptr %v1603, ptr %v1616, align 8, !tbaa !3
  %v1617 = call ptr @mlf_thunk(ptr @mlf.code.1606, ptr %v1614)
  %v1618 = call ptr @mlf_prim3(i64 37, ptr %v1599, ptr %v1617, ptr %v1605)
  ret ptr %v1618
}

define private ptr @mlf.code.1625(ptr %env, ptr %arg) {
entry:
  %v1626 = getelementptr i8, ptr %env, i64 24
  %v1627 = load ptr, ptr %v1626, align 8, !tbaa !3
  %v1628 = getelementptr i8, ptr %env, i64 32
  %v1629 = load ptr, ptr %v1628, align 8, !tbaa !3
  %v1630 = getelementptr i8, ptr %env, i64 40
  %v1631 = load ptr, ptr %v1630, align 8, !tbaa !3
  %v1632 = getelementptr i8, ptr %env, i64 48
  %v1633 = load ptr, ptr %v1632, align 8, !tbaa !3
  %v1634 = getelementptr i8, ptr %env, i64 56
  %v1635 = load ptr, ptr %v1634, align 8, !tbaa !3
  %v1636 = call ptr @mlf_force(ptr %v1631)
  %v1637 = call ptr @mlf_force(ptr %v1635)
  %v1638 = call ptr @mlf_prim2(i64 8, ptr %v1637, ptr inttoptr (i64 3 to ptr))
  %v1639 = call ptr @mlf_env_new(i64 5)
  %v1640 = getelementptr i8, ptr %v1639, i64 24
  store ptr %v1627, ptr %v1640, align 8, !tbaa !3
  %v1641 = getelementptr i8, ptr %v1639, i64 32
  store ptr %v1629, ptr %v1641, align 8, !tbaa !3
  %v1642 = getelementptr i8, ptr %v1639, i64 40
  store ptr %v1636, ptr %v1642, align 8, !tbaa !3
  %v1643 = getelementptr i8, ptr %v1639, i64 48
  store ptr %v1633, ptr %v1643, align 8, !tbaa !3
  %v1644 = getelementptr i8, ptr %v1639, i64 56
  store ptr %v1638, ptr %v1644, align 8, !tbaa !3
  %v1645 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1540, ptr %v1639)
  ret ptr %v1645
}

define private ptr @mlf.code.1586(ptr %env, ptr %arg) {
entry:
  %v1587 = getelementptr i8, ptr %env, i64 24
  %v1588 = load ptr, ptr %v1587, align 8, !tbaa !3
  %v1589 = getelementptr i8, ptr %env, i64 32
  %v1590 = load ptr, ptr %v1589, align 8, !tbaa !3
  %v1591 = getelementptr i8, ptr %env, i64 40
  %v1592 = load ptr, ptr %v1591, align 8, !tbaa !3
  %v1593 = getelementptr i8, ptr %env, i64 48
  %v1594 = load ptr, ptr %v1593, align 8, !tbaa !3
  %v1595 = getelementptr i8, ptr %env, i64 56
  %v1596 = load ptr, ptr %v1595, align 8, !tbaa !3
  %v1619 = call ptr @mlf_env_new(i64 4)
  %v1620 = getelementptr i8, ptr %v1619, i64 24
  store ptr %v1590, ptr %v1620, align 8, !tbaa !3
  %v1621 = getelementptr i8, ptr %v1619, i64 32
  store ptr %v1594, ptr %v1621, align 8, !tbaa !3
  %v1622 = getelementptr i8, ptr %v1619, i64 40
  store ptr %v1596, ptr %v1622, align 8, !tbaa !3
  %v1623 = getelementptr i8, ptr %v1619, i64 48
  store ptr %arg, ptr %v1623, align 8, !tbaa !3
  %v1624 = call ptr @mlf_thunk(ptr @mlf.code.1597, ptr %v1619)
  %v1646 = call ptr @mlf_env_new(i64 5)
  %v1647 = getelementptr i8, ptr %v1646, i64 24
  store ptr %v1588, ptr %v1647, align 8, !tbaa !3
  %v1648 = getelementptr i8, ptr %v1646, i64 32
  store ptr %v1590, ptr %v1648, align 8, !tbaa !3
  %v1649 = getelementptr i8, ptr %v1646, i64 40
  store ptr %v1592, ptr %v1649, align 8, !tbaa !3
  %v1650 = getelementptr i8, ptr %v1646, i64 48
  store ptr %v1594, ptr %v1650, align 8, !tbaa !3
  %v1651 = getelementptr i8, ptr %v1646, i64 56
  store ptr %v1596, ptr %v1651, align 8, !tbaa !3
  %v1652 = call ptr @mlf_closure(ptr @mlf.code.1625, ptr %v1646)
  %v1653 = call ptr @mlf_prim2(i64 1, ptr %v1624, ptr %v1652)
  ret ptr %v1653
}

define private ptr @mlf.worker.0(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) {
entry:
  %v1571 = call ptr @mlf_prim2(i64 11, ptr %a4, ptr %a2)
  %v1572 = icmp eq ptr %v1571, inttoptr (i64 6 to ptr)
  br i1 %v1572, label %yes.1573, label %no.1574
yes.1573:
  %v1582 = call ptr @mlf_env_new(i64 2)
  %v1583 = getelementptr i8, ptr %v1582, i64 24
  store ptr %a0, ptr %v1583, align 8, !tbaa !3
  %v1584 = getelementptr i8, ptr %v1582, i64 32
  store ptr %a4, ptr %v1584, align 8, !tbaa !3
  %v1585 = call ptr @mlf_thunk(ptr @mlf.code.1576, ptr %v1582)
  %v1654 = call ptr @mlf_env_new(i64 5)
  %v1655 = getelementptr i8, ptr %v1654, i64 24
  store ptr %a0, ptr %v1655, align 8, !tbaa !3
  %v1656 = getelementptr i8, ptr %v1654, i64 32
  store ptr %a1, ptr %v1656, align 8, !tbaa !3
  %v1657 = getelementptr i8, ptr %v1654, i64 40
  store ptr %a2, ptr %v1657, align 8, !tbaa !3
  %v1658 = getelementptr i8, ptr %v1654, i64 48
  store ptr %a3, ptr %v1658, align 8, !tbaa !3
  %v1659 = getelementptr i8, ptr %v1654, i64 56
  store ptr %a4, ptr %v1659, align 8, !tbaa !3
  %v1660 = call ptr @mlf_closure(ptr @mlf.code.1586, ptr %v1654)
  %v1661 = call ptr @mlf_prim2(i64 1, ptr %v1585, ptr %v1660)
  br label %join.1575
no.1574:
  %v1662 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.1575
join.1575:
  %v1663 = phi ptr [ %v1661, %yes.1573 ], [ %v1662, %no.1574 ]
  ret ptr %v1663
}

define private ptr @mlf.numeric.entry.1540(ptr %env, ptr %arg) {
entry:
  %v1541 = getelementptr i8, ptr %env, i64 24
  %v1542 = load ptr, ptr %v1541, align 8, !tbaa !3
  %v1543 = getelementptr i8, ptr %env, i64 32
  %v1544 = load ptr, ptr %v1543, align 8, !tbaa !3
  %v1545 = getelementptr i8, ptr %env, i64 40
  %v1546 = load ptr, ptr %v1545, align 8, !tbaa !3
  %v1547 = getelementptr i8, ptr %env, i64 48
  %v1548 = load ptr, ptr %v1547, align 8, !tbaa !3
  %v1549 = getelementptr i8, ptr %env, i64 56
  %v1550 = load ptr, ptr %v1549, align 8, !tbaa !3
  %v1551 = call ptr @mlf_peek(ptr %v1542)
  %v1552 = call ptr @mlf_peek(ptr %v1544)
  %v1553 = call ptr @mlf_peek(ptr %v1546)
  %v1554 = call ptr @mlf_peek(ptr %v1548)
  %v1555 = call ptr @mlf_peek(ptr %v1550)
  %v1556 = icmp ne ptr %v1551, null
  %v1557 = icmp ne ptr %v1552, null
  %v1558 = icmp ne ptr %v1553, null
  %v1559 = icmp ne ptr %v1554, null
  %v1560 = icmp ne ptr %v1555, null
  %v1561 = and i1 true, %v1556
  %v1562 = and i1 %v1561, %v1557
  %v1563 = and i1 %v1562, %v1558
  %v1564 = and i1 %v1563, %v1559
  %v1565 = and i1 %v1564, %v1560
  br i1 %v1565, label %yes.1566, label %no.1567
yes.1566:
  %v1569 = call ptr @mlf.numeric.0(ptr %v1551, ptr %v1552, ptr %v1553, ptr %v1554, ptr %v1555)
  %v1570 = call ptr @mlf_prim1(i64 0, ptr %v1569)
  br label %join.1568
no.1567:
  %v1664 = call ptr @mlf_force(ptr %v1546)
  %v1665 = call ptr @mlf_force(ptr %v1550)
  %v1666 = call ptr @mlf.worker.0(ptr %v1542, ptr %v1544, ptr %v1664, ptr %v1548, ptr %v1665)
  br label %join.1568
join.1568:
  %v1667 = phi ptr [ %v1570, %yes.1566 ], [ %v1666, %no.1567 ]
  ret ptr %v1667
}

define private ptr @mlf.code.1533(ptr %env, ptr %arg) {
entry:
  %v1534 = getelementptr i8, ptr %env, i64 24
  %v1535 = load ptr, ptr %v1534, align 8, !tbaa !3
  %v1536 = getelementptr i8, ptr %env, i64 32
  %v1537 = load ptr, ptr %v1536, align 8, !tbaa !3
  %v1538 = getelementptr i8, ptr %env, i64 40
  %v1539 = load ptr, ptr %v1538, align 8, !tbaa !3
  %v1668 = call ptr @mlf_force(ptr %v1537)
  %v1669 = call ptr @mlf_env_new(i64 5)
  %v1670 = getelementptr i8, ptr %v1669, i64 24
  store ptr %v1535, ptr %v1670, align 8, !tbaa !3
  %v1671 = getelementptr i8, ptr %v1669, i64 32
  store ptr %v1539, ptr %v1671, align 8, !tbaa !3
  %v1672 = getelementptr i8, ptr %v1669, i64 40
  store ptr %v1668, ptr %v1672, align 8, !tbaa !3
  %v1673 = getelementptr i8, ptr %v1669, i64 48
  store ptr inttoptr (i64 1 to ptr), ptr %v1673, align 8, !tbaa !3
  %v1674 = getelementptr i8, ptr %v1669, i64 56
  store ptr inttoptr (i64 1 to ptr), ptr %v1674, align 8, !tbaa !3
  %v1675 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1540, ptr %v1669)
  ret ptr %v1675
}

define private ptr @mlf.code.1739(ptr %env, ptr %arg) {
entry:
  %v1740 = getelementptr i8, ptr %env, i64 24
  %v1741 = load ptr, ptr %v1740, align 8, !tbaa !3
  %v1742 = getelementptr i8, ptr %env, i64 32
  %v1743 = load ptr, ptr %v1742, align 8, !tbaa !3
  %v1744 = call ptr @mlf_prim2(i64 36, ptr %v1741, ptr %v1743)
  ret ptr %v1744
}

define private ptr @mlf.code.1769(ptr %env, ptr %arg) {
entry:
  %v1770 = getelementptr i8, ptr %env, i64 24
  %v1771 = load ptr, ptr %v1770, align 8, !tbaa !3
  %v1772 = getelementptr i8, ptr %env, i64 32
  %v1773 = load ptr, ptr %v1772, align 8, !tbaa !3
  %v1774 = call ptr @mlf_force(ptr %v1771)
  %v1775 = call ptr @mlf_force(ptr %v1773)
  %v1776 = call ptr @mlf_prim2(i64 8, ptr %v1774, ptr %v1775)
  ret ptr %v1776
}

define private ptr @mlf.worker.15(ptr %a0) {
entry:
  %v1784 = call ptr @mlf_prim2(i64 10, ptr %a0, ptr inttoptr (i64 131 to ptr))
  %v1785 = icmp eq ptr %v1784, inttoptr (i64 6 to ptr)
  br i1 %v1785, label %yes.1786, label %no.1787
yes.1786:
  br label %join.1788
no.1787:
  %v1789 = call ptr @mlf_prim2(i64 10, ptr %a0, ptr inttoptr (i64 195 to ptr))
  %v1790 = icmp eq ptr %v1789, inttoptr (i64 6 to ptr)
  br i1 %v1790, label %yes.1791, label %no.1792
yes.1791:
  br label %join.1793
no.1792:
  %v1794 = call ptr @mlf_prim2(i64 10, ptr %a0, ptr inttoptr (i64 135 to ptr))
  %v1795 = icmp eq ptr %v1794, inttoptr (i64 6 to ptr)
  br i1 %v1795, label %yes.1796, label %no.1797
yes.1796:
  br label %join.1798
no.1797:
  %v1799 = call ptr @mlf_prim2(i64 10, ptr %a0, ptr inttoptr (i64 199 to ptr))
  %v1800 = icmp eq ptr %v1799, inttoptr (i64 6 to ptr)
  br i1 %v1800, label %yes.1801, label %no.1802
yes.1801:
  br label %join.1803
no.1802:
  %v1804 = call ptr @mlf_prim2(i64 10, ptr %a0, ptr inttoptr (i64 143 to ptr))
  %v1805 = icmp eq ptr %v1804, inttoptr (i64 6 to ptr)
  br i1 %v1805, label %yes.1806, label %no.1807
yes.1806:
  br label %join.1808
no.1807:
  %v1809 = call ptr @mlf_prim2(i64 10, ptr %a0, ptr inttoptr (i64 207 to ptr))
  %v1810 = icmp eq ptr %v1809, inttoptr (i64 6 to ptr)
  br i1 %v1810, label %yes.1811, label %no.1812
yes.1811:
  br label %join.1813
no.1812:
  br label %join.1813
join.1813:
  %v1814 = phi ptr [ inttoptr (i64 5 to ptr), %yes.1811 ], [ inttoptr (i64 7 to ptr), %no.1812 ]
  br label %join.1808
join.1808:
  %v1815 = phi ptr [ inttoptr (i64 5 to ptr), %yes.1806 ], [ %v1814, %join.1813 ]
  br label %join.1803
join.1803:
  %v1816 = phi ptr [ inttoptr (i64 3 to ptr), %yes.1801 ], [ %v1815, %join.1808 ]
  br label %join.1798
join.1798:
  %v1817 = phi ptr [ inttoptr (i64 3 to ptr), %yes.1796 ], [ %v1816, %join.1803 ]
  br label %join.1793
join.1793:
  %v1818 = phi ptr [ inttoptr (i64 1 to ptr), %yes.1791 ], [ %v1817, %join.1798 ]
  br label %join.1788
join.1788:
  %v1819 = phi ptr [ inttoptr (i64 1 to ptr), %yes.1786 ], [ %v1818, %join.1793 ]
  ret ptr %v1819
}

define private ptr @mlf.code.1781(ptr %env, ptr %arg) {
entry:
  %v1782 = getelementptr i8, ptr %env, i64 24
  %v1783 = load ptr, ptr %v1782, align 8, !tbaa !3
  %v1820 = call ptr @mlf_force(ptr %v1783)
  %v1821 = call ptr @mlf.worker.15(ptr %v1820)
  ret ptr %v1821
}

define private ptr @mlf.code.1760(ptr %env, ptr %arg) {
entry:
  %v1761 = getelementptr i8, ptr %env, i64 24
  %v1762 = load ptr, ptr %v1761, align 8, !tbaa !3
  %v1763 = getelementptr i8, ptr %env, i64 32
  %v1764 = load ptr, ptr %v1763, align 8, !tbaa !3
  %v1765 = getelementptr i8, ptr %env, i64 40
  %v1766 = load ptr, ptr %v1765, align 8, !tbaa !3
  %v1767 = getelementptr i8, ptr %env, i64 48
  %v1768 = load ptr, ptr %v1767, align 8, !tbaa !3
  %v1777 = call ptr @mlf_env_new(i64 2)
  %v1778 = getelementptr i8, ptr %v1777, i64 24
  store ptr %v1764, ptr %v1778, align 8, !tbaa !3
  %v1779 = getelementptr i8, ptr %v1777, i64 32
  store ptr %v1766, ptr %v1779, align 8, !tbaa !3
  %v1780 = call ptr @mlf_thunk(ptr @mlf.code.1769, ptr %v1777)
  %v1822 = call ptr @mlf_env_new(i64 1)
  %v1823 = getelementptr i8, ptr %v1822, i64 24
  store ptr %v1768, ptr %v1823, align 8, !tbaa !3
  %v1824 = call ptr @mlf_thunk(ptr @mlf.code.1781, ptr %v1822)
  %v1825 = call ptr @mlf_prim3(i64 37, ptr %v1762, ptr %v1780, ptr %v1824)
  ret ptr %v1825
}

define private ptr @mlf.code.1832(ptr %env, ptr %arg) {
entry:
  %v1833 = getelementptr i8, ptr %env, i64 24
  %v1834 = load ptr, ptr %v1833, align 8, !tbaa !3
  %v1835 = getelementptr i8, ptr %env, i64 32
  %v1836 = load ptr, ptr %v1835, align 8, !tbaa !3
  %v1837 = getelementptr i8, ptr %env, i64 40
  %v1838 = load ptr, ptr %v1837, align 8, !tbaa !3
  %v1839 = getelementptr i8, ptr %env, i64 48
  %v1840 = load ptr, ptr %v1839, align 8, !tbaa !3
  %v1841 = getelementptr i8, ptr %env, i64 56
  %v1842 = load ptr, ptr %v1841, align 8, !tbaa !3
  %v1843 = call ptr @mlf_force(ptr %v1838)
  %v1844 = call ptr @mlf_force(ptr %v1842)
  %v1845 = call ptr @mlf_prim2(i64 8, ptr %v1844, ptr inttoptr (i64 3 to ptr))
  %v1846 = call ptr @mlf_env_new(i64 5)
  %v1847 = getelementptr i8, ptr %v1846, i64 24
  store ptr %v1834, ptr %v1847, align 8, !tbaa !3
  %v1848 = getelementptr i8, ptr %v1846, i64 32
  store ptr %v1836, ptr %v1848, align 8, !tbaa !3
  %v1849 = getelementptr i8, ptr %v1846, i64 40
  store ptr %v1843, ptr %v1849, align 8, !tbaa !3
  %v1850 = getelementptr i8, ptr %v1846, i64 48
  store ptr %v1840, ptr %v1850, align 8, !tbaa !3
  %v1851 = getelementptr i8, ptr %v1846, i64 56
  store ptr %v1845, ptr %v1851, align 8, !tbaa !3
  %v1852 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1703, ptr %v1846)
  ret ptr %v1852
}

define private ptr @mlf.code.1749(ptr %env, ptr %arg) {
entry:
  %v1750 = getelementptr i8, ptr %env, i64 24
  %v1751 = load ptr, ptr %v1750, align 8, !tbaa !3
  %v1752 = getelementptr i8, ptr %env, i64 32
  %v1753 = load ptr, ptr %v1752, align 8, !tbaa !3
  %v1754 = getelementptr i8, ptr %env, i64 40
  %v1755 = load ptr, ptr %v1754, align 8, !tbaa !3
  %v1756 = getelementptr i8, ptr %env, i64 48
  %v1757 = load ptr, ptr %v1756, align 8, !tbaa !3
  %v1758 = getelementptr i8, ptr %env, i64 56
  %v1759 = load ptr, ptr %v1758, align 8, !tbaa !3
  %v1826 = call ptr @mlf_env_new(i64 4)
  %v1827 = getelementptr i8, ptr %v1826, i64 24
  store ptr %v1753, ptr %v1827, align 8, !tbaa !3
  %v1828 = getelementptr i8, ptr %v1826, i64 32
  store ptr %v1757, ptr %v1828, align 8, !tbaa !3
  %v1829 = getelementptr i8, ptr %v1826, i64 40
  store ptr %v1759, ptr %v1829, align 8, !tbaa !3
  %v1830 = getelementptr i8, ptr %v1826, i64 48
  store ptr %arg, ptr %v1830, align 8, !tbaa !3
  %v1831 = call ptr @mlf_thunk(ptr @mlf.code.1760, ptr %v1826)
  %v1853 = call ptr @mlf_env_new(i64 5)
  %v1854 = getelementptr i8, ptr %v1853, i64 24
  store ptr %v1751, ptr %v1854, align 8, !tbaa !3
  %v1855 = getelementptr i8, ptr %v1853, i64 32
  store ptr %v1753, ptr %v1855, align 8, !tbaa !3
  %v1856 = getelementptr i8, ptr %v1853, i64 40
  store ptr %v1755, ptr %v1856, align 8, !tbaa !3
  %v1857 = getelementptr i8, ptr %v1853, i64 48
  store ptr %v1757, ptr %v1857, align 8, !tbaa !3
  %v1858 = getelementptr i8, ptr %v1853, i64 56
  store ptr %v1759, ptr %v1858, align 8, !tbaa !3
  %v1859 = call ptr @mlf_closure(ptr @mlf.code.1832, ptr %v1853)
  %v1860 = call ptr @mlf_prim2(i64 1, ptr %v1831, ptr %v1859)
  ret ptr %v1860
}

define private ptr @mlf.worker.17(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) {
entry:
  %v1734 = call ptr @mlf_prim2(i64 11, ptr %a4, ptr %a2)
  %v1735 = icmp eq ptr %v1734, inttoptr (i64 6 to ptr)
  br i1 %v1735, label %yes.1736, label %no.1737
yes.1736:
  %v1745 = call ptr @mlf_env_new(i64 2)
  %v1746 = getelementptr i8, ptr %v1745, i64 24
  store ptr %a0, ptr %v1746, align 8, !tbaa !3
  %v1747 = getelementptr i8, ptr %v1745, i64 32
  store ptr %a4, ptr %v1747, align 8, !tbaa !3
  %v1748 = call ptr @mlf_thunk(ptr @mlf.code.1739, ptr %v1745)
  %v1861 = call ptr @mlf_env_new(i64 5)
  %v1862 = getelementptr i8, ptr %v1861, i64 24
  store ptr %a0, ptr %v1862, align 8, !tbaa !3
  %v1863 = getelementptr i8, ptr %v1861, i64 32
  store ptr %a1, ptr %v1863, align 8, !tbaa !3
  %v1864 = getelementptr i8, ptr %v1861, i64 40
  store ptr %a2, ptr %v1864, align 8, !tbaa !3
  %v1865 = getelementptr i8, ptr %v1861, i64 48
  store ptr %a3, ptr %v1865, align 8, !tbaa !3
  %v1866 = getelementptr i8, ptr %v1861, i64 56
  store ptr %a4, ptr %v1866, align 8, !tbaa !3
  %v1867 = call ptr @mlf_closure(ptr @mlf.code.1749, ptr %v1861)
  %v1868 = call ptr @mlf_prim2(i64 1, ptr %v1748, ptr %v1867)
  br label %join.1738
no.1737:
  %v1869 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.1738
join.1738:
  %v1870 = phi ptr [ %v1868, %yes.1736 ], [ %v1869, %no.1737 ]
  ret ptr %v1870
}

define private ptr @mlf.numeric.entry.1703(ptr %env, ptr %arg) {
entry:
  %v1704 = getelementptr i8, ptr %env, i64 24
  %v1705 = load ptr, ptr %v1704, align 8, !tbaa !3
  %v1706 = getelementptr i8, ptr %env, i64 32
  %v1707 = load ptr, ptr %v1706, align 8, !tbaa !3
  %v1708 = getelementptr i8, ptr %env, i64 40
  %v1709 = load ptr, ptr %v1708, align 8, !tbaa !3
  %v1710 = getelementptr i8, ptr %env, i64 48
  %v1711 = load ptr, ptr %v1710, align 8, !tbaa !3
  %v1712 = getelementptr i8, ptr %env, i64 56
  %v1713 = load ptr, ptr %v1712, align 8, !tbaa !3
  %v1714 = call ptr @mlf_peek(ptr %v1705)
  %v1715 = call ptr @mlf_peek(ptr %v1707)
  %v1716 = call ptr @mlf_peek(ptr %v1709)
  %v1717 = call ptr @mlf_peek(ptr %v1711)
  %v1718 = call ptr @mlf_peek(ptr %v1713)
  %v1719 = icmp ne ptr %v1714, null
  %v1720 = icmp ne ptr %v1715, null
  %v1721 = icmp ne ptr %v1716, null
  %v1722 = icmp ne ptr %v1717, null
  %v1723 = icmp ne ptr %v1718, null
  %v1724 = and i1 true, %v1719
  %v1725 = and i1 %v1724, %v1720
  %v1726 = and i1 %v1725, %v1721
  %v1727 = and i1 %v1726, %v1722
  %v1728 = and i1 %v1727, %v1723
  br i1 %v1728, label %yes.1729, label %no.1730
yes.1729:
  %v1732 = call ptr @mlf.numeric.17(ptr %v1714, ptr %v1715, ptr %v1716, ptr %v1717, ptr %v1718)
  %v1733 = call ptr @mlf_prim1(i64 0, ptr %v1732)
  br label %join.1731
no.1730:
  %v1871 = call ptr @mlf_force(ptr %v1709)
  %v1872 = call ptr @mlf_force(ptr %v1713)
  %v1873 = call ptr @mlf.worker.17(ptr %v1705, ptr %v1707, ptr %v1871, ptr %v1711, ptr %v1872)
  br label %join.1731
join.1731:
  %v1874 = phi ptr [ %v1733, %yes.1729 ], [ %v1873, %no.1730 ]
  ret ptr %v1874
}

define private ptr @mlf.code.1694(ptr %env, ptr %arg) {
entry:
  %v1695 = getelementptr i8, ptr %env, i64 24
  %v1696 = load ptr, ptr %v1695, align 8, !tbaa !3
  %v1697 = getelementptr i8, ptr %env, i64 32
  %v1698 = load ptr, ptr %v1697, align 8, !tbaa !3
  %v1699 = getelementptr i8, ptr %env, i64 40
  %v1700 = load ptr, ptr %v1699, align 8, !tbaa !3
  %v1701 = getelementptr i8, ptr %env, i64 48
  %v1702 = load ptr, ptr %v1701, align 8, !tbaa !3
  %v1875 = call ptr @mlf_force(ptr %v1700)
  %v1876 = call ptr @mlf_env_new(i64 5)
  %v1877 = getelementptr i8, ptr %v1876, i64 24
  store ptr %v1698, ptr %v1877, align 8, !tbaa !3
  %v1878 = getelementptr i8, ptr %v1876, i64 32
  store ptr %v1702, ptr %v1878, align 8, !tbaa !3
  %v1879 = getelementptr i8, ptr %v1876, i64 40
  store ptr %v1875, ptr %v1879, align 8, !tbaa !3
  %v1880 = getelementptr i8, ptr %v1876, i64 48
  store ptr %v1696, ptr %v1880, align 8, !tbaa !3
  %v1881 = getelementptr i8, ptr %v1876, i64 56
  store ptr inttoptr (i64 1 to ptr), ptr %v1881, align 8, !tbaa !3
  %v1882 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1703, ptr %v1876)
  ret ptr %v1882
}

define private ptr @mlf.code.1889(ptr %env, ptr %arg) {
entry:
  %v1890 = getelementptr i8, ptr %env, i64 24
  %v1891 = load ptr, ptr %v1890, align 8, !tbaa !3
  %v1892 = getelementptr i8, ptr %env, i64 32
  %v1893 = load ptr, ptr %v1892, align 8, !tbaa !3
  %v1894 = getelementptr i8, ptr %env, i64 40
  %v1895 = load ptr, ptr %v1894, align 8, !tbaa !3
  %v1896 = call ptr @mlf_env_new(i64 3)
  %v1897 = getelementptr i8, ptr %v1896, i64 24
  store ptr %v1895, ptr %v1897, align 8, !tbaa !3
  %v1898 = getelementptr i8, ptr %v1896, i64 32
  store ptr %v1891, ptr %v1898, align 8, !tbaa !3
  %v1899 = getelementptr i8, ptr %v1896, i64 40
  store ptr %v1893, ptr %v1899, align 8, !tbaa !3
  %v1900 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.564, ptr %v1896)
  ret ptr %v1900
}

define private ptr @mlf.code.1681(ptr %env, ptr %arg) {
entry:
  %v1682 = getelementptr i8, ptr %env, i64 24
  %v1683 = load ptr, ptr %v1682, align 8, !tbaa !3
  %v1684 = getelementptr i8, ptr %env, i64 32
  %v1685 = load ptr, ptr %v1684, align 8, !tbaa !3
  %v1686 = getelementptr i8, ptr %env, i64 40
  %v1687 = load ptr, ptr %v1686, align 8, !tbaa !3
  %v1688 = getelementptr i8, ptr %env, i64 48
  %v1689 = load ptr, ptr %v1688, align 8, !tbaa !3
  %v1690 = getelementptr i8, ptr %env, i64 56
  %v1691 = load ptr, ptr %v1690, align 8, !tbaa !3
  %v1692 = getelementptr i8, ptr %env, i64 64
  %v1693 = load ptr, ptr %v1692, align 8, !tbaa !3
  %v1883 = call ptr @mlf_env_new(i64 4)
  %v1884 = getelementptr i8, ptr %v1883, i64 24
  store ptr %v1683, ptr %v1884, align 8, !tbaa !3
  %v1885 = getelementptr i8, ptr %v1883, i64 32
  store ptr %v1685, ptr %v1885, align 8, !tbaa !3
  %v1886 = getelementptr i8, ptr %v1883, i64 40
  store ptr %v1687, ptr %v1886, align 8, !tbaa !3
  %v1887 = getelementptr i8, ptr %v1883, i64 48
  store ptr %v1693, ptr %v1887, align 8, !tbaa !3
  %v1888 = call ptr @mlf_thunk(ptr @mlf.code.1694, ptr %v1883)
  %v1901 = call ptr @mlf_env_new(i64 3)
  %v1902 = getelementptr i8, ptr %v1901, i64 24
  store ptr %v1689, ptr %v1902, align 8, !tbaa !3
  %v1903 = getelementptr i8, ptr %v1901, i64 32
  store ptr %v1691, ptr %v1903, align 8, !tbaa !3
  %v1904 = getelementptr i8, ptr %v1901, i64 40
  store ptr %v1693, ptr %v1904, align 8, !tbaa !3
  %v1905 = call ptr @mlf_closure(ptr @mlf.code.1889, ptr %v1901)
  %v1906 = call ptr @mlf_prim2(i64 1, ptr %v1888, ptr %v1905)
  ret ptr %v1906
}

define private ptr @mlf.code.1520(ptr %env, ptr %arg) {
entry:
  %v1521 = getelementptr i8, ptr %env, i64 24
  %v1522 = load ptr, ptr %v1521, align 8, !tbaa !3
  %v1523 = getelementptr i8, ptr %env, i64 32
  %v1524 = load ptr, ptr %v1523, align 8, !tbaa !3
  %v1525 = getelementptr i8, ptr %env, i64 40
  %v1526 = load ptr, ptr %v1525, align 8, !tbaa !3
  %v1527 = getelementptr i8, ptr %env, i64 48
  %v1528 = load ptr, ptr %v1527, align 8, !tbaa !3
  %v1529 = getelementptr i8, ptr %env, i64 56
  %v1530 = load ptr, ptr %v1529, align 8, !tbaa !3
  %v1531 = getelementptr i8, ptr %env, i64 64
  %v1532 = load ptr, ptr %v1531, align 8, !tbaa !3
  %v1676 = call ptr @mlf_env_new(i64 3)
  %v1677 = getelementptr i8, ptr %v1676, i64 24
  store ptr %v1522, ptr %v1677, align 8, !tbaa !3
  %v1678 = getelementptr i8, ptr %v1676, i64 32
  store ptr %v1524, ptr %v1678, align 8, !tbaa !3
  %v1679 = getelementptr i8, ptr %v1676, i64 40
  store ptr %arg, ptr %v1679, align 8, !tbaa !3
  %v1680 = call ptr @mlf_thunk(ptr @mlf.code.1533, ptr %v1676)
  %v1907 = call ptr @mlf_env_new(i64 6)
  %v1908 = getelementptr i8, ptr %v1907, i64 24
  store ptr %v1524, ptr %v1908, align 8, !tbaa !3
  %v1909 = getelementptr i8, ptr %v1907, i64 32
  store ptr %v1526, ptr %v1909, align 8, !tbaa !3
  %v1910 = getelementptr i8, ptr %v1907, i64 40
  store ptr %v1528, ptr %v1910, align 8, !tbaa !3
  %v1911 = getelementptr i8, ptr %v1907, i64 48
  store ptr %v1530, ptr %v1911, align 8, !tbaa !3
  %v1912 = getelementptr i8, ptr %v1907, i64 56
  store ptr %v1532, ptr %v1912, align 8, !tbaa !3
  %v1913 = getelementptr i8, ptr %v1907, i64 64
  store ptr %arg, ptr %v1913, align 8, !tbaa !3
  %v1914 = call ptr @mlf_closure(ptr @mlf.code.1681, ptr %v1907)
  %v1915 = call ptr @mlf_prim2(i64 1, ptr %v1680, ptr %v1914)
  ret ptr %v1915
}

define private ptr @mlf.code.1502(ptr %env, ptr %arg) {
entry:
  %v1503 = getelementptr i8, ptr %env, i64 24
  %v1504 = load ptr, ptr %v1503, align 8, !tbaa !3
  %v1505 = getelementptr i8, ptr %env, i64 32
  %v1506 = load ptr, ptr %v1505, align 8, !tbaa !3
  %v1507 = getelementptr i8, ptr %env, i64 40
  %v1508 = load ptr, ptr %v1507, align 8, !tbaa !3
  %v1509 = getelementptr i8, ptr %env, i64 48
  %v1510 = load ptr, ptr %v1509, align 8, !tbaa !3
  %v1511 = getelementptr i8, ptr %env, i64 56
  %v1512 = load ptr, ptr %v1511, align 8, !tbaa !3
  %v1517 = call ptr @mlf_env_new(i64 1)
  %v1518 = getelementptr i8, ptr %v1517, i64 24
  store ptr %arg, ptr %v1518, align 8, !tbaa !3
  %v1519 = call ptr @mlf_thunk(ptr @mlf.code.1513, ptr %v1517)
  %v1916 = call ptr @mlf_env_new(i64 6)
  %v1917 = getelementptr i8, ptr %v1916, i64 24
  store ptr %v1504, ptr %v1917, align 8, !tbaa !3
  %v1918 = getelementptr i8, ptr %v1916, i64 32
  store ptr %v1506, ptr %v1918, align 8, !tbaa !3
  %v1919 = getelementptr i8, ptr %v1916, i64 40
  store ptr %v1508, ptr %v1919, align 8, !tbaa !3
  %v1920 = getelementptr i8, ptr %v1916, i64 48
  store ptr %v1510, ptr %v1920, align 8, !tbaa !3
  %v1921 = getelementptr i8, ptr %v1916, i64 56
  store ptr %v1512, ptr %v1921, align 8, !tbaa !3
  %v1922 = getelementptr i8, ptr %v1916, i64 64
  store ptr %arg, ptr %v1922, align 8, !tbaa !3
  %v1923 = call ptr @mlf_closure(ptr @mlf.code.1520, ptr %v1916)
  %v1924 = call ptr @mlf_prim2(i64 1, ptr %v1519, ptr %v1923)
  ret ptr %v1924
}

define private ptr @mlf.code.1933(ptr %env, ptr %arg) {
entry:
  %v1934 = getelementptr i8, ptr %env, i64 24
  %v1935 = load ptr, ptr %v1934, align 8, !tbaa !3
  %v1936 = getelementptr i8, ptr %env, i64 32
  %v1937 = load ptr, ptr %v1936, align 8, !tbaa !3
  %v1938 = getelementptr i8, ptr %env, i64 40
  %v1939 = load ptr, ptr %v1938, align 8, !tbaa !3
  %v1940 = getelementptr i8, ptr %env, i64 48
  %v1941 = load ptr, ptr %v1940, align 8, !tbaa !3
  %v1942 = call ptr @mlf_force(ptr %v1941)
  %v1943 = call ptr @mlf_env_new(i64 5)
  %v1944 = getelementptr i8, ptr %v1943, i64 24
  store ptr %v1939, ptr %v1944, align 8, !tbaa !3
  %v1945 = getelementptr i8, ptr %v1943, i64 32
  store ptr %v1935, ptr %v1945, align 8, !tbaa !3
  %v1946 = getelementptr i8, ptr %v1943, i64 40
  store ptr %v1942, ptr %v1946, align 8, !tbaa !3
  %v1947 = getelementptr i8, ptr %v1943, i64 48
  store ptr %v1937, ptr %v1947, align 8, !tbaa !3
  %v1948 = getelementptr i8, ptr %v1943, i64 56
  store ptr inttoptr (i64 1 to ptr), ptr %v1948, align 8, !tbaa !3
  %v1949 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1703, ptr %v1943)
  ret ptr %v1949
}

define private ptr @mlf.code.1956(ptr %env, ptr %arg) {
entry:
  %v1957 = getelementptr i8, ptr %env, i64 24
  %v1958 = load ptr, ptr %v1957, align 8, !tbaa !3
  %v1959 = getelementptr i8, ptr %env, i64 32
  %v1960 = load ptr, ptr %v1959, align 8, !tbaa !3
  %v1961 = getelementptr i8, ptr %env, i64 40
  %v1962 = load ptr, ptr %v1961, align 8, !tbaa !3
  %v1963 = call ptr @mlf_env_new(i64 3)
  %v1964 = getelementptr i8, ptr %v1963, i64 24
  store ptr %v1958, ptr %v1964, align 8, !tbaa !3
  %v1965 = getelementptr i8, ptr %v1963, i64 32
  store ptr %v1962, ptr %v1965, align 8, !tbaa !3
  %v1966 = getelementptr i8, ptr %v1963, i64 40
  store ptr %v1960, ptr %v1966, align 8, !tbaa !3
  %v1967 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.564, ptr %v1963)
  ret ptr %v1967
}

define private ptr @mlf.code.1437(ptr %env, ptr %arg) {
entry:
  %v1438 = getelementptr i8, ptr %env, i64 24
  %v1439 = load ptr, ptr %v1438, align 8, !tbaa !3
  %v1440 = getelementptr i8, ptr %env, i64 32
  %v1441 = load ptr, ptr %v1440, align 8, !tbaa !3
  %v1442 = getelementptr i8, ptr %env, i64 40
  %v1443 = load ptr, ptr %v1442, align 8, !tbaa !3
  %v1444 = getelementptr i8, ptr %env, i64 48
  %v1445 = load ptr, ptr %v1444, align 8, !tbaa !3
  %v1446 = call ptr @mlf_force(ptr %v1441)
  %v1447 = call ptr @mlf_force(ptr %arg)
  %v1448 = call ptr @mlf_prim2(i64 8, ptr %v1446, ptr %v1447)
  %v1449 = call ptr @mlf_force(ptr %v1443)
  %v1450 = call ptr @mlf_prim2(i64 11, ptr %v1449, ptr %v1448)
  %v1451 = icmp eq ptr %v1450, inttoptr (i64 6 to ptr)
  br i1 %v1451, label %yes.1452, label %no.1453
yes.1452:
  %v1498 = call ptr @mlf_env_new(i64 2)
  %v1499 = getelementptr i8, ptr %v1498, i64 24
  store ptr %v1449, ptr %v1499, align 8, !tbaa !3
  %v1500 = getelementptr i8, ptr %v1498, i64 32
  store ptr %v1448, ptr %v1500, align 8, !tbaa !3
  %v1501 = call ptr @mlf_thunk(ptr @mlf.code.1455, ptr %v1498)
  %v1925 = call ptr @mlf_env_new(i64 5)
  %v1926 = getelementptr i8, ptr %v1925, i64 24
  store ptr %v1439, ptr %v1926, align 8, !tbaa !3
  %v1927 = getelementptr i8, ptr %v1925, i64 32
  store ptr %v1446, ptr %v1927, align 8, !tbaa !3
  %v1928 = getelementptr i8, ptr %v1925, i64 40
  store ptr %v1445, ptr %v1928, align 8, !tbaa !3
  %v1929 = getelementptr i8, ptr %v1925, i64 48
  store ptr %v1447, ptr %v1929, align 8, !tbaa !3
  %v1930 = getelementptr i8, ptr %v1925, i64 56
  store ptr %v1448, ptr %v1930, align 8, !tbaa !3
  %v1931 = call ptr @mlf_closure(ptr @mlf.code.1502, ptr %v1925)
  %v1932 = call ptr @mlf_prim2(i64 1, ptr %v1501, ptr %v1931)
  br label %join.1454
no.1453:
  %v1950 = call ptr @mlf_env_new(i64 4)
  %v1951 = getelementptr i8, ptr %v1950, i64 24
  store ptr %v1439, ptr %v1951, align 8, !tbaa !3
  %v1952 = getelementptr i8, ptr %v1950, i64 32
  store ptr %v1446, ptr %v1952, align 8, !tbaa !3
  %v1953 = getelementptr i8, ptr %v1950, i64 40
  store ptr %v1445, ptr %v1953, align 8, !tbaa !3
  %v1954 = getelementptr i8, ptr %v1950, i64 48
  store ptr %v1447, ptr %v1954, align 8, !tbaa !3
  %v1955 = call ptr @mlf_thunk(ptr @mlf.code.1933, ptr %v1950)
  %v1968 = call ptr @mlf_env_new(i64 3)
  %v1969 = getelementptr i8, ptr %v1968, i64 24
  store ptr %v1439, ptr %v1969, align 8, !tbaa !3
  %v1970 = getelementptr i8, ptr %v1968, i64 32
  store ptr %v1449, ptr %v1970, align 8, !tbaa !3
  %v1971 = getelementptr i8, ptr %v1968, i64 40
  store ptr %v1448, ptr %v1971, align 8, !tbaa !3
  %v1972 = call ptr @mlf_closure(ptr @mlf.code.1956, ptr %v1968)
  %v1973 = call ptr @mlf_prim2(i64 1, ptr %v1955, ptr %v1972)
  br label %join.1454
join.1454:
  %v1974 = phi ptr [ %v1932, %yes.1452 ], [ %v1973, %no.1453 ]
  ret ptr %v1974
}

define private ptr @mlf.code.1319(ptr %env, ptr %arg) {
entry:
  %v1320 = getelementptr i8, ptr %env, i64 24
  %v1321 = load ptr, ptr %v1320, align 8, !tbaa !3
  %v1322 = getelementptr i8, ptr %env, i64 32
  %v1323 = load ptr, ptr %v1322, align 8, !tbaa !3
  %v1324 = getelementptr i8, ptr %env, i64 40
  %v1325 = load ptr, ptr %v1324, align 8, !tbaa !3
  %v1326 = getelementptr i8, ptr %env, i64 48
  %v1327 = load ptr, ptr %v1326, align 8, !tbaa !3
  %v1328 = getelementptr i8, ptr %env, i64 56
  %v1329 = load ptr, ptr %v1328, align 8, !tbaa !3
  %v1330 = call ptr @mlf_force(ptr %arg)
  %v1331 = call ptr @mlf_prim2(i64 10, ptr %v1330, ptr inttoptr (i64 125 to ptr))
  %v1332 = icmp eq ptr %v1331, inttoptr (i64 6 to ptr)
  br i1 %v1332, label %yes.1333, label %no.1334
yes.1333:
  %v1336 = call ptr @mlf_constructor_new(i64 1, i64 3)
  %v1337 = getelementptr i8, ptr %v1336, i64 40
  %v1338 = load ptr, ptr %v1337, align 8, !tbaa !3
  %v1339 = getelementptr i8, ptr %v1338, i64 24
  store ptr %v1321, ptr %v1339, align 8, !tbaa !3
  %v1340 = getelementptr i8, ptr %v1338, i64 32
  store ptr %v1323, ptr %v1340, align 8, !tbaa !3
  %v1341 = getelementptr i8, ptr %v1338, i64 40
  store ptr %v1325, ptr %v1341, align 8, !tbaa !3
  %v1342 = call ptr @mlf_prim1(i64 0, ptr %v1336)
  br label %join.1335
no.1334:
  %v1433 = call ptr @mlf_env_new(i64 2)
  %v1434 = getelementptr i8, ptr %v1433, i64 24
  store ptr %v1327, ptr %v1434, align 8, !tbaa !3
  %v1435 = getelementptr i8, ptr %v1433, i64 32
  store ptr %v1329, ptr %v1435, align 8, !tbaa !3
  %v1436 = call ptr @mlf_thunk(ptr @mlf.code.1343, ptr %v1433)
  %v1975 = call ptr @mlf_env_new(i64 4)
  %v1976 = getelementptr i8, ptr %v1975, i64 24
  store ptr %v1321, ptr %v1976, align 8, !tbaa !3
  %v1977 = getelementptr i8, ptr %v1975, i64 32
  store ptr %v1323, ptr %v1977, align 8, !tbaa !3
  %v1978 = getelementptr i8, ptr %v1975, i64 40
  store ptr %v1325, ptr %v1978, align 8, !tbaa !3
  %v1979 = getelementptr i8, ptr %v1975, i64 48
  store ptr %v1327, ptr %v1979, align 8, !tbaa !3
  %v1980 = call ptr @mlf_closure(ptr @mlf.code.1437, ptr %v1975)
  %v1981 = call ptr @mlf_prim2(i64 1, ptr %v1436, ptr %v1980)
  br label %join.1335
join.1335:
  %v1982 = phi ptr [ %v1342, %yes.1333 ], [ %v1981, %no.1334 ]
  ret ptr %v1982
}

define private ptr @mlf.code.1290(ptr %env, ptr %arg) {
entry:
  %v1291 = getelementptr i8, ptr %env, i64 24
  %v1292 = load ptr, ptr %v1291, align 8, !tbaa !3
  %v1293 = getelementptr i8, ptr %env, i64 32
  %v1294 = load ptr, ptr %v1293, align 8, !tbaa !3
  %v1295 = getelementptr i8, ptr %env, i64 40
  %v1296 = load ptr, ptr %v1295, align 8, !tbaa !3
  %v1297 = getelementptr i8, ptr %env, i64 48
  %v1298 = load ptr, ptr %v1297, align 8, !tbaa !3
  %v1299 = call ptr @mlf_force(ptr %arg)
  %v1300 = call ptr @mlf_prim2(i64 10, ptr %v1299, ptr inttoptr (i64 1 to ptr))
  %v1301 = icmp eq ptr %v1300, inttoptr (i64 6 to ptr)
  br i1 %v1301, label %yes.1302, label %no.1303
yes.1302:
  %v1305 = call ptr @mlf_constructor_new(i64 1, i64 3)
  %v1306 = getelementptr i8, ptr %v1305, i64 40
  %v1307 = load ptr, ptr %v1306, align 8, !tbaa !3
  %v1308 = getelementptr i8, ptr %v1307, i64 24
  store ptr %v1292, ptr %v1308, align 8, !tbaa !3
  %v1309 = getelementptr i8, ptr %v1307, i64 32
  store ptr %v1294, ptr %v1309, align 8, !tbaa !3
  %v1310 = getelementptr i8, ptr %v1307, i64 40
  store ptr %v1296, ptr %v1310, align 8, !tbaa !3
  %v1311 = call ptr @mlf_prim1(i64 0, ptr %v1305)
  br label %join.1304
no.1303:
  %v1316 = call ptr @mlf_env_new(i64 1)
  %v1317 = getelementptr i8, ptr %v1316, i64 24
  store ptr %v1298, ptr %v1317, align 8, !tbaa !3
  %v1318 = call ptr @mlf_thunk(ptr @mlf.code.1312, ptr %v1316)
  %v1983 = call ptr @mlf_env_new(i64 5)
  %v1984 = getelementptr i8, ptr %v1983, i64 24
  store ptr %v1292, ptr %v1984, align 8, !tbaa !3
  %v1985 = getelementptr i8, ptr %v1983, i64 32
  store ptr %v1294, ptr %v1985, align 8, !tbaa !3
  %v1986 = getelementptr i8, ptr %v1983, i64 40
  store ptr %v1296, ptr %v1986, align 8, !tbaa !3
  %v1987 = getelementptr i8, ptr %v1983, i64 48
  store ptr %v1298, ptr %v1987, align 8, !tbaa !3
  %v1988 = getelementptr i8, ptr %v1983, i64 56
  store ptr %v1299, ptr %v1988, align 8, !tbaa !3
  %v1989 = call ptr @mlf_closure(ptr @mlf.code.1319, ptr %v1983)
  %v1990 = call ptr @mlf_prim2(i64 1, ptr %v1318, ptr %v1989)
  br label %join.1304
join.1304:
  %v1991 = phi ptr [ %v1311, %yes.1302 ], [ %v1990, %no.1303 ]
  ret ptr %v1991
}

define private ptr @mlf.code.1276(ptr %env, ptr %arg) {
entry:
  %v1277 = getelementptr i8, ptr %env, i64 24
  %v1278 = load ptr, ptr %v1277, align 8, !tbaa !3
  %v1279 = getelementptr i8, ptr %env, i64 32
  %v1280 = load ptr, ptr %v1279, align 8, !tbaa !3
  %v1281 = getelementptr i8, ptr %env, i64 40
  %v1282 = load ptr, ptr %v1281, align 8, !tbaa !3
  %v1287 = call ptr @mlf_env_new(i64 1)
  %v1288 = getelementptr i8, ptr %v1287, i64 24
  store ptr %arg, ptr %v1288, align 8, !tbaa !3
  %v1289 = call ptr @mlf_thunk(ptr @mlf.code.1283, ptr %v1287)
  %v1992 = call ptr @mlf_env_new(i64 4)
  %v1993 = getelementptr i8, ptr %v1992, i64 24
  store ptr %v1278, ptr %v1993, align 8, !tbaa !3
  %v1994 = getelementptr i8, ptr %v1992, i64 32
  store ptr %v1280, ptr %v1994, align 8, !tbaa !3
  %v1995 = getelementptr i8, ptr %v1992, i64 40
  store ptr %v1282, ptr %v1995, align 8, !tbaa !3
  %v1996 = getelementptr i8, ptr %v1992, i64 48
  store ptr %arg, ptr %v1996, align 8, !tbaa !3
  %v1997 = call ptr @mlf_closure(ptr @mlf.code.1290, ptr %v1992)
  %v1998 = call ptr @mlf_prim2(i64 1, ptr %v1289, ptr %v1997)
  ret ptr %v1998
}

define private ptr @mlf.worker.38(ptr %a0, ptr %a1, ptr %a2) {
entry:
  %v1275 = call ptr @mlf_primitive(i64 41)
  %v1999 = call ptr @mlf_env_new(i64 3)
  %v2000 = getelementptr i8, ptr %v1999, i64 24
  store ptr %a0, ptr %v2000, align 8, !tbaa !3
  %v2001 = getelementptr i8, ptr %v1999, i64 32
  store ptr %a1, ptr %v2001, align 8, !tbaa !3
  %v2002 = getelementptr i8, ptr %v1999, i64 40
  store ptr %a2, ptr %v2002, align 8, !tbaa !3
  %v2003 = call ptr @mlf_closure(ptr @mlf.code.1276, ptr %v1999)
  %v2004 = call ptr @mlf_prim2(i64 1, ptr %v1275, ptr %v2003)
  ret ptr %v2004
}

define private ptr @mlf.numeric.entry.564(ptr %env, ptr %arg) {
entry:
  %v565 = getelementptr i8, ptr %env, i64 24
  %v566 = load ptr, ptr %v565, align 8, !tbaa !3
  %v567 = getelementptr i8, ptr %env, i64 32
  %v568 = load ptr, ptr %v567, align 8, !tbaa !3
  %v569 = getelementptr i8, ptr %env, i64 40
  %v570 = load ptr, ptr %v569, align 8, !tbaa !3
  %v571 = call ptr @mlf_peek(ptr %v566)
  %v572 = call ptr @mlf_peek(ptr %v568)
  %v573 = call ptr @mlf_peek(ptr %v570)
  %v574 = icmp ne ptr %v571, null
  %v575 = icmp ne ptr %v572, null
  %v576 = icmp ne ptr %v573, null
  %v577 = and i1 true, %v574
  %v578 = and i1 %v577, %v575
  %v579 = and i1 %v578, %v576
  br i1 %v579, label %yes.580, label %no.581
yes.580:
  %v1273 = call ptr @mlf.numeric.38(ptr %v571, ptr %v572, ptr %v573)
  %v1274 = call ptr @mlf_prim1(i64 0, ptr %v1273)
  br label %join.582
no.581:
  %v2005 = call ptr @mlf.worker.38(ptr %v566, ptr %v568, ptr %v570)
  br label %join.582
join.582:
  %v2006 = phi ptr [ %v1274, %yes.580 ], [ %v2005, %no.581 ]
  ret ptr %v2006
}

define private ptr @mlf.code.561(ptr %env, ptr %arg) {
entry:
  %v562 = getelementptr i8, ptr %env, i64 24
  %v563 = load ptr, ptr %v562, align 8, !tbaa !3
  %v2007 = call ptr @mlf_env_new(i64 3)
  %v2008 = getelementptr i8, ptr %v2007, i64 24
  store ptr %v563, ptr %v2008, align 8, !tbaa !3
  %v2009 = getelementptr i8, ptr %v2007, i64 32
  store ptr inttoptr (i64 1 to ptr), ptr %v2009, align 8, !tbaa !3
  %v2010 = getelementptr i8, ptr %v2007, i64 40
  store ptr inttoptr (i64 2049 to ptr), ptr %v2010, align 8, !tbaa !3
  %v2011 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.564, ptr %v2007)
  ret ptr %v2011
}

define private ptr @mlf.numeric.58.piii(ptr %a0, ptr %a1, ptr %a2, ptr %a3) alwaysinline {
entry:
  %v2101 = ptrtoint ptr %a1 to i64
  %v2102 = ptrtoint ptr %a2 to i64
  %v2103 = icmp slt i64 %v2101, %v2102
  %v2104 = select i1 %v2103, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v2105 = icmp eq ptr %v2104, inttoptr (i64 6 to ptr)
  br i1 %v2105, label %tail.yes.2106, label %tail.no.2107
tail.yes.2106:
  %v2108 = getelementptr i8, ptr %a0, i64 24
  %v2109 = load i64, ptr %v2108, align 8, !tbaa !3
  %v2110 = getelementptr i8, ptr %a0, i64 32
  %v2111 = load ptr, ptr %v2110, align 8, !tbaa !3
  %v2112 = ptrtoint ptr %a1 to i64
  %v2113 = ashr i64 %v2112, 1
  %v2114 = and i64 %v2112, 1
  %v2115 = icmp ne i64 %v2114, 0
  %v2116 = icmp ult i64 %v2113, %v2109
  %v2117 = and i1 %v2115, %v2116
  br i1 %v2117, label %array.valid.2118, label %array.invalid.2119
array.invalid.2119:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2118:
  %v2120 = getelementptr i8, ptr %v2111, i64 %v2113
  %v2121 = load i8, ptr %v2120, align 1, !tbaa !4
  %v2122 = zext i8 %v2121 to i64
  %v2123 = shl i64 %v2122, 1
  %v2124 = or i64 %v2123, 1
  %v2125 = inttoptr i64 %v2124 to ptr
  %v2126 = ptrtoint ptr %a1 to i64
  %v2127 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2128 = sub i64 %v2127, 1
  %v2129 = add nsw i64 %v2126, %v2128
  %v2130 = inttoptr i64 %v2129 to ptr
  %v2131 = ptrtoint ptr %a3 to i64
  %v2132 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v2133 = ashr i64 %v2131, 1
  %v2134 = ashr i64 %v2132, 1
  %v2135 = mul nsw i64 %v2133, %v2134
  %v2136 = shl i64 %v2135, 1
  %v2137 = or i64 %v2136, 1
  %v2138 = inttoptr i64 %v2137 to ptr
  %v2139 = ptrtoint ptr %v2138 to i64
  %v2140 = ptrtoint ptr %v2125 to i64
  %v2141 = sub i64 %v2140, 1
  %v2142 = add nsw i64 %v2139, %v2141
  %v2143 = inttoptr i64 %v2142 to ptr
  %v2144 = musttail call ptr @mlf.numeric.58(ptr %a0, ptr %v2130, ptr %a2, ptr %v2143)
  ret ptr %v2144
tail.no.2107:
  ret ptr %a3
}

define private ptr @mlf.numeric.58(ptr %a0, ptr %a1, ptr %a2, ptr %a3) alwaysinline {
entry:
  %v2081 = ptrtoint ptr %a1 to i64
  %v2082 = and i64 %v2081, 1
  %v2083 = icmp ne i64 %v2082, 0
  %v2084 = icmp ult i64 %v2081, 4294967296
  %v2085 = and i1 %v2083, %v2084
  %v2086 = ptrtoint ptr %a2 to i64
  %v2087 = and i64 %v2086, 1
  %v2088 = icmp ne i64 %v2087, 0
  %v2089 = icmp ult i64 %v2086, 4294967296
  %v2090 = and i1 %v2088, %v2089
  %v2091 = ptrtoint ptr %a3 to i64
  %v2092 = and i64 %v2091, 1
  %v2093 = icmp ne i64 %v2092, 0
  %v2094 = icmp ult i64 %v2091, 4294967296
  %v2095 = and i1 %v2093, %v2094
  %v2096 = and i1 true, %v2085
  %v2097 = and i1 %v2096, %v2090
  %v2098 = and i1 %v2097, %v2095
  br i1 %v2098, label %range.fast.2099, label %range.general.2100
range.fast.2099:
  %v2145 = musttail call ptr @mlf.numeric.58.piii(ptr %a0, ptr %a1, ptr %a2, ptr %a3)
  ret ptr %v2145
range.general.2100:
  %v2146 = ptrtoint ptr %a1 to i64
  %v2147 = ptrtoint ptr %a2 to i64
  %v2148 = and i64 %v2146, %v2147
  %v2149 = and i64 %v2148, 1
  %v2150 = icmp ne i64 %v2149, 0
  br i1 %v2150, label %yes.2151, label %no.2152
yes.2151:
  %v2154 = icmp slt i64 %v2146, %v2147
  %v2155 = select i1 %v2154, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.2153
no.2152:
  %v2156 = call ptr @mlf_lt_int(ptr %a1, ptr %a2)
  br label %join.2153
join.2153:
  %v2157 = phi ptr [ %v2155, %yes.2151 ], [ %v2156, %no.2152 ]
  %v2158 = icmp eq ptr %v2157, inttoptr (i64 6 to ptr)
  br i1 %v2158, label %tail.yes.2159, label %tail.no.2160
tail.yes.2159:
  %v2161 = getelementptr i8, ptr %a0, i64 24
  %v2162 = load i64, ptr %v2161, align 8, !tbaa !3
  %v2163 = getelementptr i8, ptr %a0, i64 32
  %v2164 = load ptr, ptr %v2163, align 8, !tbaa !3
  %v2165 = ptrtoint ptr %a1 to i64
  %v2166 = ashr i64 %v2165, 1
  %v2167 = and i64 %v2165, 1
  %v2168 = icmp ne i64 %v2167, 0
  %v2169 = icmp ult i64 %v2166, %v2162
  %v2170 = and i1 %v2168, %v2169
  br i1 %v2170, label %array.valid.2171, label %array.invalid.2172
array.invalid.2172:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2171:
  %v2173 = getelementptr i8, ptr %v2164, i64 %v2166
  %v2174 = load i8, ptr %v2173, align 1, !tbaa !4
  %v2175 = zext i8 %v2174 to i64
  %v2176 = shl i64 %v2175, 1
  %v2177 = or i64 %v2176, 1
  %v2178 = inttoptr i64 %v2177 to ptr
  %v2179 = ptrtoint ptr %a1 to i64
  %v2180 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2181 = sub i64 %v2180, 1
  %v2182 = add nsw i64 %v2179, %v2181
  %v2183 = inttoptr i64 %v2182 to ptr
  %v2184 = ptrtoint ptr %a3 to i64
  %v2185 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v2186 = and i64 %v2184, %v2185
  %v2187 = and i64 %v2186, 1
  %v2188 = icmp ne i64 %v2187, 0
  br i1 %v2188, label %yes.2189, label %no.2190
yes.2189:
  %v2192 = ashr i64 %v2184, 1
  %v2193 = ashr i64 %v2185, 1
  %v2194 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v2192, i64 %v2193)
  %v2195 = extractvalue { i64, i1 } %v2194, 0
  %v2196 = extractvalue { i64, i1 } %v2194, 1
  %v2197 = xor i1 %v2196, true
  %v2198 = icmp sge i64 %v2195, -4611686018427387904
  %v2199 = icmp sle i64 %v2195, 4611686018427387903
  %v2200 = and i1 %v2198, %v2199
  %v2201 = and i1 %v2200, %v2197
  br i1 %v2201, label %yes.2202, label %no.2203
yes.2202:
  %v2205 = shl i64 %v2195, 1
  %v2206 = or i64 %v2205, 1
  %v2207 = inttoptr i64 %v2206 to ptr
  br label %join.2204
no.2203:
  %v2208 = call ptr @mlf_prim2(i64 14, ptr %a3, ptr inttoptr (i64 9 to ptr))
  br label %join.2204
join.2204:
  %v2209 = phi ptr [ %v2207, %yes.2202 ], [ %v2208, %no.2203 ]
  br label %join.2191
no.2190:
  %v2210 = call ptr @mlf_prim2(i64 14, ptr %a3, ptr inttoptr (i64 9 to ptr))
  br label %join.2191
join.2191:
  %v2211 = phi ptr [ %v2209, %join.2204 ], [ %v2210, %no.2190 ]
  %v2212 = ptrtoint ptr %v2211 to i64
  %v2213 = ptrtoint ptr %v2178 to i64
  %v2214 = and i64 %v2212, %v2213
  %v2215 = and i64 %v2214, 1
  %v2216 = icmp ne i64 %v2215, 0
  br i1 %v2216, label %yes.2217, label %no.2218
yes.2217:
  %v2220 = sub i64 %v2213, 1
  %v2221 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2212, i64 %v2220)
  %v2222 = extractvalue { i64, i1 } %v2221, 0
  %v2223 = extractvalue { i64, i1 } %v2221, 1
  br i1 %v2223, label %yes.2224, label %no.2225
yes.2224:
  %v2227 = call ptr @mlf_add_int(ptr %v2211, ptr %v2178)
  br label %join.2226
no.2225:
  %v2228 = inttoptr i64 %v2222 to ptr
  br label %join.2226
join.2226:
  %v2229 = phi ptr [ %v2227, %yes.2224 ], [ %v2228, %no.2225 ]
  br label %join.2219
no.2218:
  %v2230 = call ptr @mlf_add_int(ptr %v2211, ptr %v2178)
  br label %join.2219
join.2219:
  %v2231 = phi ptr [ %v2229, %join.2226 ], [ %v2230, %no.2218 ]
  %v2232 = musttail call ptr @mlf.numeric.58(ptr %a0, ptr %v2183, ptr %a2, ptr %v2231)
  ret ptr %v2232
tail.no.2160:
  ret ptr %a3
}

define private ptr @mlf.numeric.64(ptr %a0, ptr %a1) alwaysinline {
entry:
  %v2234 = ptrtoint ptr %a0 to i64
  %v2235 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v2236 = and i64 %v2234, %v2235
  %v2237 = and i64 %v2236, 1
  %v2238 = icmp ne i64 %v2237, 0
  br i1 %v2238, label %yes.2239, label %no.2240
yes.2239:
  %v2242 = icmp eq i64 %v2234, %v2235
  %v2243 = select i1 %v2242, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.2241
no.2240:
  %v2244 = call ptr @mlf_eq_int(ptr %a0, ptr inttoptr (i64 1 to ptr))
  br label %join.2241
join.2241:
  %v2245 = phi ptr [ %v2243, %yes.2239 ], [ %v2244, %no.2240 ]
  %v2246 = icmp eq ptr %v2245, inttoptr (i64 6 to ptr)
  br i1 %v2246, label %tail.yes.2247, label %tail.no.2248
tail.yes.2247:
  ret ptr %a1
tail.no.2248:
  %v2249 = ptrtoint ptr %a0 to i64
  %v2250 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2251 = and i64 %v2249, %v2250
  %v2252 = and i64 %v2251, 1
  %v2253 = icmp ne i64 %v2252, 0
  br i1 %v2253, label %yes.2254, label %no.2255
yes.2254:
  %v2257 = sub i64 %v2250, 1
  %v2258 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v2249, i64 %v2257)
  %v2259 = extractvalue { i64, i1 } %v2258, 0
  %v2260 = extractvalue { i64, i1 } %v2258, 1
  br i1 %v2260, label %yes.2261, label %no.2262
yes.2261:
  %v2264 = call ptr @mlf_sub_int(ptr %a0, ptr inttoptr (i64 3 to ptr))
  br label %join.2263
no.2262:
  %v2265 = inttoptr i64 %v2259 to ptr
  br label %join.2263
join.2263:
  %v2266 = phi ptr [ %v2264, %yes.2261 ], [ %v2265, %no.2262 ]
  br label %join.2256
no.2255:
  %v2267 = call ptr @mlf_sub_int(ptr %a0, ptr inttoptr (i64 3 to ptr))
  br label %join.2256
join.2256:
  %v2268 = phi ptr [ %v2266, %join.2263 ], [ %v2267, %no.2255 ]
  %v2269 = ptrtoint ptr %a1 to i64
  %v2270 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v2271 = and i64 %v2269, %v2270
  %v2272 = and i64 %v2271, 1
  %v2273 = icmp ne i64 %v2272, 0
  br i1 %v2273, label %yes.2274, label %no.2275
yes.2274:
  %v2277 = ashr i64 %v2269, 1
  %v2278 = ashr i64 %v2270, 1
  %v2279 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v2277, i64 %v2278)
  %v2280 = extractvalue { i64, i1 } %v2279, 0
  %v2281 = extractvalue { i64, i1 } %v2279, 1
  %v2282 = xor i1 %v2281, true
  %v2283 = icmp sge i64 %v2280, -4611686018427387904
  %v2284 = icmp sle i64 %v2280, 4611686018427387903
  %v2285 = and i1 %v2283, %v2284
  %v2286 = and i1 %v2285, %v2282
  br i1 %v2286, label %yes.2287, label %no.2288
yes.2287:
  %v2290 = shl i64 %v2280, 1
  %v2291 = or i64 %v2290, 1
  %v2292 = inttoptr i64 %v2291 to ptr
  br label %join.2289
no.2288:
  %v2293 = call ptr @mlf_prim2(i64 14, ptr %a1, ptr inttoptr (i64 9 to ptr))
  br label %join.2289
join.2289:
  %v2294 = phi ptr [ %v2292, %yes.2287 ], [ %v2293, %no.2288 ]
  br label %join.2276
no.2275:
  %v2295 = call ptr @mlf_prim2(i64 14, ptr %a1, ptr inttoptr (i64 9 to ptr))
  br label %join.2276
join.2276:
  %v2296 = phi ptr [ %v2294, %join.2289 ], [ %v2295, %no.2275 ]
  %v2297 = musttail call ptr @mlf.numeric.64(ptr %v2268, ptr %v2296)
  ret ptr %v2297
}

define private ptr @mlf.numeric.67(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6) alwaysinline {
entry:
  %v2319 = call ptr @mlf_add_int_table(ptr %a1, ptr %a6, ptr inttoptr (i64 3 to ptr))
  %v2320 = ptrtoint ptr %a5 to i64
  %v2321 = ptrtoint ptr %a3 to i64
  %v2322 = and i64 %v2320, %v2321
  %v2323 = and i64 %v2322, 1
  %v2324 = icmp ne i64 %v2323, 0
  br i1 %v2324, label %yes.2325, label %no.2326
yes.2325:
  %v2328 = sub i64 %v2321, 1
  %v2329 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2320, i64 %v2328)
  %v2330 = extractvalue { i64, i1 } %v2329, 0
  %v2331 = extractvalue { i64, i1 } %v2329, 1
  br i1 %v2331, label %yes.2332, label %no.2333
yes.2332:
  %v2335 = call ptr @mlf_add_int(ptr %a5, ptr %a3)
  br label %join.2334
no.2333:
  %v2336 = inttoptr i64 %v2330 to ptr
  br label %join.2334
join.2334:
  %v2337 = phi ptr [ %v2335, %yes.2332 ], [ %v2336, %no.2333 ]
  br label %join.2327
no.2326:
  %v2338 = call ptr @mlf_add_int(ptr %a5, ptr %a3)
  br label %join.2327
join.2327:
  %v2339 = phi ptr [ %v2337, %join.2334 ], [ %v2338, %no.2326 ]
  %v2340 = ptrtoint ptr %v2339 to i64
  %v2341 = ptrtoint ptr %a2 to i64
  %v2342 = and i64 %v2340, %v2341
  %v2343 = and i64 %v2342, 1
  %v2344 = icmp ne i64 %v2343, 0
  br i1 %v2344, label %yes.2345, label %no.2346
yes.2345:
  %v2348 = icmp slt i64 %v2340, %v2341
  %v2349 = select i1 %v2348, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.2347
no.2346:
  %v2350 = call ptr @mlf_lt_int(ptr %v2339, ptr %a2)
  br label %join.2347
join.2347:
  %v2351 = phi ptr [ %v2349, %yes.2345 ], [ %v2350, %no.2346 ]
  %v2352 = icmp eq ptr %v2351, inttoptr (i64 6 to ptr)
  br i1 %v2352, label %tail.yes.2353, label %tail.no.2354
tail.yes.2353:
  %v2355 = getelementptr i8, ptr %a0, i64 24
  %v2356 = load i64, ptr %v2355, align 8, !tbaa !3
  %v2357 = getelementptr i8, ptr %a0, i64 32
  %v2358 = load ptr, ptr %v2357, align 8, !tbaa !3
  %v2359 = ptrtoint ptr %v2339 to i64
  %v2360 = ashr i64 %v2359, 1
  %v2361 = and i64 %v2359, 1
  %v2362 = icmp ne i64 %v2361, 0
  %v2363 = icmp ult i64 %v2360, %v2356
  %v2364 = and i1 %v2362, %v2363
  br i1 %v2364, label %array.valid.2365, label %array.invalid.2366
array.invalid.2366:
  call void @mlf_bounds_failure()
  unreachable
array.valid.2365:
  %v2367 = getelementptr i8, ptr %v2358, i64 %v2360
  %v2368 = load i8, ptr %v2367, align 1, !tbaa !4
  %v2369 = zext i8 %v2368 to i64
  %v2370 = shl i64 %v2369, 1
  %v2371 = or i64 %v2370, 1
  %v2372 = inttoptr i64 %v2371 to ptr
  %v2373 = ptrtoint ptr %a6 to i64
  %v2374 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v2375 = and i64 %v2373, %v2374
  %v2376 = and i64 %v2375, 1
  %v2377 = icmp ne i64 %v2376, 0
  br i1 %v2377, label %yes.2378, label %no.2379
yes.2378:
  %v2381 = ashr i64 %v2373, 1
  %v2382 = ashr i64 %v2374, 1
  %v2383 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v2381, i64 %v2382)
  %v2384 = extractvalue { i64, i1 } %v2383, 0
  %v2385 = extractvalue { i64, i1 } %v2383, 1
  %v2386 = xor i1 %v2385, true
  %v2387 = icmp sge i64 %v2384, -4611686018427387904
  %v2388 = icmp sle i64 %v2384, 4611686018427387903
  %v2389 = and i1 %v2387, %v2388
  %v2390 = and i1 %v2389, %v2386
  br i1 %v2390, label %yes.2391, label %no.2392
yes.2391:
  %v2394 = shl i64 %v2384, 1
  %v2395 = or i64 %v2394, 1
  %v2396 = inttoptr i64 %v2395 to ptr
  br label %join.2393
no.2392:
  %v2397 = call ptr @mlf_prim2(i64 14, ptr %a6, ptr inttoptr (i64 9 to ptr))
  br label %join.2393
join.2393:
  %v2398 = phi ptr [ %v2396, %yes.2391 ], [ %v2397, %no.2392 ]
  br label %join.2380
no.2379:
  %v2399 = call ptr @mlf_prim2(i64 14, ptr %a6, ptr inttoptr (i64 9 to ptr))
  br label %join.2380
join.2380:
  %v2400 = phi ptr [ %v2398, %join.2393 ], [ %v2399, %no.2379 ]
  %v2401 = ptrtoint ptr %v2400 to i64
  %v2402 = ptrtoint ptr %a4 to i64
  %v2403 = and i64 %v2401, %v2402
  %v2404 = and i64 %v2403, 1
  %v2405 = icmp ne i64 %v2404, 0
  br i1 %v2405, label %yes.2406, label %no.2407
yes.2406:
  %v2409 = inttoptr i64 %v2403 to ptr
  br label %join.2408
no.2407:
  %v2410 = call ptr @mlf_prim2(i64 45, ptr %v2400, ptr %a4)
  br label %join.2408
join.2408:
  %v2411 = phi ptr [ %v2409, %yes.2406 ], [ %v2410, %no.2407 ]
  %v2412 = ptrtoint ptr %v2411 to i64
  %v2413 = ptrtoint ptr %v2372 to i64
  %v2414 = and i64 %v2412, %v2413
  %v2415 = and i64 %v2414, 1
  %v2416 = icmp ne i64 %v2415, 0
  br i1 %v2416, label %yes.2417, label %no.2418
yes.2417:
  %v2420 = sub i64 %v2413, 1
  %v2421 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2412, i64 %v2420)
  %v2422 = extractvalue { i64, i1 } %v2421, 0
  %v2423 = extractvalue { i64, i1 } %v2421, 1
  br i1 %v2423, label %yes.2424, label %no.2425
yes.2424:
  %v2427 = call ptr @mlf_add_int(ptr %v2411, ptr %v2372)
  br label %join.2426
no.2425:
  %v2428 = inttoptr i64 %v2422 to ptr
  br label %join.2426
join.2426:
  %v2429 = phi ptr [ %v2427, %yes.2424 ], [ %v2428, %no.2425 ]
  br label %join.2419
no.2418:
  %v2430 = call ptr @mlf_add_int(ptr %v2411, ptr %v2372)
  br label %join.2419
join.2419:
  %v2431 = phi ptr [ %v2429, %join.2426 ], [ %v2430, %no.2418 ]
  %v2432 = ptrtoint ptr %a5 to i64
  %v2433 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2434 = and i64 %v2432, %v2433
  %v2435 = and i64 %v2434, 1
  %v2436 = icmp ne i64 %v2435, 0
  br i1 %v2436, label %yes.2437, label %no.2438
yes.2437:
  %v2440 = sub i64 %v2433, 1
  %v2441 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2432, i64 %v2440)
  %v2442 = extractvalue { i64, i1 } %v2441, 0
  %v2443 = extractvalue { i64, i1 } %v2441, 1
  br i1 %v2443, label %yes.2444, label %no.2445
yes.2444:
  %v2447 = call ptr @mlf_add_int(ptr %a5, ptr inttoptr (i64 3 to ptr))
  br label %join.2446
no.2445:
  %v2448 = inttoptr i64 %v2442 to ptr
  br label %join.2446
join.2446:
  %v2449 = phi ptr [ %v2447, %yes.2444 ], [ %v2448, %no.2445 ]
  br label %join.2439
no.2438:
  %v2450 = call ptr @mlf_add_int(ptr %a5, ptr inttoptr (i64 3 to ptr))
  br label %join.2439
join.2439:
  %v2451 = phi ptr [ %v2449, %join.2446 ], [ %v2450, %no.2438 ]
  %v2452 = musttail call ptr @mlf.numeric.67(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %v2451, ptr %v2431)
  ret ptr %v2452
tail.no.2354:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.numeric.80(ptr %a0, ptr %a1, ptr %a2) {
entry:
  %v2060 = alloca [3 x ptr], align 8
  %v2061 = getelementptr ptr, ptr %v2060, i64 0
  store ptr %a0, ptr %v2061, align 8
  %v2062 = getelementptr ptr, ptr %v2060, i64 1
  store ptr %a1, ptr %v2062, align 8
  %v2063 = getelementptr ptr, ptr %v2060, i64 2
  store ptr %a2, ptr %v2063, align 8
  call void @mlf_gc_check(i64 3, ptr %v2060)
  %v2064 = call ptr @mlf_new_int_table()
  %v2065 = ptrtoint ptr %a1 to i64
  %v2066 = ptrtoint ptr %a2 to i64
  %v2067 = and i64 %v2065, %v2066
  %v2068 = and i64 %v2067, 1
  %v2069 = icmp ne i64 %v2068, 0
  br i1 %v2069, label %yes.2070, label %no.2071
yes.2070:
  %v2073 = icmp slt i64 %v2065, %v2066
  %v2074 = select i1 %v2073, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.2072
no.2071:
  %v2075 = call ptr @mlf_lt_int(ptr %a1, ptr %a2)
  br label %join.2072
join.2072:
  %v2076 = phi ptr [ %v2074, %yes.2070 ], [ %v2075, %no.2071 ]
  %v2077 = icmp eq ptr %v2076, inttoptr (i64 6 to ptr)
  br i1 %v2077, label %yes.2078, label %no.2079
yes.2078:
  br label %join.2080
no.2079:
  %v2233 = call ptr @mlf.numeric.58(ptr %a0, ptr inttoptr (i64 1 to ptr), ptr %a2, ptr inttoptr (i64 1 to ptr))
  %v2298 = call ptr @mlf.numeric.64(ptr %a2, ptr inttoptr (i64 3 to ptr))
  %v2299 = ptrtoint ptr %v2298 to i64
  %v2300 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v2301 = and i64 %v2299, %v2300
  %v2302 = and i64 %v2301, 1
  %v2303 = icmp ne i64 %v2302, 0
  br i1 %v2303, label %yes.2304, label %no.2305
yes.2304:
  %v2307 = sub i64 %v2300, 1
  %v2308 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v2299, i64 %v2307)
  %v2309 = extractvalue { i64, i1 } %v2308, 0
  %v2310 = extractvalue { i64, i1 } %v2308, 1
  br i1 %v2310, label %yes.2311, label %no.2312
yes.2311:
  %v2314 = call ptr @mlf_sub_int(ptr %v2298, ptr inttoptr (i64 3 to ptr))
  br label %join.2313
no.2312:
  %v2315 = inttoptr i64 %v2309 to ptr
  br label %join.2313
join.2313:
  %v2316 = phi ptr [ %v2314, %yes.2311 ], [ %v2315, %no.2312 ]
  br label %join.2306
no.2305:
  %v2317 = call ptr @mlf_sub_int(ptr %v2298, ptr inttoptr (i64 3 to ptr))
  br label %join.2306
join.2306:
  %v2318 = phi ptr [ %v2316, %join.2313 ], [ %v2317, %no.2305 ]
  %v2453 = call ptr @mlf.numeric.67(ptr %a0, ptr %v2064, ptr %a1, ptr %a2, ptr %v2318, ptr inttoptr (i64 1 to ptr), ptr %v2233)
  br label %join.2080
join.2080:
  %v2454 = phi ptr [ inttoptr (i64 4 to ptr), %yes.2078 ], [ %v2453, %join.2306 ]
  ret ptr %v2064
}

define private ptr @mlf.code.2518(ptr %env, ptr %arg) {
entry:
  %v2519 = getelementptr i8, ptr %env, i64 24
  %v2520 = load ptr, ptr %v2519, align 8, !tbaa !3
  %v2521 = getelementptr i8, ptr %env, i64 32
  %v2522 = load ptr, ptr %v2521, align 8, !tbaa !3
  %v2523 = call ptr @mlf_prim2(i64 36, ptr %v2520, ptr %v2522)
  ret ptr %v2523
}

define private ptr @mlf.code.2540(ptr %env, ptr %arg) {
entry:
  %v2541 = getelementptr i8, ptr %env, i64 24
  %v2542 = load ptr, ptr %v2541, align 8, !tbaa !3
  %v2543 = getelementptr i8, ptr %env, i64 32
  %v2544 = load ptr, ptr %v2543, align 8, !tbaa !3
  %v2545 = call ptr @mlf_force(ptr %v2542)
  %v2546 = call ptr @mlf_prim2(i64 14, ptr %v2545, ptr inttoptr (i64 9 to ptr))
  %v2547 = call ptr @mlf_force(ptr %v2544)
  %v2548 = call ptr @mlf_prim2(i64 8, ptr %v2546, ptr %v2547)
  ret ptr %v2548
}

define private ptr @mlf.code.2528(ptr %env, ptr %arg) {
entry:
  %v2529 = getelementptr i8, ptr %env, i64 24
  %v2530 = load ptr, ptr %v2529, align 8, !tbaa !3
  %v2531 = getelementptr i8, ptr %env, i64 32
  %v2532 = load ptr, ptr %v2531, align 8, !tbaa !3
  %v2533 = getelementptr i8, ptr %env, i64 40
  %v2534 = load ptr, ptr %v2533, align 8, !tbaa !3
  %v2535 = getelementptr i8, ptr %env, i64 48
  %v2536 = load ptr, ptr %v2535, align 8, !tbaa !3
  %v2537 = call ptr @mlf_force(ptr %v2532)
  %v2538 = call ptr @mlf_prim2(i64 8, ptr %v2537, ptr inttoptr (i64 3 to ptr))
  %v2539 = call ptr @mlf_force(ptr %v2534)
  %v2549 = call ptr @mlf_env_new(i64 2)
  %v2550 = getelementptr i8, ptr %v2549, i64 24
  store ptr %v2536, ptr %v2550, align 8, !tbaa !3
  %v2551 = getelementptr i8, ptr %v2549, i64 32
  store ptr %arg, ptr %v2551, align 8, !tbaa !3
  %v2552 = call ptr @mlf_thunk(ptr @mlf.code.2540, ptr %v2549)
  %v2553 = call ptr @mlf_env_new(i64 4)
  %v2554 = getelementptr i8, ptr %v2553, i64 24
  store ptr %v2530, ptr %v2554, align 8, !tbaa !3
  %v2555 = getelementptr i8, ptr %v2553, i64 32
  store ptr %v2538, ptr %v2555, align 8, !tbaa !3
  %v2556 = getelementptr i8, ptr %v2553, i64 40
  store ptr %v2539, ptr %v2556, align 8, !tbaa !3
  %v2557 = getelementptr i8, ptr %v2553, i64 48
  store ptr %v2552, ptr %v2557, align 8, !tbaa !3
  %v2558 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2487, ptr %v2553)
  ret ptr %v2558
}

define private ptr @mlf.worker.58(ptr %a0, ptr %a1, ptr %a2, ptr %a3) {
entry:
  %v2513 = call ptr @mlf_prim2(i64 11, ptr %a1, ptr %a2)
  %v2514 = icmp eq ptr %v2513, inttoptr (i64 6 to ptr)
  br i1 %v2514, label %yes.2515, label %no.2516
yes.2515:
  %v2524 = call ptr @mlf_env_new(i64 2)
  %v2525 = getelementptr i8, ptr %v2524, i64 24
  store ptr %a0, ptr %v2525, align 8, !tbaa !3
  %v2526 = getelementptr i8, ptr %v2524, i64 32
  store ptr %a1, ptr %v2526, align 8, !tbaa !3
  %v2527 = call ptr @mlf_thunk(ptr @mlf.code.2518, ptr %v2524)
  %v2559 = call ptr @mlf_env_new(i64 4)
  %v2560 = getelementptr i8, ptr %v2559, i64 24
  store ptr %a0, ptr %v2560, align 8, !tbaa !3
  %v2561 = getelementptr i8, ptr %v2559, i64 32
  store ptr %a1, ptr %v2561, align 8, !tbaa !3
  %v2562 = getelementptr i8, ptr %v2559, i64 40
  store ptr %a2, ptr %v2562, align 8, !tbaa !3
  %v2563 = getelementptr i8, ptr %v2559, i64 48
  store ptr %a3, ptr %v2563, align 8, !tbaa !3
  %v2564 = call ptr @mlf_closure(ptr @mlf.code.2528, ptr %v2559)
  %v2565 = call ptr @mlf_prim2(i64 1, ptr %v2527, ptr %v2564)
  br label %join.2517
no.2516:
  %v2566 = call ptr @mlf_prim1(i64 0, ptr %a3)
  br label %join.2517
join.2517:
  %v2567 = phi ptr [ %v2565, %yes.2515 ], [ %v2566, %no.2516 ]
  ret ptr %v2567
}

define private ptr @mlf.numeric.entry.2487(ptr %env, ptr %arg) {
entry:
  %v2488 = getelementptr i8, ptr %env, i64 24
  %v2489 = load ptr, ptr %v2488, align 8, !tbaa !3
  %v2490 = getelementptr i8, ptr %env, i64 32
  %v2491 = load ptr, ptr %v2490, align 8, !tbaa !3
  %v2492 = getelementptr i8, ptr %env, i64 40
  %v2493 = load ptr, ptr %v2492, align 8, !tbaa !3
  %v2494 = getelementptr i8, ptr %env, i64 48
  %v2495 = load ptr, ptr %v2494, align 8, !tbaa !3
  %v2496 = call ptr @mlf_peek(ptr %v2489)
  %v2497 = call ptr @mlf_peek(ptr %v2491)
  %v2498 = call ptr @mlf_peek(ptr %v2493)
  %v2499 = call ptr @mlf_peek(ptr %v2495)
  %v2500 = icmp ne ptr %v2496, null
  %v2501 = icmp ne ptr %v2497, null
  %v2502 = icmp ne ptr %v2498, null
  %v2503 = icmp ne ptr %v2499, null
  %v2504 = and i1 true, %v2500
  %v2505 = and i1 %v2504, %v2501
  %v2506 = and i1 %v2505, %v2502
  %v2507 = and i1 %v2506, %v2503
  br i1 %v2507, label %yes.2508, label %no.2509
yes.2508:
  %v2511 = call ptr @mlf.numeric.58(ptr %v2496, ptr %v2497, ptr %v2498, ptr %v2499)
  %v2512 = call ptr @mlf_prim1(i64 0, ptr %v2511)
  br label %join.2510
no.2509:
  %v2568 = call ptr @mlf_force(ptr %v2491)
  %v2569 = call ptr @mlf_force(ptr %v2493)
  %v2570 = call ptr @mlf.worker.58(ptr %v2489, ptr %v2568, ptr %v2569, ptr %v2495)
  br label %join.2510
join.2510:
  %v2571 = phi ptr [ %v2512, %yes.2508 ], [ %v2570, %no.2509 ]
  ret ptr %v2571
}

define private ptr @mlf.code.2482(ptr %env, ptr %arg) {
entry:
  %v2483 = getelementptr i8, ptr %env, i64 24
  %v2484 = load ptr, ptr %v2483, align 8, !tbaa !3
  %v2485 = getelementptr i8, ptr %env, i64 32
  %v2486 = load ptr, ptr %v2485, align 8, !tbaa !3
  %v2572 = call ptr @mlf_force(ptr %v2486)
  %v2573 = call ptr @mlf_env_new(i64 4)
  %v2574 = getelementptr i8, ptr %v2573, i64 24
  store ptr %v2484, ptr %v2574, align 8, !tbaa !3
  %v2575 = getelementptr i8, ptr %v2573, i64 32
  store ptr inttoptr (i64 1 to ptr), ptr %v2575, align 8, !tbaa !3
  %v2576 = getelementptr i8, ptr %v2573, i64 40
  store ptr %v2572, ptr %v2576, align 8, !tbaa !3
  %v2577 = getelementptr i8, ptr %v2573, i64 48
  store ptr inttoptr (i64 1 to ptr), ptr %v2577, align 8, !tbaa !3
  %v2578 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2487, ptr %v2573)
  ret ptr %v2578
}

define private ptr @mlf.code.2618(ptr %env, ptr %arg) {
entry:
  %v2619 = getelementptr i8, ptr %env, i64 24
  %v2620 = load ptr, ptr %v2619, align 8, !tbaa !3
  %v2621 = call ptr @mlf_force(ptr %v2620)
  %v2622 = call ptr @mlf_prim2(i64 14, ptr %v2621, ptr inttoptr (i64 9 to ptr))
  ret ptr %v2622
}

define private ptr @mlf.worker.64(ptr %a0, ptr %a1) {
entry:
  %v2611 = call ptr @mlf_prim2(i64 10, ptr %a0, ptr inttoptr (i64 1 to ptr))
  %v2612 = icmp eq ptr %v2611, inttoptr (i64 6 to ptr)
  br i1 %v2612, label %yes.2613, label %no.2614
yes.2613:
  %v2616 = call ptr @mlf_prim1(i64 0, ptr %a1)
  br label %join.2615
no.2614:
  %v2617 = call ptr @mlf_prim2(i64 9, ptr %a0, ptr inttoptr (i64 3 to ptr))
  %v2623 = call ptr @mlf_env_new(i64 1)
  %v2624 = getelementptr i8, ptr %v2623, i64 24
  store ptr %a1, ptr %v2624, align 8, !tbaa !3
  %v2625 = call ptr @mlf_thunk(ptr @mlf.code.2618, ptr %v2623)
  %v2626 = call ptr @mlf_env_new(i64 2)
  %v2627 = getelementptr i8, ptr %v2626, i64 24
  store ptr %v2617, ptr %v2627, align 8, !tbaa !3
  %v2628 = getelementptr i8, ptr %v2626, i64 32
  store ptr %v2625, ptr %v2628, align 8, !tbaa !3
  %v2629 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2595, ptr %v2626)
  br label %join.2615
join.2615:
  %v2630 = phi ptr [ %v2616, %yes.2613 ], [ %v2629, %no.2614 ]
  ret ptr %v2630
}

define private ptr @mlf.numeric.entry.2595(ptr %env, ptr %arg) {
entry:
  %v2596 = getelementptr i8, ptr %env, i64 24
  %v2597 = load ptr, ptr %v2596, align 8, !tbaa !3
  %v2598 = getelementptr i8, ptr %env, i64 32
  %v2599 = load ptr, ptr %v2598, align 8, !tbaa !3
  %v2600 = call ptr @mlf_peek(ptr %v2597)
  %v2601 = call ptr @mlf_peek(ptr %v2599)
  %v2602 = icmp ne ptr %v2600, null
  %v2603 = icmp ne ptr %v2601, null
  %v2604 = and i1 true, %v2602
  %v2605 = and i1 %v2604, %v2603
  br i1 %v2605, label %yes.2606, label %no.2607
yes.2606:
  %v2609 = call ptr @mlf.numeric.64(ptr %v2600, ptr %v2601)
  %v2610 = call ptr @mlf_prim1(i64 0, ptr %v2609)
  br label %join.2608
no.2607:
  %v2631 = call ptr @mlf_force(ptr %v2597)
  %v2632 = call ptr @mlf.worker.64(ptr %v2631, ptr %v2599)
  br label %join.2608
join.2608:
  %v2633 = phi ptr [ %v2610, %yes.2606 ], [ %v2632, %no.2607 ]
  ret ptr %v2633
}

define private ptr @mlf.code.2592(ptr %env, ptr %arg) {
entry:
  %v2593 = getelementptr i8, ptr %env, i64 24
  %v2594 = load ptr, ptr %v2593, align 8, !tbaa !3
  %v2634 = call ptr @mlf_force(ptr %v2594)
  %v2635 = call ptr @mlf_env_new(i64 2)
  %v2636 = getelementptr i8, ptr %v2635, i64 24
  store ptr %v2634, ptr %v2636, align 8, !tbaa !3
  %v2637 = getelementptr i8, ptr %v2635, i64 32
  store ptr inttoptr (i64 3 to ptr), ptr %v2637, align 8, !tbaa !3
  %v2638 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2595, ptr %v2635)
  ret ptr %v2638
}

define private ptr @mlf.code.2694(ptr %env, ptr %arg) {
entry:
  %v2695 = getelementptr i8, ptr %env, i64 24
  %v2696 = load ptr, ptr %v2695, align 8, !tbaa !3
  %v2697 = getelementptr i8, ptr %env, i64 32
  %v2698 = load ptr, ptr %v2697, align 8, !tbaa !3
  %v2699 = call ptr @mlf_prim2(i64 43, ptr %v2696, ptr %v2698)
  ret ptr %v2699
}

define private ptr @mlf.code.2726(ptr %env, ptr %arg) {
entry:
  %v2727 = getelementptr i8, ptr %env, i64 24
  %v2728 = load ptr, ptr %v2727, align 8, !tbaa !3
  %v2729 = call ptr @mlf_force(ptr %v2728)
  %v2730 = call ptr @mlf_prim2(i64 8, ptr %v2729, ptr inttoptr (i64 3 to ptr))
  ret ptr %v2730
}

define private ptr @mlf.code.2719(ptr %env, ptr %arg) {
entry:
  %v2720 = getelementptr i8, ptr %env, i64 24
  %v2721 = load ptr, ptr %v2720, align 8, !tbaa !3
  %v2722 = getelementptr i8, ptr %env, i64 32
  %v2723 = load ptr, ptr %v2722, align 8, !tbaa !3
  %v2724 = getelementptr i8, ptr %env, i64 40
  %v2725 = load ptr, ptr %v2724, align 8, !tbaa !3
  %v2731 = call ptr @mlf_env_new(i64 1)
  %v2732 = getelementptr i8, ptr %v2731, i64 24
  store ptr %v2725, ptr %v2732, align 8, !tbaa !3
  %v2733 = call ptr @mlf_thunk(ptr @mlf.code.2726, ptr %v2731)
  %v2734 = call ptr @mlf_prim3(i64 44, ptr %v2721, ptr %v2723, ptr %v2733)
  ret ptr %v2734
}

define private ptr @mlf.code.2764(ptr %env, ptr %arg) {
entry:
  %v2765 = getelementptr i8, ptr %env, i64 24
  %v2766 = load ptr, ptr %v2765, align 8, !tbaa !3
  %v2767 = getelementptr i8, ptr %env, i64 32
  %v2768 = load ptr, ptr %v2767, align 8, !tbaa !3
  %v2769 = call ptr @mlf_prim2(i64 36, ptr %v2766, ptr %v2768)
  ret ptr %v2769
}

define private ptr @mlf.code.2789(ptr %env, ptr %arg) {
entry:
  %v2790 = getelementptr i8, ptr %env, i64 24
  %v2791 = load ptr, ptr %v2790, align 8, !tbaa !3
  %v2792 = getelementptr i8, ptr %env, i64 32
  %v2793 = load ptr, ptr %v2792, align 8, !tbaa !3
  %v2794 = getelementptr i8, ptr %env, i64 40
  %v2795 = load ptr, ptr %v2794, align 8, !tbaa !3
  %v2796 = call ptr @mlf_force(ptr %v2793)
  %v2797 = call ptr @mlf_prim2(i64 14, ptr %v2796, ptr inttoptr (i64 9 to ptr))
  %v2798 = call ptr @mlf_force(ptr %v2791)
  %v2799 = call ptr @mlf_prim2(i64 45, ptr %v2797, ptr %v2798)
  %v2800 = call ptr @mlf_force(ptr %v2795)
  %v2801 = call ptr @mlf_prim2(i64 8, ptr %v2799, ptr %v2800)
  ret ptr %v2801
}

define private ptr @mlf.code.2807(ptr %env, ptr %arg) {
entry:
  %v2808 = getelementptr i8, ptr %env, i64 24
  %v2809 = load ptr, ptr %v2808, align 8, !tbaa !3
  %v2810 = call ptr @mlf_force(ptr %v2809)
  %v2811 = call ptr @mlf_prim2(i64 8, ptr %v2810, ptr inttoptr (i64 3 to ptr))
  ret ptr %v2811
}

define private ptr @mlf.code.2774(ptr %env, ptr %arg) {
entry:
  %v2775 = getelementptr i8, ptr %env, i64 24
  %v2776 = load ptr, ptr %v2775, align 8, !tbaa !3
  %v2777 = getelementptr i8, ptr %env, i64 32
  %v2778 = load ptr, ptr %v2777, align 8, !tbaa !3
  %v2779 = getelementptr i8, ptr %env, i64 40
  %v2780 = load ptr, ptr %v2779, align 8, !tbaa !3
  %v2781 = getelementptr i8, ptr %env, i64 48
  %v2782 = load ptr, ptr %v2781, align 8, !tbaa !3
  %v2783 = getelementptr i8, ptr %env, i64 56
  %v2784 = load ptr, ptr %v2783, align 8, !tbaa !3
  %v2785 = getelementptr i8, ptr %env, i64 64
  %v2786 = load ptr, ptr %v2785, align 8, !tbaa !3
  %v2787 = getelementptr i8, ptr %env, i64 72
  %v2788 = load ptr, ptr %v2787, align 8, !tbaa !3
  %v2802 = call ptr @mlf_env_new(i64 3)
  %v2803 = getelementptr i8, ptr %v2802, i64 24
  store ptr %v2784, ptr %v2803, align 8, !tbaa !3
  %v2804 = getelementptr i8, ptr %v2802, i64 32
  store ptr %v2788, ptr %v2804, align 8, !tbaa !3
  %v2805 = getelementptr i8, ptr %v2802, i64 40
  store ptr %arg, ptr %v2805, align 8, !tbaa !3
  %v2806 = call ptr @mlf_thunk(ptr @mlf.code.2789, ptr %v2802)
  %v2812 = call ptr @mlf_env_new(i64 1)
  %v2813 = getelementptr i8, ptr %v2812, i64 24
  store ptr %v2786, ptr %v2813, align 8, !tbaa !3
  %v2814 = call ptr @mlf_thunk(ptr @mlf.code.2807, ptr %v2812)
  %v2815 = call ptr @mlf_env_new(i64 7)
  %v2816 = getelementptr i8, ptr %v2815, i64 24
  store ptr %v2776, ptr %v2816, align 8, !tbaa !3
  %v2817 = getelementptr i8, ptr %v2815, i64 32
  store ptr %v2778, ptr %v2817, align 8, !tbaa !3
  %v2818 = getelementptr i8, ptr %v2815, i64 40
  store ptr %v2780, ptr %v2818, align 8, !tbaa !3
  %v2819 = getelementptr i8, ptr %v2815, i64 48
  store ptr %v2782, ptr %v2819, align 8, !tbaa !3
  %v2820 = getelementptr i8, ptr %v2815, i64 56
  store ptr %v2784, ptr %v2820, align 8, !tbaa !3
  %v2821 = getelementptr i8, ptr %v2815, i64 64
  store ptr %v2814, ptr %v2821, align 8, !tbaa !3
  %v2822 = getelementptr i8, ptr %v2815, i64 72
  store ptr %v2806, ptr %v2822, align 8, !tbaa !3
  %v2823 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2653, ptr %v2815)
  ret ptr %v2823
}

define private ptr @mlf.code.2740(ptr %env, ptr %arg) {
entry:
  %v2741 = getelementptr i8, ptr %env, i64 24
  %v2742 = load ptr, ptr %v2741, align 8, !tbaa !3
  %v2743 = getelementptr i8, ptr %env, i64 32
  %v2744 = load ptr, ptr %v2743, align 8, !tbaa !3
  %v2745 = getelementptr i8, ptr %env, i64 40
  %v2746 = load ptr, ptr %v2745, align 8, !tbaa !3
  %v2747 = getelementptr i8, ptr %env, i64 48
  %v2748 = load ptr, ptr %v2747, align 8, !tbaa !3
  %v2749 = getelementptr i8, ptr %env, i64 56
  %v2750 = load ptr, ptr %v2749, align 8, !tbaa !3
  %v2751 = getelementptr i8, ptr %env, i64 64
  %v2752 = load ptr, ptr %v2751, align 8, !tbaa !3
  %v2753 = getelementptr i8, ptr %env, i64 72
  %v2754 = load ptr, ptr %v2753, align 8, !tbaa !3
  %v2755 = call ptr @mlf_force(ptr %v2752)
  %v2756 = call ptr @mlf_force(ptr %v2748)
  %v2757 = call ptr @mlf_prim2(i64 8, ptr %v2755, ptr %v2756)
  %v2758 = call ptr @mlf_force(ptr %v2746)
  %v2759 = call ptr @mlf_prim2(i64 11, ptr %v2757, ptr %v2758)
  %v2760 = icmp eq ptr %v2759, inttoptr (i64 6 to ptr)
  br i1 %v2760, label %yes.2761, label %no.2762
yes.2761:
  %v2770 = call ptr @mlf_env_new(i64 2)
  %v2771 = getelementptr i8, ptr %v2770, i64 24
  store ptr %v2742, ptr %v2771, align 8, !tbaa !3
  %v2772 = getelementptr i8, ptr %v2770, i64 32
  store ptr %v2757, ptr %v2772, align 8, !tbaa !3
  %v2773 = call ptr @mlf_thunk(ptr @mlf.code.2764, ptr %v2770)
  %v2824 = call ptr @mlf_env_new(i64 7)
  %v2825 = getelementptr i8, ptr %v2824, i64 24
  store ptr %v2742, ptr %v2825, align 8, !tbaa !3
  %v2826 = getelementptr i8, ptr %v2824, i64 32
  store ptr %v2744, ptr %v2826, align 8, !tbaa !3
  %v2827 = getelementptr i8, ptr %v2824, i64 40
  store ptr %v2758, ptr %v2827, align 8, !tbaa !3
  %v2828 = getelementptr i8, ptr %v2824, i64 48
  store ptr %v2756, ptr %v2828, align 8, !tbaa !3
  %v2829 = getelementptr i8, ptr %v2824, i64 56
  store ptr %v2750, ptr %v2829, align 8, !tbaa !3
  %v2830 = getelementptr i8, ptr %v2824, i64 64
  store ptr %v2755, ptr %v2830, align 8, !tbaa !3
  %v2831 = getelementptr i8, ptr %v2824, i64 72
  store ptr %v2754, ptr %v2831, align 8, !tbaa !3
  %v2832 = call ptr @mlf_closure(ptr @mlf.code.2774, ptr %v2824)
  %v2833 = call ptr @mlf_prim2(i64 1, ptr %v2773, ptr %v2832)
  br label %join.2763
no.2762:
  %v2834 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.2763
join.2763:
  %v2835 = phi ptr [ %v2833, %yes.2761 ], [ %v2834, %no.2762 ]
  ret ptr %v2835
}

define private ptr @mlf.code.2704(ptr %env, ptr %arg) {
entry:
  %v2705 = getelementptr i8, ptr %env, i64 24
  %v2706 = load ptr, ptr %v2705, align 8, !tbaa !3
  %v2707 = getelementptr i8, ptr %env, i64 32
  %v2708 = load ptr, ptr %v2707, align 8, !tbaa !3
  %v2709 = getelementptr i8, ptr %env, i64 40
  %v2710 = load ptr, ptr %v2709, align 8, !tbaa !3
  %v2711 = getelementptr i8, ptr %env, i64 48
  %v2712 = load ptr, ptr %v2711, align 8, !tbaa !3
  %v2713 = getelementptr i8, ptr %env, i64 56
  %v2714 = load ptr, ptr %v2713, align 8, !tbaa !3
  %v2715 = getelementptr i8, ptr %env, i64 64
  %v2716 = load ptr, ptr %v2715, align 8, !tbaa !3
  %v2717 = getelementptr i8, ptr %env, i64 72
  %v2718 = load ptr, ptr %v2717, align 8, !tbaa !3
  %v2735 = call ptr @mlf_env_new(i64 3)
  %v2736 = getelementptr i8, ptr %v2735, i64 24
  store ptr %v2708, ptr %v2736, align 8, !tbaa !3
  %v2737 = getelementptr i8, ptr %v2735, i64 32
  store ptr %v2718, ptr %v2737, align 8, !tbaa !3
  %v2738 = getelementptr i8, ptr %v2735, i64 40
  store ptr %arg, ptr %v2738, align 8, !tbaa !3
  %v2739 = call ptr @mlf_thunk(ptr @mlf.code.2719, ptr %v2735)
  %v2836 = call ptr @mlf_env_new(i64 7)
  %v2837 = getelementptr i8, ptr %v2836, i64 24
  store ptr %v2706, ptr %v2837, align 8, !tbaa !3
  %v2838 = getelementptr i8, ptr %v2836, i64 32
  store ptr %v2708, ptr %v2838, align 8, !tbaa !3
  %v2839 = getelementptr i8, ptr %v2836, i64 40
  store ptr %v2710, ptr %v2839, align 8, !tbaa !3
  %v2840 = getelementptr i8, ptr %v2836, i64 48
  store ptr %v2712, ptr %v2840, align 8, !tbaa !3
  %v2841 = getelementptr i8, ptr %v2836, i64 56
  store ptr %v2714, ptr %v2841, align 8, !tbaa !3
  %v2842 = getelementptr i8, ptr %v2836, i64 64
  store ptr %v2716, ptr %v2842, align 8, !tbaa !3
  %v2843 = getelementptr i8, ptr %v2836, i64 72
  store ptr %v2718, ptr %v2843, align 8, !tbaa !3
  %v2844 = call ptr @mlf_closure(ptr @mlf.code.2740, ptr %v2836)
  %v2845 = call ptr @mlf_prim2(i64 1, ptr %v2739, ptr %v2844)
  ret ptr %v2845
}

define private ptr @mlf.worker.67(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6) {
entry:
  %v2700 = call ptr @mlf_env_new(i64 2)
  %v2701 = getelementptr i8, ptr %v2700, i64 24
  store ptr %a1, ptr %v2701, align 8, !tbaa !3
  %v2702 = getelementptr i8, ptr %v2700, i64 32
  store ptr %a6, ptr %v2702, align 8, !tbaa !3
  %v2703 = call ptr @mlf_thunk(ptr @mlf.code.2694, ptr %v2700)
  %v2846 = call ptr @mlf_env_new(i64 7)
  %v2847 = getelementptr i8, ptr %v2846, i64 24
  store ptr %a0, ptr %v2847, align 8, !tbaa !3
  %v2848 = getelementptr i8, ptr %v2846, i64 32
  store ptr %a1, ptr %v2848, align 8, !tbaa !3
  %v2849 = getelementptr i8, ptr %v2846, i64 40
  store ptr %a2, ptr %v2849, align 8, !tbaa !3
  %v2850 = getelementptr i8, ptr %v2846, i64 48
  store ptr %a3, ptr %v2850, align 8, !tbaa !3
  %v2851 = getelementptr i8, ptr %v2846, i64 56
  store ptr %a4, ptr %v2851, align 8, !tbaa !3
  %v2852 = getelementptr i8, ptr %v2846, i64 64
  store ptr %a5, ptr %v2852, align 8, !tbaa !3
  %v2853 = getelementptr i8, ptr %v2846, i64 72
  store ptr %a6, ptr %v2853, align 8, !tbaa !3
  %v2854 = call ptr @mlf_closure(ptr @mlf.code.2704, ptr %v2846)
  %v2855 = call ptr @mlf_prim2(i64 1, ptr %v2703, ptr %v2854)
  ret ptr %v2855
}

define private ptr @mlf.numeric.entry.2653(ptr %env, ptr %arg) {
entry:
  %v2654 = getelementptr i8, ptr %env, i64 24
  %v2655 = load ptr, ptr %v2654, align 8, !tbaa !3
  %v2656 = getelementptr i8, ptr %env, i64 32
  %v2657 = load ptr, ptr %v2656, align 8, !tbaa !3
  %v2658 = getelementptr i8, ptr %env, i64 40
  %v2659 = load ptr, ptr %v2658, align 8, !tbaa !3
  %v2660 = getelementptr i8, ptr %env, i64 48
  %v2661 = load ptr, ptr %v2660, align 8, !tbaa !3
  %v2662 = getelementptr i8, ptr %env, i64 56
  %v2663 = load ptr, ptr %v2662, align 8, !tbaa !3
  %v2664 = getelementptr i8, ptr %env, i64 64
  %v2665 = load ptr, ptr %v2664, align 8, !tbaa !3
  %v2666 = getelementptr i8, ptr %env, i64 72
  %v2667 = load ptr, ptr %v2666, align 8, !tbaa !3
  %v2668 = call ptr @mlf_peek(ptr %v2655)
  %v2669 = call ptr @mlf_peek(ptr %v2657)
  %v2670 = call ptr @mlf_peek(ptr %v2659)
  %v2671 = call ptr @mlf_peek(ptr %v2661)
  %v2672 = call ptr @mlf_peek(ptr %v2663)
  %v2673 = call ptr @mlf_peek(ptr %v2665)
  %v2674 = call ptr @mlf_peek(ptr %v2667)
  %v2675 = icmp ne ptr %v2668, null
  %v2676 = icmp ne ptr %v2669, null
  %v2677 = icmp ne ptr %v2670, null
  %v2678 = icmp ne ptr %v2671, null
  %v2679 = icmp ne ptr %v2672, null
  %v2680 = icmp ne ptr %v2673, null
  %v2681 = icmp ne ptr %v2674, null
  %v2682 = and i1 true, %v2675
  %v2683 = and i1 %v2682, %v2676
  %v2684 = and i1 %v2683, %v2677
  %v2685 = and i1 %v2684, %v2678
  %v2686 = and i1 %v2685, %v2679
  %v2687 = and i1 %v2686, %v2680
  %v2688 = and i1 %v2687, %v2681
  br i1 %v2688, label %yes.2689, label %no.2690
yes.2689:
  %v2692 = call ptr @mlf.numeric.67(ptr %v2668, ptr %v2669, ptr %v2670, ptr %v2671, ptr %v2672, ptr %v2673, ptr %v2674)
  %v2693 = call ptr @mlf_prim1(i64 0, ptr %v2692)
  br label %join.2691
no.2690:
  %v2856 = call ptr @mlf.worker.67(ptr %v2655, ptr %v2657, ptr %v2659, ptr %v2661, ptr %v2663, ptr %v2665, ptr %v2667)
  br label %join.2691
join.2691:
  %v2857 = phi ptr [ %v2693, %yes.2689 ], [ %v2856, %no.2690 ]
  ret ptr %v2857
}

define private ptr @mlf.code.2858(ptr %env, ptr %arg) {
entry:
  %v2859 = getelementptr i8, ptr %env, i64 24
  %v2860 = load ptr, ptr %v2859, align 8, !tbaa !3
  %v2861 = call ptr @mlf_force(ptr %v2860)
  %v2862 = call ptr @mlf_prim2(i64 9, ptr %v2861, ptr inttoptr (i64 3 to ptr))
  ret ptr %v2862
}

define private ptr @mlf.code.2642(ptr %env, ptr %arg) {
entry:
  %v2643 = getelementptr i8, ptr %env, i64 24
  %v2644 = load ptr, ptr %v2643, align 8, !tbaa !3
  %v2645 = getelementptr i8, ptr %env, i64 32
  %v2646 = load ptr, ptr %v2645, align 8, !tbaa !3
  %v2647 = getelementptr i8, ptr %env, i64 40
  %v2648 = load ptr, ptr %v2647, align 8, !tbaa !3
  %v2649 = getelementptr i8, ptr %env, i64 48
  %v2650 = load ptr, ptr %v2649, align 8, !tbaa !3
  %v2651 = getelementptr i8, ptr %env, i64 56
  %v2652 = load ptr, ptr %v2651, align 8, !tbaa !3
  %v2863 = call ptr @mlf_env_new(i64 1)
  %v2864 = getelementptr i8, ptr %v2863, i64 24
  store ptr %arg, ptr %v2864, align 8, !tbaa !3
  %v2865 = call ptr @mlf_thunk(ptr @mlf.code.2858, ptr %v2863)
  %v2866 = call ptr @mlf_env_new(i64 7)
  %v2867 = getelementptr i8, ptr %v2866, i64 24
  store ptr %v2644, ptr %v2867, align 8, !tbaa !3
  %v2868 = getelementptr i8, ptr %v2866, i64 32
  store ptr %v2650, ptr %v2868, align 8, !tbaa !3
  %v2869 = getelementptr i8, ptr %v2866, i64 40
  store ptr %v2646, ptr %v2869, align 8, !tbaa !3
  %v2870 = getelementptr i8, ptr %v2866, i64 48
  store ptr %v2648, ptr %v2870, align 8, !tbaa !3
  %v2871 = getelementptr i8, ptr %v2866, i64 56
  store ptr %v2865, ptr %v2871, align 8, !tbaa !3
  %v2872 = getelementptr i8, ptr %v2866, i64 64
  store ptr inttoptr (i64 1 to ptr), ptr %v2872, align 8, !tbaa !3
  %v2873 = getelementptr i8, ptr %v2866, i64 72
  store ptr %v2652, ptr %v2873, align 8, !tbaa !3
  %v2874 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2653, ptr %v2866)
  ret ptr %v2874
}

define private ptr @mlf.code.2583(ptr %env, ptr %arg) {
entry:
  %v2584 = getelementptr i8, ptr %env, i64 24
  %v2585 = load ptr, ptr %v2584, align 8, !tbaa !3
  %v2586 = getelementptr i8, ptr %env, i64 32
  %v2587 = load ptr, ptr %v2586, align 8, !tbaa !3
  %v2588 = getelementptr i8, ptr %env, i64 40
  %v2589 = load ptr, ptr %v2588, align 8, !tbaa !3
  %v2590 = getelementptr i8, ptr %env, i64 48
  %v2591 = load ptr, ptr %v2590, align 8, !tbaa !3
  %v2639 = call ptr @mlf_env_new(i64 1)
  %v2640 = getelementptr i8, ptr %v2639, i64 24
  store ptr %v2589, ptr %v2640, align 8, !tbaa !3
  %v2641 = call ptr @mlf_thunk(ptr @mlf.code.2592, ptr %v2639)
  %v2875 = call ptr @mlf_env_new(i64 5)
  %v2876 = getelementptr i8, ptr %v2875, i64 24
  store ptr %v2585, ptr %v2876, align 8, !tbaa !3
  %v2877 = getelementptr i8, ptr %v2875, i64 32
  store ptr %v2587, ptr %v2877, align 8, !tbaa !3
  %v2878 = getelementptr i8, ptr %v2875, i64 40
  store ptr %v2589, ptr %v2878, align 8, !tbaa !3
  %v2879 = getelementptr i8, ptr %v2875, i64 48
  store ptr %v2591, ptr %v2879, align 8, !tbaa !3
  %v2880 = getelementptr i8, ptr %v2875, i64 56
  store ptr %arg, ptr %v2880, align 8, !tbaa !3
  %v2881 = call ptr @mlf_closure(ptr @mlf.code.2642, ptr %v2875)
  %v2882 = call ptr @mlf_prim2(i64 1, ptr %v2641, ptr %v2881)
  ret ptr %v2882
}

define private ptr @mlf.code.2465(ptr %env, ptr %arg) {
entry:
  %v2466 = getelementptr i8, ptr %env, i64 24
  %v2467 = load ptr, ptr %v2466, align 8, !tbaa !3
  %v2468 = getelementptr i8, ptr %env, i64 32
  %v2469 = load ptr, ptr %v2468, align 8, !tbaa !3
  %v2470 = getelementptr i8, ptr %env, i64 40
  %v2471 = load ptr, ptr %v2470, align 8, !tbaa !3
  %v2472 = getelementptr i8, ptr %env, i64 48
  %v2473 = load ptr, ptr %v2472, align 8, !tbaa !3
  %v2474 = call ptr @mlf_force(ptr %v2469)
  %v2475 = call ptr @mlf_force(ptr %v2471)
  %v2476 = call ptr @mlf_prim2(i64 11, ptr %v2474, ptr %v2475)
  %v2477 = icmp eq ptr %v2476, inttoptr (i64 6 to ptr)
  br i1 %v2477, label %yes.2478, label %no.2479
yes.2478:
  %v2481 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.2480
no.2479:
  %v2579 = call ptr @mlf_env_new(i64 2)
  %v2580 = getelementptr i8, ptr %v2579, i64 24
  store ptr %v2467, ptr %v2580, align 8, !tbaa !3
  %v2581 = getelementptr i8, ptr %v2579, i64 32
  store ptr %v2475, ptr %v2581, align 8, !tbaa !3
  %v2582 = call ptr @mlf_thunk(ptr @mlf.code.2482, ptr %v2579)
  %v2883 = call ptr @mlf_env_new(i64 4)
  %v2884 = getelementptr i8, ptr %v2883, i64 24
  store ptr %v2467, ptr %v2884, align 8, !tbaa !3
  %v2885 = getelementptr i8, ptr %v2883, i64 32
  store ptr %v2474, ptr %v2885, align 8, !tbaa !3
  %v2886 = getelementptr i8, ptr %v2883, i64 40
  store ptr %v2475, ptr %v2886, align 8, !tbaa !3
  %v2887 = getelementptr i8, ptr %v2883, i64 48
  store ptr %v2473, ptr %v2887, align 8, !tbaa !3
  %v2888 = call ptr @mlf_closure(ptr @mlf.code.2583, ptr %v2883)
  %v2889 = call ptr @mlf_prim2(i64 1, ptr %v2582, ptr %v2888)
  br label %join.2480
join.2480:
  %v2890 = phi ptr [ %v2481, %yes.2478 ], [ %v2889, %no.2479 ]
  ret ptr %v2890
}

define private ptr @mlf.code.2897(ptr %env, ptr %arg) {
entry:
  %v2898 = getelementptr i8, ptr %env, i64 24
  %v2899 = load ptr, ptr %v2898, align 8, !tbaa !3
  %v2900 = call ptr @mlf_prim1(i64 0, ptr %v2899)
  ret ptr %v2900
}

define private ptr @mlf.code.2458(ptr %env, ptr %arg) {
entry:
  %v2459 = getelementptr i8, ptr %env, i64 24
  %v2460 = load ptr, ptr %v2459, align 8, !tbaa !3
  %v2461 = getelementptr i8, ptr %env, i64 32
  %v2462 = load ptr, ptr %v2461, align 8, !tbaa !3
  %v2463 = getelementptr i8, ptr %env, i64 40
  %v2464 = load ptr, ptr %v2463, align 8, !tbaa !3
  %v2891 = call ptr @mlf_env_new(i64 4)
  %v2892 = getelementptr i8, ptr %v2891, i64 24
  store ptr %v2460, ptr %v2892, align 8, !tbaa !3
  %v2893 = getelementptr i8, ptr %v2891, i64 32
  store ptr %v2462, ptr %v2893, align 8, !tbaa !3
  %v2894 = getelementptr i8, ptr %v2891, i64 40
  store ptr %v2464, ptr %v2894, align 8, !tbaa !3
  %v2895 = getelementptr i8, ptr %v2891, i64 48
  store ptr %arg, ptr %v2895, align 8, !tbaa !3
  %v2896 = call ptr @mlf_thunk(ptr @mlf.code.2465, ptr %v2891)
  %v2901 = call ptr @mlf_env_new(i64 1)
  %v2902 = getelementptr i8, ptr %v2901, i64 24
  store ptr %arg, ptr %v2902, align 8, !tbaa !3
  %v2903 = call ptr @mlf_closure(ptr @mlf.code.2897, ptr %v2901)
  %v2904 = call ptr @mlf_prim2(i64 1, ptr %v2896, ptr %v2903)
  ret ptr %v2904
}

define private ptr @mlf.worker.80(ptr %a0, ptr %a1, ptr %a2) {
entry:
  %v2457 = call ptr @mlf_primitive(i64 42)
  %v2905 = call ptr @mlf_env_new(i64 3)
  %v2906 = getelementptr i8, ptr %v2905, i64 24
  store ptr %a0, ptr %v2906, align 8, !tbaa !3
  %v2907 = getelementptr i8, ptr %v2905, i64 32
  store ptr %a1, ptr %v2907, align 8, !tbaa !3
  %v2908 = getelementptr i8, ptr %v2905, i64 40
  store ptr %a2, ptr %v2908, align 8, !tbaa !3
  %v2909 = call ptr @mlf_closure(ptr @mlf.code.2458, ptr %v2905)
  %v2910 = call ptr @mlf_prim2(i64 1, ptr %v2457, ptr %v2909)
  ret ptr %v2910
}

define private ptr @mlf.numeric.entry.2041(ptr %env, ptr %arg) {
entry:
  %v2042 = getelementptr i8, ptr %env, i64 24
  %v2043 = load ptr, ptr %v2042, align 8, !tbaa !3
  %v2044 = getelementptr i8, ptr %env, i64 32
  %v2045 = load ptr, ptr %v2044, align 8, !tbaa !3
  %v2046 = getelementptr i8, ptr %env, i64 40
  %v2047 = load ptr, ptr %v2046, align 8, !tbaa !3
  %v2048 = call ptr @mlf_peek(ptr %v2043)
  %v2049 = call ptr @mlf_peek(ptr %v2045)
  %v2050 = call ptr @mlf_peek(ptr %v2047)
  %v2051 = icmp ne ptr %v2048, null
  %v2052 = icmp ne ptr %v2049, null
  %v2053 = icmp ne ptr %v2050, null
  %v2054 = and i1 true, %v2051
  %v2055 = and i1 %v2054, %v2052
  %v2056 = and i1 %v2055, %v2053
  br i1 %v2056, label %yes.2057, label %no.2058
yes.2057:
  %v2455 = call ptr @mlf.numeric.80(ptr %v2048, ptr %v2049, ptr %v2050)
  %v2456 = call ptr @mlf_prim1(i64 0, ptr %v2455)
  br label %join.2059
no.2058:
  %v2911 = call ptr @mlf.worker.80(ptr %v2043, ptr %v2045, ptr %v2047)
  br label %join.2059
join.2059:
  %v2912 = phi ptr [ %v2456, %yes.2057 ], [ %v2911, %no.2058 ]
  ret ptr %v2912
}

define private ptr @mlf.code.2036(ptr %env, ptr %arg) {
entry:
  %v2037 = getelementptr i8, ptr %env, i64 24
  %v2038 = load ptr, ptr %v2037, align 8, !tbaa !3
  %v2039 = getelementptr i8, ptr %env, i64 32
  %v2040 = load ptr, ptr %v2039, align 8, !tbaa !3
  %v2913 = call ptr @mlf_env_new(i64 3)
  %v2914 = getelementptr i8, ptr %v2913, i64 24
  store ptr %v2038, ptr %v2914, align 8, !tbaa !3
  %v2915 = getelementptr i8, ptr %v2913, i64 32
  store ptr %v2040, ptr %v2915, align 8, !tbaa !3
  %v2916 = getelementptr i8, ptr %v2913, i64 40
  store ptr inttoptr (i64 3 to ptr), ptr %v2916, align 8, !tbaa !3
  %v2917 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2041, ptr %v2913)
  ret ptr %v2917
}

define private ptr @mlf.numeric.90(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) alwaysinline {
entry:
  %v2985 = ptrtoint ptr %a2 to i64
  %v2986 = ptrtoint ptr %a1 to i64
  %v2987 = and i64 %v2985, %v2986
  %v2988 = and i64 %v2987, 1
  %v2989 = icmp ne i64 %v2988, 0
  br i1 %v2989, label %yes.2990, label %no.2991
yes.2990:
  %v2993 = icmp slt i64 %v2985, %v2986
  %v2994 = select i1 %v2993, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.2992
no.2991:
  %v2995 = call ptr @mlf_lt_int(ptr %a2, ptr %a1)
  br label %join.2992
join.2992:
  %v2996 = phi ptr [ %v2994, %yes.2990 ], [ %v2995, %no.2991 ]
  %v2997 = icmp eq ptr %v2996, inttoptr (i64 6 to ptr)
  br i1 %v2997, label %tail.yes.2998, label %tail.no.2999
tail.yes.2998:
  %v3000 = call ptr @mlf_read_int_table(ptr %a0, ptr %a2)
  %v3001 = ptrtoint ptr %a4 to i64
  %v3002 = ptrtoint ptr %v3000 to i64
  %v3003 = and i64 %v3001, %v3002
  %v3004 = and i64 %v3003, 1
  %v3005 = icmp ne i64 %v3004, 0
  br i1 %v3005, label %yes.3006, label %no.3007
yes.3006:
  %v3009 = icmp slt i64 %v3001, %v3002
  %v3010 = select i1 %v3009, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.3008
no.3007:
  %v3011 = call ptr @mlf_lt_int(ptr %a4, ptr %v3000)
  br label %join.3008
join.3008:
  %v3012 = phi ptr [ %v3010, %yes.3006 ], [ %v3011, %no.3007 ]
  %v3013 = icmp eq ptr %v3012, inttoptr (i64 6 to ptr)
  br i1 %v3013, label %tail.yes.3014, label %tail.no.3015
tail.yes.3014:
  %v3016 = ptrtoint ptr %a2 to i64
  %v3017 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v3018 = and i64 %v3016, %v3017
  %v3019 = and i64 %v3018, 1
  %v3020 = icmp ne i64 %v3019, 0
  br i1 %v3020, label %yes.3021, label %no.3022
yes.3021:
  %v3024 = sub i64 %v3017, 1
  %v3025 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v3016, i64 %v3024)
  %v3026 = extractvalue { i64, i1 } %v3025, 0
  %v3027 = extractvalue { i64, i1 } %v3025, 1
  br i1 %v3027, label %yes.3028, label %no.3029
yes.3028:
  %v3031 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 3 to ptr))
  br label %join.3030
no.3029:
  %v3032 = inttoptr i64 %v3026 to ptr
  br label %join.3030
join.3030:
  %v3033 = phi ptr [ %v3031, %yes.3028 ], [ %v3032, %no.3029 ]
  br label %join.3023
no.3022:
  %v3034 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 3 to ptr))
  br label %join.3023
join.3023:
  %v3035 = phi ptr [ %v3033, %join.3030 ], [ %v3034, %no.3022 ]
  %v3036 = musttail call ptr @mlf.numeric.90(ptr %a0, ptr %a1, ptr %v3035, ptr %a2, ptr %v3000)
  ret ptr %v3036
tail.no.3015:
  %v3037 = ptrtoint ptr %a2 to i64
  %v3038 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v3039 = and i64 %v3037, %v3038
  %v3040 = and i64 %v3039, 1
  %v3041 = icmp ne i64 %v3040, 0
  br i1 %v3041, label %yes.3042, label %no.3043
yes.3042:
  %v3045 = sub i64 %v3038, 1
  %v3046 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v3037, i64 %v3045)
  %v3047 = extractvalue { i64, i1 } %v3046, 0
  %v3048 = extractvalue { i64, i1 } %v3046, 1
  br i1 %v3048, label %yes.3049, label %no.3050
yes.3049:
  %v3052 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 3 to ptr))
  br label %join.3051
no.3050:
  %v3053 = inttoptr i64 %v3047 to ptr
  br label %join.3051
join.3051:
  %v3054 = phi ptr [ %v3052, %yes.3049 ], [ %v3053, %no.3050 ]
  br label %join.3044
no.3043:
  %v3055 = call ptr @mlf_add_int(ptr %a2, ptr inttoptr (i64 3 to ptr))
  br label %join.3044
join.3044:
  %v3056 = phi ptr [ %v3054, %join.3051 ], [ %v3055, %no.3043 ]
  %v3057 = musttail call ptr @mlf.numeric.90(ptr %a0, ptr %a1, ptr %v3056, ptr %a3, ptr %a4)
  ret ptr %v3057
tail.no.2999:
  ret ptr %a3
}

define private ptr @mlf.code.3065(ptr %env, ptr %arg) {
entry:
  %v3066 = getelementptr i8, ptr %env, i64 24
  %v3067 = load ptr, ptr %v3066, align 8, !tbaa !3
  %v3068 = getelementptr i8, ptr %env, i64 32
  %v3069 = load ptr, ptr %v3068, align 8, !tbaa !3
  %v3070 = call ptr @mlf_prim2(i64 43, ptr %v3067, ptr %v3069)
  ret ptr %v3070
}

define private ptr @mlf.code.3075(ptr %env, ptr %arg) {
entry:
  %v3076 = getelementptr i8, ptr %env, i64 24
  %v3077 = load ptr, ptr %v3076, align 8, !tbaa !3
  %v3078 = getelementptr i8, ptr %env, i64 32
  %v3079 = load ptr, ptr %v3078, align 8, !tbaa !3
  %v3080 = getelementptr i8, ptr %env, i64 40
  %v3081 = load ptr, ptr %v3080, align 8, !tbaa !3
  %v3082 = getelementptr i8, ptr %env, i64 48
  %v3083 = load ptr, ptr %v3082, align 8, !tbaa !3
  %v3084 = getelementptr i8, ptr %env, i64 56
  %v3085 = load ptr, ptr %v3084, align 8, !tbaa !3
  %v3086 = call ptr @mlf_force(ptr %v3085)
  %v3087 = call ptr @mlf_force(ptr %arg)
  %v3088 = call ptr @mlf_prim2(i64 11, ptr %v3086, ptr %v3087)
  %v3089 = icmp eq ptr %v3088, inttoptr (i64 6 to ptr)
  br i1 %v3089, label %yes.3090, label %no.3091
yes.3090:
  %v3093 = call ptr @mlf_force(ptr %v3079)
  %v3094 = call ptr @mlf_force(ptr %v3081)
  %v3095 = call ptr @mlf_prim2(i64 8, ptr %v3094, ptr inttoptr (i64 3 to ptr))
  %v3096 = call ptr @mlf_env_new(i64 5)
  %v3097 = getelementptr i8, ptr %v3096, i64 24
  store ptr %v3077, ptr %v3097, align 8, !tbaa !3
  %v3098 = getelementptr i8, ptr %v3096, i64 32
  store ptr %v3093, ptr %v3098, align 8, !tbaa !3
  %v3099 = getelementptr i8, ptr %v3096, i64 40
  store ptr %v3095, ptr %v3099, align 8, !tbaa !3
  %v3100 = getelementptr i8, ptr %v3096, i64 48
  store ptr %v3094, ptr %v3100, align 8, !tbaa !3
  %v3101 = getelementptr i8, ptr %v3096, i64 56
  store ptr %v3087, ptr %v3101, align 8, !tbaa !3
  %v3102 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2956, ptr %v3096)
  br label %join.3092
no.3091:
  %v3103 = call ptr @mlf_force(ptr %v3079)
  %v3104 = call ptr @mlf_force(ptr %v3081)
  %v3105 = call ptr @mlf_prim2(i64 8, ptr %v3104, ptr inttoptr (i64 3 to ptr))
  %v3106 = call ptr @mlf_env_new(i64 5)
  %v3107 = getelementptr i8, ptr %v3106, i64 24
  store ptr %v3077, ptr %v3107, align 8, !tbaa !3
  %v3108 = getelementptr i8, ptr %v3106, i64 32
  store ptr %v3103, ptr %v3108, align 8, !tbaa !3
  %v3109 = getelementptr i8, ptr %v3106, i64 40
  store ptr %v3105, ptr %v3109, align 8, !tbaa !3
  %v3110 = getelementptr i8, ptr %v3106, i64 48
  store ptr %v3083, ptr %v3110, align 8, !tbaa !3
  %v3111 = getelementptr i8, ptr %v3106, i64 56
  store ptr %v3086, ptr %v3111, align 8, !tbaa !3
  %v3112 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2956, ptr %v3106)
  br label %join.3092
join.3092:
  %v3113 = phi ptr [ %v3102, %yes.3090 ], [ %v3112, %no.3091 ]
  ret ptr %v3113
}

define private ptr @mlf.worker.90(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) {
entry:
  %v3060 = call ptr @mlf_prim2(i64 11, ptr %a2, ptr %a1)
  %v3061 = icmp eq ptr %v3060, inttoptr (i64 6 to ptr)
  br i1 %v3061, label %yes.3062, label %no.3063
yes.3062:
  %v3071 = call ptr @mlf_env_new(i64 2)
  %v3072 = getelementptr i8, ptr %v3071, i64 24
  store ptr %a0, ptr %v3072, align 8, !tbaa !3
  %v3073 = getelementptr i8, ptr %v3071, i64 32
  store ptr %a2, ptr %v3073, align 8, !tbaa !3
  %v3074 = call ptr @mlf_thunk(ptr @mlf.code.3065, ptr %v3071)
  %v3114 = call ptr @mlf_env_new(i64 5)
  %v3115 = getelementptr i8, ptr %v3114, i64 24
  store ptr %a0, ptr %v3115, align 8, !tbaa !3
  %v3116 = getelementptr i8, ptr %v3114, i64 32
  store ptr %a1, ptr %v3116, align 8, !tbaa !3
  %v3117 = getelementptr i8, ptr %v3114, i64 40
  store ptr %a2, ptr %v3117, align 8, !tbaa !3
  %v3118 = getelementptr i8, ptr %v3114, i64 48
  store ptr %a3, ptr %v3118, align 8, !tbaa !3
  %v3119 = getelementptr i8, ptr %v3114, i64 56
  store ptr %a4, ptr %v3119, align 8, !tbaa !3
  %v3120 = call ptr @mlf_closure(ptr @mlf.code.3075, ptr %v3114)
  %v3121 = call ptr @mlf_prim2(i64 1, ptr %v3074, ptr %v3120)
  br label %join.3064
no.3063:
  %v3122 = call ptr @mlf_prim1(i64 0, ptr %a3)
  br label %join.3064
join.3064:
  %v3123 = phi ptr [ %v3121, %yes.3062 ], [ %v3122, %no.3063 ]
  ret ptr %v3123
}

define private ptr @mlf.numeric.entry.2956(ptr %env, ptr %arg) {
entry:
  %v2957 = getelementptr i8, ptr %env, i64 24
  %v2958 = load ptr, ptr %v2957, align 8, !tbaa !3
  %v2959 = getelementptr i8, ptr %env, i64 32
  %v2960 = load ptr, ptr %v2959, align 8, !tbaa !3
  %v2961 = getelementptr i8, ptr %env, i64 40
  %v2962 = load ptr, ptr %v2961, align 8, !tbaa !3
  %v2963 = getelementptr i8, ptr %env, i64 48
  %v2964 = load ptr, ptr %v2963, align 8, !tbaa !3
  %v2965 = getelementptr i8, ptr %env, i64 56
  %v2966 = load ptr, ptr %v2965, align 8, !tbaa !3
  %v2967 = call ptr @mlf_peek(ptr %v2958)
  %v2968 = call ptr @mlf_peek(ptr %v2960)
  %v2969 = call ptr @mlf_peek(ptr %v2962)
  %v2970 = call ptr @mlf_peek(ptr %v2964)
  %v2971 = call ptr @mlf_peek(ptr %v2966)
  %v2972 = icmp ne ptr %v2967, null
  %v2973 = icmp ne ptr %v2968, null
  %v2974 = icmp ne ptr %v2969, null
  %v2975 = icmp ne ptr %v2970, null
  %v2976 = icmp ne ptr %v2971, null
  %v2977 = and i1 true, %v2972
  %v2978 = and i1 %v2977, %v2973
  %v2979 = and i1 %v2978, %v2974
  %v2980 = and i1 %v2979, %v2975
  %v2981 = and i1 %v2980, %v2976
  br i1 %v2981, label %yes.2982, label %no.2983
yes.2982:
  %v3058 = call ptr @mlf.numeric.90(ptr %v2967, ptr %v2968, ptr %v2969, ptr %v2970, ptr %v2971)
  %v3059 = call ptr @mlf_prim1(i64 0, ptr %v3058)
  br label %join.2984
no.2983:
  %v3124 = call ptr @mlf_force(ptr %v2960)
  %v3125 = call ptr @mlf_force(ptr %v2962)
  %v3126 = call ptr @mlf.worker.90(ptr %v2958, ptr %v3124, ptr %v3125, ptr %v2964, ptr %v2966)
  br label %join.2984
join.2984:
  %v3127 = phi ptr [ %v3059, %yes.2982 ], [ %v3126, %no.2983 ]
  ret ptr %v3127
}

define private ptr @mlf.code.2951(ptr %env, ptr %arg) {
entry:
  %v2952 = getelementptr i8, ptr %env, i64 24
  %v2953 = load ptr, ptr %v2952, align 8, !tbaa !3
  %v2954 = getelementptr i8, ptr %env, i64 32
  %v2955 = load ptr, ptr %v2954, align 8, !tbaa !3
  %v3128 = call ptr @mlf_force(ptr %v2955)
  %v3129 = call ptr @mlf_env_new(i64 5)
  %v3130 = getelementptr i8, ptr %v3129, i64 24
  store ptr %v2953, ptr %v3130, align 8, !tbaa !3
  %v3131 = getelementptr i8, ptr %v3129, i64 32
  store ptr %v3128, ptr %v3131, align 8, !tbaa !3
  %v3132 = getelementptr i8, ptr %v3129, i64 40
  store ptr inttoptr (i64 1 to ptr), ptr %v3132, align 8, !tbaa !3
  %v3133 = getelementptr i8, ptr %v3129, i64 48
  store ptr inttoptr (i64 1 to ptr), ptr %v3133, align 8, !tbaa !3
  %v3134 = getelementptr i8, ptr %v3129, i64 56
  store ptr inttoptr (i64 1 to ptr), ptr %v3134, align 8, !tbaa !3
  %v3135 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2956, ptr %v3129)
  ret ptr %v3135
}

define private ptr @mlf.code.3151(ptr %env, ptr %arg) {
entry:
  %v3152 = getelementptr i8, ptr %env, i64 24
  %v3153 = load ptr, ptr %v3152, align 8, !tbaa !3
  %v3154 = getelementptr i8, ptr %env, i64 32
  %v3155 = load ptr, ptr %v3154, align 8, !tbaa !3
  %v3156 = call ptr @mlf_prim2(i64 43, ptr %v3153, ptr %v3155)
  ret ptr %v3156
}

define private ptr @mlf.code.3194(ptr %env, ptr %arg) {
entry:
  %v3195 = getelementptr i8, ptr %env, i64 24
  %v3196 = load ptr, ptr %v3195, align 8, !tbaa !3
  %v3197 = getelementptr i8, ptr %env, i64 32
  %v3198 = load ptr, ptr %v3197, align 8, !tbaa !3
  %v3199 = getelementptr i8, ptr %env, i64 40
  %v3200 = load ptr, ptr %v3199, align 8, !tbaa !3
  %v3201 = call ptr @mlf_double(double 0x4059000000000000)
  %v3202 = call ptr @mlf_force(ptr %v3200)
  %v3203 = call ptr @mlf_prim1(i64 25, ptr %v3202)
  %v3204 = getelementptr i8, ptr %v3201, i64 24
  %v3205 = load double, ptr %v3204, align 8, !tbaa !3
  %v3206 = getelementptr i8, ptr %v3203, i64 24
  %v3207 = load double, ptr %v3206, align 8, !tbaa !3
  %v3208 = fmul double %v3205, %v3207
  %v3209 = call ptr @mlf_double(double %v3208)
  %v3210 = call ptr @mlf_force(ptr %v3196)
  %v3211 = call ptr @mlf_force(ptr %v3198)
  %v3212 = ptrtoint ptr %v3210 to i64
  %v3213 = ptrtoint ptr %v3211 to i64
  %v3214 = and i64 %v3212, %v3213
  %v3215 = and i64 %v3214, 1
  %v3216 = icmp ne i64 %v3215, 0
  br i1 %v3216, label %yes.3217, label %no.3218
yes.3217:
  %v3220 = sub i64 %v3213, 1
  %v3221 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v3212, i64 %v3220)
  %v3222 = extractvalue { i64, i1 } %v3221, 0
  %v3223 = extractvalue { i64, i1 } %v3221, 1
  br i1 %v3223, label %yes.3224, label %no.3225
yes.3224:
  %v3227 = call ptr @mlf_sub_int(ptr %v3210, ptr %v3211)
  br label %join.3226
no.3225:
  %v3228 = inttoptr i64 %v3222 to ptr
  br label %join.3226
join.3226:
  %v3229 = phi ptr [ %v3227, %yes.3224 ], [ %v3228, %no.3225 ]
  br label %join.3219
no.3218:
  %v3230 = call ptr @mlf_sub_int(ptr %v3210, ptr %v3211)
  br label %join.3219
join.3219:
  %v3231 = phi ptr [ %v3229, %join.3226 ], [ %v3230, %no.3218 ]
  %v3232 = ptrtoint ptr %v3231 to i64
  %v3233 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v3234 = and i64 %v3232, %v3233
  %v3235 = and i64 %v3234, 1
  %v3236 = icmp ne i64 %v3235, 0
  br i1 %v3236, label %yes.3237, label %no.3238
yes.3237:
  %v3240 = sub i64 %v3233, 1
  %v3241 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v3232, i64 %v3240)
  %v3242 = extractvalue { i64, i1 } %v3241, 0
  %v3243 = extractvalue { i64, i1 } %v3241, 1
  br i1 %v3243, label %yes.3244, label %no.3245
yes.3244:
  %v3247 = call ptr @mlf_add_int(ptr %v3231, ptr inttoptr (i64 3 to ptr))
  br label %join.3246
no.3245:
  %v3248 = inttoptr i64 %v3242 to ptr
  br label %join.3246
join.3246:
  %v3249 = phi ptr [ %v3247, %yes.3244 ], [ %v3248, %no.3245 ]
  br label %join.3239
no.3238:
  %v3250 = call ptr @mlf_add_int(ptr %v3231, ptr inttoptr (i64 3 to ptr))
  br label %join.3239
join.3239:
  %v3251 = phi ptr [ %v3249, %join.3246 ], [ %v3250, %no.3238 ]
  %v3252 = call ptr @mlf_prim1(i64 25, ptr %v3251)
  %v3253 = getelementptr i8, ptr %v3209, i64 24
  %v3254 = load double, ptr %v3253, align 8, !tbaa !3
  %v3255 = getelementptr i8, ptr %v3252, i64 24
  %v3256 = load double, ptr %v3255, align 8, !tbaa !3
  %v3257 = fdiv double %v3254, %v3256
  %v3258 = call ptr @mlf_double(double %v3257)
  ret ptr %v3258
}

define private ptr @mlf.worker.88(ptr %a0) {
entry:
  %v3295 = ptrtoint ptr %a0 to i64
  %v3296 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v3297 = and i64 %v3295, %v3296
  %v3298 = and i64 %v3297, 1
  %v3299 = icmp ne i64 %v3298, 0
  br i1 %v3299, label %yes.3300, label %no.3301
yes.3300:
  %v3303 = icmp eq i64 %v3295, %v3296
  %v3304 = select i1 %v3303, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.3302
no.3301:
  %v3305 = call ptr @mlf_eq_int(ptr %a0, ptr inttoptr (i64 1 to ptr))
  br label %join.3302
join.3302:
  %v3306 = phi ptr [ %v3304, %yes.3300 ], [ %v3305, %no.3301 ]
  %v3307 = icmp eq ptr %v3306, inttoptr (i64 6 to ptr)
  br i1 %v3307, label %yes.3308, label %no.3309
yes.3308:
  %v3312 = call ptr @mlf_string(ptr @mlf.bytes.3311, i64 1)
  br label %join.3310
no.3309:
  %v3313 = ptrtoint ptr %a0 to i64
  %v3314 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v3315 = and i64 %v3313, %v3314
  %v3316 = and i64 %v3315, 1
  %v3317 = icmp ne i64 %v3316, 0
  br i1 %v3317, label %yes.3318, label %no.3319
yes.3318:
  %v3321 = icmp eq i64 %v3313, %v3314
  %v3322 = select i1 %v3321, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.3320
no.3319:
  %v3323 = call ptr @mlf_eq_int(ptr %a0, ptr inttoptr (i64 3 to ptr))
  br label %join.3320
join.3320:
  %v3324 = phi ptr [ %v3322, %yes.3318 ], [ %v3323, %no.3319 ]
  %v3325 = icmp eq ptr %v3324, inttoptr (i64 6 to ptr)
  br i1 %v3325, label %yes.3326, label %no.3327
yes.3326:
  %v3330 = call ptr @mlf_string(ptr @mlf.bytes.3329, i64 1)
  br label %join.3328
no.3327:
  %v3331 = ptrtoint ptr %a0 to i64
  %v3332 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v3333 = and i64 %v3331, %v3332
  %v3334 = and i64 %v3333, 1
  %v3335 = icmp ne i64 %v3334, 0
  br i1 %v3335, label %yes.3336, label %no.3337
yes.3336:
  %v3339 = icmp eq i64 %v3331, %v3332
  %v3340 = select i1 %v3339, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.3338
no.3337:
  %v3341 = call ptr @mlf_eq_int(ptr %a0, ptr inttoptr (i64 5 to ptr))
  br label %join.3338
join.3338:
  %v3342 = phi ptr [ %v3340, %yes.3336 ], [ %v3341, %no.3337 ]
  %v3343 = icmp eq ptr %v3342, inttoptr (i64 6 to ptr)
  br i1 %v3343, label %yes.3344, label %no.3345
yes.3344:
  %v3348 = call ptr @mlf_string(ptr @mlf.bytes.3347, i64 1)
  br label %join.3346
no.3345:
  %v3350 = call ptr @mlf_string(ptr @mlf.bytes.3349, i64 1)
  br label %join.3346
join.3346:
  %v3351 = phi ptr [ %v3348, %yes.3344 ], [ %v3350, %no.3345 ]
  br label %join.3328
join.3328:
  %v3352 = phi ptr [ %v3330, %yes.3326 ], [ %v3351, %join.3346 ]
  br label %join.3310
join.3310:
  %v3353 = phi ptr [ %v3312, %yes.3308 ], [ %v3352, %join.3328 ]
  ret ptr %v3353
}

define private ptr @mlf.code.3271(ptr %env, ptr %arg) {
entry:
  %v3272 = getelementptr i8, ptr %env, i64 24
  %v3273 = load ptr, ptr %v3272, align 8, !tbaa !3
  %v3274 = getelementptr i8, ptr %env, i64 32
  %v3275 = load ptr, ptr %v3274, align 8, !tbaa !3
  %v3276 = getelementptr i8, ptr %env, i64 40
  %v3277 = load ptr, ptr %v3276, align 8, !tbaa !3
  %v3278 = call ptr @mlf_force(ptr %v3273)
  %v3279 = ptrtoint ptr %v3278 to i64
  %v3280 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v3281 = and i64 %v3279, %v3280
  %v3282 = and i64 %v3281, 1
  %v3283 = icmp ne i64 %v3282, 0
  br i1 %v3283, label %yes.3284, label %no.3285
yes.3284:
  %v3287 = icmp eq i64 %v3279, %v3280
  %v3288 = select i1 %v3287, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.3286
no.3285:
  %v3289 = call ptr @mlf_eq_int(ptr %v3278, ptr inttoptr (i64 3 to ptr))
  br label %join.3286
join.3286:
  %v3290 = phi ptr [ %v3288, %yes.3284 ], [ %v3289, %no.3285 ]
  %v3291 = icmp eq ptr %v3290, inttoptr (i64 6 to ptr)
  br i1 %v3291, label %yes.3292, label %no.3293
yes.3292:
  %v3354 = call ptr @mlf_force(ptr %v3275)
  %v3355 = call ptr @mlf.worker.88(ptr %v3354)
  br label %join.3294
no.3293:
  %v3356 = call ptr @mlf_force(ptr %v3275)
  %v3357 = ptrtoint ptr %v3356 to i64
  %v3358 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v3359 = and i64 %v3357, %v3358
  %v3360 = and i64 %v3359, 1
  %v3361 = icmp ne i64 %v3360, 0
  br i1 %v3361, label %yes.3362, label %no.3363
yes.3362:
  %v3365 = ashr i64 %v3357, 1
  %v3366 = ashr i64 %v3358, 1
  %v3367 = icmp ne i64 %v3366, 0
  %v3368 = icmp eq i64 %v3365, -4611686018427387904
  %v3369 = icmp eq i64 %v3366, -1
  %v3370 = and i1 %v3368, %v3369
  %v3371 = xor i1 %v3370, true
  %v3372 = and i1 %v3367, %v3371
  br i1 %v3372, label %yes.3373, label %no.3374
yes.3373:
  %v3376 = sdiv i64 %v3365, %v3366
  %v3377 = shl i64 %v3376, 1
  %v3378 = or i64 %v3377, 1
  %v3379 = inttoptr i64 %v3378 to ptr
  br label %join.3375
no.3374:
  %v3380 = call ptr @mlf_prim2(i64 15, ptr %v3356, ptr inttoptr (i64 9 to ptr))
  br label %join.3375
join.3375:
  %v3381 = phi ptr [ %v3379, %yes.3373 ], [ %v3380, %no.3374 ]
  br label %join.3364
no.3363:
  %v3382 = call ptr @mlf_prim2(i64 15, ptr %v3356, ptr inttoptr (i64 9 to ptr))
  br label %join.3364
join.3364:
  %v3383 = phi ptr [ %v3381, %join.3375 ], [ %v3382, %no.3363 ]
  %v3384 = call ptr @mlf.worker.88(ptr %v3383)
  %v3385 = ptrtoint ptr %v3356 to i64
  %v3386 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v3387 = and i64 %v3385, %v3386
  %v3388 = and i64 %v3387, 1
  %v3389 = icmp ne i64 %v3388, 0
  br i1 %v3389, label %yes.3390, label %no.3391
yes.3390:
  %v3393 = ashr i64 %v3385, 1
  %v3394 = ashr i64 %v3386, 1
  %v3395 = icmp ne i64 %v3394, 0
  %v3396 = icmp eq i64 %v3393, -4611686018427387904
  %v3397 = icmp eq i64 %v3394, -1
  %v3398 = and i1 %v3396, %v3397
  %v3399 = xor i1 %v3398, true
  %v3400 = and i1 %v3395, %v3399
  br i1 %v3400, label %yes.3401, label %no.3402
yes.3401:
  %v3404 = srem i64 %v3393, %v3394
  %v3405 = shl i64 %v3404, 1
  %v3406 = or i64 %v3405, 1
  %v3407 = inttoptr i64 %v3406 to ptr
  br label %join.3403
no.3402:
  %v3408 = call ptr @mlf_prim2(i64 16, ptr %v3356, ptr inttoptr (i64 9 to ptr))
  br label %join.3403
join.3403:
  %v3409 = phi ptr [ %v3407, %yes.3401 ], [ %v3408, %no.3402 ]
  br label %join.3392
no.3391:
  %v3410 = call ptr @mlf_prim2(i64 16, ptr %v3356, ptr inttoptr (i64 9 to ptr))
  br label %join.3392
join.3392:
  %v3411 = phi ptr [ %v3409, %join.3403 ], [ %v3410, %no.3391 ]
  %v3412 = call ptr @mlf.worker.88(ptr %v3411)
  %v3413 = call ptr @mlf_prim2(i64 6, ptr %v3384, ptr %v3412)
  br label %join.3294
join.3294:
  %v3414 = phi ptr [ %v3355, %yes.3292 ], [ %v3413, %join.3392 ]
  %v3416 = call ptr @mlf_string(ptr @mlf.bytes.3415, i64 1)
  %v3417 = call ptr @mlf_force(ptr %v3277)
  %v3418 = call ptr @mlf_prim2(i64 26, ptr inttoptr (i64 7 to ptr), ptr %v3417)
  %v3419 = call ptr @mlf_prim2(i64 6, ptr %v3416, ptr %v3418)
  %v3420 = call ptr @mlf_prim2(i64 6, ptr %v3414, ptr %v3419)
  ret ptr %v3420
}

define private ptr @mlf.code.3264(ptr %env, ptr %arg) {
entry:
  %v3265 = getelementptr i8, ptr %env, i64 24
  %v3266 = load ptr, ptr %v3265, align 8, !tbaa !3
  %v3267 = getelementptr i8, ptr %env, i64 32
  %v3268 = load ptr, ptr %v3267, align 8, !tbaa !3
  %v3269 = getelementptr i8, ptr %env, i64 40
  %v3270 = load ptr, ptr %v3269, align 8, !tbaa !3
  %v3421 = call ptr @mlf_env_new(i64 3)
  %v3422 = getelementptr i8, ptr %v3421, i64 24
  store ptr %v3266, ptr %v3422, align 8, !tbaa !3
  %v3423 = getelementptr i8, ptr %v3421, i64 32
  store ptr %v3268, ptr %v3423, align 8, !tbaa !3
  %v3424 = getelementptr i8, ptr %v3421, i64 40
  store ptr %v3270, ptr %v3424, align 8, !tbaa !3
  %v3425 = call ptr @mlf_thunk(ptr @mlf.code.3271, ptr %v3421)
  %v3426 = call ptr @mlf_prim1(i64 3, ptr %v3425)
  ret ptr %v3426
}

define private ptr @mlf.code.3445(ptr %env, ptr %arg) {
entry:
  %v3446 = getelementptr i8, ptr %env, i64 24
  %v3447 = load ptr, ptr %v3446, align 8, !tbaa !3
  %v3448 = getelementptr i8, ptr %env, i64 32
  %v3449 = load ptr, ptr %v3448, align 8, !tbaa !3
  %v3450 = call ptr @mlf_prim3(i64 44, ptr %v3447, ptr %v3449, ptr inttoptr (i64 1 to ptr))
  ret ptr %v3450
}

define private ptr @mlf.code.3455(ptr %env, ptr %arg) {
entry:
  %v3456 = getelementptr i8, ptr %env, i64 24
  %v3457 = load ptr, ptr %v3456, align 8, !tbaa !3
  %v3458 = getelementptr i8, ptr %env, i64 32
  %v3459 = load ptr, ptr %v3458, align 8, !tbaa !3
  %v3460 = getelementptr i8, ptr %env, i64 40
  %v3461 = load ptr, ptr %v3460, align 8, !tbaa !3
  %v3462 = getelementptr i8, ptr %env, i64 48
  %v3463 = load ptr, ptr %v3462, align 8, !tbaa !3
  %v3464 = getelementptr i8, ptr %env, i64 56
  %v3465 = load ptr, ptr %v3464, align 8, !tbaa !3
  %v3466 = call ptr @mlf_force(ptr %v3465)
  %v3467 = ptrtoint ptr %v3466 to i64
  %v3468 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v3469 = and i64 %v3467, %v3468
  %v3470 = and i64 %v3469, 1
  %v3471 = icmp ne i64 %v3470, 0
  br i1 %v3471, label %yes.3472, label %no.3473
yes.3472:
  %v3475 = sub i64 %v3468, 1
  %v3476 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v3467, i64 %v3475)
  %v3477 = extractvalue { i64, i1 } %v3476, 0
  %v3478 = extractvalue { i64, i1 } %v3476, 1
  br i1 %v3478, label %yes.3479, label %no.3480
yes.3479:
  %v3482 = call ptr @mlf_sub_int(ptr %v3466, ptr inttoptr (i64 3 to ptr))
  br label %join.3481
no.3480:
  %v3483 = inttoptr i64 %v3477 to ptr
  br label %join.3481
join.3481:
  %v3484 = phi ptr [ %v3482, %yes.3479 ], [ %v3483, %no.3480 ]
  br label %join.3474
no.3473:
  %v3485 = call ptr @mlf_sub_int(ptr %v3466, ptr inttoptr (i64 3 to ptr))
  br label %join.3474
join.3474:
  %v3486 = phi ptr [ %v3484, %join.3481 ], [ %v3485, %no.3473 ]
  %v3487 = call ptr @mlf.worker.97(ptr %v3457, ptr %v3459, ptr %v3461, ptr %v3463, ptr %v3486)
  ret ptr %v3487
}

define private ptr @mlf.code.3432(ptr %env, ptr %arg) {
entry:
  %v3433 = getelementptr i8, ptr %env, i64 24
  %v3434 = load ptr, ptr %v3433, align 8, !tbaa !3
  %v3435 = getelementptr i8, ptr %env, i64 32
  %v3436 = load ptr, ptr %v3435, align 8, !tbaa !3
  %v3437 = getelementptr i8, ptr %env, i64 40
  %v3438 = load ptr, ptr %v3437, align 8, !tbaa !3
  %v3439 = getelementptr i8, ptr %env, i64 48
  %v3440 = load ptr, ptr %v3439, align 8, !tbaa !3
  %v3441 = getelementptr i8, ptr %env, i64 56
  %v3442 = load ptr, ptr %v3441, align 8, !tbaa !3
  %v3443 = getelementptr i8, ptr %env, i64 64
  %v3444 = load ptr, ptr %v3443, align 8, !tbaa !3
  %v3451 = call ptr @mlf_env_new(i64 2)
  %v3452 = getelementptr i8, ptr %v3451, i64 24
  store ptr %v3434, ptr %v3452, align 8, !tbaa !3
  %v3453 = getelementptr i8, ptr %v3451, i64 32
  store ptr %v3444, ptr %v3453, align 8, !tbaa !3
  %v3454 = call ptr @mlf_thunk(ptr @mlf.code.3445, ptr %v3451)
  %v3488 = call ptr @mlf_env_new(i64 5)
  %v3489 = getelementptr i8, ptr %v3488, i64 24
  store ptr %v3434, ptr %v3489, align 8, !tbaa !3
  %v3490 = getelementptr i8, ptr %v3488, i64 32
  store ptr %v3436, ptr %v3490, align 8, !tbaa !3
  %v3491 = getelementptr i8, ptr %v3488, i64 40
  store ptr %v3438, ptr %v3491, align 8, !tbaa !3
  %v3492 = getelementptr i8, ptr %v3488, i64 48
  store ptr %v3440, ptr %v3492, align 8, !tbaa !3
  %v3493 = getelementptr i8, ptr %v3488, i64 56
  store ptr %v3442, ptr %v3493, align 8, !tbaa !3
  %v3494 = call ptr @mlf_closure(ptr @mlf.code.3455, ptr %v3488)
  %v3495 = call ptr @mlf_prim2(i64 1, ptr %v3454, ptr %v3494)
  ret ptr %v3495
}

define private ptr @mlf.code.3161(ptr %env, ptr %arg) {
entry:
  %v3162 = getelementptr i8, ptr %env, i64 24
  %v3163 = load ptr, ptr %v3162, align 8, !tbaa !3
  %v3164 = getelementptr i8, ptr %env, i64 32
  %v3165 = load ptr, ptr %v3164, align 8, !tbaa !3
  %v3166 = getelementptr i8, ptr %env, i64 40
  %v3167 = load ptr, ptr %v3166, align 8, !tbaa !3
  %v3168 = getelementptr i8, ptr %env, i64 48
  %v3169 = load ptr, ptr %v3168, align 8, !tbaa !3
  %v3170 = getelementptr i8, ptr %env, i64 56
  %v3171 = load ptr, ptr %v3170, align 8, !tbaa !3
  %v3172 = getelementptr i8, ptr %env, i64 64
  %v3173 = load ptr, ptr %v3172, align 8, !tbaa !3
  %v3174 = call ptr @mlf_force(ptr %arg)
  %v3175 = ptrtoint ptr %v3174 to i64
  %v3176 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v3177 = and i64 %v3175, %v3176
  %v3178 = and i64 %v3177, 1
  %v3179 = icmp ne i64 %v3178, 0
  br i1 %v3179, label %yes.3180, label %no.3181
yes.3180:
  %v3183 = icmp eq i64 %v3175, %v3176
  %v3184 = select i1 %v3183, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.3182
no.3181:
  %v3185 = call ptr @mlf_eq_int(ptr %v3174, ptr inttoptr (i64 1 to ptr))
  br label %join.3182
join.3182:
  %v3186 = phi ptr [ %v3184, %yes.3180 ], [ %v3185, %no.3181 ]
  %v3187 = icmp eq ptr %v3186, inttoptr (i64 6 to ptr)
  br i1 %v3187, label %yes.3188, label %no.3189
yes.3188:
  %v3192 = call ptr @mlf_string(ptr @mlf.bytes.3191, i64 0)
  %v3193 = call ptr @mlf_prim1(i64 3, ptr %v3192)
  br label %join.3190
no.3189:
  %v3259 = call ptr @mlf_env_new(i64 3)
  %v3260 = getelementptr i8, ptr %v3259, i64 24
  store ptr %v3165, ptr %v3260, align 8, !tbaa !3
  %v3261 = getelementptr i8, ptr %v3259, i64 32
  store ptr %v3167, ptr %v3261, align 8, !tbaa !3
  %v3262 = getelementptr i8, ptr %v3259, i64 40
  store ptr %v3174, ptr %v3262, align 8, !tbaa !3
  %v3263 = call ptr @mlf_thunk(ptr @mlf.code.3194, ptr %v3259)
  %v3427 = call ptr @mlf_env_new(i64 3)
  %v3428 = getelementptr i8, ptr %v3427, i64 24
  store ptr %v3167, ptr %v3428, align 8, !tbaa !3
  %v3429 = getelementptr i8, ptr %v3427, i64 32
  store ptr %v3173, ptr %v3429, align 8, !tbaa !3
  %v3430 = getelementptr i8, ptr %v3427, i64 40
  store ptr %v3263, ptr %v3430, align 8, !tbaa !3
  %v3431 = call ptr @mlf_thunk(ptr @mlf.code.3264, ptr %v3427)
  %v3496 = call ptr @mlf_env_new(i64 6)
  %v3497 = getelementptr i8, ptr %v3496, i64 24
  store ptr %v3163, ptr %v3497, align 8, !tbaa !3
  %v3498 = getelementptr i8, ptr %v3496, i64 32
  store ptr %v3165, ptr %v3498, align 8, !tbaa !3
  %v3499 = getelementptr i8, ptr %v3496, i64 40
  store ptr %v3167, ptr %v3499, align 8, !tbaa !3
  %v3500 = getelementptr i8, ptr %v3496, i64 48
  store ptr %v3169, ptr %v3500, align 8, !tbaa !3
  %v3501 = getelementptr i8, ptr %v3496, i64 56
  store ptr %v3171, ptr %v3501, align 8, !tbaa !3
  %v3502 = getelementptr i8, ptr %v3496, i64 64
  store ptr %v3173, ptr %v3502, align 8, !tbaa !3
  %v3503 = call ptr @mlf_closure(ptr @mlf.code.3432, ptr %v3496)
  %v3504 = call ptr @mlf_prim2(i64 1, ptr %v3431, ptr %v3503)
  br label %join.3190
join.3190:
  %v3505 = phi ptr [ %v3193, %yes.3188 ], [ %v3504, %no.3189 ]
  ret ptr %v3505
}

define private ptr @mlf.code.3140(ptr %env, ptr %arg) {
entry:
  %v3141 = getelementptr i8, ptr %env, i64 24
  %v3142 = load ptr, ptr %v3141, align 8, !tbaa !3
  %v3143 = getelementptr i8, ptr %env, i64 32
  %v3144 = load ptr, ptr %v3143, align 8, !tbaa !3
  %v3145 = getelementptr i8, ptr %env, i64 40
  %v3146 = load ptr, ptr %v3145, align 8, !tbaa !3
  %v3147 = getelementptr i8, ptr %env, i64 48
  %v3148 = load ptr, ptr %v3147, align 8, !tbaa !3
  %v3149 = getelementptr i8, ptr %env, i64 56
  %v3150 = load ptr, ptr %v3149, align 8, !tbaa !3
  %v3157 = call ptr @mlf_env_new(i64 2)
  %v3158 = getelementptr i8, ptr %v3157, i64 24
  store ptr %v3142, ptr %v3158, align 8, !tbaa !3
  %v3159 = getelementptr i8, ptr %v3157, i64 32
  store ptr %arg, ptr %v3159, align 8, !tbaa !3
  %v3160 = call ptr @mlf_thunk(ptr @mlf.code.3151, ptr %v3157)
  %v3506 = call ptr @mlf_env_new(i64 6)
  %v3507 = getelementptr i8, ptr %v3506, i64 24
  store ptr %v3142, ptr %v3507, align 8, !tbaa !3
  %v3508 = getelementptr i8, ptr %v3506, i64 32
  store ptr %v3144, ptr %v3508, align 8, !tbaa !3
  %v3509 = getelementptr i8, ptr %v3506, i64 40
  store ptr %v3146, ptr %v3509, align 8, !tbaa !3
  %v3510 = getelementptr i8, ptr %v3506, i64 48
  store ptr %v3148, ptr %v3510, align 8, !tbaa !3
  %v3511 = getelementptr i8, ptr %v3506, i64 56
  store ptr %v3150, ptr %v3511, align 8, !tbaa !3
  %v3512 = getelementptr i8, ptr %v3506, i64 64
  store ptr %arg, ptr %v3512, align 8, !tbaa !3
  %v3513 = call ptr @mlf_closure(ptr @mlf.code.3161, ptr %v3506)
  %v3514 = call ptr @mlf_prim2(i64 1, ptr %v3160, ptr %v3513)
  ret ptr %v3514
}

define private ptr @mlf.worker.97(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) {
entry:
  %v2932 = ptrtoint ptr %a4 to i64
  %v2933 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v2934 = and i64 %v2932, %v2933
  %v2935 = and i64 %v2934, 1
  %v2936 = icmp ne i64 %v2935, 0
  br i1 %v2936, label %yes.2937, label %no.2938
yes.2937:
  %v2940 = icmp eq i64 %v2932, %v2933
  %v2941 = select i1 %v2940, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.2939
no.2938:
  %v2942 = call ptr @mlf_eq_int(ptr %a4, ptr inttoptr (i64 1 to ptr))
  br label %join.2939
join.2939:
  %v2943 = phi ptr [ %v2941, %yes.2937 ], [ %v2942, %no.2938 ]
  %v2944 = icmp eq ptr %v2943, inttoptr (i64 6 to ptr)
  br i1 %v2944, label %yes.2945, label %no.2946
yes.2945:
  %v2949 = call ptr @mlf_string(ptr @mlf.bytes.2948, i64 0)
  %v2950 = call ptr @mlf_prim1(i64 3, ptr %v2949)
  br label %join.2947
no.2946:
  %v3136 = call ptr @mlf_env_new(i64 2)
  %v3137 = getelementptr i8, ptr %v3136, i64 24
  store ptr %a0, ptr %v3137, align 8, !tbaa !3
  %v3138 = getelementptr i8, ptr %v3136, i64 32
  store ptr %a3, ptr %v3138, align 8, !tbaa !3
  %v3139 = call ptr @mlf_thunk(ptr @mlf.code.2951, ptr %v3136)
  %v3515 = call ptr @mlf_env_new(i64 5)
  %v3516 = getelementptr i8, ptr %v3515, i64 24
  store ptr %a0, ptr %v3516, align 8, !tbaa !3
  %v3517 = getelementptr i8, ptr %v3515, i64 32
  store ptr %a1, ptr %v3517, align 8, !tbaa !3
  %v3518 = getelementptr i8, ptr %v3515, i64 40
  store ptr %a2, ptr %v3518, align 8, !tbaa !3
  %v3519 = getelementptr i8, ptr %v3515, i64 48
  store ptr %a3, ptr %v3519, align 8, !tbaa !3
  %v3520 = getelementptr i8, ptr %v3515, i64 56
  store ptr %a4, ptr %v3520, align 8, !tbaa !3
  %v3521 = call ptr @mlf_closure(ptr @mlf.code.3140, ptr %v3515)
  %v3522 = call ptr @mlf_prim2(i64 1, ptr %v3139, ptr %v3521)
  br label %join.2947
join.2947:
  %v3523 = phi ptr [ %v2950, %yes.2945 ], [ %v3522, %no.2946 ]
  ret ptr %v3523
}

define private ptr @mlf.code.2927(ptr %env, ptr %arg) {
entry:
  %v2928 = getelementptr i8, ptr %env, i64 24
  %v2929 = load ptr, ptr %v2928, align 8, !tbaa !3
  %v2930 = getelementptr i8, ptr %env, i64 32
  %v2931 = load ptr, ptr %v2930, align 8, !tbaa !3
  %v3524 = call ptr @mlf.worker.97(ptr %v2931, ptr %v2929, ptr inttoptr (i64 3 to ptr), ptr inttoptr (i64 9 to ptr), ptr inttoptr (i64 9 to ptr))
  ret ptr %v3524
}

define private ptr @mlf.code.3534(ptr %env, ptr %arg) {
entry:
  %v3535 = getelementptr i8, ptr %env, i64 24
  %v3536 = load ptr, ptr %v3535, align 8, !tbaa !3
  %v3537 = getelementptr i8, ptr %env, i64 32
  %v3538 = load ptr, ptr %v3537, align 8, !tbaa !3
  %v3539 = call ptr @mlf_env_new(i64 3)
  %v3540 = getelementptr i8, ptr %v3539, i64 24
  store ptr %v3536, ptr %v3540, align 8, !tbaa !3
  %v3541 = getelementptr i8, ptr %v3539, i64 32
  store ptr %v3538, ptr %v3541, align 8, !tbaa !3
  %v3542 = getelementptr i8, ptr %v3539, i64 40
  store ptr inttoptr (i64 5 to ptr), ptr %v3542, align 8, !tbaa !3
  %v3543 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2041, ptr %v3539)
  ret ptr %v3543
}

define private ptr @mlf.code.3553(ptr %env, ptr %arg) {
entry:
  %v3554 = getelementptr i8, ptr %env, i64 24
  %v3555 = load ptr, ptr %v3554, align 8, !tbaa !3
  %v3556 = getelementptr i8, ptr %env, i64 32
  %v3557 = load ptr, ptr %v3556, align 8, !tbaa !3
  %v3558 = call ptr @mlf.worker.97(ptr %v3557, ptr %v3555, ptr inttoptr (i64 5 to ptr), ptr inttoptr (i64 33 to ptr), ptr inttoptr (i64 33 to ptr))
  ret ptr %v3558
}

define private ptr @mlf.code.3573(ptr %env, ptr %arg) {
entry:
  %v3574 = getelementptr i8, ptr %env, i64 24
  %v3575 = load ptr, ptr %v3574, align 8, !tbaa !3
  %v3576 = call ptr @mlf_prim1(i64 39, ptr %v3575)
  ret ptr %v3576
}

define private ptr @mlf.code.3587(ptr %env, ptr %arg) {
entry:
  %v3588 = getelementptr i8, ptr %env, i64 24
  %v3589 = load ptr, ptr %v3588, align 8, !tbaa !3
  %v3590 = call ptr @mlf_prim1(i64 38, ptr %v3589)
  ret ptr %v3590
}

define private ptr @mlf.numeric.52.piii(ptr %a0, ptr %a1, ptr %a2, ptr %a3) alwaysinline {
entry:
  %v3652 = ptrtoint ptr %a1 to i64
  %v3653 = ptrtoint ptr %a2 to i64
  %v3654 = icmp slt i64 %v3652, %v3653
  %v3655 = select i1 %v3654, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v3656 = icmp eq ptr %v3655, inttoptr (i64 6 to ptr)
  br i1 %v3656, label %tail.yes.3657, label %tail.no.3658
tail.yes.3657:
  %v3659 = getelementptr i8, ptr %a0, i64 24
  %v3660 = load i64, ptr %v3659, align 8, !tbaa !3
  %v3661 = getelementptr i8, ptr %a0, i64 32
  %v3662 = load ptr, ptr %v3661, align 8, !tbaa !3
  %v3663 = ptrtoint ptr %a1 to i64
  %v3664 = ashr i64 %v3663, 1
  %v3665 = and i64 %v3663, 1
  %v3666 = icmp ne i64 %v3665, 0
  %v3667 = icmp ult i64 %v3664, %v3660
  %v3668 = and i1 %v3666, %v3667
  br i1 %v3668, label %array.valid.3669, label %array.invalid.3670
array.invalid.3670:
  call void @mlf_bounds_failure()
  unreachable
array.valid.3669:
  %v3671 = getelementptr i8, ptr %v3662, i64 %v3664
  %v3672 = load i8, ptr %v3671, align 1, !tbaa !4
  %v3673 = zext i8 %v3672 to i64
  %v3674 = shl i64 %v3673, 1
  %v3675 = or i64 %v3674, 1
  %v3676 = inttoptr i64 %v3675 to ptr
  %v3677 = ptrtoint ptr %a1 to i64
  %v3678 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v3679 = sub i64 %v3678, 1
  %v3680 = add nsw i64 %v3677, %v3679
  %v3681 = inttoptr i64 %v3680 to ptr
  %v3682 = ptrtoint ptr %a3 to i64
  %v3683 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v3684 = ashr i64 %v3682, 1
  %v3685 = ashr i64 %v3683, 1
  %v3686 = mul nsw i64 %v3684, %v3685
  %v3687 = shl i64 %v3686, 1
  %v3688 = or i64 %v3687, 1
  %v3689 = inttoptr i64 %v3688 to ptr
  %v3690 = ptrtoint ptr %v3676 to i64
  %v3691 = ptrtoint ptr inttoptr (i64 131 to ptr) to i64
  %v3692 = icmp eq i64 %v3690, %v3691
  %v3693 = select i1 %v3692, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v3694 = icmp eq ptr %v3693, inttoptr (i64 6 to ptr)
  br i1 %v3694, label %yes.3695, label %no.3696
yes.3695:
  br label %join.3697
no.3696:
  %v3698 = ptrtoint ptr %v3676 to i64
  %v3699 = ptrtoint ptr inttoptr (i64 195 to ptr) to i64
  %v3700 = icmp eq i64 %v3698, %v3699
  %v3701 = select i1 %v3700, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v3702 = icmp eq ptr %v3701, inttoptr (i64 6 to ptr)
  br i1 %v3702, label %yes.3703, label %no.3704
yes.3703:
  br label %join.3705
no.3704:
  %v3706 = ptrtoint ptr %v3676 to i64
  %v3707 = ptrtoint ptr inttoptr (i64 135 to ptr) to i64
  %v3708 = icmp eq i64 %v3706, %v3707
  %v3709 = select i1 %v3708, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v3710 = icmp eq ptr %v3709, inttoptr (i64 6 to ptr)
  br i1 %v3710, label %yes.3711, label %no.3712
yes.3711:
  br label %join.3713
no.3712:
  %v3714 = ptrtoint ptr %v3676 to i64
  %v3715 = ptrtoint ptr inttoptr (i64 199 to ptr) to i64
  %v3716 = icmp eq i64 %v3714, %v3715
  %v3717 = select i1 %v3716, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v3718 = icmp eq ptr %v3717, inttoptr (i64 6 to ptr)
  br i1 %v3718, label %yes.3719, label %no.3720
yes.3719:
  br label %join.3721
no.3720:
  %v3722 = ptrtoint ptr %v3676 to i64
  %v3723 = ptrtoint ptr inttoptr (i64 143 to ptr) to i64
  %v3724 = icmp eq i64 %v3722, %v3723
  %v3725 = select i1 %v3724, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v3726 = icmp eq ptr %v3725, inttoptr (i64 6 to ptr)
  br i1 %v3726, label %yes.3727, label %no.3728
yes.3727:
  br label %join.3729
no.3728:
  %v3730 = ptrtoint ptr %v3676 to i64
  %v3731 = ptrtoint ptr inttoptr (i64 207 to ptr) to i64
  %v3732 = icmp eq i64 %v3730, %v3731
  %v3733 = select i1 %v3732, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v3734 = icmp eq ptr %v3733, inttoptr (i64 6 to ptr)
  br i1 %v3734, label %yes.3735, label %no.3736
yes.3735:
  br label %join.3737
no.3736:
  br label %join.3737
join.3737:
  %v3738 = phi ptr [ inttoptr (i64 5 to ptr), %yes.3735 ], [ inttoptr (i64 7 to ptr), %no.3736 ]
  br label %join.3729
join.3729:
  %v3739 = phi ptr [ inttoptr (i64 5 to ptr), %yes.3727 ], [ %v3738, %join.3737 ]
  br label %join.3721
join.3721:
  %v3740 = phi ptr [ inttoptr (i64 3 to ptr), %yes.3719 ], [ %v3739, %join.3729 ]
  br label %join.3713
join.3713:
  %v3741 = phi ptr [ inttoptr (i64 3 to ptr), %yes.3711 ], [ %v3740, %join.3721 ]
  br label %join.3705
join.3705:
  %v3742 = phi ptr [ inttoptr (i64 1 to ptr), %yes.3703 ], [ %v3741, %join.3713 ]
  br label %join.3697
join.3697:
  %v3743 = phi ptr [ inttoptr (i64 1 to ptr), %yes.3695 ], [ %v3742, %join.3705 ]
  %v3744 = ptrtoint ptr %v3689 to i64
  %v3745 = ptrtoint ptr %v3743 to i64
  %v3746 = sub i64 %v3745, 1
  %v3747 = add nsw i64 %v3744, %v3746
  %v3748 = inttoptr i64 %v3747 to ptr
  %v3749 = musttail call ptr @mlf.numeric.52(ptr %a0, ptr %v3681, ptr %a2, ptr %v3748)
  ret ptr %v3749
tail.no.3658:
  ret ptr %a3
}

define private ptr @mlf.numeric.52(ptr %a0, ptr %a1, ptr %a2, ptr %a3) alwaysinline {
entry:
  %v3632 = ptrtoint ptr %a1 to i64
  %v3633 = and i64 %v3632, 1
  %v3634 = icmp ne i64 %v3633, 0
  %v3635 = icmp ult i64 %v3632, 4294967296
  %v3636 = and i1 %v3634, %v3635
  %v3637 = ptrtoint ptr %a2 to i64
  %v3638 = and i64 %v3637, 1
  %v3639 = icmp ne i64 %v3638, 0
  %v3640 = icmp ult i64 %v3637, 4294967296
  %v3641 = and i1 %v3639, %v3640
  %v3642 = ptrtoint ptr %a3 to i64
  %v3643 = and i64 %v3642, 1
  %v3644 = icmp ne i64 %v3643, 0
  %v3645 = icmp ult i64 %v3642, 4294967296
  %v3646 = and i1 %v3644, %v3645
  %v3647 = and i1 true, %v3636
  %v3648 = and i1 %v3647, %v3641
  %v3649 = and i1 %v3648, %v3646
  br i1 %v3649, label %range.fast.3650, label %range.general.3651
range.fast.3650:
  %v3750 = musttail call ptr @mlf.numeric.52.piii(ptr %a0, ptr %a1, ptr %a2, ptr %a3)
  ret ptr %v3750
range.general.3651:
  %v3751 = ptrtoint ptr %a1 to i64
  %v3752 = ptrtoint ptr %a2 to i64
  %v3753 = and i64 %v3751, %v3752
  %v3754 = and i64 %v3753, 1
  %v3755 = icmp ne i64 %v3754, 0
  br i1 %v3755, label %yes.3756, label %no.3757
yes.3756:
  %v3759 = icmp slt i64 %v3751, %v3752
  %v3760 = select i1 %v3759, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.3758
no.3757:
  %v3761 = call ptr @mlf_lt_int(ptr %a1, ptr %a2)
  br label %join.3758
join.3758:
  %v3762 = phi ptr [ %v3760, %yes.3756 ], [ %v3761, %no.3757 ]
  %v3763 = icmp eq ptr %v3762, inttoptr (i64 6 to ptr)
  br i1 %v3763, label %tail.yes.3764, label %tail.no.3765
tail.yes.3764:
  %v3766 = getelementptr i8, ptr %a0, i64 24
  %v3767 = load i64, ptr %v3766, align 8, !tbaa !3
  %v3768 = getelementptr i8, ptr %a0, i64 32
  %v3769 = load ptr, ptr %v3768, align 8, !tbaa !3
  %v3770 = ptrtoint ptr %a1 to i64
  %v3771 = ashr i64 %v3770, 1
  %v3772 = and i64 %v3770, 1
  %v3773 = icmp ne i64 %v3772, 0
  %v3774 = icmp ult i64 %v3771, %v3767
  %v3775 = and i1 %v3773, %v3774
  br i1 %v3775, label %array.valid.3776, label %array.invalid.3777
array.invalid.3777:
  call void @mlf_bounds_failure()
  unreachable
array.valid.3776:
  %v3778 = getelementptr i8, ptr %v3769, i64 %v3771
  %v3779 = load i8, ptr %v3778, align 1, !tbaa !4
  %v3780 = zext i8 %v3779 to i64
  %v3781 = shl i64 %v3780, 1
  %v3782 = or i64 %v3781, 1
  %v3783 = inttoptr i64 %v3782 to ptr
  %v3784 = ptrtoint ptr %a1 to i64
  %v3785 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v3786 = sub i64 %v3785, 1
  %v3787 = add nsw i64 %v3784, %v3786
  %v3788 = inttoptr i64 %v3787 to ptr
  %v3789 = ptrtoint ptr %a3 to i64
  %v3790 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v3791 = and i64 %v3789, %v3790
  %v3792 = and i64 %v3791, 1
  %v3793 = icmp ne i64 %v3792, 0
  br i1 %v3793, label %yes.3794, label %no.3795
yes.3794:
  %v3797 = ashr i64 %v3789, 1
  %v3798 = ashr i64 %v3790, 1
  %v3799 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v3797, i64 %v3798)
  %v3800 = extractvalue { i64, i1 } %v3799, 0
  %v3801 = extractvalue { i64, i1 } %v3799, 1
  %v3802 = xor i1 %v3801, true
  %v3803 = icmp sge i64 %v3800, -4611686018427387904
  %v3804 = icmp sle i64 %v3800, 4611686018427387903
  %v3805 = and i1 %v3803, %v3804
  %v3806 = and i1 %v3805, %v3802
  br i1 %v3806, label %yes.3807, label %no.3808
yes.3807:
  %v3810 = shl i64 %v3800, 1
  %v3811 = or i64 %v3810, 1
  %v3812 = inttoptr i64 %v3811 to ptr
  br label %join.3809
no.3808:
  %v3813 = call ptr @mlf_prim2(i64 14, ptr %a3, ptr inttoptr (i64 9 to ptr))
  br label %join.3809
join.3809:
  %v3814 = phi ptr [ %v3812, %yes.3807 ], [ %v3813, %no.3808 ]
  br label %join.3796
no.3795:
  %v3815 = call ptr @mlf_prim2(i64 14, ptr %a3, ptr inttoptr (i64 9 to ptr))
  br label %join.3796
join.3796:
  %v3816 = phi ptr [ %v3814, %join.3809 ], [ %v3815, %no.3795 ]
  %v3817 = ptrtoint ptr %v3783 to i64
  %v3818 = ptrtoint ptr inttoptr (i64 131 to ptr) to i64
  %v3819 = icmp eq i64 %v3817, %v3818
  %v3820 = select i1 %v3819, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v3821 = icmp eq ptr %v3820, inttoptr (i64 6 to ptr)
  br i1 %v3821, label %yes.3822, label %no.3823
yes.3822:
  br label %join.3824
no.3823:
  %v3825 = ptrtoint ptr %v3783 to i64
  %v3826 = ptrtoint ptr inttoptr (i64 195 to ptr) to i64
  %v3827 = icmp eq i64 %v3825, %v3826
  %v3828 = select i1 %v3827, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v3829 = icmp eq ptr %v3828, inttoptr (i64 6 to ptr)
  br i1 %v3829, label %yes.3830, label %no.3831
yes.3830:
  br label %join.3832
no.3831:
  %v3833 = ptrtoint ptr %v3783 to i64
  %v3834 = ptrtoint ptr inttoptr (i64 135 to ptr) to i64
  %v3835 = icmp eq i64 %v3833, %v3834
  %v3836 = select i1 %v3835, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v3837 = icmp eq ptr %v3836, inttoptr (i64 6 to ptr)
  br i1 %v3837, label %yes.3838, label %no.3839
yes.3838:
  br label %join.3840
no.3839:
  %v3841 = ptrtoint ptr %v3783 to i64
  %v3842 = ptrtoint ptr inttoptr (i64 199 to ptr) to i64
  %v3843 = icmp eq i64 %v3841, %v3842
  %v3844 = select i1 %v3843, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v3845 = icmp eq ptr %v3844, inttoptr (i64 6 to ptr)
  br i1 %v3845, label %yes.3846, label %no.3847
yes.3846:
  br label %join.3848
no.3847:
  %v3849 = ptrtoint ptr %v3783 to i64
  %v3850 = ptrtoint ptr inttoptr (i64 143 to ptr) to i64
  %v3851 = icmp eq i64 %v3849, %v3850
  %v3852 = select i1 %v3851, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v3853 = icmp eq ptr %v3852, inttoptr (i64 6 to ptr)
  br i1 %v3853, label %yes.3854, label %no.3855
yes.3854:
  br label %join.3856
no.3855:
  %v3857 = ptrtoint ptr %v3783 to i64
  %v3858 = ptrtoint ptr inttoptr (i64 207 to ptr) to i64
  %v3859 = icmp eq i64 %v3857, %v3858
  %v3860 = select i1 %v3859, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v3861 = icmp eq ptr %v3860, inttoptr (i64 6 to ptr)
  br i1 %v3861, label %yes.3862, label %no.3863
yes.3862:
  br label %join.3864
no.3863:
  br label %join.3864
join.3864:
  %v3865 = phi ptr [ inttoptr (i64 5 to ptr), %yes.3862 ], [ inttoptr (i64 7 to ptr), %no.3863 ]
  br label %join.3856
join.3856:
  %v3866 = phi ptr [ inttoptr (i64 5 to ptr), %yes.3854 ], [ %v3865, %join.3864 ]
  br label %join.3848
join.3848:
  %v3867 = phi ptr [ inttoptr (i64 3 to ptr), %yes.3846 ], [ %v3866, %join.3856 ]
  br label %join.3840
join.3840:
  %v3868 = phi ptr [ inttoptr (i64 3 to ptr), %yes.3838 ], [ %v3867, %join.3848 ]
  br label %join.3832
join.3832:
  %v3869 = phi ptr [ inttoptr (i64 1 to ptr), %yes.3830 ], [ %v3868, %join.3840 ]
  br label %join.3824
join.3824:
  %v3870 = phi ptr [ inttoptr (i64 1 to ptr), %yes.3822 ], [ %v3869, %join.3832 ]
  %v3871 = ptrtoint ptr %v3816 to i64
  %v3872 = ptrtoint ptr %v3870 to i64
  %v3873 = and i64 %v3871, %v3872
  %v3874 = and i64 %v3873, 1
  %v3875 = icmp ne i64 %v3874, 0
  br i1 %v3875, label %yes.3876, label %no.3877
yes.3876:
  %v3879 = sub i64 %v3872, 1
  %v3880 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v3871, i64 %v3879)
  %v3881 = extractvalue { i64, i1 } %v3880, 0
  %v3882 = extractvalue { i64, i1 } %v3880, 1
  br i1 %v3882, label %yes.3883, label %no.3884
yes.3883:
  %v3886 = call ptr @mlf_add_int(ptr %v3816, ptr %v3870)
  br label %join.3885
no.3884:
  %v3887 = inttoptr i64 %v3881 to ptr
  br label %join.3885
join.3885:
  %v3888 = phi ptr [ %v3886, %yes.3883 ], [ %v3887, %no.3884 ]
  br label %join.3878
no.3877:
  %v3889 = call ptr @mlf_add_int(ptr %v3816, ptr %v3870)
  br label %join.3878
join.3878:
  %v3890 = phi ptr [ %v3888, %join.3885 ], [ %v3889, %no.3877 ]
  %v3891 = musttail call ptr @mlf.numeric.52(ptr %a0, ptr %v3788, ptr %a2, ptr %v3890)
  ret ptr %v3891
tail.no.3765:
  ret ptr %a3
}

define private ptr @mlf.code.3899(ptr %env, ptr %arg) {
entry:
  %v3900 = getelementptr i8, ptr %env, i64 24
  %v3901 = load ptr, ptr %v3900, align 8, !tbaa !3
  %v3902 = getelementptr i8, ptr %env, i64 32
  %v3903 = load ptr, ptr %v3902, align 8, !tbaa !3
  %v3904 = call ptr @mlf_prim2(i64 36, ptr %v3901, ptr %v3903)
  ret ptr %v3904
}

define private ptr @mlf.code.3921(ptr %env, ptr %arg) {
entry:
  %v3922 = getelementptr i8, ptr %env, i64 24
  %v3923 = load ptr, ptr %v3922, align 8, !tbaa !3
  %v3924 = getelementptr i8, ptr %env, i64 32
  %v3925 = load ptr, ptr %v3924, align 8, !tbaa !3
  %v3926 = call ptr @mlf_force(ptr %v3923)
  %v3927 = call ptr @mlf_prim2(i64 14, ptr %v3926, ptr inttoptr (i64 9 to ptr))
  %v3928 = call ptr @mlf_force(ptr %v3925)
  %v3929 = call ptr @mlf.worker.15(ptr %v3928)
  %v3930 = call ptr @mlf_prim2(i64 8, ptr %v3927, ptr %v3929)
  ret ptr %v3930
}

define private ptr @mlf.code.3909(ptr %env, ptr %arg) {
entry:
  %v3910 = getelementptr i8, ptr %env, i64 24
  %v3911 = load ptr, ptr %v3910, align 8, !tbaa !3
  %v3912 = getelementptr i8, ptr %env, i64 32
  %v3913 = load ptr, ptr %v3912, align 8, !tbaa !3
  %v3914 = getelementptr i8, ptr %env, i64 40
  %v3915 = load ptr, ptr %v3914, align 8, !tbaa !3
  %v3916 = getelementptr i8, ptr %env, i64 48
  %v3917 = load ptr, ptr %v3916, align 8, !tbaa !3
  %v3918 = call ptr @mlf_force(ptr %v3913)
  %v3919 = call ptr @mlf_prim2(i64 8, ptr %v3918, ptr inttoptr (i64 3 to ptr))
  %v3920 = call ptr @mlf_force(ptr %v3915)
  %v3931 = call ptr @mlf_env_new(i64 2)
  %v3932 = getelementptr i8, ptr %v3931, i64 24
  store ptr %v3917, ptr %v3932, align 8, !tbaa !3
  %v3933 = getelementptr i8, ptr %v3931, i64 32
  store ptr %arg, ptr %v3933, align 8, !tbaa !3
  %v3934 = call ptr @mlf_thunk(ptr @mlf.code.3921, ptr %v3931)
  %v3935 = call ptr @mlf_env_new(i64 4)
  %v3936 = getelementptr i8, ptr %v3935, i64 24
  store ptr %v3911, ptr %v3936, align 8, !tbaa !3
  %v3937 = getelementptr i8, ptr %v3935, i64 32
  store ptr %v3919, ptr %v3937, align 8, !tbaa !3
  %v3938 = getelementptr i8, ptr %v3935, i64 40
  store ptr %v3920, ptr %v3938, align 8, !tbaa !3
  %v3939 = getelementptr i8, ptr %v3935, i64 48
  store ptr %v3934, ptr %v3939, align 8, !tbaa !3
  %v3940 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.3608, ptr %v3935)
  ret ptr %v3940
}

define private ptr @mlf.worker.52(ptr %a0, ptr %a1, ptr %a2, ptr %a3) {
entry:
  %v3894 = call ptr @mlf_prim2(i64 11, ptr %a1, ptr %a2)
  %v3895 = icmp eq ptr %v3894, inttoptr (i64 6 to ptr)
  br i1 %v3895, label %yes.3896, label %no.3897
yes.3896:
  %v3905 = call ptr @mlf_env_new(i64 2)
  %v3906 = getelementptr i8, ptr %v3905, i64 24
  store ptr %a0, ptr %v3906, align 8, !tbaa !3
  %v3907 = getelementptr i8, ptr %v3905, i64 32
  store ptr %a1, ptr %v3907, align 8, !tbaa !3
  %v3908 = call ptr @mlf_thunk(ptr @mlf.code.3899, ptr %v3905)
  %v3941 = call ptr @mlf_env_new(i64 4)
  %v3942 = getelementptr i8, ptr %v3941, i64 24
  store ptr %a0, ptr %v3942, align 8, !tbaa !3
  %v3943 = getelementptr i8, ptr %v3941, i64 32
  store ptr %a1, ptr %v3943, align 8, !tbaa !3
  %v3944 = getelementptr i8, ptr %v3941, i64 40
  store ptr %a2, ptr %v3944, align 8, !tbaa !3
  %v3945 = getelementptr i8, ptr %v3941, i64 48
  store ptr %a3, ptr %v3945, align 8, !tbaa !3
  %v3946 = call ptr @mlf_closure(ptr @mlf.code.3909, ptr %v3941)
  %v3947 = call ptr @mlf_prim2(i64 1, ptr %v3908, ptr %v3946)
  br label %join.3898
no.3897:
  %v3948 = call ptr @mlf_prim1(i64 0, ptr %a3)
  br label %join.3898
join.3898:
  %v3949 = phi ptr [ %v3947, %yes.3896 ], [ %v3948, %no.3897 ]
  ret ptr %v3949
}

define private ptr @mlf.numeric.entry.3608(ptr %env, ptr %arg) {
entry:
  %v3609 = getelementptr i8, ptr %env, i64 24
  %v3610 = load ptr, ptr %v3609, align 8, !tbaa !3
  %v3611 = getelementptr i8, ptr %env, i64 32
  %v3612 = load ptr, ptr %v3611, align 8, !tbaa !3
  %v3613 = getelementptr i8, ptr %env, i64 40
  %v3614 = load ptr, ptr %v3613, align 8, !tbaa !3
  %v3615 = getelementptr i8, ptr %env, i64 48
  %v3616 = load ptr, ptr %v3615, align 8, !tbaa !3
  %v3617 = call ptr @mlf_peek(ptr %v3610)
  %v3618 = call ptr @mlf_peek(ptr %v3612)
  %v3619 = call ptr @mlf_peek(ptr %v3614)
  %v3620 = call ptr @mlf_peek(ptr %v3616)
  %v3621 = icmp ne ptr %v3617, null
  %v3622 = icmp ne ptr %v3618, null
  %v3623 = icmp ne ptr %v3619, null
  %v3624 = icmp ne ptr %v3620, null
  %v3625 = and i1 true, %v3621
  %v3626 = and i1 %v3625, %v3622
  %v3627 = and i1 %v3626, %v3623
  %v3628 = and i1 %v3627, %v3624
  br i1 %v3628, label %yes.3629, label %no.3630
yes.3629:
  %v3892 = call ptr @mlf.numeric.52(ptr %v3617, ptr %v3618, ptr %v3619, ptr %v3620)
  %v3893 = call ptr @mlf_prim1(i64 0, ptr %v3892)
  br label %join.3631
no.3630:
  %v3950 = call ptr @mlf_force(ptr %v3612)
  %v3951 = call ptr @mlf_force(ptr %v3614)
  %v3952 = call ptr @mlf.worker.52(ptr %v3610, ptr %v3950, ptr %v3951, ptr %v3616)
  br label %join.3631
join.3631:
  %v3953 = phi ptr [ %v3893, %yes.3629 ], [ %v3952, %no.3630 ]
  ret ptr %v3953
}

define private ptr @mlf.code.3603(ptr %env, ptr %arg) {
entry:
  %v3604 = getelementptr i8, ptr %env, i64 24
  %v3605 = load ptr, ptr %v3604, align 8, !tbaa !3
  %v3606 = getelementptr i8, ptr %env, i64 32
  %v3607 = load ptr, ptr %v3606, align 8, !tbaa !3
  %v3954 = call ptr @mlf_force(ptr %v3607)
  %v3955 = call ptr @mlf_env_new(i64 4)
  %v3956 = getelementptr i8, ptr %v3955, i64 24
  store ptr %v3605, ptr %v3956, align 8, !tbaa !3
  %v3957 = getelementptr i8, ptr %v3955, i64 32
  store ptr inttoptr (i64 1 to ptr), ptr %v3957, align 8, !tbaa !3
  %v3958 = getelementptr i8, ptr %v3955, i64 40
  store ptr %v3954, ptr %v3958, align 8, !tbaa !3
  %v3959 = getelementptr i8, ptr %v3955, i64 48
  store ptr inttoptr (i64 1 to ptr), ptr %v3959, align 8, !tbaa !3
  %v3960 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.3608, ptr %v3955)
  ret ptr %v3960
}

define private ptr @mlf.code.3974(ptr %env, ptr %arg) {
entry:
  %v3975 = getelementptr i8, ptr %env, i64 24
  %v3976 = load ptr, ptr %v3975, align 8, !tbaa !3
  %v3977 = getelementptr i8, ptr %env, i64 32
  %v3978 = load ptr, ptr %v3977, align 8, !tbaa !3
  %v3979 = getelementptr i8, ptr %env, i64 40
  %v3980 = load ptr, ptr %v3979, align 8, !tbaa !3
  %v3981 = call ptr @mlf_env_new(i64 3)
  %v3982 = getelementptr i8, ptr %v3981, i64 24
  store ptr %v3976, ptr %v3982, align 8, !tbaa !3
  %v3983 = getelementptr i8, ptr %v3981, i64 32
  store ptr %v3978, ptr %v3983, align 8, !tbaa !3
  %v3984 = getelementptr i8, ptr %v3981, i64 40
  store ptr %v3980, ptr %v3984, align 8, !tbaa !3
  %v3985 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2041, ptr %v3981)
  ret ptr %v3985
}

define private ptr @mlf.code.3996(ptr %env, ptr %arg) {
entry:
  %v3997 = getelementptr i8, ptr %env, i64 24
  %v3998 = load ptr, ptr %v3997, align 8, !tbaa !3
  %v3999 = getelementptr i8, ptr %env, i64 32
  %v4000 = load ptr, ptr %v3999, align 8, !tbaa !3
  %v4001 = call ptr @mlf_prim2(i64 43, ptr %v4000, ptr %v3998)
  ret ptr %v4001
}

define private ptr @mlf.code.4009(ptr %env, ptr %arg) {
entry:
  %v4010 = getelementptr i8, ptr %env, i64 24
  %v4011 = load ptr, ptr %v4010, align 8, !tbaa !3
  %v4012 = getelementptr i8, ptr %env, i64 32
  %v4013 = load ptr, ptr %v4012, align 8, !tbaa !3
  %v4014 = call ptr @mlf_force(ptr %v4013)
  %v4015 = call ptr @mlf_prim1(i64 7, ptr %v4014)
  %v4017 = call ptr @mlf_string(ptr @mlf.bytes.4016, i64 1)
  %v4018 = call ptr @mlf_force(ptr %v4011)
  %v4019 = call ptr @mlf_prim2(i64 6, ptr %v4017, ptr %v4018)
  %v4020 = call ptr @mlf_prim2(i64 6, ptr %v4015, ptr %v4019)
  ret ptr %v4020
}

define private ptr @mlf.code.4006(ptr %env, ptr %arg) {
entry:
  %v4007 = getelementptr i8, ptr %env, i64 24
  %v4008 = load ptr, ptr %v4007, align 8, !tbaa !3
  %v4021 = call ptr @mlf_env_new(i64 2)
  %v4022 = getelementptr i8, ptr %v4021, i64 24
  store ptr %v4008, ptr %v4022, align 8, !tbaa !3
  %v4023 = getelementptr i8, ptr %v4021, i64 32
  store ptr %arg, ptr %v4023, align 8, !tbaa !3
  %v4024 = call ptr @mlf_thunk(ptr @mlf.code.4009, ptr %v4021)
  %v4025 = call ptr @mlf_prim1(i64 3, ptr %v4024)
  ret ptr %v4025
}

define private ptr @mlf.code.3991(ptr %env, ptr %arg) {
entry:
  %v3992 = getelementptr i8, ptr %env, i64 24
  %v3993 = load ptr, ptr %v3992, align 8, !tbaa !3
  %v3994 = getelementptr i8, ptr %env, i64 32
  %v3995 = load ptr, ptr %v3994, align 8, !tbaa !3
  %v4002 = call ptr @mlf_env_new(i64 2)
  %v4003 = getelementptr i8, ptr %v4002, i64 24
  store ptr %v3995, ptr %v4003, align 8, !tbaa !3
  %v4004 = getelementptr i8, ptr %v4002, i64 32
  store ptr %arg, ptr %v4004, align 8, !tbaa !3
  %v4005 = call ptr @mlf_thunk(ptr @mlf.code.3996, ptr %v4002)
  %v4026 = call ptr @mlf_env_new(i64 1)
  %v4027 = getelementptr i8, ptr %v4026, i64 24
  store ptr %v3993, ptr %v4027, align 8, !tbaa !3
  %v4028 = call ptr @mlf_closure(ptr @mlf.code.4006, ptr %v4026)
  %v4029 = call ptr @mlf_prim2(i64 1, ptr %v4005, ptr %v4028)
  ret ptr %v4029
}

define private ptr @mlf.code.3965(ptr %env, ptr %arg) {
entry:
  %v3966 = getelementptr i8, ptr %env, i64 24
  %v3967 = load ptr, ptr %v3966, align 8, !tbaa !3
  %v3968 = getelementptr i8, ptr %env, i64 32
  %v3969 = load ptr, ptr %v3968, align 8, !tbaa !3
  %v3970 = getelementptr i8, ptr %env, i64 40
  %v3971 = load ptr, ptr %v3970, align 8, !tbaa !3
  %v3972 = getelementptr i8, ptr %env, i64 48
  %v3973 = load ptr, ptr %v3972, align 8, !tbaa !3
  %v3986 = call ptr @mlf_env_new(i64 3)
  %v3987 = getelementptr i8, ptr %v3986, i64 24
  store ptr %v3967, ptr %v3987, align 8, !tbaa !3
  %v3988 = getelementptr i8, ptr %v3986, i64 32
  store ptr %v3969, ptr %v3988, align 8, !tbaa !3
  %v3989 = getelementptr i8, ptr %v3986, i64 40
  store ptr %v3973, ptr %v3989, align 8, !tbaa !3
  %v3990 = call ptr @mlf_thunk(ptr @mlf.code.3974, ptr %v3986)
  %v4030 = call ptr @mlf_env_new(i64 2)
  %v4031 = getelementptr i8, ptr %v4030, i64 24
  store ptr %v3971, ptr %v4031, align 8, !tbaa !3
  %v4032 = getelementptr i8, ptr %v4030, i64 32
  store ptr %arg, ptr %v4032, align 8, !tbaa !3
  %v4033 = call ptr @mlf_closure(ptr @mlf.code.3991, ptr %v4030)
  %v4034 = call ptr @mlf_prim2(i64 1, ptr %v3990, ptr %v4033)
  ret ptr %v4034
}

define private ptr @mlf.code.3594(ptr %env, ptr %arg) {
entry:
  %v3595 = getelementptr i8, ptr %env, i64 24
  %v3596 = load ptr, ptr %v3595, align 8, !tbaa !3
  %v3597 = getelementptr i8, ptr %env, i64 32
  %v3598 = load ptr, ptr %v3597, align 8, !tbaa !3
  %v3599 = getelementptr i8, ptr %env, i64 40
  %v3600 = load ptr, ptr %v3599, align 8, !tbaa !3
  %v3601 = getelementptr i8, ptr %env, i64 48
  %v3602 = load ptr, ptr %v3601, align 8, !tbaa !3
  %v3961 = call ptr @mlf_env_new(i64 2)
  %v3962 = getelementptr i8, ptr %v3961, i64 24
  store ptr %v3602, ptr %v3962, align 8, !tbaa !3
  %v3963 = getelementptr i8, ptr %v3961, i64 32
  store ptr %arg, ptr %v3963, align 8, !tbaa !3
  %v3964 = call ptr @mlf_thunk(ptr @mlf.code.3603, ptr %v3961)
  %v4035 = call ptr @mlf_env_new(i64 4)
  %v4036 = getelementptr i8, ptr %v4035, i64 24
  store ptr %v3596, ptr %v4036, align 8, !tbaa !3
  %v4037 = getelementptr i8, ptr %v4035, i64 32
  store ptr %v3598, ptr %v4037, align 8, !tbaa !3
  %v4038 = getelementptr i8, ptr %v4035, i64 40
  store ptr %v3600, ptr %v4038, align 8, !tbaa !3
  %v4039 = getelementptr i8, ptr %v4035, i64 48
  store ptr %arg, ptr %v4039, align 8, !tbaa !3
  %v4040 = call ptr @mlf_closure(ptr @mlf.code.3965, ptr %v4035)
  %v4041 = call ptr @mlf_prim2(i64 1, ptr %v3964, ptr %v4040)
  ret ptr %v4041
}

define private ptr @mlf.code.3580(ptr %env, ptr %arg) {
entry:
  %v3581 = getelementptr i8, ptr %env, i64 24
  %v3582 = load ptr, ptr %v3581, align 8, !tbaa !3
  %v3583 = getelementptr i8, ptr %env, i64 32
  %v3584 = load ptr, ptr %v3583, align 8, !tbaa !3
  %v3585 = getelementptr i8, ptr %env, i64 40
  %v3586 = load ptr, ptr %v3585, align 8, !tbaa !3
  %v3591 = call ptr @mlf_env_new(i64 1)
  %v3592 = getelementptr i8, ptr %v3591, i64 24
  store ptr %arg, ptr %v3592, align 8, !tbaa !3
  %v3593 = call ptr @mlf_thunk(ptr @mlf.code.3587, ptr %v3591)
  %v4042 = call ptr @mlf_env_new(i64 4)
  %v4043 = getelementptr i8, ptr %v4042, i64 24
  store ptr %v3582, ptr %v4043, align 8, !tbaa !3
  %v4044 = getelementptr i8, ptr %v4042, i64 32
  store ptr %v3584, ptr %v4044, align 8, !tbaa !3
  %v4045 = getelementptr i8, ptr %v4042, i64 40
  store ptr %v3586, ptr %v4045, align 8, !tbaa !3
  %v4046 = getelementptr i8, ptr %v4042, i64 48
  store ptr %arg, ptr %v4046, align 8, !tbaa !3
  %v4047 = call ptr @mlf_closure(ptr @mlf.code.3594, ptr %v4042)
  %v4048 = call ptr @mlf_prim2(i64 1, ptr %v3593, ptr %v4047)
  ret ptr %v4048
}

define private ptr @mlf.worker.108(ptr %a0, ptr %a1, ptr %a2) {
entry:
  %v3577 = call ptr @mlf_env_new(i64 1)
  %v3578 = getelementptr i8, ptr %v3577, i64 24
  store ptr %a2, ptr %v3578, align 8, !tbaa !3
  %v3579 = call ptr @mlf_thunk(ptr @mlf.code.3573, ptr %v3577)
  %v4049 = call ptr @mlf_env_new(i64 3)
  %v4050 = getelementptr i8, ptr %v4049, i64 24
  store ptr %a0, ptr %v4050, align 8, !tbaa !3
  %v4051 = getelementptr i8, ptr %v4049, i64 32
  store ptr %a1, ptr %v4051, align 8, !tbaa !3
  %v4052 = getelementptr i8, ptr %v4049, i64 40
  store ptr %a2, ptr %v4052, align 8, !tbaa !3
  %v4053 = call ptr @mlf_closure(ptr @mlf.code.3580, ptr %v4049)
  %v4054 = call ptr @mlf_prim2(i64 1, ptr %v3579, ptr %v4053)
  ret ptr %v4054
}

define private ptr @mlf.code.3568(ptr %env, ptr %arg) {
entry:
  %v3569 = getelementptr i8, ptr %env, i64 24
  %v3570 = load ptr, ptr %v3569, align 8, !tbaa !3
  %v3571 = getelementptr i8, ptr %env, i64 32
  %v3572 = load ptr, ptr %v3571, align 8, !tbaa !3
  %v4056 = call ptr @mlf_string(ptr @mlf.bytes.4055, i64 3)
  %v4057 = call ptr @mlf.worker.108(ptr %v3570, ptr %v3572, ptr %v4056)
  ret ptr %v4057
}

define private ptr @mlf.code.4067(ptr %env, ptr %arg) {
entry:
  %v4068 = getelementptr i8, ptr %env, i64 24
  %v4069 = load ptr, ptr %v4068, align 8, !tbaa !3
  %v4070 = getelementptr i8, ptr %env, i64 32
  %v4071 = load ptr, ptr %v4070, align 8, !tbaa !3
  %v4073 = call ptr @mlf_string(ptr @mlf.bytes.4072, i64 4)
  %v4074 = call ptr @mlf.worker.108(ptr %v4069, ptr %v4071, ptr %v4073)
  ret ptr %v4074
}

define private ptr @mlf.code.4084(ptr %env, ptr %arg) {
entry:
  %v4085 = getelementptr i8, ptr %env, i64 24
  %v4086 = load ptr, ptr %v4085, align 8, !tbaa !3
  %v4087 = getelementptr i8, ptr %env, i64 32
  %v4088 = load ptr, ptr %v4087, align 8, !tbaa !3
  %v4090 = call ptr @mlf_string(ptr @mlf.bytes.4089, i64 6)
  %v4091 = call ptr @mlf.worker.108(ptr %v4086, ptr %v4088, ptr %v4090)
  ret ptr %v4091
}

define private ptr @mlf.code.4101(ptr %env, ptr %arg) {
entry:
  %v4102 = getelementptr i8, ptr %env, i64 24
  %v4103 = load ptr, ptr %v4102, align 8, !tbaa !3
  %v4104 = getelementptr i8, ptr %env, i64 32
  %v4105 = load ptr, ptr %v4104, align 8, !tbaa !3
  %v4107 = call ptr @mlf_string(ptr @mlf.bytes.4106, i64 12)
  %v4108 = call ptr @mlf.worker.108(ptr %v4103, ptr %v4105, ptr %v4107)
  ret ptr %v4108
}

define private ptr @mlf.code.4113(ptr %env, ptr %arg) {
entry:
  %v4114 = getelementptr i8, ptr %env, i64 24
  %v4115 = load ptr, ptr %v4114, align 8, !tbaa !3
  %v4116 = getelementptr i8, ptr %env, i64 32
  %v4117 = load ptr, ptr %v4116, align 8, !tbaa !3
  %v4119 = call ptr @mlf_string(ptr @mlf.bytes.4118, i64 18)
  %v4120 = call ptr @mlf.worker.108(ptr %v4115, ptr %v4117, ptr %v4119)
  ret ptr %v4120
}

define private ptr @mlf.code.4096(ptr %env, ptr %arg) {
entry:
  %v4097 = getelementptr i8, ptr %env, i64 24
  %v4098 = load ptr, ptr %v4097, align 8, !tbaa !3
  %v4099 = getelementptr i8, ptr %env, i64 32
  %v4100 = load ptr, ptr %v4099, align 8, !tbaa !3
  %v4109 = call ptr @mlf_env_new(i64 2)
  %v4110 = getelementptr i8, ptr %v4109, i64 24
  store ptr %v4098, ptr %v4110, align 8, !tbaa !3
  %v4111 = getelementptr i8, ptr %v4109, i64 32
  store ptr %v4100, ptr %v4111, align 8, !tbaa !3
  %v4112 = call ptr @mlf_thunk(ptr @mlf.code.4101, ptr %v4109)
  %v4121 = call ptr @mlf_env_new(i64 2)
  %v4122 = getelementptr i8, ptr %v4121, i64 24
  store ptr %v4098, ptr %v4122, align 8, !tbaa !3
  %v4123 = getelementptr i8, ptr %v4121, i64 32
  store ptr %v4100, ptr %v4123, align 8, !tbaa !3
  %v4124 = call ptr @mlf_closure(ptr @mlf.code.4113, ptr %v4121)
  %v4125 = call ptr @mlf_prim2(i64 1, ptr %v4112, ptr %v4124)
  ret ptr %v4125
}

define private ptr @mlf.code.4079(ptr %env, ptr %arg) {
entry:
  %v4080 = getelementptr i8, ptr %env, i64 24
  %v4081 = load ptr, ptr %v4080, align 8, !tbaa !3
  %v4082 = getelementptr i8, ptr %env, i64 32
  %v4083 = load ptr, ptr %v4082, align 8, !tbaa !3
  %v4092 = call ptr @mlf_env_new(i64 2)
  %v4093 = getelementptr i8, ptr %v4092, i64 24
  store ptr %v4081, ptr %v4093, align 8, !tbaa !3
  %v4094 = getelementptr i8, ptr %v4092, i64 32
  store ptr %v4083, ptr %v4094, align 8, !tbaa !3
  %v4095 = call ptr @mlf_thunk(ptr @mlf.code.4084, ptr %v4092)
  %v4126 = call ptr @mlf_env_new(i64 2)
  %v4127 = getelementptr i8, ptr %v4126, i64 24
  store ptr %v4081, ptr %v4127, align 8, !tbaa !3
  %v4128 = getelementptr i8, ptr %v4126, i64 32
  store ptr %v4083, ptr %v4128, align 8, !tbaa !3
  %v4129 = call ptr @mlf_closure(ptr @mlf.code.4096, ptr %v4126)
  %v4130 = call ptr @mlf_prim2(i64 1, ptr %v4095, ptr %v4129)
  ret ptr %v4130
}

define private ptr @mlf.code.4062(ptr %env, ptr %arg) {
entry:
  %v4063 = getelementptr i8, ptr %env, i64 24
  %v4064 = load ptr, ptr %v4063, align 8, !tbaa !3
  %v4065 = getelementptr i8, ptr %env, i64 32
  %v4066 = load ptr, ptr %v4065, align 8, !tbaa !3
  %v4075 = call ptr @mlf_env_new(i64 2)
  %v4076 = getelementptr i8, ptr %v4075, i64 24
  store ptr %v4064, ptr %v4076, align 8, !tbaa !3
  %v4077 = getelementptr i8, ptr %v4075, i64 32
  store ptr %v4066, ptr %v4077, align 8, !tbaa !3
  %v4078 = call ptr @mlf_thunk(ptr @mlf.code.4067, ptr %v4075)
  %v4131 = call ptr @mlf_env_new(i64 2)
  %v4132 = getelementptr i8, ptr %v4131, i64 24
  store ptr %v4064, ptr %v4132, align 8, !tbaa !3
  %v4133 = getelementptr i8, ptr %v4131, i64 32
  store ptr %v4066, ptr %v4133, align 8, !tbaa !3
  %v4134 = call ptr @mlf_closure(ptr @mlf.code.4079, ptr %v4131)
  %v4135 = call ptr @mlf_prim2(i64 1, ptr %v4078, ptr %v4134)
  ret ptr %v4135
}

define private ptr @mlf.code.3563(ptr %env, ptr %arg) {
entry:
  %v3564 = getelementptr i8, ptr %env, i64 24
  %v3565 = load ptr, ptr %v3564, align 8, !tbaa !3
  %v3566 = getelementptr i8, ptr %env, i64 32
  %v3567 = load ptr, ptr %v3566, align 8, !tbaa !3
  %v4058 = call ptr @mlf_env_new(i64 2)
  %v4059 = getelementptr i8, ptr %v4058, i64 24
  store ptr %v3565, ptr %v4059, align 8, !tbaa !3
  %v4060 = getelementptr i8, ptr %v4058, i64 32
  store ptr %v3567, ptr %v4060, align 8, !tbaa !3
  %v4061 = call ptr @mlf_thunk(ptr @mlf.code.3568, ptr %v4058)
  %v4136 = call ptr @mlf_env_new(i64 2)
  %v4137 = getelementptr i8, ptr %v4136, i64 24
  store ptr %v3565, ptr %v4137, align 8, !tbaa !3
  %v4138 = getelementptr i8, ptr %v4136, i64 32
  store ptr %v3567, ptr %v4138, align 8, !tbaa !3
  %v4139 = call ptr @mlf_closure(ptr @mlf.code.4062, ptr %v4136)
  %v4140 = call ptr @mlf_prim2(i64 1, ptr %v4061, ptr %v4139)
  ret ptr %v4140
}

define private ptr @mlf.code.3548(ptr %env, ptr %arg) {
entry:
  %v3549 = getelementptr i8, ptr %env, i64 24
  %v3550 = load ptr, ptr %v3549, align 8, !tbaa !3
  %v3551 = getelementptr i8, ptr %env, i64 32
  %v3552 = load ptr, ptr %v3551, align 8, !tbaa !3
  %v3559 = call ptr @mlf_env_new(i64 2)
  %v3560 = getelementptr i8, ptr %v3559, i64 24
  store ptr %v3552, ptr %v3560, align 8, !tbaa !3
  %v3561 = getelementptr i8, ptr %v3559, i64 32
  store ptr %arg, ptr %v3561, align 8, !tbaa !3
  %v3562 = call ptr @mlf_thunk(ptr @mlf.code.3553, ptr %v3559)
  %v4141 = call ptr @mlf_env_new(i64 2)
  %v4142 = getelementptr i8, ptr %v4141, i64 24
  store ptr %v3550, ptr %v4142, align 8, !tbaa !3
  %v4143 = getelementptr i8, ptr %v4141, i64 32
  store ptr %v3552, ptr %v4143, align 8, !tbaa !3
  %v4144 = call ptr @mlf_closure(ptr @mlf.code.3563, ptr %v4141)
  %v4145 = call ptr @mlf_prim2(i64 1, ptr %v3562, ptr %v4144)
  ret ptr %v4145
}

define private ptr @mlf.code.3529(ptr %env, ptr %arg) {
entry:
  %v3530 = getelementptr i8, ptr %env, i64 24
  %v3531 = load ptr, ptr %v3530, align 8, !tbaa !3
  %v3532 = getelementptr i8, ptr %env, i64 32
  %v3533 = load ptr, ptr %v3532, align 8, !tbaa !3
  %v3544 = call ptr @mlf_env_new(i64 2)
  %v3545 = getelementptr i8, ptr %v3544, i64 24
  store ptr %v3531, ptr %v3545, align 8, !tbaa !3
  %v3546 = getelementptr i8, ptr %v3544, i64 32
  store ptr %v3533, ptr %v3546, align 8, !tbaa !3
  %v3547 = call ptr @mlf_thunk(ptr @mlf.code.3534, ptr %v3544)
  %v4146 = call ptr @mlf_env_new(i64 2)
  %v4147 = getelementptr i8, ptr %v4146, i64 24
  store ptr %v3531, ptr %v4147, align 8, !tbaa !3
  %v4148 = getelementptr i8, ptr %v4146, i64 32
  store ptr %v3533, ptr %v4148, align 8, !tbaa !3
  %v4149 = call ptr @mlf_closure(ptr @mlf.code.3548, ptr %v4146)
  %v4150 = call ptr @mlf_prim2(i64 1, ptr %v3547, ptr %v4149)
  ret ptr %v4150
}

define private ptr @mlf.code.2922(ptr %env, ptr %arg) {
entry:
  %v2923 = getelementptr i8, ptr %env, i64 24
  %v2924 = load ptr, ptr %v2923, align 8, !tbaa !3
  %v2925 = getelementptr i8, ptr %env, i64 32
  %v2926 = load ptr, ptr %v2925, align 8, !tbaa !3
  %v3525 = call ptr @mlf_env_new(i64 2)
  %v3526 = getelementptr i8, ptr %v3525, i64 24
  store ptr %v2926, ptr %v3526, align 8, !tbaa !3
  %v3527 = getelementptr i8, ptr %v3525, i64 32
  store ptr %arg, ptr %v3527, align 8, !tbaa !3
  %v3528 = call ptr @mlf_thunk(ptr @mlf.code.2927, ptr %v3525)
  %v4151 = call ptr @mlf_env_new(i64 2)
  %v4152 = getelementptr i8, ptr %v4151, i64 24
  store ptr %v2924, ptr %v4152, align 8, !tbaa !3
  %v4153 = getelementptr i8, ptr %v4151, i64 32
  store ptr %v2926, ptr %v4153, align 8, !tbaa !3
  %v4154 = call ptr @mlf_closure(ptr @mlf.code.3529, ptr %v4151)
  %v4155 = call ptr @mlf_prim2(i64 1, ptr %v3528, ptr %v4154)
  ret ptr %v4155
}

define private ptr @mlf.code.2015(ptr %env, ptr %arg) {
entry:
  %v2016 = call ptr @mlf_force(ptr %arg)
  %v2017 = ptrtoint ptr %v2016 to i64
  %v2018 = and i64 %v2017, 7
  %v2019 = icmp eq i64 %v2018, 4
  br i1 %v2019, label %yes.2020, label %no.2021
yes.2020:
  %v2023 = lshr i64 %v2017, 3
  br label %join.2022
no.2021:
  %v2024 = getelementptr i8, ptr %v2016, i64 24
  %v2025 = load i64, ptr %v2024, align 8, !tbaa !3
  br label %join.2022
join.2022:
  %v2026 = phi i64 [ %v2023, %yes.2020 ], [ %v2025, %no.2021 ]
  switch i64 %v2026, label %case.missing.2028 [
    i64 1, label %case.2027
  ]
case.2027:
  %v2030 = getelementptr i8, ptr %v2016, i64 40
  %v2031 = load ptr, ptr %v2030, align 8, !tbaa !3
  %v2032 = getelementptr i8, ptr %v2031, i64 24
  %v2033 = load ptr, ptr %v2032, align 8, !tbaa !3
  %v2034 = getelementptr i8, ptr %v2031, i64 32
  %v2035 = load ptr, ptr %v2034, align 8, !tbaa !3
  %v2918 = call ptr @mlf_env_new(i64 2)
  %v2919 = getelementptr i8, ptr %v2918, i64 24
  store ptr %v2033, ptr %v2919, align 8, !tbaa !3
  %v2920 = getelementptr i8, ptr %v2918, i64 32
  store ptr %v2035, ptr %v2920, align 8, !tbaa !3
  %v2921 = call ptr @mlf_thunk(ptr @mlf.code.2036, ptr %v2918)
  %v4156 = call ptr @mlf_env_new(i64 2)
  %v4157 = getelementptr i8, ptr %v4156, i64 24
  store ptr %v2033, ptr %v4157, align 8, !tbaa !3
  %v4158 = getelementptr i8, ptr %v4156, i64 32
  store ptr %v2035, ptr %v4158, align 8, !tbaa !3
  %v4159 = call ptr @mlf_closure(ptr @mlf.code.2922, ptr %v4156)
  %v4160 = call ptr @mlf_prim2(i64 1, ptr %v2921, ptr %v4159)
  br label %case.join.2029
case.missing.2028:
  call void @mlf_match_failure()
  unreachable
case.join.2029:
  %v4161 = phi ptr [ %v4160, %case.2027 ]
  ret ptr %v4161
}

define private ptr @mlf.code.560(ptr %env, ptr %arg) {
entry:
  %v2012 = call ptr @mlf_env_new(i64 1)
  %v2013 = getelementptr i8, ptr %v2012, i64 24
  store ptr %arg, ptr %v2013, align 8, !tbaa !3
  %v2014 = call ptr @mlf_thunk(ptr @mlf.code.561, ptr %v2012)
  %v4162 = call ptr @mlf_closure(ptr @mlf.code.2015, ptr null)
  %v4163 = call ptr @mlf_prim2(i64 1, ptr %v2014, ptr %v4162)
  ret ptr %v4163
}

define private ptr @mlf.code.556(ptr %env, ptr %arg) {
entry:
  %v559 = call ptr @mlf_thunk(ptr @mlf.code.557, ptr null)
  %v4164 = call ptr @mlf_closure(ptr @mlf.code.560, ptr null)
  %v4165 = call ptr @mlf_prim2(i64 1, ptr %v559, ptr %v4164)
  ret ptr %v4165
}

define private ptr @mlf.code.0(ptr %env, ptr %arg) {
entry:
  %v555 = call ptr @mlf_thunk(ptr @mlf.code.1, ptr null)
  %v4166 = call ptr @mlf_closure(ptr @mlf.code.556, ptr null)
  %v4167 = call ptr @mlf_prim2(i64 1, ptr %v555, ptr %v4166)
  ret ptr %v4167
}

declare void @mlf_require_standard_abi()
define ptr @mlf_entry() {
  call void @mlf_require_standard_abi()
  %root = call ptr @mlf.code.0(ptr null, ptr null)
  ret ptr %root
}
define i32 @main(i32 %argc, ptr %argv) {
  call void @mlf_set_args(i32 %argc, ptr %argv)
  %root = call ptr @mlf_entry()
  %status = call i32 @mlf_run(ptr %root, i64 1)
  ret i32 %status
}
