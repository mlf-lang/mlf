; Generated from independently checked xMLF.
source_filename = "emlf"

declare ptr @mlf_execute_st_lazy(ptr)
declare ptr @mlf_st_new_array(ptr, ptr)
declare ptr @mlf_st_read_array(ptr, ptr)
declare ptr @mlf_st_write_array(ptr, ptr, ptr)
declare ptr @mlf_st_length_array(ptr)
declare void @mlf_set_args(i32, ptr)
declare ptr @mlf_env_new(i64)
declare void @mlf_env_set(ptr, i64, ptr)
declare ptr @mlf_env_get(ptr, i64)
declare ptr @mlf_thunk(ptr, ptr)
declare ptr @mlf_closure(ptr, ptr)
declare ptr @mlf_application(ptr, ptr)
declare ptr @mlf_hole()
declare void @mlf_fill(ptr, ptr)
declare ptr @mlf_integer(ptr)
declare ptr @mlf_string(ptr, i64)
declare ptr @mlf_double(double)
declare double @llvm.sqrt.f64(double)
declare double @mlf_int_to_double(ptr)
declare ptr @mlf_read_int_table(ptr, ptr)
declare ptr @mlf_write_int_table(ptr, ptr, ptr)
declare ptr @mlf_add_int_table(ptr, ptr, ptr)
declare void @mlf_roots_enter(ptr, i64, ptr)
declare void @mlf_roots_leave(ptr)
declare void @mlf_gc_check(i64, ptr)
declare ptr @mlf_get_byte_line()
declare ptr @mlf_new_array(i64, ptr, ptr)
declare ptr @mlf_bytes_from_string(ptr)
declare ptr @mlf_put_bytes(ptr, ptr, ptr)
declare ptr @mlf_new_int_table()
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare i8 @mlf_byte(ptr)
declare ptr @mlf_peek(ptr)
declare ptr @mlf_native_io(ptr, ptr)
declare void @mlf_bounds_failure() noreturn
declare ptr @mlf_primitive(i64)
declare ptr @mlf_prim1(i64, ptr)
declare ptr @mlf_prim2(i64, ptr, ptr)
declare i64 @mlf_truth(ptr)
declare ptr @mlf_prim3(i64, ptr, ptr, ptr)
declare ptr @mlf_force(ptr)
declare ptr @mlf_add_int(ptr, ptr)
declare ptr @mlf_sub_int(ptr, ptr)
declare ptr @mlf_eq_int(ptr, ptr)
declare ptr @mlf_lt_int(ptr, ptr)
declare ptr @mlf_constructor(i64, i64)
declare ptr @mlf_constructor1(i64, ptr)
declare ptr @mlf_constructor2(i64, ptr, ptr)
declare ptr @mlf_constructor_fields(i64, ptr)
declare ptr @mlf_constructor_new(i64, i64)
declare ptr @mlf_field(ptr, i64)
declare void @mlf_match_failure() noreturn
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare i32 @mlf_run(ptr, i64)

!0 = !{!"MLF storage"}
!1 = !{!"managed object", !0}
!2 = !{!"array cells", !0}
!3 = !{!1, !1, i64 0}
!4 = !{!2, !2, i64 0}
@mlf.bytes.91 = private unnamed_addr constant [11 x i8] c"\20\6f\66\20\64\65\70\74\68\20\00", align 1
@mlf.bytes.95 = private unnamed_addr constant [10 x i8] c"\09\20\63\68\65\63\6b\3a\20\00", align 1
@mlf.bytes.109 = private unnamed_addr constant [13 x i8] c"\73\74\72\65\74\63\68\20\74\72\65\65\00", align 1
@mlf.bytes.342 = private unnamed_addr constant [13 x i8] c"\69\6e\76\61\6c\69\64\20\74\72\65\65\00", align 1
@mlf.bytes.604 = private unnamed_addr constant [8 x i8] c"\09\20\74\72\65\65\73\00", align 1
@mlf.bytes.666 = private unnamed_addr constant [16 x i8] c"\6c\6f\6e\67\20\6c\69\76\65\64\20\74\72\65\65\00", align 1
define private ptr @mlf.worker.29(ptr %a0, ptr %a1) {
entry:
  %v6 = call ptr @mlf_prim1(i64 7, ptr %a1)
  %v7 = call ptr @mlf_prim2(i64 12, ptr %a0, ptr %v6)
  %v8 = icmp eq ptr %v7, inttoptr (i64 6 to ptr)
  br i1 %v8, label %yes.9, label %no.10
yes.9:
  br label %join.11
no.10:
  %v12 = ptrtoint ptr %a1 to i64
  %v13 = ptrtoint ptr inttoptr (i64 41 to ptr) to i64
  %v14 = and i64 %v12, %v13
  %v15 = and i64 %v14, 1
  %v16 = icmp ne i64 %v15, 0
  br i1 %v16, label %yes.17, label %no.18
yes.17:
  %v20 = icmp eq i64 %v12, %v13
  %v21 = select i1 %v20, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.19
no.18:
  %v22 = call ptr @mlf_eq_int(ptr %a1, ptr inttoptr (i64 41 to ptr))
  br label %join.19
join.19:
  %v23 = phi ptr [ %v21, %yes.17 ], [ %v22, %no.18 ]
  %v24 = icmp eq ptr %v23, inttoptr (i64 6 to ptr)
  br i1 %v24, label %yes.25, label %no.26
yes.25:
  br label %join.27
no.26:
  %v28 = ptrtoint ptr %a1 to i64
  %v29 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v30 = and i64 %v28, %v29
  %v31 = and i64 %v30, 1
  %v32 = icmp ne i64 %v31, 0
  br i1 %v32, label %yes.33, label %no.34
yes.33:
  %v36 = sub i64 %v29, 1
  %v37 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v28, i64 %v36)
  %v38 = extractvalue { i64, i1 } %v37, 0
  %v39 = extractvalue { i64, i1 } %v37, 1
  br i1 %v39, label %yes.40, label %no.41
yes.40:
  %v43 = call ptr @mlf_add_int(ptr %a1, ptr inttoptr (i64 3 to ptr))
  br label %join.42
no.41:
  %v44 = inttoptr i64 %v38 to ptr
  br label %join.42
join.42:
  %v45 = phi ptr [ %v43, %yes.40 ], [ %v44, %no.41 ]
  br label %join.35
no.34:
  %v46 = call ptr @mlf_add_int(ptr %a1, ptr inttoptr (i64 3 to ptr))
  br label %join.35
join.35:
  %v47 = phi ptr [ %v45, %join.42 ], [ %v46, %no.34 ]
  %v48 = call ptr @mlf.worker.29(ptr %a0, ptr %v47)
  br label %join.27
join.27:
  %v49 = phi ptr [ inttoptr (i64 1 to ptr), %yes.25 ], [ %v48, %join.35 ]
  br label %join.11
join.11:
  %v50 = phi ptr [ %a1, %yes.9 ], [ %v49, %join.27 ]
  ret ptr %v50
}

define private ptr @mlf.code.3(ptr %env, ptr %arg) {
entry:
  %v4 = getelementptr i8, ptr %env, i64 24
  %v5 = load ptr, ptr %v4, align 8, !tbaa !3
  %v51 = call ptr @mlf_force(ptr %v5)
  %v52 = call ptr @mlf.worker.29(ptr %v51, ptr inttoptr (i64 1 to ptr))
  ret ptr %v52
}

define private ptr @mlf.code.56(ptr %env, ptr %arg) {
entry:
  %v57 = getelementptr i8, ptr %env, i64 24
  %v58 = load ptr, ptr %v57, align 8, !tbaa !3
  %v59 = call ptr @mlf_force(ptr %v58)
  %v60 = ptrtoint ptr %v59 to i64
  %v61 = ptrtoint ptr inttoptr (i64 13 to ptr) to i64
  %v62 = and i64 %v60, %v61
  %v63 = and i64 %v62, 1
  %v64 = icmp ne i64 %v63, 0
  br i1 %v64, label %yes.65, label %no.66
yes.65:
  %v68 = icmp slt i64 %v60, %v61
  %v69 = select i1 %v68, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.67
no.66:
  %v70 = call ptr @mlf_lt_int(ptr %v59, ptr inttoptr (i64 13 to ptr))
  br label %join.67
join.67:
  %v71 = phi ptr [ %v69, %yes.65 ], [ %v70, %no.66 ]
  %v72 = icmp eq ptr %v71, inttoptr (i64 6 to ptr)
  br i1 %v72, label %yes.73, label %no.74
yes.73:
  br label %join.75
no.74:
  br label %join.75
join.75:
  %v76 = phi ptr [ inttoptr (i64 13 to ptr), %yes.73 ], [ %v59, %no.74 ]
  ret ptr %v76
}

define private ptr @mlf.code.83(ptr %env, ptr %arg) {
entry:
  %v84 = getelementptr i8, ptr %env, i64 24
  %v85 = load ptr, ptr %v84, align 8, !tbaa !3
  %v86 = getelementptr i8, ptr %env, i64 32
  %v87 = load ptr, ptr %v86, align 8, !tbaa !3
  %v88 = getelementptr i8, ptr %env, i64 40
  %v89 = load ptr, ptr %v88, align 8, !tbaa !3
  %v90 = call ptr @mlf_force(ptr %v85)
  %v92 = call ptr @mlf_string(ptr @mlf.bytes.91, i64 10)
  %v93 = call ptr @mlf_force(ptr %v87)
  %v94 = call ptr @mlf_prim1(i64 7, ptr %v93)
  %v96 = call ptr @mlf_string(ptr @mlf.bytes.95, i64 9)
  %v97 = call ptr @mlf_force(ptr %v89)
  %v98 = call ptr @mlf_prim1(i64 7, ptr %v97)
  %v99 = call ptr @mlf_prim2(i64 6, ptr %v96, ptr %v98)
  %v100 = call ptr @mlf_prim2(i64 6, ptr %v94, ptr %v99)
  %v101 = call ptr @mlf_prim2(i64 6, ptr %v92, ptr %v100)
  %v102 = call ptr @mlf_prim2(i64 6, ptr %v90, ptr %v101)
  ret ptr %v102
}

define private ptr @mlf.worker.11(ptr %a0, ptr %a1, ptr %a2) {
entry:
  %v103 = call ptr @mlf_env_new(i64 3)
  %v104 = getelementptr i8, ptr %v103, i64 24
  store ptr %a0, ptr %v104, align 8, !tbaa !3
  %v105 = getelementptr i8, ptr %v103, i64 32
  store ptr %a1, ptr %v105, align 8, !tbaa !3
  %v106 = getelementptr i8, ptr %v103, i64 40
  store ptr %a2, ptr %v106, align 8, !tbaa !3
  %v107 = call ptr @mlf_thunk(ptr @mlf.code.83, ptr %v103)
  %v108 = call ptr @mlf_prim1(i64 3, ptr %v107)
  ret ptr %v108
}

define private ptr @mlf.code.111(ptr %env, ptr %arg) {
entry:
  %v112 = getelementptr i8, ptr %env, i64 24
  %v113 = load ptr, ptr %v112, align 8, !tbaa !3
  %v114 = call ptr @mlf_force(ptr %v113)
  %v115 = ptrtoint ptr %v114 to i64
  %v116 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v117 = and i64 %v115, %v116
  %v118 = and i64 %v117, 1
  %v119 = icmp ne i64 %v118, 0
  br i1 %v119, label %yes.120, label %no.121
yes.120:
  %v123 = sub i64 %v116, 1
  %v124 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v115, i64 %v123)
  %v125 = extractvalue { i64, i1 } %v124, 0
  %v126 = extractvalue { i64, i1 } %v124, 1
  br i1 %v126, label %yes.127, label %no.128
yes.127:
  %v130 = call ptr @mlf_add_int(ptr %v114, ptr inttoptr (i64 3 to ptr))
  br label %join.129
no.128:
  %v131 = inttoptr i64 %v125 to ptr
  br label %join.129
join.129:
  %v132 = phi ptr [ %v130, %yes.127 ], [ %v131, %no.128 ]
  br label %join.122
no.121:
  %v133 = call ptr @mlf_add_int(ptr %v114, ptr inttoptr (i64 3 to ptr))
  br label %join.122
join.122:
  %v134 = phi ptr [ %v132, %join.129 ], [ %v133, %no.121 ]
  ret ptr %v134
}

define private ptr @mlf.worker.7(ptr %a0) {
entry:
  %v141 = ptrtoint ptr %a0 to i64
  %v142 = and i64 %v141, 7
  %v143 = icmp eq i64 %v142, 4
  br i1 %v143, label %yes.144, label %no.145
yes.144:
  %v147 = lshr i64 %v141, 3
  br label %join.146
no.145:
  %v148 = getelementptr i8, ptr %a0, i64 24
  %v149 = load i64, ptr %v148, align 8, !tbaa !3
  br label %join.146
join.146:
  %v150 = phi i64 [ %v147, %yes.144 ], [ %v149, %no.145 ]
  switch i64 %v150, label %case.missing.153 [
    i64 1, label %case.151
    i64 2, label %case.152
  ]
case.151:
  br label %case.join.154
case.152:
  %v155 = getelementptr i8, ptr %a0, i64 32
  %v156 = load ptr, ptr %v155, align 8, !tbaa !3
  %v157 = getelementptr i8, ptr %a0, i64 40
  %v158 = load ptr, ptr %v157, align 8, !tbaa !3
  %v159 = call ptr @mlf.worker.7(ptr %v156)
  %v160 = call ptr @mlf.worker.7(ptr %v158)
  %v161 = ptrtoint ptr %v159 to i64
  %v162 = ptrtoint ptr %v160 to i64
  %v163 = and i64 %v161, %v162
  %v164 = and i64 %v163, 1
  %v165 = icmp ne i64 %v164, 0
  br i1 %v165, label %yes.166, label %no.167
yes.166:
  %v169 = sub i64 %v162, 1
  %v170 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v161, i64 %v169)
  %v171 = extractvalue { i64, i1 } %v170, 0
  %v172 = extractvalue { i64, i1 } %v170, 1
  br i1 %v172, label %yes.173, label %no.174
yes.173:
  %v176 = call ptr @mlf_add_int(ptr %v159, ptr %v160)
  br label %join.175
no.174:
  %v177 = inttoptr i64 %v171 to ptr
  br label %join.175
join.175:
  %v178 = phi ptr [ %v176, %yes.173 ], [ %v177, %no.174 ]
  br label %join.168
no.167:
  %v179 = call ptr @mlf_add_int(ptr %v159, ptr %v160)
  br label %join.168
join.168:
  %v180 = phi ptr [ %v178, %join.175 ], [ %v179, %no.167 ]
  %v181 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v182 = ptrtoint ptr %v180 to i64
  %v183 = and i64 %v181, %v182
  %v184 = and i64 %v183, 1
  %v185 = icmp ne i64 %v184, 0
  br i1 %v185, label %yes.186, label %no.187
yes.186:
  %v189 = sub i64 %v182, 1
  %v190 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v181, i64 %v189)
  %v191 = extractvalue { i64, i1 } %v190, 0
  %v192 = extractvalue { i64, i1 } %v190, 1
  br i1 %v192, label %yes.193, label %no.194
yes.193:
  %v196 = call ptr @mlf_add_int(ptr inttoptr (i64 3 to ptr), ptr %v180)
  br label %join.195
no.194:
  %v197 = inttoptr i64 %v191 to ptr
  br label %join.195
join.195:
  %v198 = phi ptr [ %v196, %yes.193 ], [ %v197, %no.194 ]
  br label %join.188
no.187:
  %v199 = call ptr @mlf_add_int(ptr inttoptr (i64 3 to ptr), ptr %v180)
  br label %join.188
join.188:
  %v200 = phi ptr [ %v198, %join.195 ], [ %v199, %no.187 ]
  br label %case.join.154
case.missing.153:
  call void @mlf_match_failure()
  unreachable
case.join.154:
  %v201 = phi ptr [ inttoptr (i64 1 to ptr), %case.151 ], [ %v200, %join.188 ]
  ret ptr %v201
}

define private ptr @mlf.worker.3(ptr %a0) {
entry:
  %v202 = ptrtoint ptr %a0 to i64
  %v203 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v204 = and i64 %v202, %v203
  %v205 = and i64 %v204, 1
  %v206 = icmp ne i64 %v205, 0
  br i1 %v206, label %yes.207, label %no.208
yes.207:
  %v210 = icmp eq i64 %v202, %v203
  %v211 = select i1 %v210, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.209
no.208:
  %v212 = call ptr @mlf_eq_int(ptr %a0, ptr inttoptr (i64 1 to ptr))
  br label %join.209
join.209:
  %v213 = phi ptr [ %v211, %yes.207 ], [ %v212, %no.208 ]
  %v214 = icmp eq ptr %v213, inttoptr (i64 6 to ptr)
  br i1 %v214, label %yes.215, label %no.216
yes.215:
  %v218 = call ptr @mlf_constructor2(i64 2, ptr inttoptr (i64 12 to ptr), ptr inttoptr (i64 12 to ptr))
  br label %join.217
no.216:
  %v219 = ptrtoint ptr %a0 to i64
  %v220 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v221 = and i64 %v219, %v220
  %v222 = and i64 %v221, 1
  %v223 = icmp ne i64 %v222, 0
  br i1 %v223, label %yes.224, label %no.225
yes.224:
  %v227 = sub i64 %v220, 1
  %v228 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v219, i64 %v227)
  %v229 = extractvalue { i64, i1 } %v228, 0
  %v230 = extractvalue { i64, i1 } %v228, 1
  br i1 %v230, label %yes.231, label %no.232
yes.231:
  %v234 = call ptr @mlf_sub_int(ptr %a0, ptr inttoptr (i64 3 to ptr))
  br label %join.233
no.232:
  %v235 = inttoptr i64 %v229 to ptr
  br label %join.233
join.233:
  %v236 = phi ptr [ %v234, %yes.231 ], [ %v235, %no.232 ]
  br label %join.226
no.225:
  %v237 = call ptr @mlf_sub_int(ptr %a0, ptr inttoptr (i64 3 to ptr))
  br label %join.226
join.226:
  %v238 = phi ptr [ %v236, %join.233 ], [ %v237, %no.225 ]
  %v239 = call ptr @mlf.worker.3(ptr %v238)
  %v240 = ptrtoint ptr %v239 to i64
  %v241 = and i64 %v240, 7
  %v242 = icmp eq i64 %v241, 4
  br i1 %v242, label %yes.243, label %no.244
yes.243:
  %v246 = lshr i64 %v240, 3
  br label %join.245
no.244:
  %v247 = getelementptr i8, ptr %v239, i64 24
  %v248 = load i64, ptr %v247, align 8, !tbaa !3
  br label %join.245
join.245:
  %v249 = phi i64 [ %v246, %yes.243 ], [ %v248, %no.244 ]
  switch i64 %v249, label %case.missing.252 [
    i64 1, label %case.250
    i64 2, label %case.251
  ]
case.250:
  br label %case.join.253
case.251:
  %v254 = ptrtoint ptr %a0 to i64
  %v255 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v256 = and i64 %v254, %v255
  %v257 = and i64 %v256, 1
  %v258 = icmp ne i64 %v257, 0
  br i1 %v258, label %yes.259, label %no.260
yes.259:
  %v262 = sub i64 %v255, 1
  %v263 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v254, i64 %v262)
  %v264 = extractvalue { i64, i1 } %v263, 0
  %v265 = extractvalue { i64, i1 } %v263, 1
  br i1 %v265, label %yes.266, label %no.267
yes.266:
  %v269 = call ptr @mlf_sub_int(ptr %a0, ptr inttoptr (i64 3 to ptr))
  br label %join.268
no.267:
  %v270 = inttoptr i64 %v264 to ptr
  br label %join.268
join.268:
  %v271 = phi ptr [ %v269, %yes.266 ], [ %v270, %no.267 ]
  br label %join.261
no.260:
  %v272 = call ptr @mlf_sub_int(ptr %a0, ptr inttoptr (i64 3 to ptr))
  br label %join.261
join.261:
  %v273 = phi ptr [ %v271, %join.268 ], [ %v272, %no.260 ]
  %v274 = call ptr @mlf.worker.3(ptr %v273)
  %v275 = ptrtoint ptr %v274 to i64
  %v276 = and i64 %v275, 7
  %v277 = icmp eq i64 %v276, 4
  br i1 %v277, label %yes.278, label %no.279
yes.278:
  %v281 = lshr i64 %v275, 3
  br label %join.280
no.279:
  %v282 = getelementptr i8, ptr %v274, i64 24
  %v283 = load i64, ptr %v282, align 8, !tbaa !3
  br label %join.280
join.280:
  %v284 = phi i64 [ %v281, %yes.278 ], [ %v283, %no.279 ]
  switch i64 %v284, label %case.missing.287 [
    i64 1, label %case.285
    i64 2, label %case.286
  ]
case.285:
  br label %case.join.288
case.286:
  %v289 = call ptr @mlf_constructor2(i64 2, ptr %v239, ptr %v274)
  br label %case.join.288
case.missing.287:
  call void @mlf_match_failure()
  unreachable
case.join.288:
  %v290 = phi ptr [ inttoptr (i64 12 to ptr), %case.285 ], [ %v289, %case.286 ]
  br label %case.join.253
case.missing.252:
  call void @mlf_match_failure()
  unreachable
case.join.253:
  %v291 = phi ptr [ inttoptr (i64 12 to ptr), %case.250 ], [ %v290, %case.join.288 ]
  br label %join.217
join.217:
  %v292 = phi ptr [ %v218, %yes.215 ], [ %v291, %case.join.253 ]
  ret ptr %v292
}

define private ptr @mlf.code.138(ptr %env, ptr %arg) {
entry:
  %v139 = getelementptr i8, ptr %env, i64 24
  %v140 = load ptr, ptr %v139, align 8, !tbaa !3
  %v293 = call ptr @mlf_force(ptr %v140)
  %v294 = ptrtoint ptr %v293 to i64
  %v295 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v296 = and i64 %v294, %v295
  %v297 = and i64 %v296, 1
  %v298 = icmp ne i64 %v297, 0
  br i1 %v298, label %yes.299, label %no.300
yes.299:
  %v302 = sub i64 %v295, 1
  %v303 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v294, i64 %v302)
  %v304 = extractvalue { i64, i1 } %v303, 0
  %v305 = extractvalue { i64, i1 } %v303, 1
  br i1 %v305, label %yes.306, label %no.307
yes.306:
  %v309 = call ptr @mlf_add_int(ptr %v293, ptr inttoptr (i64 3 to ptr))
  br label %join.308
no.307:
  %v310 = inttoptr i64 %v304 to ptr
  br label %join.308
join.308:
  %v311 = phi ptr [ %v309, %yes.306 ], [ %v310, %no.307 ]
  br label %join.301
no.300:
  %v312 = call ptr @mlf_add_int(ptr %v293, ptr inttoptr (i64 3 to ptr))
  br label %join.301
join.301:
  %v313 = phi ptr [ %v311, %join.308 ], [ %v312, %no.300 ]
  %v314 = call ptr @mlf.worker.3(ptr %v313)
  %v315 = call ptr @mlf.worker.7(ptr %v314)
  ret ptr %v315
}

define private ptr @mlf.code.80(ptr %env, ptr %arg) {
entry:
  %v81 = getelementptr i8, ptr %env, i64 24
  %v82 = load ptr, ptr %v81, align 8, !tbaa !3
  %v110 = call ptr @mlf_string(ptr @mlf.bytes.109, i64 12)
  %v135 = call ptr @mlf_env_new(i64 1)
  %v136 = getelementptr i8, ptr %v135, i64 24
  store ptr %v82, ptr %v136, align 8, !tbaa !3
  %v137 = call ptr @mlf_thunk(ptr @mlf.code.111, ptr %v135)
  %v316 = call ptr @mlf_env_new(i64 1)
  %v317 = getelementptr i8, ptr %v316, i64 24
  store ptr %v82, ptr %v317, align 8, !tbaa !3
  %v318 = call ptr @mlf_thunk(ptr @mlf.code.138, ptr %v316)
  %v319 = call ptr @mlf.worker.11(ptr %v110, ptr %v137, ptr %v318)
  ret ptr %v319
}

define private ptr @mlf.worker.0(ptr %a0) {
entry:
  %v370 = ptrtoint ptr %a0 to i64
  %v371 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v372 = and i64 %v370, %v371
  %v373 = and i64 %v372, 1
  %v374 = icmp ne i64 %v373, 0
  br i1 %v374, label %yes.375, label %no.376
yes.375:
  %v378 = icmp eq i64 %v370, %v371
  %v379 = select i1 %v378, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.377
no.376:
  %v380 = call ptr @mlf_eq_int(ptr %a0, ptr inttoptr (i64 1 to ptr))
  br label %join.377
join.377:
  %v381 = phi ptr [ %v379, %yes.375 ], [ %v380, %no.376 ]
  %v382 = icmp eq ptr %v381, inttoptr (i64 6 to ptr)
  br i1 %v382, label %yes.383, label %no.384
yes.383:
  br label %join.385
no.384:
  %v386 = ptrtoint ptr %a0 to i64
  %v387 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v388 = and i64 %v386, %v387
  %v389 = and i64 %v388, 1
  %v390 = icmp ne i64 %v389, 0
  br i1 %v390, label %yes.391, label %no.392
yes.391:
  %v394 = sub i64 %v387, 1
  %v395 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v386, i64 %v394)
  %v396 = extractvalue { i64, i1 } %v395, 0
  %v397 = extractvalue { i64, i1 } %v395, 1
  br i1 %v397, label %yes.398, label %no.399
yes.398:
  %v401 = call ptr @mlf_sub_int(ptr %a0, ptr inttoptr (i64 3 to ptr))
  br label %join.400
no.399:
  %v402 = inttoptr i64 %v396 to ptr
  br label %join.400
join.400:
  %v403 = phi ptr [ %v401, %yes.398 ], [ %v402, %no.399 ]
  br label %join.393
no.392:
  %v404 = call ptr @mlf_sub_int(ptr %a0, ptr inttoptr (i64 3 to ptr))
  br label %join.393
join.393:
  %v405 = phi ptr [ %v403, %join.400 ], [ %v404, %no.392 ]
  %v406 = call ptr @mlf.worker.0(ptr %v405)
  %v407 = ptrtoint ptr %v406 to i64
  %v408 = ptrtoint ptr %v406 to i64
  %v409 = and i64 %v407, %v408
  %v410 = and i64 %v409, 1
  %v411 = icmp ne i64 %v410, 0
  br i1 %v411, label %yes.412, label %no.413
yes.412:
  %v415 = sub i64 %v408, 1
  %v416 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v407, i64 %v415)
  %v417 = extractvalue { i64, i1 } %v416, 0
  %v418 = extractvalue { i64, i1 } %v416, 1
  br i1 %v418, label %yes.419, label %no.420
yes.419:
  %v422 = call ptr @mlf_add_int(ptr %v406, ptr %v406)
  br label %join.421
no.420:
  %v423 = inttoptr i64 %v417 to ptr
  br label %join.421
join.421:
  %v424 = phi ptr [ %v422, %yes.419 ], [ %v423, %no.420 ]
  br label %join.414
no.413:
  %v425 = call ptr @mlf_add_int(ptr %v406, ptr %v406)
  br label %join.414
join.414:
  %v426 = phi ptr [ %v424, %join.421 ], [ %v425, %no.413 ]
  br label %join.385
join.385:
  %v427 = phi ptr [ inttoptr (i64 3 to ptr), %yes.383 ], [ %v426, %join.414 ]
  ret ptr %v427
}

define private ptr @mlf.code.365(ptr %env, ptr %arg) {
entry:
  %v366 = getelementptr i8, ptr %env, i64 24
  %v367 = load ptr, ptr %v366, align 8, !tbaa !3
  %v368 = getelementptr i8, ptr %env, i64 32
  %v369 = load ptr, ptr %v368, align 8, !tbaa !3
  %v428 = call ptr @mlf_force(ptr %v367)
  %v429 = call ptr @mlf_force(ptr %v369)
  %v430 = ptrtoint ptr %v428 to i64
  %v431 = ptrtoint ptr %v429 to i64
  %v432 = and i64 %v430, %v431
  %v433 = and i64 %v432, 1
  %v434 = icmp ne i64 %v433, 0
  br i1 %v434, label %yes.435, label %no.436
yes.435:
  %v438 = sub i64 %v431, 1
  %v439 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v430, i64 %v438)
  %v440 = extractvalue { i64, i1 } %v439, 0
  %v441 = extractvalue { i64, i1 } %v439, 1
  br i1 %v441, label %yes.442, label %no.443
yes.442:
  %v445 = call ptr @mlf_sub_int(ptr %v428, ptr %v429)
  br label %join.444
no.443:
  %v446 = inttoptr i64 %v440 to ptr
  br label %join.444
join.444:
  %v447 = phi ptr [ %v445, %yes.442 ], [ %v446, %no.443 ]
  br label %join.437
no.436:
  %v448 = call ptr @mlf_sub_int(ptr %v428, ptr %v429)
  br label %join.437
join.437:
  %v449 = phi ptr [ %v447, %join.444 ], [ %v448, %no.436 ]
  %v450 = ptrtoint ptr %v449 to i64
  %v451 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v452 = and i64 %v450, %v451
  %v453 = and i64 %v452, 1
  %v454 = icmp ne i64 %v453, 0
  br i1 %v454, label %yes.455, label %no.456
yes.455:
  %v458 = sub i64 %v451, 1
  %v459 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v450, i64 %v458)
  %v460 = extractvalue { i64, i1 } %v459, 0
  %v461 = extractvalue { i64, i1 } %v459, 1
  br i1 %v461, label %yes.462, label %no.463
yes.462:
  %v465 = call ptr @mlf_add_int(ptr %v449, ptr inttoptr (i64 9 to ptr))
  br label %join.464
no.463:
  %v466 = inttoptr i64 %v460 to ptr
  br label %join.464
join.464:
  %v467 = phi ptr [ %v465, %yes.462 ], [ %v466, %no.463 ]
  br label %join.457
no.456:
  %v468 = call ptr @mlf_add_int(ptr %v449, ptr inttoptr (i64 9 to ptr))
  br label %join.457
join.457:
  %v469 = phi ptr [ %v467, %join.464 ], [ %v468, %no.456 ]
  %v470 = call ptr @mlf.worker.0(ptr %v469)
  ret ptr %v470
}

define private ptr @mlf.code.537(ptr %env, ptr %arg) {
entry:
  %v538 = getelementptr i8, ptr %env, i64 24
  %v539 = load ptr, ptr %v538, align 8, !tbaa !3
  %v540 = call ptr @mlf_prim1(i64 0, ptr %v539)
  ret ptr %v540
}

define private ptr @mlf.code.544(ptr %env, ptr %arg) {
entry:
  %v545 = getelementptr i8, ptr %env, i64 24
  %v546 = load ptr, ptr %v545, align 8, !tbaa !3
  %v547 = getelementptr i8, ptr %env, i64 32
  %v548 = load ptr, ptr %v547, align 8, !tbaa !3
  %v549 = call ptr @mlf_force(ptr %v548)
  %v550 = ptrtoint ptr %v549 to i64
  %v551 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v552 = and i64 %v550, %v551
  %v553 = and i64 %v552, 1
  %v554 = icmp ne i64 %v553, 0
  br i1 %v554, label %yes.555, label %no.556
yes.555:
  %v558 = sub i64 %v551, 1
  %v559 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v550, i64 %v558)
  %v560 = extractvalue { i64, i1 } %v559, 0
  %v561 = extractvalue { i64, i1 } %v559, 1
  br i1 %v561, label %yes.562, label %no.563
yes.562:
  %v565 = call ptr @mlf_sub_int(ptr %v549, ptr inttoptr (i64 3 to ptr))
  br label %join.564
no.563:
  %v566 = inttoptr i64 %v560 to ptr
  br label %join.564
join.564:
  %v567 = phi ptr [ %v565, %yes.562 ], [ %v566, %no.563 ]
  br label %join.557
no.556:
  %v568 = call ptr @mlf_sub_int(ptr %v549, ptr inttoptr (i64 3 to ptr))
  br label %join.557
join.557:
  %v569 = phi ptr [ %v567, %join.564 ], [ %v568, %no.556 ]
  %v570 = call ptr @mlf.worker.15(ptr %v546, ptr %v569, ptr %arg)
  ret ptr %v570
}

define private ptr @mlf.worker.15(ptr %a0, ptr %a1, ptr %a2) {
entry:
  %v480 = ptrtoint ptr %a1 to i64
  %v481 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v482 = and i64 %v480, %v481
  %v483 = and i64 %v482, 1
  %v484 = icmp ne i64 %v483, 0
  br i1 %v484, label %yes.485, label %no.486
yes.485:
  %v488 = icmp eq i64 %v480, %v481
  %v489 = select i1 %v488, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.487
no.486:
  %v490 = call ptr @mlf_eq_int(ptr %a1, ptr inttoptr (i64 1 to ptr))
  br label %join.487
join.487:
  %v491 = phi ptr [ %v489, %yes.485 ], [ %v490, %no.486 ]
  %v492 = icmp eq ptr %v491, inttoptr (i64 6 to ptr)
  br i1 %v492, label %yes.493, label %no.494
yes.493:
  %v496 = call ptr @mlf_prim1(i64 0, ptr %a2)
  br label %join.495
no.494:
  %v497 = call ptr @mlf_force(ptr %a2)
  %v498 = call ptr @mlf_force(ptr %a0)
  %v499 = call ptr @mlf.worker.3(ptr %v498)
  %v500 = call ptr @mlf.worker.7(ptr %v499)
  %v501 = ptrtoint ptr %v497 to i64
  %v502 = ptrtoint ptr %v500 to i64
  %v503 = and i64 %v501, %v502
  %v504 = and i64 %v503, 1
  %v505 = icmp ne i64 %v504, 0
  br i1 %v505, label %yes.506, label %no.507
yes.506:
  %v509 = sub i64 %v502, 1
  %v510 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v501, i64 %v509)
  %v511 = extractvalue { i64, i1 } %v510, 0
  %v512 = extractvalue { i64, i1 } %v510, 1
  br i1 %v512, label %yes.513, label %no.514
yes.513:
  %v516 = call ptr @mlf_add_int(ptr %v497, ptr %v500)
  br label %join.515
no.514:
  %v517 = inttoptr i64 %v511 to ptr
  br label %join.515
join.515:
  %v518 = phi ptr [ %v516, %yes.513 ], [ %v517, %no.514 ]
  br label %join.508
no.507:
  %v519 = call ptr @mlf_add_int(ptr %v497, ptr %v500)
  br label %join.508
join.508:
  %v520 = phi ptr [ %v518, %join.515 ], [ %v519, %no.507 ]
  %v521 = ptrtoint ptr %v520 to i64
  %v522 = ptrtoint ptr %v520 to i64
  %v523 = and i64 %v521, %v522
  %v524 = and i64 %v523, 1
  %v525 = icmp ne i64 %v524, 0
  br i1 %v525, label %yes.526, label %no.527
yes.526:
  %v529 = icmp eq i64 %v521, %v522
  %v530 = select i1 %v529, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.528
no.527:
  %v531 = call ptr @mlf_eq_int(ptr %v520, ptr %v520)
  br label %join.528
join.528:
  %v532 = phi ptr [ %v530, %yes.526 ], [ %v531, %no.527 ]
  %v533 = icmp eq ptr %v532, inttoptr (i64 6 to ptr)
  br i1 %v533, label %yes.534, label %no.535
yes.534:
  %v541 = call ptr @mlf_env_new(i64 1)
  %v542 = getelementptr i8, ptr %v541, i64 24
  store ptr %v520, ptr %v542, align 8, !tbaa !3
  %v543 = call ptr @mlf_thunk(ptr @mlf.code.537, ptr %v541)
  %v571 = call ptr @mlf_env_new(i64 2)
  %v572 = getelementptr i8, ptr %v571, i64 24
  store ptr %v498, ptr %v572, align 8, !tbaa !3
  %v573 = getelementptr i8, ptr %v571, i64 32
  store ptr %a1, ptr %v573, align 8, !tbaa !3
  %v574 = call ptr @mlf_closure(ptr @mlf.code.544, ptr %v571)
  %v575 = call ptr @mlf_prim2(i64 1, ptr %v543, ptr %v574)
  br label %join.536
no.535:
  %v576 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 1 to ptr))
  br label %join.536
join.536:
  %v577 = phi ptr [ %v575, %yes.534 ], [ %v576, %no.535 ]
  br label %join.495
join.495:
  %v578 = phi ptr [ %v496, %yes.493 ], [ %v577, %join.536 ]
  ret ptr %v578
}

define private ptr @mlf.code.475(ptr %env, ptr %arg) {
entry:
  %v476 = getelementptr i8, ptr %env, i64 24
  %v477 = load ptr, ptr %v476, align 8, !tbaa !3
  %v478 = getelementptr i8, ptr %env, i64 32
  %v479 = load ptr, ptr %v478, align 8, !tbaa !3
  %v579 = call ptr @mlf_force(ptr %v479)
  %v580 = call ptr @mlf.worker.15(ptr %v477, ptr %v579, ptr inttoptr (i64 1 to ptr))
  ret ptr %v580
}

define private ptr @mlf.code.599(ptr %env, ptr %arg) {
entry:
  %v600 = getelementptr i8, ptr %env, i64 24
  %v601 = load ptr, ptr %v600, align 8, !tbaa !3
  %v602 = call ptr @mlf_force(ptr %v601)
  %v603 = call ptr @mlf_prim1(i64 7, ptr %v602)
  %v605 = call ptr @mlf_string(ptr @mlf.bytes.604, i64 7)
  %v606 = call ptr @mlf_prim2(i64 6, ptr %v603, ptr %v605)
  ret ptr %v606
}

define private ptr @mlf.code.592(ptr %env, ptr %arg) {
entry:
  %v593 = getelementptr i8, ptr %env, i64 24
  %v594 = load ptr, ptr %v593, align 8, !tbaa !3
  %v595 = getelementptr i8, ptr %env, i64 32
  %v596 = load ptr, ptr %v595, align 8, !tbaa !3
  %v597 = getelementptr i8, ptr %env, i64 40
  %v598 = load ptr, ptr %v597, align 8, !tbaa !3
  %v607 = call ptr @mlf_env_new(i64 1)
  %v608 = getelementptr i8, ptr %v607, i64 24
  store ptr %v596, ptr %v608, align 8, !tbaa !3
  %v609 = call ptr @mlf_thunk(ptr @mlf.code.599, ptr %v607)
  %v610 = call ptr @mlf.worker.11(ptr %v609, ptr %v594, ptr %v598)
  ret ptr %v610
}

define private ptr @mlf.code.616(ptr %env, ptr %arg) {
entry:
  %v617 = getelementptr i8, ptr %env, i64 24
  %v618 = load ptr, ptr %v617, align 8, !tbaa !3
  %v619 = getelementptr i8, ptr %env, i64 32
  %v620 = load ptr, ptr %v619, align 8, !tbaa !3
  %v621 = call ptr @mlf_force(ptr %v618)
  %v622 = call ptr @mlf_force(ptr %v620)
  %v623 = ptrtoint ptr %v622 to i64
  %v624 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v625 = and i64 %v623, %v624
  %v626 = and i64 %v625, 1
  %v627 = icmp ne i64 %v626, 0
  br i1 %v627, label %yes.628, label %no.629
yes.628:
  %v631 = sub i64 %v624, 1
  %v632 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v623, i64 %v631)
  %v633 = extractvalue { i64, i1 } %v632, 0
  %v634 = extractvalue { i64, i1 } %v632, 1
  br i1 %v634, label %yes.635, label %no.636
yes.635:
  %v638 = call ptr @mlf_add_int(ptr %v622, ptr inttoptr (i64 5 to ptr))
  br label %join.637
no.636:
  %v639 = inttoptr i64 %v633 to ptr
  br label %join.637
join.637:
  %v640 = phi ptr [ %v638, %yes.635 ], [ %v639, %no.636 ]
  br label %join.630
no.629:
  %v641 = call ptr @mlf_add_int(ptr %v622, ptr inttoptr (i64 5 to ptr))
  br label %join.630
join.630:
  %v642 = phi ptr [ %v640, %join.637 ], [ %v641, %no.629 ]
  %v643 = call ptr @mlf.worker.21(ptr %v621, ptr %v642)
  ret ptr %v643
}

define private ptr @mlf.code.585(ptr %env, ptr %arg) {
entry:
  %v586 = getelementptr i8, ptr %env, i64 24
  %v587 = load ptr, ptr %v586, align 8, !tbaa !3
  %v588 = getelementptr i8, ptr %env, i64 32
  %v589 = load ptr, ptr %v588, align 8, !tbaa !3
  %v590 = getelementptr i8, ptr %env, i64 40
  %v591 = load ptr, ptr %v590, align 8, !tbaa !3
  %v611 = call ptr @mlf_env_new(i64 3)
  %v612 = getelementptr i8, ptr %v611, i64 24
  store ptr %v589, ptr %v612, align 8, !tbaa !3
  %v613 = getelementptr i8, ptr %v611, i64 32
  store ptr %v591, ptr %v613, align 8, !tbaa !3
  %v614 = getelementptr i8, ptr %v611, i64 40
  store ptr %arg, ptr %v614, align 8, !tbaa !3
  %v615 = call ptr @mlf_thunk(ptr @mlf.code.592, ptr %v611)
  %v644 = call ptr @mlf_env_new(i64 2)
  %v645 = getelementptr i8, ptr %v644, i64 24
  store ptr %v587, ptr %v645, align 8, !tbaa !3
  %v646 = getelementptr i8, ptr %v644, i64 32
  store ptr %v589, ptr %v646, align 8, !tbaa !3
  %v647 = call ptr @mlf_closure(ptr @mlf.code.616, ptr %v644)
  %v648 = call ptr @mlf_prim2(i64 1, ptr %v615, ptr %v647)
  ret ptr %v648
}

define private ptr @mlf.worker.21(ptr %a0, ptr %a1) {
entry:
  %v348 = ptrtoint ptr %a0 to i64
  %v349 = ptrtoint ptr %a1 to i64
  %v350 = and i64 %v348, %v349
  %v351 = and i64 %v350, 1
  %v352 = icmp ne i64 %v351, 0
  br i1 %v352, label %yes.353, label %no.354
yes.353:
  %v356 = icmp slt i64 %v348, %v349
  %v357 = select i1 %v356, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.355
no.354:
  %v358 = call ptr @mlf_lt_int(ptr %a0, ptr %a1)
  br label %join.355
join.355:
  %v359 = phi ptr [ %v357, %yes.353 ], [ %v358, %no.354 ]
  %v360 = icmp eq ptr %v359, inttoptr (i64 6 to ptr)
  br i1 %v360, label %yes.361, label %no.362
yes.361:
  %v364 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.363
no.362:
  %v471 = call ptr @mlf_env_new(i64 2)
  %v472 = getelementptr i8, ptr %v471, i64 24
  store ptr %a0, ptr %v472, align 8, !tbaa !3
  %v473 = getelementptr i8, ptr %v471, i64 32
  store ptr %a1, ptr %v473, align 8, !tbaa !3
  %v474 = call ptr @mlf_thunk(ptr @mlf.code.365, ptr %v471)
  %v581 = call ptr @mlf_env_new(i64 2)
  %v582 = getelementptr i8, ptr %v581, i64 24
  store ptr %a1, ptr %v582, align 8, !tbaa !3
  %v583 = getelementptr i8, ptr %v581, i64 32
  store ptr %v474, ptr %v583, align 8, !tbaa !3
  %v584 = call ptr @mlf_thunk(ptr @mlf.code.475, ptr %v581)
  %v649 = call ptr @mlf_env_new(i64 3)
  %v650 = getelementptr i8, ptr %v649, i64 24
  store ptr %a0, ptr %v650, align 8, !tbaa !3
  %v651 = getelementptr i8, ptr %v649, i64 32
  store ptr %a1, ptr %v651, align 8, !tbaa !3
  %v652 = getelementptr i8, ptr %v649, i64 40
  store ptr %v474, ptr %v652, align 8, !tbaa !3
  %v653 = call ptr @mlf_closure(ptr @mlf.code.585, ptr %v649)
  %v654 = call ptr @mlf_prim2(i64 1, ptr %v584, ptr %v653)
  br label %join.363
join.363:
  %v655 = phi ptr [ %v364, %yes.361 ], [ %v654, %no.362 ]
  ret ptr %v655
}

define private ptr @mlf.code.345(ptr %env, ptr %arg) {
entry:
  %v346 = getelementptr i8, ptr %env, i64 24
  %v347 = load ptr, ptr %v346, align 8, !tbaa !3
  %v656 = call ptr @mlf_force(ptr %v347)
  %v657 = call ptr @mlf.worker.21(ptr %v656, ptr inttoptr (i64 9 to ptr))
  ret ptr %v657
}

define private ptr @mlf.code.668(ptr %env, ptr %arg) {
entry:
  %v669 = getelementptr i8, ptr %env, i64 24
  %v670 = load ptr, ptr %v669, align 8, !tbaa !3
  %v671 = call ptr @mlf_force(ptr %v670)
  %v672 = call ptr @mlf.worker.7(ptr %v671)
  ret ptr %v672
}

define private ptr @mlf.code.661(ptr %env, ptr %arg) {
entry:
  %v662 = getelementptr i8, ptr %env, i64 24
  %v663 = load ptr, ptr %v662, align 8, !tbaa !3
  %v664 = getelementptr i8, ptr %env, i64 32
  %v665 = load ptr, ptr %v664, align 8, !tbaa !3
  %v667 = call ptr @mlf_string(ptr @mlf.bytes.666, i64 15)
  %v673 = call ptr @mlf_env_new(i64 1)
  %v674 = getelementptr i8, ptr %v673, i64 24
  store ptr %v665, ptr %v674, align 8, !tbaa !3
  %v675 = call ptr @mlf_thunk(ptr @mlf.code.668, ptr %v673)
  %v676 = call ptr @mlf.worker.11(ptr %v667, ptr %v663, ptr %v675)
  ret ptr %v676
}

define private ptr @mlf.code.323(ptr %env, ptr %arg) {
entry:
  %v324 = getelementptr i8, ptr %env, i64 24
  %v325 = load ptr, ptr %v324, align 8, !tbaa !3
  %v326 = call ptr @mlf_force(ptr %v325)
  %v327 = call ptr @mlf.worker.3(ptr %v326)
  %v328 = ptrtoint ptr %v327 to i64
  %v329 = and i64 %v328, 7
  %v330 = icmp eq i64 %v329, 4
  br i1 %v330, label %yes.331, label %no.332
yes.331:
  %v334 = lshr i64 %v328, 3
  br label %join.333
no.332:
  %v335 = getelementptr i8, ptr %v327, i64 24
  %v336 = load i64, ptr %v335, align 8, !tbaa !3
  br label %join.333
join.333:
  %v337 = phi i64 [ %v334, %yes.331 ], [ %v336, %no.332 ]
  switch i64 %v337, label %case.missing.340 [
    i64 1, label %case.338
    i64 2, label %case.339
  ]
case.338:
  %v343 = call ptr @mlf_string(ptr @mlf.bytes.342, i64 12)
  %v344 = call ptr @mlf_prim1(i64 3, ptr %v343)
  br label %case.join.341
case.339:
  %v658 = call ptr @mlf_env_new(i64 1)
  %v659 = getelementptr i8, ptr %v658, i64 24
  store ptr %v326, ptr %v659, align 8, !tbaa !3
  %v660 = call ptr @mlf_thunk(ptr @mlf.code.345, ptr %v658)
  %v677 = call ptr @mlf_env_new(i64 2)
  %v678 = getelementptr i8, ptr %v677, i64 24
  store ptr %v326, ptr %v678, align 8, !tbaa !3
  %v679 = getelementptr i8, ptr %v677, i64 32
  store ptr %v327, ptr %v679, align 8, !tbaa !3
  %v680 = call ptr @mlf_closure(ptr @mlf.code.661, ptr %v677)
  %v681 = call ptr @mlf_prim2(i64 1, ptr %v660, ptr %v680)
  br label %case.join.341
case.missing.340:
  call void @mlf_match_failure()
  unreachable
case.join.341:
  %v682 = phi ptr [ %v344, %case.338 ], [ %v681, %case.339 ]
  ret ptr %v682
}

define private ptr @mlf.code.2(ptr %env, ptr %arg) {
entry:
  %v53 = call ptr @mlf_env_new(i64 1)
  %v54 = getelementptr i8, ptr %v53, i64 24
  store ptr %arg, ptr %v54, align 8, !tbaa !3
  %v55 = call ptr @mlf_thunk(ptr @mlf.code.3, ptr %v53)
  %v77 = call ptr @mlf_env_new(i64 1)
  %v78 = getelementptr i8, ptr %v77, i64 24
  store ptr %v55, ptr %v78, align 8, !tbaa !3
  %v79 = call ptr @mlf_thunk(ptr @mlf.code.56, ptr %v77)
  %v320 = call ptr @mlf_env_new(i64 1)
  %v321 = getelementptr i8, ptr %v320, i64 24
  store ptr %v79, ptr %v321, align 8, !tbaa !3
  %v322 = call ptr @mlf_thunk(ptr @mlf.code.80, ptr %v320)
  %v683 = call ptr @mlf_env_new(i64 1)
  %v684 = getelementptr i8, ptr %v683, i64 24
  store ptr %v79, ptr %v684, align 8, !tbaa !3
  %v685 = call ptr @mlf_closure(ptr @mlf.code.323, ptr %v683)
  %v686 = call ptr @mlf_prim2(i64 1, ptr %v322, ptr %v685)
  ret ptr %v686
}

define private ptr @mlf.code.0(ptr %env, ptr %arg) {
entry:
  %v1 = call ptr @mlf_primitive(i64 4)
  %v687 = call ptr @mlf_closure(ptr @mlf.code.2, ptr null)
  %v688 = call ptr @mlf_prim2(i64 1, ptr %v1, ptr %v687)
  ret ptr %v688
}

declare void @mlf_require_standard_abi()
define ptr @mlf_entry() {
  call void @mlf_require_standard_abi()
  %root = call ptr @mlf.code.0(ptr null, ptr null)
  ret ptr %root
}
define i32 @main(i32 %argc, ptr %argv) {
  call void @mlf_set_args(i32 %argc, ptr %argv)
  %root = call ptr @mlf_entry()
  %status = call i32 @mlf_run(ptr %root, i64 1)
  ret i32 %status
}
