; Generated from independently checked xMLF.
source_filename = "emlf"

declare ptr @mlf_thunk_new(ptr, i64)
declare ptr @mlf_execute_st_lazy(ptr)
declare ptr @mlf_st_new_array(ptr, ptr)
declare ptr @mlf_st_read_array(ptr, ptr)
declare ptr @mlf_st_write_array(ptr, ptr, ptr)
declare ptr @mlf_st_length_array(ptr)
declare void @mlf_set_args(i32, ptr)
declare ptr @mlf_env_new(i64)
declare void @mlf_env_set(ptr, i64, ptr)
declare ptr @mlf_env_get(ptr, i64)
declare ptr @mlf_thunk(ptr, ptr)
declare ptr @mlf_closure(ptr, ptr)
declare ptr @mlf_application(ptr, ptr)
declare ptr @mlf_hole()
declare void @mlf_fill(ptr, ptr)
declare ptr @mlf_integer(ptr)
declare ptr @mlf_string(ptr, i64)
declare ptr @mlf_double(double)
declare double @llvm.sqrt.f64(double)
declare double @mlf_int_to_double(ptr)
declare ptr @mlf_read_int_table(ptr, ptr)
declare ptr @mlf_write_int_table(ptr, ptr, ptr)
declare ptr @mlf_add_int_table(ptr, ptr, ptr)
declare void @mlf_roots_enter(ptr, i64, ptr)
declare void @mlf_roots_leave(ptr)
declare void @mlf_gc_check(i64, ptr)
declare ptr @mlf_get_byte_line()
declare ptr @mlf_new_array(i64, ptr, ptr)
declare ptr @mlf_bytes_from_string(ptr)
declare ptr @mlf_put_bytes(ptr, ptr, ptr)
declare ptr @mlf_new_int_table()
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare i8 @mlf_byte(ptr)
declare ptr @mlf_peek(ptr)
declare ptr @mlf_native_io(ptr, ptr)
declare void @mlf_bounds_failure() noreturn
declare ptr @mlf_primitive(i64)
declare ptr @mlf_prim1(i64, ptr)
declare ptr @mlf_prim2(i64, ptr, ptr)
declare i64 @mlf_truth(ptr)
declare ptr @mlf_prim3(i64, ptr, ptr, ptr)
declare ptr @mlf_force(ptr)
declare ptr @mlf_add_int(ptr, ptr)
declare ptr @mlf_sub_int(ptr, ptr)
declare ptr @mlf_eq_int(ptr, ptr)
declare ptr @mlf_lt_int(ptr, ptr)
declare ptr @mlf_constructor(i64, i64)
declare ptr @mlf_constructor1(i64, ptr)
declare ptr @mlf_constructor2(i64, ptr, ptr)
declare ptr @mlf_constructor_fields(i64, ptr)
declare ptr @mlf_constructor_new(i64, i64)
declare ptr @mlf_field(ptr, i64)
declare void @mlf_match_failure() noreturn
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare i32 @mlf_run(ptr, i64)

@mlf_constructor_pending = external global [33 x ptr]
declare ptr @mlf_constructor_allocate(i64, i64)
define private ptr @mlf.allocate.constructor(i64 %identity, i64 %count, i64 %size) alwaysinline {
entry:
  %small = icmp ule i64 %size, 256
  br i1 %small, label %batch, label %slow
batch:
  %index = lshr i64 %size, 3
  %slot = getelementptr [33 x ptr], ptr @mlf_constructor_pending, i64 0, i64 %index
  %value = load ptr, ptr %slot, align 8
  %empty = icmp eq ptr %value, null
  br i1 %empty, label %slow, label %ready
ready:
  %next = load ptr, ptr %value, align 8
  store ptr %next, ptr %slot, align 8
  store i64 0, ptr %value, align 8
  ret ptr %value
slow:
  %allocated = call ptr @mlf_constructor_allocate(i64 %identity, i64 %count)
  ret ptr %allocated
}
define private ptr @mlf.construct.1(i64 %identity, ptr %a) alwaysinline {
entry:
  %value = call ptr @mlf.allocate.constructor(i64 %identity, i64 1, i64 24)
  store i32 12, ptr %value, align 4
  %id = getelementptr i8, ptr %value, i64 8
  store i64 %identity, ptr %id, align 8
  %first = getelementptr i8, ptr %value, i64 16
  store ptr %a, ptr %first, align 8
  ret ptr %value
}
define private ptr @mlf.construct.2(i64 %identity, ptr %a, ptr %b) alwaysinline {
entry:
  %value = call ptr @mlf.allocate.constructor(i64 %identity, i64 2, i64 32)
  store i32 13, ptr %value, align 4
  %id = getelementptr i8, ptr %value, i64 8
  store i64 %identity, ptr %id, align 8
  %first = getelementptr i8, ptr %value, i64 16
  store ptr %a, ptr %first, align 8
  %second = getelementptr i8, ptr %value, i64 24
  store ptr %b, ptr %second, align 8
  ret ptr %value
}
define private ptr @mlf.construct.wide(i64 %identity, i64 %count) alwaysinline {
entry:
  %fields = mul i64 %count, 8
  %size = add i64 %fields, 24
  %value = call ptr @mlf.allocate.constructor(i64 %identity, i64 %count, i64 %size)
  store i32 28, ptr %value, align 4
  %id = getelementptr i8, ptr %value, i64 8
  store i64 %identity, ptr %id, align 8
  %arity = getelementptr i8, ptr %value, i64 16
  store i64 %count, ptr %arity, align 8
  ret ptr %value
}
@mlf_compact_pending = external global [17 x ptr]
define private ptr @mlf.allocate.thunk(ptr %code, i64 %count) alwaysinline {
entry:
  %words = add i64 %count, 4
  %index = lshr i64 %words, 1
  %slot = getelementptr [17 x ptr], ptr @mlf_compact_pending, i64 0, i64 %index
  %value = load ptr, ptr %slot, align 8
  %empty = icmp eq ptr %value, null
  br i1 %empty, label %slow, label %ready
ready:
  %next = load ptr, ptr %value, align 8
  store ptr %next, ptr %slot, align 8
  store i64 3, ptr %value, align 8
  %function = getelementptr i8, ptr %value, i64 8
  store ptr %code, ptr %function, align 8
  %environment = getelementptr i8, ptr %value, i64 24
  %capture = getelementptr i8, ptr %value, i64 16
  store ptr %environment, ptr %capture, align 8
  store i64 %count, ptr %environment, align 8
  ret ptr %value
slow:
  %allocated = call ptr @mlf_thunk_new(ptr %code, i64 %count)
  ret ptr %allocated
}
define private ptr @mlf.force(ptr %value) alwaysinline {
entry:
  %null = icmp eq ptr %value, null
  br i1 %null, label %slow, label %test
test:
  %bits = ptrtoint ptr %value to i64
  %kind = and i64 %bits, 7
  %immediate = icmp ne i64 %kind, 0
  br i1 %immediate, label %done, label %tagged
tagged:
  %tag = load i32, ptr %value, align 4
  %ready = icmp uge i32 %tag, 5
  br i1 %ready, label %done, label %deferred
deferred:
  %isthunk = icmp eq i32 %tag, 3
  br i1 %isthunk, label %enter, label %indirect
indirect:
  %forwarded = icmp eq i32 %tag, 2
  br i1 %forwarded, label %next, label %slow
next:
  %slot = getelementptr i8, ptr %value, i64 8
  %p = load ptr, ptr %slot, align 8
  %missing = icmp eq ptr %p, null
  br i1 %missing, label %slow, label %nexttest
nexttest:
  %pbits = ptrtoint ptr %p to i64
  %pkind = and i64 %pbits, 7
  %pimm = icmp ne i64 %pkind, 0
  br i1 %pimm, label %forward, label %ptagged
ptagged:
  %ptag = load i32, ptr %p, align 4
  %pready = icmp uge i32 %ptag, 5
  br i1 %pready, label %forward, label %slow
forward:
  ret ptr %p
done:
  ret ptr %value
enter:
  %code.slot = getelementptr i8, ptr %value, i64 8
  %env.slot = getelementptr i8, ptr %value, i64 16
  %code = load ptr, ptr %code.slot, align 8
  %env = load ptr, ptr %env.slot, align 8
  store i32 1, ptr %value, align 4
  store ptr null, ptr %code.slot, align 8
  store ptr null, ptr %env.slot, align 8
  %returned = call ptr %code(ptr %env, ptr null)
  %canonical = call ptr @mlf_force(ptr %returned)
  store i32 2, ptr %value, align 4
  store ptr %canonical, ptr %code.slot, align 8
  ret ptr %canonical
slow:
  %result = tail call ptr @mlf_force(ptr %value)
  ret ptr %result
}
!0 = !{!"MLF storage"}
!1 = !{!"managed object", !0}
!2 = !{!"array cells", !0}
!3 = !{!1, !1, i64 0}
!4 = !{!2, !2, i64 0}
@mlf.bytes.6 = private unnamed_addr constant [17 x i8] c"\41\43\47\54\55\4d\52\57\53\59\4b\56\48\44\42\4e\00", align 1
@mlf.bytes.6.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 16, ptr @mlf.bytes.6, ptr null }, align 8
@mlf.bytes.13 = private unnamed_addr constant [17 x i8] c"\54\47\43\41\41\4b\59\57\53\52\4d\42\44\48\56\4e\00", align 1
@mlf.bytes.13.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 16, ptr @mlf.bytes.13, ptr null }, align 8
define private ptr @mlf.code.1(ptr %env, ptr %arg) {
entry:
  %v2 = call ptr @mlf_prim2(i64 35, ptr inttoptr (i64 513 to ptr), ptr inttoptr (i64 1 to ptr))
  ret ptr %v2
}

define private ptr @mlf.code.5(ptr %env, ptr %arg) {
entry:
  %v7 = call ptr @mlf_prim1(i64 39, ptr @mlf.bytes.6.value)
  ret ptr %v7
}

define private ptr @mlf.code.12(ptr %env, ptr %arg) {
entry:
  %v14 = call ptr @mlf_prim1(i64 39, ptr @mlf.bytes.13.value)
  ret ptr %v14
}

define private ptr @mlf.numeric.15.pppi(ptr %a0, ptr %a1, ptr %a2, ptr %a3) alwaysinline {
entry:
  %v63 = ptrtoint ptr %a3 to i64
  %v64 = ptrtoint ptr inttoptr (i64 33 to ptr) to i64
  %v65 = icmp slt i64 %v63, %v64
  %v66 = select i1 %v65, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v67 = icmp eq ptr %v66, inttoptr (i64 6 to ptr)
  br i1 %v67, label %tail.yes.68, label %tail.no.69
tail.yes.68:
  %v70 = getelementptr i8, ptr %a1, i64 8
  %v71 = load i64, ptr %v70, align 8, !tbaa !3
  %v72 = getelementptr i8, ptr %a1, i64 16
  %v73 = load ptr, ptr %v72, align 8, !tbaa !3
  %v74 = ptrtoint ptr %a3 to i64
  %v75 = ashr i64 %v74, 1
  %v76 = and i64 %v74, 1
  %v77 = icmp ne i64 %v76, 0
  %v78 = icmp ult i64 %v75, %v71
  %v79 = and i1 %v77, %v78
  br i1 %v79, label %array.valid.80, label %array.invalid.81
array.invalid.81:
  call void @mlf_bounds_failure()
  unreachable
array.valid.80:
  %v82 = getelementptr i8, ptr %v73, i64 %v75
  %v83 = load i8, ptr %v82, align 1, !tbaa !4
  %v84 = zext i8 %v83 to i64
  %v85 = shl i64 %v84, 1
  %v86 = or i64 %v85, 1
  %v87 = inttoptr i64 %v86 to ptr
  %v88 = getelementptr i8, ptr %a2, i64 8
  %v89 = load i64, ptr %v88, align 8, !tbaa !3
  %v90 = getelementptr i8, ptr %a2, i64 16
  %v91 = load ptr, ptr %v90, align 8, !tbaa !3
  %v92 = ptrtoint ptr %a3 to i64
  %v93 = ashr i64 %v92, 1
  %v94 = and i64 %v92, 1
  %v95 = icmp ne i64 %v94, 0
  %v96 = icmp ult i64 %v93, %v89
  %v97 = and i1 %v95, %v96
  br i1 %v97, label %array.valid.98, label %array.invalid.99
array.invalid.99:
  call void @mlf_bounds_failure()
  unreachable
array.valid.98:
  %v100 = getelementptr i8, ptr %v91, i64 %v93
  %v101 = load i8, ptr %v100, align 1, !tbaa !4
  %v102 = zext i8 %v101 to i64
  %v103 = shl i64 %v102, 1
  %v104 = or i64 %v103, 1
  %v105 = inttoptr i64 %v104 to ptr
  %v106 = getelementptr i8, ptr %a0, i64 8
  %v107 = load i64, ptr %v106, align 8, !tbaa !3
  %v108 = getelementptr i8, ptr %a0, i64 16
  %v109 = load ptr, ptr %v108, align 8, !tbaa !3
  %v110 = ptrtoint ptr %v87 to i64
  %v111 = ashr i64 %v110, 1
  %v112 = and i64 %v110, 1
  %v113 = icmp ne i64 %v112, 0
  %v114 = icmp ult i64 %v111, %v107
  %v115 = and i1 %v113, %v114
  br i1 %v115, label %array.valid.116, label %array.invalid.117
array.invalid.117:
  call void @mlf_bounds_failure()
  unreachable
array.valid.116:
  %v118 = getelementptr i8, ptr %v109, i64 %v111
  %v119 = ptrtoint ptr %v105 to i64
  %v120 = ashr i64 %v119, 1
  %v121 = trunc i64 %v120 to i8
  store i8 %v121, ptr %v118, align 1, !tbaa !4
  %v122 = ptrtoint ptr %v87 to i64
  %v123 = ptrtoint ptr inttoptr (i64 65 to ptr) to i64
  %v124 = sub i64 %v123, 1
  %v125 = add nsw i64 %v122, %v124
  %v126 = inttoptr i64 %v125 to ptr
  %v127 = ptrtoint ptr %v126 to i64
  %v128 = ashr i64 %v127, 1
  %v129 = and i64 %v127, 1
  %v130 = icmp ne i64 %v129, 0
  %v131 = icmp ult i64 %v128, %v107
  %v132 = and i1 %v130, %v131
  br i1 %v132, label %array.valid.133, label %array.invalid.134
array.invalid.134:
  call void @mlf_bounds_failure()
  unreachable
array.valid.133:
  %v135 = getelementptr i8, ptr %v109, i64 %v128
  %v136 = ptrtoint ptr %v105 to i64
  %v137 = ashr i64 %v136, 1
  %v138 = trunc i64 %v137 to i8
  store i8 %v138, ptr %v135, align 1, !tbaa !4
  %v139 = ptrtoint ptr %a3 to i64
  %v140 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v141 = sub i64 %v140, 1
  %v142 = add nsw i64 %v139, %v141
  %v143 = inttoptr i64 %v142 to ptr
  %v144 = musttail call ptr @mlf.numeric.15.pppi(ptr %a0, ptr %a1, ptr %a2, ptr %v143)
  ret ptr %v144
tail.no.69:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.numeric.15(ptr %a0, ptr %a1, ptr %a2, ptr %a3) alwaysinline {
entry:
  %v55 = ptrtoint ptr %a3 to i64
  %v56 = and i64 %v55, 1
  %v57 = icmp ne i64 %v56, 0
  %v58 = icmp ult i64 %v55, 4294967296
  %v59 = and i1 %v57, %v58
  %v60 = and i1 true, %v59
  br i1 %v60, label %range.fast.61, label %range.general.62
range.fast.61:
  %v145 = musttail call ptr @mlf.numeric.15.pppi(ptr %a0, ptr %a1, ptr %a2, ptr %a3)
  ret ptr %v145
range.general.62:
  %v146 = ptrtoint ptr %a3 to i64
  %v147 = ptrtoint ptr inttoptr (i64 33 to ptr) to i64
  %v148 = and i64 %v146, %v147
  %v149 = and i64 %v148, 1
  %v150 = icmp ne i64 %v149, 0
  br i1 %v150, label %yes.151, label %no.152
yes.151:
  %v154 = icmp slt i64 %v146, %v147
  %v155 = select i1 %v154, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.153
no.152:
  %v156 = call ptr @mlf_lt_int(ptr %a3, ptr inttoptr (i64 33 to ptr))
  br label %join.153
join.153:
  %v157 = phi ptr [ %v155, %yes.151 ], [ %v156, %no.152 ]
  %v158 = icmp eq ptr %v157, inttoptr (i64 6 to ptr)
  br i1 %v158, label %tail.yes.159, label %tail.no.160
tail.yes.159:
  %v161 = getelementptr i8, ptr %a1, i64 8
  %v162 = load i64, ptr %v161, align 8, !tbaa !3
  %v163 = getelementptr i8, ptr %a1, i64 16
  %v164 = load ptr, ptr %v163, align 8, !tbaa !3
  %v165 = ptrtoint ptr %a3 to i64
  %v166 = ashr i64 %v165, 1
  %v167 = and i64 %v165, 1
  %v168 = icmp ne i64 %v167, 0
  %v169 = icmp ult i64 %v166, %v162
  %v170 = and i1 %v168, %v169
  br i1 %v170, label %array.valid.171, label %array.invalid.172
array.invalid.172:
  call void @mlf_bounds_failure()
  unreachable
array.valid.171:
  %v173 = getelementptr i8, ptr %v164, i64 %v166
  %v174 = load i8, ptr %v173, align 1, !tbaa !4
  %v175 = zext i8 %v174 to i64
  %v176 = shl i64 %v175, 1
  %v177 = or i64 %v176, 1
  %v178 = inttoptr i64 %v177 to ptr
  %v179 = getelementptr i8, ptr %a2, i64 8
  %v180 = load i64, ptr %v179, align 8, !tbaa !3
  %v181 = getelementptr i8, ptr %a2, i64 16
  %v182 = load ptr, ptr %v181, align 8, !tbaa !3
  %v183 = ptrtoint ptr %a3 to i64
  %v184 = ashr i64 %v183, 1
  %v185 = and i64 %v183, 1
  %v186 = icmp ne i64 %v185, 0
  %v187 = icmp ult i64 %v184, %v180
  %v188 = and i1 %v186, %v187
  br i1 %v188, label %array.valid.189, label %array.invalid.190
array.invalid.190:
  call void @mlf_bounds_failure()
  unreachable
array.valid.189:
  %v191 = getelementptr i8, ptr %v182, i64 %v184
  %v192 = load i8, ptr %v191, align 1, !tbaa !4
  %v193 = zext i8 %v192 to i64
  %v194 = shl i64 %v193, 1
  %v195 = or i64 %v194, 1
  %v196 = inttoptr i64 %v195 to ptr
  %v197 = getelementptr i8, ptr %a0, i64 8
  %v198 = load i64, ptr %v197, align 8, !tbaa !3
  %v199 = getelementptr i8, ptr %a0, i64 16
  %v200 = load ptr, ptr %v199, align 8, !tbaa !3
  %v201 = ptrtoint ptr %v178 to i64
  %v202 = ashr i64 %v201, 1
  %v203 = and i64 %v201, 1
  %v204 = icmp ne i64 %v203, 0
  %v205 = icmp ult i64 %v202, %v198
  %v206 = and i1 %v204, %v205
  br i1 %v206, label %array.valid.207, label %array.invalid.208
array.invalid.208:
  call void @mlf_bounds_failure()
  unreachable
array.valid.207:
  %v209 = getelementptr i8, ptr %v200, i64 %v202
  %v210 = ptrtoint ptr %v196 to i64
  %v211 = ashr i64 %v210, 1
  %v212 = trunc i64 %v211 to i8
  store i8 %v212, ptr %v209, align 1, !tbaa !4
  %v213 = ptrtoint ptr %v178 to i64
  %v214 = ptrtoint ptr inttoptr (i64 65 to ptr) to i64
  %v215 = sub i64 %v214, 1
  %v216 = add nsw i64 %v213, %v215
  %v217 = inttoptr i64 %v216 to ptr
  %v218 = ptrtoint ptr %v217 to i64
  %v219 = ashr i64 %v218, 1
  %v220 = and i64 %v218, 1
  %v221 = icmp ne i64 %v220, 0
  %v222 = icmp ult i64 %v219, %v198
  %v223 = and i1 %v221, %v222
  br i1 %v223, label %array.valid.224, label %array.invalid.225
array.invalid.225:
  call void @mlf_bounds_failure()
  unreachable
array.valid.224:
  %v226 = getelementptr i8, ptr %v200, i64 %v219
  %v227 = ptrtoint ptr %v196 to i64
  %v228 = ashr i64 %v227, 1
  %v229 = trunc i64 %v228 to i8
  store i8 %v229, ptr %v226, align 1, !tbaa !4
  %v230 = ptrtoint ptr %a3 to i64
  %v231 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v232 = sub i64 %v231, 1
  %v233 = add nsw i64 %v230, %v232
  %v234 = inttoptr i64 %v233 to ptr
  %v235 = musttail call ptr @mlf.numeric.15(ptr %a0, ptr %a1, ptr %a2, ptr %v234)
  ret ptr %v235
tail.no.160:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.code.243(ptr %env, ptr %arg) {
entry:
  %v244 = getelementptr i8, ptr %env, i64 8
  %v245 = load ptr, ptr %v244, align 8, !tbaa !3
  %v246 = getelementptr i8, ptr %env, i64 16
  %v247 = load ptr, ptr %v246, align 8, !tbaa !3
  %v248 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v248, align 8, !tbaa !3
  %v249 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v249, align 8, !tbaa !3
  %v250 = call ptr @mlf_prim2(i64 36, ptr %v245, ptr %v247)
  ret ptr %v250
}

define private ptr @mlf.code.265(ptr %env, ptr %arg) {
entry:
  %v266 = getelementptr i8, ptr %env, i64 8
  %v267 = load ptr, ptr %v266, align 8, !tbaa !3
  %v268 = getelementptr i8, ptr %env, i64 16
  %v269 = load ptr, ptr %v268, align 8, !tbaa !3
  %v270 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v270, align 8, !tbaa !3
  %v271 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v271, align 8, !tbaa !3
  %v272 = call ptr @mlf_prim2(i64 36, ptr %v267, ptr %v269)
  ret ptr %v272
}

define private ptr @mlf.code.289(ptr %env, ptr %arg) {
entry:
  %v290 = getelementptr i8, ptr %env, i64 8
  %v291 = load ptr, ptr %v290, align 8, !tbaa !3
  %v292 = getelementptr i8, ptr %env, i64 16
  %v293 = load ptr, ptr %v292, align 8, !tbaa !3
  %v294 = getelementptr i8, ptr %env, i64 24
  %v295 = load ptr, ptr %v294, align 8, !tbaa !3
  %v296 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v296, align 8, !tbaa !3
  %v297 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v297, align 8, !tbaa !3
  %v298 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v298, align 8, !tbaa !3
  %v299 = call ptr @mlf_prim3(i64 37, ptr %v291, ptr %v293, ptr %v295)
  ret ptr %v299
}

define private ptr @mlf.code.329(ptr %env, ptr %arg) {
entry:
  %v330 = getelementptr i8, ptr %env, i64 8
  %v331 = load ptr, ptr %v330, align 8, !tbaa !3
  %v332 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v332, align 8, !tbaa !3
  %v333 = call ptr @mlf.force(ptr %v331)
  %v334 = call ptr @mlf_prim2(i64 8, ptr %v333, ptr inttoptr (i64 65 to ptr))
  ret ptr %v334
}

define private ptr @mlf.code.319(ptr %env, ptr %arg) {
entry:
  %v320 = getelementptr i8, ptr %env, i64 8
  %v321 = load ptr, ptr %v320, align 8, !tbaa !3
  %v322 = getelementptr i8, ptr %env, i64 16
  %v323 = load ptr, ptr %v322, align 8, !tbaa !3
  %v324 = getelementptr i8, ptr %env, i64 24
  %v325 = load ptr, ptr %v324, align 8, !tbaa !3
  %v326 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v326, align 8, !tbaa !3
  %v327 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v327, align 8, !tbaa !3
  %v328 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v328, align 8, !tbaa !3
  %v335 = call ptr @mlf.allocate.thunk(ptr @mlf.code.329, i64 1)
  %v336 = getelementptr i8, ptr %v335, i64 16
  %v337 = load ptr, ptr %v336, align 8, !tbaa !3
  %v338 = getelementptr i8, ptr %v337, i64 8
  store ptr %v323, ptr %v338, align 8, !tbaa !3
  %v339 = call ptr @mlf_prim3(i64 37, ptr %v321, ptr %v335, ptr %v325)
  ret ptr %v339
}

define private ptr @mlf.code.346(ptr %env, ptr %arg) {
entry:
  %v347 = getelementptr i8, ptr %env, i64 8
  %v348 = load ptr, ptr %v347, align 8, !tbaa !3
  %v349 = getelementptr i8, ptr %env, i64 16
  %v350 = load ptr, ptr %v349, align 8, !tbaa !3
  %v351 = getelementptr i8, ptr %env, i64 24
  %v352 = load ptr, ptr %v351, align 8, !tbaa !3
  %v353 = getelementptr i8, ptr %env, i64 32
  %v354 = load ptr, ptr %v353, align 8, !tbaa !3
  %v355 = call ptr @mlf.force(ptr %v354)
  %v356 = call ptr @mlf_prim2(i64 8, ptr %v355, ptr inttoptr (i64 3 to ptr))
  %v357 = call ptr @mlf_env_new(i64 4)
  %v358 = getelementptr i8, ptr %v357, i64 8
  store ptr %v348, ptr %v358, align 8, !tbaa !3
  %v359 = getelementptr i8, ptr %v357, i64 16
  store ptr %v350, ptr %v359, align 8, !tbaa !3
  %v360 = getelementptr i8, ptr %v357, i64 24
  store ptr %v352, ptr %v360, align 8, !tbaa !3
  %v361 = getelementptr i8, ptr %v357, i64 32
  store ptr %v356, ptr %v361, align 8, !tbaa !3
  %v362 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.31, ptr %v357)
  ret ptr %v362
}

define private ptr @mlf.code.306(ptr %env, ptr %arg) {
entry:
  %v307 = getelementptr i8, ptr %env, i64 8
  %v308 = load ptr, ptr %v307, align 8, !tbaa !3
  %v309 = getelementptr i8, ptr %env, i64 16
  %v310 = load ptr, ptr %v309, align 8, !tbaa !3
  %v311 = getelementptr i8, ptr %env, i64 24
  %v312 = load ptr, ptr %v311, align 8, !tbaa !3
  %v313 = getelementptr i8, ptr %env, i64 32
  %v314 = load ptr, ptr %v313, align 8, !tbaa !3
  %v315 = getelementptr i8, ptr %env, i64 40
  %v316 = load ptr, ptr %v315, align 8, !tbaa !3
  %v317 = getelementptr i8, ptr %env, i64 48
  %v318 = load ptr, ptr %v317, align 8, !tbaa !3
  %v340 = call ptr @mlf.allocate.thunk(ptr @mlf.code.319, i64 3)
  %v341 = getelementptr i8, ptr %v340, i64 16
  %v342 = load ptr, ptr %v341, align 8, !tbaa !3
  %v343 = getelementptr i8, ptr %v342, i64 8
  store ptr %v308, ptr %v343, align 8, !tbaa !3
  %v344 = getelementptr i8, ptr %v342, i64 16
  store ptr %v316, ptr %v344, align 8, !tbaa !3
  %v345 = getelementptr i8, ptr %v342, i64 24
  store ptr %v318, ptr %v345, align 8, !tbaa !3
  %v363 = call ptr @mlf_env_new(i64 4)
  %v364 = getelementptr i8, ptr %v363, i64 8
  store ptr %v308, ptr %v364, align 8, !tbaa !3
  %v365 = getelementptr i8, ptr %v363, i64 16
  store ptr %v310, ptr %v365, align 8, !tbaa !3
  %v366 = getelementptr i8, ptr %v363, i64 24
  store ptr %v312, ptr %v366, align 8, !tbaa !3
  %v367 = getelementptr i8, ptr %v363, i64 32
  store ptr %v314, ptr %v367, align 8, !tbaa !3
  %v368 = call ptr @mlf_closure(ptr @mlf.code.346, ptr %v363)
  %v369 = call ptr @mlf_prim2(i64 1, ptr %v340, ptr %v368)
  ret ptr %v369
}

define private ptr @mlf.code.278(ptr %env, ptr %arg) {
entry:
  %v279 = getelementptr i8, ptr %env, i64 8
  %v280 = load ptr, ptr %v279, align 8, !tbaa !3
  %v281 = getelementptr i8, ptr %env, i64 16
  %v282 = load ptr, ptr %v281, align 8, !tbaa !3
  %v283 = getelementptr i8, ptr %env, i64 24
  %v284 = load ptr, ptr %v283, align 8, !tbaa !3
  %v285 = getelementptr i8, ptr %env, i64 32
  %v286 = load ptr, ptr %v285, align 8, !tbaa !3
  %v287 = getelementptr i8, ptr %env, i64 40
  %v288 = load ptr, ptr %v287, align 8, !tbaa !3
  %v300 = call ptr @mlf.allocate.thunk(ptr @mlf.code.289, i64 3)
  %v301 = getelementptr i8, ptr %v300, i64 16
  %v302 = load ptr, ptr %v301, align 8, !tbaa !3
  %v303 = getelementptr i8, ptr %v302, i64 8
  store ptr %v280, ptr %v303, align 8, !tbaa !3
  %v304 = getelementptr i8, ptr %v302, i64 16
  store ptr %v288, ptr %v304, align 8, !tbaa !3
  %v305 = getelementptr i8, ptr %v302, i64 24
  store ptr %arg, ptr %v305, align 8, !tbaa !3
  %v370 = call ptr @mlf_env_new(i64 6)
  %v371 = getelementptr i8, ptr %v370, i64 8
  store ptr %v280, ptr %v371, align 8, !tbaa !3
  %v372 = getelementptr i8, ptr %v370, i64 16
  store ptr %v282, ptr %v372, align 8, !tbaa !3
  %v373 = getelementptr i8, ptr %v370, i64 24
  store ptr %v284, ptr %v373, align 8, !tbaa !3
  %v374 = getelementptr i8, ptr %v370, i64 32
  store ptr %v286, ptr %v374, align 8, !tbaa !3
  %v375 = getelementptr i8, ptr %v370, i64 40
  store ptr %v288, ptr %v375, align 8, !tbaa !3
  %v376 = getelementptr i8, ptr %v370, i64 48
  store ptr %arg, ptr %v376, align 8, !tbaa !3
  %v377 = call ptr @mlf_closure(ptr @mlf.code.306, ptr %v370)
  %v378 = call ptr @mlf_prim2(i64 1, ptr %v300, ptr %v377)
  ret ptr %v378
}

define private ptr @mlf.code.256(ptr %env, ptr %arg) {
entry:
  %v257 = getelementptr i8, ptr %env, i64 8
  %v258 = load ptr, ptr %v257, align 8, !tbaa !3
  %v259 = getelementptr i8, ptr %env, i64 16
  %v260 = load ptr, ptr %v259, align 8, !tbaa !3
  %v261 = getelementptr i8, ptr %env, i64 24
  %v262 = load ptr, ptr %v261, align 8, !tbaa !3
  %v263 = getelementptr i8, ptr %env, i64 32
  %v264 = load ptr, ptr %v263, align 8, !tbaa !3
  %v273 = call ptr @mlf.allocate.thunk(ptr @mlf.code.265, i64 2)
  %v274 = getelementptr i8, ptr %v273, i64 16
  %v275 = load ptr, ptr %v274, align 8, !tbaa !3
  %v276 = getelementptr i8, ptr %v275, i64 8
  store ptr %v262, ptr %v276, align 8, !tbaa !3
  %v277 = getelementptr i8, ptr %v275, i64 16
  store ptr %v264, ptr %v277, align 8, !tbaa !3
  %v379 = call ptr @mlf_env_new(i64 5)
  %v380 = getelementptr i8, ptr %v379, i64 8
  store ptr %v258, ptr %v380, align 8, !tbaa !3
  %v381 = getelementptr i8, ptr %v379, i64 16
  store ptr %v260, ptr %v381, align 8, !tbaa !3
  %v382 = getelementptr i8, ptr %v379, i64 24
  store ptr %v262, ptr %v382, align 8, !tbaa !3
  %v383 = getelementptr i8, ptr %v379, i64 32
  store ptr %v264, ptr %v383, align 8, !tbaa !3
  %v384 = getelementptr i8, ptr %v379, i64 40
  store ptr %arg, ptr %v384, align 8, !tbaa !3
  %v385 = call ptr @mlf_closure(ptr @mlf.code.278, ptr %v379)
  %v386 = call ptr @mlf_prim2(i64 1, ptr %v273, ptr %v385)
  ret ptr %v386
}

define private ptr @mlf.worker.15(ptr %a0, ptr %a1, ptr %a2, ptr %a3) {
entry:
  %v238 = call ptr @mlf_prim2(i64 11, ptr %a3, ptr inttoptr (i64 33 to ptr))
  %v239 = icmp eq ptr %v238, inttoptr (i64 6 to ptr)
  br i1 %v239, label %yes.240, label %no.241
yes.240:
  %v251 = call ptr @mlf.allocate.thunk(ptr @mlf.code.243, i64 2)
  %v252 = getelementptr i8, ptr %v251, i64 16
  %v253 = load ptr, ptr %v252, align 8, !tbaa !3
  %v254 = getelementptr i8, ptr %v253, i64 8
  store ptr %a1, ptr %v254, align 8, !tbaa !3
  %v255 = getelementptr i8, ptr %v253, i64 16
  store ptr %a3, ptr %v255, align 8, !tbaa !3
  %v387 = call ptr @mlf_env_new(i64 4)
  %v388 = getelementptr i8, ptr %v387, i64 8
  store ptr %a0, ptr %v388, align 8, !tbaa !3
  %v389 = getelementptr i8, ptr %v387, i64 16
  store ptr %a1, ptr %v389, align 8, !tbaa !3
  %v390 = getelementptr i8, ptr %v387, i64 24
  store ptr %a2, ptr %v390, align 8, !tbaa !3
  %v391 = getelementptr i8, ptr %v387, i64 32
  store ptr %a3, ptr %v391, align 8, !tbaa !3
  %v392 = call ptr @mlf_closure(ptr @mlf.code.256, ptr %v387)
  %v393 = call ptr @mlf_prim2(i64 1, ptr %v251, ptr %v392)
  br label %join.242
no.241:
  %v394 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.242
join.242:
  %v395 = phi ptr [ %v393, %yes.240 ], [ %v394, %no.241 ]
  ret ptr %v395
}

define private ptr @mlf.numeric.entry.31(ptr %env, ptr %arg) {
entry:
  %v32 = getelementptr i8, ptr %env, i64 8
  %v33 = load ptr, ptr %v32, align 8, !tbaa !3
  %v34 = getelementptr i8, ptr %env, i64 16
  %v35 = load ptr, ptr %v34, align 8, !tbaa !3
  %v36 = getelementptr i8, ptr %env, i64 24
  %v37 = load ptr, ptr %v36, align 8, !tbaa !3
  %v38 = getelementptr i8, ptr %env, i64 32
  %v39 = load ptr, ptr %v38, align 8, !tbaa !3
  %v40 = call ptr @mlf_peek(ptr %v33)
  %v41 = call ptr @mlf_peek(ptr %v35)
  %v42 = call ptr @mlf_peek(ptr %v37)
  %v43 = call ptr @mlf_peek(ptr %v39)
  %v44 = icmp ne ptr %v40, null
  %v45 = icmp ne ptr %v41, null
  %v46 = icmp ne ptr %v42, null
  %v47 = icmp ne ptr %v43, null
  %v48 = and i1 true, %v44
  %v49 = and i1 %v48, %v45
  %v50 = and i1 %v49, %v46
  %v51 = and i1 %v50, %v47
  br i1 %v51, label %yes.52, label %no.53
yes.52:
  %v236 = call ptr @mlf.numeric.15(ptr %v40, ptr %v41, ptr %v42, ptr %v43)
  %v237 = call ptr @mlf_prim1(i64 0, ptr %v236)
  br label %join.54
no.53:
  %v396 = call ptr @mlf.force(ptr %v39)
  %v397 = call ptr @mlf.worker.15(ptr %v33, ptr %v35, ptr %v37, ptr %v396)
  br label %join.54
join.54:
  %v398 = phi ptr [ %v237, %yes.52 ], [ %v397, %no.53 ]
  ret ptr %v398
}

define private ptr @mlf.code.21(ptr %env, ptr %arg) {
entry:
  %v22 = getelementptr i8, ptr %env, i64 8
  %v23 = load ptr, ptr %v22, align 8, !tbaa !3
  %v24 = getelementptr i8, ptr %env, i64 16
  %v25 = load ptr, ptr %v24, align 8, !tbaa !3
  %v26 = getelementptr i8, ptr %env, i64 24
  %v27 = load ptr, ptr %v26, align 8, !tbaa !3
  %v28 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v28, align 8, !tbaa !3
  %v29 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v29, align 8, !tbaa !3
  %v30 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v30, align 8, !tbaa !3
  %v399 = call ptr @mlf_env_new(i64 4)
  %v400 = getelementptr i8, ptr %v399, i64 8
  store ptr %v23, ptr %v400, align 8, !tbaa !3
  %v401 = getelementptr i8, ptr %v399, i64 16
  store ptr %v25, ptr %v401, align 8, !tbaa !3
  %v402 = getelementptr i8, ptr %v399, i64 24
  store ptr %v27, ptr %v402, align 8, !tbaa !3
  %v403 = getelementptr i8, ptr %v399, i64 32
  store ptr inttoptr (i64 1 to ptr), ptr %v403, align 8, !tbaa !3
  %v404 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.31, ptr %v399)
  ret ptr %v404
}

define private ptr @mlf.code.414(ptr %env, ptr %arg) {
entry:
  %v415 = call ptr @mlf_prim2(i64 35, ptr inttoptr (i64 2049 to ptr), ptr inttoptr (i64 1 to ptr))
  ret ptr %v415
}

define private ptr @mlf.code.420(ptr %env, ptr %arg) {
entry:
  %v421 = call ptr @mlf_prim2(i64 35, ptr inttoptr (i64 124929 to ptr), ptr inttoptr (i64 1 to ptr))
  ret ptr %v421
}

define private ptr @mlf.numeric.24.pppiiii(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6) alwaysinline {
entry:
  %v574 = ptrtoint ptr %a6 to i64
  %v575 = ptrtoint ptr %a5 to i64
  %v576 = icmp slt i64 %v574, %v575
  %v577 = select i1 %v576, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v578 = icmp eq ptr %v577, inttoptr (i64 6 to ptr)
  br i1 %v578, label %tail.yes.579, label %tail.no.580
tail.yes.579:
  %v581 = ptrtoint ptr %a3 to i64
  %v582 = ptrtoint ptr %a6 to i64
  %v583 = sub i64 %v582, 1
  %v584 = sub nsw i64 %v581, %v583
  %v585 = inttoptr i64 %v584 to ptr
  %v586 = getelementptr i8, ptr %a1, i64 8
  %v587 = load i64, ptr %v586, align 8, !tbaa !3
  %v588 = getelementptr i8, ptr %a1, i64 16
  %v589 = load ptr, ptr %v588, align 8, !tbaa !3
  %v590 = ptrtoint ptr %v585 to i64
  %v591 = ashr i64 %v590, 1
  %v592 = and i64 %v590, 1
  %v593 = icmp ne i64 %v592, 0
  %v594 = icmp ult i64 %v591, %v587
  %v595 = and i1 %v593, %v594
  br i1 %v595, label %array.valid.596, label %array.invalid.597
array.invalid.597:
  call void @mlf_bounds_failure()
  unreachable
array.valid.596:
  %v598 = getelementptr i8, ptr %v589, i64 %v591
  %v599 = load i8, ptr %v598, align 1, !tbaa !4
  %v600 = zext i8 %v599 to i64
  %v601 = shl i64 %v600, 1
  %v602 = or i64 %v601, 1
  %v603 = inttoptr i64 %v602 to ptr
  %v604 = getelementptr i8, ptr %a0, i64 8
  %v605 = load i64, ptr %v604, align 8, !tbaa !3
  %v606 = getelementptr i8, ptr %a0, i64 16
  %v607 = load ptr, ptr %v606, align 8, !tbaa !3
  %v608 = ptrtoint ptr %v603 to i64
  %v609 = ashr i64 %v608, 1
  %v610 = and i64 %v608, 1
  %v611 = icmp ne i64 %v610, 0
  %v612 = icmp ult i64 %v609, %v605
  %v613 = and i1 %v611, %v612
  br i1 %v613, label %array.valid.614, label %array.invalid.615
array.invalid.615:
  call void @mlf_bounds_failure()
  unreachable
array.valid.614:
  %v616 = getelementptr i8, ptr %v607, i64 %v609
  %v617 = load i8, ptr %v616, align 1, !tbaa !4
  %v618 = zext i8 %v617 to i64
  %v619 = shl i64 %v618, 1
  %v620 = or i64 %v619, 1
  %v621 = inttoptr i64 %v620 to ptr
  %v622 = ptrtoint ptr %a4 to i64
  %v623 = ptrtoint ptr %a6 to i64
  %v624 = sub i64 %v623, 1
  %v625 = add nsw i64 %v622, %v624
  %v626 = inttoptr i64 %v625 to ptr
  %v627 = getelementptr i8, ptr %a2, i64 8
  %v628 = load i64, ptr %v627, align 8, !tbaa !3
  %v629 = getelementptr i8, ptr %a2, i64 16
  %v630 = load ptr, ptr %v629, align 8, !tbaa !3
  %v631 = ptrtoint ptr %v626 to i64
  %v632 = ashr i64 %v631, 1
  %v633 = and i64 %v631, 1
  %v634 = icmp ne i64 %v633, 0
  %v635 = icmp ult i64 %v632, %v628
  %v636 = and i1 %v634, %v635
  br i1 %v636, label %array.valid.637, label %array.invalid.638
array.invalid.638:
  call void @mlf_bounds_failure()
  unreachable
array.valid.637:
  %v639 = getelementptr i8, ptr %v630, i64 %v632
  %v640 = ptrtoint ptr %v621 to i64
  %v641 = ashr i64 %v640, 1
  %v642 = trunc i64 %v641 to i8
  store i8 %v642, ptr %v639, align 1, !tbaa !4
  %v643 = ptrtoint ptr %a6 to i64
  %v644 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v645 = sub i64 %v644, 1
  %v646 = add nsw i64 %v643, %v645
  %v647 = inttoptr i64 %v646 to ptr
  %v648 = musttail call ptr @mlf.numeric.24.pppiiii(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %v647)
  ret ptr %v648
tail.no.580:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.numeric.35.pppiii(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5) alwaysinline {
entry:
  %v558 = ptrtoint ptr %a4 to i64
  %v559 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v560 = icmp eq i64 %v558, %v559
  %v561 = select i1 %v560, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v562 = icmp eq ptr %v561, inttoptr (i64 6 to ptr)
  br i1 %v562, label %tail.yes.563, label %tail.no.564
tail.yes.563:
  ret ptr inttoptr (i64 4 to ptr)
tail.no.564:
  %v565 = ptrtoint ptr %a4 to i64
  %v566 = ptrtoint ptr inttoptr (i64 121 to ptr) to i64
  %v567 = icmp slt i64 %v565, %v566
  %v568 = select i1 %v567, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v569 = icmp eq ptr %v568, inttoptr (i64 6 to ptr)
  br i1 %v569, label %yes.570, label %no.571
yes.570:
  br label %join.572
no.571:
  br label %join.572
join.572:
  %v573 = phi ptr [ %a4, %yes.570 ], [ inttoptr (i64 121 to ptr), %no.571 ]
  %v649 = call ptr @mlf.numeric.24.pppiiii(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a5, ptr %v573, ptr inttoptr (i64 1 to ptr))
  %v650 = ptrtoint ptr %a5 to i64
  %v651 = ptrtoint ptr %v573 to i64
  %v652 = sub i64 %v651, 1
  %v653 = add nsw i64 %v650, %v652
  %v654 = inttoptr i64 %v653 to ptr
  %v655 = getelementptr i8, ptr %a2, i64 8
  %v656 = load i64, ptr %v655, align 8, !tbaa !3
  %v657 = getelementptr i8, ptr %a2, i64 16
  %v658 = load ptr, ptr %v657, align 8, !tbaa !3
  %v659 = ptrtoint ptr %v654 to i64
  %v660 = ashr i64 %v659, 1
  %v661 = and i64 %v659, 1
  %v662 = icmp ne i64 %v661, 0
  %v663 = icmp ult i64 %v660, %v656
  %v664 = and i1 %v662, %v663
  br i1 %v664, label %array.valid.665, label %array.invalid.666
array.invalid.666:
  call void @mlf_bounds_failure()
  unreachable
array.valid.665:
  %v667 = getelementptr i8, ptr %v658, i64 %v660
  %v668 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v669 = ashr i64 %v668, 1
  %v670 = trunc i64 %v669 to i8
  store i8 %v670, ptr %v667, align 1, !tbaa !4
  %v671 = ptrtoint ptr %a3 to i64
  %v672 = ptrtoint ptr %v573 to i64
  %v673 = sub i64 %v672, 1
  %v674 = sub nsw i64 %v671, %v673
  %v675 = inttoptr i64 %v674 to ptr
  %v676 = ptrtoint ptr %a4 to i64
  %v677 = ptrtoint ptr %v573 to i64
  %v678 = sub i64 %v677, 1
  %v679 = sub nsw i64 %v676, %v678
  %v680 = inttoptr i64 %v679 to ptr
  %v681 = ptrtoint ptr %a5 to i64
  %v682 = ptrtoint ptr %v573 to i64
  %v683 = sub i64 %v682, 1
  %v684 = add nsw i64 %v681, %v683
  %v685 = inttoptr i64 %v684 to ptr
  %v686 = ptrtoint ptr %v685 to i64
  %v687 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v688 = sub i64 %v687, 1
  %v689 = add nsw i64 %v686, %v688
  %v690 = inttoptr i64 %v689 to ptr
  %v691 = musttail call ptr @mlf.numeric.35(ptr %a0, ptr %a1, ptr %a2, ptr %v675, ptr %v680, ptr %v690)
  ret ptr %v691
}

define private ptr @mlf.numeric.24(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6) alwaysinline {
entry:
  %v725 = ptrtoint ptr %a3 to i64
  %v726 = and i64 %v725, 1
  %v727 = icmp ne i64 %v726, 0
  %v728 = icmp ult i64 %v725, 4294967296
  %v729 = and i1 %v727, %v728
  %v730 = ptrtoint ptr %a4 to i64
  %v731 = and i64 %v730, 1
  %v732 = icmp ne i64 %v731, 0
  %v733 = icmp ult i64 %v730, 4294967296
  %v734 = and i1 %v732, %v733
  %v735 = ptrtoint ptr %a5 to i64
  %v736 = and i64 %v735, 1
  %v737 = icmp ne i64 %v736, 0
  %v738 = icmp ult i64 %v735, 4294967296
  %v739 = and i1 %v737, %v738
  %v740 = ptrtoint ptr %a6 to i64
  %v741 = and i64 %v740, 1
  %v742 = icmp ne i64 %v741, 0
  %v743 = icmp ult i64 %v740, 4294967296
  %v744 = and i1 %v742, %v743
  %v745 = and i1 true, %v729
  %v746 = and i1 %v745, %v734
  %v747 = and i1 %v746, %v739
  %v748 = and i1 %v747, %v744
  br i1 %v748, label %range.fast.749, label %range.general.750
range.fast.749:
  %v751 = musttail call ptr @mlf.numeric.24.pppiiii(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6)
  ret ptr %v751
range.general.750:
  %v752 = ptrtoint ptr %a6 to i64
  %v753 = ptrtoint ptr %a5 to i64
  %v754 = and i64 %v752, %v753
  %v755 = and i64 %v754, 1
  %v756 = icmp ne i64 %v755, 0
  br i1 %v756, label %yes.757, label %no.758
yes.757:
  %v760 = icmp slt i64 %v752, %v753
  %v761 = select i1 %v760, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.759
no.758:
  %v762 = call ptr @mlf_lt_int(ptr %a6, ptr %a5)
  br label %join.759
join.759:
  %v763 = phi ptr [ %v761, %yes.757 ], [ %v762, %no.758 ]
  %v764 = icmp eq ptr %v763, inttoptr (i64 6 to ptr)
  br i1 %v764, label %tail.yes.765, label %tail.no.766
tail.yes.765:
  %v767 = ptrtoint ptr %a3 to i64
  %v768 = ptrtoint ptr %a6 to i64
  %v769 = and i64 %v767, %v768
  %v770 = and i64 %v769, 1
  %v771 = icmp ne i64 %v770, 0
  br i1 %v771, label %yes.772, label %no.773
yes.772:
  %v775 = sub i64 %v768, 1
  %v776 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v767, i64 %v775)
  %v777 = extractvalue { i64, i1 } %v776, 0
  %v778 = extractvalue { i64, i1 } %v776, 1
  br i1 %v778, label %yes.779, label %no.780
yes.779:
  %v782 = call ptr @mlf_sub_int(ptr %a3, ptr %a6)
  br label %join.781
no.780:
  %v783 = inttoptr i64 %v777 to ptr
  br label %join.781
join.781:
  %v784 = phi ptr [ %v782, %yes.779 ], [ %v783, %no.780 ]
  br label %join.774
no.773:
  %v785 = call ptr @mlf_sub_int(ptr %a3, ptr %a6)
  br label %join.774
join.774:
  %v786 = phi ptr [ %v784, %join.781 ], [ %v785, %no.773 ]
  %v787 = getelementptr i8, ptr %a1, i64 8
  %v788 = load i64, ptr %v787, align 8, !tbaa !3
  %v789 = getelementptr i8, ptr %a1, i64 16
  %v790 = load ptr, ptr %v789, align 8, !tbaa !3
  %v791 = ptrtoint ptr %v786 to i64
  %v792 = ashr i64 %v791, 1
  %v793 = and i64 %v791, 1
  %v794 = icmp ne i64 %v793, 0
  %v795 = icmp ult i64 %v792, %v788
  %v796 = and i1 %v794, %v795
  br i1 %v796, label %array.valid.797, label %array.invalid.798
array.invalid.798:
  call void @mlf_bounds_failure()
  unreachable
array.valid.797:
  %v799 = getelementptr i8, ptr %v790, i64 %v792
  %v800 = load i8, ptr %v799, align 1, !tbaa !4
  %v801 = zext i8 %v800 to i64
  %v802 = shl i64 %v801, 1
  %v803 = or i64 %v802, 1
  %v804 = inttoptr i64 %v803 to ptr
  %v805 = getelementptr i8, ptr %a0, i64 8
  %v806 = load i64, ptr %v805, align 8, !tbaa !3
  %v807 = getelementptr i8, ptr %a0, i64 16
  %v808 = load ptr, ptr %v807, align 8, !tbaa !3
  %v809 = ptrtoint ptr %v804 to i64
  %v810 = ashr i64 %v809, 1
  %v811 = and i64 %v809, 1
  %v812 = icmp ne i64 %v811, 0
  %v813 = icmp ult i64 %v810, %v806
  %v814 = and i1 %v812, %v813
  br i1 %v814, label %array.valid.815, label %array.invalid.816
array.invalid.816:
  call void @mlf_bounds_failure()
  unreachable
array.valid.815:
  %v817 = getelementptr i8, ptr %v808, i64 %v810
  %v818 = load i8, ptr %v817, align 1, !tbaa !4
  %v819 = zext i8 %v818 to i64
  %v820 = shl i64 %v819, 1
  %v821 = or i64 %v820, 1
  %v822 = inttoptr i64 %v821 to ptr
  %v823 = ptrtoint ptr %a4 to i64
  %v824 = ptrtoint ptr %a6 to i64
  %v825 = and i64 %v823, %v824
  %v826 = and i64 %v825, 1
  %v827 = icmp ne i64 %v826, 0
  br i1 %v827, label %yes.828, label %no.829
yes.828:
  %v831 = sub i64 %v824, 1
  %v832 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v823, i64 %v831)
  %v833 = extractvalue { i64, i1 } %v832, 0
  %v834 = extractvalue { i64, i1 } %v832, 1
  br i1 %v834, label %yes.835, label %no.836
yes.835:
  %v838 = call ptr @mlf_add_int(ptr %a4, ptr %a6)
  br label %join.837
no.836:
  %v839 = inttoptr i64 %v833 to ptr
  br label %join.837
join.837:
  %v840 = phi ptr [ %v838, %yes.835 ], [ %v839, %no.836 ]
  br label %join.830
no.829:
  %v841 = call ptr @mlf_add_int(ptr %a4, ptr %a6)
  br label %join.830
join.830:
  %v842 = phi ptr [ %v840, %join.837 ], [ %v841, %no.829 ]
  %v843 = getelementptr i8, ptr %a2, i64 8
  %v844 = load i64, ptr %v843, align 8, !tbaa !3
  %v845 = getelementptr i8, ptr %a2, i64 16
  %v846 = load ptr, ptr %v845, align 8, !tbaa !3
  %v847 = ptrtoint ptr %v842 to i64
  %v848 = ashr i64 %v847, 1
  %v849 = and i64 %v847, 1
  %v850 = icmp ne i64 %v849, 0
  %v851 = icmp ult i64 %v848, %v844
  %v852 = and i1 %v850, %v851
  br i1 %v852, label %array.valid.853, label %array.invalid.854
array.invalid.854:
  call void @mlf_bounds_failure()
  unreachable
array.valid.853:
  %v855 = getelementptr i8, ptr %v846, i64 %v848
  %v856 = ptrtoint ptr %v822 to i64
  %v857 = ashr i64 %v856, 1
  %v858 = trunc i64 %v857 to i8
  store i8 %v858, ptr %v855, align 1, !tbaa !4
  %v859 = ptrtoint ptr %a6 to i64
  %v860 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v861 = and i64 %v859, %v860
  %v862 = and i64 %v861, 1
  %v863 = icmp ne i64 %v862, 0
  br i1 %v863, label %yes.864, label %no.865
yes.864:
  %v867 = sub i64 %v860, 1
  %v868 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v859, i64 %v867)
  %v869 = extractvalue { i64, i1 } %v868, 0
  %v870 = extractvalue { i64, i1 } %v868, 1
  br i1 %v870, label %yes.871, label %no.872
yes.871:
  %v874 = call ptr @mlf_add_int(ptr %a6, ptr inttoptr (i64 3 to ptr))
  br label %join.873
no.872:
  %v875 = inttoptr i64 %v869 to ptr
  br label %join.873
join.873:
  %v876 = phi ptr [ %v874, %yes.871 ], [ %v875, %no.872 ]
  br label %join.866
no.865:
  %v877 = call ptr @mlf_add_int(ptr %a6, ptr inttoptr (i64 3 to ptr))
  br label %join.866
join.866:
  %v878 = phi ptr [ %v876, %join.873 ], [ %v877, %no.865 ]
  %v879 = musttail call ptr @mlf.numeric.24(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %v878)
  ret ptr %v879
tail.no.766:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.numeric.35(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5) alwaysinline {
entry:
  %v538 = ptrtoint ptr %a3 to i64
  %v539 = and i64 %v538, 1
  %v540 = icmp ne i64 %v539, 0
  %v541 = icmp ult i64 %v538, 4294967296
  %v542 = and i1 %v540, %v541
  %v543 = ptrtoint ptr %a4 to i64
  %v544 = and i64 %v543, 1
  %v545 = icmp ne i64 %v544, 0
  %v546 = icmp ult i64 %v543, 4294967296
  %v547 = and i1 %v545, %v546
  %v548 = ptrtoint ptr %a5 to i64
  %v549 = and i64 %v548, 1
  %v550 = icmp ne i64 %v549, 0
  %v551 = icmp ult i64 %v548, 4294967296
  %v552 = and i1 %v550, %v551
  %v553 = and i1 true, %v542
  %v554 = and i1 %v553, %v547
  %v555 = and i1 %v554, %v552
  br i1 %v555, label %range.fast.556, label %range.general.557
range.fast.556:
  %v692 = musttail call ptr @mlf.numeric.35.pppiii(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5)
  ret ptr %v692
range.general.557:
  %v693 = ptrtoint ptr %a4 to i64
  %v694 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v695 = and i64 %v693, %v694
  %v696 = and i64 %v695, 1
  %v697 = icmp ne i64 %v696, 0
  br i1 %v697, label %yes.698, label %no.699
yes.698:
  %v701 = icmp eq i64 %v693, %v694
  %v702 = select i1 %v701, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.700
no.699:
  %v703 = call ptr @mlf_eq_int(ptr %a4, ptr inttoptr (i64 1 to ptr))
  br label %join.700
join.700:
  %v704 = phi ptr [ %v702, %yes.698 ], [ %v703, %no.699 ]
  %v705 = icmp eq ptr %v704, inttoptr (i64 6 to ptr)
  br i1 %v705, label %tail.yes.706, label %tail.no.707
tail.yes.706:
  ret ptr inttoptr (i64 4 to ptr)
tail.no.707:
  %v708 = ptrtoint ptr %a4 to i64
  %v709 = ptrtoint ptr inttoptr (i64 121 to ptr) to i64
  %v710 = and i64 %v708, %v709
  %v711 = and i64 %v710, 1
  %v712 = icmp ne i64 %v711, 0
  br i1 %v712, label %yes.713, label %no.714
yes.713:
  %v716 = icmp slt i64 %v708, %v709
  %v717 = select i1 %v716, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.715
no.714:
  %v718 = call ptr @mlf_lt_int(ptr %a4, ptr inttoptr (i64 121 to ptr))
  br label %join.715
join.715:
  %v719 = phi ptr [ %v717, %yes.713 ], [ %v718, %no.714 ]
  %v720 = icmp eq ptr %v719, inttoptr (i64 6 to ptr)
  br i1 %v720, label %yes.721, label %no.722
yes.721:
  br label %join.723
no.722:
  br label %join.723
join.723:
  %v724 = phi ptr [ %a4, %yes.721 ], [ inttoptr (i64 121 to ptr), %no.722 ]
  %v880 = call ptr @mlf.numeric.24(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a5, ptr %v724, ptr inttoptr (i64 1 to ptr))
  %v881 = ptrtoint ptr %a5 to i64
  %v882 = ptrtoint ptr %v724 to i64
  %v883 = and i64 %v881, %v882
  %v884 = and i64 %v883, 1
  %v885 = icmp ne i64 %v884, 0
  br i1 %v885, label %yes.886, label %no.887
yes.886:
  %v889 = sub i64 %v882, 1
  %v890 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v881, i64 %v889)
  %v891 = extractvalue { i64, i1 } %v890, 0
  %v892 = extractvalue { i64, i1 } %v890, 1
  br i1 %v892, label %yes.893, label %no.894
yes.893:
  %v896 = call ptr @mlf_add_int(ptr %a5, ptr %v724)
  br label %join.895
no.894:
  %v897 = inttoptr i64 %v891 to ptr
  br label %join.895
join.895:
  %v898 = phi ptr [ %v896, %yes.893 ], [ %v897, %no.894 ]
  br label %join.888
no.887:
  %v899 = call ptr @mlf_add_int(ptr %a5, ptr %v724)
  br label %join.888
join.888:
  %v900 = phi ptr [ %v898, %join.895 ], [ %v899, %no.887 ]
  %v901 = getelementptr i8, ptr %a2, i64 8
  %v902 = load i64, ptr %v901, align 8, !tbaa !3
  %v903 = getelementptr i8, ptr %a2, i64 16
  %v904 = load ptr, ptr %v903, align 8, !tbaa !3
  %v905 = ptrtoint ptr %v900 to i64
  %v906 = ashr i64 %v905, 1
  %v907 = and i64 %v905, 1
  %v908 = icmp ne i64 %v907, 0
  %v909 = icmp ult i64 %v906, %v902
  %v910 = and i1 %v908, %v909
  br i1 %v910, label %array.valid.911, label %array.invalid.912
array.invalid.912:
  call void @mlf_bounds_failure()
  unreachable
array.valid.911:
  %v913 = getelementptr i8, ptr %v904, i64 %v906
  %v914 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v915 = ashr i64 %v914, 1
  %v916 = trunc i64 %v915 to i8
  store i8 %v916, ptr %v913, align 1, !tbaa !4
  %v917 = ptrtoint ptr %a3 to i64
  %v918 = ptrtoint ptr %v724 to i64
  %v919 = and i64 %v917, %v918
  %v920 = and i64 %v919, 1
  %v921 = icmp ne i64 %v920, 0
  br i1 %v921, label %yes.922, label %no.923
yes.922:
  %v925 = sub i64 %v918, 1
  %v926 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v917, i64 %v925)
  %v927 = extractvalue { i64, i1 } %v926, 0
  %v928 = extractvalue { i64, i1 } %v926, 1
  br i1 %v928, label %yes.929, label %no.930
yes.929:
  %v932 = call ptr @mlf_sub_int(ptr %a3, ptr %v724)
  br label %join.931
no.930:
  %v933 = inttoptr i64 %v927 to ptr
  br label %join.931
join.931:
  %v934 = phi ptr [ %v932, %yes.929 ], [ %v933, %no.930 ]
  br label %join.924
no.923:
  %v935 = call ptr @mlf_sub_int(ptr %a3, ptr %v724)
  br label %join.924
join.924:
  %v936 = phi ptr [ %v934, %join.931 ], [ %v935, %no.923 ]
  %v937 = ptrtoint ptr %a4 to i64
  %v938 = ptrtoint ptr %v724 to i64
  %v939 = and i64 %v937, %v938
  %v940 = and i64 %v939, 1
  %v941 = icmp ne i64 %v940, 0
  br i1 %v941, label %yes.942, label %no.943
yes.942:
  %v945 = sub i64 %v938, 1
  %v946 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v937, i64 %v945)
  %v947 = extractvalue { i64, i1 } %v946, 0
  %v948 = extractvalue { i64, i1 } %v946, 1
  br i1 %v948, label %yes.949, label %no.950
yes.949:
  %v952 = call ptr @mlf_sub_int(ptr %a4, ptr %v724)
  br label %join.951
no.950:
  %v953 = inttoptr i64 %v947 to ptr
  br label %join.951
join.951:
  %v954 = phi ptr [ %v952, %yes.949 ], [ %v953, %no.950 ]
  br label %join.944
no.943:
  %v955 = call ptr @mlf_sub_int(ptr %a4, ptr %v724)
  br label %join.944
join.944:
  %v956 = phi ptr [ %v954, %join.951 ], [ %v955, %no.943 ]
  %v957 = ptrtoint ptr %a5 to i64
  %v958 = ptrtoint ptr %v724 to i64
  %v959 = and i64 %v957, %v958
  %v960 = and i64 %v959, 1
  %v961 = icmp ne i64 %v960, 0
  br i1 %v961, label %yes.962, label %no.963
yes.962:
  %v965 = sub i64 %v958, 1
  %v966 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v957, i64 %v965)
  %v967 = extractvalue { i64, i1 } %v966, 0
  %v968 = extractvalue { i64, i1 } %v966, 1
  br i1 %v968, label %yes.969, label %no.970
yes.969:
  %v972 = call ptr @mlf_add_int(ptr %a5, ptr %v724)
  br label %join.971
no.970:
  %v973 = inttoptr i64 %v967 to ptr
  br label %join.971
join.971:
  %v974 = phi ptr [ %v972, %yes.969 ], [ %v973, %no.970 ]
  br label %join.964
no.963:
  %v975 = call ptr @mlf_add_int(ptr %a5, ptr %v724)
  br label %join.964
join.964:
  %v976 = phi ptr [ %v974, %join.971 ], [ %v975, %no.963 ]
  %v977 = ptrtoint ptr %v976 to i64
  %v978 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v979 = and i64 %v977, %v978
  %v980 = and i64 %v979, 1
  %v981 = icmp ne i64 %v980, 0
  br i1 %v981, label %yes.982, label %no.983
yes.982:
  %v985 = sub i64 %v978, 1
  %v986 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v977, i64 %v985)
  %v987 = extractvalue { i64, i1 } %v986, 0
  %v988 = extractvalue { i64, i1 } %v986, 1
  br i1 %v988, label %yes.989, label %no.990
yes.989:
  %v992 = call ptr @mlf_add_int(ptr %v976, ptr inttoptr (i64 3 to ptr))
  br label %join.991
no.990:
  %v993 = inttoptr i64 %v987 to ptr
  br label %join.991
join.991:
  %v994 = phi ptr [ %v992, %yes.989 ], [ %v993, %no.990 ]
  br label %join.984
no.983:
  %v995 = call ptr @mlf_add_int(ptr %v976, ptr inttoptr (i64 3 to ptr))
  br label %join.984
join.984:
  %v996 = phi ptr [ %v994, %join.991 ], [ %v995, %no.983 ]
  %v997 = musttail call ptr @mlf.numeric.35(ptr %a0, ptr %a1, ptr %a2, ptr %v936, ptr %v956, ptr %v996)
  ret ptr %v997
}

define private ptr @mlf.numeric.45(ptr %a0, ptr %a1, ptr %a2, ptr %a3) alwaysinline {
entry:
  %v486 = ptrtoint ptr %a3 to i64
  %v487 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v488 = and i64 %v486, %v487
  %v489 = and i64 %v488, 1
  %v490 = icmp ne i64 %v489, 0
  br i1 %v490, label %yes.491, label %no.492
yes.491:
  %v494 = icmp eq i64 %v486, %v487
  %v495 = select i1 %v494, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.493
no.492:
  %v496 = call ptr @mlf_eq_int(ptr %a3, ptr inttoptr (i64 1 to ptr))
  br label %join.493
join.493:
  %v497 = phi ptr [ %v495, %yes.491 ], [ %v496, %no.492 ]
  %v498 = icmp eq ptr %v497, inttoptr (i64 6 to ptr)
  br i1 %v498, label %tail.yes.499, label %tail.no.500
tail.yes.499:
  ret ptr inttoptr (i64 4 to ptr)
tail.no.500:
  %v501 = ptrtoint ptr %a3 to i64
  %v502 = ptrtoint ptr inttoptr (i64 122881 to ptr) to i64
  %v503 = and i64 %v501, %v502
  %v504 = and i64 %v503, 1
  %v505 = icmp ne i64 %v504, 0
  br i1 %v505, label %yes.506, label %no.507
yes.506:
  %v509 = icmp slt i64 %v501, %v502
  %v510 = select i1 %v509, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.508
no.507:
  %v511 = call ptr @mlf_lt_int(ptr %a3, ptr inttoptr (i64 122881 to ptr))
  br label %join.508
join.508:
  %v512 = phi ptr [ %v510, %yes.506 ], [ %v511, %no.507 ]
  %v513 = icmp eq ptr %v512, inttoptr (i64 6 to ptr)
  br i1 %v513, label %yes.514, label %no.515
yes.514:
  br label %join.516
no.515:
  br label %join.516
join.516:
  %v517 = phi ptr [ %a3, %yes.514 ], [ inttoptr (i64 122881 to ptr), %no.515 ]
  %v518 = ptrtoint ptr %a3 to i64
  %v519 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v520 = and i64 %v518, %v519
  %v521 = and i64 %v520, 1
  %v522 = icmp ne i64 %v521, 0
  br i1 %v522, label %yes.523, label %no.524
yes.523:
  %v526 = sub i64 %v519, 1
  %v527 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v518, i64 %v526)
  %v528 = extractvalue { i64, i1 } %v527, 0
  %v529 = extractvalue { i64, i1 } %v527, 1
  br i1 %v529, label %yes.530, label %no.531
yes.530:
  %v533 = call ptr @mlf_sub_int(ptr %a3, ptr inttoptr (i64 3 to ptr))
  br label %join.532
no.531:
  %v534 = inttoptr i64 %v528 to ptr
  br label %join.532
join.532:
  %v535 = phi ptr [ %v533, %yes.530 ], [ %v534, %no.531 ]
  br label %join.525
no.524:
  %v536 = call ptr @mlf_sub_int(ptr %a3, ptr inttoptr (i64 3 to ptr))
  br label %join.525
join.525:
  %v537 = phi ptr [ %v535, %join.532 ], [ %v536, %no.524 ]
  %v998 = call ptr @mlf.numeric.35(ptr %a0, ptr %a2, ptr %a1, ptr %v537, ptr %v517, ptr inttoptr (i64 1 to ptr))
  %v999 = ptrtoint ptr %v517 to i64
  %v1000 = ptrtoint ptr inttoptr (i64 119 to ptr) to i64
  %v1001 = and i64 %v999, %v1000
  %v1002 = and i64 %v1001, 1
  %v1003 = icmp ne i64 %v1002, 0
  br i1 %v1003, label %yes.1004, label %no.1005
yes.1004:
  %v1007 = sub i64 %v1000, 1
  %v1008 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v999, i64 %v1007)
  %v1009 = extractvalue { i64, i1 } %v1008, 0
  %v1010 = extractvalue { i64, i1 } %v1008, 1
  br i1 %v1010, label %yes.1011, label %no.1012
yes.1011:
  %v1014 = call ptr @mlf_add_int(ptr %v517, ptr inttoptr (i64 119 to ptr))
  br label %join.1013
no.1012:
  %v1015 = inttoptr i64 %v1009 to ptr
  br label %join.1013
join.1013:
  %v1016 = phi ptr [ %v1014, %yes.1011 ], [ %v1015, %no.1012 ]
  br label %join.1006
no.1005:
  %v1017 = call ptr @mlf_add_int(ptr %v517, ptr inttoptr (i64 119 to ptr))
  br label %join.1006
join.1006:
  %v1018 = phi ptr [ %v1016, %join.1013 ], [ %v1017, %no.1005 ]
  %v1019 = ptrtoint ptr %v1018 to i64
  %v1020 = ptrtoint ptr inttoptr (i64 121 to ptr) to i64
  %v1021 = and i64 %v1019, %v1020
  %v1022 = and i64 %v1021, 1
  %v1023 = icmp ne i64 %v1022, 0
  br i1 %v1023, label %yes.1024, label %no.1025
yes.1024:
  %v1027 = ashr i64 %v1019, 1
  %v1028 = ashr i64 %v1020, 1
  %v1029 = icmp ne i64 %v1028, 0
  %v1030 = icmp eq i64 %v1027, -4611686018427387904
  %v1031 = icmp eq i64 %v1028, -1
  %v1032 = and i1 %v1030, %v1031
  %v1033 = xor i1 %v1032, true
  %v1034 = and i1 %v1029, %v1033
  br i1 %v1034, label %yes.1035, label %no.1036
yes.1035:
  %v1038 = sdiv i64 %v1027, %v1028
  %v1039 = shl i64 %v1038, 1
  %v1040 = or i64 %v1039, 1
  %v1041 = inttoptr i64 %v1040 to ptr
  br label %join.1037
no.1036:
  %v1042 = call ptr @mlf_prim2(i64 15, ptr %v1018, ptr inttoptr (i64 121 to ptr))
  br label %join.1037
join.1037:
  %v1043 = phi ptr [ %v1041, %yes.1035 ], [ %v1042, %no.1036 ]
  br label %join.1026
no.1025:
  %v1044 = call ptr @mlf_prim2(i64 15, ptr %v1018, ptr inttoptr (i64 121 to ptr))
  br label %join.1026
join.1026:
  %v1045 = phi ptr [ %v1043, %join.1037 ], [ %v1044, %no.1025 ]
  %v1046 = ptrtoint ptr %v517 to i64
  %v1047 = ptrtoint ptr %v1045 to i64
  %v1048 = and i64 %v1046, %v1047
  %v1049 = and i64 %v1048, 1
  %v1050 = icmp ne i64 %v1049, 0
  br i1 %v1050, label %yes.1051, label %no.1052
yes.1051:
  %v1054 = sub i64 %v1047, 1
  %v1055 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1046, i64 %v1054)
  %v1056 = extractvalue { i64, i1 } %v1055, 0
  %v1057 = extractvalue { i64, i1 } %v1055, 1
  br i1 %v1057, label %yes.1058, label %no.1059
yes.1058:
  %v1061 = call ptr @mlf_add_int(ptr %v517, ptr %v1045)
  br label %join.1060
no.1059:
  %v1062 = inttoptr i64 %v1056 to ptr
  br label %join.1060
join.1060:
  %v1063 = phi ptr [ %v1061, %yes.1058 ], [ %v1062, %no.1059 ]
  br label %join.1053
no.1052:
  %v1064 = call ptr @mlf_add_int(ptr %v517, ptr %v1045)
  br label %join.1053
join.1053:
  %v1065 = phi ptr [ %v1063, %join.1060 ], [ %v1064, %no.1052 ]
  %v1066 = call ptr @mlf_put_bytes(ptr %a1, ptr inttoptr (i64 1 to ptr), ptr %v1065)
  %v1067 = ptrtoint ptr %a3 to i64
  %v1068 = ptrtoint ptr %v517 to i64
  %v1069 = and i64 %v1067, %v1068
  %v1070 = and i64 %v1069, 1
  %v1071 = icmp ne i64 %v1070, 0
  br i1 %v1071, label %yes.1072, label %no.1073
yes.1072:
  %v1075 = sub i64 %v1068, 1
  %v1076 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v1067, i64 %v1075)
  %v1077 = extractvalue { i64, i1 } %v1076, 0
  %v1078 = extractvalue { i64, i1 } %v1076, 1
  br i1 %v1078, label %yes.1079, label %no.1080
yes.1079:
  %v1082 = call ptr @mlf_sub_int(ptr %a3, ptr %v517)
  br label %join.1081
no.1080:
  %v1083 = inttoptr i64 %v1077 to ptr
  br label %join.1081
join.1081:
  %v1084 = phi ptr [ %v1082, %yes.1079 ], [ %v1083, %no.1080 ]
  br label %join.1074
no.1073:
  %v1085 = call ptr @mlf_sub_int(ptr %a3, ptr %v517)
  br label %join.1074
join.1074:
  %v1086 = phi ptr [ %v1084, %join.1081 ], [ %v1085, %no.1073 ]
  %v1087 = musttail call ptr @mlf.numeric.45(ptr %a0, ptr %a1, ptr %a2, ptr %v1086)
  ret ptr %v1087
}

define private ptr @mlf.numeric.11.pi(ptr %a0, ptr %a1) alwaysinline {
entry:
  %v1121 = ptrtoint ptr %a1 to i64
  %v1122 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v1123 = icmp eq i64 %v1121, %v1122
  %v1124 = select i1 %v1123, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1125 = icmp eq ptr %v1124, inttoptr (i64 6 to ptr)
  br i1 %v1125, label %tail.yes.1126, label %tail.no.1127
tail.yes.1126:
  ret ptr inttoptr (i64 1 to ptr)
tail.no.1127:
  %v1128 = ptrtoint ptr %a1 to i64
  %v1129 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1130 = sub i64 %v1129, 1
  %v1131 = sub nsw i64 %v1128, %v1130
  %v1132 = inttoptr i64 %v1131 to ptr
  %v1133 = getelementptr i8, ptr %a0, i64 8
  %v1134 = load i64, ptr %v1133, align 8, !tbaa !3
  %v1135 = getelementptr i8, ptr %a0, i64 16
  %v1136 = load ptr, ptr %v1135, align 8, !tbaa !3
  %v1137 = ptrtoint ptr %v1132 to i64
  %v1138 = ashr i64 %v1137, 1
  %v1139 = and i64 %v1137, 1
  %v1140 = icmp ne i64 %v1139, 0
  %v1141 = icmp ult i64 %v1138, %v1134
  %v1142 = and i1 %v1140, %v1141
  br i1 %v1142, label %array.valid.1143, label %array.invalid.1144
array.invalid.1144:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1143:
  %v1145 = getelementptr i8, ptr %v1136, i64 %v1138
  %v1146 = load i8, ptr %v1145, align 1, !tbaa !4
  %v1147 = zext i8 %v1146 to i64
  %v1148 = shl i64 %v1147, 1
  %v1149 = or i64 %v1148, 1
  %v1150 = inttoptr i64 %v1149 to ptr
  %v1151 = ptrtoint ptr %v1150 to i64
  %v1152 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v1153 = icmp eq i64 %v1151, %v1152
  %v1154 = select i1 %v1153, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1155 = icmp eq ptr %v1154, inttoptr (i64 6 to ptr)
  br i1 %v1155, label %tail.yes.1156, label %tail.no.1157
tail.yes.1156:
  %v1158 = ptrtoint ptr %a1 to i64
  %v1159 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1160 = sub i64 %v1159, 1
  %v1161 = sub nsw i64 %v1158, %v1160
  %v1162 = inttoptr i64 %v1161 to ptr
  %v1163 = musttail call ptr @mlf.numeric.11.pi(ptr %a0, ptr %v1162)
  ret ptr %v1163
tail.no.1157:
  %v1164 = ptrtoint ptr %v1150 to i64
  %v1165 = ptrtoint ptr inttoptr (i64 27 to ptr) to i64
  %v1166 = icmp eq i64 %v1164, %v1165
  %v1167 = select i1 %v1166, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1168 = icmp eq ptr %v1167, inttoptr (i64 6 to ptr)
  br i1 %v1168, label %tail.yes.1169, label %tail.no.1170
tail.yes.1169:
  %v1171 = ptrtoint ptr %a1 to i64
  %v1172 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1173 = sub i64 %v1172, 1
  %v1174 = sub nsw i64 %v1171, %v1173
  %v1175 = inttoptr i64 %v1174 to ptr
  %v1176 = musttail call ptr @mlf.numeric.11.pi(ptr %a0, ptr %v1175)
  ret ptr %v1176
tail.no.1170:
  ret ptr %a1
}

define private ptr @mlf.numeric.11(ptr %a0, ptr %a1) alwaysinline {
entry:
  %v1113 = ptrtoint ptr %a1 to i64
  %v1114 = and i64 %v1113, 1
  %v1115 = icmp ne i64 %v1114, 0
  %v1116 = icmp ult i64 %v1113, 4294967296
  %v1117 = and i1 %v1115, %v1116
  %v1118 = and i1 true, %v1117
  br i1 %v1118, label %range.fast.1119, label %range.general.1120
range.fast.1119:
  %v1177 = musttail call ptr @mlf.numeric.11.pi(ptr %a0, ptr %a1)
  ret ptr %v1177
range.general.1120:
  %v1178 = ptrtoint ptr %a1 to i64
  %v1179 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v1180 = and i64 %v1178, %v1179
  %v1181 = and i64 %v1180, 1
  %v1182 = icmp ne i64 %v1181, 0
  br i1 %v1182, label %yes.1183, label %no.1184
yes.1183:
  %v1186 = icmp eq i64 %v1178, %v1179
  %v1187 = select i1 %v1186, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1185
no.1184:
  %v1188 = call ptr @mlf_eq_int(ptr %a1, ptr inttoptr (i64 1 to ptr))
  br label %join.1185
join.1185:
  %v1189 = phi ptr [ %v1187, %yes.1183 ], [ %v1188, %no.1184 ]
  %v1190 = icmp eq ptr %v1189, inttoptr (i64 6 to ptr)
  br i1 %v1190, label %tail.yes.1191, label %tail.no.1192
tail.yes.1191:
  ret ptr inttoptr (i64 1 to ptr)
tail.no.1192:
  %v1193 = ptrtoint ptr %a1 to i64
  %v1194 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1195 = and i64 %v1193, %v1194
  %v1196 = and i64 %v1195, 1
  %v1197 = icmp ne i64 %v1196, 0
  br i1 %v1197, label %yes.1198, label %no.1199
yes.1198:
  %v1201 = sub i64 %v1194, 1
  %v1202 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v1193, i64 %v1201)
  %v1203 = extractvalue { i64, i1 } %v1202, 0
  %v1204 = extractvalue { i64, i1 } %v1202, 1
  br i1 %v1204, label %yes.1205, label %no.1206
yes.1205:
  %v1208 = call ptr @mlf_sub_int(ptr %a1, ptr inttoptr (i64 3 to ptr))
  br label %join.1207
no.1206:
  %v1209 = inttoptr i64 %v1203 to ptr
  br label %join.1207
join.1207:
  %v1210 = phi ptr [ %v1208, %yes.1205 ], [ %v1209, %no.1206 ]
  br label %join.1200
no.1199:
  %v1211 = call ptr @mlf_sub_int(ptr %a1, ptr inttoptr (i64 3 to ptr))
  br label %join.1200
join.1200:
  %v1212 = phi ptr [ %v1210, %join.1207 ], [ %v1211, %no.1199 ]
  %v1213 = getelementptr i8, ptr %a0, i64 8
  %v1214 = load i64, ptr %v1213, align 8, !tbaa !3
  %v1215 = getelementptr i8, ptr %a0, i64 16
  %v1216 = load ptr, ptr %v1215, align 8, !tbaa !3
  %v1217 = ptrtoint ptr %v1212 to i64
  %v1218 = ashr i64 %v1217, 1
  %v1219 = and i64 %v1217, 1
  %v1220 = icmp ne i64 %v1219, 0
  %v1221 = icmp ult i64 %v1218, %v1214
  %v1222 = and i1 %v1220, %v1221
  br i1 %v1222, label %array.valid.1223, label %array.invalid.1224
array.invalid.1224:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1223:
  %v1225 = getelementptr i8, ptr %v1216, i64 %v1218
  %v1226 = load i8, ptr %v1225, align 1, !tbaa !4
  %v1227 = zext i8 %v1226 to i64
  %v1228 = shl i64 %v1227, 1
  %v1229 = or i64 %v1228, 1
  %v1230 = inttoptr i64 %v1229 to ptr
  %v1231 = ptrtoint ptr %v1230 to i64
  %v1232 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v1233 = icmp eq i64 %v1231, %v1232
  %v1234 = select i1 %v1233, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1235 = icmp eq ptr %v1234, inttoptr (i64 6 to ptr)
  br i1 %v1235, label %tail.yes.1236, label %tail.no.1237
tail.yes.1236:
  %v1238 = ptrtoint ptr %a1 to i64
  %v1239 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1240 = and i64 %v1238, %v1239
  %v1241 = and i64 %v1240, 1
  %v1242 = icmp ne i64 %v1241, 0
  br i1 %v1242, label %yes.1243, label %no.1244
yes.1243:
  %v1246 = sub i64 %v1239, 1
  %v1247 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v1238, i64 %v1246)
  %v1248 = extractvalue { i64, i1 } %v1247, 0
  %v1249 = extractvalue { i64, i1 } %v1247, 1
  br i1 %v1249, label %yes.1250, label %no.1251
yes.1250:
  %v1253 = call ptr @mlf_sub_int(ptr %a1, ptr inttoptr (i64 3 to ptr))
  br label %join.1252
no.1251:
  %v1254 = inttoptr i64 %v1248 to ptr
  br label %join.1252
join.1252:
  %v1255 = phi ptr [ %v1253, %yes.1250 ], [ %v1254, %no.1251 ]
  br label %join.1245
no.1244:
  %v1256 = call ptr @mlf_sub_int(ptr %a1, ptr inttoptr (i64 3 to ptr))
  br label %join.1245
join.1245:
  %v1257 = phi ptr [ %v1255, %join.1252 ], [ %v1256, %no.1244 ]
  %v1258 = musttail call ptr @mlf.numeric.11(ptr %a0, ptr %v1257)
  ret ptr %v1258
tail.no.1237:
  %v1259 = ptrtoint ptr %v1230 to i64
  %v1260 = ptrtoint ptr inttoptr (i64 27 to ptr) to i64
  %v1261 = icmp eq i64 %v1259, %v1260
  %v1262 = select i1 %v1261, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1263 = icmp eq ptr %v1262, inttoptr (i64 6 to ptr)
  br i1 %v1263, label %tail.yes.1264, label %tail.no.1265
tail.yes.1264:
  %v1266 = ptrtoint ptr %a1 to i64
  %v1267 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1268 = and i64 %v1266, %v1267
  %v1269 = and i64 %v1268, 1
  %v1270 = icmp ne i64 %v1269, 0
  br i1 %v1270, label %yes.1271, label %no.1272
yes.1271:
  %v1274 = sub i64 %v1267, 1
  %v1275 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v1266, i64 %v1274)
  %v1276 = extractvalue { i64, i1 } %v1275, 0
  %v1277 = extractvalue { i64, i1 } %v1275, 1
  br i1 %v1277, label %yes.1278, label %no.1279
yes.1278:
  %v1281 = call ptr @mlf_sub_int(ptr %a1, ptr inttoptr (i64 3 to ptr))
  br label %join.1280
no.1279:
  %v1282 = inttoptr i64 %v1276 to ptr
  br label %join.1280
join.1280:
  %v1283 = phi ptr [ %v1281, %yes.1278 ], [ %v1282, %no.1279 ]
  br label %join.1273
no.1272:
  %v1284 = call ptr @mlf_sub_int(ptr %a1, ptr inttoptr (i64 3 to ptr))
  br label %join.1273
join.1273:
  %v1285 = phi ptr [ %v1283, %join.1280 ], [ %v1284, %no.1272 ]
  %v1286 = musttail call ptr @mlf.numeric.11(ptr %a0, ptr %v1285)
  ret ptr %v1286
tail.no.1265:
  ret ptr %a1
}

define private ptr @mlf.numeric.8(ptr %a0, ptr %a1) alwaysinline {
entry:
  %v1323 = ptrtoint ptr %a0 to i64
  %v1324 = ptrtoint ptr %a1 to i64
  %v1325 = and i64 %v1323, %v1324
  %v1326 = and i64 %v1325, 1
  %v1327 = icmp ne i64 %v1326, 0
  br i1 %v1327, label %yes.1328, label %no.1329
yes.1328:
  %v1331 = icmp slt i64 %v1323, %v1324
  %v1332 = select i1 %v1331, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1330
no.1329:
  %v1333 = call ptr @mlf_lt_int(ptr %a0, ptr %a1)
  br label %join.1330
join.1330:
  %v1334 = phi ptr [ %v1332, %yes.1328 ], [ %v1333, %no.1329 ]
  %v1335 = icmp eq ptr %v1334, inttoptr (i64 6 to ptr)
  br i1 %v1335, label %tail.yes.1336, label %tail.no.1337
tail.yes.1336:
  %v1338 = ptrtoint ptr %a0 to i64
  %v1339 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v1340 = and i64 %v1338, %v1339
  %v1341 = and i64 %v1340, 1
  %v1342 = icmp ne i64 %v1341, 0
  br i1 %v1342, label %yes.1343, label %no.1344
yes.1343:
  %v1346 = ashr i64 %v1338, 1
  %v1347 = ashr i64 %v1339, 1
  %v1348 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v1346, i64 %v1347)
  %v1349 = extractvalue { i64, i1 } %v1348, 0
  %v1350 = extractvalue { i64, i1 } %v1348, 1
  %v1351 = xor i1 %v1350, true
  %v1352 = icmp sge i64 %v1349, -4611686018427387904
  %v1353 = icmp sle i64 %v1349, 4611686018427387903
  %v1354 = and i1 %v1352, %v1353
  %v1355 = and i1 %v1354, %v1351
  br i1 %v1355, label %yes.1356, label %no.1357
yes.1356:
  %v1359 = shl i64 %v1349, 1
  %v1360 = or i64 %v1359, 1
  %v1361 = inttoptr i64 %v1360 to ptr
  br label %join.1358
no.1357:
  %v1362 = call ptr @mlf_prim2(i64 14, ptr %a0, ptr inttoptr (i64 5 to ptr))
  br label %join.1358
join.1358:
  %v1363 = phi ptr [ %v1361, %yes.1356 ], [ %v1362, %no.1357 ]
  br label %join.1345
no.1344:
  %v1364 = call ptr @mlf_prim2(i64 14, ptr %a0, ptr inttoptr (i64 5 to ptr))
  br label %join.1345
join.1345:
  %v1365 = phi ptr [ %v1363, %join.1358 ], [ %v1364, %no.1344 ]
  %v1366 = musttail call ptr @mlf.numeric.8(ptr %v1365, ptr %a1)
  ret ptr %v1366
tail.no.1337:
  ret ptr %a0
}

define private ptr @mlf.numeric.0(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) alwaysinline {
entry:
  %v1369 = getelementptr i8, ptr %a0, i64 8
  %v1370 = load i64, ptr %v1369, align 8, !tbaa !3
  %v1371 = getelementptr i8, ptr %a0, i64 16
  %v1372 = load ptr, ptr %v1371, align 8, !tbaa !3
  %v1373 = getelementptr i8, ptr %a1, i64 8
  %v1374 = load i64, ptr %v1373, align 8, !tbaa !3
  %v1375 = getelementptr i8, ptr %a1, i64 16
  %v1376 = load ptr, ptr %v1375, align 8, !tbaa !3
  %v1377 = ptrtoint ptr %a2 to i64
  %v1378 = ptrtoint ptr %a3 to i64
  %v1379 = ptrtoint ptr %a4 to i64
  %v1380 = and i64 %v1377, 1
  %v1381 = icmp ne i64 %v1380, 0
  %v1382 = and i64 %v1378, 1
  %v1383 = icmp ne i64 %v1382, 0
  %v1384 = and i64 %v1379, 1
  %v1385 = icmp ne i64 %v1384, 0
  %v1386 = ashr i64 %v1377, 1
  %v1387 = ashr i64 %v1378, 1
  %v1388 = ashr i64 %v1379, 1
  %v1389 = icmp sge i64 %v1388, 0
  %v1390 = icmp sge i64 %v1386, %v1388
  %v1391 = icmp ule i64 %v1386, %v1370
  %v1392 = icmp ule i64 %v1387, %v1374
  %v1393 = sub i64 %v1374, %v1387
  %v1394 = icmp ule i64 %v1386, %v1393
  %v1395 = sub i64 %v1386, %v1388
  %v1396 = icmp ne ptr %v1372, %v1376
  %v1397 = icmp eq i64 %v1387, 0
  %v1398 = icmp uge i64 %v1387, %v1395
  %v1399 = or i1 %v1396, %v1397
  %v1400 = or i1 %v1399, %v1398
  %v1401 = and i1 true, %v1381
  %v1402 = and i1 %v1401, %v1383
  %v1403 = and i1 %v1402, %v1385
  %v1404 = and i1 %v1403, %v1389
  %v1405 = and i1 %v1404, %v1390
  %v1406 = and i1 %v1405, %v1391
  %v1407 = and i1 %v1406, %v1392
  %v1408 = and i1 %v1407, %v1394
  %v1409 = and i1 %v1408, %v1400
  br i1 %v1409, label %copy.bulk.1410, label %copy.scalar.1411
copy.bulk.1410:
  %v1412 = getelementptr i8, ptr %v1372, i64 %v1388
  %v1413 = add i64 %v1387, %v1388
  %v1414 = getelementptr i8, ptr %v1376, i64 %v1413
  call void @llvm.memmove.p0.p0.i64(ptr %v1414, ptr %v1412, i64 %v1395, i1 false)
  ret ptr inttoptr (i64 4 to ptr)
copy.scalar.1411:
  %v1415 = ptrtoint ptr %a4 to i64
  %v1416 = ptrtoint ptr %a2 to i64
  %v1417 = and i64 %v1415, %v1416
  %v1418 = and i64 %v1417, 1
  %v1419 = icmp ne i64 %v1418, 0
  br i1 %v1419, label %yes.1420, label %no.1421
yes.1420:
  %v1423 = icmp slt i64 %v1415, %v1416
  %v1424 = select i1 %v1423, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1422
no.1421:
  %v1425 = call ptr @mlf_lt_int(ptr %a4, ptr %a2)
  br label %join.1422
join.1422:
  %v1426 = phi ptr [ %v1424, %yes.1420 ], [ %v1425, %no.1421 ]
  %v1427 = icmp eq ptr %v1426, inttoptr (i64 6 to ptr)
  br i1 %v1427, label %tail.yes.1428, label %tail.no.1429
tail.yes.1428:
  %v1430 = ptrtoint ptr %a4 to i64
  %v1431 = ashr i64 %v1430, 1
  %v1432 = and i64 %v1430, 1
  %v1433 = icmp ne i64 %v1432, 0
  %v1434 = icmp ult i64 %v1431, %v1370
  %v1435 = and i1 %v1433, %v1434
  br i1 %v1435, label %array.valid.1436, label %array.invalid.1437
array.invalid.1437:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1436:
  %v1438 = getelementptr i8, ptr %v1372, i64 %v1431
  %v1439 = load i8, ptr %v1438, align 1, !tbaa !4
  %v1440 = zext i8 %v1439 to i64
  %v1441 = shl i64 %v1440, 1
  %v1442 = or i64 %v1441, 1
  %v1443 = inttoptr i64 %v1442 to ptr
  %v1444 = ptrtoint ptr %a3 to i64
  %v1445 = ptrtoint ptr %a4 to i64
  %v1446 = and i64 %v1444, %v1445
  %v1447 = and i64 %v1446, 1
  %v1448 = icmp ne i64 %v1447, 0
  br i1 %v1448, label %yes.1449, label %no.1450
yes.1449:
  %v1452 = sub i64 %v1445, 1
  %v1453 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1444, i64 %v1452)
  %v1454 = extractvalue { i64, i1 } %v1453, 0
  %v1455 = extractvalue { i64, i1 } %v1453, 1
  br i1 %v1455, label %yes.1456, label %no.1457
yes.1456:
  %v1459 = call ptr @mlf_add_int(ptr %a3, ptr %a4)
  br label %join.1458
no.1457:
  %v1460 = inttoptr i64 %v1454 to ptr
  br label %join.1458
join.1458:
  %v1461 = phi ptr [ %v1459, %yes.1456 ], [ %v1460, %no.1457 ]
  br label %join.1451
no.1450:
  %v1462 = call ptr @mlf_add_int(ptr %a3, ptr %a4)
  br label %join.1451
join.1451:
  %v1463 = phi ptr [ %v1461, %join.1458 ], [ %v1462, %no.1450 ]
  %v1464 = ptrtoint ptr %v1463 to i64
  %v1465 = ashr i64 %v1464, 1
  %v1466 = and i64 %v1464, 1
  %v1467 = icmp ne i64 %v1466, 0
  %v1468 = icmp ult i64 %v1465, %v1374
  %v1469 = and i1 %v1467, %v1468
  br i1 %v1469, label %array.valid.1470, label %array.invalid.1471
array.invalid.1471:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1470:
  %v1472 = getelementptr i8, ptr %v1376, i64 %v1465
  %v1473 = ptrtoint ptr %v1443 to i64
  %v1474 = ashr i64 %v1473, 1
  %v1475 = trunc i64 %v1474 to i8
  store i8 %v1475, ptr %v1472, align 1, !tbaa !4
  %v1476 = ptrtoint ptr %a4 to i64
  %v1477 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v1478 = sub i64 %v1477, 1
  %v1479 = add nsw i64 %v1476, %v1478
  %v1480 = inttoptr i64 %v1479 to ptr
  %v1481 = musttail call ptr @mlf.numeric.0(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %v1480)
  ret ptr %v1481
tail.no.1429:
  ret ptr inttoptr (i64 4 to ptr)
}

define private ptr @mlf.numeric.53(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) {
entry:
  %v457 = alloca [5 x ptr], align 8
  %v458 = getelementptr ptr, ptr %v457, i64 0
  store ptr %a0, ptr %v458, align 8
  %v459 = getelementptr ptr, ptr %v457, i64 1
  store ptr %a1, ptr %v459, align 8
  %v460 = getelementptr ptr, ptr %v457, i64 2
  store ptr %a2, ptr %v460, align 8
  %v461 = getelementptr ptr, ptr %v457, i64 3
  store ptr %a3, ptr %v461, align 8
  %v462 = getelementptr ptr, ptr %v457, i64 4
  store ptr %a4, ptr %v462, align 8
  call void @mlf_gc_check(i64 5, ptr %v457)
  %v463 = call ptr @mlf_get_byte_line()
  %v464 = getelementptr i8, ptr %v463, i64 8
  %v465 = load i64, ptr %v464, align 8, !tbaa !3
  %v466 = getelementptr i8, ptr %v463, i64 16
  %v467 = load ptr, ptr %v466, align 8, !tbaa !3
  %v468 = shl i64 %v465, 1
  %v469 = or i64 %v468, 1
  %v470 = inttoptr i64 %v469 to ptr
  %v471 = ptrtoint ptr %v470 to i64
  %v472 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v473 = and i64 %v471, %v472
  %v474 = and i64 %v473, 1
  %v475 = icmp ne i64 %v474, 0
  br i1 %v475, label %yes.476, label %no.477
yes.476:
  %v479 = icmp eq i64 %v471, %v472
  %v480 = select i1 %v479, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.478
no.477:
  %v481 = call ptr @mlf_eq_int(ptr %v470, ptr inttoptr (i64 1 to ptr))
  br label %join.478
join.478:
  %v482 = phi ptr [ %v480, %yes.476 ], [ %v481, %no.477 ]
  %v483 = icmp eq ptr %v482, inttoptr (i64 6 to ptr)
  br i1 %v483, label %tail.yes.484, label %tail.no.485
tail.yes.484:
  %v1088 = call ptr @mlf.numeric.45(ptr %a0, ptr %a1, ptr %a2, ptr %a3)
  ret ptr %v1088
tail.no.485:
  %v1089 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v1090 = ashr i64 %v1089, 1
  %v1091 = and i64 %v1089, 1
  %v1092 = icmp ne i64 %v1091, 0
  %v1093 = icmp ult i64 %v1090, %v465
  %v1094 = and i1 %v1092, %v1093
  br i1 %v1094, label %array.valid.1095, label %array.invalid.1096
array.invalid.1096:
  call void @mlf_bounds_failure()
  unreachable
array.valid.1095:
  %v1097 = getelementptr i8, ptr %v467, i64 %v1090
  %v1098 = load i8, ptr %v1097, align 1, !tbaa !4
  %v1099 = zext i8 %v1098 to i64
  %v1100 = shl i64 %v1099, 1
  %v1101 = or i64 %v1100, 1
  %v1102 = inttoptr i64 %v1101 to ptr
  %v1103 = ptrtoint ptr %v1102 to i64
  %v1104 = ptrtoint ptr inttoptr (i64 125 to ptr) to i64
  %v1105 = icmp eq i64 %v1103, %v1104
  %v1106 = select i1 %v1105, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  %v1107 = icmp eq ptr %v1106, inttoptr (i64 6 to ptr)
  br i1 %v1107, label %tail.yes.1108, label %tail.no.1109
tail.yes.1108:
  %v1110 = call ptr @mlf.numeric.45(ptr %a0, ptr %a1, ptr %a2, ptr %a3)
  %v1111 = call ptr @mlf_put_bytes(ptr %v463, ptr inttoptr (i64 1 to ptr), ptr %v470)
  %v1112 = musttail call ptr @mlf.numeric.53(ptr %a0, ptr %a1, ptr %a2, ptr inttoptr (i64 1 to ptr), ptr %a4)
  ret ptr %v1112
tail.no.1109:
  %v1287 = call ptr @mlf.numeric.11(ptr %v463, ptr %v470)
  %v1288 = ptrtoint ptr %a3 to i64
  %v1289 = ptrtoint ptr %v1287 to i64
  %v1290 = and i64 %v1288, %v1289
  %v1291 = and i64 %v1290, 1
  %v1292 = icmp ne i64 %v1291, 0
  br i1 %v1292, label %yes.1293, label %no.1294
yes.1293:
  %v1296 = sub i64 %v1289, 1
  %v1297 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1288, i64 %v1296)
  %v1298 = extractvalue { i64, i1 } %v1297, 0
  %v1299 = extractvalue { i64, i1 } %v1297, 1
  br i1 %v1299, label %yes.1300, label %no.1301
yes.1300:
  %v1303 = call ptr @mlf_add_int(ptr %a3, ptr %v1287)
  br label %join.1302
no.1301:
  %v1304 = inttoptr i64 %v1298 to ptr
  br label %join.1302
join.1302:
  %v1305 = phi ptr [ %v1303, %yes.1300 ], [ %v1304, %no.1301 ]
  br label %join.1295
no.1294:
  %v1306 = call ptr @mlf_add_int(ptr %a3, ptr %v1287)
  br label %join.1295
join.1295:
  %v1307 = phi ptr [ %v1305, %join.1302 ], [ %v1306, %no.1294 ]
  %v1308 = ptrtoint ptr %a4 to i64
  %v1309 = ptrtoint ptr %v1307 to i64
  %v1310 = and i64 %v1308, %v1309
  %v1311 = and i64 %v1310, 1
  %v1312 = icmp ne i64 %v1311, 0
  br i1 %v1312, label %yes.1313, label %no.1314
yes.1313:
  %v1316 = icmp slt i64 %v1308, %v1309
  %v1317 = select i1 %v1316, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.1315
no.1314:
  %v1318 = call ptr @mlf_lt_int(ptr %a4, ptr %v1307)
  br label %join.1315
join.1315:
  %v1319 = phi ptr [ %v1317, %yes.1313 ], [ %v1318, %no.1314 ]
  %v1320 = icmp eq ptr %v1319, inttoptr (i64 6 to ptr)
  br i1 %v1320, label %tail.yes.1321, label %tail.no.1322
tail.yes.1321:
  %v1367 = call ptr @mlf.numeric.8(ptr %a4, ptr %v1307)
  %v1368 = call ptr @mlf_new_array(i64 35, ptr %v1367, ptr inttoptr (i64 1 to ptr))
  %v1482 = call ptr @mlf.numeric.0(ptr %a2, ptr %v1368, ptr %a3, ptr inttoptr (i64 1 to ptr), ptr inttoptr (i64 1 to ptr))
  %v1483 = call ptr @mlf.numeric.0(ptr %v463, ptr %v1368, ptr %v1287, ptr %a3, ptr inttoptr (i64 1 to ptr))
  %v1484 = musttail call ptr @mlf.numeric.53(ptr %a0, ptr %a1, ptr %v1368, ptr %v1307, ptr %v1367)
  ret ptr %v1484
tail.no.1322:
  %v1485 = call ptr @mlf.numeric.0(ptr %v463, ptr %a2, ptr %v1287, ptr %a3, ptr inttoptr (i64 1 to ptr))
  %v1486 = musttail call ptr @mlf.numeric.53(ptr %a0, ptr %a1, ptr %a2, ptr %v1307, ptr %a4)
  ret ptr %v1486
}

define private ptr @mlf.code.1501(ptr %env, ptr %arg) {
entry:
  %v1502 = getelementptr i8, ptr %env, i64 8
  %v1503 = load ptr, ptr %v1502, align 8, !tbaa !3
  %v1504 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1504, align 8, !tbaa !3
  %v1505 = call ptr @mlf_prim1(i64 38, ptr %v1503)
  ret ptr %v1505
}

define private ptr @mlf.code.1561(ptr %env, ptr %arg) {
entry:
  %v1562 = getelementptr i8, ptr %env, i64 8
  %v1563 = load ptr, ptr %v1562, align 8, !tbaa !3
  %v1564 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1564, align 8, !tbaa !3
  %v1565 = call ptr @mlf.force(ptr %v1563)
  %v1566 = call ptr @mlf_prim2(i64 11, ptr %v1565, ptr inttoptr (i64 122881 to ptr))
  %v1567 = icmp eq ptr %v1566, inttoptr (i64 6 to ptr)
  br i1 %v1567, label %yes.1568, label %no.1569
yes.1568:
  br label %join.1570
no.1569:
  br label %join.1570
join.1570:
  %v1571 = phi ptr [ %v1565, %yes.1568 ], [ inttoptr (i64 122881 to ptr), %no.1569 ]
  ret ptr %v1571
}

define private ptr @mlf.code.1634(ptr %env, ptr %arg) {
entry:
  %v1635 = getelementptr i8, ptr %env, i64 8
  %v1636 = load ptr, ptr %v1635, align 8, !tbaa !3
  %v1637 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1637, align 8, !tbaa !3
  %v1638 = call ptr @mlf.force(ptr %v1636)
  %v1639 = call ptr @mlf_prim2(i64 11, ptr %v1638, ptr inttoptr (i64 121 to ptr))
  %v1640 = icmp eq ptr %v1639, inttoptr (i64 6 to ptr)
  br i1 %v1640, label %yes.1641, label %no.1642
yes.1641:
  br label %join.1643
no.1642:
  br label %join.1643
join.1643:
  %v1644 = phi ptr [ %v1638, %yes.1641 ], [ inttoptr (i64 121 to ptr), %no.1642 ]
  ret ptr %v1644
}

define private ptr @mlf.code.1724(ptr %env, ptr %arg) {
entry:
  %v1725 = getelementptr i8, ptr %env, i64 8
  %v1726 = load ptr, ptr %v1725, align 8, !tbaa !3
  %v1727 = getelementptr i8, ptr %env, i64 16
  %v1728 = load ptr, ptr %v1727, align 8, !tbaa !3
  %v1729 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1729, align 8, !tbaa !3
  %v1730 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1730, align 8, !tbaa !3
  %v1731 = call ptr @mlf.force(ptr %v1726)
  %v1732 = call ptr @mlf.force(ptr %v1728)
  %v1733 = call ptr @mlf_prim2(i64 9, ptr %v1731, ptr %v1732)
  ret ptr %v1733
}

define private ptr @mlf.code.1714(ptr %env, ptr %arg) {
entry:
  %v1715 = getelementptr i8, ptr %env, i64 8
  %v1716 = load ptr, ptr %v1715, align 8, !tbaa !3
  %v1717 = getelementptr i8, ptr %env, i64 16
  %v1718 = load ptr, ptr %v1717, align 8, !tbaa !3
  %v1719 = getelementptr i8, ptr %env, i64 24
  %v1720 = load ptr, ptr %v1719, align 8, !tbaa !3
  %v1721 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1721, align 8, !tbaa !3
  %v1722 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1722, align 8, !tbaa !3
  %v1723 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v1723, align 8, !tbaa !3
  %v1734 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1724, i64 2)
  %v1735 = getelementptr i8, ptr %v1734, i64 16
  %v1736 = load ptr, ptr %v1735, align 8, !tbaa !3
  %v1737 = getelementptr i8, ptr %v1736, i64 8
  store ptr %v1718, ptr %v1737, align 8, !tbaa !3
  %v1738 = getelementptr i8, ptr %v1736, i64 16
  store ptr %v1720, ptr %v1738, align 8, !tbaa !3
  %v1739 = call ptr @mlf_prim2(i64 36, ptr %v1716, ptr %v1734)
  ret ptr %v1739
}

define private ptr @mlf.code.1761(ptr %env, ptr %arg) {
entry:
  %v1762 = getelementptr i8, ptr %env, i64 8
  %v1763 = load ptr, ptr %v1762, align 8, !tbaa !3
  %v1764 = getelementptr i8, ptr %env, i64 16
  %v1765 = load ptr, ptr %v1764, align 8, !tbaa !3
  %v1766 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1766, align 8, !tbaa !3
  %v1767 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1767, align 8, !tbaa !3
  %v1768 = call ptr @mlf_prim2(i64 36, ptr %v1763, ptr %v1765)
  ret ptr %v1768
}

define private ptr @mlf.code.1802(ptr %env, ptr %arg) {
entry:
  %v1803 = getelementptr i8, ptr %env, i64 8
  %v1804 = load ptr, ptr %v1803, align 8, !tbaa !3
  %v1805 = getelementptr i8, ptr %env, i64 16
  %v1806 = load ptr, ptr %v1805, align 8, !tbaa !3
  %v1807 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1807, align 8, !tbaa !3
  %v1808 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1808, align 8, !tbaa !3
  %v1809 = call ptr @mlf.force(ptr %v1804)
  %v1810 = call ptr @mlf.force(ptr %v1806)
  %v1811 = call ptr @mlf_prim2(i64 8, ptr %v1809, ptr %v1810)
  ret ptr %v1811
}

define private ptr @mlf.code.1789(ptr %env, ptr %arg) {
entry:
  %v1790 = getelementptr i8, ptr %env, i64 8
  %v1791 = load ptr, ptr %v1790, align 8, !tbaa !3
  %v1792 = getelementptr i8, ptr %env, i64 16
  %v1793 = load ptr, ptr %v1792, align 8, !tbaa !3
  %v1794 = getelementptr i8, ptr %env, i64 24
  %v1795 = load ptr, ptr %v1794, align 8, !tbaa !3
  %v1796 = getelementptr i8, ptr %env, i64 32
  %v1797 = load ptr, ptr %v1796, align 8, !tbaa !3
  %v1798 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1798, align 8, !tbaa !3
  %v1799 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1799, align 8, !tbaa !3
  %v1800 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v1800, align 8, !tbaa !3
  %v1801 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v1801, align 8, !tbaa !3
  %v1812 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1802, i64 2)
  %v1813 = getelementptr i8, ptr %v1812, i64 16
  %v1814 = load ptr, ptr %v1813, align 8, !tbaa !3
  %v1815 = getelementptr i8, ptr %v1814, i64 8
  store ptr %v1793, ptr %v1815, align 8, !tbaa !3
  %v1816 = getelementptr i8, ptr %v1814, i64 16
  store ptr %v1795, ptr %v1816, align 8, !tbaa !3
  %v1817 = call ptr @mlf_prim3(i64 37, ptr %v1791, ptr %v1812, ptr %v1797)
  ret ptr %v1817
}

define private ptr @mlf.code.1825(ptr %env, ptr %arg) {
entry:
  %v1826 = getelementptr i8, ptr %env, i64 8
  %v1827 = load ptr, ptr %v1826, align 8, !tbaa !3
  %v1828 = getelementptr i8, ptr %env, i64 16
  %v1829 = load ptr, ptr %v1828, align 8, !tbaa !3
  %v1830 = getelementptr i8, ptr %env, i64 24
  %v1831 = load ptr, ptr %v1830, align 8, !tbaa !3
  %v1832 = getelementptr i8, ptr %env, i64 32
  %v1833 = load ptr, ptr %v1832, align 8, !tbaa !3
  %v1834 = getelementptr i8, ptr %env, i64 40
  %v1835 = load ptr, ptr %v1834, align 8, !tbaa !3
  %v1836 = getelementptr i8, ptr %env, i64 48
  %v1837 = load ptr, ptr %v1836, align 8, !tbaa !3
  %v1838 = getelementptr i8, ptr %env, i64 56
  %v1839 = load ptr, ptr %v1838, align 8, !tbaa !3
  %v1840 = call ptr @mlf.force(ptr %v1837)
  %v1841 = call ptr @mlf.force(ptr %v1839)
  %v1842 = call ptr @mlf_prim2(i64 8, ptr %v1841, ptr inttoptr (i64 3 to ptr))
  %v1843 = call ptr @mlf_env_new(i64 7)
  %v1844 = getelementptr i8, ptr %v1843, i64 8
  store ptr %v1827, ptr %v1844, align 8, !tbaa !3
  %v1845 = getelementptr i8, ptr %v1843, i64 16
  store ptr %v1829, ptr %v1845, align 8, !tbaa !3
  %v1846 = getelementptr i8, ptr %v1843, i64 24
  store ptr %v1831, ptr %v1846, align 8, !tbaa !3
  %v1847 = getelementptr i8, ptr %v1843, i64 32
  store ptr %v1833, ptr %v1847, align 8, !tbaa !3
  %v1848 = getelementptr i8, ptr %v1843, i64 40
  store ptr %v1835, ptr %v1848, align 8, !tbaa !3
  %v1849 = getelementptr i8, ptr %v1843, i64 48
  store ptr %v1840, ptr %v1849, align 8, !tbaa !3
  %v1850 = getelementptr i8, ptr %v1843, i64 56
  store ptr %v1842, ptr %v1850, align 8, !tbaa !3
  %v1851 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1668, ptr %v1843)
  ret ptr %v1851
}

define private ptr @mlf.code.1774(ptr %env, ptr %arg) {
entry:
  %v1775 = getelementptr i8, ptr %env, i64 8
  %v1776 = load ptr, ptr %v1775, align 8, !tbaa !3
  %v1777 = getelementptr i8, ptr %env, i64 16
  %v1778 = load ptr, ptr %v1777, align 8, !tbaa !3
  %v1779 = getelementptr i8, ptr %env, i64 24
  %v1780 = load ptr, ptr %v1779, align 8, !tbaa !3
  %v1781 = getelementptr i8, ptr %env, i64 32
  %v1782 = load ptr, ptr %v1781, align 8, !tbaa !3
  %v1783 = getelementptr i8, ptr %env, i64 40
  %v1784 = load ptr, ptr %v1783, align 8, !tbaa !3
  %v1785 = getelementptr i8, ptr %env, i64 48
  %v1786 = load ptr, ptr %v1785, align 8, !tbaa !3
  %v1787 = getelementptr i8, ptr %env, i64 56
  %v1788 = load ptr, ptr %v1787, align 8, !tbaa !3
  %v1818 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1789, i64 4)
  %v1819 = getelementptr i8, ptr %v1818, i64 16
  %v1820 = load ptr, ptr %v1819, align 8, !tbaa !3
  %v1821 = getelementptr i8, ptr %v1820, i64 8
  store ptr %v1780, ptr %v1821, align 8, !tbaa !3
  %v1822 = getelementptr i8, ptr %v1820, i64 16
  store ptr %v1784, ptr %v1822, align 8, !tbaa !3
  %v1823 = getelementptr i8, ptr %v1820, i64 24
  store ptr %v1788, ptr %v1823, align 8, !tbaa !3
  %v1824 = getelementptr i8, ptr %v1820, i64 32
  store ptr %arg, ptr %v1824, align 8, !tbaa !3
  %v1852 = call ptr @mlf_env_new(i64 7)
  %v1853 = getelementptr i8, ptr %v1852, i64 8
  store ptr %v1776, ptr %v1853, align 8, !tbaa !3
  %v1854 = getelementptr i8, ptr %v1852, i64 16
  store ptr %v1778, ptr %v1854, align 8, !tbaa !3
  %v1855 = getelementptr i8, ptr %v1852, i64 24
  store ptr %v1780, ptr %v1855, align 8, !tbaa !3
  %v1856 = getelementptr i8, ptr %v1852, i64 32
  store ptr %v1782, ptr %v1856, align 8, !tbaa !3
  %v1857 = getelementptr i8, ptr %v1852, i64 40
  store ptr %v1784, ptr %v1857, align 8, !tbaa !3
  %v1858 = getelementptr i8, ptr %v1852, i64 48
  store ptr %v1786, ptr %v1858, align 8, !tbaa !3
  %v1859 = getelementptr i8, ptr %v1852, i64 56
  store ptr %v1788, ptr %v1859, align 8, !tbaa !3
  %v1860 = call ptr @mlf_closure(ptr @mlf.code.1825, ptr %v1852)
  %v1861 = call ptr @mlf_prim2(i64 1, ptr %v1818, ptr %v1860)
  ret ptr %v1861
}

define private ptr @mlf.code.1746(ptr %env, ptr %arg) {
entry:
  %v1747 = getelementptr i8, ptr %env, i64 8
  %v1748 = load ptr, ptr %v1747, align 8, !tbaa !3
  %v1749 = getelementptr i8, ptr %env, i64 16
  %v1750 = load ptr, ptr %v1749, align 8, !tbaa !3
  %v1751 = getelementptr i8, ptr %env, i64 24
  %v1752 = load ptr, ptr %v1751, align 8, !tbaa !3
  %v1753 = getelementptr i8, ptr %env, i64 32
  %v1754 = load ptr, ptr %v1753, align 8, !tbaa !3
  %v1755 = getelementptr i8, ptr %env, i64 40
  %v1756 = load ptr, ptr %v1755, align 8, !tbaa !3
  %v1757 = getelementptr i8, ptr %env, i64 48
  %v1758 = load ptr, ptr %v1757, align 8, !tbaa !3
  %v1759 = getelementptr i8, ptr %env, i64 56
  %v1760 = load ptr, ptr %v1759, align 8, !tbaa !3
  %v1769 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1761, i64 2)
  %v1770 = getelementptr i8, ptr %v1769, i64 16
  %v1771 = load ptr, ptr %v1770, align 8, !tbaa !3
  %v1772 = getelementptr i8, ptr %v1771, i64 8
  store ptr %v1748, ptr %v1772, align 8, !tbaa !3
  %v1773 = getelementptr i8, ptr %v1771, i64 16
  store ptr %arg, ptr %v1773, align 8, !tbaa !3
  %v1862 = call ptr @mlf_env_new(i64 7)
  %v1863 = getelementptr i8, ptr %v1862, i64 8
  store ptr %v1748, ptr %v1863, align 8, !tbaa !3
  %v1864 = getelementptr i8, ptr %v1862, i64 16
  store ptr %v1750, ptr %v1864, align 8, !tbaa !3
  %v1865 = getelementptr i8, ptr %v1862, i64 24
  store ptr %v1752, ptr %v1865, align 8, !tbaa !3
  %v1866 = getelementptr i8, ptr %v1862, i64 32
  store ptr %v1754, ptr %v1866, align 8, !tbaa !3
  %v1867 = getelementptr i8, ptr %v1862, i64 40
  store ptr %v1756, ptr %v1867, align 8, !tbaa !3
  %v1868 = getelementptr i8, ptr %v1862, i64 48
  store ptr %v1758, ptr %v1868, align 8, !tbaa !3
  %v1869 = getelementptr i8, ptr %v1862, i64 56
  store ptr %v1760, ptr %v1869, align 8, !tbaa !3
  %v1870 = call ptr @mlf_closure(ptr @mlf.code.1774, ptr %v1862)
  %v1871 = call ptr @mlf_prim2(i64 1, ptr %v1769, ptr %v1870)
  ret ptr %v1871
}

define private ptr @mlf.worker.24(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6) {
entry:
  %v1709 = call ptr @mlf_prim2(i64 11, ptr %a6, ptr %a5)
  %v1710 = icmp eq ptr %v1709, inttoptr (i64 6 to ptr)
  br i1 %v1710, label %yes.1711, label %no.1712
yes.1711:
  %v1740 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1714, i64 3)
  %v1741 = getelementptr i8, ptr %v1740, i64 16
  %v1742 = load ptr, ptr %v1741, align 8, !tbaa !3
  %v1743 = getelementptr i8, ptr %v1742, i64 8
  store ptr %a1, ptr %v1743, align 8, !tbaa !3
  %v1744 = getelementptr i8, ptr %v1742, i64 16
  store ptr %a3, ptr %v1744, align 8, !tbaa !3
  %v1745 = getelementptr i8, ptr %v1742, i64 24
  store ptr %a6, ptr %v1745, align 8, !tbaa !3
  %v1872 = call ptr @mlf_env_new(i64 7)
  %v1873 = getelementptr i8, ptr %v1872, i64 8
  store ptr %a0, ptr %v1873, align 8, !tbaa !3
  %v1874 = getelementptr i8, ptr %v1872, i64 16
  store ptr %a1, ptr %v1874, align 8, !tbaa !3
  %v1875 = getelementptr i8, ptr %v1872, i64 24
  store ptr %a2, ptr %v1875, align 8, !tbaa !3
  %v1876 = getelementptr i8, ptr %v1872, i64 32
  store ptr %a3, ptr %v1876, align 8, !tbaa !3
  %v1877 = getelementptr i8, ptr %v1872, i64 40
  store ptr %a4, ptr %v1877, align 8, !tbaa !3
  %v1878 = getelementptr i8, ptr %v1872, i64 48
  store ptr %a5, ptr %v1878, align 8, !tbaa !3
  %v1879 = getelementptr i8, ptr %v1872, i64 56
  store ptr %a6, ptr %v1879, align 8, !tbaa !3
  %v1880 = call ptr @mlf_closure(ptr @mlf.code.1746, ptr %v1872)
  %v1881 = call ptr @mlf_prim2(i64 1, ptr %v1740, ptr %v1880)
  br label %join.1713
no.1712:
  %v1882 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.1713
join.1713:
  %v1883 = phi ptr [ %v1881, %yes.1711 ], [ %v1882, %no.1712 ]
  ret ptr %v1883
}

define private ptr @mlf.numeric.entry.1668(ptr %env, ptr %arg) {
entry:
  %v1669 = getelementptr i8, ptr %env, i64 8
  %v1670 = load ptr, ptr %v1669, align 8, !tbaa !3
  %v1671 = getelementptr i8, ptr %env, i64 16
  %v1672 = load ptr, ptr %v1671, align 8, !tbaa !3
  %v1673 = getelementptr i8, ptr %env, i64 24
  %v1674 = load ptr, ptr %v1673, align 8, !tbaa !3
  %v1675 = getelementptr i8, ptr %env, i64 32
  %v1676 = load ptr, ptr %v1675, align 8, !tbaa !3
  %v1677 = getelementptr i8, ptr %env, i64 40
  %v1678 = load ptr, ptr %v1677, align 8, !tbaa !3
  %v1679 = getelementptr i8, ptr %env, i64 48
  %v1680 = load ptr, ptr %v1679, align 8, !tbaa !3
  %v1681 = getelementptr i8, ptr %env, i64 56
  %v1682 = load ptr, ptr %v1681, align 8, !tbaa !3
  %v1683 = call ptr @mlf_peek(ptr %v1670)
  %v1684 = call ptr @mlf_peek(ptr %v1672)
  %v1685 = call ptr @mlf_peek(ptr %v1674)
  %v1686 = call ptr @mlf_peek(ptr %v1676)
  %v1687 = call ptr @mlf_peek(ptr %v1678)
  %v1688 = call ptr @mlf_peek(ptr %v1680)
  %v1689 = call ptr @mlf_peek(ptr %v1682)
  %v1690 = icmp ne ptr %v1683, null
  %v1691 = icmp ne ptr %v1684, null
  %v1692 = icmp ne ptr %v1685, null
  %v1693 = icmp ne ptr %v1686, null
  %v1694 = icmp ne ptr %v1687, null
  %v1695 = icmp ne ptr %v1688, null
  %v1696 = icmp ne ptr %v1689, null
  %v1697 = and i1 true, %v1690
  %v1698 = and i1 %v1697, %v1691
  %v1699 = and i1 %v1698, %v1692
  %v1700 = and i1 %v1699, %v1693
  %v1701 = and i1 %v1700, %v1694
  %v1702 = and i1 %v1701, %v1695
  %v1703 = and i1 %v1702, %v1696
  br i1 %v1703, label %yes.1704, label %no.1705
yes.1704:
  %v1707 = call ptr @mlf.numeric.24(ptr %v1683, ptr %v1684, ptr %v1685, ptr %v1686, ptr %v1687, ptr %v1688, ptr %v1689)
  %v1708 = call ptr @mlf_prim1(i64 0, ptr %v1707)
  br label %join.1706
no.1705:
  %v1884 = call ptr @mlf.force(ptr %v1680)
  %v1885 = call ptr @mlf.force(ptr %v1682)
  %v1886 = call ptr @mlf.worker.24(ptr %v1670, ptr %v1672, ptr %v1674, ptr %v1676, ptr %v1678, ptr %v1884, ptr %v1885)
  br label %join.1706
join.1706:
  %v1887 = phi ptr [ %v1708, %yes.1704 ], [ %v1886, %no.1705 ]
  ret ptr %v1887
}

define private ptr @mlf.code.1649(ptr %env, ptr %arg) {
entry:
  %v1650 = getelementptr i8, ptr %env, i64 8
  %v1651 = load ptr, ptr %v1650, align 8, !tbaa !3
  %v1652 = getelementptr i8, ptr %env, i64 16
  %v1653 = load ptr, ptr %v1652, align 8, !tbaa !3
  %v1654 = getelementptr i8, ptr %env, i64 24
  %v1655 = load ptr, ptr %v1654, align 8, !tbaa !3
  %v1656 = getelementptr i8, ptr %env, i64 32
  %v1657 = load ptr, ptr %v1656, align 8, !tbaa !3
  %v1658 = getelementptr i8, ptr %env, i64 40
  %v1659 = load ptr, ptr %v1658, align 8, !tbaa !3
  %v1660 = getelementptr i8, ptr %env, i64 48
  %v1661 = load ptr, ptr %v1660, align 8, !tbaa !3
  %v1662 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1662, align 8, !tbaa !3
  %v1663 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1663, align 8, !tbaa !3
  %v1664 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v1664, align 8, !tbaa !3
  %v1665 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v1665, align 8, !tbaa !3
  %v1666 = getelementptr i8, ptr %env, i64 40
  store ptr null, ptr %v1666, align 8, !tbaa !3
  %v1667 = getelementptr i8, ptr %env, i64 48
  store ptr null, ptr %v1667, align 8, !tbaa !3
  %v1888 = call ptr @mlf.force(ptr %v1661)
  %v1889 = call ptr @mlf_env_new(i64 7)
  %v1890 = getelementptr i8, ptr %v1889, i64 8
  store ptr %v1651, ptr %v1890, align 8, !tbaa !3
  %v1891 = getelementptr i8, ptr %v1889, i64 16
  store ptr %v1653, ptr %v1891, align 8, !tbaa !3
  %v1892 = getelementptr i8, ptr %v1889, i64 24
  store ptr %v1655, ptr %v1892, align 8, !tbaa !3
  %v1893 = getelementptr i8, ptr %v1889, i64 32
  store ptr %v1657, ptr %v1893, align 8, !tbaa !3
  %v1894 = getelementptr i8, ptr %v1889, i64 40
  store ptr %v1659, ptr %v1894, align 8, !tbaa !3
  %v1895 = getelementptr i8, ptr %v1889, i64 48
  store ptr %v1888, ptr %v1895, align 8, !tbaa !3
  %v1896 = getelementptr i8, ptr %v1889, i64 56
  store ptr inttoptr (i64 1 to ptr), ptr %v1896, align 8, !tbaa !3
  %v1897 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1668, ptr %v1889)
  ret ptr %v1897
}

define private ptr @mlf.code.1932(ptr %env, ptr %arg) {
entry:
  %v1933 = getelementptr i8, ptr %env, i64 8
  %v1934 = load ptr, ptr %v1933, align 8, !tbaa !3
  %v1935 = getelementptr i8, ptr %env, i64 16
  %v1936 = load ptr, ptr %v1935, align 8, !tbaa !3
  %v1937 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1937, align 8, !tbaa !3
  %v1938 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1938, align 8, !tbaa !3
  %v1939 = call ptr @mlf.force(ptr %v1934)
  %v1940 = call ptr @mlf.force(ptr %v1936)
  %v1941 = call ptr @mlf_prim2(i64 8, ptr %v1939, ptr %v1940)
  ret ptr %v1941
}

define private ptr @mlf.code.1922(ptr %env, ptr %arg) {
entry:
  %v1923 = getelementptr i8, ptr %env, i64 8
  %v1924 = load ptr, ptr %v1923, align 8, !tbaa !3
  %v1925 = getelementptr i8, ptr %env, i64 16
  %v1926 = load ptr, ptr %v1925, align 8, !tbaa !3
  %v1927 = getelementptr i8, ptr %env, i64 24
  %v1928 = load ptr, ptr %v1927, align 8, !tbaa !3
  %v1929 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1929, align 8, !tbaa !3
  %v1930 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1930, align 8, !tbaa !3
  %v1931 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v1931, align 8, !tbaa !3
  %v1942 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1932, i64 2)
  %v1943 = getelementptr i8, ptr %v1942, i64 16
  %v1944 = load ptr, ptr %v1943, align 8, !tbaa !3
  %v1945 = getelementptr i8, ptr %v1944, i64 8
  store ptr %v1926, ptr %v1945, align 8, !tbaa !3
  %v1946 = getelementptr i8, ptr %v1944, i64 16
  store ptr %v1928, ptr %v1946, align 8, !tbaa !3
  %v1947 = call ptr @mlf_prim3(i64 37, ptr %v1924, ptr %v1942, ptr inttoptr (i64 21 to ptr))
  ret ptr %v1947
}

define private ptr @mlf.code.1969(ptr %env, ptr %arg) {
entry:
  %v1970 = getelementptr i8, ptr %env, i64 8
  %v1971 = load ptr, ptr %v1970, align 8, !tbaa !3
  %v1972 = getelementptr i8, ptr %env, i64 16
  %v1973 = load ptr, ptr %v1972, align 8, !tbaa !3
  %v1974 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1974, align 8, !tbaa !3
  %v1975 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1975, align 8, !tbaa !3
  %v1976 = call ptr @mlf.force(ptr %v1971)
  %v1977 = call ptr @mlf.force(ptr %v1973)
  %v1978 = call ptr @mlf_prim2(i64 9, ptr %v1976, ptr %v1977)
  ret ptr %v1978
}

define private ptr @mlf.code.1987(ptr %env, ptr %arg) {
entry:
  %v1988 = getelementptr i8, ptr %env, i64 8
  %v1989 = load ptr, ptr %v1988, align 8, !tbaa !3
  %v1990 = getelementptr i8, ptr %env, i64 16
  %v1991 = load ptr, ptr %v1990, align 8, !tbaa !3
  %v1992 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1992, align 8, !tbaa !3
  %v1993 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1993, align 8, !tbaa !3
  %v1994 = call ptr @mlf.force(ptr %v1989)
  %v1995 = call ptr @mlf.force(ptr %v1991)
  %v1996 = call ptr @mlf_prim2(i64 8, ptr %v1994, ptr %v1995)
  %v1997 = call ptr @mlf_prim2(i64 8, ptr %v1996, ptr inttoptr (i64 3 to ptr))
  ret ptr %v1997
}

define private ptr @mlf.code.1954(ptr %env, ptr %arg) {
entry:
  %v1955 = getelementptr i8, ptr %env, i64 8
  %v1956 = load ptr, ptr %v1955, align 8, !tbaa !3
  %v1957 = getelementptr i8, ptr %env, i64 16
  %v1958 = load ptr, ptr %v1957, align 8, !tbaa !3
  %v1959 = getelementptr i8, ptr %env, i64 24
  %v1960 = load ptr, ptr %v1959, align 8, !tbaa !3
  %v1961 = getelementptr i8, ptr %env, i64 32
  %v1962 = load ptr, ptr %v1961, align 8, !tbaa !3
  %v1963 = getelementptr i8, ptr %env, i64 40
  %v1964 = load ptr, ptr %v1963, align 8, !tbaa !3
  %v1965 = getelementptr i8, ptr %env, i64 48
  %v1966 = load ptr, ptr %v1965, align 8, !tbaa !3
  %v1967 = getelementptr i8, ptr %env, i64 56
  %v1968 = load ptr, ptr %v1967, align 8, !tbaa !3
  %v1979 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1969, i64 2)
  %v1980 = getelementptr i8, ptr %v1979, i64 16
  %v1981 = load ptr, ptr %v1980, align 8, !tbaa !3
  %v1982 = getelementptr i8, ptr %v1981, i64 8
  store ptr %v1962, ptr %v1982, align 8, !tbaa !3
  %v1983 = getelementptr i8, ptr %v1981, i64 16
  store ptr %v1968, ptr %v1983, align 8, !tbaa !3
  %v1984 = call ptr @mlf.force(ptr %v1964)
  %v1985 = call ptr @mlf.force(ptr %v1968)
  %v1986 = call ptr @mlf_prim2(i64 9, ptr %v1984, ptr %v1985)
  %v1998 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1987, i64 2)
  %v1999 = getelementptr i8, ptr %v1998, i64 16
  %v2000 = load ptr, ptr %v1999, align 8, !tbaa !3
  %v2001 = getelementptr i8, ptr %v2000, i64 8
  store ptr %v1966, ptr %v2001, align 8, !tbaa !3
  %v2002 = getelementptr i8, ptr %v2000, i64 16
  store ptr %v1985, ptr %v2002, align 8, !tbaa !3
  %v2003 = call ptr @mlf_env_new(i64 6)
  %v2004 = getelementptr i8, ptr %v2003, i64 8
  store ptr %v1956, ptr %v2004, align 8, !tbaa !3
  %v2005 = getelementptr i8, ptr %v2003, i64 16
  store ptr %v1958, ptr %v2005, align 8, !tbaa !3
  %v2006 = getelementptr i8, ptr %v2003, i64 24
  store ptr %v1960, ptr %v2006, align 8, !tbaa !3
  %v2007 = getelementptr i8, ptr %v2003, i64 32
  store ptr %v1979, ptr %v2007, align 8, !tbaa !3
  %v2008 = getelementptr i8, ptr %v2003, i64 40
  store ptr %v1986, ptr %v2008, align 8, !tbaa !3
  %v2009 = getelementptr i8, ptr %v2003, i64 48
  store ptr %v1998, ptr %v2009, align 8, !tbaa !3
  %v2010 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1592, ptr %v2003)
  ret ptr %v2010
}

define private ptr @mlf.code.1907(ptr %env, ptr %arg) {
entry:
  %v1908 = getelementptr i8, ptr %env, i64 8
  %v1909 = load ptr, ptr %v1908, align 8, !tbaa !3
  %v1910 = getelementptr i8, ptr %env, i64 16
  %v1911 = load ptr, ptr %v1910, align 8, !tbaa !3
  %v1912 = getelementptr i8, ptr %env, i64 24
  %v1913 = load ptr, ptr %v1912, align 8, !tbaa !3
  %v1914 = getelementptr i8, ptr %env, i64 32
  %v1915 = load ptr, ptr %v1914, align 8, !tbaa !3
  %v1916 = getelementptr i8, ptr %env, i64 40
  %v1917 = load ptr, ptr %v1916, align 8, !tbaa !3
  %v1918 = getelementptr i8, ptr %env, i64 48
  %v1919 = load ptr, ptr %v1918, align 8, !tbaa !3
  %v1920 = getelementptr i8, ptr %env, i64 56
  %v1921 = load ptr, ptr %v1920, align 8, !tbaa !3
  %v1948 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1922, i64 3)
  %v1949 = getelementptr i8, ptr %v1948, i64 16
  %v1950 = load ptr, ptr %v1949, align 8, !tbaa !3
  %v1951 = getelementptr i8, ptr %v1950, i64 8
  store ptr %v1913, ptr %v1951, align 8, !tbaa !3
  %v1952 = getelementptr i8, ptr %v1950, i64 16
  store ptr %v1919, ptr %v1952, align 8, !tbaa !3
  %v1953 = getelementptr i8, ptr %v1950, i64 24
  store ptr %v1921, ptr %v1953, align 8, !tbaa !3
  %v2011 = call ptr @mlf_env_new(i64 7)
  %v2012 = getelementptr i8, ptr %v2011, i64 8
  store ptr %v1909, ptr %v2012, align 8, !tbaa !3
  %v2013 = getelementptr i8, ptr %v2011, i64 16
  store ptr %v1911, ptr %v2013, align 8, !tbaa !3
  %v2014 = getelementptr i8, ptr %v2011, i64 24
  store ptr %v1913, ptr %v2014, align 8, !tbaa !3
  %v2015 = getelementptr i8, ptr %v2011, i64 32
  store ptr %v1915, ptr %v2015, align 8, !tbaa !3
  %v2016 = getelementptr i8, ptr %v2011, i64 40
  store ptr %v1917, ptr %v2016, align 8, !tbaa !3
  %v2017 = getelementptr i8, ptr %v2011, i64 48
  store ptr %v1919, ptr %v2017, align 8, !tbaa !3
  %v2018 = getelementptr i8, ptr %v2011, i64 56
  store ptr %v1921, ptr %v2018, align 8, !tbaa !3
  %v2019 = call ptr @mlf_closure(ptr @mlf.code.1954, ptr %v2011)
  %v2020 = call ptr @mlf_prim2(i64 1, ptr %v1948, ptr %v2019)
  ret ptr %v2020
}

define private ptr @mlf.worker.35(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5) {
entry:
  %v1628 = call ptr @mlf_prim2(i64 10, ptr %a4, ptr inttoptr (i64 1 to ptr))
  %v1629 = icmp eq ptr %v1628, inttoptr (i64 6 to ptr)
  br i1 %v1629, label %yes.1630, label %no.1631
yes.1630:
  %v1633 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.1632
no.1631:
  %v1645 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1634, i64 1)
  %v1646 = getelementptr i8, ptr %v1645, i64 16
  %v1647 = load ptr, ptr %v1646, align 8, !tbaa !3
  %v1648 = getelementptr i8, ptr %v1647, i64 8
  store ptr %a4, ptr %v1648, align 8, !tbaa !3
  %v1898 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1649, i64 6)
  %v1899 = getelementptr i8, ptr %v1898, i64 16
  %v1900 = load ptr, ptr %v1899, align 8, !tbaa !3
  %v1901 = getelementptr i8, ptr %v1900, i64 8
  store ptr %a0, ptr %v1901, align 8, !tbaa !3
  %v1902 = getelementptr i8, ptr %v1900, i64 16
  store ptr %a1, ptr %v1902, align 8, !tbaa !3
  %v1903 = getelementptr i8, ptr %v1900, i64 24
  store ptr %a2, ptr %v1903, align 8, !tbaa !3
  %v1904 = getelementptr i8, ptr %v1900, i64 32
  store ptr %a3, ptr %v1904, align 8, !tbaa !3
  %v1905 = getelementptr i8, ptr %v1900, i64 40
  store ptr %a5, ptr %v1905, align 8, !tbaa !3
  %v1906 = getelementptr i8, ptr %v1900, i64 48
  store ptr %v1645, ptr %v1906, align 8, !tbaa !3
  %v2021 = call ptr @mlf_env_new(i64 7)
  %v2022 = getelementptr i8, ptr %v2021, i64 8
  store ptr %a0, ptr %v2022, align 8, !tbaa !3
  %v2023 = getelementptr i8, ptr %v2021, i64 16
  store ptr %a1, ptr %v2023, align 8, !tbaa !3
  %v2024 = getelementptr i8, ptr %v2021, i64 24
  store ptr %a2, ptr %v2024, align 8, !tbaa !3
  %v2025 = getelementptr i8, ptr %v2021, i64 32
  store ptr %a3, ptr %v2025, align 8, !tbaa !3
  %v2026 = getelementptr i8, ptr %v2021, i64 40
  store ptr %a4, ptr %v2026, align 8, !tbaa !3
  %v2027 = getelementptr i8, ptr %v2021, i64 48
  store ptr %a5, ptr %v2027, align 8, !tbaa !3
  %v2028 = getelementptr i8, ptr %v2021, i64 56
  store ptr %v1645, ptr %v2028, align 8, !tbaa !3
  %v2029 = call ptr @mlf_closure(ptr @mlf.code.1907, ptr %v2021)
  %v2030 = call ptr @mlf_prim2(i64 1, ptr %v1898, ptr %v2029)
  br label %join.1632
join.1632:
  %v2031 = phi ptr [ %v1633, %yes.1630 ], [ %v2030, %no.1631 ]
  ret ptr %v2031
}

define private ptr @mlf.numeric.entry.1592(ptr %env, ptr %arg) {
entry:
  %v1593 = getelementptr i8, ptr %env, i64 8
  %v1594 = load ptr, ptr %v1593, align 8, !tbaa !3
  %v1595 = getelementptr i8, ptr %env, i64 16
  %v1596 = load ptr, ptr %v1595, align 8, !tbaa !3
  %v1597 = getelementptr i8, ptr %env, i64 24
  %v1598 = load ptr, ptr %v1597, align 8, !tbaa !3
  %v1599 = getelementptr i8, ptr %env, i64 32
  %v1600 = load ptr, ptr %v1599, align 8, !tbaa !3
  %v1601 = getelementptr i8, ptr %env, i64 40
  %v1602 = load ptr, ptr %v1601, align 8, !tbaa !3
  %v1603 = getelementptr i8, ptr %env, i64 48
  %v1604 = load ptr, ptr %v1603, align 8, !tbaa !3
  %v1605 = call ptr @mlf_peek(ptr %v1594)
  %v1606 = call ptr @mlf_peek(ptr %v1596)
  %v1607 = call ptr @mlf_peek(ptr %v1598)
  %v1608 = call ptr @mlf_peek(ptr %v1600)
  %v1609 = call ptr @mlf_peek(ptr %v1602)
  %v1610 = call ptr @mlf_peek(ptr %v1604)
  %v1611 = icmp ne ptr %v1605, null
  %v1612 = icmp ne ptr %v1606, null
  %v1613 = icmp ne ptr %v1607, null
  %v1614 = icmp ne ptr %v1608, null
  %v1615 = icmp ne ptr %v1609, null
  %v1616 = icmp ne ptr %v1610, null
  %v1617 = and i1 true, %v1611
  %v1618 = and i1 %v1617, %v1612
  %v1619 = and i1 %v1618, %v1613
  %v1620 = and i1 %v1619, %v1614
  %v1621 = and i1 %v1620, %v1615
  %v1622 = and i1 %v1621, %v1616
  br i1 %v1622, label %yes.1623, label %no.1624
yes.1623:
  %v1626 = call ptr @mlf.numeric.35(ptr %v1605, ptr %v1606, ptr %v1607, ptr %v1608, ptr %v1609, ptr %v1610)
  %v1627 = call ptr @mlf_prim1(i64 0, ptr %v1626)
  br label %join.1625
no.1624:
  %v2032 = call ptr @mlf.force(ptr %v1602)
  %v2033 = call ptr @mlf.worker.35(ptr %v1594, ptr %v1596, ptr %v1598, ptr %v1600, ptr %v2032, ptr %v1604)
  br label %join.1625
join.1625:
  %v2034 = phi ptr [ %v1627, %yes.1623 ], [ %v2033, %no.1624 ]
  ret ptr %v2034
}

define private ptr @mlf.code.2035(ptr %env, ptr %arg) {
entry:
  %v2036 = getelementptr i8, ptr %env, i64 8
  %v2037 = load ptr, ptr %v2036, align 8, !tbaa !3
  %v2038 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2038, align 8, !tbaa !3
  %v2039 = call ptr @mlf.force(ptr %v2037)
  %v2040 = call ptr @mlf_prim2(i64 9, ptr %v2039, ptr inttoptr (i64 3 to ptr))
  ret ptr %v2040
}

define private ptr @mlf.code.1576(ptr %env, ptr %arg) {
entry:
  %v1577 = getelementptr i8, ptr %env, i64 8
  %v1578 = load ptr, ptr %v1577, align 8, !tbaa !3
  %v1579 = getelementptr i8, ptr %env, i64 16
  %v1580 = load ptr, ptr %v1579, align 8, !tbaa !3
  %v1581 = getelementptr i8, ptr %env, i64 24
  %v1582 = load ptr, ptr %v1581, align 8, !tbaa !3
  %v1583 = getelementptr i8, ptr %env, i64 32
  %v1584 = load ptr, ptr %v1583, align 8, !tbaa !3
  %v1585 = getelementptr i8, ptr %env, i64 40
  %v1586 = load ptr, ptr %v1585, align 8, !tbaa !3
  %v1587 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v1587, align 8, !tbaa !3
  %v1588 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v1588, align 8, !tbaa !3
  %v1589 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v1589, align 8, !tbaa !3
  %v1590 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v1590, align 8, !tbaa !3
  %v1591 = getelementptr i8, ptr %env, i64 40
  store ptr null, ptr %v1591, align 8, !tbaa !3
  %v2041 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2035, i64 1)
  %v2042 = getelementptr i8, ptr %v2041, i64 16
  %v2043 = load ptr, ptr %v2042, align 8, !tbaa !3
  %v2044 = getelementptr i8, ptr %v2043, i64 8
  store ptr %v1584, ptr %v2044, align 8, !tbaa !3
  %v2045 = call ptr @mlf.force(ptr %v1586)
  %v2046 = call ptr @mlf_env_new(i64 6)
  %v2047 = getelementptr i8, ptr %v2046, i64 8
  store ptr %v1578, ptr %v2047, align 8, !tbaa !3
  %v2048 = getelementptr i8, ptr %v2046, i64 16
  store ptr %v1582, ptr %v2048, align 8, !tbaa !3
  %v2049 = getelementptr i8, ptr %v2046, i64 24
  store ptr %v1580, ptr %v2049, align 8, !tbaa !3
  %v2050 = getelementptr i8, ptr %v2046, i64 32
  store ptr %v2041, ptr %v2050, align 8, !tbaa !3
  %v2051 = getelementptr i8, ptr %v2046, i64 40
  store ptr %v2045, ptr %v2051, align 8, !tbaa !3
  %v2052 = getelementptr i8, ptr %v2046, i64 48
  store ptr inttoptr (i64 1 to ptr), ptr %v2052, align 8, !tbaa !3
  %v2053 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1592, ptr %v2046)
  ret ptr %v2053
}

define private ptr @mlf.code.2080(ptr %env, ptr %arg) {
entry:
  %v2081 = getelementptr i8, ptr %env, i64 8
  %v2082 = load ptr, ptr %v2081, align 8, !tbaa !3
  %v2083 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2083, align 8, !tbaa !3
  %v2084 = call ptr @mlf.force(ptr %v2082)
  %v2085 = call ptr @mlf_prim2(i64 8, ptr %v2084, ptr inttoptr (i64 119 to ptr))
  %v2086 = call ptr @mlf_prim2(i64 15, ptr %v2085, ptr inttoptr (i64 121 to ptr))
  %v2087 = call ptr @mlf_prim2(i64 8, ptr %v2084, ptr %v2086)
  ret ptr %v2087
}

define private ptr @mlf.code.2073(ptr %env, ptr %arg) {
entry:
  %v2074 = getelementptr i8, ptr %env, i64 8
  %v2075 = load ptr, ptr %v2074, align 8, !tbaa !3
  %v2076 = getelementptr i8, ptr %env, i64 16
  %v2077 = load ptr, ptr %v2076, align 8, !tbaa !3
  %v2078 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2078, align 8, !tbaa !3
  %v2079 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2079, align 8, !tbaa !3
  %v2088 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2080, i64 1)
  %v2089 = getelementptr i8, ptr %v2088, i64 16
  %v2090 = load ptr, ptr %v2089, align 8, !tbaa !3
  %v2091 = getelementptr i8, ptr %v2090, i64 8
  store ptr %v2077, ptr %v2091, align 8, !tbaa !3
  %v2092 = call ptr @mlf_prim3(i64 40, ptr %v2075, ptr inttoptr (i64 1 to ptr), ptr %v2088)
  ret ptr %v2092
}

define private ptr @mlf.code.2098(ptr %env, ptr %arg) {
entry:
  %v2099 = getelementptr i8, ptr %env, i64 8
  %v2100 = load ptr, ptr %v2099, align 8, !tbaa !3
  %v2101 = getelementptr i8, ptr %env, i64 16
  %v2102 = load ptr, ptr %v2101, align 8, !tbaa !3
  %v2103 = getelementptr i8, ptr %env, i64 24
  %v2104 = load ptr, ptr %v2103, align 8, !tbaa !3
  %v2105 = getelementptr i8, ptr %env, i64 32
  %v2106 = load ptr, ptr %v2105, align 8, !tbaa !3
  %v2107 = getelementptr i8, ptr %env, i64 40
  %v2108 = load ptr, ptr %v2107, align 8, !tbaa !3
  %v2109 = call ptr @mlf.force(ptr %v2106)
  %v2110 = call ptr @mlf.force(ptr %v2108)
  %v2111 = call ptr @mlf_prim2(i64 9, ptr %v2109, ptr %v2110)
  %v2112 = call ptr @mlf_env_new(i64 4)
  %v2113 = getelementptr i8, ptr %v2112, i64 8
  store ptr %v2100, ptr %v2113, align 8, !tbaa !3
  %v2114 = getelementptr i8, ptr %v2112, i64 16
  store ptr %v2102, ptr %v2114, align 8, !tbaa !3
  %v2115 = getelementptr i8, ptr %v2112, i64 24
  store ptr %v2104, ptr %v2115, align 8, !tbaa !3
  %v2116 = getelementptr i8, ptr %v2112, i64 32
  store ptr %v2111, ptr %v2116, align 8, !tbaa !3
  %v2117 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1529, ptr %v2112)
  ret ptr %v2117
}

define private ptr @mlf.code.2062(ptr %env, ptr %arg) {
entry:
  %v2063 = getelementptr i8, ptr %env, i64 8
  %v2064 = load ptr, ptr %v2063, align 8, !tbaa !3
  %v2065 = getelementptr i8, ptr %env, i64 16
  %v2066 = load ptr, ptr %v2065, align 8, !tbaa !3
  %v2067 = getelementptr i8, ptr %env, i64 24
  %v2068 = load ptr, ptr %v2067, align 8, !tbaa !3
  %v2069 = getelementptr i8, ptr %env, i64 32
  %v2070 = load ptr, ptr %v2069, align 8, !tbaa !3
  %v2071 = getelementptr i8, ptr %env, i64 40
  %v2072 = load ptr, ptr %v2071, align 8, !tbaa !3
  %v2093 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2073, i64 2)
  %v2094 = getelementptr i8, ptr %v2093, i64 16
  %v2095 = load ptr, ptr %v2094, align 8, !tbaa !3
  %v2096 = getelementptr i8, ptr %v2095, i64 8
  store ptr %v2066, ptr %v2096, align 8, !tbaa !3
  %v2097 = getelementptr i8, ptr %v2095, i64 16
  store ptr %v2072, ptr %v2097, align 8, !tbaa !3
  %v2118 = call ptr @mlf_env_new(i64 5)
  %v2119 = getelementptr i8, ptr %v2118, i64 8
  store ptr %v2064, ptr %v2119, align 8, !tbaa !3
  %v2120 = getelementptr i8, ptr %v2118, i64 16
  store ptr %v2066, ptr %v2120, align 8, !tbaa !3
  %v2121 = getelementptr i8, ptr %v2118, i64 24
  store ptr %v2068, ptr %v2121, align 8, !tbaa !3
  %v2122 = getelementptr i8, ptr %v2118, i64 32
  store ptr %v2070, ptr %v2122, align 8, !tbaa !3
  %v2123 = getelementptr i8, ptr %v2118, i64 40
  store ptr %v2072, ptr %v2123, align 8, !tbaa !3
  %v2124 = call ptr @mlf_closure(ptr @mlf.code.2098, ptr %v2118)
  %v2125 = call ptr @mlf_prim2(i64 1, ptr %v2093, ptr %v2124)
  ret ptr %v2125
}

define private ptr @mlf.worker.45(ptr %a0, ptr %a1, ptr %a2, ptr %a3) {
entry:
  %v1555 = call ptr @mlf_prim2(i64 10, ptr %a3, ptr inttoptr (i64 1 to ptr))
  %v1556 = icmp eq ptr %v1555, inttoptr (i64 6 to ptr)
  br i1 %v1556, label %yes.1557, label %no.1558
yes.1557:
  %v1560 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.1559
no.1558:
  %v1572 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1561, i64 1)
  %v1573 = getelementptr i8, ptr %v1572, i64 16
  %v1574 = load ptr, ptr %v1573, align 8, !tbaa !3
  %v1575 = getelementptr i8, ptr %v1574, i64 8
  store ptr %a3, ptr %v1575, align 8, !tbaa !3
  %v2054 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1576, i64 5)
  %v2055 = getelementptr i8, ptr %v2054, i64 16
  %v2056 = load ptr, ptr %v2055, align 8, !tbaa !3
  %v2057 = getelementptr i8, ptr %v2056, i64 8
  store ptr %a0, ptr %v2057, align 8, !tbaa !3
  %v2058 = getelementptr i8, ptr %v2056, i64 16
  store ptr %a1, ptr %v2058, align 8, !tbaa !3
  %v2059 = getelementptr i8, ptr %v2056, i64 24
  store ptr %a2, ptr %v2059, align 8, !tbaa !3
  %v2060 = getelementptr i8, ptr %v2056, i64 32
  store ptr %a3, ptr %v2060, align 8, !tbaa !3
  %v2061 = getelementptr i8, ptr %v2056, i64 40
  store ptr %v1572, ptr %v2061, align 8, !tbaa !3
  %v2126 = call ptr @mlf_env_new(i64 5)
  %v2127 = getelementptr i8, ptr %v2126, i64 8
  store ptr %a0, ptr %v2127, align 8, !tbaa !3
  %v2128 = getelementptr i8, ptr %v2126, i64 16
  store ptr %a1, ptr %v2128, align 8, !tbaa !3
  %v2129 = getelementptr i8, ptr %v2126, i64 24
  store ptr %a2, ptr %v2129, align 8, !tbaa !3
  %v2130 = getelementptr i8, ptr %v2126, i64 32
  store ptr %a3, ptr %v2130, align 8, !tbaa !3
  %v2131 = getelementptr i8, ptr %v2126, i64 40
  store ptr %v1572, ptr %v2131, align 8, !tbaa !3
  %v2132 = call ptr @mlf_closure(ptr @mlf.code.2062, ptr %v2126)
  %v2133 = call ptr @mlf_prim2(i64 1, ptr %v2054, ptr %v2132)
  br label %join.1559
join.1559:
  %v2134 = phi ptr [ %v1560, %yes.1557 ], [ %v2133, %no.1558 ]
  ret ptr %v2134
}

define private ptr @mlf.numeric.entry.1529(ptr %env, ptr %arg) {
entry:
  %v1530 = getelementptr i8, ptr %env, i64 8
  %v1531 = load ptr, ptr %v1530, align 8, !tbaa !3
  %v1532 = getelementptr i8, ptr %env, i64 16
  %v1533 = load ptr, ptr %v1532, align 8, !tbaa !3
  %v1534 = getelementptr i8, ptr %env, i64 24
  %v1535 = load ptr, ptr %v1534, align 8, !tbaa !3
  %v1536 = getelementptr i8, ptr %env, i64 32
  %v1537 = load ptr, ptr %v1536, align 8, !tbaa !3
  %v1538 = call ptr @mlf_peek(ptr %v1531)
  %v1539 = call ptr @mlf_peek(ptr %v1533)
  %v1540 = call ptr @mlf_peek(ptr %v1535)
  %v1541 = call ptr @mlf_peek(ptr %v1537)
  %v1542 = icmp ne ptr %v1538, null
  %v1543 = icmp ne ptr %v1539, null
  %v1544 = icmp ne ptr %v1540, null
  %v1545 = icmp ne ptr %v1541, null
  %v1546 = and i1 true, %v1542
  %v1547 = and i1 %v1546, %v1543
  %v1548 = and i1 %v1547, %v1544
  %v1549 = and i1 %v1548, %v1545
  br i1 %v1549, label %yes.1550, label %no.1551
yes.1550:
  %v1553 = call ptr @mlf.numeric.45(ptr %v1538, ptr %v1539, ptr %v1540, ptr %v1541)
  %v1554 = call ptr @mlf_prim1(i64 0, ptr %v1553)
  br label %join.1552
no.1551:
  %v2135 = call ptr @mlf.force(ptr %v1537)
  %v2136 = call ptr @mlf.worker.45(ptr %v1531, ptr %v1533, ptr %v1535, ptr %v2135)
  br label %join.1552
join.1552:
  %v2137 = phi ptr [ %v1554, %yes.1550 ], [ %v2136, %no.1551 ]
  ret ptr %v2137
}

define private ptr @mlf.code.2145(ptr %env, ptr %arg) {
entry:
  %v2146 = getelementptr i8, ptr %env, i64 8
  %v2147 = load ptr, ptr %v2146, align 8, !tbaa !3
  %v2148 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2148, align 8, !tbaa !3
  %v2149 = call ptr @mlf_prim2(i64 36, ptr %v2147, ptr inttoptr (i64 1 to ptr))
  ret ptr %v2149
}

define private ptr @mlf.code.2175(ptr %env, ptr %arg) {
entry:
  %v2176 = getelementptr i8, ptr %env, i64 8
  %v2177 = load ptr, ptr %v2176, align 8, !tbaa !3
  %v2178 = getelementptr i8, ptr %env, i64 16
  %v2179 = load ptr, ptr %v2178, align 8, !tbaa !3
  %v2180 = getelementptr i8, ptr %env, i64 24
  %v2181 = load ptr, ptr %v2180, align 8, !tbaa !3
  %v2182 = getelementptr i8, ptr %env, i64 32
  %v2183 = load ptr, ptr %v2182, align 8, !tbaa !3
  %v2184 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2184, align 8, !tbaa !3
  %v2185 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2185, align 8, !tbaa !3
  %v2186 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v2186, align 8, !tbaa !3
  %v2187 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v2187, align 8, !tbaa !3
  %v2188 = call ptr @mlf.force(ptr %v2183)
  %v2189 = call ptr @mlf_env_new(i64 4)
  %v2190 = getelementptr i8, ptr %v2189, i64 8
  store ptr %v2177, ptr %v2190, align 8, !tbaa !3
  %v2191 = getelementptr i8, ptr %v2189, i64 16
  store ptr %v2179, ptr %v2191, align 8, !tbaa !3
  %v2192 = getelementptr i8, ptr %v2189, i64 24
  store ptr %v2181, ptr %v2192, align 8, !tbaa !3
  %v2193 = getelementptr i8, ptr %v2189, i64 32
  store ptr %v2188, ptr %v2193, align 8, !tbaa !3
  %v2194 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1529, ptr %v2189)
  ret ptr %v2194
}

define private ptr @mlf.code.2215(ptr %env, ptr %arg) {
entry:
  %v2216 = getelementptr i8, ptr %env, i64 8
  %v2217 = load ptr, ptr %v2216, align 8, !tbaa !3
  %v2218 = getelementptr i8, ptr %env, i64 16
  %v2219 = load ptr, ptr %v2218, align 8, !tbaa !3
  %v2220 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2220, align 8, !tbaa !3
  %v2221 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2221, align 8, !tbaa !3
  %v2222 = call ptr @mlf_prim3(i64 40, ptr %v2217, ptr inttoptr (i64 1 to ptr), ptr %v2219)
  ret ptr %v2222
}

define private ptr @mlf.code.2228(ptr %env, ptr %arg) {
entry:
  %v2229 = getelementptr i8, ptr %env, i64 8
  %v2230 = load ptr, ptr %v2229, align 8, !tbaa !3
  %v2231 = getelementptr i8, ptr %env, i64 16
  %v2232 = load ptr, ptr %v2231, align 8, !tbaa !3
  %v2233 = getelementptr i8, ptr %env, i64 24
  %v2234 = load ptr, ptr %v2233, align 8, !tbaa !3
  %v2235 = getelementptr i8, ptr %env, i64 32
  %v2236 = load ptr, ptr %v2235, align 8, !tbaa !3
  %v2237 = call ptr @mlf_env_new(i64 5)
  %v2238 = getelementptr i8, ptr %v2237, i64 8
  store ptr %v2230, ptr %v2238, align 8, !tbaa !3
  %v2239 = getelementptr i8, ptr %v2237, i64 16
  store ptr %v2232, ptr %v2239, align 8, !tbaa !3
  %v2240 = getelementptr i8, ptr %v2237, i64 24
  store ptr %v2234, ptr %v2240, align 8, !tbaa !3
  %v2241 = getelementptr i8, ptr %v2237, i64 32
  store ptr inttoptr (i64 1 to ptr), ptr %v2241, align 8, !tbaa !3
  %v2242 = getelementptr i8, ptr %v2237, i64 40
  store ptr %v2236, ptr %v2242, align 8, !tbaa !3
  %v2243 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.428, ptr %v2237)
  ret ptr %v2243
}

define private ptr @mlf.code.2202(ptr %env, ptr %arg) {
entry:
  %v2203 = getelementptr i8, ptr %env, i64 8
  %v2204 = load ptr, ptr %v2203, align 8, !tbaa !3
  %v2205 = getelementptr i8, ptr %env, i64 16
  %v2206 = load ptr, ptr %v2205, align 8, !tbaa !3
  %v2207 = getelementptr i8, ptr %env, i64 24
  %v2208 = load ptr, ptr %v2207, align 8, !tbaa !3
  %v2209 = getelementptr i8, ptr %env, i64 32
  %v2210 = load ptr, ptr %v2209, align 8, !tbaa !3
  %v2211 = getelementptr i8, ptr %env, i64 40
  %v2212 = load ptr, ptr %v2211, align 8, !tbaa !3
  %v2213 = getelementptr i8, ptr %env, i64 48
  %v2214 = load ptr, ptr %v2213, align 8, !tbaa !3
  %v2223 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2215, i64 2)
  %v2224 = getelementptr i8, ptr %v2223, i64 16
  %v2225 = load ptr, ptr %v2224, align 8, !tbaa !3
  %v2226 = getelementptr i8, ptr %v2225, i64 8
  store ptr %v2212, ptr %v2226, align 8, !tbaa !3
  %v2227 = getelementptr i8, ptr %v2225, i64 16
  store ptr %v2214, ptr %v2227, align 8, !tbaa !3
  %v2244 = call ptr @mlf_env_new(i64 4)
  %v2245 = getelementptr i8, ptr %v2244, i64 8
  store ptr %v2204, ptr %v2245, align 8, !tbaa !3
  %v2246 = getelementptr i8, ptr %v2244, i64 16
  store ptr %v2206, ptr %v2246, align 8, !tbaa !3
  %v2247 = getelementptr i8, ptr %v2244, i64 24
  store ptr %v2208, ptr %v2247, align 8, !tbaa !3
  %v2248 = getelementptr i8, ptr %v2244, i64 32
  store ptr %v2210, ptr %v2248, align 8, !tbaa !3
  %v2249 = call ptr @mlf_closure(ptr @mlf.code.2228, ptr %v2244)
  %v2250 = call ptr @mlf_prim2(i64 1, ptr %v2223, ptr %v2249)
  ret ptr %v2250
}

define private ptr @mlf.code.2296(ptr %env, ptr %arg) {
entry:
  %v2297 = getelementptr i8, ptr %env, i64 8
  %v2298 = load ptr, ptr %v2297, align 8, !tbaa !3
  %v2299 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2299, align 8, !tbaa !3
  %v2300 = call ptr @mlf.force(ptr %v2298)
  %v2301 = call ptr @mlf_prim2(i64 9, ptr %v2300, ptr inttoptr (i64 3 to ptr))
  ret ptr %v2301
}

define private ptr @mlf.code.2289(ptr %env, ptr %arg) {
entry:
  %v2290 = getelementptr i8, ptr %env, i64 8
  %v2291 = load ptr, ptr %v2290, align 8, !tbaa !3
  %v2292 = getelementptr i8, ptr %env, i64 16
  %v2293 = load ptr, ptr %v2292, align 8, !tbaa !3
  %v2294 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2294, align 8, !tbaa !3
  %v2295 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2295, align 8, !tbaa !3
  %v2302 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2296, i64 1)
  %v2303 = getelementptr i8, ptr %v2302, i64 16
  %v2304 = load ptr, ptr %v2303, align 8, !tbaa !3
  %v2305 = getelementptr i8, ptr %v2304, i64 8
  store ptr %v2293, ptr %v2305, align 8, !tbaa !3
  %v2306 = call ptr @mlf_prim2(i64 36, ptr %v2291, ptr %v2302)
  ret ptr %v2306
}

define private ptr @mlf.code.2312(ptr %env, ptr %arg) {
entry:
  %v2313 = getelementptr i8, ptr %env, i64 8
  %v2314 = load ptr, ptr %v2313, align 8, !tbaa !3
  %v2315 = getelementptr i8, ptr %env, i64 16
  %v2316 = load ptr, ptr %v2315, align 8, !tbaa !3
  %v2317 = call ptr @mlf.force(ptr %arg)
  %v2318 = call ptr @mlf_prim2(i64 10, ptr %v2317, ptr inttoptr (i64 21 to ptr))
  %v2319 = icmp eq ptr %v2318, inttoptr (i64 6 to ptr)
  br i1 %v2319, label %yes.2320, label %no.2321
yes.2320:
  %v2323 = call ptr @mlf.force(ptr %v2316)
  %v2324 = call ptr @mlf_prim2(i64 9, ptr %v2323, ptr inttoptr (i64 3 to ptr))
  %v2325 = call ptr @mlf_env_new(i64 2)
  %v2326 = getelementptr i8, ptr %v2325, i64 8
  store ptr %v2314, ptr %v2326, align 8, !tbaa !3
  %v2327 = getelementptr i8, ptr %v2325, i64 16
  store ptr %v2324, ptr %v2327, align 8, !tbaa !3
  %v2328 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2267, ptr %v2325)
  br label %join.2322
no.2321:
  %v2329 = call ptr @mlf_prim2(i64 10, ptr %v2317, ptr inttoptr (i64 27 to ptr))
  %v2330 = icmp eq ptr %v2329, inttoptr (i64 6 to ptr)
  br i1 %v2330, label %yes.2331, label %no.2332
yes.2331:
  %v2334 = call ptr @mlf.force(ptr %v2316)
  %v2335 = call ptr @mlf_prim2(i64 9, ptr %v2334, ptr inttoptr (i64 3 to ptr))
  %v2336 = call ptr @mlf_env_new(i64 2)
  %v2337 = getelementptr i8, ptr %v2336, i64 8
  store ptr %v2314, ptr %v2337, align 8, !tbaa !3
  %v2338 = getelementptr i8, ptr %v2336, i64 16
  store ptr %v2335, ptr %v2338, align 8, !tbaa !3
  %v2339 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2267, ptr %v2336)
  br label %join.2333
no.2332:
  %v2340 = call ptr @mlf_prim1(i64 0, ptr %v2316)
  br label %join.2333
join.2333:
  %v2341 = phi ptr [ %v2339, %yes.2331 ], [ %v2340, %no.2332 ]
  br label %join.2322
join.2322:
  %v2342 = phi ptr [ %v2328, %yes.2320 ], [ %v2341, %join.2333 ]
  ret ptr %v2342
}

define private ptr @mlf.worker.11(ptr %a0, ptr %a1) {
entry:
  %v2283 = call ptr @mlf_prim2(i64 10, ptr %a1, ptr inttoptr (i64 1 to ptr))
  %v2284 = icmp eq ptr %v2283, inttoptr (i64 6 to ptr)
  br i1 %v2284, label %yes.2285, label %no.2286
yes.2285:
  %v2288 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 1 to ptr))
  br label %join.2287
no.2286:
  %v2307 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2289, i64 2)
  %v2308 = getelementptr i8, ptr %v2307, i64 16
  %v2309 = load ptr, ptr %v2308, align 8, !tbaa !3
  %v2310 = getelementptr i8, ptr %v2309, i64 8
  store ptr %a0, ptr %v2310, align 8, !tbaa !3
  %v2311 = getelementptr i8, ptr %v2309, i64 16
  store ptr %a1, ptr %v2311, align 8, !tbaa !3
  %v2343 = call ptr @mlf_env_new(i64 2)
  %v2344 = getelementptr i8, ptr %v2343, i64 8
  store ptr %a0, ptr %v2344, align 8, !tbaa !3
  %v2345 = getelementptr i8, ptr %v2343, i64 16
  store ptr %a1, ptr %v2345, align 8, !tbaa !3
  %v2346 = call ptr @mlf_closure(ptr @mlf.code.2312, ptr %v2343)
  %v2347 = call ptr @mlf_prim2(i64 1, ptr %v2307, ptr %v2346)
  br label %join.2287
join.2287:
  %v2348 = phi ptr [ %v2288, %yes.2285 ], [ %v2347, %no.2286 ]
  ret ptr %v2348
}

define private ptr @mlf.numeric.entry.2267(ptr %env, ptr %arg) {
entry:
  %v2268 = getelementptr i8, ptr %env, i64 8
  %v2269 = load ptr, ptr %v2268, align 8, !tbaa !3
  %v2270 = getelementptr i8, ptr %env, i64 16
  %v2271 = load ptr, ptr %v2270, align 8, !tbaa !3
  %v2272 = call ptr @mlf_peek(ptr %v2269)
  %v2273 = call ptr @mlf_peek(ptr %v2271)
  %v2274 = icmp ne ptr %v2272, null
  %v2275 = icmp ne ptr %v2273, null
  %v2276 = and i1 true, %v2274
  %v2277 = and i1 %v2276, %v2275
  br i1 %v2277, label %yes.2278, label %no.2279
yes.2278:
  %v2281 = call ptr @mlf.numeric.11(ptr %v2272, ptr %v2273)
  %v2282 = call ptr @mlf_prim1(i64 0, ptr %v2281)
  br label %join.2280
no.2279:
  %v2349 = call ptr @mlf.force(ptr %v2271)
  %v2350 = call ptr @mlf.worker.11(ptr %v2269, ptr %v2349)
  br label %join.2280
join.2280:
  %v2351 = phi ptr [ %v2282, %yes.2278 ], [ %v2350, %no.2279 ]
  ret ptr %v2351
}

define private ptr @mlf.code.2260(ptr %env, ptr %arg) {
entry:
  %v2261 = getelementptr i8, ptr %env, i64 8
  %v2262 = load ptr, ptr %v2261, align 8, !tbaa !3
  %v2263 = getelementptr i8, ptr %env, i64 16
  %v2264 = load ptr, ptr %v2263, align 8, !tbaa !3
  %v2265 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2265, align 8, !tbaa !3
  %v2266 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2266, align 8, !tbaa !3
  %v2352 = call ptr @mlf.force(ptr %v2264)
  %v2353 = call ptr @mlf_env_new(i64 2)
  %v2354 = getelementptr i8, ptr %v2353, i64 8
  store ptr %v2262, ptr %v2354, align 8, !tbaa !3
  %v2355 = getelementptr i8, ptr %v2353, i64 16
  store ptr %v2352, ptr %v2355, align 8, !tbaa !3
  %v2356 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2267, ptr %v2353)
  ret ptr %v2356
}

define private ptr @mlf.worker.8(ptr %a0, ptr %a1) {
entry:
  %v2407 = call ptr @mlf_prim2(i64 11, ptr %a0, ptr %a1)
  %v2408 = icmp eq ptr %v2407, inttoptr (i64 6 to ptr)
  br i1 %v2408, label %yes.2409, label %no.2410
yes.2409:
  %v2412 = call ptr @mlf_prim2(i64 14, ptr %a0, ptr inttoptr (i64 5 to ptr))
  %v2413 = call ptr @mlf_env_new(i64 2)
  %v2414 = getelementptr i8, ptr %v2413, i64 8
  store ptr %v2412, ptr %v2414, align 8, !tbaa !3
  %v2415 = getelementptr i8, ptr %v2413, i64 16
  store ptr %a1, ptr %v2415, align 8, !tbaa !3
  %v2416 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2391, ptr %v2413)
  br label %join.2411
no.2410:
  %v2417 = call ptr @mlf_prim1(i64 0, ptr %a0)
  br label %join.2411
join.2411:
  %v2418 = phi ptr [ %v2416, %yes.2409 ], [ %v2417, %no.2410 ]
  ret ptr %v2418
}

define private ptr @mlf.numeric.entry.2391(ptr %env, ptr %arg) {
entry:
  %v2392 = getelementptr i8, ptr %env, i64 8
  %v2393 = load ptr, ptr %v2392, align 8, !tbaa !3
  %v2394 = getelementptr i8, ptr %env, i64 16
  %v2395 = load ptr, ptr %v2394, align 8, !tbaa !3
  %v2396 = call ptr @mlf_peek(ptr %v2393)
  %v2397 = call ptr @mlf_peek(ptr %v2395)
  %v2398 = icmp ne ptr %v2396, null
  %v2399 = icmp ne ptr %v2397, null
  %v2400 = and i1 true, %v2398
  %v2401 = and i1 %v2400, %v2399
  br i1 %v2401, label %yes.2402, label %no.2403
yes.2402:
  %v2405 = call ptr @mlf.numeric.8(ptr %v2396, ptr %v2397)
  %v2406 = call ptr @mlf_prim1(i64 0, ptr %v2405)
  br label %join.2404
no.2403:
  %v2419 = call ptr @mlf.force(ptr %v2393)
  %v2420 = call ptr @mlf.force(ptr %v2395)
  %v2421 = call ptr @mlf.worker.8(ptr %v2419, ptr %v2420)
  br label %join.2404
join.2404:
  %v2422 = phi ptr [ %v2406, %yes.2402 ], [ %v2421, %no.2403 ]
  ret ptr %v2422
}

define private ptr @mlf.code.2384(ptr %env, ptr %arg) {
entry:
  %v2385 = getelementptr i8, ptr %env, i64 8
  %v2386 = load ptr, ptr %v2385, align 8, !tbaa !3
  %v2387 = getelementptr i8, ptr %env, i64 16
  %v2388 = load ptr, ptr %v2387, align 8, !tbaa !3
  %v2389 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2389, align 8, !tbaa !3
  %v2390 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2390, align 8, !tbaa !3
  %v2423 = call ptr @mlf.force(ptr %v2386)
  %v2424 = call ptr @mlf.force(ptr %v2388)
  %v2425 = call ptr @mlf_env_new(i64 2)
  %v2426 = getelementptr i8, ptr %v2425, i64 8
  store ptr %v2423, ptr %v2426, align 8, !tbaa !3
  %v2427 = getelementptr i8, ptr %v2425, i64 16
  store ptr %v2424, ptr %v2427, align 8, !tbaa !3
  %v2428 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2391, ptr %v2425)
  ret ptr %v2428
}

define private ptr @mlf.code.2449(ptr %env, ptr %arg) {
entry:
  %v2450 = getelementptr i8, ptr %env, i64 8
  %v2451 = load ptr, ptr %v2450, align 8, !tbaa !3
  %v2452 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2452, align 8, !tbaa !3
  %v2453 = call ptr @mlf_prim2(i64 35, ptr %v2451, ptr inttoptr (i64 1 to ptr))
  ret ptr %v2453
}

define private ptr @mlf.code.2521(ptr %env, ptr %arg) {
entry:
  %v2522 = getelementptr i8, ptr %env, i64 8
  %v2523 = load ptr, ptr %v2522, align 8, !tbaa !3
  %v2524 = getelementptr i8, ptr %env, i64 16
  %v2525 = load ptr, ptr %v2524, align 8, !tbaa !3
  %v2526 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2526, align 8, !tbaa !3
  %v2527 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2527, align 8, !tbaa !3
  %v2528 = call ptr @mlf_prim2(i64 36, ptr %v2523, ptr %v2525)
  ret ptr %v2528
}

define private ptr @mlf.code.2558(ptr %env, ptr %arg) {
entry:
  %v2559 = getelementptr i8, ptr %env, i64 8
  %v2560 = load ptr, ptr %v2559, align 8, !tbaa !3
  %v2561 = getelementptr i8, ptr %env, i64 16
  %v2562 = load ptr, ptr %v2561, align 8, !tbaa !3
  %v2563 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2563, align 8, !tbaa !3
  %v2564 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2564, align 8, !tbaa !3
  %v2565 = call ptr @mlf.force(ptr %v2560)
  %v2566 = call ptr @mlf.force(ptr %v2562)
  %v2567 = call ptr @mlf_prim2(i64 8, ptr %v2565, ptr %v2566)
  ret ptr %v2567
}

define private ptr @mlf.code.2545(ptr %env, ptr %arg) {
entry:
  %v2546 = getelementptr i8, ptr %env, i64 8
  %v2547 = load ptr, ptr %v2546, align 8, !tbaa !3
  %v2548 = getelementptr i8, ptr %env, i64 16
  %v2549 = load ptr, ptr %v2548, align 8, !tbaa !3
  %v2550 = getelementptr i8, ptr %env, i64 24
  %v2551 = load ptr, ptr %v2550, align 8, !tbaa !3
  %v2552 = getelementptr i8, ptr %env, i64 32
  %v2553 = load ptr, ptr %v2552, align 8, !tbaa !3
  %v2554 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2554, align 8, !tbaa !3
  %v2555 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2555, align 8, !tbaa !3
  %v2556 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v2556, align 8, !tbaa !3
  %v2557 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v2557, align 8, !tbaa !3
  %v2568 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2558, i64 2)
  %v2569 = getelementptr i8, ptr %v2568, i64 16
  %v2570 = load ptr, ptr %v2569, align 8, !tbaa !3
  %v2571 = getelementptr i8, ptr %v2570, i64 8
  store ptr %v2549, ptr %v2571, align 8, !tbaa !3
  %v2572 = getelementptr i8, ptr %v2570, i64 16
  store ptr %v2551, ptr %v2572, align 8, !tbaa !3
  %v2573 = call ptr @mlf_prim3(i64 37, ptr %v2547, ptr %v2568, ptr %v2553)
  ret ptr %v2573
}

define private ptr @mlf.code.2581(ptr %env, ptr %arg) {
entry:
  %v2582 = getelementptr i8, ptr %env, i64 8
  %v2583 = load ptr, ptr %v2582, align 8, !tbaa !3
  %v2584 = getelementptr i8, ptr %env, i64 16
  %v2585 = load ptr, ptr %v2584, align 8, !tbaa !3
  %v2586 = getelementptr i8, ptr %env, i64 24
  %v2587 = load ptr, ptr %v2586, align 8, !tbaa !3
  %v2588 = getelementptr i8, ptr %env, i64 32
  %v2589 = load ptr, ptr %v2588, align 8, !tbaa !3
  %v2590 = getelementptr i8, ptr %env, i64 40
  %v2591 = load ptr, ptr %v2590, align 8, !tbaa !3
  %v2592 = call ptr @mlf.force(ptr %v2587)
  %v2593 = call ptr @mlf.force(ptr %v2591)
  %v2594 = call ptr @mlf_prim2(i64 8, ptr %v2593, ptr inttoptr (i64 3 to ptr))
  %v2595 = call ptr @mlf_env_new(i64 5)
  %v2596 = getelementptr i8, ptr %v2595, i64 8
  store ptr %v2583, ptr %v2596, align 8, !tbaa !3
  %v2597 = getelementptr i8, ptr %v2595, i64 16
  store ptr %v2585, ptr %v2597, align 8, !tbaa !3
  %v2598 = getelementptr i8, ptr %v2595, i64 24
  store ptr %v2592, ptr %v2598, align 8, !tbaa !3
  %v2599 = getelementptr i8, ptr %v2595, i64 32
  store ptr %v2589, ptr %v2599, align 8, !tbaa !3
  %v2600 = getelementptr i8, ptr %v2595, i64 40
  store ptr %v2594, ptr %v2600, align 8, !tbaa !3
  %v2601 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2485, ptr %v2595)
  ret ptr %v2601
}

define private ptr @mlf.code.2534(ptr %env, ptr %arg) {
entry:
  %v2535 = getelementptr i8, ptr %env, i64 8
  %v2536 = load ptr, ptr %v2535, align 8, !tbaa !3
  %v2537 = getelementptr i8, ptr %env, i64 16
  %v2538 = load ptr, ptr %v2537, align 8, !tbaa !3
  %v2539 = getelementptr i8, ptr %env, i64 24
  %v2540 = load ptr, ptr %v2539, align 8, !tbaa !3
  %v2541 = getelementptr i8, ptr %env, i64 32
  %v2542 = load ptr, ptr %v2541, align 8, !tbaa !3
  %v2543 = getelementptr i8, ptr %env, i64 40
  %v2544 = load ptr, ptr %v2543, align 8, !tbaa !3
  %v2574 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2545, i64 4)
  %v2575 = getelementptr i8, ptr %v2574, i64 16
  %v2576 = load ptr, ptr %v2575, align 8, !tbaa !3
  %v2577 = getelementptr i8, ptr %v2576, i64 8
  store ptr %v2538, ptr %v2577, align 8, !tbaa !3
  %v2578 = getelementptr i8, ptr %v2576, i64 16
  store ptr %v2542, ptr %v2578, align 8, !tbaa !3
  %v2579 = getelementptr i8, ptr %v2576, i64 24
  store ptr %v2544, ptr %v2579, align 8, !tbaa !3
  %v2580 = getelementptr i8, ptr %v2576, i64 32
  store ptr %arg, ptr %v2580, align 8, !tbaa !3
  %v2602 = call ptr @mlf_env_new(i64 5)
  %v2603 = getelementptr i8, ptr %v2602, i64 8
  store ptr %v2536, ptr %v2603, align 8, !tbaa !3
  %v2604 = getelementptr i8, ptr %v2602, i64 16
  store ptr %v2538, ptr %v2604, align 8, !tbaa !3
  %v2605 = getelementptr i8, ptr %v2602, i64 24
  store ptr %v2540, ptr %v2605, align 8, !tbaa !3
  %v2606 = getelementptr i8, ptr %v2602, i64 32
  store ptr %v2542, ptr %v2606, align 8, !tbaa !3
  %v2607 = getelementptr i8, ptr %v2602, i64 40
  store ptr %v2544, ptr %v2607, align 8, !tbaa !3
  %v2608 = call ptr @mlf_closure(ptr @mlf.code.2581, ptr %v2602)
  %v2609 = call ptr @mlf_prim2(i64 1, ptr %v2574, ptr %v2608)
  ret ptr %v2609
}

define private ptr @mlf.worker.0(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) {
entry:
  %v2516 = call ptr @mlf_prim2(i64 11, ptr %a4, ptr %a2)
  %v2517 = icmp eq ptr %v2516, inttoptr (i64 6 to ptr)
  br i1 %v2517, label %yes.2518, label %no.2519
yes.2518:
  %v2529 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2521, i64 2)
  %v2530 = getelementptr i8, ptr %v2529, i64 16
  %v2531 = load ptr, ptr %v2530, align 8, !tbaa !3
  %v2532 = getelementptr i8, ptr %v2531, i64 8
  store ptr %a0, ptr %v2532, align 8, !tbaa !3
  %v2533 = getelementptr i8, ptr %v2531, i64 16
  store ptr %a4, ptr %v2533, align 8, !tbaa !3
  %v2610 = call ptr @mlf_env_new(i64 5)
  %v2611 = getelementptr i8, ptr %v2610, i64 8
  store ptr %a0, ptr %v2611, align 8, !tbaa !3
  %v2612 = getelementptr i8, ptr %v2610, i64 16
  store ptr %a1, ptr %v2612, align 8, !tbaa !3
  %v2613 = getelementptr i8, ptr %v2610, i64 24
  store ptr %a2, ptr %v2613, align 8, !tbaa !3
  %v2614 = getelementptr i8, ptr %v2610, i64 32
  store ptr %a3, ptr %v2614, align 8, !tbaa !3
  %v2615 = getelementptr i8, ptr %v2610, i64 40
  store ptr %a4, ptr %v2615, align 8, !tbaa !3
  %v2616 = call ptr @mlf_closure(ptr @mlf.code.2534, ptr %v2610)
  %v2617 = call ptr @mlf_prim2(i64 1, ptr %v2529, ptr %v2616)
  br label %join.2520
no.2519:
  %v2618 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.2520
join.2520:
  %v2619 = phi ptr [ %v2617, %yes.2518 ], [ %v2618, %no.2519 ]
  ret ptr %v2619
}

define private ptr @mlf.numeric.entry.2485(ptr %env, ptr %arg) {
entry:
  %v2486 = getelementptr i8, ptr %env, i64 8
  %v2487 = load ptr, ptr %v2486, align 8, !tbaa !3
  %v2488 = getelementptr i8, ptr %env, i64 16
  %v2489 = load ptr, ptr %v2488, align 8, !tbaa !3
  %v2490 = getelementptr i8, ptr %env, i64 24
  %v2491 = load ptr, ptr %v2490, align 8, !tbaa !3
  %v2492 = getelementptr i8, ptr %env, i64 32
  %v2493 = load ptr, ptr %v2492, align 8, !tbaa !3
  %v2494 = getelementptr i8, ptr %env, i64 40
  %v2495 = load ptr, ptr %v2494, align 8, !tbaa !3
  %v2496 = call ptr @mlf_peek(ptr %v2487)
  %v2497 = call ptr @mlf_peek(ptr %v2489)
  %v2498 = call ptr @mlf_peek(ptr %v2491)
  %v2499 = call ptr @mlf_peek(ptr %v2493)
  %v2500 = call ptr @mlf_peek(ptr %v2495)
  %v2501 = icmp ne ptr %v2496, null
  %v2502 = icmp ne ptr %v2497, null
  %v2503 = icmp ne ptr %v2498, null
  %v2504 = icmp ne ptr %v2499, null
  %v2505 = icmp ne ptr %v2500, null
  %v2506 = and i1 true, %v2501
  %v2507 = and i1 %v2506, %v2502
  %v2508 = and i1 %v2507, %v2503
  %v2509 = and i1 %v2508, %v2504
  %v2510 = and i1 %v2509, %v2505
  br i1 %v2510, label %yes.2511, label %no.2512
yes.2511:
  %v2514 = call ptr @mlf.numeric.0(ptr %v2496, ptr %v2497, ptr %v2498, ptr %v2499, ptr %v2500)
  %v2515 = call ptr @mlf_prim1(i64 0, ptr %v2514)
  br label %join.2513
no.2512:
  %v2620 = call ptr @mlf.force(ptr %v2491)
  %v2621 = call ptr @mlf.force(ptr %v2495)
  %v2622 = call ptr @mlf.worker.0(ptr %v2487, ptr %v2489, ptr %v2620, ptr %v2493, ptr %v2621)
  br label %join.2513
join.2513:
  %v2623 = phi ptr [ %v2515, %yes.2511 ], [ %v2622, %no.2512 ]
  ret ptr %v2623
}

define private ptr @mlf.code.2475(ptr %env, ptr %arg) {
entry:
  %v2476 = getelementptr i8, ptr %env, i64 8
  %v2477 = load ptr, ptr %v2476, align 8, !tbaa !3
  %v2478 = getelementptr i8, ptr %env, i64 16
  %v2479 = load ptr, ptr %v2478, align 8, !tbaa !3
  %v2480 = getelementptr i8, ptr %env, i64 24
  %v2481 = load ptr, ptr %v2480, align 8, !tbaa !3
  %v2482 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2482, align 8, !tbaa !3
  %v2483 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2483, align 8, !tbaa !3
  %v2484 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v2484, align 8, !tbaa !3
  %v2624 = call ptr @mlf.force(ptr %v2479)
  %v2625 = call ptr @mlf_env_new(i64 5)
  %v2626 = getelementptr i8, ptr %v2625, i64 8
  store ptr %v2477, ptr %v2626, align 8, !tbaa !3
  %v2627 = getelementptr i8, ptr %v2625, i64 16
  store ptr %v2481, ptr %v2627, align 8, !tbaa !3
  %v2628 = getelementptr i8, ptr %v2625, i64 24
  store ptr %v2624, ptr %v2628, align 8, !tbaa !3
  %v2629 = getelementptr i8, ptr %v2625, i64 32
  store ptr inttoptr (i64 1 to ptr), ptr %v2629, align 8, !tbaa !3
  %v2630 = getelementptr i8, ptr %v2625, i64 40
  store ptr inttoptr (i64 1 to ptr), ptr %v2630, align 8, !tbaa !3
  %v2631 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2485, ptr %v2625)
  ret ptr %v2631
}

define private ptr @mlf.code.2655(ptr %env, ptr %arg) {
entry:
  %v2656 = getelementptr i8, ptr %env, i64 8
  %v2657 = load ptr, ptr %v2656, align 8, !tbaa !3
  %v2658 = getelementptr i8, ptr %env, i64 16
  %v2659 = load ptr, ptr %v2658, align 8, !tbaa !3
  %v2660 = getelementptr i8, ptr %env, i64 24
  %v2661 = load ptr, ptr %v2660, align 8, !tbaa !3
  %v2662 = getelementptr i8, ptr %env, i64 32
  %v2663 = load ptr, ptr %v2662, align 8, !tbaa !3
  %v2664 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2664, align 8, !tbaa !3
  %v2665 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2665, align 8, !tbaa !3
  %v2666 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v2666, align 8, !tbaa !3
  %v2667 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v2667, align 8, !tbaa !3
  %v2668 = call ptr @mlf.force(ptr %v2661)
  %v2669 = call ptr @mlf_env_new(i64 5)
  %v2670 = getelementptr i8, ptr %v2669, i64 8
  store ptr %v2659, ptr %v2670, align 8, !tbaa !3
  %v2671 = getelementptr i8, ptr %v2669, i64 16
  store ptr %v2663, ptr %v2671, align 8, !tbaa !3
  %v2672 = getelementptr i8, ptr %v2669, i64 24
  store ptr %v2668, ptr %v2672, align 8, !tbaa !3
  %v2673 = getelementptr i8, ptr %v2669, i64 32
  store ptr %v2657, ptr %v2673, align 8, !tbaa !3
  %v2674 = getelementptr i8, ptr %v2669, i64 40
  store ptr inttoptr (i64 1 to ptr), ptr %v2674, align 8, !tbaa !3
  %v2675 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2485, ptr %v2669)
  ret ptr %v2675
}

define private ptr @mlf.code.2683(ptr %env, ptr %arg) {
entry:
  %v2684 = getelementptr i8, ptr %env, i64 8
  %v2685 = load ptr, ptr %v2684, align 8, !tbaa !3
  %v2686 = getelementptr i8, ptr %env, i64 16
  %v2687 = load ptr, ptr %v2686, align 8, !tbaa !3
  %v2688 = getelementptr i8, ptr %env, i64 24
  %v2689 = load ptr, ptr %v2688, align 8, !tbaa !3
  %v2690 = getelementptr i8, ptr %env, i64 32
  %v2691 = load ptr, ptr %v2690, align 8, !tbaa !3
  %v2692 = getelementptr i8, ptr %env, i64 40
  %v2693 = load ptr, ptr %v2692, align 8, !tbaa !3
  %v2694 = call ptr @mlf_env_new(i64 5)
  %v2695 = getelementptr i8, ptr %v2694, i64 8
  store ptr %v2685, ptr %v2695, align 8, !tbaa !3
  %v2696 = getelementptr i8, ptr %v2694, i64 16
  store ptr %v2687, ptr %v2696, align 8, !tbaa !3
  %v2697 = getelementptr i8, ptr %v2694, i64 24
  store ptr %v2693, ptr %v2697, align 8, !tbaa !3
  %v2698 = getelementptr i8, ptr %v2694, i64 32
  store ptr %v2689, ptr %v2698, align 8, !tbaa !3
  %v2699 = getelementptr i8, ptr %v2694, i64 40
  store ptr %v2691, ptr %v2699, align 8, !tbaa !3
  %v2700 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.428, ptr %v2694)
  ret ptr %v2700
}

define private ptr @mlf.code.2638(ptr %env, ptr %arg) {
entry:
  %v2639 = getelementptr i8, ptr %env, i64 8
  %v2640 = load ptr, ptr %v2639, align 8, !tbaa !3
  %v2641 = getelementptr i8, ptr %env, i64 16
  %v2642 = load ptr, ptr %v2641, align 8, !tbaa !3
  %v2643 = getelementptr i8, ptr %env, i64 24
  %v2644 = load ptr, ptr %v2643, align 8, !tbaa !3
  %v2645 = getelementptr i8, ptr %env, i64 32
  %v2646 = load ptr, ptr %v2645, align 8, !tbaa !3
  %v2647 = getelementptr i8, ptr %env, i64 40
  %v2648 = load ptr, ptr %v2647, align 8, !tbaa !3
  %v2649 = getelementptr i8, ptr %env, i64 48
  %v2650 = load ptr, ptr %v2649, align 8, !tbaa !3
  %v2651 = getelementptr i8, ptr %env, i64 56
  %v2652 = load ptr, ptr %v2651, align 8, !tbaa !3
  %v2653 = getelementptr i8, ptr %env, i64 64
  %v2654 = load ptr, ptr %v2653, align 8, !tbaa !3
  %v2676 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2655, i64 4)
  %v2677 = getelementptr i8, ptr %v2676, i64 16
  %v2678 = load ptr, ptr %v2677, align 8, !tbaa !3
  %v2679 = getelementptr i8, ptr %v2678, i64 8
  store ptr %v2644, ptr %v2679, align 8, !tbaa !3
  %v2680 = getelementptr i8, ptr %v2678, i64 16
  store ptr %v2646, ptr %v2680, align 8, !tbaa !3
  %v2681 = getelementptr i8, ptr %v2678, i64 24
  store ptr %v2648, ptr %v2681, align 8, !tbaa !3
  %v2682 = getelementptr i8, ptr %v2678, i64 32
  store ptr %v2654, ptr %v2682, align 8, !tbaa !3
  %v2701 = call ptr @mlf_env_new(i64 5)
  %v2702 = getelementptr i8, ptr %v2701, i64 8
  store ptr %v2640, ptr %v2702, align 8, !tbaa !3
  %v2703 = getelementptr i8, ptr %v2701, i64 16
  store ptr %v2642, ptr %v2703, align 8, !tbaa !3
  %v2704 = getelementptr i8, ptr %v2701, i64 24
  store ptr %v2650, ptr %v2704, align 8, !tbaa !3
  %v2705 = getelementptr i8, ptr %v2701, i64 32
  store ptr %v2652, ptr %v2705, align 8, !tbaa !3
  %v2706 = getelementptr i8, ptr %v2701, i64 40
  store ptr %v2654, ptr %v2706, align 8, !tbaa !3
  %v2707 = call ptr @mlf_closure(ptr @mlf.code.2683, ptr %v2701)
  %v2708 = call ptr @mlf_prim2(i64 1, ptr %v2676, ptr %v2707)
  ret ptr %v2708
}

define private ptr @mlf.code.2458(ptr %env, ptr %arg) {
entry:
  %v2459 = getelementptr i8, ptr %env, i64 8
  %v2460 = load ptr, ptr %v2459, align 8, !tbaa !3
  %v2461 = getelementptr i8, ptr %env, i64 16
  %v2462 = load ptr, ptr %v2461, align 8, !tbaa !3
  %v2463 = getelementptr i8, ptr %env, i64 24
  %v2464 = load ptr, ptr %v2463, align 8, !tbaa !3
  %v2465 = getelementptr i8, ptr %env, i64 32
  %v2466 = load ptr, ptr %v2465, align 8, !tbaa !3
  %v2467 = getelementptr i8, ptr %env, i64 40
  %v2468 = load ptr, ptr %v2467, align 8, !tbaa !3
  %v2469 = getelementptr i8, ptr %env, i64 48
  %v2470 = load ptr, ptr %v2469, align 8, !tbaa !3
  %v2471 = getelementptr i8, ptr %env, i64 56
  %v2472 = load ptr, ptr %v2471, align 8, !tbaa !3
  %v2473 = getelementptr i8, ptr %env, i64 64
  %v2474 = load ptr, ptr %v2473, align 8, !tbaa !3
  %v2632 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2475, i64 3)
  %v2633 = getelementptr i8, ptr %v2632, i64 16
  %v2634 = load ptr, ptr %v2633, align 8, !tbaa !3
  %v2635 = getelementptr i8, ptr %v2634, i64 8
  store ptr %v2464, ptr %v2635, align 8, !tbaa !3
  %v2636 = getelementptr i8, ptr %v2634, i64 16
  store ptr %v2466, ptr %v2636, align 8, !tbaa !3
  %v2637 = getelementptr i8, ptr %v2634, i64 24
  store ptr %arg, ptr %v2637, align 8, !tbaa !3
  %v2709 = call ptr @mlf_env_new(i64 8)
  %v2710 = getelementptr i8, ptr %v2709, i64 8
  store ptr %v2460, ptr %v2710, align 8, !tbaa !3
  %v2711 = getelementptr i8, ptr %v2709, i64 16
  store ptr %v2462, ptr %v2711, align 8, !tbaa !3
  %v2712 = getelementptr i8, ptr %v2709, i64 24
  store ptr %v2466, ptr %v2712, align 8, !tbaa !3
  %v2713 = getelementptr i8, ptr %v2709, i64 32
  store ptr %v2468, ptr %v2713, align 8, !tbaa !3
  %v2714 = getelementptr i8, ptr %v2709, i64 40
  store ptr %v2470, ptr %v2714, align 8, !tbaa !3
  %v2715 = getelementptr i8, ptr %v2709, i64 48
  store ptr %v2472, ptr %v2715, align 8, !tbaa !3
  %v2716 = getelementptr i8, ptr %v2709, i64 56
  store ptr %v2474, ptr %v2716, align 8, !tbaa !3
  %v2717 = getelementptr i8, ptr %v2709, i64 64
  store ptr %arg, ptr %v2717, align 8, !tbaa !3
  %v2718 = call ptr @mlf_closure(ptr @mlf.code.2638, ptr %v2709)
  %v2719 = call ptr @mlf_prim2(i64 1, ptr %v2632, ptr %v2718)
  ret ptr %v2719
}

define private ptr @mlf.code.2434(ptr %env, ptr %arg) {
entry:
  %v2435 = getelementptr i8, ptr %env, i64 8
  %v2436 = load ptr, ptr %v2435, align 8, !tbaa !3
  %v2437 = getelementptr i8, ptr %env, i64 16
  %v2438 = load ptr, ptr %v2437, align 8, !tbaa !3
  %v2439 = getelementptr i8, ptr %env, i64 24
  %v2440 = load ptr, ptr %v2439, align 8, !tbaa !3
  %v2441 = getelementptr i8, ptr %env, i64 32
  %v2442 = load ptr, ptr %v2441, align 8, !tbaa !3
  %v2443 = getelementptr i8, ptr %env, i64 40
  %v2444 = load ptr, ptr %v2443, align 8, !tbaa !3
  %v2445 = getelementptr i8, ptr %env, i64 48
  %v2446 = load ptr, ptr %v2445, align 8, !tbaa !3
  %v2447 = getelementptr i8, ptr %env, i64 56
  %v2448 = load ptr, ptr %v2447, align 8, !tbaa !3
  %v2454 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2449, i64 1)
  %v2455 = getelementptr i8, ptr %v2454, i64 16
  %v2456 = load ptr, ptr %v2455, align 8, !tbaa !3
  %v2457 = getelementptr i8, ptr %v2456, i64 8
  store ptr %arg, ptr %v2457, align 8, !tbaa !3
  %v2720 = call ptr @mlf_env_new(i64 8)
  %v2721 = getelementptr i8, ptr %v2720, i64 8
  store ptr %v2436, ptr %v2721, align 8, !tbaa !3
  %v2722 = getelementptr i8, ptr %v2720, i64 16
  store ptr %v2438, ptr %v2722, align 8, !tbaa !3
  %v2723 = getelementptr i8, ptr %v2720, i64 24
  store ptr %v2440, ptr %v2723, align 8, !tbaa !3
  %v2724 = getelementptr i8, ptr %v2720, i64 32
  store ptr %v2442, ptr %v2724, align 8, !tbaa !3
  %v2725 = getelementptr i8, ptr %v2720, i64 40
  store ptr %v2444, ptr %v2725, align 8, !tbaa !3
  %v2726 = getelementptr i8, ptr %v2720, i64 48
  store ptr %v2446, ptr %v2726, align 8, !tbaa !3
  %v2727 = getelementptr i8, ptr %v2720, i64 56
  store ptr %v2448, ptr %v2727, align 8, !tbaa !3
  %v2728 = getelementptr i8, ptr %v2720, i64 64
  store ptr %arg, ptr %v2728, align 8, !tbaa !3
  %v2729 = call ptr @mlf_closure(ptr @mlf.code.2458, ptr %v2720)
  %v2730 = call ptr @mlf_prim2(i64 1, ptr %v2454, ptr %v2729)
  ret ptr %v2730
}

define private ptr @mlf.code.2741(ptr %env, ptr %arg) {
entry:
  %v2742 = getelementptr i8, ptr %env, i64 8
  %v2743 = load ptr, ptr %v2742, align 8, !tbaa !3
  %v2744 = getelementptr i8, ptr %env, i64 16
  %v2745 = load ptr, ptr %v2744, align 8, !tbaa !3
  %v2746 = getelementptr i8, ptr %env, i64 24
  %v2747 = load ptr, ptr %v2746, align 8, !tbaa !3
  %v2748 = getelementptr i8, ptr %env, i64 32
  %v2749 = load ptr, ptr %v2748, align 8, !tbaa !3
  %v2750 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v2750, align 8, !tbaa !3
  %v2751 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v2751, align 8, !tbaa !3
  %v2752 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v2752, align 8, !tbaa !3
  %v2753 = getelementptr i8, ptr %env, i64 32
  store ptr null, ptr %v2753, align 8, !tbaa !3
  %v2754 = call ptr @mlf.force(ptr %v2749)
  %v2755 = call ptr @mlf_env_new(i64 5)
  %v2756 = getelementptr i8, ptr %v2755, i64 8
  store ptr %v2747, ptr %v2756, align 8, !tbaa !3
  %v2757 = getelementptr i8, ptr %v2755, i64 16
  store ptr %v2743, ptr %v2757, align 8, !tbaa !3
  %v2758 = getelementptr i8, ptr %v2755, i64 24
  store ptr %v2754, ptr %v2758, align 8, !tbaa !3
  %v2759 = getelementptr i8, ptr %v2755, i64 32
  store ptr %v2745, ptr %v2759, align 8, !tbaa !3
  %v2760 = getelementptr i8, ptr %v2755, i64 40
  store ptr inttoptr (i64 1 to ptr), ptr %v2760, align 8, !tbaa !3
  %v2761 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.2485, ptr %v2755)
  ret ptr %v2761
}

define private ptr @mlf.code.2769(ptr %env, ptr %arg) {
entry:
  %v2770 = getelementptr i8, ptr %env, i64 8
  %v2771 = load ptr, ptr %v2770, align 8, !tbaa !3
  %v2772 = getelementptr i8, ptr %env, i64 16
  %v2773 = load ptr, ptr %v2772, align 8, !tbaa !3
  %v2774 = getelementptr i8, ptr %env, i64 24
  %v2775 = load ptr, ptr %v2774, align 8, !tbaa !3
  %v2776 = getelementptr i8, ptr %env, i64 32
  %v2777 = load ptr, ptr %v2776, align 8, !tbaa !3
  %v2778 = getelementptr i8, ptr %env, i64 40
  %v2779 = load ptr, ptr %v2778, align 8, !tbaa !3
  %v2780 = call ptr @mlf_env_new(i64 5)
  %v2781 = getelementptr i8, ptr %v2780, i64 8
  store ptr %v2771, ptr %v2781, align 8, !tbaa !3
  %v2782 = getelementptr i8, ptr %v2780, i64 16
  store ptr %v2773, ptr %v2782, align 8, !tbaa !3
  %v2783 = getelementptr i8, ptr %v2780, i64 24
  store ptr %v2775, ptr %v2783, align 8, !tbaa !3
  %v2784 = getelementptr i8, ptr %v2780, i64 32
  store ptr %v2779, ptr %v2784, align 8, !tbaa !3
  %v2785 = getelementptr i8, ptr %v2780, i64 40
  store ptr %v2777, ptr %v2785, align 8, !tbaa !3
  %v2786 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.428, ptr %v2780)
  ret ptr %v2786
}

define private ptr @mlf.code.2362(ptr %env, ptr %arg) {
entry:
  %v2363 = getelementptr i8, ptr %env, i64 8
  %v2364 = load ptr, ptr %v2363, align 8, !tbaa !3
  %v2365 = getelementptr i8, ptr %env, i64 16
  %v2366 = load ptr, ptr %v2365, align 8, !tbaa !3
  %v2367 = getelementptr i8, ptr %env, i64 24
  %v2368 = load ptr, ptr %v2367, align 8, !tbaa !3
  %v2369 = getelementptr i8, ptr %env, i64 32
  %v2370 = load ptr, ptr %v2369, align 8, !tbaa !3
  %v2371 = getelementptr i8, ptr %env, i64 40
  %v2372 = load ptr, ptr %v2371, align 8, !tbaa !3
  %v2373 = getelementptr i8, ptr %env, i64 48
  %v2374 = load ptr, ptr %v2373, align 8, !tbaa !3
  %v2375 = call ptr @mlf.force(ptr %v2370)
  %v2376 = call ptr @mlf.force(ptr %arg)
  %v2377 = call ptr @mlf_prim2(i64 8, ptr %v2375, ptr %v2376)
  %v2378 = call ptr @mlf.force(ptr %v2372)
  %v2379 = call ptr @mlf_prim2(i64 11, ptr %v2378, ptr %v2377)
  %v2380 = icmp eq ptr %v2379, inttoptr (i64 6 to ptr)
  br i1 %v2380, label %yes.2381, label %no.2382
yes.2381:
  %v2429 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2384, i64 2)
  %v2430 = getelementptr i8, ptr %v2429, i64 16
  %v2431 = load ptr, ptr %v2430, align 8, !tbaa !3
  %v2432 = getelementptr i8, ptr %v2431, i64 8
  store ptr %v2378, ptr %v2432, align 8, !tbaa !3
  %v2433 = getelementptr i8, ptr %v2431, i64 16
  store ptr %v2377, ptr %v2433, align 8, !tbaa !3
  %v2731 = call ptr @mlf_env_new(i64 7)
  %v2732 = getelementptr i8, ptr %v2731, i64 8
  store ptr %v2364, ptr %v2732, align 8, !tbaa !3
  %v2733 = getelementptr i8, ptr %v2731, i64 16
  store ptr %v2366, ptr %v2733, align 8, !tbaa !3
  %v2734 = getelementptr i8, ptr %v2731, i64 24
  store ptr %v2368, ptr %v2734, align 8, !tbaa !3
  %v2735 = getelementptr i8, ptr %v2731, i64 32
  store ptr %v2375, ptr %v2735, align 8, !tbaa !3
  %v2736 = getelementptr i8, ptr %v2731, i64 40
  store ptr %v2374, ptr %v2736, align 8, !tbaa !3
  %v2737 = getelementptr i8, ptr %v2731, i64 48
  store ptr %v2376, ptr %v2737, align 8, !tbaa !3
  %v2738 = getelementptr i8, ptr %v2731, i64 56
  store ptr %v2377, ptr %v2738, align 8, !tbaa !3
  %v2739 = call ptr @mlf_closure(ptr @mlf.code.2434, ptr %v2731)
  %v2740 = call ptr @mlf_prim2(i64 1, ptr %v2429, ptr %v2739)
  br label %join.2383
no.2382:
  %v2762 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2741, i64 4)
  %v2763 = getelementptr i8, ptr %v2762, i64 16
  %v2764 = load ptr, ptr %v2763, align 8, !tbaa !3
  %v2765 = getelementptr i8, ptr %v2764, i64 8
  store ptr %v2368, ptr %v2765, align 8, !tbaa !3
  %v2766 = getelementptr i8, ptr %v2764, i64 16
  store ptr %v2375, ptr %v2766, align 8, !tbaa !3
  %v2767 = getelementptr i8, ptr %v2764, i64 24
  store ptr %v2374, ptr %v2767, align 8, !tbaa !3
  %v2768 = getelementptr i8, ptr %v2764, i64 32
  store ptr %v2376, ptr %v2768, align 8, !tbaa !3
  %v2787 = call ptr @mlf_env_new(i64 5)
  %v2788 = getelementptr i8, ptr %v2787, i64 8
  store ptr %v2364, ptr %v2788, align 8, !tbaa !3
  %v2789 = getelementptr i8, ptr %v2787, i64 16
  store ptr %v2366, ptr %v2789, align 8, !tbaa !3
  %v2790 = getelementptr i8, ptr %v2787, i64 24
  store ptr %v2368, ptr %v2790, align 8, !tbaa !3
  %v2791 = getelementptr i8, ptr %v2787, i64 32
  store ptr %v2378, ptr %v2791, align 8, !tbaa !3
  %v2792 = getelementptr i8, ptr %v2787, i64 40
  store ptr %v2377, ptr %v2792, align 8, !tbaa !3
  %v2793 = call ptr @mlf_closure(ptr @mlf.code.2769, ptr %v2787)
  %v2794 = call ptr @mlf_prim2(i64 1, ptr %v2762, ptr %v2793)
  br label %join.2383
join.2383:
  %v2795 = phi ptr [ %v2740, %yes.2381 ], [ %v2794, %no.2382 ]
  ret ptr %v2795
}

define private ptr @mlf.code.2154(ptr %env, ptr %arg) {
entry:
  %v2155 = getelementptr i8, ptr %env, i64 8
  %v2156 = load ptr, ptr %v2155, align 8, !tbaa !3
  %v2157 = getelementptr i8, ptr %env, i64 16
  %v2158 = load ptr, ptr %v2157, align 8, !tbaa !3
  %v2159 = getelementptr i8, ptr %env, i64 24
  %v2160 = load ptr, ptr %v2159, align 8, !tbaa !3
  %v2161 = getelementptr i8, ptr %env, i64 32
  %v2162 = load ptr, ptr %v2161, align 8, !tbaa !3
  %v2163 = getelementptr i8, ptr %env, i64 40
  %v2164 = load ptr, ptr %v2163, align 8, !tbaa !3
  %v2165 = getelementptr i8, ptr %env, i64 48
  %v2166 = load ptr, ptr %v2165, align 8, !tbaa !3
  %v2167 = getelementptr i8, ptr %env, i64 56
  %v2168 = load ptr, ptr %v2167, align 8, !tbaa !3
  %v2169 = call ptr @mlf.force(ptr %arg)
  %v2170 = call ptr @mlf_prim2(i64 10, ptr %v2169, ptr inttoptr (i64 125 to ptr))
  %v2171 = icmp eq ptr %v2170, inttoptr (i64 6 to ptr)
  br i1 %v2171, label %yes.2172, label %no.2173
yes.2172:
  %v2195 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2175, i64 4)
  %v2196 = getelementptr i8, ptr %v2195, i64 16
  %v2197 = load ptr, ptr %v2196, align 8, !tbaa !3
  %v2198 = getelementptr i8, ptr %v2197, i64 8
  store ptr %v2156, ptr %v2198, align 8, !tbaa !3
  %v2199 = getelementptr i8, ptr %v2197, i64 16
  store ptr %v2158, ptr %v2199, align 8, !tbaa !3
  %v2200 = getelementptr i8, ptr %v2197, i64 24
  store ptr %v2160, ptr %v2200, align 8, !tbaa !3
  %v2201 = getelementptr i8, ptr %v2197, i64 32
  store ptr %v2162, ptr %v2201, align 8, !tbaa !3
  %v2251 = call ptr @mlf_env_new(i64 6)
  %v2252 = getelementptr i8, ptr %v2251, i64 8
  store ptr %v2156, ptr %v2252, align 8, !tbaa !3
  %v2253 = getelementptr i8, ptr %v2251, i64 16
  store ptr %v2158, ptr %v2253, align 8, !tbaa !3
  %v2254 = getelementptr i8, ptr %v2251, i64 24
  store ptr %v2160, ptr %v2254, align 8, !tbaa !3
  %v2255 = getelementptr i8, ptr %v2251, i64 32
  store ptr %v2164, ptr %v2255, align 8, !tbaa !3
  %v2256 = getelementptr i8, ptr %v2251, i64 40
  store ptr %v2166, ptr %v2256, align 8, !tbaa !3
  %v2257 = getelementptr i8, ptr %v2251, i64 48
  store ptr %v2168, ptr %v2257, align 8, !tbaa !3
  %v2258 = call ptr @mlf_closure(ptr @mlf.code.2202, ptr %v2251)
  %v2259 = call ptr @mlf_prim2(i64 1, ptr %v2195, ptr %v2258)
  br label %join.2174
no.2173:
  %v2357 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2260, i64 2)
  %v2358 = getelementptr i8, ptr %v2357, i64 16
  %v2359 = load ptr, ptr %v2358, align 8, !tbaa !3
  %v2360 = getelementptr i8, ptr %v2359, i64 8
  store ptr %v2166, ptr %v2360, align 8, !tbaa !3
  %v2361 = getelementptr i8, ptr %v2359, i64 16
  store ptr %v2168, ptr %v2361, align 8, !tbaa !3
  %v2796 = call ptr @mlf_env_new(i64 6)
  %v2797 = getelementptr i8, ptr %v2796, i64 8
  store ptr %v2156, ptr %v2797, align 8, !tbaa !3
  %v2798 = getelementptr i8, ptr %v2796, i64 16
  store ptr %v2158, ptr %v2798, align 8, !tbaa !3
  %v2799 = getelementptr i8, ptr %v2796, i64 24
  store ptr %v2160, ptr %v2799, align 8, !tbaa !3
  %v2800 = getelementptr i8, ptr %v2796, i64 32
  store ptr %v2162, ptr %v2800, align 8, !tbaa !3
  %v2801 = getelementptr i8, ptr %v2796, i64 40
  store ptr %v2164, ptr %v2801, align 8, !tbaa !3
  %v2802 = getelementptr i8, ptr %v2796, i64 48
  store ptr %v2166, ptr %v2802, align 8, !tbaa !3
  %v2803 = call ptr @mlf_closure(ptr @mlf.code.2362, ptr %v2796)
  %v2804 = call ptr @mlf_prim2(i64 1, ptr %v2357, ptr %v2803)
  br label %join.2174
join.2174:
  %v2805 = phi ptr [ %v2259, %yes.2172 ], [ %v2804, %no.2173 ]
  ret ptr %v2805
}

define private ptr @mlf.code.1510(ptr %env, ptr %arg) {
entry:
  %v1511 = getelementptr i8, ptr %env, i64 8
  %v1512 = load ptr, ptr %v1511, align 8, !tbaa !3
  %v1513 = getelementptr i8, ptr %env, i64 16
  %v1514 = load ptr, ptr %v1513, align 8, !tbaa !3
  %v1515 = getelementptr i8, ptr %env, i64 24
  %v1516 = load ptr, ptr %v1515, align 8, !tbaa !3
  %v1517 = getelementptr i8, ptr %env, i64 32
  %v1518 = load ptr, ptr %v1517, align 8, !tbaa !3
  %v1519 = getelementptr i8, ptr %env, i64 40
  %v1520 = load ptr, ptr %v1519, align 8, !tbaa !3
  %v1521 = getelementptr i8, ptr %env, i64 48
  %v1522 = load ptr, ptr %v1521, align 8, !tbaa !3
  %v1523 = call ptr @mlf.force(ptr %arg)
  %v1524 = call ptr @mlf_prim2(i64 10, ptr %v1523, ptr inttoptr (i64 1 to ptr))
  %v1525 = icmp eq ptr %v1524, inttoptr (i64 6 to ptr)
  br i1 %v1525, label %yes.1526, label %no.1527
yes.1526:
  %v2138 = call ptr @mlf.force(ptr %v1518)
  %v2139 = call ptr @mlf_env_new(i64 4)
  %v2140 = getelementptr i8, ptr %v2139, i64 8
  store ptr %v1512, ptr %v2140, align 8, !tbaa !3
  %v2141 = getelementptr i8, ptr %v2139, i64 16
  store ptr %v1514, ptr %v2141, align 8, !tbaa !3
  %v2142 = getelementptr i8, ptr %v2139, i64 24
  store ptr %v1516, ptr %v2142, align 8, !tbaa !3
  %v2143 = getelementptr i8, ptr %v2139, i64 32
  store ptr %v2138, ptr %v2143, align 8, !tbaa !3
  %v2144 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.1529, ptr %v2139)
  br label %join.1528
no.1527:
  %v2150 = call ptr @mlf.allocate.thunk(ptr @mlf.code.2145, i64 1)
  %v2151 = getelementptr i8, ptr %v2150, i64 16
  %v2152 = load ptr, ptr %v2151, align 8, !tbaa !3
  %v2153 = getelementptr i8, ptr %v2152, i64 8
  store ptr %v1522, ptr %v2153, align 8, !tbaa !3
  %v2806 = call ptr @mlf_env_new(i64 7)
  %v2807 = getelementptr i8, ptr %v2806, i64 8
  store ptr %v1512, ptr %v2807, align 8, !tbaa !3
  %v2808 = getelementptr i8, ptr %v2806, i64 16
  store ptr %v1514, ptr %v2808, align 8, !tbaa !3
  %v2809 = getelementptr i8, ptr %v2806, i64 24
  store ptr %v1516, ptr %v2809, align 8, !tbaa !3
  %v2810 = getelementptr i8, ptr %v2806, i64 32
  store ptr %v1518, ptr %v2810, align 8, !tbaa !3
  %v2811 = getelementptr i8, ptr %v2806, i64 40
  store ptr %v1520, ptr %v2811, align 8, !tbaa !3
  %v2812 = getelementptr i8, ptr %v2806, i64 48
  store ptr %v1522, ptr %v2812, align 8, !tbaa !3
  %v2813 = getelementptr i8, ptr %v2806, i64 56
  store ptr %v1523, ptr %v2813, align 8, !tbaa !3
  %v2814 = call ptr @mlf_closure(ptr @mlf.code.2154, ptr %v2806)
  %v2815 = call ptr @mlf_prim2(i64 1, ptr %v2150, ptr %v2814)
  br label %join.1528
join.1528:
  %v2816 = phi ptr [ %v2144, %yes.1526 ], [ %v2815, %no.1527 ]
  ret ptr %v2816
}

define private ptr @mlf.code.1490(ptr %env, ptr %arg) {
entry:
  %v1491 = getelementptr i8, ptr %env, i64 8
  %v1492 = load ptr, ptr %v1491, align 8, !tbaa !3
  %v1493 = getelementptr i8, ptr %env, i64 16
  %v1494 = load ptr, ptr %v1493, align 8, !tbaa !3
  %v1495 = getelementptr i8, ptr %env, i64 24
  %v1496 = load ptr, ptr %v1495, align 8, !tbaa !3
  %v1497 = getelementptr i8, ptr %env, i64 32
  %v1498 = load ptr, ptr %v1497, align 8, !tbaa !3
  %v1499 = getelementptr i8, ptr %env, i64 40
  %v1500 = load ptr, ptr %v1499, align 8, !tbaa !3
  %v1506 = call ptr @mlf.allocate.thunk(ptr @mlf.code.1501, i64 1)
  %v1507 = getelementptr i8, ptr %v1506, i64 16
  %v1508 = load ptr, ptr %v1507, align 8, !tbaa !3
  %v1509 = getelementptr i8, ptr %v1508, i64 8
  store ptr %arg, ptr %v1509, align 8, !tbaa !3
  %v2817 = call ptr @mlf_env_new(i64 6)
  %v2818 = getelementptr i8, ptr %v2817, i64 8
  store ptr %v1492, ptr %v2818, align 8, !tbaa !3
  %v2819 = getelementptr i8, ptr %v2817, i64 16
  store ptr %v1494, ptr %v2819, align 8, !tbaa !3
  %v2820 = getelementptr i8, ptr %v2817, i64 24
  store ptr %v1496, ptr %v2820, align 8, !tbaa !3
  %v2821 = getelementptr i8, ptr %v2817, i64 32
  store ptr %v1498, ptr %v2821, align 8, !tbaa !3
  %v2822 = getelementptr i8, ptr %v2817, i64 40
  store ptr %v1500, ptr %v2822, align 8, !tbaa !3
  %v2823 = getelementptr i8, ptr %v2817, i64 48
  store ptr %arg, ptr %v2823, align 8, !tbaa !3
  %v2824 = call ptr @mlf_closure(ptr @mlf.code.1510, ptr %v2817)
  %v2825 = call ptr @mlf_prim2(i64 1, ptr %v1506, ptr %v2824)
  ret ptr %v2825
}

define private ptr @mlf.worker.53(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) {
entry:
  %v1489 = call ptr @mlf_primitive(i64 41)
  %v2826 = call ptr @mlf_env_new(i64 5)
  %v2827 = getelementptr i8, ptr %v2826, i64 8
  store ptr %a0, ptr %v2827, align 8, !tbaa !3
  %v2828 = getelementptr i8, ptr %v2826, i64 16
  store ptr %a1, ptr %v2828, align 8, !tbaa !3
  %v2829 = getelementptr i8, ptr %v2826, i64 24
  store ptr %a2, ptr %v2829, align 8, !tbaa !3
  %v2830 = getelementptr i8, ptr %v2826, i64 32
  store ptr %a3, ptr %v2830, align 8, !tbaa !3
  %v2831 = getelementptr i8, ptr %v2826, i64 40
  store ptr %a4, ptr %v2831, align 8, !tbaa !3
  %v2832 = call ptr @mlf_closure(ptr @mlf.code.1490, ptr %v2826)
  %v2833 = call ptr @mlf_prim2(i64 1, ptr %v1489, ptr %v2832)
  ret ptr %v2833
}

define private ptr @mlf.numeric.entry.428(ptr %env, ptr %arg) {
entry:
  %v429 = getelementptr i8, ptr %env, i64 8
  %v430 = load ptr, ptr %v429, align 8, !tbaa !3
  %v431 = getelementptr i8, ptr %env, i64 16
  %v432 = load ptr, ptr %v431, align 8, !tbaa !3
  %v433 = getelementptr i8, ptr %env, i64 24
  %v434 = load ptr, ptr %v433, align 8, !tbaa !3
  %v435 = getelementptr i8, ptr %env, i64 32
  %v436 = load ptr, ptr %v435, align 8, !tbaa !3
  %v437 = getelementptr i8, ptr %env, i64 40
  %v438 = load ptr, ptr %v437, align 8, !tbaa !3
  %v439 = call ptr @mlf_peek(ptr %v430)
  %v440 = call ptr @mlf_peek(ptr %v432)
  %v441 = call ptr @mlf_peek(ptr %v434)
  %v442 = call ptr @mlf_peek(ptr %v436)
  %v443 = call ptr @mlf_peek(ptr %v438)
  %v444 = icmp ne ptr %v439, null
  %v445 = icmp ne ptr %v440, null
  %v446 = icmp ne ptr %v441, null
  %v447 = icmp ne ptr %v442, null
  %v448 = icmp ne ptr %v443, null
  %v449 = and i1 true, %v444
  %v450 = and i1 %v449, %v445
  %v451 = and i1 %v450, %v446
  %v452 = and i1 %v451, %v447
  %v453 = and i1 %v452, %v448
  br i1 %v453, label %yes.454, label %no.455
yes.454:
  %v1487 = call ptr @mlf.numeric.53(ptr %v439, ptr %v440, ptr %v441, ptr %v442, ptr %v443)
  %v1488 = call ptr @mlf_prim1(i64 0, ptr %v1487)
  br label %join.456
no.455:
  %v2834 = call ptr @mlf.worker.53(ptr %v430, ptr %v432, ptr %v434, ptr %v436, ptr %v438)
  br label %join.456
join.456:
  %v2835 = phi ptr [ %v1488, %yes.454 ], [ %v2834, %no.455 ]
  ret ptr %v2835
}

define private ptr @mlf.code.423(ptr %env, ptr %arg) {
entry:
  %v424 = getelementptr i8, ptr %env, i64 8
  %v425 = load ptr, ptr %v424, align 8, !tbaa !3
  %v426 = getelementptr i8, ptr %env, i64 16
  %v427 = load ptr, ptr %v426, align 8, !tbaa !3
  %v2836 = call ptr @mlf_env_new(i64 5)
  %v2837 = getelementptr i8, ptr %v2836, i64 8
  store ptr %v425, ptr %v2837, align 8, !tbaa !3
  %v2838 = getelementptr i8, ptr %v2836, i64 16
  store ptr %arg, ptr %v2838, align 8, !tbaa !3
  %v2839 = getelementptr i8, ptr %v2836, i64 24
  store ptr %v427, ptr %v2839, align 8, !tbaa !3
  %v2840 = getelementptr i8, ptr %v2836, i64 32
  store ptr inttoptr (i64 1 to ptr), ptr %v2840, align 8, !tbaa !3
  %v2841 = getelementptr i8, ptr %v2836, i64 40
  store ptr inttoptr (i64 2049 to ptr), ptr %v2841, align 8, !tbaa !3
  %v2842 = call ptr @mlf_native_io(ptr @mlf.numeric.entry.428, ptr %v2836)
  ret ptr %v2842
}

define private ptr @mlf.code.417(ptr %env, ptr %arg) {
entry:
  %v418 = getelementptr i8, ptr %env, i64 8
  %v419 = load ptr, ptr %v418, align 8, !tbaa !3
  %v422 = call ptr @mlf_thunk(ptr @mlf.code.420, ptr null)
  %v2843 = call ptr @mlf_env_new(i64 2)
  %v2844 = getelementptr i8, ptr %v2843, i64 8
  store ptr %v419, ptr %v2844, align 8, !tbaa !3
  %v2845 = getelementptr i8, ptr %v2843, i64 16
  store ptr %arg, ptr %v2845, align 8, !tbaa !3
  %v2846 = call ptr @mlf_closure(ptr @mlf.code.423, ptr %v2843)
  %v2847 = call ptr @mlf_prim2(i64 1, ptr %v422, ptr %v2846)
  ret ptr %v2847
}

define private ptr @mlf.code.411(ptr %env, ptr %arg) {
entry:
  %v412 = getelementptr i8, ptr %env, i64 8
  %v413 = load ptr, ptr %v412, align 8, !tbaa !3
  %v416 = call ptr @mlf_thunk(ptr @mlf.code.414, ptr null)
  %v2848 = call ptr @mlf_env_new(i64 1)
  %v2849 = getelementptr i8, ptr %v2848, i64 8
  store ptr %v413, ptr %v2849, align 8, !tbaa !3
  %v2850 = call ptr @mlf_closure(ptr @mlf.code.417, ptr %v2848)
  %v2851 = call ptr @mlf_prim2(i64 1, ptr %v416, ptr %v2850)
  ret ptr %v2851
}

define private ptr @mlf.code.16(ptr %env, ptr %arg) {
entry:
  %v17 = getelementptr i8, ptr %env, i64 8
  %v18 = load ptr, ptr %v17, align 8, !tbaa !3
  %v19 = getelementptr i8, ptr %env, i64 16
  %v20 = load ptr, ptr %v19, align 8, !tbaa !3
  %v405 = call ptr @mlf.allocate.thunk(ptr @mlf.code.21, i64 3)
  %v406 = getelementptr i8, ptr %v405, i64 16
  %v407 = load ptr, ptr %v406, align 8, !tbaa !3
  %v408 = getelementptr i8, ptr %v407, i64 8
  store ptr %v18, ptr %v408, align 8, !tbaa !3
  %v409 = getelementptr i8, ptr %v407, i64 16
  store ptr %v20, ptr %v409, align 8, !tbaa !3
  %v410 = getelementptr i8, ptr %v407, i64 24
  store ptr %arg, ptr %v410, align 8, !tbaa !3
  %v2852 = call ptr @mlf_env_new(i64 1)
  %v2853 = getelementptr i8, ptr %v2852, i64 8
  store ptr %v18, ptr %v2853, align 8, !tbaa !3
  %v2854 = call ptr @mlf_closure(ptr @mlf.code.411, ptr %v2852)
  %v2855 = call ptr @mlf_prim2(i64 1, ptr %v405, ptr %v2854)
  ret ptr %v2855
}

define private ptr @mlf.code.9(ptr %env, ptr %arg) {
entry:
  %v10 = getelementptr i8, ptr %env, i64 8
  %v11 = load ptr, ptr %v10, align 8, !tbaa !3
  %v15 = call ptr @mlf_thunk(ptr @mlf.code.12, ptr null)
  %v2856 = call ptr @mlf_env_new(i64 2)
  %v2857 = getelementptr i8, ptr %v2856, i64 8
  store ptr %v11, ptr %v2857, align 8, !tbaa !3
  %v2858 = getelementptr i8, ptr %v2856, i64 16
  store ptr %arg, ptr %v2858, align 8, !tbaa !3
  %v2859 = call ptr @mlf_closure(ptr @mlf.code.16, ptr %v2856)
  %v2860 = call ptr @mlf_prim2(i64 1, ptr %v15, ptr %v2859)
  ret ptr %v2860
}

define private ptr @mlf.code.4(ptr %env, ptr %arg) {
entry:
  %v8 = call ptr @mlf_thunk(ptr @mlf.code.5, ptr null)
  %v2861 = call ptr @mlf_env_new(i64 1)
  %v2862 = getelementptr i8, ptr %v2861, i64 8
  store ptr %arg, ptr %v2862, align 8, !tbaa !3
  %v2863 = call ptr @mlf_closure(ptr @mlf.code.9, ptr %v2861)
  %v2864 = call ptr @mlf_prim2(i64 1, ptr %v8, ptr %v2863)
  ret ptr %v2864
}

define private ptr @mlf.code.0(ptr %env, ptr %arg) {
entry:
  %v3 = call ptr @mlf_thunk(ptr @mlf.code.1, ptr null)
  %v2865 = call ptr @mlf_closure(ptr @mlf.code.4, ptr null)
  %v2866 = call ptr @mlf_prim2(i64 1, ptr %v3, ptr %v2865)
  ret ptr %v2866
}

declare void @mlf_require_compact_gc_abi()
define ptr @mlf_entry() {
  call void @mlf_require_compact_gc_abi()
  %root = call ptr @mlf.code.0(ptr null, ptr null)
  ret ptr %root
}
define i32 @main(i32 %argc, ptr %argv) {
  call void @mlf_set_args(i32 %argc, ptr %argv)
  %root = call ptr @mlf_entry()
  %status = call i32 @mlf_run(ptr %root, i64 1)
  ret i32 %status
}
