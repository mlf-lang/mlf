; Generated from independently checked xMLF.
source_filename = "emlf"

declare ptr @mlf_thunk_new(ptr, i64)
declare ptr @mlf_execute_st_lazy(ptr)
declare ptr @mlf_st_new_array(ptr, ptr)
declare ptr @mlf_st_read_array(ptr, ptr)
declare ptr @mlf_st_write_array(ptr, ptr, ptr)
declare ptr @mlf_st_length_array(ptr)
declare void @mlf_set_args(i32, ptr)
declare ptr @mlf_env_new(i64)
declare void @mlf_env_set(ptr, i64, ptr)
declare ptr @mlf_env_get(ptr, i64)
declare ptr @mlf_thunk(ptr, ptr)
declare ptr @mlf_closure(ptr, ptr)
declare ptr @mlf_application(ptr, ptr)
declare ptr @mlf_hole()
declare void @mlf_fill(ptr, ptr)
declare ptr @mlf_integer(ptr)
declare ptr @mlf_string(ptr, i64)
declare ptr @mlf_double(double)
declare double @llvm.sqrt.f64(double)
declare double @mlf_int_to_double(ptr)
declare ptr @mlf_read_int_table(ptr, ptr)
declare ptr @mlf_write_int_table(ptr, ptr, ptr)
declare ptr @mlf_add_int_table(ptr, ptr, ptr)
declare void @mlf_roots_enter(ptr, i64, ptr)
declare void @mlf_roots_leave(ptr)
declare void @mlf_gc_check(i64, ptr)
declare ptr @mlf_get_byte_line()
declare ptr @mlf_new_array(i64, ptr, ptr)
declare ptr @mlf_bytes_from_string(ptr)
declare ptr @mlf_put_bytes(ptr, ptr, ptr)
declare ptr @mlf_new_int_table()
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare i8 @mlf_byte(ptr)
declare ptr @mlf_peek(ptr)
declare ptr @mlf_native_io(ptr, ptr)
declare void @mlf_bounds_failure() noreturn
declare ptr @mlf_primitive(i64)
declare ptr @mlf_prim1(i64, ptr)
declare ptr @mlf_prim2(i64, ptr, ptr)
declare i64 @mlf_truth(ptr)
declare ptr @mlf_prim3(i64, ptr, ptr, ptr)
declare ptr @mlf_force(ptr)
declare ptr @mlf_add_int(ptr, ptr)
declare ptr @mlf_sub_int(ptr, ptr)
declare ptr @mlf_eq_int(ptr, ptr)
declare ptr @mlf_lt_int(ptr, ptr)
declare ptr @mlf_constructor(i64, i64)
declare ptr @mlf_constructor1(i64, ptr)
declare ptr @mlf_constructor2(i64, ptr, ptr)
declare ptr @mlf_constructor_fields(i64, ptr)
declare ptr @mlf_constructor_new(i64, i64)
declare ptr @mlf_field(ptr, i64)
declare void @mlf_match_failure() noreturn
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare i32 @mlf_run(ptr, i64)

@mlf_constructor_pending = external global [33 x ptr]
declare ptr @mlf_constructor_allocate(i64, i64)
define private ptr @mlf.allocate.constructor(i64 %identity, i64 %count, i64 %size) alwaysinline {
entry:
  %small = icmp ule i64 %size, 256
  br i1 %small, label %batch, label %slow
batch:
  %index = lshr i64 %size, 3
  %slot = getelementptr [33 x ptr], ptr @mlf_constructor_pending, i64 0, i64 %index
  %value = load ptr, ptr %slot, align 8
  %empty = icmp eq ptr %value, null
  br i1 %empty, label %slow, label %ready
ready:
  %next = load ptr, ptr %value, align 8
  store ptr %next, ptr %slot, align 8
  store i64 0, ptr %value, align 8
  ret ptr %value
slow:
  %allocated = call ptr @mlf_constructor_allocate(i64 %identity, i64 %count)
  ret ptr %allocated
}
define private ptr @mlf.construct.1(i64 %identity, ptr %a) alwaysinline {
entry:
  %value = call ptr @mlf.allocate.constructor(i64 %identity, i64 1, i64 24)
  store i32 12, ptr %value, align 4
  %id = getelementptr i8, ptr %value, i64 8
  store i64 %identity, ptr %id, align 8
  %first = getelementptr i8, ptr %value, i64 16
  store ptr %a, ptr %first, align 8
  ret ptr %value
}
define private ptr @mlf.construct.2(i64 %identity, ptr %a, ptr %b) alwaysinline {
entry:
  %value = call ptr @mlf.allocate.constructor(i64 %identity, i64 2, i64 32)
  store i32 13, ptr %value, align 4
  %id = getelementptr i8, ptr %value, i64 8
  store i64 %identity, ptr %id, align 8
  %first = getelementptr i8, ptr %value, i64 16
  store ptr %a, ptr %first, align 8
  %second = getelementptr i8, ptr %value, i64 24
  store ptr %b, ptr %second, align 8
  ret ptr %value
}
define private ptr @mlf.construct.wide(i64 %identity, i64 %count) alwaysinline {
entry:
  %fields = mul i64 %count, 8
  %size = add i64 %fields, 24
  %value = call ptr @mlf.allocate.constructor(i64 %identity, i64 %count, i64 %size)
  store i32 28, ptr %value, align 4
  %id = getelementptr i8, ptr %value, i64 8
  store i64 %identity, ptr %id, align 8
  %arity = getelementptr i8, ptr %value, i64 16
  store i64 %count, ptr %arity, align 8
  ret ptr %value
}
@mlf_compact_pending = external global [17 x ptr]
define private ptr @mlf.allocate.thunk(ptr %code, i64 %count) alwaysinline {
entry:
  %words = add i64 %count, 4
  %index = lshr i64 %words, 1
  %slot = getelementptr [17 x ptr], ptr @mlf_compact_pending, i64 0, i64 %index
  %value = load ptr, ptr %slot, align 8
  %empty = icmp eq ptr %value, null
  br i1 %empty, label %slow, label %ready
ready:
  %next = load ptr, ptr %value, align 8
  store ptr %next, ptr %slot, align 8
  store i64 3, ptr %value, align 8
  %function = getelementptr i8, ptr %value, i64 8
  store ptr %code, ptr %function, align 8
  %environment = getelementptr i8, ptr %value, i64 24
  %capture = getelementptr i8, ptr %value, i64 16
  store ptr %environment, ptr %capture, align 8
  store i64 %count, ptr %environment, align 8
  ret ptr %value
slow:
  %allocated = call ptr @mlf_thunk_new(ptr %code, i64 %count)
  ret ptr %allocated
}
define private ptr @mlf.force(ptr %value) alwaysinline {
entry:
  %null = icmp eq ptr %value, null
  br i1 %null, label %slow, label %test
test:
  %bits = ptrtoint ptr %value to i64
  %kind = and i64 %bits, 7
  %immediate = icmp ne i64 %kind, 0
  br i1 %immediate, label %done, label %tagged
tagged:
  %tag = load i32, ptr %value, align 4
  %ready = icmp uge i32 %tag, 5
  br i1 %ready, label %done, label %deferred
deferred:
  %isthunk = icmp eq i32 %tag, 3
  br i1 %isthunk, label %enter, label %indirect
indirect:
  %forwarded = icmp eq i32 %tag, 2
  br i1 %forwarded, label %next, label %slow
next:
  %slot = getelementptr i8, ptr %value, i64 8
  %p = load ptr, ptr %slot, align 8
  %missing = icmp eq ptr %p, null
  br i1 %missing, label %slow, label %nexttest
nexttest:
  %pbits = ptrtoint ptr %p to i64
  %pkind = and i64 %pbits, 7
  %pimm = icmp ne i64 %pkind, 0
  br i1 %pimm, label %forward, label %ptagged
ptagged:
  %ptag = load i32, ptr %p, align 4
  %pready = icmp uge i32 %ptag, 5
  br i1 %pready, label %forward, label %slow
forward:
  ret ptr %p
done:
  ret ptr %value
enter:
  %code.slot = getelementptr i8, ptr %value, i64 8
  %env.slot = getelementptr i8, ptr %value, i64 16
  %code = load ptr, ptr %code.slot, align 8
  %env = load ptr, ptr %env.slot, align 8
  store i32 1, ptr %value, align 4
  store ptr null, ptr %code.slot, align 8
  store ptr null, ptr %env.slot, align 8
  %returned = call ptr %code(ptr %env, ptr null)
  %canonical = call ptr @mlf_force(ptr %returned)
  store i32 2, ptr %value, align 4
  store ptr %canonical, ptr %code.slot, align 8
  ret ptr %canonical
slow:
  %result = tail call ptr @mlf_force(ptr %value)
  ret ptr %result
}
!0 = !{!"MLF storage"}
!1 = !{!"managed object", !0}
!2 = !{!"array cells", !0}
!3 = !{!1, !1, i64 0}
!4 = !{!2, !2, i64 0}
@mlf.bytes.87 = private unnamed_addr constant [1 x i8] c"\00", align 1
@mlf.bytes.87.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 0, ptr @mlf.bytes.87, ptr null }, align 8
@mlf.bytes.88 = private unnamed_addr constant [2 x i8] c"\20\00", align 1
@mlf.bytes.88.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 1, ptr @mlf.bytes.88, ptr null }, align 8
@mlf.bytes.161 = private unnamed_addr constant [3 x i8] c"\09\3a\00", align 1
@mlf.bytes.161.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 2, ptr @mlf.bytes.161, ptr null }, align 8
@mlf.bytes.678 = private unnamed_addr constant [3 x i8] c"\09\3a\00", align 1
@mlf.bytes.678.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 2, ptr @mlf.bytes.678, ptr null }, align 8
@mlf.bytes.898 = private unnamed_addr constant [1 x i8] c"\00", align 1
@mlf.bytes.898.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 0, ptr @mlf.bytes.898, ptr null }, align 8
@mlf.bytes.924 = private unnamed_addr constant [1 x i8] c"\00", align 1
@mlf.bytes.924.value = private global { i32, i32, i64, ptr, ptr } { i32 8, i32 0, i64 0, ptr @mlf.bytes.924, ptr null }, align 8
define private ptr @mlf.worker.0(ptr %a0) {
entry:
  %v71 = ptrtoint ptr %a0 to i64
  %v72 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v73 = and i64 %v71, %v72
  %v74 = and i64 %v73, 1
  %v75 = icmp ne i64 %v74, 0
  br i1 %v75, label %yes.76, label %no.77
yes.76:
  %v79 = icmp eq i64 %v71, %v72
  %v80 = select i1 %v79, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.78
no.77:
  %v81 = call ptr @mlf_eq_int(ptr %a0, ptr inttoptr (i64 1 to ptr))
  br label %join.78
join.78:
  %v82 = phi ptr [ %v80, %yes.76 ], [ %v81, %no.77 ]
  %v83 = icmp eq ptr %v82, inttoptr (i64 6 to ptr)
  br i1 %v83, label %yes.84, label %no.85
yes.84:
  br label %join.86
no.85:
  %v89 = ptrtoint ptr %a0 to i64
  %v90 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v91 = and i64 %v89, %v90
  %v92 = and i64 %v91, 1
  %v93 = icmp ne i64 %v92, 0
  br i1 %v93, label %yes.94, label %no.95
yes.94:
  %v97 = sub i64 %v90, 1
  %v98 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v89, i64 %v97)
  %v99 = extractvalue { i64, i1 } %v98, 0
  %v100 = extractvalue { i64, i1 } %v98, 1
  br i1 %v100, label %yes.101, label %no.102
yes.101:
  %v104 = call ptr @mlf_sub_int(ptr %a0, ptr inttoptr (i64 3 to ptr))
  br label %join.103
no.102:
  %v105 = inttoptr i64 %v99 to ptr
  br label %join.103
join.103:
  %v106 = phi ptr [ %v104, %yes.101 ], [ %v105, %no.102 ]
  br label %join.96
no.95:
  %v107 = call ptr @mlf_sub_int(ptr %a0, ptr inttoptr (i64 3 to ptr))
  br label %join.96
join.96:
  %v108 = phi ptr [ %v106, %join.103 ], [ %v107, %no.95 ]
  %v109 = call ptr @mlf.worker.0(ptr %v108)
  %v110 = call ptr @mlf_prim2(i64 6, ptr @mlf.bytes.88.value, ptr %v109)
  br label %join.86
join.86:
  %v111 = phi ptr [ @mlf.bytes.87.value, %yes.84 ], [ %v110, %join.96 ]
  ret ptr %v111
}

define private ptr @mlf.code.63(ptr %env, ptr %arg) {
entry:
  %v64 = getelementptr i8, ptr %env, i64 8
  %v65 = load ptr, ptr %v64, align 8, !tbaa !3
  %v66 = getelementptr i8, ptr %env, i64 16
  %v67 = load ptr, ptr %v66, align 8, !tbaa !3
  %v68 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v68, align 8, !tbaa !3
  %v69 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v69, align 8, !tbaa !3
  %v70 = call ptr @mlf.force(ptr %v67)
  %v112 = call ptr @mlf.force(ptr %v65)
  %v113 = ptrtoint ptr %v112 to i64
  %v114 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v115 = and i64 %v113, %v114
  %v116 = and i64 %v115, 1
  %v117 = icmp ne i64 %v116, 0
  br i1 %v117, label %yes.118, label %no.119
yes.118:
  %v121 = ashr i64 %v113, 1
  %v122 = ashr i64 %v114, 1
  %v123 = icmp ne i64 %v122, 0
  %v124 = icmp eq i64 %v121, -4611686018427387904
  %v125 = icmp eq i64 %v122, -1
  %v126 = and i1 %v124, %v125
  %v127 = xor i1 %v126, true
  %v128 = and i1 %v123, %v127
  br i1 %v128, label %yes.129, label %no.130
yes.129:
  %v132 = srem i64 %v121, %v122
  %v133 = shl i64 %v132, 1
  %v134 = or i64 %v133, 1
  %v135 = inttoptr i64 %v134 to ptr
  br label %join.131
no.130:
  %v136 = call ptr @mlf_prim2(i64 16, ptr %v112, ptr inttoptr (i64 21 to ptr))
  br label %join.131
join.131:
  %v137 = phi ptr [ %v135, %yes.129 ], [ %v136, %no.130 ]
  br label %join.120
no.119:
  %v138 = call ptr @mlf_prim2(i64 16, ptr %v112, ptr inttoptr (i64 21 to ptr))
  br label %join.120
join.120:
  %v139 = phi ptr [ %v137, %join.131 ], [ %v138, %no.119 ]
  %v140 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v141 = ptrtoint ptr %v139 to i64
  %v142 = and i64 %v140, %v141
  %v143 = and i64 %v142, 1
  %v144 = icmp ne i64 %v143, 0
  br i1 %v144, label %yes.145, label %no.146
yes.145:
  %v148 = sub i64 %v141, 1
  %v149 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v140, i64 %v148)
  %v150 = extractvalue { i64, i1 } %v149, 0
  %v151 = extractvalue { i64, i1 } %v149, 1
  br i1 %v151, label %yes.152, label %no.153
yes.152:
  %v155 = call ptr @mlf_sub_int(ptr inttoptr (i64 21 to ptr), ptr %v139)
  br label %join.154
no.153:
  %v156 = inttoptr i64 %v150 to ptr
  br label %join.154
join.154:
  %v157 = phi ptr [ %v155, %yes.152 ], [ %v156, %no.153 ]
  br label %join.147
no.146:
  %v158 = call ptr @mlf_sub_int(ptr inttoptr (i64 21 to ptr), ptr %v139)
  br label %join.147
join.147:
  %v159 = phi ptr [ %v157, %join.154 ], [ %v158, %no.146 ]
  %v160 = call ptr @mlf.worker.0(ptr %v159)
  %v162 = call ptr @mlf_prim1(i64 7, ptr %v112)
  %v163 = call ptr @mlf_prim2(i64 6, ptr @mlf.bytes.161.value, ptr %v162)
  %v164 = call ptr @mlf_prim2(i64 6, ptr %v160, ptr %v163)
  %v165 = call ptr @mlf_prim2(i64 6, ptr %v70, ptr %v164)
  ret ptr %v165
}

define private ptr @mlf.code.348(ptr %env, ptr %arg) {
entry:
  %v349 = getelementptr i8, ptr %env, i64 8
  %v350 = load ptr, ptr %v349, align 8, !tbaa !3
  %v351 = getelementptr i8, ptr %env, i64 16
  %v352 = load ptr, ptr %v351, align 8, !tbaa !3
  %v353 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v353, align 8, !tbaa !3
  %v354 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v354, align 8, !tbaa !3
  %v355 = call ptr @mlf.force(ptr %v350)
  %v356 = call ptr @mlf.force(ptr %v352)
  %v357 = ptrtoint ptr %v355 to i64
  %v358 = ptrtoint ptr %v356 to i64
  %v359 = and i64 %v357, %v358
  %v360 = and i64 %v359, 1
  %v361 = icmp ne i64 %v360, 0
  br i1 %v361, label %yes.362, label %no.363
yes.362:
  %v365 = ashr i64 %v357, 1
  %v366 = ashr i64 %v358, 1
  %v367 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v365, i64 %v366)
  %v368 = extractvalue { i64, i1 } %v367, 0
  %v369 = extractvalue { i64, i1 } %v367, 1
  %v370 = xor i1 %v369, true
  %v371 = icmp sge i64 %v368, -4611686018427387904
  %v372 = icmp sle i64 %v368, 4611686018427387903
  %v373 = and i1 %v371, %v372
  %v374 = and i1 %v373, %v370
  br i1 %v374, label %yes.375, label %no.376
yes.375:
  %v378 = shl i64 %v368, 1
  %v379 = or i64 %v378, 1
  %v380 = inttoptr i64 %v379 to ptr
  br label %join.377
no.376:
  %v381 = call ptr @mlf_prim2(i64 14, ptr %v355, ptr %v356)
  br label %join.377
join.377:
  %v382 = phi ptr [ %v380, %yes.375 ], [ %v381, %no.376 ]
  br label %join.364
no.363:
  %v383 = call ptr @mlf_prim2(i64 14, ptr %v355, ptr %v356)
  br label %join.364
join.364:
  %v384 = phi ptr [ %v382, %join.377 ], [ %v383, %no.363 ]
  ret ptr %v384
}

define private ptr @mlf.code.574(ptr %env, ptr %arg) {
entry:
  %v575 = getelementptr i8, ptr %env, i64 8
  %v576 = load ptr, ptr %v575, align 8, !tbaa !3
  %v577 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v577, align 8, !tbaa !3
  %v578 = call ptr @mlf.force(ptr %v576)
  %v579 = ptrtoint ptr %v578 to i64
  %v580 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v581 = and i64 %v579, %v580
  %v582 = and i64 %v581, 1
  %v583 = icmp ne i64 %v582, 0
  br i1 %v583, label %yes.584, label %no.585
yes.584:
  %v587 = sub i64 %v580, 1
  %v588 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v579, i64 %v587)
  %v589 = extractvalue { i64, i1 } %v588, 0
  %v590 = extractvalue { i64, i1 } %v588, 1
  br i1 %v590, label %yes.591, label %no.592
yes.591:
  %v594 = call ptr @mlf_add_int(ptr %v578, ptr inttoptr (i64 3 to ptr))
  br label %join.593
no.592:
  %v595 = inttoptr i64 %v589 to ptr
  br label %join.593
join.593:
  %v596 = phi ptr [ %v594, %yes.591 ], [ %v595, %no.592 ]
  br label %join.586
no.585:
  %v597 = call ptr @mlf_add_int(ptr %v578, ptr inttoptr (i64 3 to ptr))
  br label %join.586
join.586:
  %v598 = phi ptr [ %v596, %join.593 ], [ %v597, %no.585 ]
  ret ptr %v598
}

define private ptr @mlf.code.603(ptr %env, ptr %arg) {
entry:
  %v604 = getelementptr i8, ptr %env, i64 8
  %v605 = load ptr, ptr %v604, align 8, !tbaa !3
  %v606 = getelementptr i8, ptr %env, i64 16
  %v607 = load ptr, ptr %v606, align 8, !tbaa !3
  %v608 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v608, align 8, !tbaa !3
  %v609 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v609, align 8, !tbaa !3
  %v610 = call ptr @mlf.force(ptr %v605)
  %v611 = call ptr @mlf.force(ptr %v607)
  %v612 = call ptr @mlf_prim1(i64 7, ptr %v611)
  %v613 = call ptr @mlf_prim2(i64 6, ptr %v610, ptr %v612)
  ret ptr %v613
}

define private ptr @mlf.code.670(ptr %env, ptr %arg) {
entry:
  %v671 = getelementptr i8, ptr %env, i64 8
  %v672 = load ptr, ptr %v671, align 8, !tbaa !3
  %v673 = getelementptr i8, ptr %env, i64 16
  %v674 = load ptr, ptr %v673, align 8, !tbaa !3
  %v675 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v675, align 8, !tbaa !3
  %v676 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v676, align 8, !tbaa !3
  %v677 = call ptr @mlf.force(ptr %v674)
  %v679 = call ptr @mlf.force(ptr %v672)
  %v680 = call ptr @mlf_prim1(i64 7, ptr %v679)
  %v681 = call ptr @mlf_prim2(i64 6, ptr @mlf.bytes.678.value, ptr %v680)
  %v682 = call ptr @mlf_prim2(i64 6, ptr %v677, ptr %v681)
  ret ptr %v682
}

define private ptr @mlf.code.619(ptr %env, ptr %arg) {
entry:
  %v620 = getelementptr i8, ptr %env, i64 8
  %v621 = load ptr, ptr %v620, align 8, !tbaa !3
  %v622 = getelementptr i8, ptr %env, i64 16
  %v623 = load ptr, ptr %v622, align 8, !tbaa !3
  %v624 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v624, align 8, !tbaa !3
  %v625 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v625, align 8, !tbaa !3
  %v626 = call ptr @mlf.force(ptr %v621)
  %v627 = ptrtoint ptr %v626 to i64
  %v628 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v629 = and i64 %v627, %v628
  %v630 = and i64 %v629, 1
  %v631 = icmp ne i64 %v630, 0
  br i1 %v631, label %yes.632, label %no.633
yes.632:
  %v635 = ashr i64 %v627, 1
  %v636 = ashr i64 %v628, 1
  %v637 = icmp ne i64 %v636, 0
  %v638 = icmp eq i64 %v635, -4611686018427387904
  %v639 = icmp eq i64 %v636, -1
  %v640 = and i1 %v638, %v639
  %v641 = xor i1 %v640, true
  %v642 = and i1 %v637, %v641
  br i1 %v642, label %yes.643, label %no.644
yes.643:
  %v646 = srem i64 %v635, %v636
  %v647 = shl i64 %v646, 1
  %v648 = or i64 %v647, 1
  %v649 = inttoptr i64 %v648 to ptr
  br label %join.645
no.644:
  %v650 = call ptr @mlf_prim2(i64 16, ptr %v626, ptr inttoptr (i64 21 to ptr))
  br label %join.645
join.645:
  %v651 = phi ptr [ %v649, %yes.643 ], [ %v650, %no.644 ]
  br label %join.634
no.633:
  %v652 = call ptr @mlf_prim2(i64 16, ptr %v626, ptr inttoptr (i64 21 to ptr))
  br label %join.634
join.634:
  %v653 = phi ptr [ %v651, %join.645 ], [ %v652, %no.633 ]
  %v654 = ptrtoint ptr %v653 to i64
  %v655 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v656 = and i64 %v654, %v655
  %v657 = and i64 %v656, 1
  %v658 = icmp ne i64 %v657, 0
  br i1 %v658, label %yes.659, label %no.660
yes.659:
  %v662 = icmp eq i64 %v654, %v655
  %v663 = select i1 %v662, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.661
no.660:
  %v664 = call ptr @mlf_eq_int(ptr %v653, ptr inttoptr (i64 1 to ptr))
  br label %join.661
join.661:
  %v665 = phi ptr [ %v663, %yes.659 ], [ %v664, %no.660 ]
  %v666 = icmp eq ptr %v665, inttoptr (i64 6 to ptr)
  br i1 %v666, label %yes.667, label %no.668
yes.667:
  %v683 = call ptr @mlf.allocate.thunk(ptr @mlf.code.670, i64 2)
  %v684 = getelementptr i8, ptr %v683, i64 16
  %v685 = load ptr, ptr %v684, align 8, !tbaa !3
  %v686 = getelementptr i8, ptr %v685, i64 8
  store ptr %v626, ptr %v686, align 8, !tbaa !3
  %v687 = getelementptr i8, ptr %v685, i64 16
  store ptr %v623, ptr %v687, align 8, !tbaa !3
  %v688 = call ptr @mlf_prim1(i64 3, ptr %v683)
  br label %join.669
no.668:
  %v689 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.669
join.669:
  %v690 = phi ptr [ %v688, %yes.667 ], [ %v689, %no.668 ]
  ret ptr %v690
}

define private ptr @mlf.code.715(ptr %env, ptr %arg) {
entry:
  %v716 = getelementptr i8, ptr %env, i64 8
  %v717 = load ptr, ptr %v716, align 8, !tbaa !3
  %v718 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v718, align 8, !tbaa !3
  %v719 = call ptr @mlf.force(ptr %v717)
  %v720 = ptrtoint ptr %v719 to i64
  %v721 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v722 = and i64 %v720, %v721
  %v723 = and i64 %v722, 1
  %v724 = icmp ne i64 %v723, 0
  br i1 %v724, label %yes.725, label %no.726
yes.725:
  %v728 = ashr i64 %v720, 1
  %v729 = ashr i64 %v721, 1
  %v730 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v728, i64 %v729)
  %v731 = extractvalue { i64, i1 } %v730, 0
  %v732 = extractvalue { i64, i1 } %v730, 1
  %v733 = xor i1 %v732, true
  %v734 = icmp sge i64 %v731, -4611686018427387904
  %v735 = icmp sle i64 %v731, 4611686018427387903
  %v736 = and i1 %v734, %v735
  %v737 = and i1 %v736, %v733
  br i1 %v737, label %yes.738, label %no.739
yes.738:
  %v741 = shl i64 %v731, 1
  %v742 = or i64 %v741, 1
  %v743 = inttoptr i64 %v742 to ptr
  br label %join.740
no.739:
  %v744 = call ptr @mlf_prim2(i64 14, ptr %v719, ptr inttoptr (i64 21 to ptr))
  br label %join.740
join.740:
  %v745 = phi ptr [ %v743, %yes.738 ], [ %v744, %no.739 ]
  br label %join.727
no.726:
  %v746 = call ptr @mlf_prim2(i64 14, ptr %v719, ptr inttoptr (i64 21 to ptr))
  br label %join.727
join.727:
  %v747 = phi ptr [ %v745, %join.740 ], [ %v746, %no.726 ]
  ret ptr %v747
}

define private ptr @mlf.code.752(ptr %env, ptr %arg) {
entry:
  %v753 = getelementptr i8, ptr %env, i64 8
  %v754 = load ptr, ptr %v753, align 8, !tbaa !3
  %v755 = getelementptr i8, ptr %env, i64 16
  %v756 = load ptr, ptr %v755, align 8, !tbaa !3
  %v757 = getelementptr i8, ptr %env, i64 24
  %v758 = load ptr, ptr %v757, align 8, !tbaa !3
  %v759 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v759, align 8, !tbaa !3
  %v760 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v760, align 8, !tbaa !3
  %v761 = getelementptr i8, ptr %env, i64 24
  store ptr null, ptr %v761, align 8, !tbaa !3
  %v762 = call ptr @mlf.force(ptr %v754)
  %v763 = call ptr @mlf.force(ptr %v756)
  %v764 = call ptr @mlf.force(ptr %v758)
  %v765 = ptrtoint ptr %v763 to i64
  %v766 = ptrtoint ptr %v764 to i64
  %v767 = and i64 %v765, %v766
  %v768 = and i64 %v767, 1
  %v769 = icmp ne i64 %v768, 0
  br i1 %v769, label %yes.770, label %no.771
yes.770:
  %v773 = ashr i64 %v765, 1
  %v774 = ashr i64 %v766, 1
  %v775 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v773, i64 %v774)
  %v776 = extractvalue { i64, i1 } %v775, 0
  %v777 = extractvalue { i64, i1 } %v775, 1
  %v778 = xor i1 %v777, true
  %v779 = icmp sge i64 %v776, -4611686018427387904
  %v780 = icmp sle i64 %v776, 4611686018427387903
  %v781 = and i1 %v779, %v780
  %v782 = and i1 %v781, %v778
  br i1 %v782, label %yes.783, label %no.784
yes.783:
  %v786 = shl i64 %v776, 1
  %v787 = or i64 %v786, 1
  %v788 = inttoptr i64 %v787 to ptr
  br label %join.785
no.784:
  %v789 = call ptr @mlf_prim2(i64 14, ptr %v763, ptr %v764)
  br label %join.785
join.785:
  %v790 = phi ptr [ %v788, %yes.783 ], [ %v789, %no.784 ]
  br label %join.772
no.771:
  %v791 = call ptr @mlf_prim2(i64 14, ptr %v763, ptr %v764)
  br label %join.772
join.772:
  %v792 = phi ptr [ %v790, %join.785 ], [ %v791, %no.771 ]
  %v793 = ptrtoint ptr %v762 to i64
  %v794 = ptrtoint ptr %v792 to i64
  %v795 = and i64 %v793, %v794
  %v796 = and i64 %v795, 1
  %v797 = icmp ne i64 %v796, 0
  br i1 %v797, label %yes.798, label %no.799
yes.798:
  %v801 = sub i64 %v794, 1
  %v802 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v793, i64 %v801)
  %v803 = extractvalue { i64, i1 } %v802, 0
  %v804 = extractvalue { i64, i1 } %v802, 1
  br i1 %v804, label %yes.805, label %no.806
yes.805:
  %v808 = call ptr @mlf_sub_int(ptr %v762, ptr %v792)
  br label %join.807
no.806:
  %v809 = inttoptr i64 %v803 to ptr
  br label %join.807
join.807:
  %v810 = phi ptr [ %v808, %yes.805 ], [ %v809, %no.806 ]
  br label %join.800
no.799:
  %v811 = call ptr @mlf_sub_int(ptr %v762, ptr %v792)
  br label %join.800
join.800:
  %v812 = phi ptr [ %v810, %join.807 ], [ %v811, %no.799 ]
  %v813 = ptrtoint ptr %v812 to i64
  %v814 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v815 = and i64 %v813, %v814
  %v816 = and i64 %v815, 1
  %v817 = icmp ne i64 %v816, 0
  br i1 %v817, label %yes.818, label %no.819
yes.818:
  %v821 = ashr i64 %v813, 1
  %v822 = ashr i64 %v814, 1
  %v823 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v821, i64 %v822)
  %v824 = extractvalue { i64, i1 } %v823, 0
  %v825 = extractvalue { i64, i1 } %v823, 1
  %v826 = xor i1 %v825, true
  %v827 = icmp sge i64 %v824, -4611686018427387904
  %v828 = icmp sle i64 %v824, 4611686018427387903
  %v829 = and i1 %v827, %v828
  %v830 = and i1 %v829, %v826
  br i1 %v830, label %yes.831, label %no.832
yes.831:
  %v834 = shl i64 %v824, 1
  %v835 = or i64 %v834, 1
  %v836 = inttoptr i64 %v835 to ptr
  br label %join.833
no.832:
  %v837 = call ptr @mlf_prim2(i64 14, ptr %v812, ptr inttoptr (i64 21 to ptr))
  br label %join.833
join.833:
  %v838 = phi ptr [ %v836, %yes.831 ], [ %v837, %no.832 ]
  br label %join.820
no.819:
  %v839 = call ptr @mlf_prim2(i64 14, ptr %v812, ptr inttoptr (i64 21 to ptr))
  br label %join.820
join.820:
  %v840 = phi ptr [ %v838, %join.833 ], [ %v839, %no.819 ]
  ret ptr %v840
}

define private ptr @mlf.code.847(ptr %env, ptr %arg) {
entry:
  %v848 = getelementptr i8, ptr %env, i64 8
  %v849 = load ptr, ptr %v848, align 8, !tbaa !3
  %v850 = getelementptr i8, ptr %env, i64 16
  %v851 = load ptr, ptr %v850, align 8, !tbaa !3
  %v852 = getelementptr i8, ptr %env, i64 8
  store ptr null, ptr %v852, align 8, !tbaa !3
  %v853 = getelementptr i8, ptr %env, i64 16
  store ptr null, ptr %v853, align 8, !tbaa !3
  %v854 = call ptr @mlf.force(ptr %v849)
  %v855 = ptrtoint ptr %v854 to i64
  %v856 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v857 = and i64 %v855, %v856
  %v858 = and i64 %v857, 1
  %v859 = icmp ne i64 %v858, 0
  br i1 %v859, label %yes.860, label %no.861
yes.860:
  %v863 = ashr i64 %v855, 1
  %v864 = ashr i64 %v856, 1
  %v865 = icmp ne i64 %v864, 0
  %v866 = icmp eq i64 %v863, -4611686018427387904
  %v867 = icmp eq i64 %v864, -1
  %v868 = and i1 %v866, %v867
  %v869 = xor i1 %v868, true
  %v870 = and i1 %v865, %v869
  br i1 %v870, label %yes.871, label %no.872
yes.871:
  %v874 = srem i64 %v863, %v864
  %v875 = shl i64 %v874, 1
  %v876 = or i64 %v875, 1
  %v877 = inttoptr i64 %v876 to ptr
  br label %join.873
no.872:
  %v878 = call ptr @mlf_prim2(i64 16, ptr %v854, ptr inttoptr (i64 21 to ptr))
  br label %join.873
join.873:
  %v879 = phi ptr [ %v877, %yes.871 ], [ %v878, %no.872 ]
  br label %join.862
no.861:
  %v880 = call ptr @mlf_prim2(i64 16, ptr %v854, ptr inttoptr (i64 21 to ptr))
  br label %join.862
join.862:
  %v881 = phi ptr [ %v879, %join.873 ], [ %v880, %no.861 ]
  %v882 = ptrtoint ptr %v881 to i64
  %v883 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v884 = and i64 %v882, %v883
  %v885 = and i64 %v884, 1
  %v886 = icmp ne i64 %v885, 0
  br i1 %v886, label %yes.887, label %no.888
yes.887:
  %v890 = icmp eq i64 %v882, %v883
  %v891 = select i1 %v890, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.889
no.888:
  %v892 = call ptr @mlf_eq_int(ptr %v881, ptr inttoptr (i64 1 to ptr))
  br label %join.889
join.889:
  %v893 = phi ptr [ %v891, %yes.887 ], [ %v892, %no.888 ]
  %v894 = icmp eq ptr %v893, inttoptr (i64 6 to ptr)
  br i1 %v894, label %yes.895, label %no.896
yes.895:
  br label %join.897
no.896:
  %v899 = call ptr @mlf.force(ptr %v851)
  br label %join.897
join.897:
  %v900 = phi ptr [ @mlf.bytes.898.value, %yes.895 ], [ %v899, %no.896 ]
  ret ptr %v900
}

define private ptr @mlf.code.696(ptr %env, ptr %arg) {
entry:
  %v697 = getelementptr i8, ptr %env, i64 8
  %v698 = load ptr, ptr %v697, align 8, !tbaa !3
  %v699 = getelementptr i8, ptr %env, i64 16
  %v700 = load ptr, ptr %v699, align 8, !tbaa !3
  %v701 = getelementptr i8, ptr %env, i64 24
  %v702 = load ptr, ptr %v701, align 8, !tbaa !3
  %v703 = getelementptr i8, ptr %env, i64 32
  %v704 = load ptr, ptr %v703, align 8, !tbaa !3
  %v705 = getelementptr i8, ptr %env, i64 40
  %v706 = load ptr, ptr %v705, align 8, !tbaa !3
  %v707 = getelementptr i8, ptr %env, i64 48
  %v708 = load ptr, ptr %v707, align 8, !tbaa !3
  %v709 = getelementptr i8, ptr %env, i64 56
  %v710 = load ptr, ptr %v709, align 8, !tbaa !3
  %v711 = getelementptr i8, ptr %env, i64 64
  %v712 = load ptr, ptr %v711, align 8, !tbaa !3
  %v713 = call ptr @mlf.force(ptr %v698)
  %v714 = call ptr @mlf.force(ptr %v710)
  %v748 = call ptr @mlf.allocate.thunk(ptr @mlf.code.715, i64 1)
  %v749 = getelementptr i8, ptr %v748, i64 16
  %v750 = load ptr, ptr %v749, align 8, !tbaa !3
  %v751 = getelementptr i8, ptr %v750, i64 8
  store ptr %v702, ptr %v751, align 8, !tbaa !3
  %v841 = call ptr @mlf.allocate.thunk(ptr @mlf.code.752, i64 3)
  %v842 = getelementptr i8, ptr %v841, i64 16
  %v843 = load ptr, ptr %v842, align 8, !tbaa !3
  %v844 = getelementptr i8, ptr %v843, i64 8
  store ptr %v704, ptr %v844, align 8, !tbaa !3
  %v845 = getelementptr i8, ptr %v843, i64 16
  store ptr %v706, ptr %v845, align 8, !tbaa !3
  %v846 = getelementptr i8, ptr %v843, i64 24
  store ptr %v708, ptr %v846, align 8, !tbaa !3
  %v901 = call ptr @mlf.allocate.thunk(ptr @mlf.code.847, i64 2)
  %v902 = getelementptr i8, ptr %v901, i64 16
  %v903 = load ptr, ptr %v902, align 8, !tbaa !3
  %v904 = getelementptr i8, ptr %v903, i64 8
  store ptr %v714, ptr %v904, align 8, !tbaa !3
  %v905 = getelementptr i8, ptr %v903, i64 16
  store ptr %v712, ptr %v905, align 8, !tbaa !3
  %v906 = call ptr @mlf.worker.2(ptr %v713, ptr %v714, ptr %v700, ptr %v748, ptr %v841, ptr %v706, ptr %v901)
  ret ptr %v906
}

define private ptr @mlf.worker.2(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6) {
entry:
  %v3 = ptrtoint ptr %a1 to i64
  %v4 = ptrtoint ptr %a0 to i64
  %v5 = and i64 %v3, %v4
  %v6 = and i64 %v5, 1
  %v7 = icmp ne i64 %v6, 0
  br i1 %v7, label %yes.8, label %no.9
yes.8:
  %v11 = icmp eq i64 %v3, %v4
  %v12 = select i1 %v11, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.10
no.9:
  %v13 = call ptr @mlf_eq_int(ptr %a1, ptr %a0)
  br label %join.10
join.10:
  %v14 = phi ptr [ %v12, %yes.8 ], [ %v13, %no.9 ]
  %v15 = icmp eq ptr %v14, inttoptr (i64 6 to ptr)
  br i1 %v15, label %yes.16, label %no.17
yes.16:
  %v19 = ptrtoint ptr %a1 to i64
  %v20 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v21 = and i64 %v19, %v20
  %v22 = and i64 %v21, 1
  %v23 = icmp ne i64 %v22, 0
  br i1 %v23, label %yes.24, label %no.25
yes.24:
  %v27 = ashr i64 %v19, 1
  %v28 = ashr i64 %v20, 1
  %v29 = icmp ne i64 %v28, 0
  %v30 = icmp eq i64 %v27, -4611686018427387904
  %v31 = icmp eq i64 %v28, -1
  %v32 = and i1 %v30, %v31
  %v33 = xor i1 %v32, true
  %v34 = and i1 %v29, %v33
  br i1 %v34, label %yes.35, label %no.36
yes.35:
  %v38 = srem i64 %v27, %v28
  %v39 = shl i64 %v38, 1
  %v40 = or i64 %v39, 1
  %v41 = inttoptr i64 %v40 to ptr
  br label %join.37
no.36:
  %v42 = call ptr @mlf_prim2(i64 16, ptr %a1, ptr inttoptr (i64 21 to ptr))
  br label %join.37
join.37:
  %v43 = phi ptr [ %v41, %yes.35 ], [ %v42, %no.36 ]
  br label %join.26
no.25:
  %v44 = call ptr @mlf_prim2(i64 16, ptr %a1, ptr inttoptr (i64 21 to ptr))
  br label %join.26
join.26:
  %v45 = phi ptr [ %v43, %join.37 ], [ %v44, %no.25 ]
  %v46 = ptrtoint ptr %v45 to i64
  %v47 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v48 = and i64 %v46, %v47
  %v49 = and i64 %v48, 1
  %v50 = icmp ne i64 %v49, 0
  br i1 %v50, label %yes.51, label %no.52
yes.51:
  %v54 = icmp eq i64 %v46, %v47
  %v55 = select i1 %v54, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.53
no.52:
  %v56 = call ptr @mlf_eq_int(ptr %v45, ptr inttoptr (i64 1 to ptr))
  br label %join.53
join.53:
  %v57 = phi ptr [ %v55, %yes.51 ], [ %v56, %no.52 ]
  %v58 = icmp eq ptr %v57, inttoptr (i64 6 to ptr)
  br i1 %v58, label %yes.59, label %no.60
yes.59:
  %v62 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.61
no.60:
  %v166 = call ptr @mlf.allocate.thunk(ptr @mlf.code.63, i64 2)
  %v167 = getelementptr i8, ptr %v166, i64 16
  %v168 = load ptr, ptr %v167, align 8, !tbaa !3
  %v169 = getelementptr i8, ptr %v168, i64 8
  store ptr %a1, ptr %v169, align 8, !tbaa !3
  %v170 = getelementptr i8, ptr %v168, i64 16
  store ptr %a6, ptr %v170, align 8, !tbaa !3
  %v171 = call ptr @mlf_prim1(i64 3, ptr %v166)
  br label %join.61
join.61:
  %v172 = phi ptr [ %v62, %yes.59 ], [ %v171, %no.60 ]
  br label %join.18
no.17:
  %v173 = call ptr @mlf.force(ptr %a2)
  %v174 = ptrtoint ptr %v173 to i64
  %v175 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v176 = and i64 %v174, %v175
  %v177 = and i64 %v176, 1
  %v178 = icmp ne i64 %v177, 0
  br i1 %v178, label %yes.179, label %no.180
yes.179:
  %v182 = sub i64 %v175, 1
  %v183 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v174, i64 %v182)
  %v184 = extractvalue { i64, i1 } %v183, 0
  %v185 = extractvalue { i64, i1 } %v183, 1
  br i1 %v185, label %yes.186, label %no.187
yes.186:
  %v189 = call ptr @mlf_add_int(ptr %v173, ptr inttoptr (i64 3 to ptr))
  br label %join.188
no.187:
  %v190 = inttoptr i64 %v184 to ptr
  br label %join.188
join.188:
  %v191 = phi ptr [ %v189, %yes.186 ], [ %v190, %no.187 ]
  br label %join.181
no.180:
  %v192 = call ptr @mlf_add_int(ptr %v173, ptr inttoptr (i64 3 to ptr))
  br label %join.181
join.181:
  %v193 = phi ptr [ %v191, %join.188 ], [ %v192, %no.180 ]
  %v194 = ptrtoint ptr %v193 to i64
  %v195 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v196 = and i64 %v194, %v195
  %v197 = and i64 %v196, 1
  %v198 = icmp ne i64 %v197, 0
  br i1 %v198, label %yes.199, label %no.200
yes.199:
  %v202 = ashr i64 %v194, 1
  %v203 = ashr i64 %v195, 1
  %v204 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v202, i64 %v203)
  %v205 = extractvalue { i64, i1 } %v204, 0
  %v206 = extractvalue { i64, i1 } %v204, 1
  %v207 = xor i1 %v206, true
  %v208 = icmp sge i64 %v205, -4611686018427387904
  %v209 = icmp sle i64 %v205, 4611686018427387903
  %v210 = and i1 %v208, %v209
  %v211 = and i1 %v210, %v207
  br i1 %v211, label %yes.212, label %no.213
yes.212:
  %v215 = shl i64 %v205, 1
  %v216 = or i64 %v215, 1
  %v217 = inttoptr i64 %v216 to ptr
  br label %join.214
no.213:
  %v218 = call ptr @mlf_prim2(i64 14, ptr %v193, ptr inttoptr (i64 5 to ptr))
  br label %join.214
join.214:
  %v219 = phi ptr [ %v217, %yes.212 ], [ %v218, %no.213 ]
  br label %join.201
no.200:
  %v220 = call ptr @mlf_prim2(i64 14, ptr %v193, ptr inttoptr (i64 5 to ptr))
  br label %join.201
join.201:
  %v221 = phi ptr [ %v219, %join.214 ], [ %v220, %no.200 ]
  %v222 = ptrtoint ptr %v221 to i64
  %v223 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v224 = and i64 %v222, %v223
  %v225 = and i64 %v224, 1
  %v226 = icmp ne i64 %v225, 0
  br i1 %v226, label %yes.227, label %no.228
yes.227:
  %v230 = sub i64 %v223, 1
  %v231 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v222, i64 %v230)
  %v232 = extractvalue { i64, i1 } %v231, 0
  %v233 = extractvalue { i64, i1 } %v231, 1
  br i1 %v233, label %yes.234, label %no.235
yes.234:
  %v237 = call ptr @mlf_add_int(ptr %v221, ptr inttoptr (i64 3 to ptr))
  br label %join.236
no.235:
  %v238 = inttoptr i64 %v232 to ptr
  br label %join.236
join.236:
  %v239 = phi ptr [ %v237, %yes.234 ], [ %v238, %no.235 ]
  br label %join.229
no.228:
  %v240 = call ptr @mlf_add_int(ptr %v221, ptr inttoptr (i64 3 to ptr))
  br label %join.229
join.229:
  %v241 = phi ptr [ %v239, %join.236 ], [ %v240, %no.228 ]
  %v242 = call ptr @mlf.force(ptr %a3)
  %v243 = ptrtoint ptr %v242 to i64
  %v244 = ptrtoint ptr %v193 to i64
  %v245 = and i64 %v243, %v244
  %v246 = and i64 %v245, 1
  %v247 = icmp ne i64 %v246, 0
  br i1 %v247, label %yes.248, label %no.249
yes.248:
  %v251 = ashr i64 %v243, 1
  %v252 = ashr i64 %v244, 1
  %v253 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v251, i64 %v252)
  %v254 = extractvalue { i64, i1 } %v253, 0
  %v255 = extractvalue { i64, i1 } %v253, 1
  %v256 = xor i1 %v255, true
  %v257 = icmp sge i64 %v254, -4611686018427387904
  %v258 = icmp sle i64 %v254, 4611686018427387903
  %v259 = and i1 %v257, %v258
  %v260 = and i1 %v259, %v256
  br i1 %v260, label %yes.261, label %no.262
yes.261:
  %v264 = shl i64 %v254, 1
  %v265 = or i64 %v264, 1
  %v266 = inttoptr i64 %v265 to ptr
  br label %join.263
no.262:
  %v267 = call ptr @mlf_prim2(i64 14, ptr %v242, ptr %v193)
  br label %join.263
join.263:
  %v268 = phi ptr [ %v266, %yes.261 ], [ %v267, %no.262 ]
  br label %join.250
no.249:
  %v269 = call ptr @mlf_prim2(i64 14, ptr %v242, ptr %v193)
  br label %join.250
join.250:
  %v270 = phi ptr [ %v268, %join.263 ], [ %v269, %no.249 ]
  %v271 = call ptr @mlf.force(ptr %a4)
  %v272 = ptrtoint ptr %v242 to i64
  %v273 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v274 = and i64 %v272, %v273
  %v275 = and i64 %v274, 1
  %v276 = icmp ne i64 %v275, 0
  br i1 %v276, label %yes.277, label %no.278
yes.277:
  %v280 = ashr i64 %v272, 1
  %v281 = ashr i64 %v273, 1
  %v282 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v280, i64 %v281)
  %v283 = extractvalue { i64, i1 } %v282, 0
  %v284 = extractvalue { i64, i1 } %v282, 1
  %v285 = xor i1 %v284, true
  %v286 = icmp sge i64 %v283, -4611686018427387904
  %v287 = icmp sle i64 %v283, 4611686018427387903
  %v288 = and i1 %v286, %v287
  %v289 = and i1 %v288, %v285
  br i1 %v289, label %yes.290, label %no.291
yes.290:
  %v293 = shl i64 %v283, 1
  %v294 = or i64 %v293, 1
  %v295 = inttoptr i64 %v294 to ptr
  br label %join.292
no.291:
  %v296 = call ptr @mlf_prim2(i64 14, ptr %v242, ptr inttoptr (i64 5 to ptr))
  br label %join.292
join.292:
  %v297 = phi ptr [ %v295, %yes.290 ], [ %v296, %no.291 ]
  br label %join.279
no.278:
  %v298 = call ptr @mlf_prim2(i64 14, ptr %v242, ptr inttoptr (i64 5 to ptr))
  br label %join.279
join.279:
  %v299 = phi ptr [ %v297, %join.292 ], [ %v298, %no.278 ]
  %v300 = ptrtoint ptr %v271 to i64
  %v301 = ptrtoint ptr %v299 to i64
  %v302 = and i64 %v300, %v301
  %v303 = and i64 %v302, 1
  %v304 = icmp ne i64 %v303, 0
  br i1 %v304, label %yes.305, label %no.306
yes.305:
  %v308 = sub i64 %v301, 1
  %v309 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v300, i64 %v308)
  %v310 = extractvalue { i64, i1 } %v309, 0
  %v311 = extractvalue { i64, i1 } %v309, 1
  br i1 %v311, label %yes.312, label %no.313
yes.312:
  %v315 = call ptr @mlf_add_int(ptr %v271, ptr %v299)
  br label %join.314
no.313:
  %v316 = inttoptr i64 %v310 to ptr
  br label %join.314
join.314:
  %v317 = phi ptr [ %v315, %yes.312 ], [ %v316, %no.313 ]
  br label %join.307
no.306:
  %v318 = call ptr @mlf_add_int(ptr %v271, ptr %v299)
  br label %join.307
join.307:
  %v319 = phi ptr [ %v317, %join.314 ], [ %v318, %no.306 ]
  %v320 = ptrtoint ptr %v319 to i64
  %v321 = ptrtoint ptr %v241 to i64
  %v322 = and i64 %v320, %v321
  %v323 = and i64 %v322, 1
  %v324 = icmp ne i64 %v323, 0
  br i1 %v324, label %yes.325, label %no.326
yes.325:
  %v328 = ashr i64 %v320, 1
  %v329 = ashr i64 %v321, 1
  %v330 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v328, i64 %v329)
  %v331 = extractvalue { i64, i1 } %v330, 0
  %v332 = extractvalue { i64, i1 } %v330, 1
  %v333 = xor i1 %v332, true
  %v334 = icmp sge i64 %v331, -4611686018427387904
  %v335 = icmp sle i64 %v331, 4611686018427387903
  %v336 = and i1 %v334, %v335
  %v337 = and i1 %v336, %v333
  br i1 %v337, label %yes.338, label %no.339
yes.338:
  %v341 = shl i64 %v331, 1
  %v342 = or i64 %v341, 1
  %v343 = inttoptr i64 %v342 to ptr
  br label %join.340
no.339:
  %v344 = call ptr @mlf_prim2(i64 14, ptr %v319, ptr %v241)
  br label %join.340
join.340:
  %v345 = phi ptr [ %v343, %yes.338 ], [ %v344, %no.339 ]
  br label %join.327
no.326:
  %v346 = call ptr @mlf_prim2(i64 14, ptr %v319, ptr %v241)
  br label %join.327
join.327:
  %v347 = phi ptr [ %v345, %join.340 ], [ %v346, %no.326 ]
  %v385 = call ptr @mlf.allocate.thunk(ptr @mlf.code.348, i64 2)
  %v386 = getelementptr i8, ptr %v385, i64 16
  %v387 = load ptr, ptr %v386, align 8, !tbaa !3
  %v388 = getelementptr i8, ptr %v387, i64 8
  store ptr %a5, ptr %v388, align 8, !tbaa !3
  %v389 = getelementptr i8, ptr %v387, i64 16
  store ptr %v241, ptr %v389, align 8, !tbaa !3
  %v390 = ptrtoint ptr %v347 to i64
  %v391 = ptrtoint ptr %v270 to i64
  %v392 = and i64 %v390, %v391
  %v393 = and i64 %v392, 1
  %v394 = icmp ne i64 %v393, 0
  br i1 %v394, label %yes.395, label %no.396
yes.395:
  %v398 = icmp slt i64 %v390, %v391
  %v399 = select i1 %v398, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.397
no.396:
  %v400 = call ptr @mlf_lt_int(ptr %v347, ptr %v270)
  br label %join.397
join.397:
  %v401 = phi ptr [ %v399, %yes.395 ], [ %v400, %no.396 ]
  %v402 = icmp eq ptr %v401, inttoptr (i64 6 to ptr)
  br i1 %v402, label %yes.403, label %no.404
yes.403:
  %v406 = call ptr @mlf.worker.2(ptr %a0, ptr %a1, ptr %v193, ptr %v270, ptr %v347, ptr %v385, ptr %a6)
  br label %join.405
no.404:
  %v407 = ptrtoint ptr %v270 to i64
  %v408 = ptrtoint ptr inttoptr (i64 7 to ptr) to i64
  %v409 = and i64 %v407, %v408
  %v410 = and i64 %v409, 1
  %v411 = icmp ne i64 %v410, 0
  br i1 %v411, label %yes.412, label %no.413
yes.412:
  %v415 = ashr i64 %v407, 1
  %v416 = ashr i64 %v408, 1
  %v417 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v415, i64 %v416)
  %v418 = extractvalue { i64, i1 } %v417, 0
  %v419 = extractvalue { i64, i1 } %v417, 1
  %v420 = xor i1 %v419, true
  %v421 = icmp sge i64 %v418, -4611686018427387904
  %v422 = icmp sle i64 %v418, 4611686018427387903
  %v423 = and i1 %v421, %v422
  %v424 = and i1 %v423, %v420
  br i1 %v424, label %yes.425, label %no.426
yes.425:
  %v428 = shl i64 %v418, 1
  %v429 = or i64 %v428, 1
  %v430 = inttoptr i64 %v429 to ptr
  br label %join.427
no.426:
  %v431 = call ptr @mlf_prim2(i64 14, ptr %v270, ptr inttoptr (i64 7 to ptr))
  br label %join.427
join.427:
  %v432 = phi ptr [ %v430, %yes.425 ], [ %v431, %no.426 ]
  br label %join.414
no.413:
  %v433 = call ptr @mlf_prim2(i64 14, ptr %v270, ptr inttoptr (i64 7 to ptr))
  br label %join.414
join.414:
  %v434 = phi ptr [ %v432, %join.427 ], [ %v433, %no.413 ]
  %v435 = ptrtoint ptr %v434 to i64
  %v436 = ptrtoint ptr %v347 to i64
  %v437 = and i64 %v435, %v436
  %v438 = and i64 %v437, 1
  %v439 = icmp ne i64 %v438, 0
  br i1 %v439, label %yes.440, label %no.441
yes.440:
  %v443 = sub i64 %v436, 1
  %v444 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v435, i64 %v443)
  %v445 = extractvalue { i64, i1 } %v444, 0
  %v446 = extractvalue { i64, i1 } %v444, 1
  br i1 %v446, label %yes.447, label %no.448
yes.447:
  %v450 = call ptr @mlf_add_int(ptr %v434, ptr %v347)
  br label %join.449
no.448:
  %v451 = inttoptr i64 %v445 to ptr
  br label %join.449
join.449:
  %v452 = phi ptr [ %v450, %yes.447 ], [ %v451, %no.448 ]
  br label %join.442
no.441:
  %v453 = call ptr @mlf_add_int(ptr %v434, ptr %v347)
  br label %join.442
join.442:
  %v454 = phi ptr [ %v452, %join.449 ], [ %v453, %no.441 ]
  %v455 = call ptr @mlf.force(ptr %v385)
  %v456 = ptrtoint ptr %v454 to i64
  %v457 = ptrtoint ptr %v455 to i64
  %v458 = and i64 %v456, %v457
  %v459 = and i64 %v458, 1
  %v460 = icmp ne i64 %v459, 0
  br i1 %v460, label %yes.461, label %no.462
yes.461:
  %v464 = ashr i64 %v456, 1
  %v465 = ashr i64 %v457, 1
  %v466 = icmp ne i64 %v465, 0
  %v467 = icmp eq i64 %v464, -4611686018427387904
  %v468 = icmp eq i64 %v465, -1
  %v469 = and i1 %v467, %v468
  %v470 = xor i1 %v469, true
  %v471 = and i1 %v466, %v470
  br i1 %v471, label %yes.472, label %no.473
yes.472:
  %v475 = sdiv i64 %v464, %v465
  %v476 = shl i64 %v475, 1
  %v477 = or i64 %v476, 1
  %v478 = inttoptr i64 %v477 to ptr
  br label %join.474
no.473:
  %v479 = call ptr @mlf_prim2(i64 15, ptr %v454, ptr %v455)
  br label %join.474
join.474:
  %v480 = phi ptr [ %v478, %yes.472 ], [ %v479, %no.473 ]
  br label %join.463
no.462:
  %v481 = call ptr @mlf_prim2(i64 15, ptr %v454, ptr %v455)
  br label %join.463
join.463:
  %v482 = phi ptr [ %v480, %join.474 ], [ %v481, %no.462 ]
  %v483 = ptrtoint ptr %v270 to i64
  %v484 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v485 = and i64 %v483, %v484
  %v486 = and i64 %v485, 1
  %v487 = icmp ne i64 %v486, 0
  br i1 %v487, label %yes.488, label %no.489
yes.488:
  %v491 = ashr i64 %v483, 1
  %v492 = ashr i64 %v484, 1
  %v493 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v491, i64 %v492)
  %v494 = extractvalue { i64, i1 } %v493, 0
  %v495 = extractvalue { i64, i1 } %v493, 1
  %v496 = xor i1 %v495, true
  %v497 = icmp sge i64 %v494, -4611686018427387904
  %v498 = icmp sle i64 %v494, 4611686018427387903
  %v499 = and i1 %v497, %v498
  %v500 = and i1 %v499, %v496
  br i1 %v500, label %yes.501, label %no.502
yes.501:
  %v504 = shl i64 %v494, 1
  %v505 = or i64 %v504, 1
  %v506 = inttoptr i64 %v505 to ptr
  br label %join.503
no.502:
  %v507 = call ptr @mlf_prim2(i64 14, ptr %v270, ptr inttoptr (i64 9 to ptr))
  br label %join.503
join.503:
  %v508 = phi ptr [ %v506, %yes.501 ], [ %v507, %no.502 ]
  br label %join.490
no.489:
  %v509 = call ptr @mlf_prim2(i64 14, ptr %v270, ptr inttoptr (i64 9 to ptr))
  br label %join.490
join.490:
  %v510 = phi ptr [ %v508, %join.503 ], [ %v509, %no.489 ]
  %v511 = ptrtoint ptr %v510 to i64
  %v512 = ptrtoint ptr %v347 to i64
  %v513 = and i64 %v511, %v512
  %v514 = and i64 %v513, 1
  %v515 = icmp ne i64 %v514, 0
  br i1 %v515, label %yes.516, label %no.517
yes.516:
  %v519 = sub i64 %v512, 1
  %v520 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v511, i64 %v519)
  %v521 = extractvalue { i64, i1 } %v520, 0
  %v522 = extractvalue { i64, i1 } %v520, 1
  br i1 %v522, label %yes.523, label %no.524
yes.523:
  %v526 = call ptr @mlf_add_int(ptr %v510, ptr %v347)
  br label %join.525
no.524:
  %v527 = inttoptr i64 %v521 to ptr
  br label %join.525
join.525:
  %v528 = phi ptr [ %v526, %yes.523 ], [ %v527, %no.524 ]
  br label %join.518
no.517:
  %v529 = call ptr @mlf_add_int(ptr %v510, ptr %v347)
  br label %join.518
join.518:
  %v530 = phi ptr [ %v528, %join.525 ], [ %v529, %no.517 ]
  %v531 = ptrtoint ptr %v530 to i64
  %v532 = ptrtoint ptr %v455 to i64
  %v533 = and i64 %v531, %v532
  %v534 = and i64 %v533, 1
  %v535 = icmp ne i64 %v534, 0
  br i1 %v535, label %yes.536, label %no.537
yes.536:
  %v539 = ashr i64 %v531, 1
  %v540 = ashr i64 %v532, 1
  %v541 = icmp ne i64 %v540, 0
  %v542 = icmp eq i64 %v539, -4611686018427387904
  %v543 = icmp eq i64 %v540, -1
  %v544 = and i1 %v542, %v543
  %v545 = xor i1 %v544, true
  %v546 = and i1 %v541, %v545
  br i1 %v546, label %yes.547, label %no.548
yes.547:
  %v550 = sdiv i64 %v539, %v540
  %v551 = shl i64 %v550, 1
  %v552 = or i64 %v551, 1
  %v553 = inttoptr i64 %v552 to ptr
  br label %join.549
no.548:
  %v554 = call ptr @mlf_prim2(i64 15, ptr %v530, ptr %v455)
  br label %join.549
join.549:
  %v555 = phi ptr [ %v553, %yes.547 ], [ %v554, %no.548 ]
  br label %join.538
no.537:
  %v556 = call ptr @mlf_prim2(i64 15, ptr %v530, ptr %v455)
  br label %join.538
join.538:
  %v557 = phi ptr [ %v555, %join.549 ], [ %v556, %no.537 ]
  %v558 = ptrtoint ptr %v482 to i64
  %v559 = ptrtoint ptr %v557 to i64
  %v560 = and i64 %v558, %v559
  %v561 = and i64 %v560, 1
  %v562 = icmp ne i64 %v561, 0
  br i1 %v562, label %yes.563, label %no.564
yes.563:
  %v566 = icmp eq i64 %v558, %v559
  %v567 = select i1 %v566, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.565
no.564:
  %v568 = call ptr @mlf_eq_int(ptr %v482, ptr %v557)
  br label %join.565
join.565:
  %v569 = phi ptr [ %v567, %yes.563 ], [ %v568, %no.564 ]
  %v570 = icmp eq ptr %v569, inttoptr (i64 6 to ptr)
  br i1 %v570, label %yes.571, label %no.572
yes.571:
  %v599 = call ptr @mlf.allocate.thunk(ptr @mlf.code.574, i64 1)
  %v600 = getelementptr i8, ptr %v599, i64 16
  %v601 = load ptr, ptr %v600, align 8, !tbaa !3
  %v602 = getelementptr i8, ptr %v601, i64 8
  store ptr %a1, ptr %v602, align 8, !tbaa !3
  %v614 = call ptr @mlf.allocate.thunk(ptr @mlf.code.603, i64 2)
  %v615 = getelementptr i8, ptr %v614, i64 16
  %v616 = load ptr, ptr %v615, align 8, !tbaa !3
  %v617 = getelementptr i8, ptr %v616, i64 8
  store ptr %a6, ptr %v617, align 8, !tbaa !3
  %v618 = getelementptr i8, ptr %v616, i64 16
  store ptr %v482, ptr %v618, align 8, !tbaa !3
  %v691 = call ptr @mlf.allocate.thunk(ptr @mlf.code.619, i64 2)
  %v692 = getelementptr i8, ptr %v691, i64 16
  %v693 = load ptr, ptr %v692, align 8, !tbaa !3
  %v694 = getelementptr i8, ptr %v693, i64 8
  store ptr %v599, ptr %v694, align 8, !tbaa !3
  %v695 = getelementptr i8, ptr %v693, i64 16
  store ptr %v614, ptr %v695, align 8, !tbaa !3
  %v907 = call ptr @mlf_env_new(i64 8)
  %v908 = getelementptr i8, ptr %v907, i64 8
  store ptr %a0, ptr %v908, align 8, !tbaa !3
  %v909 = getelementptr i8, ptr %v907, i64 16
  store ptr %v193, ptr %v909, align 8, !tbaa !3
  %v910 = getelementptr i8, ptr %v907, i64 24
  store ptr %v270, ptr %v910, align 8, !tbaa !3
  %v911 = getelementptr i8, ptr %v907, i64 32
  store ptr %v347, ptr %v911, align 8, !tbaa !3
  %v912 = getelementptr i8, ptr %v907, i64 40
  store ptr %v455, ptr %v912, align 8, !tbaa !3
  %v913 = getelementptr i8, ptr %v907, i64 48
  store ptr %v482, ptr %v913, align 8, !tbaa !3
  %v914 = getelementptr i8, ptr %v907, i64 56
  store ptr %v599, ptr %v914, align 8, !tbaa !3
  %v915 = getelementptr i8, ptr %v907, i64 64
  store ptr %v614, ptr %v915, align 8, !tbaa !3
  %v916 = call ptr @mlf_closure(ptr @mlf.code.696, ptr %v907)
  %v917 = call ptr @mlf_prim2(i64 1, ptr %v691, ptr %v916)
  br label %join.573
no.572:
  %v918 = call ptr @mlf.worker.2(ptr %a0, ptr %a1, ptr %v193, ptr %v270, ptr %v347, ptr %v455, ptr %a6)
  br label %join.573
join.573:
  %v919 = phi ptr [ %v917, %yes.571 ], [ %v918, %no.572 ]
  br label %join.405
join.405:
  %v920 = phi ptr [ %v406, %yes.403 ], [ %v919, %join.573 ]
  br label %join.18
join.18:
  %v921 = phi ptr [ %v172, %join.61 ], [ %v920, %join.405 ]
  ret ptr %v921
}

define private ptr @mlf.code.2(ptr %env, ptr %arg) {
entry:
  %v922 = call ptr @mlf.force(ptr %arg)
  %v923 = call ptr @mlf_prim1(i64 17, ptr %v922)
  %v925 = call ptr @mlf.worker.2(ptr %v923, ptr inttoptr (i64 1 to ptr), ptr inttoptr (i64 1 to ptr), ptr inttoptr (i64 3 to ptr), ptr inttoptr (i64 1 to ptr), ptr inttoptr (i64 3 to ptr), ptr @mlf.bytes.924.value)
  ret ptr %v925
}

define private ptr @mlf.code.0(ptr %env, ptr %arg) {
entry:
  %v1 = call ptr @mlf_primitive(i64 4)
  %v926 = call ptr @mlf_closure(ptr @mlf.code.2, ptr null)
  %v927 = call ptr @mlf_prim2(i64 1, ptr %v1, ptr %v926)
  ret ptr %v927
}

declare void @mlf_require_compact_gc_abi()
define ptr @mlf_entry() {
  call void @mlf_require_compact_gc_abi()
  %root = call ptr @mlf.code.0(ptr null, ptr null)
  ret ptr %root
}
define i32 @main(i32 %argc, ptr %argv) {
  call void @mlf_set_args(i32 %argc, ptr %argv)
  %root = call ptr @mlf_entry()
  %status = call i32 @mlf_run(ptr %root, i64 1)
  ret i32 %status
}
