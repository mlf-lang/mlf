; Generated from independently checked xMLF.
source_filename = "emlf"

declare ptr @mlf_execute_st_lazy(ptr)
declare ptr @mlf_st_new_array(ptr, ptr)
declare ptr @mlf_st_read_array(ptr, ptr)
declare ptr @mlf_st_write_array(ptr, ptr, ptr)
declare ptr @mlf_st_length_array(ptr)
declare void @mlf_set_args(i32, ptr)
declare ptr @mlf_env_new(i64)
declare void @mlf_env_set(ptr, i64, ptr)
declare ptr @mlf_env_get(ptr, i64)
declare ptr @mlf_thunk(ptr, ptr)
declare ptr @mlf_closure(ptr, ptr)
declare ptr @mlf_application(ptr, ptr)
declare ptr @mlf_hole()
declare void @mlf_fill(ptr, ptr)
declare ptr @mlf_integer(ptr)
declare ptr @mlf_string(ptr, i64)
declare ptr @mlf_double(double)
declare double @llvm.sqrt.f64(double)
declare double @mlf_int_to_double(ptr)
declare ptr @mlf_read_int_table(ptr, ptr)
declare ptr @mlf_write_int_table(ptr, ptr, ptr)
declare ptr @mlf_add_int_table(ptr, ptr, ptr)
declare void @mlf_roots_enter(ptr, i64, ptr)
declare void @mlf_roots_leave(ptr)
declare void @mlf_gc_check(i64, ptr)
declare ptr @mlf_get_byte_line()
declare ptr @mlf_new_array(i64, ptr, ptr)
declare ptr @mlf_bytes_from_string(ptr)
declare ptr @mlf_put_bytes(ptr, ptr, ptr)
declare ptr @mlf_new_int_table()
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare i8 @mlf_byte(ptr)
declare ptr @mlf_peek(ptr)
declare ptr @mlf_native_io(ptr, ptr)
declare void @mlf_bounds_failure() noreturn
declare ptr @mlf_primitive(i64)
declare ptr @mlf_prim1(i64, ptr)
declare ptr @mlf_prim2(i64, ptr, ptr)
declare i64 @mlf_truth(ptr)
declare ptr @mlf_prim3(i64, ptr, ptr, ptr)
declare ptr @mlf_force(ptr)
declare ptr @mlf_add_int(ptr, ptr)
declare ptr @mlf_sub_int(ptr, ptr)
declare ptr @mlf_eq_int(ptr, ptr)
declare ptr @mlf_lt_int(ptr, ptr)
declare ptr @mlf_constructor(i64, i64)
declare ptr @mlf_constructor1(i64, ptr)
declare ptr @mlf_constructor2(i64, ptr, ptr)
declare ptr @mlf_constructor_fields(i64, ptr)
declare ptr @mlf_constructor_new(i64, i64)
declare ptr @mlf_field(ptr, i64)
declare void @mlf_match_failure() noreturn
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare i32 @mlf_run(ptr, i64)

!0 = !{!"MLF storage"}
!1 = !{!"managed object", !0}
!2 = !{!"array cells", !0}
!3 = !{!1, !1, i64 0}
!4 = !{!2, !2, i64 0}
@mlf.bytes.85 = private unnamed_addr constant [1 x i8] c"\00", align 1
@mlf.bytes.87 = private unnamed_addr constant [2 x i8] c"\20\00", align 1
@mlf.bytes.161 = private unnamed_addr constant [3 x i8] c"\09\3a\00", align 1
@mlf.bytes.666 = private unnamed_addr constant [3 x i8] c"\09\3a\00", align 1
@mlf.bytes.877 = private unnamed_addr constant [1 x i8] c"\00", align 1
@mlf.bytes.903 = private unnamed_addr constant [1 x i8] c"\00", align 1
define private ptr @mlf.worker.0(ptr %a0) {
entry:
  %v69 = ptrtoint ptr %a0 to i64
  %v70 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v71 = and i64 %v69, %v70
  %v72 = and i64 %v71, 1
  %v73 = icmp ne i64 %v72, 0
  br i1 %v73, label %yes.74, label %no.75
yes.74:
  %v77 = icmp eq i64 %v69, %v70
  %v78 = select i1 %v77, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.76
no.75:
  %v79 = call ptr @mlf_eq_int(ptr %a0, ptr inttoptr (i64 1 to ptr))
  br label %join.76
join.76:
  %v80 = phi ptr [ %v78, %yes.74 ], [ %v79, %no.75 ]
  %v81 = icmp eq ptr %v80, inttoptr (i64 6 to ptr)
  br i1 %v81, label %yes.82, label %no.83
yes.82:
  %v86 = call ptr @mlf_string(ptr @mlf.bytes.85, i64 0)
  br label %join.84
no.83:
  %v88 = call ptr @mlf_string(ptr @mlf.bytes.87, i64 1)
  %v89 = ptrtoint ptr %a0 to i64
  %v90 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v91 = and i64 %v89, %v90
  %v92 = and i64 %v91, 1
  %v93 = icmp ne i64 %v92, 0
  br i1 %v93, label %yes.94, label %no.95
yes.94:
  %v97 = sub i64 %v90, 1
  %v98 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v89, i64 %v97)
  %v99 = extractvalue { i64, i1 } %v98, 0
  %v100 = extractvalue { i64, i1 } %v98, 1
  br i1 %v100, label %yes.101, label %no.102
yes.101:
  %v104 = call ptr @mlf_sub_int(ptr %a0, ptr inttoptr (i64 3 to ptr))
  br label %join.103
no.102:
  %v105 = inttoptr i64 %v99 to ptr
  br label %join.103
join.103:
  %v106 = phi ptr [ %v104, %yes.101 ], [ %v105, %no.102 ]
  br label %join.96
no.95:
  %v107 = call ptr @mlf_sub_int(ptr %a0, ptr inttoptr (i64 3 to ptr))
  br label %join.96
join.96:
  %v108 = phi ptr [ %v106, %join.103 ], [ %v107, %no.95 ]
  %v109 = call ptr @mlf.worker.0(ptr %v108)
  %v110 = call ptr @mlf_prim2(i64 6, ptr %v88, ptr %v109)
  br label %join.84
join.84:
  %v111 = phi ptr [ %v86, %yes.82 ], [ %v110, %join.96 ]
  ret ptr %v111
}

define private ptr @mlf.code.63(ptr %env, ptr %arg) {
entry:
  %v64 = getelementptr i8, ptr %env, i64 24
  %v65 = load ptr, ptr %v64, align 8, !tbaa !3
  %v66 = getelementptr i8, ptr %env, i64 32
  %v67 = load ptr, ptr %v66, align 8, !tbaa !3
  %v68 = call ptr @mlf_force(ptr %v67)
  %v112 = call ptr @mlf_force(ptr %v65)
  %v113 = ptrtoint ptr %v112 to i64
  %v114 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v115 = and i64 %v113, %v114
  %v116 = and i64 %v115, 1
  %v117 = icmp ne i64 %v116, 0
  br i1 %v117, label %yes.118, label %no.119
yes.118:
  %v121 = ashr i64 %v113, 1
  %v122 = ashr i64 %v114, 1
  %v123 = icmp ne i64 %v122, 0
  %v124 = icmp eq i64 %v121, -4611686018427387904
  %v125 = icmp eq i64 %v122, -1
  %v126 = and i1 %v124, %v125
  %v127 = xor i1 %v126, true
  %v128 = and i1 %v123, %v127
  br i1 %v128, label %yes.129, label %no.130
yes.129:
  %v132 = srem i64 %v121, %v122
  %v133 = shl i64 %v132, 1
  %v134 = or i64 %v133, 1
  %v135 = inttoptr i64 %v134 to ptr
  br label %join.131
no.130:
  %v136 = call ptr @mlf_prim2(i64 16, ptr %v112, ptr inttoptr (i64 21 to ptr))
  br label %join.131
join.131:
  %v137 = phi ptr [ %v135, %yes.129 ], [ %v136, %no.130 ]
  br label %join.120
no.119:
  %v138 = call ptr @mlf_prim2(i64 16, ptr %v112, ptr inttoptr (i64 21 to ptr))
  br label %join.120
join.120:
  %v139 = phi ptr [ %v137, %join.131 ], [ %v138, %no.119 ]
  %v140 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v141 = ptrtoint ptr %v139 to i64
  %v142 = and i64 %v140, %v141
  %v143 = and i64 %v142, 1
  %v144 = icmp ne i64 %v143, 0
  br i1 %v144, label %yes.145, label %no.146
yes.145:
  %v148 = sub i64 %v141, 1
  %v149 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v140, i64 %v148)
  %v150 = extractvalue { i64, i1 } %v149, 0
  %v151 = extractvalue { i64, i1 } %v149, 1
  br i1 %v151, label %yes.152, label %no.153
yes.152:
  %v155 = call ptr @mlf_sub_int(ptr inttoptr (i64 21 to ptr), ptr %v139)
  br label %join.154
no.153:
  %v156 = inttoptr i64 %v150 to ptr
  br label %join.154
join.154:
  %v157 = phi ptr [ %v155, %yes.152 ], [ %v156, %no.153 ]
  br label %join.147
no.146:
  %v158 = call ptr @mlf_sub_int(ptr inttoptr (i64 21 to ptr), ptr %v139)
  br label %join.147
join.147:
  %v159 = phi ptr [ %v157, %join.154 ], [ %v158, %no.146 ]
  %v160 = call ptr @mlf.worker.0(ptr %v159)
  %v162 = call ptr @mlf_string(ptr @mlf.bytes.161, i64 2)
  %v163 = call ptr @mlf_prim1(i64 7, ptr %v112)
  %v164 = call ptr @mlf_prim2(i64 6, ptr %v162, ptr %v163)
  %v165 = call ptr @mlf_prim2(i64 6, ptr %v160, ptr %v164)
  %v166 = call ptr @mlf_prim2(i64 6, ptr %v68, ptr %v165)
  ret ptr %v166
}

define private ptr @mlf.code.348(ptr %env, ptr %arg) {
entry:
  %v349 = getelementptr i8, ptr %env, i64 24
  %v350 = load ptr, ptr %v349, align 8, !tbaa !3
  %v351 = getelementptr i8, ptr %env, i64 32
  %v352 = load ptr, ptr %v351, align 8, !tbaa !3
  %v353 = call ptr @mlf_force(ptr %v350)
  %v354 = call ptr @mlf_force(ptr %v352)
  %v355 = ptrtoint ptr %v353 to i64
  %v356 = ptrtoint ptr %v354 to i64
  %v357 = and i64 %v355, %v356
  %v358 = and i64 %v357, 1
  %v359 = icmp ne i64 %v358, 0
  br i1 %v359, label %yes.360, label %no.361
yes.360:
  %v363 = ashr i64 %v355, 1
  %v364 = ashr i64 %v356, 1
  %v365 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v363, i64 %v364)
  %v366 = extractvalue { i64, i1 } %v365, 0
  %v367 = extractvalue { i64, i1 } %v365, 1
  %v368 = xor i1 %v367, true
  %v369 = icmp sge i64 %v366, -4611686018427387904
  %v370 = icmp sle i64 %v366, 4611686018427387903
  %v371 = and i1 %v369, %v370
  %v372 = and i1 %v371, %v368
  br i1 %v372, label %yes.373, label %no.374
yes.373:
  %v376 = shl i64 %v366, 1
  %v377 = or i64 %v376, 1
  %v378 = inttoptr i64 %v377 to ptr
  br label %join.375
no.374:
  %v379 = call ptr @mlf_prim2(i64 14, ptr %v353, ptr %v354)
  br label %join.375
join.375:
  %v380 = phi ptr [ %v378, %yes.373 ], [ %v379, %no.374 ]
  br label %join.362
no.361:
  %v381 = call ptr @mlf_prim2(i64 14, ptr %v353, ptr %v354)
  br label %join.362
join.362:
  %v382 = phi ptr [ %v380, %join.375 ], [ %v381, %no.361 ]
  ret ptr %v382
}

define private ptr @mlf.code.571(ptr %env, ptr %arg) {
entry:
  %v572 = getelementptr i8, ptr %env, i64 24
  %v573 = load ptr, ptr %v572, align 8, !tbaa !3
  %v574 = call ptr @mlf_force(ptr %v573)
  %v575 = ptrtoint ptr %v574 to i64
  %v576 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v577 = and i64 %v575, %v576
  %v578 = and i64 %v577, 1
  %v579 = icmp ne i64 %v578, 0
  br i1 %v579, label %yes.580, label %no.581
yes.580:
  %v583 = sub i64 %v576, 1
  %v584 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v575, i64 %v583)
  %v585 = extractvalue { i64, i1 } %v584, 0
  %v586 = extractvalue { i64, i1 } %v584, 1
  br i1 %v586, label %yes.587, label %no.588
yes.587:
  %v590 = call ptr @mlf_add_int(ptr %v574, ptr inttoptr (i64 3 to ptr))
  br label %join.589
no.588:
  %v591 = inttoptr i64 %v585 to ptr
  br label %join.589
join.589:
  %v592 = phi ptr [ %v590, %yes.587 ], [ %v591, %no.588 ]
  br label %join.582
no.581:
  %v593 = call ptr @mlf_add_int(ptr %v574, ptr inttoptr (i64 3 to ptr))
  br label %join.582
join.582:
  %v594 = phi ptr [ %v592, %join.589 ], [ %v593, %no.581 ]
  ret ptr %v594
}

define private ptr @mlf.code.598(ptr %env, ptr %arg) {
entry:
  %v599 = getelementptr i8, ptr %env, i64 24
  %v600 = load ptr, ptr %v599, align 8, !tbaa !3
  %v601 = getelementptr i8, ptr %env, i64 32
  %v602 = load ptr, ptr %v601, align 8, !tbaa !3
  %v603 = call ptr @mlf_force(ptr %v600)
  %v604 = call ptr @mlf_force(ptr %v602)
  %v605 = call ptr @mlf_prim1(i64 7, ptr %v604)
  %v606 = call ptr @mlf_prim2(i64 6, ptr %v603, ptr %v605)
  ret ptr %v606
}

define private ptr @mlf.code.660(ptr %env, ptr %arg) {
entry:
  %v661 = getelementptr i8, ptr %env, i64 24
  %v662 = load ptr, ptr %v661, align 8, !tbaa !3
  %v663 = getelementptr i8, ptr %env, i64 32
  %v664 = load ptr, ptr %v663, align 8, !tbaa !3
  %v665 = call ptr @mlf_force(ptr %v664)
  %v667 = call ptr @mlf_string(ptr @mlf.bytes.666, i64 2)
  %v668 = call ptr @mlf_force(ptr %v662)
  %v669 = call ptr @mlf_prim1(i64 7, ptr %v668)
  %v670 = call ptr @mlf_prim2(i64 6, ptr %v667, ptr %v669)
  %v671 = call ptr @mlf_prim2(i64 6, ptr %v665, ptr %v670)
  ret ptr %v671
}

define private ptr @mlf.code.611(ptr %env, ptr %arg) {
entry:
  %v612 = getelementptr i8, ptr %env, i64 24
  %v613 = load ptr, ptr %v612, align 8, !tbaa !3
  %v614 = getelementptr i8, ptr %env, i64 32
  %v615 = load ptr, ptr %v614, align 8, !tbaa !3
  %v616 = call ptr @mlf_force(ptr %v613)
  %v617 = ptrtoint ptr %v616 to i64
  %v618 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v619 = and i64 %v617, %v618
  %v620 = and i64 %v619, 1
  %v621 = icmp ne i64 %v620, 0
  br i1 %v621, label %yes.622, label %no.623
yes.622:
  %v625 = ashr i64 %v617, 1
  %v626 = ashr i64 %v618, 1
  %v627 = icmp ne i64 %v626, 0
  %v628 = icmp eq i64 %v625, -4611686018427387904
  %v629 = icmp eq i64 %v626, -1
  %v630 = and i1 %v628, %v629
  %v631 = xor i1 %v630, true
  %v632 = and i1 %v627, %v631
  br i1 %v632, label %yes.633, label %no.634
yes.633:
  %v636 = srem i64 %v625, %v626
  %v637 = shl i64 %v636, 1
  %v638 = or i64 %v637, 1
  %v639 = inttoptr i64 %v638 to ptr
  br label %join.635
no.634:
  %v640 = call ptr @mlf_prim2(i64 16, ptr %v616, ptr inttoptr (i64 21 to ptr))
  br label %join.635
join.635:
  %v641 = phi ptr [ %v639, %yes.633 ], [ %v640, %no.634 ]
  br label %join.624
no.623:
  %v642 = call ptr @mlf_prim2(i64 16, ptr %v616, ptr inttoptr (i64 21 to ptr))
  br label %join.624
join.624:
  %v643 = phi ptr [ %v641, %join.635 ], [ %v642, %no.623 ]
  %v644 = ptrtoint ptr %v643 to i64
  %v645 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v646 = and i64 %v644, %v645
  %v647 = and i64 %v646, 1
  %v648 = icmp ne i64 %v647, 0
  br i1 %v648, label %yes.649, label %no.650
yes.649:
  %v652 = icmp eq i64 %v644, %v645
  %v653 = select i1 %v652, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.651
no.650:
  %v654 = call ptr @mlf_eq_int(ptr %v643, ptr inttoptr (i64 1 to ptr))
  br label %join.651
join.651:
  %v655 = phi ptr [ %v653, %yes.649 ], [ %v654, %no.650 ]
  %v656 = icmp eq ptr %v655, inttoptr (i64 6 to ptr)
  br i1 %v656, label %yes.657, label %no.658
yes.657:
  %v672 = call ptr @mlf_env_new(i64 2)
  %v673 = getelementptr i8, ptr %v672, i64 24
  store ptr %v616, ptr %v673, align 8, !tbaa !3
  %v674 = getelementptr i8, ptr %v672, i64 32
  store ptr %v615, ptr %v674, align 8, !tbaa !3
  %v675 = call ptr @mlf_thunk(ptr @mlf.code.660, ptr %v672)
  %v676 = call ptr @mlf_prim1(i64 3, ptr %v675)
  br label %join.659
no.658:
  %v677 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.659
join.659:
  %v678 = phi ptr [ %v676, %yes.657 ], [ %v677, %no.658 ]
  ret ptr %v678
}

define private ptr @mlf.code.702(ptr %env, ptr %arg) {
entry:
  %v703 = getelementptr i8, ptr %env, i64 24
  %v704 = load ptr, ptr %v703, align 8, !tbaa !3
  %v705 = call ptr @mlf_force(ptr %v704)
  %v706 = ptrtoint ptr %v705 to i64
  %v707 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v708 = and i64 %v706, %v707
  %v709 = and i64 %v708, 1
  %v710 = icmp ne i64 %v709, 0
  br i1 %v710, label %yes.711, label %no.712
yes.711:
  %v714 = ashr i64 %v706, 1
  %v715 = ashr i64 %v707, 1
  %v716 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v714, i64 %v715)
  %v717 = extractvalue { i64, i1 } %v716, 0
  %v718 = extractvalue { i64, i1 } %v716, 1
  %v719 = xor i1 %v718, true
  %v720 = icmp sge i64 %v717, -4611686018427387904
  %v721 = icmp sle i64 %v717, 4611686018427387903
  %v722 = and i1 %v720, %v721
  %v723 = and i1 %v722, %v719
  br i1 %v723, label %yes.724, label %no.725
yes.724:
  %v727 = shl i64 %v717, 1
  %v728 = or i64 %v727, 1
  %v729 = inttoptr i64 %v728 to ptr
  br label %join.726
no.725:
  %v730 = call ptr @mlf_prim2(i64 14, ptr %v705, ptr inttoptr (i64 21 to ptr))
  br label %join.726
join.726:
  %v731 = phi ptr [ %v729, %yes.724 ], [ %v730, %no.725 ]
  br label %join.713
no.712:
  %v732 = call ptr @mlf_prim2(i64 14, ptr %v705, ptr inttoptr (i64 21 to ptr))
  br label %join.713
join.713:
  %v733 = phi ptr [ %v731, %join.726 ], [ %v732, %no.712 ]
  ret ptr %v733
}

define private ptr @mlf.code.737(ptr %env, ptr %arg) {
entry:
  %v738 = getelementptr i8, ptr %env, i64 24
  %v739 = load ptr, ptr %v738, align 8, !tbaa !3
  %v740 = getelementptr i8, ptr %env, i64 32
  %v741 = load ptr, ptr %v740, align 8, !tbaa !3
  %v742 = getelementptr i8, ptr %env, i64 40
  %v743 = load ptr, ptr %v742, align 8, !tbaa !3
  %v744 = call ptr @mlf_force(ptr %v739)
  %v745 = call ptr @mlf_force(ptr %v741)
  %v746 = call ptr @mlf_force(ptr %v743)
  %v747 = ptrtoint ptr %v745 to i64
  %v748 = ptrtoint ptr %v746 to i64
  %v749 = and i64 %v747, %v748
  %v750 = and i64 %v749, 1
  %v751 = icmp ne i64 %v750, 0
  br i1 %v751, label %yes.752, label %no.753
yes.752:
  %v755 = ashr i64 %v747, 1
  %v756 = ashr i64 %v748, 1
  %v757 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v755, i64 %v756)
  %v758 = extractvalue { i64, i1 } %v757, 0
  %v759 = extractvalue { i64, i1 } %v757, 1
  %v760 = xor i1 %v759, true
  %v761 = icmp sge i64 %v758, -4611686018427387904
  %v762 = icmp sle i64 %v758, 4611686018427387903
  %v763 = and i1 %v761, %v762
  %v764 = and i1 %v763, %v760
  br i1 %v764, label %yes.765, label %no.766
yes.765:
  %v768 = shl i64 %v758, 1
  %v769 = or i64 %v768, 1
  %v770 = inttoptr i64 %v769 to ptr
  br label %join.767
no.766:
  %v771 = call ptr @mlf_prim2(i64 14, ptr %v745, ptr %v746)
  br label %join.767
join.767:
  %v772 = phi ptr [ %v770, %yes.765 ], [ %v771, %no.766 ]
  br label %join.754
no.753:
  %v773 = call ptr @mlf_prim2(i64 14, ptr %v745, ptr %v746)
  br label %join.754
join.754:
  %v774 = phi ptr [ %v772, %join.767 ], [ %v773, %no.753 ]
  %v775 = ptrtoint ptr %v744 to i64
  %v776 = ptrtoint ptr %v774 to i64
  %v777 = and i64 %v775, %v776
  %v778 = and i64 %v777, 1
  %v779 = icmp ne i64 %v778, 0
  br i1 %v779, label %yes.780, label %no.781
yes.780:
  %v783 = sub i64 %v776, 1
  %v784 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v775, i64 %v783)
  %v785 = extractvalue { i64, i1 } %v784, 0
  %v786 = extractvalue { i64, i1 } %v784, 1
  br i1 %v786, label %yes.787, label %no.788
yes.787:
  %v790 = call ptr @mlf_sub_int(ptr %v744, ptr %v774)
  br label %join.789
no.788:
  %v791 = inttoptr i64 %v785 to ptr
  br label %join.789
join.789:
  %v792 = phi ptr [ %v790, %yes.787 ], [ %v791, %no.788 ]
  br label %join.782
no.781:
  %v793 = call ptr @mlf_sub_int(ptr %v744, ptr %v774)
  br label %join.782
join.782:
  %v794 = phi ptr [ %v792, %join.789 ], [ %v793, %no.781 ]
  %v795 = ptrtoint ptr %v794 to i64
  %v796 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v797 = and i64 %v795, %v796
  %v798 = and i64 %v797, 1
  %v799 = icmp ne i64 %v798, 0
  br i1 %v799, label %yes.800, label %no.801
yes.800:
  %v803 = ashr i64 %v795, 1
  %v804 = ashr i64 %v796, 1
  %v805 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v803, i64 %v804)
  %v806 = extractvalue { i64, i1 } %v805, 0
  %v807 = extractvalue { i64, i1 } %v805, 1
  %v808 = xor i1 %v807, true
  %v809 = icmp sge i64 %v806, -4611686018427387904
  %v810 = icmp sle i64 %v806, 4611686018427387903
  %v811 = and i1 %v809, %v810
  %v812 = and i1 %v811, %v808
  br i1 %v812, label %yes.813, label %no.814
yes.813:
  %v816 = shl i64 %v806, 1
  %v817 = or i64 %v816, 1
  %v818 = inttoptr i64 %v817 to ptr
  br label %join.815
no.814:
  %v819 = call ptr @mlf_prim2(i64 14, ptr %v794, ptr inttoptr (i64 21 to ptr))
  br label %join.815
join.815:
  %v820 = phi ptr [ %v818, %yes.813 ], [ %v819, %no.814 ]
  br label %join.802
no.801:
  %v821 = call ptr @mlf_prim2(i64 14, ptr %v794, ptr inttoptr (i64 21 to ptr))
  br label %join.802
join.802:
  %v822 = phi ptr [ %v820, %join.815 ], [ %v821, %no.801 ]
  ret ptr %v822
}

define private ptr @mlf.code.828(ptr %env, ptr %arg) {
entry:
  %v829 = getelementptr i8, ptr %env, i64 24
  %v830 = load ptr, ptr %v829, align 8, !tbaa !3
  %v831 = getelementptr i8, ptr %env, i64 32
  %v832 = load ptr, ptr %v831, align 8, !tbaa !3
  %v833 = call ptr @mlf_force(ptr %v830)
  %v834 = ptrtoint ptr %v833 to i64
  %v835 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v836 = and i64 %v834, %v835
  %v837 = and i64 %v836, 1
  %v838 = icmp ne i64 %v837, 0
  br i1 %v838, label %yes.839, label %no.840
yes.839:
  %v842 = ashr i64 %v834, 1
  %v843 = ashr i64 %v835, 1
  %v844 = icmp ne i64 %v843, 0
  %v845 = icmp eq i64 %v842, -4611686018427387904
  %v846 = icmp eq i64 %v843, -1
  %v847 = and i1 %v845, %v846
  %v848 = xor i1 %v847, true
  %v849 = and i1 %v844, %v848
  br i1 %v849, label %yes.850, label %no.851
yes.850:
  %v853 = srem i64 %v842, %v843
  %v854 = shl i64 %v853, 1
  %v855 = or i64 %v854, 1
  %v856 = inttoptr i64 %v855 to ptr
  br label %join.852
no.851:
  %v857 = call ptr @mlf_prim2(i64 16, ptr %v833, ptr inttoptr (i64 21 to ptr))
  br label %join.852
join.852:
  %v858 = phi ptr [ %v856, %yes.850 ], [ %v857, %no.851 ]
  br label %join.841
no.840:
  %v859 = call ptr @mlf_prim2(i64 16, ptr %v833, ptr inttoptr (i64 21 to ptr))
  br label %join.841
join.841:
  %v860 = phi ptr [ %v858, %join.852 ], [ %v859, %no.840 ]
  %v861 = ptrtoint ptr %v860 to i64
  %v862 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v863 = and i64 %v861, %v862
  %v864 = and i64 %v863, 1
  %v865 = icmp ne i64 %v864, 0
  br i1 %v865, label %yes.866, label %no.867
yes.866:
  %v869 = icmp eq i64 %v861, %v862
  %v870 = select i1 %v869, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.868
no.867:
  %v871 = call ptr @mlf_eq_int(ptr %v860, ptr inttoptr (i64 1 to ptr))
  br label %join.868
join.868:
  %v872 = phi ptr [ %v870, %yes.866 ], [ %v871, %no.867 ]
  %v873 = icmp eq ptr %v872, inttoptr (i64 6 to ptr)
  br i1 %v873, label %yes.874, label %no.875
yes.874:
  %v878 = call ptr @mlf_string(ptr @mlf.bytes.877, i64 0)
  br label %join.876
no.875:
  %v879 = call ptr @mlf_force(ptr %v832)
  br label %join.876
join.876:
  %v880 = phi ptr [ %v878, %yes.874 ], [ %v879, %no.875 ]
  ret ptr %v880
}

define private ptr @mlf.code.683(ptr %env, ptr %arg) {
entry:
  %v684 = getelementptr i8, ptr %env, i64 24
  %v685 = load ptr, ptr %v684, align 8, !tbaa !3
  %v686 = getelementptr i8, ptr %env, i64 32
  %v687 = load ptr, ptr %v686, align 8, !tbaa !3
  %v688 = getelementptr i8, ptr %env, i64 40
  %v689 = load ptr, ptr %v688, align 8, !tbaa !3
  %v690 = getelementptr i8, ptr %env, i64 48
  %v691 = load ptr, ptr %v690, align 8, !tbaa !3
  %v692 = getelementptr i8, ptr %env, i64 56
  %v693 = load ptr, ptr %v692, align 8, !tbaa !3
  %v694 = getelementptr i8, ptr %env, i64 64
  %v695 = load ptr, ptr %v694, align 8, !tbaa !3
  %v696 = getelementptr i8, ptr %env, i64 72
  %v697 = load ptr, ptr %v696, align 8, !tbaa !3
  %v698 = getelementptr i8, ptr %env, i64 80
  %v699 = load ptr, ptr %v698, align 8, !tbaa !3
  %v700 = call ptr @mlf_force(ptr %v685)
  %v701 = call ptr @mlf_force(ptr %v697)
  %v734 = call ptr @mlf_env_new(i64 1)
  %v735 = getelementptr i8, ptr %v734, i64 24
  store ptr %v689, ptr %v735, align 8, !tbaa !3
  %v736 = call ptr @mlf_thunk(ptr @mlf.code.702, ptr %v734)
  %v823 = call ptr @mlf_env_new(i64 3)
  %v824 = getelementptr i8, ptr %v823, i64 24
  store ptr %v691, ptr %v824, align 8, !tbaa !3
  %v825 = getelementptr i8, ptr %v823, i64 32
  store ptr %v693, ptr %v825, align 8, !tbaa !3
  %v826 = getelementptr i8, ptr %v823, i64 40
  store ptr %v695, ptr %v826, align 8, !tbaa !3
  %v827 = call ptr @mlf_thunk(ptr @mlf.code.737, ptr %v823)
  %v881 = call ptr @mlf_env_new(i64 2)
  %v882 = getelementptr i8, ptr %v881, i64 24
  store ptr %v701, ptr %v882, align 8, !tbaa !3
  %v883 = getelementptr i8, ptr %v881, i64 32
  store ptr %v699, ptr %v883, align 8, !tbaa !3
  %v884 = call ptr @mlf_thunk(ptr @mlf.code.828, ptr %v881)
  %v885 = call ptr @mlf.worker.2(ptr %v700, ptr %v701, ptr %v687, ptr %v736, ptr %v827, ptr %v693, ptr %v884)
  ret ptr %v885
}

define private ptr @mlf.worker.2(ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6) {
entry:
  %v3 = ptrtoint ptr %a1 to i64
  %v4 = ptrtoint ptr %a0 to i64
  %v5 = and i64 %v3, %v4
  %v6 = and i64 %v5, 1
  %v7 = icmp ne i64 %v6, 0
  br i1 %v7, label %yes.8, label %no.9
yes.8:
  %v11 = icmp eq i64 %v3, %v4
  %v12 = select i1 %v11, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.10
no.9:
  %v13 = call ptr @mlf_eq_int(ptr %a1, ptr %a0)
  br label %join.10
join.10:
  %v14 = phi ptr [ %v12, %yes.8 ], [ %v13, %no.9 ]
  %v15 = icmp eq ptr %v14, inttoptr (i64 6 to ptr)
  br i1 %v15, label %yes.16, label %no.17
yes.16:
  %v19 = ptrtoint ptr %a1 to i64
  %v20 = ptrtoint ptr inttoptr (i64 21 to ptr) to i64
  %v21 = and i64 %v19, %v20
  %v22 = and i64 %v21, 1
  %v23 = icmp ne i64 %v22, 0
  br i1 %v23, label %yes.24, label %no.25
yes.24:
  %v27 = ashr i64 %v19, 1
  %v28 = ashr i64 %v20, 1
  %v29 = icmp ne i64 %v28, 0
  %v30 = icmp eq i64 %v27, -4611686018427387904
  %v31 = icmp eq i64 %v28, -1
  %v32 = and i1 %v30, %v31
  %v33 = xor i1 %v32, true
  %v34 = and i1 %v29, %v33
  br i1 %v34, label %yes.35, label %no.36
yes.35:
  %v38 = srem i64 %v27, %v28
  %v39 = shl i64 %v38, 1
  %v40 = or i64 %v39, 1
  %v41 = inttoptr i64 %v40 to ptr
  br label %join.37
no.36:
  %v42 = call ptr @mlf_prim2(i64 16, ptr %a1, ptr inttoptr (i64 21 to ptr))
  br label %join.37
join.37:
  %v43 = phi ptr [ %v41, %yes.35 ], [ %v42, %no.36 ]
  br label %join.26
no.25:
  %v44 = call ptr @mlf_prim2(i64 16, ptr %a1, ptr inttoptr (i64 21 to ptr))
  br label %join.26
join.26:
  %v45 = phi ptr [ %v43, %join.37 ], [ %v44, %no.25 ]
  %v46 = ptrtoint ptr %v45 to i64
  %v47 = ptrtoint ptr inttoptr (i64 1 to ptr) to i64
  %v48 = and i64 %v46, %v47
  %v49 = and i64 %v48, 1
  %v50 = icmp ne i64 %v49, 0
  br i1 %v50, label %yes.51, label %no.52
yes.51:
  %v54 = icmp eq i64 %v46, %v47
  %v55 = select i1 %v54, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.53
no.52:
  %v56 = call ptr @mlf_eq_int(ptr %v45, ptr inttoptr (i64 1 to ptr))
  br label %join.53
join.53:
  %v57 = phi ptr [ %v55, %yes.51 ], [ %v56, %no.52 ]
  %v58 = icmp eq ptr %v57, inttoptr (i64 6 to ptr)
  br i1 %v58, label %yes.59, label %no.60
yes.59:
  %v62 = call ptr @mlf_prim1(i64 0, ptr inttoptr (i64 4 to ptr))
  br label %join.61
no.60:
  %v167 = call ptr @mlf_env_new(i64 2)
  %v168 = getelementptr i8, ptr %v167, i64 24
  store ptr %a1, ptr %v168, align 8, !tbaa !3
  %v169 = getelementptr i8, ptr %v167, i64 32
  store ptr %a6, ptr %v169, align 8, !tbaa !3
  %v170 = call ptr @mlf_thunk(ptr @mlf.code.63, ptr %v167)
  %v171 = call ptr @mlf_prim1(i64 3, ptr %v170)
  br label %join.61
join.61:
  %v172 = phi ptr [ %v62, %yes.59 ], [ %v171, %no.60 ]
  br label %join.18
no.17:
  %v173 = call ptr @mlf_force(ptr %a2)
  %v174 = ptrtoint ptr %v173 to i64
  %v175 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v176 = and i64 %v174, %v175
  %v177 = and i64 %v176, 1
  %v178 = icmp ne i64 %v177, 0
  br i1 %v178, label %yes.179, label %no.180
yes.179:
  %v182 = sub i64 %v175, 1
  %v183 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v174, i64 %v182)
  %v184 = extractvalue { i64, i1 } %v183, 0
  %v185 = extractvalue { i64, i1 } %v183, 1
  br i1 %v185, label %yes.186, label %no.187
yes.186:
  %v189 = call ptr @mlf_add_int(ptr %v173, ptr inttoptr (i64 3 to ptr))
  br label %join.188
no.187:
  %v190 = inttoptr i64 %v184 to ptr
  br label %join.188
join.188:
  %v191 = phi ptr [ %v189, %yes.186 ], [ %v190, %no.187 ]
  br label %join.181
no.180:
  %v192 = call ptr @mlf_add_int(ptr %v173, ptr inttoptr (i64 3 to ptr))
  br label %join.181
join.181:
  %v193 = phi ptr [ %v191, %join.188 ], [ %v192, %no.180 ]
  %v194 = ptrtoint ptr %v193 to i64
  %v195 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v196 = and i64 %v194, %v195
  %v197 = and i64 %v196, 1
  %v198 = icmp ne i64 %v197, 0
  br i1 %v198, label %yes.199, label %no.200
yes.199:
  %v202 = ashr i64 %v194, 1
  %v203 = ashr i64 %v195, 1
  %v204 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v202, i64 %v203)
  %v205 = extractvalue { i64, i1 } %v204, 0
  %v206 = extractvalue { i64, i1 } %v204, 1
  %v207 = xor i1 %v206, true
  %v208 = icmp sge i64 %v205, -4611686018427387904
  %v209 = icmp sle i64 %v205, 4611686018427387903
  %v210 = and i1 %v208, %v209
  %v211 = and i1 %v210, %v207
  br i1 %v211, label %yes.212, label %no.213
yes.212:
  %v215 = shl i64 %v205, 1
  %v216 = or i64 %v215, 1
  %v217 = inttoptr i64 %v216 to ptr
  br label %join.214
no.213:
  %v218 = call ptr @mlf_prim2(i64 14, ptr %v193, ptr inttoptr (i64 5 to ptr))
  br label %join.214
join.214:
  %v219 = phi ptr [ %v217, %yes.212 ], [ %v218, %no.213 ]
  br label %join.201
no.200:
  %v220 = call ptr @mlf_prim2(i64 14, ptr %v193, ptr inttoptr (i64 5 to ptr))
  br label %join.201
join.201:
  %v221 = phi ptr [ %v219, %join.214 ], [ %v220, %no.200 ]
  %v222 = ptrtoint ptr %v221 to i64
  %v223 = ptrtoint ptr inttoptr (i64 3 to ptr) to i64
  %v224 = and i64 %v222, %v223
  %v225 = and i64 %v224, 1
  %v226 = icmp ne i64 %v225, 0
  br i1 %v226, label %yes.227, label %no.228
yes.227:
  %v230 = sub i64 %v223, 1
  %v231 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v222, i64 %v230)
  %v232 = extractvalue { i64, i1 } %v231, 0
  %v233 = extractvalue { i64, i1 } %v231, 1
  br i1 %v233, label %yes.234, label %no.235
yes.234:
  %v237 = call ptr @mlf_add_int(ptr %v221, ptr inttoptr (i64 3 to ptr))
  br label %join.236
no.235:
  %v238 = inttoptr i64 %v232 to ptr
  br label %join.236
join.236:
  %v239 = phi ptr [ %v237, %yes.234 ], [ %v238, %no.235 ]
  br label %join.229
no.228:
  %v240 = call ptr @mlf_add_int(ptr %v221, ptr inttoptr (i64 3 to ptr))
  br label %join.229
join.229:
  %v241 = phi ptr [ %v239, %join.236 ], [ %v240, %no.228 ]
  %v242 = call ptr @mlf_force(ptr %a3)
  %v243 = ptrtoint ptr %v242 to i64
  %v244 = ptrtoint ptr %v193 to i64
  %v245 = and i64 %v243, %v244
  %v246 = and i64 %v245, 1
  %v247 = icmp ne i64 %v246, 0
  br i1 %v247, label %yes.248, label %no.249
yes.248:
  %v251 = ashr i64 %v243, 1
  %v252 = ashr i64 %v244, 1
  %v253 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v251, i64 %v252)
  %v254 = extractvalue { i64, i1 } %v253, 0
  %v255 = extractvalue { i64, i1 } %v253, 1
  %v256 = xor i1 %v255, true
  %v257 = icmp sge i64 %v254, -4611686018427387904
  %v258 = icmp sle i64 %v254, 4611686018427387903
  %v259 = and i1 %v257, %v258
  %v260 = and i1 %v259, %v256
  br i1 %v260, label %yes.261, label %no.262
yes.261:
  %v264 = shl i64 %v254, 1
  %v265 = or i64 %v264, 1
  %v266 = inttoptr i64 %v265 to ptr
  br label %join.263
no.262:
  %v267 = call ptr @mlf_prim2(i64 14, ptr %v242, ptr %v193)
  br label %join.263
join.263:
  %v268 = phi ptr [ %v266, %yes.261 ], [ %v267, %no.262 ]
  br label %join.250
no.249:
  %v269 = call ptr @mlf_prim2(i64 14, ptr %v242, ptr %v193)
  br label %join.250
join.250:
  %v270 = phi ptr [ %v268, %join.263 ], [ %v269, %no.249 ]
  %v271 = call ptr @mlf_force(ptr %a4)
  %v272 = ptrtoint ptr %v242 to i64
  %v273 = ptrtoint ptr inttoptr (i64 5 to ptr) to i64
  %v274 = and i64 %v272, %v273
  %v275 = and i64 %v274, 1
  %v276 = icmp ne i64 %v275, 0
  br i1 %v276, label %yes.277, label %no.278
yes.277:
  %v280 = ashr i64 %v272, 1
  %v281 = ashr i64 %v273, 1
  %v282 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v280, i64 %v281)
  %v283 = extractvalue { i64, i1 } %v282, 0
  %v284 = extractvalue { i64, i1 } %v282, 1
  %v285 = xor i1 %v284, true
  %v286 = icmp sge i64 %v283, -4611686018427387904
  %v287 = icmp sle i64 %v283, 4611686018427387903
  %v288 = and i1 %v286, %v287
  %v289 = and i1 %v288, %v285
  br i1 %v289, label %yes.290, label %no.291
yes.290:
  %v293 = shl i64 %v283, 1
  %v294 = or i64 %v293, 1
  %v295 = inttoptr i64 %v294 to ptr
  br label %join.292
no.291:
  %v296 = call ptr @mlf_prim2(i64 14, ptr %v242, ptr inttoptr (i64 5 to ptr))
  br label %join.292
join.292:
  %v297 = phi ptr [ %v295, %yes.290 ], [ %v296, %no.291 ]
  br label %join.279
no.278:
  %v298 = call ptr @mlf_prim2(i64 14, ptr %v242, ptr inttoptr (i64 5 to ptr))
  br label %join.279
join.279:
  %v299 = phi ptr [ %v297, %join.292 ], [ %v298, %no.278 ]
  %v300 = ptrtoint ptr %v271 to i64
  %v301 = ptrtoint ptr %v299 to i64
  %v302 = and i64 %v300, %v301
  %v303 = and i64 %v302, 1
  %v304 = icmp ne i64 %v303, 0
  br i1 %v304, label %yes.305, label %no.306
yes.305:
  %v308 = sub i64 %v301, 1
  %v309 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v300, i64 %v308)
  %v310 = extractvalue { i64, i1 } %v309, 0
  %v311 = extractvalue { i64, i1 } %v309, 1
  br i1 %v311, label %yes.312, label %no.313
yes.312:
  %v315 = call ptr @mlf_add_int(ptr %v271, ptr %v299)
  br label %join.314
no.313:
  %v316 = inttoptr i64 %v310 to ptr
  br label %join.314
join.314:
  %v317 = phi ptr [ %v315, %yes.312 ], [ %v316, %no.313 ]
  br label %join.307
no.306:
  %v318 = call ptr @mlf_add_int(ptr %v271, ptr %v299)
  br label %join.307
join.307:
  %v319 = phi ptr [ %v317, %join.314 ], [ %v318, %no.306 ]
  %v320 = ptrtoint ptr %v319 to i64
  %v321 = ptrtoint ptr %v241 to i64
  %v322 = and i64 %v320, %v321
  %v323 = and i64 %v322, 1
  %v324 = icmp ne i64 %v323, 0
  br i1 %v324, label %yes.325, label %no.326
yes.325:
  %v328 = ashr i64 %v320, 1
  %v329 = ashr i64 %v321, 1
  %v330 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v328, i64 %v329)
  %v331 = extractvalue { i64, i1 } %v330, 0
  %v332 = extractvalue { i64, i1 } %v330, 1
  %v333 = xor i1 %v332, true
  %v334 = icmp sge i64 %v331, -4611686018427387904
  %v335 = icmp sle i64 %v331, 4611686018427387903
  %v336 = and i1 %v334, %v335
  %v337 = and i1 %v336, %v333
  br i1 %v337, label %yes.338, label %no.339
yes.338:
  %v341 = shl i64 %v331, 1
  %v342 = or i64 %v341, 1
  %v343 = inttoptr i64 %v342 to ptr
  br label %join.340
no.339:
  %v344 = call ptr @mlf_prim2(i64 14, ptr %v319, ptr %v241)
  br label %join.340
join.340:
  %v345 = phi ptr [ %v343, %yes.338 ], [ %v344, %no.339 ]
  br label %join.327
no.326:
  %v346 = call ptr @mlf_prim2(i64 14, ptr %v319, ptr %v241)
  br label %join.327
join.327:
  %v347 = phi ptr [ %v345, %join.340 ], [ %v346, %no.326 ]
  %v383 = call ptr @mlf_env_new(i64 2)
  %v384 = getelementptr i8, ptr %v383, i64 24
  store ptr %a5, ptr %v384, align 8, !tbaa !3
  %v385 = getelementptr i8, ptr %v383, i64 32
  store ptr %v241, ptr %v385, align 8, !tbaa !3
  %v386 = call ptr @mlf_thunk(ptr @mlf.code.348, ptr %v383)
  %v387 = ptrtoint ptr %v347 to i64
  %v388 = ptrtoint ptr %v270 to i64
  %v389 = and i64 %v387, %v388
  %v390 = and i64 %v389, 1
  %v391 = icmp ne i64 %v390, 0
  br i1 %v391, label %yes.392, label %no.393
yes.392:
  %v395 = icmp slt i64 %v387, %v388
  %v396 = select i1 %v395, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.394
no.393:
  %v397 = call ptr @mlf_lt_int(ptr %v347, ptr %v270)
  br label %join.394
join.394:
  %v398 = phi ptr [ %v396, %yes.392 ], [ %v397, %no.393 ]
  %v399 = icmp eq ptr %v398, inttoptr (i64 6 to ptr)
  br i1 %v399, label %yes.400, label %no.401
yes.400:
  %v403 = call ptr @mlf.worker.2(ptr %a0, ptr %a1, ptr %v193, ptr %v270, ptr %v347, ptr %v386, ptr %a6)
  br label %join.402
no.401:
  %v404 = ptrtoint ptr %v270 to i64
  %v405 = ptrtoint ptr inttoptr (i64 7 to ptr) to i64
  %v406 = and i64 %v404, %v405
  %v407 = and i64 %v406, 1
  %v408 = icmp ne i64 %v407, 0
  br i1 %v408, label %yes.409, label %no.410
yes.409:
  %v412 = ashr i64 %v404, 1
  %v413 = ashr i64 %v405, 1
  %v414 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v412, i64 %v413)
  %v415 = extractvalue { i64, i1 } %v414, 0
  %v416 = extractvalue { i64, i1 } %v414, 1
  %v417 = xor i1 %v416, true
  %v418 = icmp sge i64 %v415, -4611686018427387904
  %v419 = icmp sle i64 %v415, 4611686018427387903
  %v420 = and i1 %v418, %v419
  %v421 = and i1 %v420, %v417
  br i1 %v421, label %yes.422, label %no.423
yes.422:
  %v425 = shl i64 %v415, 1
  %v426 = or i64 %v425, 1
  %v427 = inttoptr i64 %v426 to ptr
  br label %join.424
no.423:
  %v428 = call ptr @mlf_prim2(i64 14, ptr %v270, ptr inttoptr (i64 7 to ptr))
  br label %join.424
join.424:
  %v429 = phi ptr [ %v427, %yes.422 ], [ %v428, %no.423 ]
  br label %join.411
no.410:
  %v430 = call ptr @mlf_prim2(i64 14, ptr %v270, ptr inttoptr (i64 7 to ptr))
  br label %join.411
join.411:
  %v431 = phi ptr [ %v429, %join.424 ], [ %v430, %no.410 ]
  %v432 = ptrtoint ptr %v431 to i64
  %v433 = ptrtoint ptr %v347 to i64
  %v434 = and i64 %v432, %v433
  %v435 = and i64 %v434, 1
  %v436 = icmp ne i64 %v435, 0
  br i1 %v436, label %yes.437, label %no.438
yes.437:
  %v440 = sub i64 %v433, 1
  %v441 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v432, i64 %v440)
  %v442 = extractvalue { i64, i1 } %v441, 0
  %v443 = extractvalue { i64, i1 } %v441, 1
  br i1 %v443, label %yes.444, label %no.445
yes.444:
  %v447 = call ptr @mlf_add_int(ptr %v431, ptr %v347)
  br label %join.446
no.445:
  %v448 = inttoptr i64 %v442 to ptr
  br label %join.446
join.446:
  %v449 = phi ptr [ %v447, %yes.444 ], [ %v448, %no.445 ]
  br label %join.439
no.438:
  %v450 = call ptr @mlf_add_int(ptr %v431, ptr %v347)
  br label %join.439
join.439:
  %v451 = phi ptr [ %v449, %join.446 ], [ %v450, %no.438 ]
  %v452 = call ptr @mlf_force(ptr %v386)
  %v453 = ptrtoint ptr %v451 to i64
  %v454 = ptrtoint ptr %v452 to i64
  %v455 = and i64 %v453, %v454
  %v456 = and i64 %v455, 1
  %v457 = icmp ne i64 %v456, 0
  br i1 %v457, label %yes.458, label %no.459
yes.458:
  %v461 = ashr i64 %v453, 1
  %v462 = ashr i64 %v454, 1
  %v463 = icmp ne i64 %v462, 0
  %v464 = icmp eq i64 %v461, -4611686018427387904
  %v465 = icmp eq i64 %v462, -1
  %v466 = and i1 %v464, %v465
  %v467 = xor i1 %v466, true
  %v468 = and i1 %v463, %v467
  br i1 %v468, label %yes.469, label %no.470
yes.469:
  %v472 = sdiv i64 %v461, %v462
  %v473 = shl i64 %v472, 1
  %v474 = or i64 %v473, 1
  %v475 = inttoptr i64 %v474 to ptr
  br label %join.471
no.470:
  %v476 = call ptr @mlf_prim2(i64 15, ptr %v451, ptr %v452)
  br label %join.471
join.471:
  %v477 = phi ptr [ %v475, %yes.469 ], [ %v476, %no.470 ]
  br label %join.460
no.459:
  %v478 = call ptr @mlf_prim2(i64 15, ptr %v451, ptr %v452)
  br label %join.460
join.460:
  %v479 = phi ptr [ %v477, %join.471 ], [ %v478, %no.459 ]
  %v480 = ptrtoint ptr %v270 to i64
  %v481 = ptrtoint ptr inttoptr (i64 9 to ptr) to i64
  %v482 = and i64 %v480, %v481
  %v483 = and i64 %v482, 1
  %v484 = icmp ne i64 %v483, 0
  br i1 %v484, label %yes.485, label %no.486
yes.485:
  %v488 = ashr i64 %v480, 1
  %v489 = ashr i64 %v481, 1
  %v490 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v488, i64 %v489)
  %v491 = extractvalue { i64, i1 } %v490, 0
  %v492 = extractvalue { i64, i1 } %v490, 1
  %v493 = xor i1 %v492, true
  %v494 = icmp sge i64 %v491, -4611686018427387904
  %v495 = icmp sle i64 %v491, 4611686018427387903
  %v496 = and i1 %v494, %v495
  %v497 = and i1 %v496, %v493
  br i1 %v497, label %yes.498, label %no.499
yes.498:
  %v501 = shl i64 %v491, 1
  %v502 = or i64 %v501, 1
  %v503 = inttoptr i64 %v502 to ptr
  br label %join.500
no.499:
  %v504 = call ptr @mlf_prim2(i64 14, ptr %v270, ptr inttoptr (i64 9 to ptr))
  br label %join.500
join.500:
  %v505 = phi ptr [ %v503, %yes.498 ], [ %v504, %no.499 ]
  br label %join.487
no.486:
  %v506 = call ptr @mlf_prim2(i64 14, ptr %v270, ptr inttoptr (i64 9 to ptr))
  br label %join.487
join.487:
  %v507 = phi ptr [ %v505, %join.500 ], [ %v506, %no.486 ]
  %v508 = ptrtoint ptr %v507 to i64
  %v509 = ptrtoint ptr %v347 to i64
  %v510 = and i64 %v508, %v509
  %v511 = and i64 %v510, 1
  %v512 = icmp ne i64 %v511, 0
  br i1 %v512, label %yes.513, label %no.514
yes.513:
  %v516 = sub i64 %v509, 1
  %v517 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v508, i64 %v516)
  %v518 = extractvalue { i64, i1 } %v517, 0
  %v519 = extractvalue { i64, i1 } %v517, 1
  br i1 %v519, label %yes.520, label %no.521
yes.520:
  %v523 = call ptr @mlf_add_int(ptr %v507, ptr %v347)
  br label %join.522
no.521:
  %v524 = inttoptr i64 %v518 to ptr
  br label %join.522
join.522:
  %v525 = phi ptr [ %v523, %yes.520 ], [ %v524, %no.521 ]
  br label %join.515
no.514:
  %v526 = call ptr @mlf_add_int(ptr %v507, ptr %v347)
  br label %join.515
join.515:
  %v527 = phi ptr [ %v525, %join.522 ], [ %v526, %no.514 ]
  %v528 = ptrtoint ptr %v527 to i64
  %v529 = ptrtoint ptr %v452 to i64
  %v530 = and i64 %v528, %v529
  %v531 = and i64 %v530, 1
  %v532 = icmp ne i64 %v531, 0
  br i1 %v532, label %yes.533, label %no.534
yes.533:
  %v536 = ashr i64 %v528, 1
  %v537 = ashr i64 %v529, 1
  %v538 = icmp ne i64 %v537, 0
  %v539 = icmp eq i64 %v536, -4611686018427387904
  %v540 = icmp eq i64 %v537, -1
  %v541 = and i1 %v539, %v540
  %v542 = xor i1 %v541, true
  %v543 = and i1 %v538, %v542
  br i1 %v543, label %yes.544, label %no.545
yes.544:
  %v547 = sdiv i64 %v536, %v537
  %v548 = shl i64 %v547, 1
  %v549 = or i64 %v548, 1
  %v550 = inttoptr i64 %v549 to ptr
  br label %join.546
no.545:
  %v551 = call ptr @mlf_prim2(i64 15, ptr %v527, ptr %v452)
  br label %join.546
join.546:
  %v552 = phi ptr [ %v550, %yes.544 ], [ %v551, %no.545 ]
  br label %join.535
no.534:
  %v553 = call ptr @mlf_prim2(i64 15, ptr %v527, ptr %v452)
  br label %join.535
join.535:
  %v554 = phi ptr [ %v552, %join.546 ], [ %v553, %no.534 ]
  %v555 = ptrtoint ptr %v479 to i64
  %v556 = ptrtoint ptr %v554 to i64
  %v557 = and i64 %v555, %v556
  %v558 = and i64 %v557, 1
  %v559 = icmp ne i64 %v558, 0
  br i1 %v559, label %yes.560, label %no.561
yes.560:
  %v563 = icmp eq i64 %v555, %v556
  %v564 = select i1 %v563, ptr inttoptr (i64 6 to ptr), ptr inttoptr (i64 2 to ptr)
  br label %join.562
no.561:
  %v565 = call ptr @mlf_eq_int(ptr %v479, ptr %v554)
  br label %join.562
join.562:
  %v566 = phi ptr [ %v564, %yes.560 ], [ %v565, %no.561 ]
  %v567 = icmp eq ptr %v566, inttoptr (i64 6 to ptr)
  br i1 %v567, label %yes.568, label %no.569
yes.568:
  %v595 = call ptr @mlf_env_new(i64 1)
  %v596 = getelementptr i8, ptr %v595, i64 24
  store ptr %a1, ptr %v596, align 8, !tbaa !3
  %v597 = call ptr @mlf_thunk(ptr @mlf.code.571, ptr %v595)
  %v607 = call ptr @mlf_env_new(i64 2)
  %v608 = getelementptr i8, ptr %v607, i64 24
  store ptr %a6, ptr %v608, align 8, !tbaa !3
  %v609 = getelementptr i8, ptr %v607, i64 32
  store ptr %v479, ptr %v609, align 8, !tbaa !3
  %v610 = call ptr @mlf_thunk(ptr @mlf.code.598, ptr %v607)
  %v679 = call ptr @mlf_env_new(i64 2)
  %v680 = getelementptr i8, ptr %v679, i64 24
  store ptr %v597, ptr %v680, align 8, !tbaa !3
  %v681 = getelementptr i8, ptr %v679, i64 32
  store ptr %v610, ptr %v681, align 8, !tbaa !3
  %v682 = call ptr @mlf_thunk(ptr @mlf.code.611, ptr %v679)
  %v886 = call ptr @mlf_env_new(i64 8)
  %v887 = getelementptr i8, ptr %v886, i64 24
  store ptr %a0, ptr %v887, align 8, !tbaa !3
  %v888 = getelementptr i8, ptr %v886, i64 32
  store ptr %v193, ptr %v888, align 8, !tbaa !3
  %v889 = getelementptr i8, ptr %v886, i64 40
  store ptr %v270, ptr %v889, align 8, !tbaa !3
  %v890 = getelementptr i8, ptr %v886, i64 48
  store ptr %v347, ptr %v890, align 8, !tbaa !3
  %v891 = getelementptr i8, ptr %v886, i64 56
  store ptr %v452, ptr %v891, align 8, !tbaa !3
  %v892 = getelementptr i8, ptr %v886, i64 64
  store ptr %v479, ptr %v892, align 8, !tbaa !3
  %v893 = getelementptr i8, ptr %v886, i64 72
  store ptr %v597, ptr %v893, align 8, !tbaa !3
  %v894 = getelementptr i8, ptr %v886, i64 80
  store ptr %v610, ptr %v894, align 8, !tbaa !3
  %v895 = call ptr @mlf_closure(ptr @mlf.code.683, ptr %v886)
  %v896 = call ptr @mlf_prim2(i64 1, ptr %v682, ptr %v895)
  br label %join.570
no.569:
  %v897 = call ptr @mlf.worker.2(ptr %a0, ptr %a1, ptr %v193, ptr %v270, ptr %v347, ptr %v452, ptr %a6)
  br label %join.570
join.570:
  %v898 = phi ptr [ %v896, %yes.568 ], [ %v897, %no.569 ]
  br label %join.402
join.402:
  %v899 = phi ptr [ %v403, %yes.400 ], [ %v898, %join.570 ]
  br label %join.18
join.18:
  %v900 = phi ptr [ %v172, %join.61 ], [ %v899, %join.402 ]
  ret ptr %v900
}

define private ptr @mlf.code.2(ptr %env, ptr %arg) {
entry:
  %v901 = call ptr @mlf_force(ptr %arg)
  %v902 = call ptr @mlf_prim1(i64 17, ptr %v901)
  %v904 = call ptr @mlf_string(ptr @mlf.bytes.903, i64 0)
  %v905 = call ptr @mlf.worker.2(ptr %v902, ptr inttoptr (i64 1 to ptr), ptr inttoptr (i64 1 to ptr), ptr inttoptr (i64 3 to ptr), ptr inttoptr (i64 1 to ptr), ptr inttoptr (i64 3 to ptr), ptr %v904)
  ret ptr %v905
}

define private ptr @mlf.code.0(ptr %env, ptr %arg) {
entry:
  %v1 = call ptr @mlf_primitive(i64 4)
  %v906 = call ptr @mlf_closure(ptr @mlf.code.2, ptr null)
  %v907 = call ptr @mlf_prim2(i64 1, ptr %v1, ptr %v906)
  ret ptr %v907
}

declare void @mlf_require_standard_abi()
define ptr @mlf_entry() {
  call void @mlf_require_standard_abi()
  %root = call ptr @mlf.code.0(ptr null, ptr null)
  ret ptr %root
}
define i32 @main(i32 %argc, ptr %argv) {
  call void @mlf_set_args(i32 %argc, ptr %argv)
  %root = call ptr @mlf_entry()
  %status = call i32 @mlf_run(ptr %root, i64 1)
  ret i32 %status
}
